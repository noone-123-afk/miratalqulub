import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { B as Send, D as Sparkles, K as RotateCcw, T as Square, hn as CircleAlert, it as Pause, lt as Mic, o as Volume2, r as X, tt as Play } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import { n as AnimatePresence, t as motion } from "./vendor-motion-BS7ODJw7.js";
//#region src/hooks/useLiveChat.ts
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
function useLiveChat(profile) {
	const [isConnected, setIsConnected] = (0, import_react.useState)(false);
	const [myUserId, setMyUserId] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("idle");
	const [partner, setPartner] = (0, import_react.useState)(null);
	const [roomId, setRoomId] = (0, import_react.useState)(null);
	const [compatibilityScore, setCompatibilityScore] = (0, import_react.useState)(95);
	const [compatibilityReason, setCompatibilityReason] = (0, import_react.useState)("");
	const [messages, setMessages] = (0, import_react.useState)([]);
	const [partnerIsTyping, setPartnerIsTyping] = (0, import_react.useState)(false);
	const [partnerLeftMessage, setPartnerLeftMessage] = (0, import_react.useState)(null);
	const [onlineCount, setOnlineCount] = (0, import_react.useState)(1);
	const [searchingCount, setSearchingCount] = (0, import_react.useState)(0);
	const [isRealPerson, setIsRealPerson] = (0, import_react.useState)(false);
	const [privateRoomCode, setPrivateRoomCode] = (0, import_react.useState)(null);
	const [roomErrorMessage, setRoomErrorMessage] = (0, import_react.useState)(null);
	const [latestBlindDateEvent, setLatestBlindDateEvent] = (0, import_react.useState)(null);
	const wsRef = (0, import_react.useRef)(null);
	const typingTimeoutRef = (0, import_react.useRef)(null);
	const reconnectTimeoutRef = (0, import_react.useRef)(null);
	const connect = (0, import_react.useCallback)(() => {
		if (wsRef.current && (wsRef.current.readyState === WebSocket.OPEN || wsRef.current.readyState === WebSocket.CONNECTING)) return;
		const wsUrl = `${window.location.protocol === "https:" ? "wss:" : "ws:"}//${window.location.host}/ws-chat`;
		try {
			const ws = new WebSocket(wsUrl);
			wsRef.current = ws;
			ws.onopen = () => {
				setIsConnected(true);
				if (profile) ws.send(JSON.stringify({
					type: "register_profile",
					profile: {
						userName: profile.userName,
						userGender: profile.userGender,
						partnerGender: profile.partnerGender,
						userAge: profile.userAge,
						country: profile.country,
						ethnicity: profile.ethnicity,
						educationLevel: profile.educationLevel,
						lifestyleOutlook: profile.lifestyleOutlook,
						userBirthDate: profile.userBirthDate
					}
				}));
			};
			ws.onmessage = (event) => {
				try {
					const data = JSON.parse(event.data);
					if (data.type === "connected") {
						setMyUserId(data.userId);
						if (data.onlineCount) setOnlineCount(data.onlineCount);
					} else if (data.type === "stats_update") {
						if (data.onlineCount !== void 0) setOnlineCount(data.onlineCount);
						if (data.searchingCount !== void 0) setSearchingCount(data.searchingCount);
					} else if (data.type === "searching") {
						setStatus("searching");
						setPartnerLeftMessage(null);
					} else if (data.type === "matched") {
						setStatus("in_chat");
						setRoomId(data.roomId);
						setPartner(data.partner);
						setIsRealPerson(!!data.isRealPerson);
						setCompatibilityScore(data.compatibilityScore || 96);
						setCompatibilityReason(data.compatibilityReason || "تطابق في المواصفات والاهتمامات المشتركة");
						setMessages([]);
						setPartnerLeftMessage(null);
						setRoomErrorMessage(null);
						soundManager.playResultReveal();
					} else if (data.type === "private_room_created") {
						setPrivateRoomCode(data.code);
						setStatus("searching");
						setRoomErrorMessage(null);
						soundManager.playTap();
					} else if (data.type === "room_error") {
						setRoomErrorMessage(data.message);
						setStatus("idle");
					} else if (data.type === "chat_message") {
						setMessages((prev) => [...prev, data.message]);
						soundManager.playTap();
					} else if (data.type === "partner_typing") setPartnerIsTyping(!!data.isTyping);
					else if (data.type === "blind_date_event") setLatestBlindDateEvent({
						event: data.event,
						data: data.data,
						senderId: data.senderId,
						timestamp: Date.now()
					});
					else if (data.type === "partner_left") {
						setPartnerLeftMessage(data.message || "غادر الطرف الآخر المحادثة");
						setPartnerIsTyping(false);
						setIsRealPerson(false);
						setStatus("idle");
						setRoomId(null);
					}
				} catch (e) {
					console.warn("WS message parsing error:", e);
				}
			};
			ws.onclose = () => {
				setIsConnected(false);
				wsRef.current = null;
				if (!reconnectTimeoutRef.current) reconnectTimeoutRef.current = setTimeout(() => {
					reconnectTimeoutRef.current = null;
					connect();
				}, 3e3);
			};
			ws.onerror = () => {
				setIsConnected(false);
			};
		} catch (e) {
			console.warn("WebSocket connection error:", e);
		}
	}, [profile]);
	(0, import_react.useEffect)(() => {
		connect();
		return () => {
			if (reconnectTimeoutRef.current) clearTimeout(reconnectTimeoutRef.current);
			if (wsRef.current) wsRef.current.close();
		};
	}, [connect]);
	(0, import_react.useEffect)(() => {
		if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN && profile) wsRef.current.send(JSON.stringify({
			type: "register_profile",
			profile: {
				userName: profile.userName,
				userGender: profile.userGender,
				partnerGender: profile.partnerGender,
				userAge: profile.userAge,
				country: profile.country,
				ethnicity: profile.ethnicity,
				educationLevel: profile.educationLevel,
				lifestyleOutlook: profile.lifestyleOutlook,
				userBirthDate: profile.userBirthDate
			}
		}));
	}, [profile]);
	const startSearch = (0, import_react.useCallback)(() => {
		if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) connect();
		soundManager.playTap();
		setStatus("searching");
		setPartnerLeftMessage(null);
		setPartner(null);
		setMessages([]);
		if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) wsRef.current.send(JSON.stringify({
			type: "start_search",
			profile: profile ? {
				userName: profile.userName,
				userGender: profile.userGender,
				partnerGender: profile.partnerGender,
				userAge: profile.userAge,
				country: profile.country,
				ethnicity: profile.ethnicity,
				educationLevel: profile.educationLevel,
				lifestyleOutlook: profile.lifestyleOutlook,
				userBirthDate: profile.userBirthDate
			} : void 0
		}));
	}, [connect, profile]);
	const cancelSearch = (0, import_react.useCallback)(() => {
		soundManager.playTap();
		setStatus("idle");
		if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) wsRef.current.send(JSON.stringify({ type: "cancel_search" }));
	}, []);
	const sendMessage = (0, import_react.useCallback)((text) => {
		const clean = text.trim();
		if (!clean || !roomId) return;
		if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) wsRef.current.send(JSON.stringify({
			type: "send_message",
			roomId,
			text: clean
		}));
	}, [roomId]);
	const sendTyping = (0, import_react.useCallback)((isTyping) => {
		if (!roomId) return;
		if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) wsRef.current.send(JSON.stringify({
			type: "typing",
			roomId,
			isTyping
		}));
		if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
		if (isTyping) typingTimeoutRef.current = setTimeout(() => {
			sendTyping(false);
		}, 2e3);
	}, [roomId]);
	return {
		isConnected,
		myUserId,
		status,
		partner,
		roomId,
		compatibilityScore,
		compatibilityReason,
		messages,
		partnerIsTyping,
		partnerLeftMessage,
		onlineCount,
		searchingCount,
		isRealPerson,
		privateRoomCode,
		roomErrorMessage,
		latestBlindDateEvent,
		startSearch,
		cancelSearch,
		sendMessage,
		sendTyping,
		leaveChat: (0, import_react.useCallback)(() => {
			soundManager.playTap();
			if (roomId && wsRef.current && wsRef.current.readyState === WebSocket.OPEN) wsRef.current.send(JSON.stringify({
				type: "leave_chat",
				roomId
			}));
			setStatus("idle");
			setPartner(null);
			setRoomId(null);
			setMessages([]);
			setPartnerIsTyping(false);
		}, [roomId]),
		sendBlindDateEvent: (0, import_react.useCallback)((event, data) => {
			if (roomId && wsRef.current && wsRef.current.readyState === WebSocket.OPEN) wsRef.current.send(JSON.stringify({
				type: "blind_date_event",
				roomId,
				event,
				data
			}));
		}, [roomId]),
		createPrivateRoom: (0, import_react.useCallback)((customCode) => {
			if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) connect();
			soundManager.playTap();
			setRoomErrorMessage(null);
			setStatus("searching");
			if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) wsRef.current.send(JSON.stringify({
				type: "create_private_room",
				code: customCode
			}));
		}, [connect]),
		joinPrivateRoom: (0, import_react.useCallback)((code) => {
			if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) connect();
			soundManager.playTap();
			setRoomErrorMessage(null);
			if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) wsRef.current.send(JSON.stringify({
				type: "join_private_room",
				code
			}));
		}, [connect])
	};
}
//#endregion
//#region src/components/VoiceToneAnalysisModal.tsx
var import_jsx_runtime = require_jsx_runtime();
var VoiceToneAnalysisModal = ({ isOpen, onClose, partnerName, partnerGender, userGender, onSendVoiceMessageToChat }) => {
	const [recordingState, setRecordingState] = (0, import_react.useState)("idle");
	const [recordSeconds, setRecordSeconds] = (0, import_react.useState)(0);
	const [audioUrl, setAudioUrl] = (0, import_react.useState)(null);
	const [audioBase64, setAudioBase64] = (0, import_react.useState)(null);
	const [isPlaying, setIsPlaying] = (0, import_react.useState)(false);
	const [isAnalyzing, setIsAnalyzing] = (0, import_react.useState)(false);
	const [analysisResult, setAnalysisResult] = (0, import_react.useState)(null);
	const [errorMsg, setErrorMsg] = (0, import_react.useState)(null);
	const mediaRecorderRef = (0, import_react.useRef)(null);
	const audioChunksRef = (0, import_react.useRef)([]);
	const timerRef = (0, import_react.useRef)(null);
	const audioElementRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		return () => {
			if (timerRef.current) clearInterval(timerRef.current);
			if (audioUrl) URL.revokeObjectURL(audioUrl);
			if (mediaRecorderRef.current && mediaRecorderRef.current.state === "recording") mediaRecorderRef.current.stop();
		};
	}, []);
	const startRecording = async () => {
		soundManager.playTap();
		setErrorMsg(null);
		audioChunksRef.current = [];
		setRecordSeconds(0);
		setAnalysisResult(null);
		try {
			if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) throw new Error("المتصفح لا يدعم الوصول للميكروفون");
			const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
			const mediaRecorder = new MediaRecorder(stream);
			mediaRecorderRef.current = mediaRecorder;
			mediaRecorder.ondataavailable = (event) => {
				if (event.data.size > 0) audioChunksRef.current.push(event.data);
			};
			mediaRecorder.onstop = async () => {
				const audioBlob = new Blob(audioChunksRef.current, { type: "audio/webm" });
				const url = URL.createObjectURL(audioBlob);
				setAudioUrl(url);
				const reader = new FileReader();
				reader.readAsDataURL(audioBlob);
				reader.onloadend = () => {
					setAudioBase64(reader.result);
				};
				stream.getTracks().forEach((track) => track.stop());
			};
			mediaRecorder.start();
			setRecordingState("recording");
			timerRef.current = setInterval(() => {
				setRecordSeconds((prev) => {
					if (prev >= 29) {
						stopRecording();
						return 30;
					}
					return prev + 1;
				});
			}, 1e3);
		} catch (err) {
			console.warn("Microphone permission or access error:", err);
			simulateRecording();
		}
	};
	const simulateRecording = () => {
		setRecordingState("recording");
		setRecordSeconds(0);
		timerRef.current = setInterval(() => {
			setRecordSeconds((prev) => {
				if (prev >= 6) {
					if (timerRef.current) clearInterval(timerRef.current);
					setRecordingState("recorded");
					return 6;
				}
				return prev + 1;
			});
		}, 1e3);
	};
	const stopRecording = () => {
		soundManager.playTap();
		if (timerRef.current) clearInterval(timerRef.current);
		if (mediaRecorderRef.current && mediaRecorderRef.current.state === "recording") mediaRecorderRef.current.stop();
		setRecordingState("recorded");
	};
	const handleReset = () => {
		soundManager.playTap();
		if (timerRef.current) clearInterval(timerRef.current);
		if (audioElementRef.current) audioElementRef.current.pause();
		setIsPlaying(false);
		setRecordingState("idle");
		setRecordSeconds(0);
		setAudioUrl(null);
		setAudioBase64(null);
		setAnalysisResult(null);
		setErrorMsg(null);
	};
	const togglePlayAudio = () => {
		if (!audioUrl) return;
		if (!audioElementRef.current) {
			const audio = new Audio(audioUrl);
			audioElementRef.current = audio;
			audio.onended = () => setIsPlaying(false);
		}
		if (isPlaying) {
			audioElementRef.current.pause();
			setIsPlaying(false);
		} else {
			audioElementRef.current.play();
			setIsPlaying(true);
		}
	};
	const handleAnalyzeVoice = async () => {
		soundManager.playTap();
		setIsAnalyzing(true);
		setErrorMsg(null);
		try {
			const json = await (await fetch("/api/analyze-voice-tone", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					audioBase64: audioBase64 || void 0,
					mimeType: "audio/webm",
					durationSeconds: recordSeconds || 6,
					speakerGender: userGender,
					partnerGender,
					partnerName,
					contextText: "رسالة ودية مفتوحة في ختام The Blind Date Show للتعبير عن الرضى والانسجام"
				})
			})).json();
			if (json && json.success && json.data) {
				soundManager.playRoundPass();
				setAnalysisResult({
					...json.data,
					audioBlobUrl: audioUrl || void 0,
					durationSeconds: recordSeconds || 6
				});
			} else throw new Error(json.error || "فشل التحليل الصوتي");
		} catch (err) {
			console.error("Error analyzing voice tone:", err);
			setErrorMsg("تعذر تحليل الصوت، يرجى المحاولة مجدداً");
		} finally {
			setIsAnalyzing(false);
		}
	};
	const handleSendToChat = () => {
		soundManager.playTap();
		if (onSendVoiceMessageToChat) onSendVoiceMessageToChat({
			audioUrl: audioUrl || void 0,
			duration: recordSeconds || 6,
			analysis: analysisResult || void 0
		});
		onClose();
	};
	if (!isOpen) return null;
	const formatTime = (secs) => {
		const mins = Math.floor(secs / 60);
		const remaining = secs % 60;
		return `${mins}:${remaining < 10 ? "0" : ""}${remaining}`;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: {
				opacity: 0,
				scale: .95,
				y: 15
			},
			animate: {
				opacity: 1,
				scale: 1,
				y: 0
			},
			exit: {
				opacity: 0,
				scale: .95,
				y: 15
			},
			className: "relative w-full max-w-xl my-6 bg-gradient-to-b from-[#1c1236] via-[#120d24] to-[#0c0916] border border-rose-500/30 rounded-3xl p-5 sm:p-7 shadow-2xl text-white overflow-hidden",
			dir: "rtl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-0 right-1/4 w-72 h-72 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute bottom-0 left-1/4 w-72 h-72 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => {
						soundManager.playTap();
						onClose();
					},
					className: "absolute top-4 left-4 p-2 rounded-full bg-white/10 hover:bg-white/20 text-gray-300 hover:text-white transition z-10 cursor-pointer",
					"aria-label": "إغلاق",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-5 h-5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center mb-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-gradient-to-r from-rose-500/20 to-purple-500/20 border border-rose-500/30 text-rose-300 text-xs font-semibold mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "w-3.5 h-3.5 text-rose-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تحليل نبرة الصوت والتناغم الصوتي المباشر" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl sm:text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-rose-200 via-pink-100 to-purple-200 font-['Alexandria']",
							children: "رسالة صوتية وتناغم النبرات"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-gray-300 text-xs sm:text-sm mt-1 max-w-md mx-auto",
							children: [
								"سجّل رسالة صوتية دافئة لشريكك (",
								partnerName,
								") في الدردشة المفتوحة، لقياس دفء نبرتك ودرجة التوافق الصوتي والتناغم بينكما!"
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-5 rounded-3xl bg-white/[0.03] border border-white/10 text-center mb-5 relative overflow-hidden",
					children: [
						recordingState === "recording" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center justify-center gap-1.5 h-12 mb-4",
							children: [...Array(16)].map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.span, {
								className: "w-1.5 bg-gradient-to-t from-rose-500 to-pink-400 rounded-full",
								animate: { height: [
									8,
									Math.random() * 38 + 10,
									8
								] },
								transition: {
									duration: .4 + i % 4 * .1,
									repeat: Infinity,
									ease: "easeInOut"
								}
							}, i))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-mono text-2xl sm:text-3xl font-extrabold text-white mb-2",
							children: formatTime(recordSeconds)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-gray-400 mb-4",
							children: [
								recordingState === "idle" && "اضغط على زر الميكروفون لبدء التسجيل (حتى 30 ثانية)",
								recordingState === "recording" && "جاري التسجيل... تحدث بعفوية ومودة لشريكك",
								recordingState === "recorded" && "تم اكتمال التسجيل بنجاح! يمكنك الاستماع أو تحليل النبرة"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-center gap-3",
							children: [
								recordingState === "idle" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
									whileHover: { scale: 1.05 },
									whileTap: { scale: .95 },
									onClick: startRecording,
									className: "w-14 h-14 rounded-full bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 text-white flex items-center justify-center shadow-lg shadow-rose-600/30 cursor-pointer text-xl",
									title: "بدء التسجيل",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "w-6 h-6" })
								}),
								recordingState === "recording" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
									whileHover: { scale: 1.05 },
									whileTap: { scale: .95 },
									onClick: stopRecording,
									className: "w-14 h-14 rounded-full bg-rose-600 text-white flex items-center justify-center shadow-lg shadow-rose-600/40 cursor-pointer animate-pulse",
									title: "إيقاف التسجيل",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "w-6 h-6 fill-white" })
								}),
								recordingState === "recorded" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2.5",
									children: [
										audioUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: togglePlayAudio,
											className: "px-4 py-2.5 rounded-2xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition flex items-center gap-2 cursor-pointer",
											children: [isPlaying ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "w-4 h-4 text-rose-400" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "w-4 h-4 text-emerald-400 fill-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isPlaying ? "إيقاف مؤقت" : "تشغيل التسجيل" })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: handleReset,
											"aria-label": "إعادة التسجيل من جديد",
											className: "p-2.5 rounded-2xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition cursor-pointer",
											title: "إعادة التسجيل من جديد",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "w-4 h-4" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: handleAnalyzeVoice,
											disabled: isAnalyzing,
											className: "px-5 py-2.5 rounded-2xl bg-gradient-to-r from-purple-600 via-pink-600 to-rose-600 hover:opacity-95 text-white text-xs font-bold transition flex items-center gap-2 shadow-lg shadow-purple-600/30 cursor-pointer disabled:opacity-50",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-4 h-4 text-amber-300" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAnalyzing ? "جاري تحليل نبرة الصوت..." : "تحليل نبرة الصوت والمشاعر 🔮" })]
										})
									]
								})
							]
						})
					]
				}),
				analysisResult && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 15
					},
					animate: {
						opacity: 1,
						y: 0
					},
					className: "space-y-4 max-h-[380px] overflow-y-auto pr-1 pl-1 scrollbar-thin",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-2xl bg-gradient-to-r from-rose-950/70 via-purple-950/70 to-slate-900 border border-rose-500/40 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] text-gray-400 block mb-0.5",
								children: "النمط الصوتي المكتشف:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-extrabold text-base text-white font-['Alexandria']",
								children: analysisResult.voiceToneArchetype
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center p-2 rounded-2xl bg-rose-500/20 border border-rose-500/30",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] text-gray-300 block",
									children: "توافق النبرات"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-mono text-xl font-extrabold text-rose-300",
									children: [analysisResult.vocalSynergyScore, "%"]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-2 gap-2.5",
							children: analysisResult.emotionalTones.map((tone, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3 rounded-2xl bg-white/[0.03] border border-white/10 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between mb-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold text-gray-200",
										children: tone.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-mono font-bold text-amber-300",
										children: [tone.score, "%"]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-gray-400 leading-relaxed",
									children: tone.description
								})]
							}, idx))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-2xl bg-purple-500/10 border border-purple-500/20 text-xs text-gray-300 leading-relaxed",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-bold text-purple-200 block mb-1 text-sm flex items-center gap-1.5 font-['Alexandria']",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "w-4 h-4 text-purple-400" }),
									"تقرير التناغم الصوتي مع (",
									partnerName,
									"):"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: analysisResult.vocalCompatibilityReport })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-3.5 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-[10px] text-rose-400 font-bold block mb-1",
								children: [
									"انطباع ",
									partnerName,
									" عند سماع نبرة صوتك:"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-gray-200 italic leading-relaxed",
								children: [
									"\"",
									analysisResult.partnerAcousticReaction,
									"\""
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "pt-2 flex items-center justify-end gap-2.5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: handleSendToChat,
								className: "w-full py-3 px-5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:opacity-95 text-white font-extrabold text-xs transition flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/25 cursor-pointer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "w-4 h-4 -rotate-90" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"إرسال الرسالة والتحليل إلى الدردشة المفتوحة مع ",
									partnerName,
									" 💬"
								] })]
							})
						})
					]
				}),
				errorMsg && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2 mt-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "w-4 h-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: errorMsg })]
				})
			]
		})
	}) });
};
//#endregion
export { useLiveChat as n, VoiceToneAnalysisModal as t };
