import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { B as Send, D as Sparkles, Lt as Globe, Nn as ArrowRight, Pn as ArrowLeft, _t as Mail, cn as Clock, dn as CircleQuestionMark, gt as MapPin, hn as CircleAlert, mn as CircleCheck, yn as ChevronDown } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import { l as useLanguage, s as OFFICIAL_LOGO_URL, u as useAuth } from "./index-C5uCeetQ.js";
import { t as motion } from "./vendor-motion-BS7ODJw7.js";
import { r as submitFeedbackMessage } from "./feedbackService-rknvSOxy.js";
import { t as PageSEO } from "./PageSEO-tUCGtj4d.js";
//#region src/pages/ContactUsPage.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var ContactUsPage = ({ onBackToHome, onNavigatePage }) => {
	const { language, isRTL, toggleLanguage } = useLanguage();
	const { user } = useAuth();
	const isAr = language === "ar";
	const [name, setName] = (0, import_react.useState)(user?.displayName || "");
	const [email, setEmail] = (0, import_react.useState)(user?.email || "");
	const [subject, setSubject] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("general");
	const [message, setMessage] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [submitted, setSubmitted] = (0, import_react.useState)(false);
	const [errorMessage, setErrorMessage] = (0, import_react.useState)(null);
	const [openFaq, setOpenFaq] = (0, import_react.useState)(0);
	const categories = isAr ? [
		{
			key: "general",
			label: "استفسار عام",
			icon: "💬"
		},
		{
			key: "test_question",
			label: "استفسار عن الاختبارات والنتائج",
			icon: "🧠"
		},
		{
			key: "feature_request",
			label: "اقتراح ميزة أو تطوير برمجي",
			icon: "💡"
		},
		{
			key: "technical",
			label: "الإبلاغ عن خطأ تقني",
			icon: "🛠️"
		},
		{
			key: "privacy",
			label: "طلب حذف أو تصحيح بيانات (GDPR)",
			icon: "🔒"
		}
	] : [
		{
			key: "general",
			label: "General Inquiry",
			icon: "💬"
		},
		{
			key: "test_question",
			label: "Questions on Tests & Scoring",
			icon: "🧠"
		},
		{
			key: "feature_request",
			label: "Feature Suggestion",
			icon: "💡"
		},
		{
			key: "technical",
			label: "Report a Technical Bug",
			icon: "🛠️"
		},
		{
			key: "privacy",
			label: "Data Deletion / GDPR Request",
			icon: "🔒"
		}
	];
	const contactFaqs = isAr ? [
		{
			q: "ما هو الوقت المتوقع للرد على استفساري؟",
			a: "يقوم فريقنا الهندسي بمراجعة الرسائل الواردة بشكل يومي، ويتم الرد على معظم الاستفسارات خلال 24 إلى 48 ساعة عمل كحد أقصى."
		},
		{
			q: "كيف يمكنني التقدم بطلب محو أو حذف حسابي وبياناتي نهائياً؟",
			a: "يمكنك إرسال طلب المحو مباشرة من هذا النموذج باختيار فئة \"طلب حذف أو تصحيح بيانات (GDPR)\" مع ذكر بريدك الإلكتروني المسجل، وسيتم محو سجلك بالكامل فوراً."
		},
		{
			q: "هل تقدمون استشارات خاصة أو جلسات توفيق شخصية؟",
			a: "كلا. نؤكد أن الموقع يقدم أدوات ومقاييس معرفية ورقمية ذاتية فقط، ولا نقدم استشارات عيادية أو خدمات وساطة زواج خاصة."
		},
		{
			q: "أواجه مشكلة في حفظ أو تصدير ملف الـ PDF، ماذا أفعل؟",
			a: "يرجى التأكد من استخدام متصفح حديث (مثل Google Chrome أو Safari أو Edge) وعدم تفعيل حظر النوافذ أو الملفات المنزلة. إذا استمرت المشكلة، يرجى تزويدنا بتفاصيل جهازك عبر هذا النموذج."
		}
	] : [
		{
			q: "What is the expected response turnaround time?",
			a: "Our engineering and support team reviews messages daily, replying to the vast majority of inquiries within 24 to 48 business hours."
		},
		{
			q: "How can I submit a formal GDPR data erasure request?",
			a: "Select the “Data Deletion / GDPR Request” category in the form below with your registered email, and our team will permanently purge your records immediately."
		},
		{
			q: "Do you offer private consultations or personalized matchmaking?",
			a: "No. The platform strictly provides self-guided digital psychometric diagnostics and does not offer clinical consultations or private matchmaking services."
		},
		{
			q: "I am experiencing an issue exporting my PDF report, what should I do?",
			a: "Ensure you are utilizing a modern web browser (Google Chrome, Safari, Edge) without popup download blockers. If issues persist, detail your device and browser in the form."
		}
	];
	const handleSubmit = async (e) => {
		e.preventDefault();
		if (!name.trim() || !email.trim() || !message.trim()) {
			setErrorMessage(isAr ? "يرجى ملء كافة الحقول المطلوبة" : "Please fill in all required fields");
			return;
		}
		setLoading(true);
		setErrorMessage(null);
		soundManager.playTap();
		const selectedCategoryObj = categories.find((c) => c.key === category);
		try {
			await submitFeedbackMessage({
				name: name.trim(),
				email: email.trim(),
				subject: subject.trim() || (selectedCategoryObj?.label ?? "رسالة تواصل"),
				message: message.trim(),
				category,
				categoryLabelAr: selectedCategoryObj?.label || "استفسار",
				rating: 5,
				user
			});
			setSubmitted(true);
			soundManager.playRoundPass();
		} catch (err) {
			console.warn("Direct submit fallback to mailto:", err);
			const mailto = `mailto:one497303@gmail.com?subject=${encodeURIComponent(`[مرآة القلوب - ${selectedCategoryObj?.label}] ${subject || name}`)}&body=${encodeURIComponent(`الاسم: ${name}\nالبريد: ${email}\nالفئة: ${selectedCategoryObj?.label}\n\nالرسالة:\n${message}`)}`;
			window.location.href = mailto;
			setSubmitted(true);
		} finally {
			setLoading(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full min-h-screen text-slate-100 py-6 sm:py-10 px-3 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageSEO, {
			title: isAr ? "اتصل بنا | مرآة القلوب - تواصل مع فريق التطوير والدعم الفني" : "Contact Us | Mirror of Hearts - Get in Touch with Engineering",
			description: isAr ? "تواصل مع إدارة منصة مرآة القلوب عبر البريد الإلكتروني الرسمي one497303@gmail.com أو نموذج الاتصال المباشر. مقرنا: عمّان - الأردن." : "Contact the Mirror of Hearts development team via official email one497303@gmail.com or our direct contact form. Located in Amman, Jordan.",
			canonicalPath: "/#/contact",
			language,
			pageType: "contact",
			structuredData: {
				"@context": "https://schema.org",
				"@type": "ContactPage",
				name: isAr ? "اتصل بنا | مرآة القلوب" : "Contact Us | Mirror of Hearts",
				description: isAr ? "تواصل مع فريق تطوير وإدارة منصة مرآة القلوب في عمّان - الأردن للاستفسارات والاقتراحات والدعم الفني." : "Get in touch with the Mirror of Hearts engineering team in Amman, Jordan for inquiries, suggestions, and technical support.",
				url: "https://miratalqulub.com/#/contact",
				mainEntity: {
					"@type": "Organization",
					name: "مرآة القلوب - Mirror of Hearts",
					email: "one497303@gmail.com",
					address: {
						"@type": "PostalAddress",
						addressLocality: "Amman",
						addressCountry: "JO"
					}
				}
			}
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-5xl mx-auto space-y-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-white/10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-xs text-slate-400",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: onBackToHome,
								className: "hover:text-rose-400 transition cursor-pointer flex items-center gap-1 font-semibold",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "الرئيسية" : "Home" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "/" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-white font-bold",
								children: isAr ? "اتصل بنا" : "Contact Us"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: toggleLanguage,
							className: "px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-bold text-sky-300 transition flex items-center gap-1.5 cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "English" : "العربية" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: onBackToHome,
							className: "px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-xs font-bold text-rose-300 transition flex items-center gap-1 cursor-pointer",
							children: [isRTL ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "العودة للرئيسية" : "Back to Home" })]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-sky-950/40 via-slate-900/80 to-blue-950/40 border border-sky-500/30 shadow-2xl backdrop-blur-xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 mb-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: OFFICIAL_LOGO_URL,
							alt: "شعار مرآة القلوب الرسمي",
							className: "w-12 h-12 rounded-2xl object-cover border border-sky-500/40 shadow-lg shrink-0"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-sky-500/20 text-sky-300 text-[11px] font-bold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-3 h-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "قنوات الاتصال المباشرة والدعم الفني" : "Direct Support & Inquiries" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-2xl sm:text-3xl font-black text-white font-['Alexandria'] mt-1",
							children: isAr ? "اتصل بنا — مرآة القلوب" : "Contact Us — Mirror of Hearts"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs sm:text-sm text-slate-300 leading-relaxed max-w-2xl",
						children: isAr ? "يسعدنا دائماً الاستماع إلى آرائكم، مقترحاتكم، استفساراتكم السيكومترية أو طلبات الدعم التقني والامتثال لخصوصية البيانات." : "We welcome your feedback, psychometric inquiries, technical reports, and data privacy requests."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 sm:grid-cols-3 gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-5 rounded-3xl bg-slate-900/60 border border-slate-800 space-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-9 h-9 rounded-xl bg-blue-500/20 border border-blue-500/30 flex items-center justify-center text-blue-400",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "w-4 h-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-bold text-sm text-white",
									children: isAr ? "البريد الإلكتروني الرسمي" : "Official Email"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-slate-400",
									children: isAr ? "للتواصل المباشر والرد السريع:" : "Direct inquiries and response:"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "mailto:one497303@gmail.com",
									className: "text-xs font-mono font-bold text-sky-400 hover:text-sky-300 underline block",
									children: "one497303@gmail.com"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-5 rounded-3xl bg-slate-900/60 border border-slate-800 space-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "w-4 h-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-bold text-sm text-white",
									children: isAr ? "المقر والدولة" : "Location & Headquarters"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-slate-400",
									children: isAr ? "فريق التطوير المستقل:" : "Independent Engineering Team:"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-semibold text-emerald-300 block",
									children: isAr ? "عمّان، المملكة الأردنية الهاشمية" : "Amman, Hashemite Kingdom of Jordan"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-5 rounded-3xl bg-slate-900/60 border border-slate-800 space-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "w-4 h-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-bold text-sm text-white",
									children: isAr ? "زمن الاستجابة" : "Response Turnaround"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-slate-400",
									children: isAr ? "متابعة دورية على مدار الأسبوع:" : "Monitored daily:"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-semibold text-amber-300 block",
									children: isAr ? "خلال 24 إلى 48 ساعة كحد أقصى" : "Within 24 to 48 business hours"
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-6 sm:p-8 rounded-3xl bg-slate-900/70 border border-slate-800 shadow-xl space-y-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-10 h-10 rounded-2xl bg-gradient-to-tr from-sky-500 to-blue-600 flex items-center justify-center text-white",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "w-5 h-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl font-bold text-white font-['Alexandria']",
							children: isAr ? "أرسل لنا رسالة مباشرة" : "Send Us a Direct Message"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-slate-400",
							children: isAr ? "سيتم تسليم رسالتك سحابياً إلى الفريق الهندسي والرد على بريدك" : "Your message will be securely transmitted to our engineering team"
						})] })]
					}), submitted ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
						initial: {
							opacity: 0,
							scale: .95
						},
						animate: {
							opacity: 1,
							scale: 1
						},
						className: "p-8 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-center space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-14 h-14 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 mx-auto",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-7 h-7" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-lg font-bold text-white font-['Alexandria']",
								children: isAr ? "تم استلام رسالتك بنجاح!" : "Message Received Successfully!"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs sm:text-sm text-slate-300 max-w-md mx-auto leading-relaxed",
								children: isAr ? "شكراً لتواصلك معنا. قام نظامنا بتسجيل رسالتك وتوجيهها إلى فريق العمل، وسنقوم بالرد على بريدك الإلكتروني في أقرب وقت." : "Thank you for reaching out. Your message has been logged and forwarded to our team. We will reply to your email promptly."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setSubmitted(false);
									setMessage("");
									setSubject("");
								},
								className: "px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-white transition cursor-pointer mt-2",
								children: isAr ? "إرسال رسالة أخرى" : "Send Another Message"
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleSubmit,
						className: "space-y-4",
						children: [
							errorMessage && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-xs text-rose-300 flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "w-4 h-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: errorMessage })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-bold text-slate-300 mb-2",
								children: isAr ? "نوع وموضوع الاستفسار:" : "Inquiry Category:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2",
								children: categories.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setCategory(cat.key),
									className: `p-2.5 rounded-xl border text-xs font-bold transition flex flex-col items-center justify-center gap-1 cursor-pointer text-center ${category === cat.key ? "bg-sky-600/30 border-sky-400 text-white shadow-sm" : "bg-slate-950/60 border-white/5 text-slate-400 hover:text-white hover:bg-white/5"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-base",
										children: cat.icon
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[11px] leading-tight",
										children: cat.label
									})]
								}, cat.key))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-slate-300 mb-1",
									children: isAr ? "الاسم الكامل أو اللقب *" : "Your Full Name or Pseudonym *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									required: true,
									value: name,
									onChange: (e) => setName(e.target.value),
									placeholder: isAr ? "مثال: سارة أو عمر" : "e.g. Sarah or Alex",
									className: "w-full px-3.5 py-2.5 rounded-xl bg-slate-950/80 border border-slate-700 text-white placeholder-slate-500 text-xs focus:outline-none focus:border-sky-500 transition"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-slate-300 mb-1",
									children: isAr ? "البريد الإلكتروني للرد *" : "Your Email Address *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "email",
									required: true,
									value: email,
									onChange: (e) => setEmail(e.target.value),
									placeholder: "name@example.com",
									className: "w-full px-3.5 py-2.5 rounded-xl bg-slate-950/80 border border-slate-700 text-white placeholder-slate-500 text-xs focus:outline-none focus:border-sky-500 transition font-mono"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-bold text-slate-300 mb-1",
								children: isAr ? "عنوان الرسالة (اختياري)" : "Message Subject (Optional)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								value: subject,
								onChange: (e) => setSubject(e.target.value),
								placeholder: isAr ? "اكتب عنواناً مختصراً لرسالتك" : "Brief subject summary",
								className: "w-full px-3.5 py-2.5 rounded-xl bg-slate-950/80 border border-slate-700 text-white placeholder-slate-500 text-xs focus:outline-none focus:border-sky-500 transition"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-bold text-slate-300 mb-1",
								children: isAr ? "تفاصيل الرسالة أو الاستفسار *" : "Message Details *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								required: true,
								rows: 5,
								value: message,
								onChange: (e) => setMessage(e.target.value),
								placeholder: isAr ? "يرجى كتابة استفسارك أو ملاحظتك بالتفصيل لمساعدتنا في تقديم أفضل رد ممكن..." : "Please describe your inquiry, feedback, or report in detail...",
								className: "w-full px-3.5 py-2.5 rounded-xl bg-slate-950/80 border border-slate-700 text-white placeholder-slate-500 text-xs focus:outline-none focus:border-sky-500 transition leading-relaxed resize-y"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "submit",
								disabled: loading,
								className: "w-full sm:w-auto px-8 py-3 rounded-xl bg-gradient-to-r from-sky-600 via-blue-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white text-xs sm:text-sm font-bold shadow-lg shadow-blue-500/25 transition cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50",
								children: [loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: loading ? isAr ? "جاري الإرسال..." : "Sending..." : isAr ? "إرسال الرسالة الآن" : "Send Message Now" })]
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-6 sm:p-8 rounded-3xl bg-slate-900/70 border border-slate-800 shadow-xl space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-9 h-9 rounded-xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-purple-400",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleQuestionMark, { className: "w-4 h-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-bold text-white font-['Alexandria']",
							children: isAr ? "أسئلة شائعة حول التواصل والدعم" : "Frequently Asked Support Questions"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-2.5",
						children: contactFaqs.map((faq, index) => {
							const isOpen = openFaq === index;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl border border-white/5 bg-slate-950/60 overflow-hidden",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => setOpenFaq(isOpen ? null : index),
									className: "w-full p-3.5 text-right sm:text-start flex items-center justify-between gap-3 text-xs font-bold text-white hover:text-sky-400 transition cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: faq.q }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `w-4 h-4 text-slate-400 shrink-0 transition-transform ${isOpen ? "rotate-180 text-sky-400" : ""}` })]
								}), isOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "p-3.5 pt-0 text-xs text-slate-300 border-t border-white/5 leading-relaxed bg-white/[0.01]",
									children: faq.a
								})]
							}, index);
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-4 p-5 rounded-3xl bg-slate-900/50 border border-white/5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => onNavigatePage("about"),
						className: "text-xs text-purple-400 hover:underline flex items-center gap-1 font-semibold cursor-pointer",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "انتقل إلى: من نحن (About Us)" : "View: About Us" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => onNavigatePage("privacy"),
						className: "text-xs text-emerald-400 hover:underline flex items-center gap-1 font-semibold cursor-pointer",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "سياسة الخصوصية (Privacy Policy)" : "Privacy Policy" })
					})]
				})
			]
		})]
	});
};
//#endregion
export { ContactUsPage };
