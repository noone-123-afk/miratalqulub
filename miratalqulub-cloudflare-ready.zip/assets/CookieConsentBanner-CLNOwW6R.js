import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { P as ShieldCheck, R as Settings2, bn as Check, in as Cookie } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import { l as useLanguage } from "./index-C5uCeetQ.js";
//#region src/components/CookieConsentBanner.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var CookieConsentBanner = ({ onOpenPrivacyPolicy, onOpenTermsOfService }) => {
	const { language, isRTL } = useLanguage();
	const isEn = language === "en";
	const [isRendered, setIsRendered] = (0, import_react.useState)(false);
	const [isAnimatedIn, setIsAnimatedIn] = (0, import_react.useState)(false);
	const [showPreferences, setShowPreferences] = (0, import_react.useState)(false);
	const [allowAnalytics, setAllowAnalytics] = (0, import_react.useState)(true);
	const [allowPersonalizedAds, setAllowPersonalizedAds] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		try {
			if (!localStorage.getItem("cookie_consent_status")) {
				const timer = setTimeout(() => {
					setIsRendered(true);
					requestAnimationFrame(() => {
						requestAnimationFrame(() => setIsAnimatedIn(true));
					});
				}, 1200);
				return () => clearTimeout(timer);
			}
		} catch {}
	}, []);
	const dismissBanner = () => {
		setIsAnimatedIn(false);
		setTimeout(() => setIsRendered(false), 320);
	};
	const handleAcceptAll = () => {
		soundManager.playTap();
		try {
			localStorage.setItem("cookie_consent_status", "accepted_all");
			localStorage.setItem("cookie_consent_analytics", "true");
			localStorage.setItem("cookie_consent_ads", "true");
			localStorage.setItem("cookie_consent_timestamp", (/* @__PURE__ */ new Date()).toISOString());
		} catch {}
		dismissBanner();
	};
	const handleAcceptNecessaryOnly = () => {
		soundManager.playTap();
		try {
			localStorage.setItem("cookie_consent_status", "necessary_only");
			localStorage.setItem("cookie_consent_analytics", "false");
			localStorage.setItem("cookie_consent_ads", "false");
			localStorage.setItem("cookie_consent_timestamp", (/* @__PURE__ */ new Date()).toISOString());
		} catch {}
		dismissBanner();
	};
	const handleSaveCustom = () => {
		soundManager.playTap();
		try {
			localStorage.setItem("cookie_consent_status", "custom");
			localStorage.setItem("cookie_consent_analytics", allowAnalytics ? "true" : "false");
			localStorage.setItem("cookie_consent_ads", allowPersonalizedAds ? "true" : "false");
			localStorage.setItem("cookie_consent_timestamp", (/* @__PURE__ */ new Date()).toISOString());
		} catch {}
		dismissBanner();
	};
	if (!isRendered) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed bottom-0 inset-x-0 z-50 p-3 sm:p-5 pointer-events-none no-print",
		dir: isRTL ? "rtl" : "ltr",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: `max-w-4xl mx-auto rounded-3xl bg-[#0f172a] border border-slate-700/90 shadow-2xl p-4 sm:p-6 text-white pointer-events-auto shadow-black/80 transition-all duration-300 ease-out transform ${isAnimatedIn ? "opacity-100 translate-y-0 scale-100" : "opacity-0 translate-y-10 scale-[0.98]"}`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col md:flex-row items-start md:items-center justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-blue-950/80 border border-blue-500/40 flex items-center justify-center text-blue-400 shrink-0 mt-0.5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cookie, { className: "w-5 h-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "text-sm sm:text-base font-extrabold text-white font-['Alexandria']",
									children: isEn ? "Cookie Consent & Digital Privacy" : "ملفات تعريف الارتباط والخصوصية الرقمية"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 text-[10px] font-bold border border-emerald-500/30 flex items-center gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "w-3 h-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isEn ? "GDPR & TLS 1.3 Privacy Standard" : "حماية الخصوصية وتشفير TLS 1.3" })]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-slate-200 leading-relaxed max-w-2xl",
								children: [isEn ? "We use essential cookies and performance technologies to enhance your browsing experience, save your reading preferences, and safeguard platform security." : "نحن نستخدم ملفات تعريف الارتباط الضرورية وتقنيات القياس المعتمدة لتحسين تجربة التصفح، وحفظ تفضيلات القراءة والمظهر، وضمان أمان المنصة.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-emerald-300 font-semibold block mt-1",
									children: isEn ? "🔒 All psychological assessments and test data are encrypted (TLS 1.3/AES-256), never sold or shared with advertisers, and comply strictly with Google privacy standards." : "🔒 جميع بياناتك النفسية وإجابات الاختبارات تُعالج بتشفير TLS 1.3 تام ولا تُباع ولا تُشارك مع أي طرف إعلاني، وتخضع لشروط وسياسة قوقل."
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 text-xs pt-0.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										soundManager.playTap();
										onOpenPrivacyPolicy();
									},
									className: "text-sky-300 hover:text-sky-200 underline font-semibold cursor-pointer",
									children: isEn ? "Full Privacy Policy" : "سياسة الخصوصية الكاملة"
								}), onOpenTermsOfService && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-slate-300",
									children: "•"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										soundManager.playTap();
										onOpenTermsOfService();
									},
									className: "text-slate-200 hover:text-white underline cursor-pointer",
									children: isEn ? "Terms of Service" : "شروط الاستخدام"
								})] })]
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2 shrink-0 w-full md:w-auto justify-end",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								soundManager.playTap();
								setShowPreferences(!showPreferences);
							},
							className: "py-2.5 px-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs font-bold border border-slate-600 transition flex items-center gap-1.5 cursor-pointer",
							title: isEn ? "Customize Preferences" : "تخصيص الخيارات",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings2, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isEn ? "Customize" : "تخصيص" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: handleAcceptNecessaryOnly,
							className: "py-2.5 px-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 hover:text-white text-xs font-bold border border-slate-600 transition cursor-pointer",
							children: isEn ? "Necessary Only" : "الضرورية فقط"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: handleAcceptAll,
							className: "py-2.5 px-4 rounded-xl bg-blue-700 hover:bg-blue-600 text-white text-xs font-extrabold shadow-md shadow-blue-900/30 transition flex items-center gap-1.5 cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isEn ? "Accept All" : "موافق وقبول الكل" })]
						})
					]
				})]
			}), showPreferences && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 pt-4 border-t border-slate-800 space-y-3 transition-all duration-200 ease-out",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-start justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold text-white block",
									children: isEn ? "Strictly Necessary" : "ملفات ضرورية للتشغيل"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-slate-300 leading-snug",
									children: isEn ? "Session security, PIN lock authentication, and core UI functionality." : "وظائف الأمان، التحقق من الجلسة، وحفظ إعدادات الخصوصية."
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-200 font-bold shrink-0 mx-2",
								children: isEn ? "Always Active" : "دائمة التفعيل"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-start justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold text-white block",
									children: isEn ? "Performance & Speed" : "تحسين الأداء والسرعة"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-slate-300 leading-snug",
									children: isEn ? "Measures response latency and diagnostics to optimize the platform." : "قياس أوقات الاستجابة وتشخيص الأخطاء لتحسين المنصة."
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: allowAnalytics,
								onChange: (e) => setAllowAnalytics(e.target.checked),
								"aria-label": isEn ? "Performance & Speed Cookies" : "ملفات تحسين الأداء والسرعة",
								className: "w-4 h-4 rounded text-blue-600 focus:ring-0 cursor-pointer mx-2 mt-0.5"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-start justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold text-white block",
									children: isEn ? "Personalization Preferences" : "تفضيلات القراءة والتخصيص"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-slate-300 leading-snug",
									children: isEn ? "Saves your preferred reading font size, theme mode, and customized interface settings." : "حفظ إعدادات القراءة وحجم الخط والوضع الليلي أو النهاري المفضل لديك."
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: allowPersonalizedAds,
								onChange: (e) => setAllowPersonalizedAds(e.target.checked),
								"aria-label": isEn ? "Personalization Cookies" : "ملفات التخصيص وتفضيلات القراءة",
								className: "w-4 h-4 rounded text-blue-600 focus:ring-0 cursor-pointer mx-2 mt-0.5"
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex justify-end pt-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: handleSaveCustom,
						className: "py-2 px-4 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isEn ? "Save Preferences" : "حفظ خياراتي المفضلة" })]
					})
				})]
			})]
		})
	});
};
//#endregion
export { CookieConsentBanner };
