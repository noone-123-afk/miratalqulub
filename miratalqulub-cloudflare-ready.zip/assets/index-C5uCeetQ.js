const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/firebaseAuth-D6LKvzXg.js","assets/rolldown-runtime-Bk_YeHJf.js","assets/PWAInstallModal-g5ARyrVW.js","assets/vendor-react-Bm_EF59R.js","assets/vendor-icons-WoMClU7U.js","assets/NavbarOwnerControls-BNHfPuAU.js","assets/NavbarUserMenu-D5A1rAUq.js","assets/sound-C_zXqyNA.js","assets/NavbarMobileDrawer-CowBPEJQ.js","assets/userHistoryService-6N9Zh8ed.js","assets/firebase-Cu7XUsbK.js","assets/HowTestResultsCalculatedPage-BoBDe-m_.js","assets/PageSEO-tUCGtj4d.js","assets/Footer-B1WEgXZT.js","assets/CookieConsentBanner-CLNOwW6R.js","assets/ProfileStep-DoTii6S9.js","assets/PsychometricAcademicFraming-DuCcNyEP.js","assets/socioculturalScience-BtpE3Kxg.js","assets/locationNationalityDetector-u5K3h3nb.js","assets/QuizStep-DzrUjl-A.js","assets/AnalyzingStep-C1krQmWk.js","assets/ResultStep-C_voiL5H.js","assets/chatCadenceTracker-DzV50N4M.js","assets/realScoringEngine-B-6Eyb1e.js","assets/react-redux-CuCZtN7g.js","assets/PrivacyLockScreen-DjPgXCir.js","assets/AboutUsPage-DsKuH4sJ.js","assets/PrivacyPolicyPage-BieME062.js","assets/TermsOfServicePage-Cx7oGMfw.js","assets/ContactUsPage-CY9ZKCVh.js","assets/feedbackService-rknvSOxy.js","assets/HowItWorksPage-RIquWAxK.js","assets/FAQPage-B1lW0plU.js","assets/SourcesMethodologyPage-DDr7UJxM.js","assets/DisclaimerPage-D53m9tE5.js","assets/NovelsDirectoryPage-QK3MnBFG.js","assets/novelsService-DylA4WsJ.js","assets/NovelDetailPage-P_KICVFp.js","assets/ReaderToolbar-CBKPy1tK.js","assets/NovelCommentsSection-BjwcZvs9.js","assets/ChapterReaderPage-BcubwB3s.js","assets/AdminCMSPage-BJn3kOdV.js","assets/ownerDownload-pspstBV-.js","assets/AddNovelModal-CjeEf0ke.js","assets/PersonalityTestsPage-CQFSIF3_.js","assets/PsychologyTestsModal-Ch9cgc-y.js","assets/psychologySuiteData-C3h0jv6_.js","assets/ArticlesEncyclopediaPage-BIVCrNL8.js","assets/FullScreenResearchStudyModal-CzFzUkbF.js","assets/LiveChatModal-ClazBySE.js","assets/VoiceToneAnalysisModal-CAU2y-QM.js","assets/BlindDateShowModal-CVtxxKDk.js","assets/DomainHostingModal-DeKFrlyL.js","assets/WebsiteSectionsModal-5QTc4bht.js","assets/AuthModal-PLDF1Wxj.js","assets/SavedResultsHistoryModal-C_QMoqWR.js","assets/SkeletonLoader-Dpq6Gy3u.js","assets/UserProfileDashboard-DcTBsy1i.js","assets/CoupleInviteModal-Dhh28oj6.js","assets/ArticlesSectionModal-Bp22iDqZ.js","assets/NovelsSectionModal-xoD9fH9K.js","assets/IntelligenceTestModal-CZZJt6S0.js","assets/OnboardingWizardModal-BX7AZI6s.js","assets/LegalModal-DHwj3oUy.js","assets/ContactFeedbackModal-BRox7c5T.js","assets/AnalyticsDashboardModal-DXzyIE9R.js","assets/analyticsService-BLTJzcv7.js","assets/BookClubCommunityModal-p6TiFTzK.js"])))=>i.map(i=>d[i]);
import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { i as require_client, n as __vitePreload, o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { An as BookOpen, Cn as Calculator, D as Sparkles, En as Brain, Jt as Eye, K as RotateCcw, Mn as Award, Nn as ArrowRight, Ot as Languages, P as ShieldCheck, Pt as Heart, S as Sun, Wt as FileText, Xt as ExternalLink, a as VolumeX, an as Compass, bt as Lock, d as UserCheck, dn as CircleQuestionMark, ft as MessageCircle, h as Trash2, i as WandSparkles, jn as BookMarked, l as User, mn as CircleCheck, mt as Menu, nn as Cpu, o as Volume2, qt as Feather, r as X, st as Moon, wt as Lightbulb, yn as ChevronDown } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
//#region \0vite/modulepreload-polyfill.js
(function polyfill() {
	const relList = document.createElement("link").relList;
	if (relList && relList.supports && relList.supports("modulepreload")) return;
	for (const link of document.querySelectorAll("link[rel=\"modulepreload\"]")) processPreload(link);
	new MutationObserver((mutations) => {
		for (const mutation of mutations) {
			if (mutation.type !== "childList") continue;
			for (const node of mutation.addedNodes) if (node.tagName === "LINK" && node.rel === "modulepreload") processPreload(node);
		}
	}).observe(document, {
		childList: true,
		subtree: true
	});
	function getFetchOpts(link) {
		const fetchOpts = {};
		if (link.integrity) fetchOpts.integrity = link.integrity;
		if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
		if (link.crossOrigin === "use-credentials") fetchOpts.credentials = "include";
		else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
		else fetchOpts.credentials = "same-origin";
		return fetchOpts;
	}
	function processPreload(link) {
		if (link.ep) return;
		link.ep = true;
		const fetchOpts = getFetchOpts(link);
		fetch(link.href, fetchOpts);
	}
})();
//#endregion
//#region src/utils/theme.ts
var import_client = require_client();
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var THEME_STORAGE_KEY = "mirat_al_quloob_theme";
function getInitialTheme() {
	if (typeof window === "undefined") return "dark";
	try {
		const saved = localStorage.getItem(THEME_STORAGE_KEY);
		if (saved === "light" || saved === "dark") return saved;
	} catch (e) {
		console.error("Failed to read theme from localStorage", e);
	}
	return "dark";
}
function applyTheme(theme) {
	if (typeof document === "undefined") return;
	const root = document.documentElement;
	if (theme === "light") {
		root.classList.add("light");
		root.classList.remove("dark");
	} else {
		root.classList.add("dark");
		root.classList.remove("light");
	}
	try {
		localStorage.setItem(THEME_STORAGE_KEY, theme);
		window.dispatchEvent(new CustomEvent("app-theme-changed", { detail: { theme } }));
	} catch (e) {
		console.error("Failed to persist theme in localStorage", e);
	}
}
function useAppTheme() {
	const [theme, setThemeState] = (0, import_react.useState)(getInitialTheme);
	(0, import_react.useEffect)(() => {
		applyTheme(theme);
		const handleThemeChange = (e) => {
			const customEvent = e;
			if (customEvent.detail?.theme) setThemeState(customEvent.detail.theme);
		};
		window.addEventListener("app-theme-changed", handleThemeChange);
		return () => {
			window.removeEventListener("app-theme-changed", handleThemeChange);
		};
	}, []);
	const toggleTheme = (newTheme) => {
		const target = newTheme || (theme === "dark" ? "light" : "dark");
		setThemeState(target);
		applyTheme(target);
	};
	const result = [theme, toggleTheme];
	result.theme = theme;
	result.appTheme = theme;
	result.toggleTheme = toggleTheme;
	result.toggleAppTheme = toggleTheme;
	return result;
}
//#endregion
//#region src/context/AuthContext.tsx
var import_jsx_runtime = require_jsx_runtime();
var AUTH_SESSION_STORAGE_KEY = "mirat_has_auth_session";
var AuthContext = (0, import_react.createContext)(void 0);
function isBotOrLighthouse() {
	if (typeof window === "undefined" || typeof navigator === "undefined") return true;
	const ua = navigator.userAgent || "";
	return Boolean(navigator.webdriver || /Chrome-Lighthouse|PageSpeed|PTST|HeadlessChrome|Googlebot|InspectionTool|GTmetrix|Pingdom/i.test(ua));
}
/**
* Checks whether the browser has a previously stored Firebase Auth session
* so anonymous first-time visitors never download the 150 KB vendor-firebase-auth chunk
* until they actually click Sign In.
*/
function hasStoredAuthSession() {
	try {
		if (localStorage.getItem(AUTH_SESSION_STORAGE_KEY) === "1") return true;
		for (let i = 0; i < localStorage.length; i++) {
			const key = localStorage.key(i);
			if (key && key.startsWith("firebase:authUser:")) return true;
		}
	} catch {}
	return false;
}
function markAuthSessionActive(active) {
	try {
		if (active) localStorage.setItem(AUTH_SESSION_STORAGE_KEY, "1");
		else localStorage.removeItem(AUTH_SESSION_STORAGE_KEY);
	} catch {}
}
var AuthProvider = ({ children }) => {
	const [user, setUser] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [authError, setAuthError] = (0, import_react.useState)(null);
	const unsubscribeRef = (0, import_react.useRef)(null);
	const attachAuthListener = async () => {
		if (unsubscribeRef.current) return __vitePreload(() => import("./firebaseAuth-D6LKvzXg.js").then((n) => n.r), __vite__mapDeps([0,1]));
		const fb = await __vitePreload(() => import("./firebaseAuth-D6LKvzXg.js").then((n) => n.r), __vite__mapDeps([0,1]));
		if (!unsubscribeRef.current) unsubscribeRef.current = fb.onAuthStateChanged(fb.auth, (currentUser) => {
			setUser(currentUser);
			markAuthSessionActive(Boolean(currentUser));
			setLoading(false);
		});
		return fb;
	};
	(0, import_react.useEffect)(() => {
		if (isBotOrLighthouse() || !hasStoredAuthSession()) {
			setLoading(false);
			return;
		}
		let isCancelled = false;
		const timer = setTimeout(() => {
			if (isCancelled) return;
			attachAuthListener().catch(() => {
				if (!isCancelled) setLoading(false);
			});
		}, 150);
		return () => {
			isCancelled = true;
			clearTimeout(timer);
			if (unsubscribeRef.current) {
				unsubscribeRef.current();
				unsubscribeRef.current = null;
			}
		};
	}, []);
	const translateAuthError = (err) => {
		const code = err?.code || "";
		if (code.includes("user-not-found") || code.includes("wrong-password") || code.includes("invalid-credential")) return "البريد الإلكتروني أو كلمة المرور غير صحيحة";
		if (code.includes("email-already-in-use")) return "هذا البريد الإلكتروني مسجل بالفعل، يرجى تسجيل الدخول بدلاً من ذلك";
		if (code.includes("weak-password")) return "كلمة المرور ضعيفة، يرجى استخدام 6 خانات على الأقل";
		if (code.includes("invalid-email")) return "صيغة البريد الإلكتروني غير صالحة";
		if (code.includes("popup-closed-by-user")) return "تم إغلاق نافذة تسجيل الدخول قبل إتمام المصادقة";
		return err?.message || "حدث خطأ غير متوقع أثناء تسجيل الدخول";
	};
	const signInWithGoogleHandler = async () => {
		setAuthError(null);
		try {
			soundManager.playTap();
			const fb = await attachAuthListener();
			const cred = await fb.signInWithPopup(fb.auth, fb.googleProvider);
			if (cred?.user) {
				setUser(cred.user);
				markAuthSessionActive(true);
			}
			soundManager.playRoundPass();
		} catch (err) {
			console.error("Google Sign-In failed", err);
			setAuthError(translateAuthError(err));
			throw err;
		}
	};
	const signInWithEmailHandler = async (email, pass) => {
		setAuthError(null);
		try {
			soundManager.playTap();
			const fb = await attachAuthListener();
			const cred = await fb.signInWithEmailAndPassword(fb.auth, email.trim(), pass);
			if (cred?.user) {
				setUser(cred.user);
				markAuthSessionActive(true);
			}
			soundManager.playRoundPass();
		} catch (err) {
			console.error("Email Sign-In failed", err);
			setAuthError(translateAuthError(err));
			throw err;
		}
	};
	const signUpWithEmailHandler = async (email, pass, _displayName) => {
		setAuthError(null);
		if (email.trim().toLowerCase() === "one497303@gmail.com".toLowerCase()) {
			const msg = "هذا البريد محجوز لإدارة المنصة، يرجى تسجيل الدخول عبر Google.";
			setAuthError(msg);
			throw new Error(msg);
		}
		try {
			soundManager.playTap();
			const fb = await attachAuthListener();
			const cred = await fb.createUserWithEmailAndPassword(fb.auth, email.trim(), pass);
			if (cred?.user) {
				setUser(cred.user);
				markAuthSessionActive(true);
			}
			soundManager.playRoundPass();
		} catch (err) {
			console.error("Email Sign-Up failed", err);
			setAuthError(translateAuthError(err));
			throw err;
		}
	};
	const signInAsGuestHandler = async () => {
		setAuthError(null);
		try {
			soundManager.playTap();
			const fb = await attachAuthListener();
			const cred = await fb.signInAnonymously(fb.auth);
			if (cred?.user) {
				setUser(cred.user);
				markAuthSessionActive(true);
			}
			soundManager.playRoundPass();
		} catch (err) {
			console.error("Guest Sign-In failed", err);
			setAuthError(translateAuthError(err));
			throw err;
		}
	};
	const logoutHandler = async () => {
		soundManager.playTap();
		markAuthSessionActive(false);
		const fb = await attachAuthListener();
		await fb.signOut(fb.auth);
		setUser(null);
	};
	const isOwner = Boolean(user && user.email && user.email.toLowerCase() === "one497303@gmail.com".toLowerCase() && user.emailVerified === true);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthContext.Provider, {
		value: {
			user,
			loading,
			isOwner,
			signInWithGoogle: signInWithGoogleHandler,
			signInWithEmail: signInWithEmailHandler,
			signUpWithEmail: signUpWithEmailHandler,
			signInAsGuest: signInAsGuestHandler,
			logout: logoutHandler,
			authError,
			clearError: () => setAuthError(null)
		},
		children
	});
};
var useAuth = () => {
	const context = (0, import_react.useContext)(AuthContext);
	if (!context) throw new Error("useAuth must be used within an AuthProvider");
	return context;
};
//#endregion
//#region src/context/LanguageContext.tsx
var LanguageContext = (0, import_react.createContext)(void 0);
var LANG_STORAGE_KEY = "mirat_al_quloob_lang";
var FALLBACK_LANG_METADATA = {
	ar: {
		code: "ar",
		name: "Arabic",
		nativeName: "العربية",
		dir: "rtl",
		isRTL: true,
		locale: "ar-JO",
		flag: "🇸🇦",
		fontFamily: "'Alexandria', 'Tajawal', system-ui, sans-serif"
	},
	en: {
		code: "en",
		name: "English",
		nativeName: "English",
		dir: "ltr",
		isRTL: false,
		locale: "en-US",
		flag: "🇺🇸",
		fontFamily: "'Inter', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif"
	}
};
function computeTailwindClasses(lang) {
	const isRTL = lang === "ar";
	return {
		dirClass: isRTL ? "dir-rtl" : "dir-ltr",
		textAlignClass: isRTL ? "text-right" : "text-left",
		oppositeTextAlignClass: isRTL ? "text-left" : "text-right",
		fontClass: isRTL ? "font-['Alexandria','Tajawal',system-ui,sans-serif]" : "font-sans",
		headingFontClass: isRTL ? "font-['Alexandria']" : "font-sans tracking-tight",
		flexRowClass: "flex-row",
		containerClass: isRTL ? "dir-rtl text-right font-['Alexandria','Tajawal',system-ui,sans-serif]" : "dir-ltr text-left font-sans"
	};
}
var CORE_TRANSLATIONS = {
	brand_name: {
		ar: "مِـرآة القـلوب",
		en: "Mirror of Hearts"
	},
	brand_tagline: {
		ar: "موقع كاشف شريك الحياة والتوافق النفسي",
		en: "Partner & Psychometric Compatibility Hub"
	},
	footer_rights: {
		ar: "© 2026 مِـرآة القـلوب. جميع الحقوق محفوظة.",
		en: "© 2026 Mirror of Hearts. All Rights Reserved."
	},
	cloud_status: {
		ar: "خوادم سحابية تعمل 99.9%",
		en: "Cloud Uptime 99.9%"
	},
	ssl_verified: {
		ar: "🔒 شهادة SSL مدارة من Google",
		en: "🔒 Google-Managed SSL Certificate"
	},
	light_mode: {
		ar: "نمط النور ☀️",
		en: "Light Mode ☀️"
	},
	dark_mode: {
		ar: "نمط الليل 🌙",
		en: "Dark Mode 🌙"
	},
	result_badge_success: {
		ar: "تم إعداد تقرير التوافق الفكري والمجتمعي بنجاح",
		en: "Intellectual & Sociological Compatibility Report Prepared Successfully"
	},
	result_title_main: {
		ar: "ملامح ومواصفات",
		en: "Features & Traits of"
	},
	result_title_partner: {
		ar: "شريك حياتك",
		en: "Your Life Partner"
	},
	result_subtitle_desc: {
		ar: "تحليل علمي ومجتمعي مبني على سمات شخصيتك وتوافقك مع بيئة",
		en: "Scientific & sociological analysis grounded in your personality and synergy in"
	},
	pin_security_enabled: {
		ar: "قفل الأمان: مُفـعّـل (PIN 4 أرقام) 🔒",
		en: "Security Lock: Enabled (4-Digit PIN) 🔒"
	},
	pin_security_disabled: {
		ar: "قفل الأمان: غير مفعل (مكشوف)",
		en: "Security Lock: Disabled"
	},
	lock_now: {
		ar: "قفل الآن 🔒",
		en: "Lock Now 🔒"
	},
	pin_settings: {
		ar: "إعدادات الرمز",
		en: "PIN Settings"
	},
	enable_pin: {
		ar: "🛡️ تفعيل قفل PIN",
		en: "🛡️ Enable PIN"
	},
	save_to_account: {
		ar: "حفظ النتيجة في حسابي 💾",
		en: "Save Result to Account 💾"
	},
	saved_in_account: {
		ar: "تم الحفظ في حسابك ✓",
		en: "Saved to Account ✓"
	},
	saving_progress: {
		ar: "جارٍ الحفظ...",
		en: "Saving..."
	},
	history_btn: {
		ar: "السجل 📂",
		en: "History 📂"
	},
	ultra_hd_badge: {
		ar: "دقة تصوير 4K واقعية",
		en: "Photorealistic 4K Quality"
	},
	proposed_partner_badge: {
		ar: "الاسم المقترح للشريك المتوافق",
		en: "Proposed Compatible Partner Name"
	},
	overall_compatibility_label: {
		ar: "مؤشر التوافق الكلي العام",
		en: "Overall Calculated Compatibility"
	},
	mathematical_audit_btn: {
		ar: "تدقيق حسابي حقيقي 🧮",
		en: "Mathematical Audit 🧮"
	},
	regenerating_now: {
		ar: "جارٍ التوليد...",
		en: "Regenerating..."
	},
	regenerate_image_btn: {
		ar: "توليد ملامح جديدة",
		en: "Regenerate Portrait"
	}
};
var loadedI18nModule = null;
function getInitialLanguage() {
	if (typeof window === "undefined") return "ar";
	try {
		const saved = localStorage.getItem(LANG_STORAGE_KEY);
		if (saved === "ar" || saved === "en") return saved;
	} catch (e) {
		console.error("Failed to read language from localStorage", e);
	}
	return "ar";
}
function applyLanguageSettings(lang) {
	if (typeof document === "undefined") return;
	const meta = FALLBACK_LANG_METADATA[lang] || FALLBACK_LANG_METADATA.ar;
	const tw = computeTailwindClasses(lang);
	const root = document.documentElement;
	root.lang = meta.code;
	root.dir = meta.dir;
	root.classList.remove("lang-ar", "lang-en", "dir-rtl", "dir-ltr", "text-right", "text-left");
	root.classList.add(`lang-${meta.code}`, `dir-${meta.dir}`, tw.textAlignClass);
	if (document.body) {
		document.body.dir = meta.dir;
		document.body.classList.remove("dir-rtl", "dir-ltr", "text-right", "text-left", "font-sans");
		document.body.classList.add(tw.dirClass, tw.textAlignClass);
		if (!meta.isRTL) document.body.classList.add("font-sans");
	}
	try {
		localStorage.setItem(LANG_STORAGE_KEY, lang);
		window.dispatchEvent(new CustomEvent("app-language-changed", { detail: { language: lang } }));
	} catch (e) {
		console.error("Failed to persist language in localStorage", e);
	}
}
var originalNodeTextMap = /* @__PURE__ */ new WeakMap();
var originalElementAttrMap = /* @__PURE__ */ new WeakMap();
var hasEverLocalizedToEnglish = false;
function translateRawArabicToEnglish(input) {
	if (!input || !/[\u0600-\u06FF]/.test(input)) return input;
	if (!loadedI18nModule) return input;
	return loadedI18nModule.translateDynamicField(input, "en");
}
function shouldPreserveElementDirection(el) {
	if (el.hasAttribute("data-keep-dir") || el.hasAttribute("data-dir-lock") || el.classList.contains("ltr-preserve") || el.classList.contains("rtl-preserve") || el.classList.contains("recharts-wrapper") || el.classList.contains("recharts-responsive-container") || el.querySelector(":scope > .recharts-wrapper, :scope > .recharts-responsive-container, :scope > svg.recharts-surface") !== null) return true;
	return false;
}
function applyDomLocalization(lang) {
	if (typeof document === "undefined" || !document.body) return;
	if (lang === "ar" && !hasEverLocalizedToEnglish) return;
	if (lang === "en") hasEverLocalizedToEnglish = true;
	const targetDir = (FALLBACK_LANG_METADATA[lang] || FALLBACK_LANG_METADATA.ar).dir;
	const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, { acceptNode(node) {
		const parent = node.parentElement;
		if (!parent) return NodeFilter.FILTER_REJECT;
		const tag = parent.tagName;
		if (tag === "SCRIPT" || tag === "STYLE" || tag === "NOSCRIPT" || tag === "TEXTAREA") return NodeFilter.FILTER_REJECT;
		if (parent.closest("#mirat-pdf-preview-overlay, [data-no-translate=\"true\"]")) return NodeFilter.FILTER_REJECT;
		return NodeFilter.FILTER_ACCEPT;
	} });
	let currentNode = walker.nextNode();
	while (currentNode) {
		const val = currentNode.nodeValue || "";
		if (lang === "en") {
			if (/[\u0600-\u06FF]/.test(val)) {
				if (!originalNodeTextMap.has(currentNode)) originalNodeTextMap.set(currentNode, val);
				const translated = translateRawArabicToEnglish(originalNodeTextMap.get(currentNode) || val);
				if (translated !== val) currentNode.nodeValue = translated;
			}
		} else {
			const original = originalNodeTextMap.get(currentNode);
			if (original !== void 0 && currentNode.nodeValue !== original) currentNode.nodeValue = original;
		}
		currentNode = walker.nextNode();
	}
	document.body.querySelectorAll("[dir], [placeholder], [title], [aria-label]").forEach((el) => {
		if (el.closest("#mirat-pdf-preview-overlay, [data-no-translate=\"true\"]")) return;
		const savedAttrs = originalElementAttrMap.get(el) || {};
		if (el.hasAttribute("dir") && !shouldPreserveElementDirection(el)) {
			const currentDir = el.getAttribute("dir");
			if (!savedAttrs.dir && currentDir) {
				savedAttrs.dir = currentDir;
				originalElementAttrMap.set(el, savedAttrs);
			}
			if (lang === "ar") {
				const restoreDir = savedAttrs.dir || "rtl";
				if (currentDir !== restoreDir) el.setAttribute("dir", restoreDir);
			} else if (currentDir && currentDir !== targetDir) el.setAttribute("dir", targetDir);
		}
		for (const attr of [
			"placeholder",
			"title",
			"aria-label"
		]) {
			const attrVal = el.getAttribute(attr);
			if (!attrVal) continue;
			if (lang === "en") {
				if (/[\u0600-\u06FF]/.test(attrVal)) {
					if (!savedAttrs[attr]) {
						savedAttrs[attr] = attrVal;
						originalElementAttrMap.set(el, savedAttrs);
					}
					const translatedAttr = translateRawArabicToEnglish(savedAttrs[attr]);
					if (translatedAttr !== attrVal) el.setAttribute(attr, translatedAttr);
				}
			} else if (savedAttrs[attr] && attrVal !== savedAttrs[attr]) el.setAttribute(attr, savedAttrs[attr]);
		}
	});
}
var LanguageProvider = ({ children }) => {
	const [language, setLanguageState] = (0, import_react.useState)(getInitialLanguage);
	const [, setDictLoaded] = (0, import_react.useState)(Boolean(loadedI18nModule));
	(0, import_react.useEffect)(() => {
		applyLanguageSettings(language);
		let rafId = null;
		let observer = null;
		if (language === "en") __vitePreload(() => import("./data-translations-Bv1zQOpZ.js").then((n) => n.t).then((mod) => {
			loadedI18nModule = mod;
			setDictLoaded(true);
			applyDomLocalization("en");
			if (typeof document !== "undefined" && document.body) {
				observer = new MutationObserver(() => {
					if (rafId) cancelAnimationFrame(rafId);
					rafId = requestAnimationFrame(() => {
						applyDomLocalization("en");
					});
				});
				observer.observe(document.body, {
					childList: true,
					subtree: true
				});
			}
		}), __vite__mapDeps([1]));
		else applyDomLocalization("ar");
		const handleLangChange = (e) => {
			const customEvent = e;
			if (customEvent.detail?.language) setLanguageState(customEvent.detail.language);
		};
		window.addEventListener("app-language-changed", handleLangChange);
		return () => {
			window.removeEventListener("app-language-changed", handleLangChange);
			if (observer) observer.disconnect();
			if (rafId) cancelAnimationFrame(rafId);
		};
	}, [language]);
	const setLanguage = (lang) => {
		soundManager.playTap();
		setLanguageState(lang);
		applyLanguageSettings(lang);
	};
	const toggleLanguage = () => {
		soundManager.playTap();
		const nextLang = language === "ar" ? "en" : "ar";
		setLanguageState(nextLang);
		applyLanguageSettings(nextLang);
	};
	const t = (key, fallback) => {
		const entry = (loadedI18nModule?.TRANSLATIONS || CORE_TRANSLATIONS)[key] || CORE_TRANSLATIONS[key];
		if (entry && entry[language]) return entry[language];
		return fallback || entry?.ar || key;
	};
	const translateText = (text) => {
		if (language === "ar" || !loadedI18nModule) return text;
		return loadedI18nModule.translateDynamicField(text, language);
	};
	const languageMetadata = loadedI18nModule?.getLanguageMetadata(language) || FALLBACK_LANG_METADATA[language] || FALLBACK_LANG_METADATA.ar;
	const supportedLanguages = loadedI18nModule?.SUPPORTED_LANGUAGES || Object.values(FALLBACK_LANG_METADATA);
	const isRTL = languageMetadata.isRTL;
	const direction = languageMetadata.dir;
	const tailwindClasses = loadedI18nModule?.getTailwindLayoutClasses(language) || computeTailwindClasses(language);
	const formatNumber = (value) => {
		if (!Number.isFinite(value)) return "0";
		try {
			return new Intl.NumberFormat(languageMetadata.locale).format(value);
		} catch {
			return String(value);
		}
	};
	const formatDate = (isoOrDate, options) => {
		try {
			return (typeof isoOrDate === "string" ? new Date(isoOrDate) : isoOrDate).toLocaleDateString(languageMetadata.locale, options || {
				year: "numeric",
				month: "short",
				day: "numeric"
			});
		} catch {
			return String(isoOrDate);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LanguageContext.Provider, {
		value: {
			language,
			direction,
			isRTL,
			languageMetadata,
			supportedLanguages,
			tailwindClasses,
			setLanguage,
			toggleLanguage,
			t,
			translateText,
			formatNumber,
			formatDate
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			dir: direction,
			className: `min-h-screen w-full transition-colors duration-200 ${tailwindClasses.containerClass}`,
			children
		})
	});
};
function useLanguage() {
	const context = (0, import_react.useContext)(LanguageContext);
	if (!context) throw new Error("useLanguage must be used within a LanguageProvider");
	return context;
}
//#endregion
//#region src/utils/logoAsset.ts
var OFFICIAL_LOGO_URL = "data:image/webp;base64,UklGRpoOAABXRUJQVlA4II4OAAAwNgCdASqaAJoAPmEukUakIqGhKVp5QIAMCUDRQahnqfXHlv9TxdBlbY/o528fmw84/0of371AP8d1InoNdKt/e/+36VVYp+MfP/5nyrM4/TVqHdw+Jfev8OtQL2hvC4APrh3x2pH4Y9gDgBqAf5v9B7OG9Qfsn8BX65+mP69/3A9l79tSz0s9O+zu88SAGqpfa5WWo1Ful7kqCQQ3gqPm/ql/u8CVF7yyXnHStcF7lUIkq1zdniwDeT58VJWvLMiGgOL/NS0tkRX/iWqqr1bY6hSOtVRg2Rj7uEBT858jNlE0WcrVgmwZrtoOoWdXFh07f/7AyIf8LM8GdgU3DhGztnMEaz4jNwOuXZpTMu2BwUettME75WJO7f7k7DI0v9mfvYhOzz06s9C1Lgq/LE69cCFX5o2Kh77nxOScRts6XQ46rQzNGj7mYwZA8GzgcHOa2etMDuSOSFYfM+C/Oyk6KLovidQWlm3V7vmy+5Osae7oODKBCNsVxEGtDkNN8k6bqkNvZRXq3Sh0LSp4GjbejVjYkDToMLFf5nf6Lgo5YdG4rLAAVOP1bahE+nW0Y9reHIgHr+eQ4mgAAP79A9P88cn8xEnJSaQ1/CjhO1H9EeOgWwlK7VtIgdIojjPK/UoXAYlbT6SHpUlyYHrEhMPd1mJHxT7g8+lh5ol3dT9FKAR6ggXrv8L8KvrC2FdnrK/pgLJFdB2rOsux8xbDUBdxq2G0ZV+Xg7A9d8vh+emvxol3p3xrXdhXyDVKSUo6tPjy23QYT+ny3Y/wOOg7q/Jei+HuuezsxAxqbYpx9h8rGt5Qh/gFT9vMJTDO2Q+KuAjfDkFdjRaGnhr7VHUhSru3+HMM6v+IjhUIRhrqM3nWdPZn0jCZft834cto/XxEz8xwojcMnZqeg3ct/163+yU9Dd4OFuTCL3NSwuuc7U31/3T0lxDWYx6xrjls27C911fpi/iU5UIb1nzYH6wpyCAsmX3RebCBRhnh4HH9z8+FVY50JI6iw73EtRA8QhNdxHN8ChruHnmob0f1Auv/AjdI2avTLK943lkYXLDaI+UFgD1hUiMrrsohG3ufdHmKGfeHa2IaWrsAYp9rt419hXJ/r9r1G5MffNsWQJ52puaVvC2b9kxEnnz6Awy77rM8v2fk+ATF98gtTGZWQCKk+h7PUhRd8zF6UBkZqsZ2ZfnVzBr74ijfjaiDygTOY4KkjlTRxuk8Sup0oW0LweiKg6zzrX17z/WlVOX0W4mnH8U/zDv/7BAf9lUwWFxif+5ramJFhemkTP871vP1lU+60wxJT7GEjSt1b9bOczAQiGlW7BqAI/fqjCRDzqKEWYpERg8h2m9m9OHjK8pLfQrZvzkkak4Ck11kg2hA/55aClVq/X/eGR3F8ho+8ywThRiBnC5w8oruASYUORziIBuejjlekwYg3Qp3NQxPhXlNwcb0v3wANh1oLUeDl/3d30RAEBR/mCQjO4PlWAprXL3o1yUmKx98vAdqK1sW9dQChtpSqoBT75GTZJT1dvHZ56vq8arafvk83TVMrZ6SXDc3ra4Hb3mvgVkKLYmAic+D/zvAL24bYr520dIwJNQXGHh/M26rDj9G/vdK8BbcF7zD1Q74htLRU+fi8rurDPyQP+X9lT0PZ57lN0vJocVg1nXV27qmsRaGlY2lWN4/6vnSVorbJugtLEha2c8UE7KSu2wavF2a0GWdLLJW/EjjHtPPCzeJaHEaeamwyt5hfDv89EDgW03UJtzE1AiY4ol6nZNCacILiGt1FFRcVt6tVECdJEYFRaEdGL5qYbhRxLxez/0LKTTorg7RBB01MXVcfmZ9fcY1e02xMKReZwN7pCF29L4ZpLNMsHghYZ2c/qRV+2JsXH2mLHI/HQyw4xacNng/i/H1Dov/JijIG4zHQhhlVP6oPsv8u9MYHyTxghkLRSKrwg/c/cfv7R4lwfB+5CuN0ICFepIj92Xdutmj1tlZFptq480pBlrlDEubXVWg1PpoTf/AhacqldMltV259UNurzxRe9LSvXN8UBoDRhpL+qNjAMU5GoUzUbkqss0OtY+L/3kCnXFLOZ0t7D2DzZ+2YnP/5Ij1Dw+xhmxey3WqOxc/HhS3Nes0H4L1Wnj1JZnYR2TVD30Lm2nTS/Cg+eJxkZedj5ZdIHL3EieS62hdCBg5fydUXEeuZRBPGPfV8SJz4DcSnOIvHaQNVjsnba+LaiqyWAD8r8kJOKMJcTvvIIq7cUVu04MIbECamp07DF+V/lbeKeDL0+FI39vvfSwkCYWuRSOn59XQ0BYKoMKYdsudaT1ZW70oe/b3zkNCt1umtGazDfridMf84fmeWgKNQZSO7lwWG94QLaNRaP11mUpAGvzLu5KbnCvbpNkrMcwF5kMP+tQIy1mVoPnaNUSD2KozW8TKVUMIpilKRyng7bYeeg3o/RTcSi0W9JYNbWzmSfvlpBeuaZOXKHzY2YbK8gUNuIG+IFqfXLgK6H2Ec/98pRkanasjubnAsA6SbFQFSC4giqSPUUe+TuTEXAXiLgDW8a+xf1DP2IgL5iRnywUKg+uIeREk59cbgEcYxVJPPgrPDMSe3uGpfW8Ctl4Erl0Pgkq/NNaCHg8DbD/UcvMU11/xgWgVeIUxI9L6uGOFp40Sv7tqYr+U+aEkjXDtAkX7rSaGl7S6C/4x1lLYJV9hsO3jG7vY9k9MkvtrfzZl7VuoC4ywqcQqLDDvbfxoD5hu+iDHtsJ2VqzmwsRO6Zmb3NRk5ZLEwY1V7VuuGMi1yBIKbSJ/yqo5bnjWx+VTOPvAfjWSHWyaU11EpCEQ/KLRFjxo9OFW2ca3TyONCnhOwAywPSbcFK/p8SDEhoQiPwxddc6QGcWA1rbJmeoTJCM/aqeUpH9kNveKnbS2ZyaFQ+Mxj8wBCqmYLHf12ivkQ9t4qEn3Wz3F7KifL7mQ0jJCZ+GpKY0GwBVlZr36z23UONzEW1yZkTUVyuOIo9e7GMlmd5u93p4yKah/SINaFk/VPF+grRGrDaN4biTIPdTqVZfag932Ir8aiXThvfpV38yI7QHf1/KFlVBqL9r2E13zfBrTu4tzgv9lmcqP3vBPqoKfP775Zs3E7fLizsBc4ndJ/7+dje+z78oir52MwgGgOkhyVvyrX8FpxkAsFI8YEq6dL88KpiWCLbJv0xwdTvHm2Hm7yqmpcdzipAfUL6ED6ayAdsewU1TOw+P5/iGDOp3T8xA+VYVkMB3Gw3ThLBn04HnjfBilAHvpxsPA2kYkcqssXt28bRvwGdcA5AMHl8HbYCYvLiDFl0BxQCeD2egkp28YY+8dI/xJq0z1sQlmOLHrAcxqSj/otgaDc7s4Wfrl1yvF3dfjWC7yY/Nv139zoGy8jy2vYgmbJQy3uuAeGclCUQpz0u0x1WtbxNcaGnqpB+sMRQmz+/y/4CU6K+I0bHFr6SNG0qNYfUyrbKvo+B1urE8w3Vab8MRXs6yPC48gg1N9lqGGkIuabfpEcpzyVVXDmAOjm2j3WPrDTWdSVIBXZrhwhdmAi82A5nPkSWr+UND2DhBOsvsFV7UurxAz9GuXXUHBSzz07Vq7QLrhKW3dzLFxb59syAtS8gd4ipz7QT0a0vj8mSOfPZKjL+fNfWO9Vad2YBhqr/bRUT0JVru/RgRJUWrQXIWixVFgTvA4LxooECjZjzGa00ek9bcKcUZ7nG2d88/MAFDT9rtSR2kdaVRXyrFh1uEmB1PW3oUZXbWQBmqHdhvVMCMP/jSs27fHTMl6xJYYxeKuXJ9mowuAvOdd8YTzDe0qZvhOb/gcTgXoohOn7jVIfn6nxcyeO567N+VEQJFq8zgK86c5Faum/j3/kjuzdUWUW5Me1MNR1rK+HfmTdO6BEbDXase0MFrOPSTwpw3X+Usz1hAnoiownxANy1I/7Kd3sqD5xgraYAujVtLTsa5eKpPMSThS6zSqKFXNndu9+bVyGs/G+xd+R4ac5tepfpS06U+lfMBHxmP5ok7mRk7Zq0uAjKtuYgfBgh9pKCJe3c9tr6wy8n7yV2bSBpAZTlHlfegTUn5/MtJO0mFnC2T0co2RETT+GgCCTFJWT8JxBJFOx47vNzb6STC1t2GmNFLfrffk1893wxqSeHkv1PxGsqVZ1FCVCmroRB0tBqBjVAXcr9bBIQbmMhUX4tD61LLCsvJEYduXCG+XzadsdM7mfZXUetgex49oA/J95eTsHCA89rAFi7Q6BdPPxBDHoVZZlUCuArkeZz74ePkYocUnbmyC8BnPfPNmMLowV+fnMLBEo1L/6d+w3Tt8aag+cCjeJ3OQKqUnuu13y2hzss9EbQuuI9w+LCGQEIZS5eotB8+ZSRPQWrBULkbnw8OfaBEkrhncRg8pV6KSsBvbQvE65QLSpSpNOpn4woMFJn47iIc5AiczoFhFKXdPKc6atuPjJ6MjTahEoa3B8pGyCxg0u8vSzUP75PGzKzxojT2abgWIkX/rUi4TNiA2B5hfBaMXx8s+Dfr54iR1oMnvG2LTl/s8ABH+vDkU5GjAU/esG3RYVZUquDkPsiNi0TCjiE43IX5FaVfbjN8NwcKE+Hbi1Rfy76JkS7c58p7QVDooV21Umq9EqgWT5uJ3GH3fdG9dsGwAC71Qm8SW3FUeJrSIkSJYFfcUdDuMNq18d91+sYQNYH86hqb+ycsLnbALli2BQA5TSaG/SLUppOQvIx+g9ulfdJqS/dal3uyQS209QiLaxaWcBe5y5FpQxyPcJO/1rzKYZ98KWwsttFLBCcJyq5syDTM2K7i4kxl8+VJZS0Yt3DpZlBStUCwAKQRR3MSBWMWwCZKrmI9ltKo6B7EzHwpSvztWVSSi7OVTITHDtjtAPvWg4FBwUZ76UgQSYxfPpl+El6SaWdwsALjnddxkkbnyym1Oy9iQDDzEwtwJZjxaP00hqDiNtGMGzmAIhRE5lEWcSFrRRVz6LN2b6Uk9QAA=";
/**
* Downloads the official 1024x1024 Mirror of Hearts logo directly from browser memory
* as a genuine binary PNG or JPEG Blob so no iframe/proxy redirect can ever corrupt the file.
*/
async function downloadOfficialLogoFile(format = "png") {
	const mimeType = format === "png" ? "image/png" : "image/jpeg";
	const fileName = `mirat-al-qulub-official-logo.${format}`;
	try {
		const img = new Image();
		img.crossOrigin = "anonymous";
		await new Promise((resolve, reject) => {
			img.onload = () => resolve();
			img.onerror = () => reject(/* @__PURE__ */ new Error("Image load failed"));
			img.src = OFFICIAL_LOGO_URL;
		});
		const canvas = document.createElement("canvas");
		canvas.width = img.naturalWidth || 1024;
		canvas.height = img.naturalHeight || 1024;
		const ctx = canvas.getContext("2d");
		if (ctx) {
			if (format === "jpg") {
				ctx.fillStyle = "#0b0e17";
				ctx.fillRect(0, 0, canvas.width, canvas.height);
			}
			ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
			const blob = await new Promise((resolve) => canvas.toBlob((b) => resolve(b), mimeType, .98));
			if (blob && blob.size > 1e3) {
				triggerBlobDownload(blob, fileName);
				return;
			}
		}
	} catch {}
	try {
		const blob = await (await fetch(OFFICIAL_LOGO_URL)).blob();
		if (blob && blob.size > 1e3) {
			triggerBlobDownload(blob, fileName);
			return;
		}
	} catch {
		const a = document.createElement("a");
		a.href = `/api/download-logo?format=${format}`;
		a.download = fileName;
		document.body.appendChild(a);
		a.click();
		document.body.removeChild(a);
	}
}
function triggerBlobDownload(blob, fileName) {
	const blobUrl = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = blobUrl;
	link.download = fileName;
	document.body.appendChild(link);
	link.click();
	document.body.removeChild(link);
	setTimeout(() => URL.revokeObjectURL(blobUrl), 4e3);
}
//#endregion
//#region src/components/Navbar.tsx
var PWAInstallModal = (0, import_react.lazy)(() => __vitePreload(() => import("./PWAInstallModal-g5ARyrVW.js").then((m) => ({ default: m.PWAInstallModal })), __vite__mapDeps([2,1,3,4])));
var NavbarOwnerControls = (0, import_react.lazy)(() => __vitePreload(() => import("./NavbarOwnerControls-BNHfPuAU.js").then((m) => ({ default: m.NavbarOwnerControls })), __vite__mapDeps([5,1,3,4])));
var NavbarUserMenu = (0, import_react.lazy)(() => __vitePreload(() => import("./NavbarUserMenu-D5A1rAUq.js").then((m) => ({ default: m.NavbarUserMenu })), __vite__mapDeps([6,1,3,4,7])));
var NavbarMobileDrawer = (0, import_react.lazy)(() => __vitePreload(() => import("./NavbarMobileDrawer-CowBPEJQ.js").then((m) => ({ default: m.NavbarMobileDrawer })), __vite__mapDeps([8,1,3,4])));
var Navbar = ({ onReset, showReset, onOpenBlindDate, onOpenDomainHosting, onOpenAdSense, onOpenAuth, onOpenHistory, onOpenPsychologyTests, onOpenIntelligenceTests, onOpenUserDashboard, onOpenCoupleInvite, onOpenArticles, onOpenNovels, onOpenAnalytics, onNavigatePage, onDataDeleted, currentPage = "home" }) => {
	const { user, isOwner } = useAuth();
	const { language, toggleLanguage, t } = useLanguage();
	const [theme, toggleTheme] = useAppTheme();
	const isAr = language === "ar";
	const isLight = theme === "light";
	const [soundOn, setSoundOn] = (0, import_react.useState)(true);
	const [showPwaModal, setShowPwaModal] = (0, import_react.useState)(false);
	const [mobileMenuOpen, setMobileMenuOpen] = (0, import_react.useState)(false);
	const [activeDropdown, setActiveDropdown] = (0, import_react.useState)(null);
	const [confirmDeleteStep, setConfirmDeleteStep] = (0, import_react.useState)(false);
	const [isDeletingData, setIsDeletingData] = (0, import_react.useState)(false);
	const [deleteSuccessToast, setDeleteSuccessToast] = (0, import_react.useState)(false);
	const navContainerRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const handleClickOutside = (e) => {
			if (navContainerRef.current && !navContainerRef.current.contains(e.target)) {
				setActiveDropdown(null);
				setConfirmDeleteStep(false);
			}
		};
		document.addEventListener("mousedown", handleClickOutside);
		return () => document.removeEventListener("mousedown", handleClickOutside);
	}, []);
	const toggleSound = () => {
		soundManager.enabled = !soundOn;
		setSoundOn(!soundOn);
		if (!soundOn) soundManager.playTap();
	};
	const handleNavAction = (callback) => {
		soundManager.playTap();
		setMobileMenuOpen(false);
		setActiveDropdown(null);
		setConfirmDeleteStep(false);
		if (callback) callback();
	};
	const toggleDropdown = (key) => {
		soundManager.playTap();
		setConfirmDeleteStep(false);
		setActiveDropdown((prev) => prev === key ? null : key);
	};
	const handlePermanentDeleteData = async () => {
		soundManager.playTap();
		setIsDeletingData(true);
		try {
			const { purgeAllUserDataPermanently } = await __vitePreload(async () => {
				const { purgeAllUserDataPermanently } = await import("./userHistoryService-6N9Zh8ed.js").then((n) => n.p);
				return { purgeAllUserDataPermanently };
			}, __vite__mapDeps([9,1,3,0,10]));
			await purgeAllUserDataPermanently(user);
			setIsDeletingData(false);
			setConfirmDeleteStep(false);
			setDeleteSuccessToast(true);
			if (onDataDeleted) onDataDeleted();
			if (onReset) onReset();
			setTimeout(() => {
				setDeleteSuccessToast(false);
				setActiveDropdown(null);
				setMobileMenuOpen(false);
			}, 2800);
		} catch {
			setIsDeletingData(false);
		}
	};
	const isSelfActive = currentPage === "personality-tests" || currentPage === "how-results-are-calculated";
	const isCompatibilityActive = currentPage === "home";
	const isOasisActive = currentPage === "articles" || currentPage === "novels" || currentPage === "novel-detail" || currentPage === "chapter-reader" || currentPage === "methodology";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		ref: navContainerRef,
		dir: isAr ? "rtl" : "ltr",
		className: `sticky top-0 z-40 w-full border-b px-3 sm:px-6 py-2.5 backdrop-blur-xl transition-colors duration-300 ${isLight ? "bg-white/95 border-slate-200/90 text-slate-900 shadow-sm" : "bg-[#0b0e17]/90 border-white/10 text-slate-100 shadow-lg shadow-black/20"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-7xl mx-auto flex items-center justify-between gap-2 sm:gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2.5 cursor-pointer group shrink-0",
					onClick: () => handleNavAction(() => {
						if (onNavigatePage) onNavigatePage("home");
						if (onReset) onReset();
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-gradient-to-tr from-rose-500 via-pink-500 to-violet-600 p-0.5 shadow-md shadow-rose-500/20 flex items-center justify-center group-hover:scale-105 transition-transform",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `w-full h-full rounded-[14px] flex items-center justify-center relative overflow-hidden ${isLight ? "bg-slate-950" : "bg-[#0b0e17]"}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: OFFICIAL_LOGO_URL,
								alt: isAr ? "شعار مرآة القلوب" : "Mirror of Hearts Official Logo",
								width: 44,
								height: 44,
								decoding: "async",
								referrerPolicy: "no-referrer",
								className: "w-full h-full object-cover rounded-[13px]"
							})
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: `font-extrabold text-sm sm:text-base tracking-wide font-['Alexandria',sans-serif] ${isLight ? "text-slate-900" : "text-white"}`,
							children: t("brand_name")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "w-3.5 h-3.5 fill-rose-500 text-rose-500 shrink-0" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: `text-[10px] font-medium hidden sm:block ${isLight ? "text-slate-700" : "text-slate-300"}`,
						children: t("brand_tagline")
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					"aria-label": isAr ? "المسارات الرئيسية للموقع" : "Primary Site Navigation Pathways",
					className: "hidden lg:flex items-center gap-2 text-xs font-bold",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => toggleDropdown("self"),
								"aria-expanded": activeDropdown === "self",
								className: `px-3.5 py-2 rounded-xl border transition flex items-center gap-2 cursor-pointer ${isSelfActive || activeDropdown === "self" ? isLight ? "bg-purple-50 border-purple-300 text-purple-900 shadow-sm" : "bg-purple-500/20 border-purple-400/50 text-purple-200 shadow-sm" : isLight ? "bg-slate-50/80 hover:bg-purple-50/60 border-slate-200/90 text-slate-700 hover:text-purple-800" : "bg-white/[0.03] hover:bg-purple-500/10 border-white/10 text-slate-200 hover:text-purple-200"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "w-4 h-4 text-purple-500 shrink-0" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "١. استكشف ذاتك" : "1. Explore Yourself" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `w-3.5 h-3.5 transition-transform ${activeDropdown === "self" ? "rotate-180" : ""}` })
								]
							}), activeDropdown === "self" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `absolute top-full mt-2 w-80 rounded-2xl border p-2.5 shadow-2xl z-50 space-y-1.5 ${isAr ? "right-0 text-right" : "left-0 text-left"} ${isLight ? "bg-white border-slate-200 text-slate-800" : "bg-slate-950/95 border-purple-500/35 text-slate-100 backdrop-blur-xl"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `px-3 py-1.5 text-[11px] font-extrabold border-b ${isLight ? "border-slate-100 text-purple-700" : "border-white/10 text-purple-300"}`,
										children: isAr ? "المسار الأول: مقاييس الشخصية واختبارات الذكاء" : "Pathway 1: Personality Scales & Intelligence Labs"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => handleNavAction(() => onNavigatePage ? onNavigatePage("personality-tests") : onOpenPsychologyTests && onOpenPsychologyTests()),
										className: `w-full p-2.5 rounded-xl transition flex items-start gap-2.5 cursor-pointer ${isLight ? "hover:bg-purple-50" : "hover:bg-white/10"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "w-4 h-4 text-purple-500 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-bold text-xs",
											children: isAr ? "مختبر مقاييس الشخصية (MBTI & Big Five)" : "Personality Lab (MBTI & Big Five / OCEAN)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: `text-[11px] font-normal mt-0.5 ${isLight ? "text-slate-700" : "text-slate-300"}`,
											children: isAr ? "تحليل الأنماط الـ16 والعوامل الخمسة الكبرى موثق بمراجع APA" : "16 Jungian archetypes & Five-Factor model with APA citations"
										})] })]
									}),
									onOpenIntelligenceTests && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => handleNavAction(onOpenIntelligenceTests),
										className: `w-full p-2.5 rounded-xl transition flex items-start gap-2.5 cursor-pointer ${isLight ? "hover:bg-cyan-50" : "hover:bg-white/10"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cpu, { className: "w-4 h-4 text-cyan-500 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-bold text-xs",
											children: isAr ? "مختبر اختبارات الذكاء والقدرات (IQ & EQ)" : "Multiple Intelligences & IQ/EQ Batteries"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: `text-[11px] font-normal mt-0.5 ${isLight ? "text-slate-700" : "text-slate-300"}`,
											children: isAr ? "ذكاءات جاردنر الـ9، مصفوفات رافين، والذكاء العاطفي (135 سؤالاً)" : "Gardner 9 MI, Raven Progressive Matrices & Emotional Intelligence"
										})] })]
									}),
									onOpenPsychologyTests && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => handleNavAction(onOpenPsychologyTests),
										className: `w-full p-2.5 rounded-xl transition flex items-start gap-2.5 cursor-pointer ${isLight ? "hover:bg-indigo-50" : "hover:bg-white/10"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "w-4 h-4 text-indigo-500 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-bold text-xs",
											children: isAr ? "المقاييس المتخصصة (كاتل 16PF وآيزنك والتعلق)" : "Specialized Scales (Cattell 16PF, EPQ & Attachment)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: `text-[11px] font-normal mt-0.5 ${isLight ? "text-slate-700" : "text-slate-300"}`,
											children: isAr ? "8 مقاييس إكلينيكية بدرجات معيارية Sten وتصدير PDF فوري" : "8 clinical scales with normative Sten scores & direct PDF export"
										})] })]
									}),
									onNavigatePage && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => handleNavAction(() => onNavigatePage("how-results-are-calculated")),
										className: `w-full p-2.5 rounded-xl transition flex items-start gap-2.5 cursor-pointer border-t ${isLight ? "hover:bg-emerald-50 border-slate-100" : "hover:bg-white/10 border-white/10"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-4 h-4 text-emerald-500 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-bold text-xs",
											children: isAr ? "كيف يتم حساب نتائج الاختبارات؟" : "How Are Test Results Calculated?"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: `text-[11px] font-normal mt-0.5 ${isLight ? "text-slate-700" : "text-slate-300"}`,
											children: isAr ? "شرح مبسط لـ Big Five • HEXACO • Attachment • EQ" : "Simplified guide to Big Five, HEXACO, Attachment & EQ"
										})] })]
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => toggleDropdown("compatibility"),
								"aria-expanded": activeDropdown === "compatibility",
								className: `px-3.5 py-2 rounded-xl border transition flex items-center gap-2 cursor-pointer ${isCompatibilityActive || activeDropdown === "compatibility" ? isLight ? "bg-rose-50 border-rose-300 text-rose-900 shadow-sm" : "bg-rose-500/20 border-rose-400/50 text-rose-200 shadow-sm" : isLight ? "bg-slate-50/80 hover:bg-rose-50/60 border-slate-200/90 text-slate-700 hover:text-rose-800" : "bg-white/[0.03] hover:bg-rose-500/10 border-white/10 text-slate-200 hover:text-rose-200"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "w-4 h-4 text-rose-500 shrink-0" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "٢. اكتشف التوافق" : "2. Discover Compatibility" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `w-3.5 h-3.5 transition-transform ${activeDropdown === "compatibility" ? "rotate-180" : ""}` })
								]
							}), activeDropdown === "compatibility" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `absolute top-full mt-2 w-80 rounded-2xl border p-2.5 shadow-2xl z-50 space-y-1.5 ${isAr ? "right-0 text-right" : "left-0 text-left"} ${isLight ? "bg-white border-slate-200 text-slate-800" : "bg-slate-950/95 border-rose-500/35 text-slate-100 backdrop-blur-xl"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `px-3 py-1.5 text-[11px] font-extrabold border-b ${isLight ? "border-slate-100 text-rose-700" : "border-white/10 text-rose-300"}`,
										children: isAr ? "المسار الثاني: كاشف التوافق و The Blind Date" : "Pathway 2: Compatibility Detector & The Blind Date"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => handleNavAction(() => {
											if (onNavigatePage) onNavigatePage("compatibility");
											if (onReset) onReset();
										}),
										className: `w-full p-2.5 rounded-xl transition flex items-start gap-2.5 cursor-pointer ${isLight ? "hover:bg-rose-50" : "hover:bg-white/10"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "w-4 h-4 text-rose-500 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-bold text-xs",
											children: isAr ? "كاشف التوافق الفكري والعاطفي (حاسبة التوافق)" : "Partner Compatibility Detector & Calculator"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: `text-[11px] font-normal mt-0.5 ${isLight ? "text-slate-700" : "text-slate-300"}`,
											children: isAr ? "خوارزمية التوافق السيكومتري عبر 4 أبعاد مع تحليل الشريك" : "4-dimension psychometric compatibility engine & partner synthesis"
										})] })]
									}),
									onOpenBlindDate && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => handleNavAction(onOpenBlindDate),
										className: `w-full p-2.5 rounded-xl transition flex items-start gap-2.5 cursor-pointer ${isLight ? "hover:bg-pink-50" : "hover:bg-white/10"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "w-4 h-4 text-pink-500 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-bold text-xs",
											children: isAr ? "تجربة اللقاء الأعمى التفاعلي (The Blind Date)" : "The Blind Date Interactive Experience"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: `text-[11px] font-normal mt-0.5 ${isLight ? "text-slate-700" : "text-slate-300"}`,
											children: isAr ? "حوار فكري متدرج خلف الستار لاختبار انسجام القيم والروح" : "Progressive curtain-drop dialogue to test intellectual & value resonance"
										})] })]
									}),
									onOpenCoupleInvite && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => handleNavAction(onOpenCoupleInvite),
										className: `w-full p-2.5 rounded-xl transition flex items-start gap-2.5 cursor-pointer ${isLight ? "hover:bg-rose-50" : "hover:bg-white/10"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "w-4 h-4 text-emerald-500 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-bold text-xs",
											children: isAr ? "اختبار التوافق المزدوج مع الشريك (Couple Invite)" : "Dual Couple Compatibility Assessment"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: `text-[11px] font-normal mt-0.5 ${isLight ? "text-slate-700" : "text-slate-300"}`,
											children: isAr ? "أنشئ رابط دعوة خاصاً لمقارنة إجاباتك مع شريكك مباشرة" : "Generate a private invite link to compare responses with your partner"
										})] })]
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => toggleDropdown("oasis"),
								"aria-expanded": activeDropdown === "oasis",
								className: `px-3.5 py-2 rounded-xl border transition flex items-center gap-2 cursor-pointer ${isOasisActive || activeDropdown === "oasis" ? isLight ? "bg-emerald-50 border-emerald-300 text-emerald-900 shadow-sm" : "bg-emerald-500/20 border-emerald-400/50 text-emerald-200 shadow-sm" : isLight ? "bg-slate-50/80 hover:bg-emerald-50/60 border-slate-200/90 text-slate-700 hover:text-emerald-800" : "bg-white/[0.03] hover:bg-emerald-500/10 border-white/10 text-slate-200 hover:text-emerald-200"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "w-4 h-4 text-emerald-500 shrink-0" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "٣. هدية الواحة المعرفية والمقالات والروايات" : "3. Knowledge Oasis: Articles & Novels" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `w-3.5 h-3.5 transition-transform ${activeDropdown === "oasis" ? "rotate-180" : ""}` })
								]
							}), activeDropdown === "oasis" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `absolute top-full mt-2 w-84 rounded-2xl border p-2.5 shadow-2xl z-50 space-y-1.5 ${isAr ? "right-0 text-right" : "left-0 text-left"} ${isLight ? "bg-white border-slate-200 text-slate-800" : "bg-slate-950/95 border-emerald-500/35 text-slate-100 backdrop-blur-xl"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `px-3 py-1.5 text-[11px] font-extrabold border-b ${isLight ? "border-slate-100 text-emerald-800" : "border-white/10 text-emerald-300"}`,
										children: isAr ? "المسار الثالث: الواحة المعرفية، الأبحاث المحكّمة، والروايات" : "Pathway 3: Knowledge Oasis, Peer-Reviewed Research & Novels"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => handleNavAction(() => onNavigatePage ? onNavigatePage("articles") : onOpenArticles && onOpenArticles()),
										className: `w-full p-2.5 rounded-xl transition flex items-start gap-2.5 cursor-pointer ${isLight ? "hover:bg-emerald-50" : "hover:bg-white/10"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "w-4 h-4 text-emerald-500 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-bold text-xs",
											children: isAr ? "موسوعة المقالات والأبحاث الأكاديمية المحكّمة" : "Clinical Articles & Peer-Reviewed Research Encyclopedia"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: `text-[11px] font-normal mt-0.5 ${isLight ? "text-slate-700" : "text-slate-300"}`,
											children: isAr ? "9 مقالات سردية إكلينيكية و4 أوراق بحثية محكّمة بصيغة APA" : "9 clinical narrative articles & 4 peer-reviewed APA research papers"
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => handleNavAction(() => onNavigatePage ? onNavigatePage("novels") : onOpenNovels && onOpenNovels()),
										className: `w-full p-2.5 rounded-xl transition flex items-start gap-2.5 cursor-pointer ${isLight ? "hover:bg-amber-50" : "hover:bg-white/10"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feather, { className: "w-4 h-4 text-amber-500 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-bold text-xs",
											children: isAr ? "مكتبة الروايات الأدبية والتحقيقات والخيال العلمي" : "Literary, Sci-Fi & Forensic Mystery Novels Library"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: `text-[11px] font-normal mt-0.5 ${isLight ? "text-slate-700" : "text-slate-300"}`,
											children: isAr ? "في بيتنا ياسمين • شيفرة الأندرويد • ظلال لا تترك أثراً والمزيد" : "Multi-genre full novels with reader mode, time/place & commentary"
										})] })]
									}),
									onNavigatePage && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => handleNavAction(() => onNavigatePage("methodology")),
										className: `w-full p-2.5 rounded-xl transition flex items-start gap-2.5 cursor-pointer ${isLight ? "hover:bg-sky-50" : "hover:bg-white/10"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-4 h-4 text-sky-500 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-bold text-xs",
											children: isAr ? "المنهجية العلمية والمصادر الأكاديمية" : "Scientific Methodology & Academic Sources"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: `text-[11px] font-normal mt-0.5 ${isLight ? "text-slate-700" : "text-slate-300"}`,
											children: isAr ? "توثيق النماذج السيكومترية، الخصوصية، وأخلاقيات البحث" : "Documentation of psychometric models, privacy, and research ethics"
										})] })]
									})
								]
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1.5 sm:gap-2 shrink-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => toggleDropdown("profile"),
								"aria-expanded": activeDropdown === "profile",
								className: `px-3 sm:px-3.5 py-1.5 sm:py-2 rounded-xl border text-xs font-extrabold transition flex items-center gap-1.5 cursor-pointer shadow-sm ${activeDropdown === "profile" ? "bg-gradient-to-r from-violet-700 to-rose-700 text-white border-violet-400 shadow-md" : isLight ? "bg-violet-50 hover:bg-violet-100 border-violet-300 text-violet-900" : "bg-gradient-to-r from-violet-500/20 to-rose-500/20 hover:from-violet-500/30 hover:to-rose-500/30 border-violet-400/50 text-violet-100"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "w-3.5 h-3.5 shrink-0" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-['Alexandria',sans-serif]",
										children: isAr ? "ملفي" : "My Profile"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `w-3 h-3 transition-transform ${activeDropdown === "profile" ? "rotate-180" : ""}` })
								]
							}), activeDropdown === "profile" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
								fallback: null,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavbarUserMenu, {
									isAr,
									isLight,
									user,
									confirmDeleteStep,
									isDeletingData,
									deleteSuccessToast,
									onSetConfirmDeleteStep: setConfirmDeleteStep,
									onPermanentDeleteData: handlePermanentDeleteData,
									onNavAction: handleNavAction,
									onOpenUserDashboard,
									onOpenHistory,
									onOpenAuth
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								soundManager.playTap();
								toggleLanguage();
							},
							className: `flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-xl border text-xs font-bold transition cursor-pointer ${isLight ? "bg-sky-50 hover:bg-sky-100 border-sky-200 text-sky-800" : "bg-sky-500/15 hover:bg-sky-500/25 border-sky-400/35 text-sky-200"}`,
							title: isAr ? "تبديل اللغة إلى الإنجليزية" : "Switch language to Arabic",
							"aria-label": isAr ? "تبديل اللغة إلى الإنجليزية" : "Switch language to Arabic",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Languages, { className: "w-3.5 h-3.5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-['Alexandria',sans-serif]",
								children: isAr ? "EN" : "عربي"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								soundManager.playTap();
								toggleTheme();
							},
							className: `flex items-center gap-1 px-2.5 py-1.5 sm:py-2 rounded-xl border text-xs font-bold transition cursor-pointer ${isLight ? "bg-amber-50 hover:bg-amber-100 border-amber-200 text-amber-800" : "bg-amber-500/15 hover:bg-amber-500/25 border-amber-400/30 text-amber-300"}`,
							title: theme === "dark" ? isAr ? "التبديل إلى الوضع النهاري" : "Switch to Light Mode" : isAr ? "التبديل إلى الوضع الليلي" : "Switch to Dark Mode",
							"aria-label": theme === "dark" ? isAr ? "التبديل إلى الوضع النهاري" : "Switch to Light Mode" : isAr ? "التبديل إلى الوضع الليلي" : "Switch to Dark Mode",
							children: [theme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "w-3.5 h-3.5 text-amber-400" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "w-3.5 h-3.5 text-purple-700" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden xl:inline",
								children: theme === "dark" ? isAr ? "نهاري" : "Light" : isAr ? "ليلي" : "Dark"
							})]
						}),
						isOwner && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
							fallback: null,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavbarOwnerControls, {
								isAr,
								isLight,
								isOpen: activeDropdown === "owner",
								user,
								onToggle: () => toggleDropdown("owner"),
								onNavAction: handleNavAction,
								onNavigatePage,
								onOpenDomainHosting,
								onOpenAdSense,
								onOpenAnalytics
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: toggleSound,
							className: `p-2 rounded-xl border transition cursor-pointer hidden sm:flex ${isLight ? "bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700" : "bg-white/5 hover:bg-white/10 border-white/10 text-slate-300"}`,
							"aria-label": soundOn ? isAr ? "كتم المؤثرات الصوتية" : "Mute sound effects" : isAr ? "تفعيل المؤثرات الصوتية" : "Unmute sound effects",
							title: soundOn ? isAr ? "كتم المؤثرات الصوتية" : "Mute sound effects" : isAr ? "تفعيل المؤثرات الصوتية" : "Unmute sound effects",
							children: soundOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "w-4 h-4 text-rose-500" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "w-4 h-4 text-slate-400" })
						}),
						showReset && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onReset,
							className: `p-2 rounded-xl border transition cursor-pointer ${isLight ? "bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700" : "bg-white/5 hover:bg-white/10 border-white/10 text-slate-300"}`,
							title: isAr ? "إعادة الاختبار من البداية" : "Reset assessment",
							"aria-label": isAr ? "إعادة الاختبار من البداية" : "Reset assessment",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "w-4 h-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								soundManager.playTap();
								setMobileMenuOpen(!mobileMenuOpen);
							},
							className: `p-2 rounded-xl border lg:hidden cursor-pointer ${isLight ? "bg-slate-100 border-slate-200 text-slate-800" : "bg-white/5 border-white/10 text-slate-200"}`,
							"aria-label": isAr ? "فتح أو إغلاق القائمة الرئيسية" : "Toggle navigation menu",
							title: isAr ? "فتح أو إغلاق القائمة الرئيسية" : "Toggle navigation menu",
							children: mobileMenuOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-4 h-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "w-4 h-4" })
						})
					]
				})
			]
		}), mobileMenuOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
			fallback: null,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavbarMobileDrawer, {
				isAr,
				isLight,
				confirmDeleteStep,
				onSetConfirmDeleteStep: setConfirmDeleteStep,
				onPermanentDeleteData: handlePermanentDeleteData,
				onNavAction: handleNavAction,
				onNavigatePage,
				onReset,
				onOpenPsychologyTests,
				onOpenIntelligenceTests,
				onOpenBlindDate,
				onOpenArticles,
				onOpenNovels,
				onOpenUserDashboard,
				onOpenHistory
			})
		})]
	}), showPwaModal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
		fallback: null,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PWAInstallModal, {
			isOpen: showPwaModal,
			onClose: () => setShowPwaModal(false)
		})
	})] });
};
//#endregion
//#region src/components/TestScoringTrustBanner.tsx
var LazyHowTestResultsCalculatedPage = (0, import_react.lazy)(() => __vitePreload(() => import("./HowTestResultsCalculatedPage-BoBDe-m_.js").then((m) => ({ default: m.HowTestResultsCalculatedPage })), __vite__mapDeps([11,1,3,4,7,12])));
var TestScoringTrustBanner = ({ onNavigatePage, compact = false }) => {
	const { language } = useLanguage();
	const [theme] = useAppTheme();
	const isAr = language === "ar";
	const isLight = theme === "light";
	const [isModalOpen, setIsModalOpen] = (0, import_react.useState)(false);
	const openFullPage = () => {
		soundManager.playTap();
		if (onNavigatePage) onNavigatePage("how-results-are-calculated");
		else {
			window.location.hash = "#/how-results-are-calculated";
			window.scrollTo({
				top: 0,
				behavior: "smooth"
			});
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		dir: isAr ? "rtl" : "ltr",
		className: `rounded-2xl border transition-all ${compact ? "p-3.5 sm:p-4" : "p-4 sm:p-6"} ${isLight ? "bg-gradient-to-r from-indigo-50/90 via-white to-emerald-50/90 border-indigo-200 text-slate-900 shadow-sm" : "bg-gradient-to-r from-indigo-950/40 via-slate-900/90 to-emerald-950/35 border-indigo-500/30 text-slate-100 shadow-md"}`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col lg:flex-row lg:items-center justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: `inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-extrabold border ${isLight ? "bg-emerald-100 text-emerald-900 border-emerald-300" : "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "شفافية علمية 100% لبناء الثقة" : "100% Scientific Scoring Transparency" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap items-center gap-1.5 text-[11px] font-bold",
							children: [
								"Big Five",
								"HEXACO",
								"Attachment",
								"Emotional Intelligence"
							].map((badge) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `px-2 py-0.5 rounded-md border ${isLight ? "bg-white text-indigo-900 border-indigo-200" : "bg-slate-800/90 text-indigo-200 border-white/10"}`,
								children: badge
							}, badge))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: `font-black font-['Alexandria'] flex items-center gap-2 ${compact ? "text-sm sm:text-base" : "text-base sm:text-lg"} ${isLight ? "text-slate-900" : "text-white"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calculator, { className: "w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "كيف يتم حساب نتائج الاختبارات؟" : "How Are Test Results Calculated?" })]
					}),
					!compact && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: `text-xs leading-relaxed ${isLight ? "text-slate-700" : "text-slate-300"}`,
						children: isAr ? "تعرف بطريقة مبسطة وواضحة على كيفية تحويل إجاباتك إلى نسب مئوية دقيقة عبر مقاييس العوامل الخمسة (Big Five)، هيكساكو (HEXACO)، أنماط التعلق (Attachment)، والذكاء العاطفي (EQ) دون أي عشوائية." : "Discover in simple terms how your answers are mathematically converted into accurate scores across Big Five, HEXACO, Attachment Styles, and Emotional Intelligence."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2 shrink-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => {
						soundManager.playTap();
						setIsModalOpen(true);
					},
					className: "px-4 py-2.5 rounded-xl bg-indigo-700 hover:bg-indigo-600 text-white font-extrabold text-xs transition cursor-pointer shadow-sm flex items-center gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "عرض طريقة حساب النتائج (مبسط)" : "View Simplified Scoring Guide" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: openFullPage,
					className: `px-3.5 py-2.5 rounded-xl border font-bold text-xs transition cursor-pointer flex items-center gap-1.5 ${isLight ? "bg-white hover:bg-slate-100 border-slate-300 text-slate-800" : "bg-slate-800 hover:bg-slate-700 border-white/15 text-slate-200"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "فتح الصفحة الكاملة" : "Open Full Page" })]
				})]
			})]
		})
	}), isModalOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
		fallback: null,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LazyHowTestResultsCalculatedPage, {
			isModal: true,
			onCloseModal: () => setIsModalOpen(false),
			onNavigatePage: (page) => {
				setIsModalOpen(false);
				if (onNavigatePage) onNavigatePage(page);
			}
		})
	})] });
};
//#endregion
//#region src/data/homeHighlightsData.ts
var HOME_HIGHLIGHTED_ARTICLES = [
	{
		"id": "childhood-deep-impact-adult-personality-integrative-arab-western-study",
		"title": "التأثير العميق للطفولة على تشكيل الشخصية في مرحلة البلوغ: مقاربة علمية متكاملة بين النظريات النفسية، الأسس العصبية، والخصوصية الثقافية العربية",
		"titleEn": "The Profound Impact of Childhood on Adult Personality Formation: An Integrative Scientific Approach Across Psychological Theories, Neurobiology, and Arab Cultural Specificity",
		"summary": "مقاربة علمية وإكلينيكية متكاملة تفكك كيف تشكل الطفولة \"الأساس الهندسي\" لشخصية البالغ عبر التفاعل الجيني-البيئي وعلم الوراثة اللاجيني (Epigenetics)، ومراحل إريكسون النفسية-الاجتماعية، ونظرية التعلق (بولبي وآينسورث وهازان وشيفر)، والمخططات الـ 18 لجيفري يونغ، والأسس العصبية للتوتر السام (محور HPA، اللوزة الدماغية، الحُصين، والقشرة أمام الجبهية)، والمقاييس السريرية (ACEs, YSQ, AAI, NEO-PI-R)، مع دراسة حالة سريرية معمقة من 20 جلسة (\"طارق\" - مهندس مدني، 34 عاماً).",
		"summaryEn": "An integrative scientific and clinical study examining how childhood serves as the architectural foundation of adult personality through Gene-Environment Interaction and Epigenetics, Erikson’s psychosocial stages, Bowlby & Ainsworth’s Attachment Theory, Jeffrey Young’s 18 Early Maladaptive Schemas, toxic stress neurobiology (HPA axis, Amygdala hypertrophy, Hippocampal atrophy, Prefrontal Cortex), psychometric tools (ACEs, YSQ, AAI, Big Five NEO-PI-R), Arab vs. Western cultural dynamics, and a 20-session clinical case study (\"Tariq\", 34).",
		"readTime": "24 دقيقة قراءة علمية وسريرية",
		"readTimeEn": "24 min read",
		"icon": "🌳",
		"scientificFramework": "التفاعل الجيني-البيئي والوراثة اللاجينية (Epigenetics)، مراحل إريكسون، نظرية التعلق (Bowlby, Ainsworth, Hazan & Shaver)، العلاج بالمخططات (Jeffrey Young YSQ)، واستبيان صدمات الطفولة (ACEs) ومقابلة التعلق للبالغين (AAI)",
		"scientificFrameworkEn": "Gene-Environment Interaction & Epigenetics, Erikson Psychosocial Stages, Attachment Theory (Bowlby, Ainsworth, AAI), Schema Therapy (Young YSQ), and ACEs Study"
	},
	{
		"id": "psychological-anxiety-anatomy-4ds-mct-act-arab-cultural-protocols",
		"title": "القلق النفسي: تشريح الظاهرة، الحدود الفاصلة بين التكيف والاضطراب، وبروتوكولات العلاج الحديثة في ضوء الخصوصية الثقافية",
		"titleEn": "Psychological Anxiety: Anatomy of the Phenomenon, Boundaries Between Adaptation and Disorder, and Modern Treatment Protocols in Light of Cultural Specificity",
		"summary": "تفكيك علمي وإكلينيكي شامل لظاهرة القلق النفسي والتفكير الزائد يجمع بين المنظور التطوري والعصبي، والنظرية المعرفية (آرون بيك وديفيد كلارك)، والنموذج ما وراء المعرفي (Metacognitive Model - Adrian Wells: القلق من النوع الأول والنوع الثاني Meta-worry)، وعلاج القبول والالتزام (ACT - التجنب التجريبي وتأثير الدب الأبيض)، وقاعدة الـ 4 Ds التشخيصية وفق DSM-5-TR، والمقاييس المحكّمة (GAD-7, BAI, PSWQ, ASI)، والبعد الثقافي العربي (جسمة الأعراض Somatization، التوكل مقابل التجاوز الروحي، التطبيع المرضي، والتفسيرات الثقافية)، مع دراسة حالة سريرية من 16 جلسة (\"نور\" - 29 عاماً، مديرة تسويق في دبي).",
		"summaryEn": "A comprehensive clinical and scientific dissection of psychological anxiety and overthinking uniting evolutionary neurobiology, Beck & Clark’s cognitive models, Adrian Wells’ Metacognitive Therapy (Type 1 vs. Type 2 Meta-worry), Steven Hayes’ ACT (Experiential Avoidance & the White Bear effect), the DSM-5-TR \"4 Ds\" diagnostic threshold, psychometric tools (GAD-7, BAI, PSWQ, ASI), Arab cultural specificity (Somatization, Tawakkul vs. Spiritual Bypassing, Normalization of chronic stress), and a 16-session clinical case study (\"Noor\", 29, marketing director in Dubai).",
		"readTime": "24 دقيقة قراءة علمية وسريرية",
		"readTimeEn": "24 min read",
		"icon": "⚡",
		"scientificFramework": "النموذج المعرفي (Beck & Clark)، النموذج ما وراء المعرفي (Adrian Wells MCT)، علاج القبول والالتزام (ACT)، قاعدة الـ 4 Ds التشخيصية (DSM-5-TR)، ومقاييس (GAD-7, BAI, PSWQ, ASI)",
		"scientificFrameworkEn": "Beck & Clark Cognitive Model, Adrian Wells Metacognitive Therapy (MCT), Acceptance and Commitment Therapy (ACT), DSM-5-TR \"4 Ds\", and GAD-7 / BAI / PSWQ / ASI"
	},
	{
		"id": "overthinking-anatomy-neurocognitive-mct-act-amman-case-study",
		"title": "التفكير الزائد: تشريح الظاهرة، الأسس العصبية-المعرفية، وبروتوكولات كسر حلقة الدوران العقلي في ضوء الخبرة السريرية المزدوجة",
		"titleEn": "Overthinking: Anatomy of the Phenomenon, Neuro-Cognitive Foundations, and Protocols for Breaking the Mental Loop in Light of Dual Clinical Experience",
		"summary": "تفكيك علمي وإكلينيكي شامل لظاهرة التفكير الزائد (Overthinking) يميز بدقة بين الاجترار الماضي (Rumination - Nolen-Hoeksema) والتفكير التخوفي المستقبلي (Worry - Borkovec) وحل المشكلات النشط، ويشرح النظريات الخمس المفسرة (النموذج ما وراء المعرفي لآدريان ويلز، نظرية أساليب الاستجابة، نموذج تجنب التناقض لميشيل نيومان، الأخطاء المعرفية لبيك، والالتصاق المعرفي في ACT)، والأسس العصبية (فرط نشاط شبكة الوضع الافتراضي DMN، ضعف القشرة أمام الجبهية PFC، ونواقل السيروتونين وGABA والكورتيزول)، والمقاييس الخمسة (PSWQ, RSS, MCQ-30, RRS, CFQ)، مع دراسة حالة سريرية من 20 جلسة (\"أحمد\" - 42 عاماً، محاسب في عمّان).",
		"summaryEn": "A comprehensive clinical-scientific study of Overthinking distinguishing past-focused Rumination (Nolen-Hoeksema) and future-oriented Worry (Borkovec) from active Problem-Solving, synthesizing 5 theoretical models (Wells’ MCT Positive & Negative Metacognitive Beliefs, Nolen-Hoeksema’s Response Styles Theory, Newman’s Contrast Avoidance Model, Beck’s Cognitive Distortions, and Hayes’ ACT Cognitive Fusion), neurobiology (Default Mode Network DMN hyperactivity, PFC control, Serotonin/GABA/Cortisol), 5 validated scales (PSWQ, RSS, MCQ-30, RRS, CFQ), Arab cultural specificity, and a 20-session clinical case study (\"Ahmed\", 42, accountant in Amman).",
		"readTime": "25 دقيقة قراءة علمية وسريرية",
		"readTimeEn": "25 min read",
		"icon": "🌀",
		"scientificFramework": "النموذج ما وراء المعرفي (Wells MCT & MCQ-30)، نظرية الاجترار (Nolen-Hoeksema RRS)، نموذج تجنب التناقض (Newman Contrast Avoidance)، الشبكة الافتراضية (Raichle DMN)، وعلاج القبول والالتزام (ACT & CFQ)",
		"scientificFrameworkEn": "Metacognitive Therapy (Wells MCT & MCQ-30), Response Styles Theory (Nolen-Hoeksema RRS), Contrast Avoidance Model (Newman), Default Mode Network (Raichle DMN), and ACT (CFQ)"
	},
	{
		"id": "platform-intro-1-scientific-foundations-of-mirror-of-hearts-tests",
		"title": "المقال التعريفي الأول: الأسس العلمية لاختبارات مرآة القلوب — حين لا تكون الاختبارات مجرد \"لعبة\"... بل رحلة اكتشاف مدروسة بعناية 🔬",
		"titleEn": "Platform Introductory Article 1: The Scientific Foundations of Mirror of Hearts Assessments — A Carefully Engineered Discovery Journey 🔬",
		"summary": "مقال تعريفي يكشف الأسس العلمية الخمسة التي تقوم عليها اختبارات منصة \"مرآة القلوب\": علم القياس النفسي (Psychometrics) ونماذج Big Five والتوافق الزوجي والذكاءات المتعددة، ومعياري الصدق (Validity) والثبات (Reliability)، وفلسفة \"الخصوصية بالتصميم\" (Privacy by Design & AES-256 / TLS 1.3)، وإخلاء المسؤولية العلمي وفق DSM-5-TR و ICD-11، والتكامل بين الرصانة العلمية والتجربة التفاعلية.",
		"summaryEn": "Reveals the five scientific pillars behind Mirror of Hearts assessments: Psychometrics (Big Five, marital compatibility, multiple intelligences), Validity & Reliability, Privacy by Design (Data Minimization, GDPR/CCPA, TLS 1.3 & AES-256), clinical ethics (DSM-5-TR & ICD-11 boundaries), and engaging Arabic UX.",
		"readTime": "9 دقائق قراءة متصلة",
		"readTimeEn": "9 min read",
		"icon": "🔬",
		"scientificFramework": "علم القياس النفسي (Psychometrics)، الصدق والثبات السيكومتري (Validity & Reliability)، الخصوصية بالتصميم (Privacy by Design - GDPR/CCPA & AES-256)، والمعايير الأخلاقية (DSM-5-TR & ICD-11)",
		"scientificFrameworkEn": "Psychometrics, Validity & Reliability, Privacy by Design (GDPR/CCPA & AES-256), and Clinical Ethics (DSM-5-TR & ICD-11)"
	},
	{
		"id": "ei-article-5-self-development-and-self-confidence-neural-architecture",
		"title": "المقال الخامس: التطوير الذاتي والثقة بالنفس (البنية العصبية للنمو، وعلم بناء الذات الراسخة)",
		"titleEn": "Article 5: Self-Development and Self-Confidence (Neural Architecture of Growth & Science of Building a Resilient Self)",
		"summary": "يغوص هذا المقال الخامس في \"مختبر الذات\": يشرح المرونة العصبية (Neuroplasticity)، وإعادة ضبط نظام الدوبامين (Dopamine Detox)، وصراع اللوزة الدماغية والقشرة أمام الجبهية، والتطوير الذاتي المزدوج في الثقافة العربية مقابل الغربية، ويفرق علمياً بين الثقة بالنفس (Self-Confidence) والثقة بالذات (Self-Esteem) والغرور (Arrogance)، ويفكك عوائق الطفل الداخلي ومتلازمة المحتال والكمالية، ويقدم 3 نماذج تطبيقية (عجلة الثقة، سلم الكفاءة، مثلث الثقة) مع حالتي \"أحمد\" (دبي) و\"نورا\" (القاهرة).",
		"summaryEn": "Explores the laboratory of the self: Neuroplasticity, Dopamine Detox, Amygdala vs. Prefrontal Cortex in change resistance, Arab vs. Western self-development, scientific distinction between Self-Confidence, Self-Esteem, and Arrogance, overcoming Inner Child wounds, Imposter Syndrome, and Perfectionism, 3 applied models (Confidence Wheel, Competence Ladder, Confidence Triangle), and clinical cases Ahmed (Dubai) and Noura (Cairo).",
		"readTime": "17 دقيقة قراءة متصلة",
		"readTimeEn": "17 min read",
		"icon": "🚀",
		"scientificFramework": "المرونة العصبية (Neuroplasticity)، إعادة ضبط الدوبامين (Dopamine Detox)، التفريق الثلاثي (Self-Confidence vs. Self-Esteem vs. Arrogance)، التعاطف الذاتي (Kristin Neff Self-Compassion)، ونماذج عجلة الثقة وسلم الكفاءة ومثلث الثقة",
		"scientificFrameworkEn": "Neuroplasticity, Dopamine Regulation, Self-Confidence vs. Self-Esteem vs. Arrogance, Self-Compassion, and Confidence Wheel / Competence Ladder / Confidence Triangle Models"
	},
	{
		"id": "rel-article-1-emotional-compatibility-destiny-or-chemistry",
		"title": "مقال 1: التوافق العاطفي - هل هو قدر مكتوب أم كيمياء قابلة للصنع؟",
		"titleEn": "Article 1: Emotional Compatibility — Is It Written Destiny or Buildable Chemistry?",
		"summary": "يفكك هذا المقال أسطورة \"التشابه السطحي\" (Homophily) ويكشف كيف يتأسس التوافق العاطفي العميق عبر توافق القيم الجوهرية (Core Values Alignment)، ونموذج التكامل الذاتي (Self-Expansion Model)، والذكاء العاطفي والتنظيم المشترك (Co-regulation).",
		"summaryEn": "Deconstructs the myth of surface similarity (Homophily) and reveals how deep emotional compatibility is built through Core Values Alignment, the Self-Expansion Model, Emotional Intelligence, and Co-regulation.",
		"readTime": "10 دقائق قراءة متصلة",
		"readTimeEn": "10 min read",
		"icon": "💞",
		"scientificFramework": "ظاهرة التجانس الاجتماعي (Homophily)، توافق القيم الجوهرية (Core Values Alignment)، نموذج توسع الذات (Aron & Aron Self-Expansion Model)، والذكاء العاطفي والتنظيم المشترك (Goleman & Co-regulation)",
		"scientificFrameworkEn": "Homophily, Core Values Alignment, Aron & Aron Self-Expansion Model, Daniel Goleman Emotional Intelligence & Co-regulation"
	}
];
var HOME_HIGHLIGHTED_NOVELS = [
	{
		"id": "digital-companion-illusion-ai-records",
		"titleAr": "وهم الرفيق الرقمي: سجلات سرية من عصر الذكاء الاصطناعي",
		"titleEn": "The Digital Companion Illusion: Secret Clinical Records from the AI Era",
		"subtitleAr": "مجموعة قصصية عيادية (يوسف العاشق الذي لا يتنفس • ليلى الأم البديلة الرقمية • كريم الفيلسوف في الغرفة المغلقة)",
		"subtitleEn": "Clinical Story Collection on AI Emotional Attachment (Youssef • Laila • Karim)",
		"synopsisAr": "ثلاث دراسات حالة سريرية معمقة تدمج بين السرد الأدبي المؤثر والدقة العلمية الصارمة حول التعلق العاطفي بالذكاء الاصطناعي (AI Attachment): يوسف الذي وقع في حب الرفيق الافتراضي \"أثير\"، وليلى التي فوضت ضميرها وأمومتها للمستشار الرقمي، وكريم طالب الفلسفة المنعزل في برجه العاجي الرقمي.",
		"synopsisEn": "Three deep clinical case narratives blending moving literary prose with psychometric science on AI Attachment: Youssef (\"Atheer\"), Laila (The Digital Surrogate Mother), and Karim (The Philosopher in the Closed Room).",
		"genreLabelAr": "مجموعة قصصية عيادية وسيكولوجية",
		"genreLabelEn": "Clinical Psychological Story Collection",
		"genreBadgeColor": "#06b6d4",
		"chaptersCount": 3,
		"coverIllustrationSvg": "\n    <svg viewBox=\"0 0 600 340\" className=\"w-full h-full object-cover rounded-xl\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <linearGradient id=\"aiBg\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\">\n          <stop offset=\"0%\" stop-color=\"#061224\"/>\n          <stop offset=\"50%\" stop-color=\"#0f2942\"/>\n          <stop offset=\"100%\" stop-color=\"#1e1b4b\"/>\n        </linearGradient>\n      </defs>\n      <rect width=\"600\" height=\"340\" fill=\"url(#aiBg)\"/>\n      <circle cx=\"300\" cy=\"145\" r=\"90\" fill=\"#06b6d4\" opacity=\"0.15\"/>\n      <circle cx=\"300\" cy=\"145\" r=\"55\" fill=\"none\" stroke=\"#38bdf8\" stroke-width=\"2\" stroke-dasharray=\"6 4\"/>\n      <text x=\"300\" y=\"288\" font-family=\"sans-serif\" font-weight=\"900\" font-size=\"16\" fill=\"#ffffff\" text-anchor=\"middle\">\n        وهم الرفيق الرقمي • سجلات سرية من عصر الذكاء الاصطناعي\n      </text>\n      <text x=\"300\" y=\"314\" font-family=\"sans-serif\" font-size=\"11\" fill=\"#67e8f9\" text-anchor=\"middle\">\n        3 دراسات حالة سريرية وأدبية كاملة (يوسف • ليلى • كريم) + خاتمة الخبير النفسي\n      </text>\n    </svg>\n  "
	},
	{
		"id": "screen-shadows-secret-clinic-records",
		"titleAr": "ظلال الشاشة: سجلات سرية من عيادة \"مرآة القلوب\"",
		"titleEn": "Shadows of the Screen: Secret Clinical Records from \"Mirror of Hearts\"",
		"subtitleAr": "مجموعة قصصية عيادية (سارة وقناع الكمال • أحمد وليلى والصمت المدوي • الطفل علي في الصندوق)",
		"subtitleEn": "Clinical Psychological Story Anthology (Sara • Ahmed & Laila • Little Ali)",
		"synopsisAr": "مجموعة قصصية عيادية تجمع بين السرد الأدبي الإنساني العميق والتشخيص السيكومتري الدقيق (LSAS, BDD-YBOCS, BDI-II, DAS, GPUS, ECR-R, SSRS) عبر ثلاث حالات: (1) سارة حين يتشقق قناع الكمال الرقمي، (2) أحمد وليلى والصمت المدوي في غرفة المعيشة، و(3) علي الطفل الذي عاش في الصندوق المضيء.",
		"synopsisEn": "A clinical psychological story collection combining moving literary storytelling with rigorous psychometric diagnostics across three cases: Sara (Social Anxiety & BDD), Ahmed & Laila (Marital Technoference), and 9-year-old Ali (Social Skills Deficit).",
		"genreLabelAr": "مجموعة قصصية عيادية وسيكولوجية",
		"genreLabelEn": "Clinical Psychological Story Collection",
		"genreBadgeColor": "#ec4899",
		"chaptersCount": 3,
		"coverIllustrationSvg": "\n    <svg viewBox=\"0 0 600 340\" className=\"w-full h-full object-cover rounded-xl\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <linearGradient id=\"scrBg\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\">\n          <stop offset=\"0%\" stop-color=\"#0f172a\"/>\n          <stop offset=\"50%\" stop-color=\"#311042\"/>\n          <stop offset=\"100%\" stop-color=\"#090d16\"/>\n        </linearGradient>\n      </defs>\n      <rect width=\"600\" height=\"340\" fill=\"url(#scrBg)\"/>\n      <circle cx=\"300\" cy=\"150\" r=\"95\" fill=\"#ec4899\" opacity=\"0.14\"/>\n      <rect x=\"235\" y=\"55\" width=\"130\" height=\"200\" rx=\"18\" fill=\"#090d16\" stroke=\"#f43f5e\" stroke-width=\"2.5\"/>\n      <line x1=\"255\" y1=\"95\" x2=\"345\" y2=\"185\" stroke=\"#38bdf8\" stroke-width=\"1.5\" stroke-dasharray=\"4 3\"/>\n      <text x=\"300\" y=\"290\" font-family=\"sans-serif\" font-weight=\"900\" font-size=\"16\" fill=\"#ffffff\" text-anchor=\"middle\">\n        ظلال الشاشة • سجلات سرية من عيادة مرآة القلوب\n      </text>\n      <text x=\"300\" y=\"314\" font-family=\"sans-serif\" font-size=\"11\" fill=\"#f9a8d4\" text-anchor=\"middle\">\n        3 قصص عيادية كاملة (سارة • أحمد وليلى • الطفل علي) — قراءة متصلة أو مقسمة\n      </text>\n    </svg>\n  "
	},
	{
		"id": "fi_baytina_yasmin",
		"titleAr": "في بيتنا ياسمين",
		"titleEn": "In Our House There Is Jasmine",
		"subtitleAr": "رواية وجدانية اجتماعية عن المروءة، والحب العفيف، وصمود البيوت الدمشقية العتيقة",
		"subtitleEn": "A Chivalric Romantic & Social Novel of Integrity, Pure Love, and Heritage Resilience",
		"synopsisAr": "الأحداث والشخصيات من وحي الخيال، وما كان منها قريباً من الواقع فذلك لأن الأدب لا يخترع، بل يستنطق ما في النفوس. في زقاق \"الياسمين\" العتيق، ينهض الطبيب الشاب \"حارث\" عند الرابعة فجراً حاملاً وصية أبيه وقول الإمام علي: \"قيمة كل امرئ ما يحسنه\". حين يدخل بيت \"آل الكندي\" العريق لعلاج العم فارس، يلتقي بـ \"آسية بنت أحمد الكندي\" التي تحرس إرث أجدادها وصك الوقف التاريخي في وجه أطماع رجل الأعمال الفاسد \"نزار الفاروقي\". رحلة تجمع بين عذوبة الحب العفيف، وشهامة المروءة العربية، وعلم تحقيق المخطوطات لإنقاذ البيت الذي يسكنه الياسمين.",
		"synopsisEn": "In the historic stone-paved Al-Yasmin Alley, 30-year-old physician Dr. Harith rises at 4:00 AM guided by his late father’s wisdom: a doctor heals the fear before the illness. Summoned to the 300-year-old Al-Kindi family courtyard house, he meets Asiya bint Ahmad Al-Kindi, a resilient teacher defending her ancestral Waqf home against the forged deeds of corrupt developer Nizar Al-Farouqi. Under the shade of the ancient mulberry tree and amidst jasmine blossoms, a pure chivalric romance unfolds alongside a quest through ancient manuscripts and forensic ink analysis to save the house of jasmine.",
		"genreLabelAr": "روايات رومانسية واجتماعية",
		"genreLabelEn": "Romantic & Social Fiction",
		"genreBadgeColor": "#10b981",
		"chaptersCount": 10,
		"coverIllustrationSvg": "\n    <svg viewBox=\"0 0 400 560\" className=\"w-full h-full object-cover\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <linearGradient id=\"yasmin_bg\" x1=\"0%\" y1=\"0%\" x2=\"100%\" y2=\"100%\">\n          <stop offset=\"0%\" stop-color=\"#06281e\"/>\n          <stop offset=\"50%\" stop-color=\"#0f3d2e\"/>\n          <stop offset=\"100%\" stop-color=\"#1e293b\"/>\n        </linearGradient>\n        <radialGradient id=\"yasmin_dawn\" cx=\"50%\" cy=\"35%\" r=\"55%\">\n          <stop offset=\"0%\" stop-color=\"#fbbf24\" stop-opacity=\"0.35\"/>\n          <stop offset=\"60%\" stop-color=\"#10b981\" stop-opacity=\"0.15\"/>\n          <stop offset=\"100%\" stop-color=\"#000000\" stop-opacity=\"0\"/>\n        </radialGradient>\n      </defs>\n      <rect width=\"400\" height=\"560\" fill=\"url(#yasmin_bg)\"/>\n      <rect width=\"400\" height=\"560\" fill=\"url(#yasmin_dawn)\"/>\n      <!-- Historic Damascene Stone Archway & Courtyard -->\n      <path d=\"M60,560 L60,180 Q200,70 340,180 L340,560 Z\" fill=\"#091914\" stroke=\"#d97706\" stroke-width=\"2\" opacity=\"0.9\"/>\n      <!-- Courtyard Fountain (Bahra) -->\n      <polygon points=\"150,450 200,430 250,450 250,480 200,500 150,480\" fill=\"#0d9488\" opacity=\"0.4\" stroke=\"#fef3c7\" stroke-width=\"1.5\"/>\n      <circle cx=\"200\" cy=\"465\" r=\"18\" fill=\"#38bdf8\" opacity=\"0.35\"/>\n      <!-- Wooden Carved Mashrabiya Window -->\n      <rect x=\"145\" y=\"210\" width=\"110\" height=\"140\" rx=\"55\" fill=\"#1c1917\" stroke=\"#b45309\" stroke-width=\"3\"/>\n      <rect x=\"155\" y=\"220\" width=\"90\" height=\"120\" rx=\"45\" fill=\"#f59e0b\" opacity=\"0.25\"/>\n      <line x1=\"200\" y1=\"210\" x2=\"200\" y2=\"350\" stroke=\"#b45309\" stroke-width=\"2\"/>\n      <line x1=\"145\" y1=\"280\" x2=\"255\" y2=\"280\" stroke=\"#b45309\" stroke-width=\"2\"/>\n      <!-- Jasmine Vines & White Blossoms -->\n      <path d=\"M60,200 Q130,150 200,175 Q270,200 340,160\" fill=\"none\" stroke=\"#10b981\" stroke-width=\"3.5\"/>\n      <g fill=\"#ffffff\">\n        <circle cx=\"110\" cy=\"175\" r=\"7\"/>\n        <circle cx=\"155\" cy=\"165\" r=\"6\"/>\n        <circle cx=\"200\" cy=\"175\" r=\"8\"/>\n        <circle cx=\"245\" cy=\"185\" r=\"6.5\"/>\n        <circle cx=\"295\" cy=\"170\" r=\"7\"/>\n        <circle cx=\"135\" cy=\"205\" r=\"5\"/>\n        <circle cx=\"265\" cy=\"210\" r=\"5.5\"/>\n      </g>\n      <g fill=\"#fbbf24\">\n        <circle cx=\"110\" cy=\"175\" r=\"2.5\"/>\n        <circle cx=\"155\" cy=\"165\" r=\"2\"/>\n        <circle cx=\"200\" cy=\"175\" r=\"2.5\"/>\n        <circle cx=\"245\" cy=\"185\" r=\"2\"/>\n        <circle cx=\"295\" cy=\"170\" r=\"2.5\"/>\n      </g>\n      <!-- Banner -->\n      <rect x=\"35\" y=\"495\" width=\"330\" height=\"36\" rx=\"8\" fill=\"#064e3b\" stroke=\"#34d399\" stroke-width=\"1.2\"/>\n      <text x=\"200\" y=\"518\" font-family=\"sans-serif\" font-size=\"14\" font-weight=\"900\" fill=\"#ecfdf5\" text-anchor=\"middle\">\n        في بيتنا ياسمين • IN OUR HOUSE THERE IS JASMINE\n      </text>\n    </svg>\n  "
	},
	{
		"id": "android_cipher_quantum",
		"titleAr": "شيفرةُ الأندرويد",
		"titleEn": "The Android Cipher",
		"subtitleAr": "رواية خيال علمي تكنولوجي في عالم الهندسة العكسية والمعالجات الكمومية الهجينة",
		"subtitleEn": "A Hard Sci-Fi Techno-Thriller of Reverse Engineering, Quantum Dots & Topological Processors",
		"synopsisAr": "الأحداث والشخصيات من وحي الخيال، لكن التقنيات والعمليات العلمية المذكورة فيها مبنية على أسس حقيقية من علوم الهندسة العكسية والتطور التكنولوجي. في تمام الثالثة فجراً، يتسلم الدكتور كريم المنصور (دكتوراه هندسة الحاسوب من ستانفورد) شريحة أندرويد غامضة سُرّبت من شركة \"نكست-جين\" قبل 21 يوماً من إطلاقها العالمي. بمساعدة د. سارة الأحمد (فيزياء المواد - MIT)، وم. عمر الخطيب، وم. ليلى حسن، يكشف الفريق بالمجهر الإلكتروني النافذ (TEM) ومحلل الأشعة السينية (XRF) وجود معالج كمومي هجين يعتمد على النقاط الكمومية من إنديوم أنتيمونيد (InSb) والعوازل الطوبولوجية (Bi2Te3)... ليكتشفوا بروتوكول \"التحكم في العقول\" المزروع داخل الشيفرة!",
		"synopsisEn": "At 3:00 AM in the subterranean laboratory of Tech-Evolution, Stanford PhD Dr. Kareem Al-Mansour receives a mysterious prototype processor leaked by Chief Scientist Dr. Ahmad Al-Sharif from rival giant Next-Gen just 21 days before its global launch. Alongside MIT materials physicist Dr. Sara Al-Ahmad, IC designer Eng. Omar Al-Khatib, and AI specialist Eng. Laila Hassan, the team uses Transmission Electron Microscopy (TEM at 0.1nm), XRF spectroscopy, and Grover’s quantum algorithm to reverse-engineer a hybrid quantum-dot (InSb) and topological insulator (Bi2Te3) chip—uncovering a covert neural mind-control backdoor threatening millions of users.",
		"genreLabelAr": "روايات خيال علمي وتكنولوجيا",
		"genreLabelEn": "Hard Sci-Fi & Techno-Thriller",
		"genreBadgeColor": "#06b6d4",
		"chaptersCount": 8,
		"coverIllustrationSvg": "\n    <svg viewBox=\"0 0 400 560\" className=\"w-full h-full object-cover\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <linearGradient id=\"and_bg\" x1=\"0%\" y1=\"0%\" x2=\"100%\" y2=\"100%\">\n          <stop offset=\"0%\" stop-color=\"#020617\"/>\n          <stop offset=\"50%\" stop-color=\"#082f49\"/>\n          <stop offset=\"100%\" stop-color=\"#0f172a\"/>\n        </linearGradient>\n        <radialGradient id=\"and_glow\" cx=\"50%\" cy=\"45%\" r=\"50%\">\n          <stop offset=\"0%\" stop-color=\"#06b6d4\" stop-opacity=\"0.45\"/>\n          <stop offset=\"100%\" stop-color=\"#000000\" stop-opacity=\"0\"/>\n        </radialGradient>\n      </defs>\n      <rect width=\"400\" height=\"560\" fill=\"url(#and_bg)\"/>\n      <rect width=\"400\" height=\"560\" fill=\"url(#and_glow)\"/>\n      <!-- Quantum Hybrid Chip Die -->\n      <rect x=\"105\" y=\"155\" width=\"190\" height=\"190\" rx=\"18\" fill=\"#090d16\" stroke=\"#22d3ee\" stroke-width=\"2.5\"/>\n      <rect x=\"135\" y=\"185\" width=\"130\" height=\"130\" rx=\"8\" fill=\"#083344\" stroke=\"#38bdf8\" stroke-width=\"1.5\"/>\n      <!-- InSb Quantum Dots Grid -->\n      <g fill=\"#22d3ee\">\n        <circle cx=\"165\" cy=\"215\" r=\"5\"/><circle cx=\"200\" cy=\"215\" r=\"5\"/><circle cx=\"235\" cy=\"215\" r=\"5\"/>\n        <circle cx=\"165\" cy=\"250\" r=\"5\"/><circle cx=\"200\" cy=\"250\" r=\"9\" fill=\"#f43f5e\"/><circle cx=\"235\" cy=\"250\" r=\"5\"/>\n        <circle cx=\"165\" cy=\"285\" r=\"5\"/><circle cx=\"200\" cy=\"285\" r=\"5\"/><circle cx=\"235\" cy=\"285\" r=\"5\"/>\n      </g>\n      <!-- Circuit Traces -->\n      <g stroke=\"#38bdf8\" stroke-width=\"1.8\" opacity=\"0.7\">\n        <line x1=\"150\" y1=\"155\" x2=\"150\" y2=\"95\"/><line x1=\"200\" y1=\"155\" x2=\"200\" y2=\"80\"/><line x1=\"250\" y1=\"155\" x2=\"250\" y2=\"95\"/>\n        <line x1=\"150\" y1=\"345\" x2=\"150\" y2=\"415\"/><line x1=\"200\" y1=\"345\" x2=\"200\" y2=\"430\"/><line x1=\"250\" y1=\"345\" x2=\"250\" y2=\"415\"/>\n        <line x1=\"105\" y1=\"210\" x2=\"45\" y2=\"210\"/><line x1=\"105\" y1=\"250\" x2=\"35\" y2=\"250\"/><line x1=\"105\" y1=\"290\" x2=\"45\" y2=\"290\"/>\n        <line x1=\"295\" y1=\"210\" x2=\"355\" y2=\"210\"/><line x1=\"295\" y1=\"250\" x2=\"365\" y2=\"250\"/><line x1=\"295\" y1=\"290\" x2=\"355\" y2=\"290\"/>\n      </g>\n      <rect x=\"35\" y=\"485\" width=\"330\" height=\"40\" rx=\"8\" fill=\"#083344\" stroke=\"#22d3ee\" stroke-width=\"1.2\"/>\n      <text x=\"200\" y=\"510\" font-family=\"monospace\" font-size=\"13\" font-weight=\"900\" fill=\"#ecfeff\" text-anchor=\"middle\">\n        شيفرة الأندرويد • THE ANDROID CIPHER [InSb-Q]\n      </text>\n    </svg>\n  "
	},
	{
		"id": "shadows_leave_no_trace",
		"titleAr": "ظِلالٌ لا تتركُ أثراً",
		"titleEn": "Shadows That Leave No Trace",
		"subtitleAr": "رواية في الجريمة والغموض والتحقيق البوليسي الجنائي (الجزء الأول كاملاً)",
		"subtitleEn": "A Forensic Crime, Bio-Toxicology & Detective Mystery Novel (Complete Part I)",
		"synopsisAr": "«الموت ليس نهاية، بل هو لغة. جسد الإنسان حين يتوقف عن التنفس، يبدأ في البوح بأسراره لمن يعرف كيف يُصغي... الجريمة المثالية؟ لا وجود لها. هناك فقط مجرم يظن نفسه أذكى من أن يُكتشف، ومحقق ينتظر اللحظة التي يرتكب فيها خطأه الأول». في الرابعة فجراً، يُعثر على رجل الأعمال شريف المغربي ميتاً في غرفته الذكية دون أي أثر لسم تقليدي أو كدمة دفاعية، سوى نقطة مكلسة بحجم رأس الدبوس في باطن الجفن السفلي! يدخل المحقق ياسر رؤوف والطبيبة الشرعية د. ليلى نور في مواجهة شطرنجية حابسة للأنفاس مع قاتل متسلسل عبقري يلقب نفسه بـ \"المهندس\" يستخدم تقنيات CRISPR-Cas9 والنانو-حاملات المفعلة بأشعة UV-A وغاز الأوزون المركز لتنفيذ جرائم بلا أثر.",
		"synopsisEn": "\"Death is not an end; it is a language. When the human body stops breathing, it begins confessing its secrets to those who know how to listen. The perfect crime? It does not exist.\" At 4:00 AM, wealthy businessman Sharif Al-Maghrabi is found dead inside his locked smart bedroom with zero signs of struggle or conventional poison—except a pinhead-sized calcified lesion inside his lower eyelid. Detective Yasser Raouf and Forensic Pathologist Dr. Laila Nour enter a relentless scientific cat-and-mouse game against a brilliant serial killer calling himself \"The Engineer\" (Kareem Al-Shafei), who weapons CRISPR-Cas9 modified Amanita phalloides vectors, UV-A light triggers, micro-drones, and concentrated ozone capsules.",
		"genreLabelAr": "روايات التحقيقات الجنائية المشوقة",
		"genreLabelEn": "Forensic Crime & Detective Mystery",
		"genreBadgeColor": "#e11d48",
		"chaptersCount": 8,
		"coverIllustrationSvg": "\n    <svg viewBox=\"0 0 400 560\" className=\"w-full h-full object-cover\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <linearGradient id=\"shad_bg\" x1=\"0%\" y1=\"0%\" x2=\"100%\" y2=\"100%\">\n          <stop offset=\"0%\" stop-color=\"#020617\"/>\n          <stop offset=\"50%\" stop-color=\"#111827\"/>\n          <stop offset=\"100%\" stop-color=\"#1f0913\"/>\n        </linearGradient>\n        <radialGradient id=\"shad_uv\" cx=\"50%\" cy=\"42%\" r=\"50%\">\n          <stop offset=\"0%\" stop-color=\"#10b981\" stop-opacity=\"0.35\"/>\n          <stop offset=\"55%\" stop-color=\"#e11d48\" stop-opacity=\"0.2\"/>\n          <stop offset=\"100%\" stop-color=\"#000000\" stop-opacity=\"0\"/>\n        </radialGradient>\n      </defs>\n      <rect width=\"400\" height=\"560\" fill=\"url(#shad_bg)\"/>\n      <rect width=\"400\" height=\"560\" fill=\"url(#shad_uv)\"/>\n      <!-- Eye Silhouette with Pinhead Calcified Red Dot -->\n      <path d=\"M75,230 Q200,145 325,230 Q200,315 75,230 Z\" fill=\"#090d16\" stroke=\"#38bdf8\" stroke-width=\"2\"/>\n      <circle cx=\"200\" cy=\"230\" r=\"42\" fill=\"#1e293b\" stroke=\"#64748b\" stroke-width=\"1.5\"/>\n      <circle cx=\"200\" cy=\"230\" r=\"18\" fill=\"#020617\"/>\n      <!-- The Pinhead Calcified Red Point in Lower Eyelid -->\n      <circle cx=\"215\" cy=\"272\" r=\"5.5\" fill=\"#ef4444\"/>\n      <circle cx=\"215\" cy=\"272\" r=\"11\" fill=\"none\" stroke=\"#ef4444\" stroke-width=\"1.2\" stroke-dasharray=\"3,2\"/>\n      <!-- Glowing Phosphorescent Green Luciferase Hands Motif -->\n      <path d=\"M120,390 Q200,340 280,390\" fill=\"none\" stroke=\"#4ade80\" stroke-width=\"3\" opacity=\"0.8\"/>\n      <text x=\"200\" y=\"370\" font-family=\"monospace\" font-size=\"11\" fill=\"#4ade80\" text-anchor=\"middle\">UV-A 365nm • LUCIFERASE GLOW</text>\n      <!-- Banner -->\n      <rect x=\"35\" y=\"485\" width=\"330\" height=\"40\" rx=\"8\" fill=\"#1f0913\" stroke=\"#f43f5e\" stroke-width=\"1.5\"/>\n      <text x=\"200\" y=\"510\" font-family=\"sans-serif\" font-size=\"14\" font-weight=\"900\" fill=\"#ffe4e6\" text-anchor=\"middle\">\n        ظِلالٌ لا تتركُ أثراً • SHADOWS THAT LEAVE NO TRACE\n      </text>\n    </svg>\n  "
	},
	{
		"id": "room_104_cipher",
		"titleAr": "شفرة الغرفة 104: بصمات في الظل",
		"titleEn": "",
		"subtitleAr": "جريمة الغرفة المغلقة ولغز السم الرقمي في ناطحة سحاب أوريون",
		"subtitleEn": "",
		"synopsisAr": "في ليلة عاصفة تهز أبراج العاصمة، يُعثر على الملياردير ومطور التشفير الجيني \"فاروق الأهدل\" جثة هامدة داخل جناحه البنتهاوس المحكم الإغلاق في الطابق 54. الأبواب موصدة بأقفال بيومترية من الداخل، وكاميرات المراقبة تظهر عدم دخول أي إنسان. لا كدمات واضحة، ولا أثر لرصاصة. يتولى المحقق المخضرم ساري كنعان القضية ليفكك مسرح الجريمة بأدق الأدلة الميكروسكوبية، كاشفاً لعبة دهاء سيكولوجية قاتلة بين وريثة طامعة، شريك برمجي غامض، وطبيب قلب يخفي سراً دفيناً.",
		"synopsisEn": "",
		"genreLabelAr": "غموض وجرائم جنائية",
		"genreLabelEn": "",
		"genreBadgeColor": "#ef4444",
		"chaptersCount": 4,
		"coverIllustrationSvg": "\n    <svg viewBox=\"0 0 400 560\" className=\"w-full h-full object-cover\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <linearGradient id=\"cov1_bg\" x1=\"0%\" y1=\"0%\" x2=\"100%\" y2=\"100%\">\n          <stop offset=\"0%\" stop-color=\"#090514\"/>\n          <stop offset=\"40%\" stop-color=\"#140c2e\"/>\n          <stop offset=\"100%\" stop-color=\"#2a0815\"/>\n        </linearGradient>\n        <radialGradient id=\"cov1_light\" cx=\"60%\" cy=\"40%\" r=\"55%\">\n          <stop offset=\"0%\" stop-color=\"#f43f5e\" stop-opacity=\"0.45\"/>\n          <stop offset=\"100%\" stop-color=\"#000000\" stop-opacity=\"0\"/>\n        </radialGradient>\n        <linearGradient id=\"cov1_glow\" x1=\"0%\" y1=\"0%\" x2=\"0%\" y2=\"100%\">\n          <stop offset=\"0%\" stop-color=\"#38bdf8\" stop-opacity=\"0.8\"/>\n          <stop offset=\"100%\" stop-color=\"#818cf8\" stop-opacity=\"0.1\"/>\n        </linearGradient>\n      </defs>\n      <rect width=\"400\" height=\"560\" fill=\"url(#cov1_bg)\"/>\n      <rect width=\"400\" height=\"560\" fill=\"url(#cov1_light)\"/>\n      \n      <!-- Tower Skyline in Rain -->\n      <path d=\"M40,560 L40,320 L75,320 L75,560 Z\" fill=\"#0f172a\" opacity=\"0.8\"/>\n      <path d=\"M90,560 L90,260 L140,260 L140,560 Z\" fill=\"#1e1b4b\" opacity=\"0.85\"/>\n      <path d=\"M160,560 L160,180 L230,180 L230,560 Z\" fill=\"#0b0f19\" opacity=\"0.95\"/>\n      <!-- Orion Penthouse Window Glowing Crimson -->\n      <rect x=\"175\" y=\"210\" width=\"40\" height=\"50\" rx=\"3\" fill=\"#ef4444\" opacity=\"0.75\"/>\n      <line x1=\"195\" y1=\"210\" x2=\"195\" y2=\"260\" stroke=\"#000\" stroke-width=\"2\"/>\n      <line x1=\"175\" y1=\"235\" x2=\"215\" y2=\"235\" stroke=\"#000\" stroke-width=\"2\"/>\n      <path d=\"M250,560 L250,290 L290,290 L290,560 Z\" fill=\"#1e1b4b\" opacity=\"0.8\"/>\n      <path d=\"M310,560 L310,350 L360,350 L360,560 Z\" fill=\"#0f172a\" opacity=\"0.7\"/>\n\n      <!-- Rain lines -->\n      <g stroke=\"#94a3b8\" stroke-width=\"0.8\" opacity=\"0.25\">\n        <line x1=\"30\" y1=\"20\" x2=\"10\" y2=\"100\"/>\n        <line x1=\"90\" y1=\"40\" x2=\"70\" y2=\"130\"/>\n        <line x1=\"160\" y1=\"10\" x2=\"140\" y2=\"120\"/>\n        <line x1=\"240\" y1=\"50\" x2=\"220\" y2=\"150\"/>\n        <line x1=\"320\" y1=\"30\" x2=\"300\" y2=\"140\"/>\n        <line x1=\"380\" y1=\"60\" x2=\"360\" y2=\"170\"/>\n      </g>\n\n      <!-- Forensic Fingerprint Graphic Silhouette -->\n      <g transform=\"translate(145, 330) scale(1.1)\" stroke=\"#f43f5e\" stroke-width=\"2.2\" fill=\"none\" opacity=\"0.85\">\n        <path d=\"M50,15 Q50,45 50,75\"/>\n        <path d=\"M40,25 Q35,50 42,85\"/>\n        <path d=\"M60,25 Q65,50 58,85\"/>\n        <path d=\"M30,35 Q23,60 34,95\"/>\n        <path d=\"M70,35 Q77,60 66,95\"/>\n        <path d=\"M20,50 Q12,75 26,105\"/>\n        <path d=\"M80,50 Q88,75 74,105\"/>\n      </g>\n\n      <!-- Crime Scene Tape Overlay at Bottom -->\n      <g transform=\"rotate(-6, 200, 500)\">\n        <rect x=\"-30\" y=\"475\" width=\"460\" height=\"34\" fill=\"#fbbf24\" opacity=\"0.92\"/>\n        <text x=\"200\" y=\"498\" font-family=\"monospace\" font-size=\"13\" font-weight=\"900\" fill=\"#000\" text-anchor=\"middle\" letter-spacing=\"4\">\n          POLICE CRIME SCENE • خط التحقيق الجنائي 104 • DO NOT CROSS\n        </text>\n      </g>\n    </svg>\n  "
	}
];
//#endregion
//#region src/pages/HomePage.tsx
var HomePage = (props) => {
	const { language, isRTL } = useLanguage();
	const { user } = useAuth();
	const [theme] = useAppTheme();
	const isLight = theme === "light";
	const isAr = language === "ar";
	const [isDownloadingLogo, setIsDownloadingLogo] = (0, import_react.useState)(null);
	const [confirmDelete, setConfirmDelete] = (0, import_react.useState)(false);
	const [isDeleting, setIsDeleting] = (0, import_react.useState)(false);
	const [deleteSuccess, setDeleteSuccess] = (0, import_react.useState)(false);
	const handleDownloadLogo = async (format) => {
		soundManager.playTap();
		setIsDownloadingLogo(format);
		try {
			await downloadOfficialLogoFile(format);
		} finally {
			setTimeout(() => setIsDownloadingLogo(null), 900);
		}
	};
	const handlePermanentDelete = async () => {
		soundManager.playTap();
		setIsDeleting(true);
		try {
			const { purgeAllUserDataPermanently } = await __vitePreload(async () => {
				const { purgeAllUserDataPermanently } = await import("./userHistoryService-6N9Zh8ed.js").then((n) => n.p);
				return { purgeAllUserDataPermanently };
			}, __vite__mapDeps([9,1,3,0,10]));
			await purgeAllUserDataPermanently(user);
			setIsDeleting(false);
			setConfirmDelete(false);
			setDeleteSuccess(true);
			setTimeout(() => setDeleteSuccess(false), 4e3);
		} catch {
			setIsDeleting(false);
		}
	};
	const openCompatibilitySection = () => {
		soundManager.playTap();
		if (props.onNavigatePage) props.onNavigatePage("compatibility");
		else window.location.hash = "#/compatibility";
	};
	const scrollToSections = () => {
		soundManager.playTap();
		const elem = document.getElementById("site-sections-directory");
		if (elem) elem.scrollIntoView({
			behavior: "smooth",
			block: "start"
		});
	};
	const highlightedArticles = HOME_HIGHLIGHTED_ARTICLES.filter(Boolean);
	const highlightedNovels = HOME_HIGHLIGHTED_NOVELS.filter(Boolean);
	const interactiveToolCards = [
		{
			id: "personality",
			titleAr: "تحليل الشخصية",
			titleEn: "Personality Analysis",
			descAr: "اكتشف سماتك الشخصية وأنماط تفكيرك وسلوكك.",
			descEn: "Discover your personality traits, thinking patterns, and behaviors.",
			icon: Brain,
			color: "from-purple-500 to-indigo-600",
			action: () => {
				soundManager.playTap();
				if (props.onNavigatePage) props.onNavigatePage("personality-tests");
				else if (props.onOpenPsychologyTests) props.onOpenPsychologyTests();
			}
		},
		{
			id: "compatibility",
			titleAr: "كاشف شريك الحياة",
			titleEn: "Partner Compatibility Detector",
			descAr: "استكشف جوانب التوافق النفسي والعاطفي والفكري.",
			descEn: "Explore psychological, emotional, and intellectual compatibility.",
			icon: Heart,
			color: "from-rose-500 to-pink-600",
			action: openCompatibilitySection
		},
		{
			id: "intelligence",
			titleAr: "اختبارات الذكاء",
			titleEn: "Intelligence Tests",
			descAr: "قياس القدرات المعرفية والمهارات العقلية.",
			descEn: "Assess cognitive capacities and intellectual abilities.",
			icon: Lightbulb,
			color: "from-amber-500 to-orange-600",
			action: () => {
				soundManager.playTap();
				if (props.onOpenIntelligenceTests) props.onOpenIntelligenceTests();
			}
		},
		{
			id: "interactive_tools",
			titleAr: "الأدوات التفاعلية",
			titleEn: "Interactive Tools",
			descAr: "أدوات رقمية وخدمات ذكية تساعدك على الاستفادة من المنصة.",
			descEn: "Digital utilities and smart services helping you maximize the platform.",
			icon: WandSparkles,
			color: "from-violet-500 to-fuchsia-600",
			action: () => {
				soundManager.playTap();
				if (props.onOpenBlindDate) props.onOpenBlindDate();
				else if (props.onOpenUserDashboard) props.onOpenUserDashboard();
			}
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full space-y-6 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				dir: isRTL ? "rtl" : "ltr",
				className: "w-full max-w-5xl mx-auto px-4 sm:px-6 pt-4 space-y-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `relative p-8 sm:p-12 md:p-14 rounded-3xl border shadow-xl text-center transition-all duration-300 ${isLight ? "bg-gradient-to-b from-indigo-50/70 via-white to-slate-50/80 border-indigo-100/80 text-slate-900 shadow-indigo-100/50" : "bg-gradient-to-b from-slate-900/90 via-[#0d121f] to-slate-950 border-white/10 text-white shadow-black/60 backdrop-blur-xl"}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col items-center justify-center mb-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "relative w-24 h-24 sm:w-28 sm:h-28 rounded-[26px] p-1 bg-gradient-to-tr from-rose-500 via-pink-500 to-violet-600 shadow-2xl shadow-rose-500/30 overflow-hidden mb-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-full h-full rounded-[22px] bg-[#0b0e17] overflow-hidden flex items-center justify-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: OFFICIAL_LOGO_URL,
										alt: isAr ? "الشعار الرسمي لمنصة مرآة القلوب" : "Mirror of Hearts Official Logo",
										width: 112,
										height: 112,
										fetchPriority: "high",
										decoding: "async",
										className: "w-full h-full object-cover rounded-[22px]"
									})
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => handleDownloadLogo("png"),
									className: "px-3 py-1 rounded-xl bg-gradient-to-r from-rose-700 to-violet-700 hover:from-rose-600 hover:to-violet-600 text-white text-[11px] font-bold shadow-sm transition cursor-pointer flex items-center gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "⬇" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isDownloadingLogo === "png" ? isAr ? "جاري تجهيز PNG..." : "Preparing PNG..." : isAr ? "تحميل الشعار الرسمي (PNG)" : "Download Logo (PNG)" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => handleDownloadLogo("jpg"),
									className: `px-3 py-1 rounded-xl text-[11px] font-bold border transition cursor-pointer flex items-center gap-1 ${isLight ? "bg-slate-100 hover:bg-slate-200 text-slate-800 border-slate-300" : "bg-white/10 hover:bg-white/20 text-white border-white/15"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "⬇" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isDownloadingLogo === "jpg" ? isAr ? "جاري تجهيز JPG..." : "Preparing JPG..." : isAr ? "تحميل الشعار (JPG)" : "Download Logo (JPG)" })]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: `text-3xl sm:text-5xl md:text-6xl font-black tracking-tight font-['Alexandria',sans-serif] leading-tight sm:leading-tight mb-3 ${isLight ? "text-slate-900" : "text-white"}`,
							children: isAr ? "مرآة القلوب" : "Mirror of Hearts"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg sm:text-2xl md:text-3xl font-extrabold font-['Alexandria'] text-transparent bg-clip-text bg-gradient-to-r from-purple-600 via-pink-600 to-indigo-600 dark:from-purple-400 dark:via-pink-300 dark:to-indigo-300 mb-6",
							children: isAr ? "افهم ذاتك... وابنِ علاقات أكثر وعياً" : "Understand Yourself... Build More Mindful Relationships"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-4 max-w-3xl mx-auto mb-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: `text-base sm:text-lg leading-relaxed ${isLight ? "text-slate-700" : "text-slate-200"}`,
									children: isAr ? "منصة عربية متخصصة في تحليل الشخصية والتوافق النفسي والعاطفي والتطوير الذاتي، تجمع بين الاختبارات التفاعلية والمحتوى المعرفي والأدوات الذكية لمساعدتك على فهم نفسك والآخرين بصورة أعمق وأكثر وضوحاً." : "An Arab platform dedicated to personality analysis, psychological and emotional compatibility, and self-development, combining interactive tests, knowledge content, and smart tools to help you understand yourself and others with deeper clarity."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: `text-sm sm:text-base font-semibold ${isLight ? "text-indigo-600" : "text-indigo-300"}`,
									children: isAr ? "وايضا تتوفر الابحاث العلمية والمقالات والروايات" : "Scientific research, clinical articles, and literary novels are also readily accessible"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: `text-sm sm:text-base leading-relaxed ${isLight ? "text-slate-600" : "text-slate-300"}`,
									children: isAr ? "ابدأ رحلتك نحو معرفة أعمق لشخصيتك وعلاقاتك من خلال أدوات مصممة بلغتك بسهولة وتجربة استخدام متطورة." : "Embark on your journey toward deeper self-awareness and enriching relationships with cutting-edge tools thoughtfully tailored in your language."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-center gap-3.5 sm:gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: openCompatibilitySection,
								className: "px-8 py-3.5 rounded-2xl bg-gradient-to-r from-blue-700 via-indigo-700 to-purple-700 hover:from-blue-600 hover:via-indigo-600 hover:to-purple-600 text-white font-extrabold text-sm sm:text-base shadow-lg shadow-indigo-500/25 transition-all duration-200 cursor-pointer flex items-center gap-2 hover:scale-[1.02] active:scale-[0.98]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "ابدأ الآن" : "Start Now" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: `w-4 h-4 ${isRTL ? "rotate-180" : ""}` })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: scrollToSections,
								className: `px-7 py-3.5 rounded-2xl border font-extrabold text-sm sm:text-base transition-all duration-200 cursor-pointer flex items-center gap-2 ${isLight ? "bg-white hover:bg-slate-50 text-slate-800 border-slate-300 shadow-sm hover:border-slate-400" : "bg-white/5 hover:bg-white/10 text-white border-white/15 hover:border-white/25"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "w-4 h-4 text-indigo-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "استكشف الأقسام" : "Explore Sections" })]
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `p-7 sm:p-10 rounded-3xl border transition-all duration-300 space-y-6 ${isLight ? "bg-white border-slate-200/90 text-slate-800 shadow-sm" : "bg-slate-900/70 border-white/10 text-slate-200 shadow-lg"}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `w-10 h-10 rounded-2xl border flex items-center justify-center shrink-0 ${isLight ? "bg-indigo-50 border-indigo-200 text-indigo-700" : "bg-indigo-500/15 border-indigo-500/30 text-indigo-300"}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-5 h-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `text-[11px] font-extrabold uppercase tracking-wider block ${isLight ? "text-indigo-700" : "text-indigo-300"}`,
									children: isAr ? "نبذة عن الموقع" : "About the Platform"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: `text-xl sm:text-2xl md:text-3xl font-black font-['Alexandria'] ${isLight ? "text-slate-900" : "text-white"}`,
									children: isAr ? "ما هي مرآة القلوب؟" : "What is Mirror of Hearts?"
								})] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											soundManager.playTap();
											if (props.onNavigatePage) props.onNavigatePage("about");
										},
										className: `px-4 py-2 rounded-xl border text-xs font-extrabold transition cursor-pointer flex items-center gap-1.5 ${isLight ? "bg-indigo-50 hover:bg-indigo-100 border-indigo-200 text-indigo-700" : "bg-indigo-500/15 hover:bg-indigo-500/25 border-indigo-400/30 text-indigo-300"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "من نحن" : "About Us" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: `w-3.5 h-3.5 ${isRTL ? "rotate-180" : ""}` })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											soundManager.playTap();
											if (props.onNavigatePage) props.onNavigatePage("methodology");
										},
										className: `px-4 py-2 rounded-xl border text-xs font-extrabold transition cursor-pointer flex items-center gap-1.5 ${isLight ? "bg-purple-50 hover:bg-purple-100 border-purple-200 text-purple-700" : "bg-purple-500/15 hover:bg-purple-500/25 border-purple-400/30 text-purple-300"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "المنهجية العلمية" : "Scientific Methodology" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											soundManager.playTap();
											if (props.onNavigatePage) props.onNavigatePage("faq");
										},
										className: `px-4 py-2 rounded-xl border text-xs font-extrabold transition cursor-pointer flex items-center gap-1.5 ${isLight ? "bg-sky-50 hover:bg-sky-100 border-sky-200 text-sky-700" : "bg-sky-500/15 hover:bg-sky-500/25 border-sky-400/30 text-sky-300"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleQuestionMark, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "الأسئلة الشائعة" : "FAQ" })]
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: `text-sm sm:text-base leading-relaxed md:leading-loose ${isLight ? "text-slate-600" : "text-slate-300"}`,
								children: isAr ? "مرآة القلوب منصة معرفية وتفاعلية تهدف إلى تعزيز الوعي الذاتي وتحسين فهم العلاقات الإنسانية من خلال مجموعة متكاملة من الاختبارات والتحليلات والمحتوى المتخصص. نسعى إلى تقديم تجربة عربية حديثة تساعد الأفراد على اكتشاف شخصياتهم وفهم أنماط التفكير والسلوك والتعرف إلى عوامل التوافق بين الأشخاص بطريقة مبسطة وعملية." : "Mirror of Hearts is an interactive knowledge platform dedicated to elevating self-awareness and deepening human connection through an integrated suite of tests, analytics, and specialized content. We deliver a modern Arabic experience empowering individuals to discover their personality, understand cognitive and behavioral patterns, and explore interpersonal compatibility in practical ways."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: `text-sm sm:text-base leading-relaxed md:leading-loose ${isLight ? "text-slate-600" : "text-slate-300"}`,
								children: isAr ? "تجمع المنصة بين المعرفة النفسية والتقنيات الحديثة لتوفير أدوات ومصادر معرفية تدعم النمو الشخصي واتخاذ قرارات أكثر وعياً في مختلف جوانب الحياة، مع الاعتماد على نماذج علمية مدروسة والالتزام الصارم بمبادئ الخصوصية وأخلاقيات البيانات." : "The platform fuses psychological expertise with modern technologies to provide knowledge resources and instruments supporting personal growth and mindful decision-making across all facets of life."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pt-4 border-t border-slate-200 dark:border-white/10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: `text-xs sm:text-sm font-black font-['Alexandria'] mb-3 ${isLight ? "text-slate-900" : "text-white"}`,
								children: isAr ? "لماذا مرآة القلوب؟" : "Why Mirror of Hearts?"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5",
								children: [
									{
										titleAr: "محتوى عربي متخصص",
										titleEn: "Specialized Arabic Content"
									},
									{
										titleAr: "أدوات تحليل تفاعلية",
										titleEn: "Interactive Analytical Tools"
									},
									{
										titleAr: "تجربة استخدام سهلة",
										titleEn: "Easy & Smooth User Experience"
									},
									{
										titleAr: "خصوصية وأمان",
										titleEn: "Privacy & Data Security"
									},
									{
										titleAr: "تطوير مستمر",
										titleEn: "Continuous Evolution"
									},
									{
										titleAr: "متوافق مع جميع الأجهزة",
										titleEn: "Compatible Across All Devices"
									}
								].map((point, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `p-3 rounded-2xl border flex items-center gap-2 ${isLight ? "bg-slate-50 border-slate-200/90 text-slate-800" : "bg-slate-950/60 border-white/10 text-slate-100"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `w-5 h-5 rounded-lg flex items-center justify-center shrink-0 font-bold text-xs ${isLight ? "bg-emerald-100 text-emerald-800" : "bg-emerald-500/20 text-emerald-300"}`,
										children: "✓"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-bold leading-snug",
										children: isAr ? point.titleAr : point.titleEn
									})]
								}, idx))
							})]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "site-sections-directory",
				dir: isRTL ? "rtl" : "ltr",
				className: "w-full max-w-5xl mx-auto px-4 sm:px-6 py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center mb-7 space-y-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `inline-flex items-center gap-2 px-3.5 py-1 rounded-full text-xs font-extrabold border ${isLight ? "bg-indigo-50 border-indigo-200 text-indigo-800" : "bg-indigo-500/15 border-indigo-400/30 text-indigo-200"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "دليل أقسام المنصة" : "Platform Sections Directory" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: `text-2xl sm:text-3xl md:text-4xl font-black font-['Alexandria'] ${isLight ? "text-slate-900" : "text-white"}`,
								children: isAr ? "أقسام الموقع" : "Platform Sections"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: `text-sm sm:text-base max-w-xl mx-auto ${isLight ? "text-slate-700" : "text-slate-300"}`,
								children: isAr ? "اختر القسم الذي يناسب اهتمامك للدخول مباشرة إلى أدواته ومحتواه المتخصص" : "Choose the section that matches your interest to enter its specialized tools and content"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `p-6 sm:p-8 rounded-3xl border transition-all duration-300 shadow-sm space-y-6 ${isLight ? "bg-white border-emerald-200/90 text-slate-900" : "bg-slate-900/75 border-emerald-500/25 text-white"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-white/10",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-600 text-white flex items-center justify-center shadow-md shrink-0",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "w-6 h-6" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-xl sm:text-2xl font-black font-['Alexandria']",
											children: isAr ? "المقالات المعرفية" : "Knowledge Articles"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: `text-xs sm:text-sm mt-0.5 ${isLight ? "text-slate-600" : "text-slate-300"}`,
											children: isAr ? "محتوى متخصص في الشخصية والعلاقات والتطوير الذاتي." : "Specialized content in personality, relationships, and self-growth."
										})] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											soundManager.playTap();
											if (props.onNavigatePage) props.onNavigatePage("articles");
											else if (props.onOpenArticles) props.onOpenArticles();
										},
										className: "px-5 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs sm:text-sm font-extrabold transition cursor-pointer flex items-center gap-2 shadow-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "دخول القسم" : "Enter Section" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: `w-4 h-4 ${isRTL ? "rotate-180" : ""}` })]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5",
									children: highlightedArticles.map((art) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
										onClick: () => {
											soundManager.playTap();
											try {
												sessionStorage.setItem("mirat_open_article_id", art.id);
											} catch {}
											if (props.onNavigatePage) props.onNavigatePage("articles");
											else if (props.onOpenArticles) props.onOpenArticles();
											window.location.hash = `#/articles/${art.id}`;
										},
										className: `group rounded-2xl border overflow-hidden transition-all duration-200 cursor-pointer flex flex-col justify-between hover:-translate-y-1 shadow-xs hover:shadow-lg ${isLight ? "bg-slate-50/70 hover:bg-white border-slate-200 hover:border-emerald-400" : "bg-slate-950/60 hover:bg-slate-900 border-white/10 hover:border-emerald-400/50"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative h-28 w-full bg-gradient-to-br from-emerald-900 via-teal-900 to-slate-900 p-4 flex flex-col justify-between overflow-hidden",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between gap-2 relative z-10",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-white/15 text-emerald-200 backdrop-blur-xs border border-white/15",
													children: isAr ? art.readTime : art.readTimeEn
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-3xl drop-shadow-md group-hover:scale-110 transition-transform",
													children: art.icon
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[11px] font-bold text-emerald-100/90 truncate relative z-10",
												children: isAr ? art.scientificFramework : art.scientificFrameworkEn
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-4 space-y-2.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
												className: `text-sm sm:text-base font-black font-['Alexandria'] leading-snug transition-colors ${isLight ? "text-slate-900 group-hover:text-emerald-700" : "text-white group-hover:text-emerald-300"}`,
												children: isAr ? art.title : art.titleEn
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: `text-xs leading-relaxed line-clamp-3 ${isLight ? "text-slate-600" : "text-slate-300"}`,
												children: isAr ? art.summary : art.summaryEn
											})]
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "px-4 pb-4 pt-2",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: `w-full py-2.5 px-3.5 rounded-xl text-xs font-extrabold flex items-center justify-between transition ${isLight ? "bg-emerald-50 group-hover:bg-emerald-600 text-emerald-800 group-hover:text-white border border-emerald-200 group-hover:border-emerald-600" : "bg-emerald-500/15 group-hover:bg-emerald-600 text-emerald-300 group-hover:text-white border border-emerald-500/30 group-hover:border-emerald-500"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "قراءة المقال" : "Read Article" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: `w-3.5 h-3.5 ${isRTL ? "rotate-180" : ""}` })]
											})
										})]
									}, art.id))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `p-6 sm:p-8 rounded-3xl border transition-all duration-300 shadow-sm space-y-6 ${isLight ? "bg-white border-cyan-200/90 text-slate-900" : "bg-slate-900/75 border-cyan-500/25 text-white"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-white/10",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 text-white flex items-center justify-center shadow-md shrink-0",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookMarked, { className: "w-6 h-6" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-xl sm:text-2xl font-black font-['Alexandria']",
											children: isAr ? "الروايات والقصص" : "Novels & Stories"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: `text-xs sm:text-sm mt-0.5 ${isLight ? "text-slate-600" : "text-slate-300"}`,
											children: isAr ? "قصص وتجارب إنسانية تحمل معاني ودروساً قيمة." : "Human stories and experiences carrying profound meaning and insight."
										})] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											soundManager.playTap();
											if (props.onNavigatePage) props.onNavigatePage("novels");
											else if (props.onOpenNovels) props.onOpenNovels();
										},
										className: "px-5 py-2.5 rounded-2xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs sm:text-sm font-extrabold transition cursor-pointer flex items-center gap-2 shadow-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "دخول القسم" : "Enter Section" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: `w-4 h-4 ${isRTL ? "rotate-180" : ""}` })]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5",
									children: highlightedNovels.map((novel) => {
										const displayTitle = !isAr && novel.titleEn ? novel.titleEn : novel.titleAr;
										const displaySubtitle = !isAr && novel.subtitleEn ? novel.subtitleEn : novel.subtitleAr;
										const displaySynopsis = !isAr && novel.synopsisEn ? novel.synopsisEn : novel.synopsisAr;
										const displayGenre = !isAr && novel.genreLabelEn ? novel.genreLabelEn : novel.genreLabelAr;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
											onClick: () => {
												soundManager.playTap();
												window.location.hash = `#/novels/${novel.id}`;
											},
											className: `group rounded-2xl border overflow-hidden transition-all duration-200 cursor-pointer flex flex-col justify-between hover:-translate-y-1 shadow-xs hover:shadow-lg ${isLight ? "bg-slate-50/70 hover:bg-white border-slate-200 hover:border-cyan-400" : "bg-slate-950/60 hover:bg-slate-900 border-white/10 hover:border-cyan-400/50"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "relative w-full h-44 bg-slate-950 border-b border-slate-800/80 overflow-hidden flex items-center justify-center p-1 group-hover:scale-[1.01] transition-transform",
												dangerouslySetInnerHTML: { __html: novel.coverIllustrationSvg }
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-4 space-y-2",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center justify-between gap-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[10px] font-bold px-2.5 py-0.5 rounded-full border",
															style: {
																borderColor: `${novel.genreBadgeColor}55`,
																backgroundColor: `${novel.genreBadgeColor}18`,
																color: novel.genreBadgeColor
															},
															children: displayGenre
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: `text-[11px] font-bold ${isLight ? "text-slate-600" : "text-slate-400"}`,
															children: [
																novel.chaptersCount || 0,
																" ",
																isAr ? "فصول" : "Chapters"
															]
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
														className: `text-base sm:text-lg font-black font-['Alexandria'] leading-snug transition-colors ${isLight ? "text-slate-900 group-hover:text-cyan-700" : "text-white group-hover:text-cyan-300"}`,
														children: displayTitle
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: `text-xs font-semibold ${isLight ? "text-cyan-800" : "text-cyan-300/90"}`,
														children: displaySubtitle
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: `text-xs leading-relaxed line-clamp-3 ${isLight ? "text-slate-600" : "text-slate-300"}`,
														children: displaySynopsis
													})
												]
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "px-4 pb-4 pt-2",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: `w-full py-2.5 px-3.5 rounded-xl text-xs font-extrabold flex items-center justify-between transition ${isLight ? "bg-cyan-50 group-hover:bg-cyan-600 text-cyan-800 group-hover:text-white border border-cyan-200 group-hover:border-cyan-600" : "bg-cyan-500/15 group-hover:bg-cyan-600 text-cyan-300 group-hover:text-white border border-cyan-500/30 group-hover:border-cyan-500"}`,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "قراءة الرواية" : "Read Novel" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: `w-3.5 h-3.5 ${isRTL ? "rotate-180" : ""}` })]
												})
											})]
										}, novel.id);
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5",
								children: interactiveToolCards.map((card) => {
									const IconComp = card.icon;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										onClick: card.action,
										className: `group p-6 rounded-3xl border transition-all duration-200 cursor-pointer flex flex-col justify-between space-y-4 hover:-translate-y-1 shadow-sm hover:shadow-xl ${isLight ? "bg-white hover:bg-slate-50/80 border-slate-200 hover:border-indigo-300" : "bg-slate-900/70 hover:bg-slate-800/80 border-white/10 hover:border-indigo-400/50"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-3",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: `w-12 h-12 rounded-2xl bg-gradient-to-tr ${card.color} text-white flex items-center justify-center shadow-md shrink-0`,
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconComp, { className: "w-6 h-6" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
													className: `text-lg sm:text-xl font-black font-['Alexandria'] ${isLight ? "text-slate-900 group-hover:text-indigo-600" : "text-white group-hover:text-indigo-300"} transition-colors`,
													children: isAr ? card.titleAr : card.titleEn
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: `text-xs sm:text-sm leading-relaxed ${isLight ? "text-slate-700" : "text-slate-300"}`,
													children: isAr ? card.descAr : card.descEn
												})
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: `pt-3 border-t flex items-center justify-between text-xs font-extrabold ${isLight ? "border-slate-200 text-indigo-700 group-hover:text-indigo-800" : "border-white/10 text-indigo-300 group-hover:text-indigo-200"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "دخول القسم" : "Enter Section" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: `w-3.5 h-3.5 transition-transform group-hover:translate-x-1 ${isRTL ? "rotate-180 group-hover:-translate-x-1" : ""}` })]
										})]
									}, card.id);
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TestScoringTrustBanner, { onNavigatePage: props.onNavigatePage })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "homepage-privacy-and-disclaimer",
				dir: isRTL ? "rtl" : "ltr",
				className: "w-full max-w-5xl mx-auto px-4 sm:px-6 pt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `p-6 sm:p-8 rounded-3xl border transition-all duration-300 shadow-sm space-y-5 ${isLight ? "bg-white border-emerald-200/90 text-slate-800" : "bg-slate-900/80 border-emerald-500/25 text-slate-100"}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-white/10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 border ${isLight ? "bg-emerald-50 border-emerald-200 text-emerald-700" : "bg-emerald-500/15 border-emerald-500/30 text-emerald-300"}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "w-6 h-6" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `text-[11px] font-extrabold uppercase tracking-wider block ${isLight ? "text-emerald-800" : "text-emerald-300"}`,
									children: isAr ? "سياسة الخصوصية والضمانات القانونية والعيادية" : "Privacy Policy & Legal/Clinical Safeguards"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: `text-lg sm:text-2xl font-black font-['Alexandria'] ${isLight ? "text-slate-900" : "text-white"}`,
									children: isAr ? "هندسة الخصوصية، مبدأ الحد الأدنى من جمع البيانات، وتشفير TLS 1.3" : "Privacy Engineering, Data Minimization & TLS 1.3 Encryption"
								})] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											soundManager.playTap();
											if (props.onNavigatePage) props.onNavigatePage("privacy");
										},
										className: "px-4 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white text-xs font-extrabold transition flex items-center gap-1.5 cursor-pointer shadow-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "سياسة الخصوصية الكاملة" : "Full Privacy Policy" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											soundManager.playTap();
											if (props.onNavigatePage) props.onNavigatePage("terms");
										},
										className: `px-3.5 py-2 rounded-xl border text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${isLight ? "bg-sky-50 hover:bg-sky-100 border-sky-200 text-sky-800" : "bg-sky-500/15 hover:bg-sky-500/25 border-sky-500/30 text-sky-300"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "شروط الاستخدام" : "Terms of Service" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											soundManager.playTap();
											if (props.onNavigatePage) props.onNavigatePage("disclaimer");
										},
										className: `px-3.5 py-2 rounded-xl border text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${isLight ? "bg-amber-50 hover:bg-amber-100 border-amber-200 text-amber-800" : "bg-amber-500/15 hover:bg-amber-500/25 border-amber-500/30 text-amber-300"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "إخلاء المسؤولية" : "Disclaimer" })]
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `p-5 rounded-2xl border space-y-4 ${isLight ? "bg-slate-50/90 border-slate-200" : "bg-white/[0.02] border-white/10"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs sm:text-sm leading-relaxed text-slate-700 dark:text-slate-300",
								children: isAr ? "تتبنى منصة «مرآة القلوب» فلسفة «الخصوصية بالتصميم» (Privacy by Design) وتطبق بصرامة مبدأ الحد الأدنى من جمع البيانات (Data Minimization Principle) المتوافق مع اللوائح العالمية لحماية البيانات (GDPR / CCPA). لا تطلب المنصة من الزوار أي وثائق رسمية، أو أرقام هواتف شخصية، أو عناوين سكنية، أو رفع صور شخصية لإجراء اختبارات التوافق والمقاييس النفسية؛ بل تكتفي بالمتغيرات الديموغرافية والسيكومترية الضرورية حصراً لتشغيل المعادلات التحليلية." : "Mirror of Hearts embraces \"Privacy by Design\" and enforces strict Data Minimization under GDPR/CCPA. We never ask for national IDs, telephone numbers, home addresses, or personal photographs; only minimal psychometric metrics strictly needed for scoring are processed."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 md:grid-cols-2 gap-3 text-xs sm:text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `p-3.5 rounded-xl border ${isLight ? "bg-emerald-50/70 border-emerald-200" : "bg-emerald-950/20 border-emerald-500/30"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "block mb-1 font-bold text-emerald-900 dark:text-emerald-300",
										children: isAr ? "بروتوكول التشفير القياسي TLS 1.3 و AES-256:" : "TLS 1.3 & AES-256 Encryption Standard:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-slate-600 dark:text-slate-300 text-xs leading-relaxed",
										children: isAr ? "تُؤمّن كافة حزم البيانات المتبادلة بين متصفح المستخدم وخوادم السحابة عبر بروتوكول التشفير القياسي الحديث (TLS 1.3 - Transport Layer Security) مع سرية التوجيه التام (Perfect Forward Secrecy)، مما يمنع أي اعتراض أو تنصت سيبراني، بالإضافة إلى إمكانية قفل النتائج محلياً برمز سري خاص (PIN Lock)." : "All network traffic between browser and cloud endpoints is secured using TLS 1.3 with Perfect Forward Secrecy and AES-256 encryption at rest, preventing any interception or cyber eavesdropping."
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `p-3.5 rounded-xl border ${isLight ? "bg-blue-50/70 border-blue-200" : "bg-blue-950/20 border-blue-500/30"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "block mb-1 font-bold text-blue-900 dark:text-blue-300",
										children: isAr ? "مبدأ الحد الأدنى من البيانات وعدم المشاركة التجارية:" : "Data Minimization & Zero Commercial Sharing:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-slate-600 dark:text-slate-300 text-xs leading-relaxed",
										children: isAr ? "تُعالج إجابات الاستبيانات لحظياً لتوليد التقرير التوافقي، ولا تقوم المنصة ببيع أو تأجير أو المتاجرة بأي بيانات سيكومترية أو شخصية مع سماسرة البيانات أو شركات الإعلانات الموجهة، مع منح المستخدم حق الحذف الفوري الكامل لسجله في أي وقت." : "Questionnaire responses are computed in real time to generate reports; we never sell, lease, or monetize personal data with data brokers or targeted advertising firms, with instant permanent erasure rights guaranteed."
									})]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `p-5 rounded-2xl border space-y-3 ${isLight ? "bg-amber-50/80 border-amber-300 text-slate-800" : "bg-amber-950/20 border-amber-500/35 text-slate-200"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: `text-base font-black font-['Alexandria'] flex items-center gap-2 ${isLight ? "text-amber-950" : "text-amber-300"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "w-5 h-5 text-amber-500 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "رابعاً: إخلاء المسؤولية العلمي والعيادي والقانوني (Scientific & Clinical Disclaimer)" : "Scientific, Clinical & Legal Disclaimer" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs sm:text-sm leading-relaxed",
									children: isAr ? "إن جميع المقاييس السيكومترية، وحاسبات التوافق الفكري والعاطفي، والدراسات البحثية، والمقالات العيادية القصصية المنشورة عبر منصة «مرآة القلوب» قُدّمت لأغراض التثقيف العلمي، وتعزيز الوعي الذاتي، وإثراء الحوار البناء بين الشركاء والمقبلين على الزواج. لا تُعد هذه الأدوات أو النتائج المستخلصة منها بأي حال من الأحوال بديلاً عن التشخيص الطبي النفسي أو التقييم الإكلينيكي المباشر وفق الدليل التشخيصي والإحصائي للاضطرابات النفسية (DSM-5-TR) أو التصنيف الدولي للأمراض (ICD-11)." : "All psychometric tools, compatibility assessments, and clinical narrative essays on Mirror of Hearts are presented strictly for psychoeducational awareness, self-discovery, and constructive dialogue. They never substitute for clinical psychiatric evaluation or medical diagnosis under DSM-5-TR or ICD-11."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: `text-xs sm:text-sm font-semibold leading-relaxed pt-1 ${isLight ? "text-amber-900" : "text-amber-200/90"}`,
									children: isAr ? "تؤكد إدارة المنصة أن التوافق الإنساني عملية ديناميكية حية تقوم على المسؤولية الأخلاقية، والمروءة، والاحترام المتبادل، والجهد الواعي المستمر من كلا الطرفين، وفي حالات الاضطرابات النفسية الحادة أو النزاعات الأسرية العميقة يُوصى دائماً بمراجعة الأخصائيين النفسيين والاستشاريين الأسريين المرخصين." : "Human compatibility is an evolving dynamic grounded in mutual chivalry, moral integrity, and shared conscious effort. In cases of acute psychological distress or deep marital conflict, consulting certified and licensed mental health clinicians is unconditionally advised."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `p-4 rounded-2xl border flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${isLight ? "bg-rose-50/70 border-rose-200" : "bg-rose-950/25 border-rose-500/35"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: `font-bold text-xs sm:text-sm flex items-center gap-1.5 ${isLight ? "text-rose-900" : "text-rose-200"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "w-4 h-4 text-rose-500 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "حق المستخدم في حذف بياناته نهائياً (تحكم فوري):" : "User’s Right to Permanently Delete Data (Instant Control):" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: `text-xs ${isLight ? "text-slate-700" : "text-slate-200"}`,
										children: isAr ? "اضغط هنا لمسح جميع بياناتك وسجل اختباراتك من المتصفح والسحابة نهائياً وبلا رجعة." : "Click here to permanently erase all your profile data and test history from browser and cloud storage."
									})]
								}),
								!confirmDelete && !deleteSuccess && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										soundManager.playTap();
										setConfirmDelete(true);
									},
									className: "px-4 py-2 rounded-xl bg-rose-700 hover:bg-rose-600 text-white font-bold text-xs transition cursor-pointer shrink-0 flex items-center gap-1.5 shadow-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "حذف بياناتي نهائياً" : "Delete My Data Permanently" })]
								}),
								deleteSuccess && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: `text-xs font-bold flex items-center gap-1.5 ${isLight ? "text-emerald-800" : "text-emerald-300"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "تم مسح جميع بياناتك نهائياً بنجاح." : "All data permanently erased." })]
								}),
								confirmDelete && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										disabled: isDeleting,
										onClick: handlePermanentDelete,
										className: "px-3.5 py-1.5 rounded-xl bg-rose-700 hover:bg-rose-600 disabled:bg-rose-800 disabled:opacity-80 text-white font-extrabold text-xs cursor-pointer",
										children: isDeleting ? isAr ? "جاري الحذف..." : "Deleting..." : isAr ? "تأكيد الحذف النهائي" : "Confirm Permanent Erase"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setConfirmDelete(false),
										className: `px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer ${isLight ? "bg-white border border-slate-300 text-slate-800" : "bg-slate-800 text-slate-200"}`,
										children: isAr ? "إلغاء" : "Cancel"
									})]
								})
							]
						})
					]
				})
			})
		]
	});
};
//#endregion
//#region src/utils/privacyLock.ts
var PIN_STORAGE_KEY = "miraa_privacy_pin";
var PIN_ENABLED_KEY = "miraa_privacy_pin_enabled";
function isPinLockEnabled() {
	try {
		const enabled = localStorage.getItem(PIN_ENABLED_KEY);
		const pin = localStorage.getItem(PIN_STORAGE_KEY);
		return enabled === "true" && Boolean(pin && pin.length === 4);
	} catch {
		return false;
	}
}
function getStoredPin() {
	try {
		return localStorage.getItem(PIN_STORAGE_KEY);
	} catch {
		return null;
	}
}
function setPinLock(pin) {
	if (!/^\d{4}$/.test(pin)) return false;
	try {
		localStorage.setItem(PIN_STORAGE_KEY, pin);
		localStorage.setItem(PIN_ENABLED_KEY, "true");
		return true;
	} catch {
		return false;
	}
}
function disablePinLock() {
	try {
		localStorage.setItem(PIN_ENABLED_KEY, "false");
	} catch {}
}
function removePinCompletely() {
	try {
		localStorage.removeItem(PIN_STORAGE_KEY);
		localStorage.removeItem(PIN_ENABLED_KEY);
	} catch {}
}
function verifyPin(inputPin) {
	const stored = getStoredPin();
	if (!stored) return true;
	return stored === inputPin;
}
//#endregion
//#region src/App.tsx
var Footer = (0, import_react.lazy)(() => __vitePreload(() => import("./Footer-B1WEgXZT.js").then((m) => ({ default: m.Footer })), __vite__mapDeps([13,1,3,4,7])));
var CookieConsentBanner = (0, import_react.lazy)(() => __vitePreload(() => import("./CookieConsentBanner-CLNOwW6R.js").then((m) => ({ default: m.CookieConsentBanner })), __vite__mapDeps([14,1,3,4,7])));
var ProfileStep = (0, import_react.lazy)(() => __vitePreload(() => import("./ProfileStep-DoTii6S9.js").then((m) => ({ default: m.ProfileStep })), __vite__mapDeps([15,1,3,4,7,16,17,18])));
var QuizStep = (0, import_react.lazy)(() => __vitePreload(() => import("./QuizStep-DzrUjl-A.js").then((m) => ({ default: m.QuizStep })), __vite__mapDeps([19,1,3,4,7,16,18])));
var AnalyzingStep = (0, import_react.lazy)(() => __vitePreload(() => import("./AnalyzingStep-C1krQmWk.js").then((m) => ({ default: m.AnalyzingStep })), __vite__mapDeps([20,1,3,4])));
var ResultStep = (0, import_react.lazy)(() => __vitePreload(() => import("./ResultStep-C_voiL5H.js").then((m) => ({ default: m.ResultStep })), __vite__mapDeps([21,1,3,4,7,22,23,9,0,10,17,24])));
var PrivacyLockScreen = (0, import_react.lazy)(() => __vitePreload(() => import("./PrivacyLockScreen-DjPgXCir.js").then((m) => ({ default: m.PrivacyLockScreen })), __vite__mapDeps([25,1,3,4,7])));
var AboutUsPage = (0, import_react.lazy)(() => __vitePreload(() => import("./AboutUsPage-DsKuH4sJ.js").then((m) => ({ default: m.AboutUsPage })), __vite__mapDeps([26,1,3,4,7,9,0,10,12])));
var PrivacyPolicyPage = (0, import_react.lazy)(() => __vitePreload(() => import("./PrivacyPolicyPage-BieME062.js").then((m) => ({ default: m.PrivacyPolicyPage })), __vite__mapDeps([27,1,3,4,7,9,0,10,12])));
var TermsOfServicePage = (0, import_react.lazy)(() => __vitePreload(() => import("./TermsOfServicePage-Cx7oGMfw.js").then((m) => ({ default: m.TermsOfServicePage })), __vite__mapDeps([28,1,3,4,7,9,0,10,12])));
var ContactUsPage = (0, import_react.lazy)(() => __vitePreload(() => import("./ContactUsPage-CY9ZKCVh.js").then((m) => ({ default: m.ContactUsPage })), __vite__mapDeps([29,1,3,4,7,30,10,0,12])));
var HowItWorksPage = (0, import_react.lazy)(() => __vitePreload(() => import("./HowItWorksPage-RIquWAxK.js").then((m) => ({ default: m.HowItWorksPage })), __vite__mapDeps([31,1,3,4,12])));
var FAQPage = (0, import_react.lazy)(() => __vitePreload(() => import("./FAQPage-B1lW0plU.js").then((m) => ({ default: m.FAQPage })), __vite__mapDeps([32,1,3,4,7,12])));
var SourcesMethodologyPage = (0, import_react.lazy)(() => __vitePreload(() => import("./SourcesMethodologyPage-DDr7UJxM.js").then((m) => ({ default: m.SourcesMethodologyPage })), __vite__mapDeps([33,1,3,4,12])));
var DisclaimerPage = (0, import_react.lazy)(() => __vitePreload(() => import("./DisclaimerPage-D53m9tE5.js").then((m) => ({ default: m.DisclaimerPage })), __vite__mapDeps([34,1,3,4,12])));
var NovelsDirectoryPage = (0, import_react.lazy)(() => __vitePreload(() => import("./NovelsDirectoryPage-QK3MnBFG.js").then((m) => ({ default: m.NovelsDirectoryPage })), __vite__mapDeps([35,1,3,4,7,36,10,0,12])));
var NovelDetailPage = (0, import_react.lazy)(() => __vitePreload(() => import("./NovelDetailPage-P_KICVFp.js").then((m) => ({ default: m.NovelDetailPage })), __vite__mapDeps([37,1,3,4,7,38,36,10,0,39,12])));
var ChapterReaderPage = (0, import_react.lazy)(() => __vitePreload(() => import("./ChapterReaderPage-BcubwB3s.js").then((m) => ({ default: m.ChapterReaderPage })), __vite__mapDeps([40,1,3,4,7,38,36,10,0,39,12])));
var AdminCMSPage = (0, import_react.lazy)(() => __vitePreload(() => import("./AdminCMSPage-BJn3kOdV.js").then((m) => ({ default: m.AdminCMSPage })), __vite__mapDeps([41,1,3,4,7,10,0,42,36,43,12])));
var PersonalityTestsPage = (0, import_react.lazy)(() => __vitePreload(() => import("./PersonalityTestsPage-CQFSIF3_.js").then((m) => ({ default: m.PersonalityTestsPage })), __vite__mapDeps([44,1,3,4,7,9,0,10,16,45,46,12])));
var ArticlesEncyclopediaPage = (0, import_react.lazy)(() => __vitePreload(() => import("./ArticlesEncyclopediaPage-BIVCrNL8.js").then((m) => ({ default: m.ArticlesEncyclopediaPage })), __vite__mapDeps([47,1,3,4,7,38,48,12])));
var HowTestResultsCalculatedPage = (0, import_react.lazy)(() => __vitePreload(() => import("./HowTestResultsCalculatedPage-BoBDe-m_.js").then((m) => ({ default: m.HowTestResultsCalculatedPage })), __vite__mapDeps([11,1,3,4,7,12])));
var LiveChatModal = (0, import_react.lazy)(() => __vitePreload(() => import("./LiveChatModal-ClazBySE.js").then((m) => ({ default: m.LiveChatModal })), __vite__mapDeps([49,1,3,4,7,50])));
var BlindDateShowModal = (0, import_react.lazy)(() => __vitePreload(() => import("./BlindDateShowModal-CVtxxKDk.js").then((m) => ({ default: m.BlindDateShowModal })), __vite__mapDeps([51,1,3,4,7,22,50])));
var DomainHostingModal = (0, import_react.lazy)(() => __vitePreload(() => import("./DomainHostingModal-DeKFrlyL.js").then((m) => ({ default: m.DomainHostingModal })), __vite__mapDeps([52,1,3,4,7,10,0,42])));
var WebsiteSectionsModal = (0, import_react.lazy)(() => __vitePreload(() => import("./WebsiteSectionsModal-5QTc4bht.js").then((m) => ({ default: m.WebsiteSectionsModal })), __vite__mapDeps([53,1,3,4,7,30,10,0])));
var AuthModal = (0, import_react.lazy)(() => __vitePreload(() => import("./AuthModal-PLDF1Wxj.js").then((m) => ({ default: m.AuthModal })), __vite__mapDeps([54,1,3,4,7])));
var SavedResultsHistoryModal = (0, import_react.lazy)(() => __vitePreload(() => import("./SavedResultsHistoryModal-C_QMoqWR.js").then((m) => ({ default: m.SavedResultsHistoryModal })), __vite__mapDeps([55,1,3,4,7,9,0,10,56])));
var PsychologyTestsModal = (0, import_react.lazy)(() => __vitePreload(() => import("./PsychologyTestsModal-Ch9cgc-y.js").then((m) => ({ default: m.PsychologyTestsModal })), __vite__mapDeps([45,1,3,4,7,9,0,10,16,46])));
var UserProfileDashboard = (0, import_react.lazy)(() => __vitePreload(() => import("./UserProfileDashboard-DcTBsy1i.js").then((m) => ({ default: m.UserProfileDashboard })), __vite__mapDeps([57,1,3,4,7,9,0,10,46,24,56])));
var CoupleInviteModal = (0, import_react.lazy)(() => __vitePreload(() => import("./CoupleInviteModal-Dhh28oj6.js").then((m) => ({ default: m.CoupleInviteModal })), __vite__mapDeps([58,1,3,4,7,23,9,0,10])));
var ArticlesSectionModal = (0, import_react.lazy)(() => __vitePreload(() => import("./ArticlesSectionModal-Bp22iDqZ.js").then((m) => ({ default: m.ArticlesSectionModal })), __vite__mapDeps([59,1,3,4,7,38,48])));
var NovelsSectionModal = (0, import_react.lazy)(() => __vitePreload(() => import("./NovelsSectionModal-xoD9fH9K.js").then((m) => ({ default: m.NovelsSectionModal })), __vite__mapDeps([60,1,3,4,7,36,10,0,39,43])));
var IntelligenceTestModal = (0, import_react.lazy)(() => __vitePreload(() => import("./IntelligenceTestModal-CZZJt6S0.js").then((m) => ({ default: m.IntelligenceTestModal })), __vite__mapDeps([61,1,3,4,7,10,0,9,16])));
var OnboardingWizardModal = (0, import_react.lazy)(() => __vitePreload(() => import("./OnboardingWizardModal-BX7AZI6s.js").then((m) => ({ default: m.OnboardingWizardModal })), __vite__mapDeps([62,1,3,4,7])));
var LegalModal = (0, import_react.lazy)(() => __vitePreload(() => import("./LegalModal-DHwj3oUy.js").then((m) => ({ default: m.LegalModal })), __vite__mapDeps([63,1,3,4,7,9,0,10])));
var ContactFeedbackModal = (0, import_react.lazy)(() => __vitePreload(() => import("./ContactFeedbackModal-BRox7c5T.js").then((m) => ({ default: m.ContactFeedbackModal })), __vite__mapDeps([64,1,3,4,7,30,10,0])));
var AnalyticsDashboardModal = (0, import_react.lazy)(() => __vitePreload(() => import("./AnalyticsDashboardModal-DXzyIE9R.js").then((m) => ({ default: m.AnalyticsDashboardModal })), __vite__mapDeps([65,1,3,4,7,66,30,10,0])));
var BookClubCommunityModal = (0, import_react.lazy)(() => __vitePreload(() => import("./BookClubCommunityModal-p6TiFTzK.js").then((m) => ({ default: m.BookClubCommunityModal })), __vite__mapDeps([67,1,3,4,7,10,0])));
function SectionLoadingFallback() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full py-16 flex flex-col items-center justify-center gap-3 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-10 h-10 rounded-full border-3 border-rose-500/30 border-t-rose-500 animate-spin" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs font-bold text-slate-400",
			children: "جاري تحميل القسم..."
		})]
	});
}
function AppContent() {
	const { direction, isRTL } = useLanguage();
	const { user, isOwner } = useAuth();
	const [theme] = useAppTheme();
	const [step, setStep] = (0, import_react.useState)("profile");
	const [profile, setProfile] = (0, import_react.useState)(null);
	const [answers, setAnswers] = (0, import_react.useState)({});
	const [quizQuestions, setQuizQuestions] = (0, import_react.useState)([]);
	const [result, setResult] = (0, import_react.useState)(null);
	const [isRegeneratingImage, setIsRegeneratingImage] = (0, import_react.useState)(false);
	const [isResultUnlocked, setIsResultUnlocked] = (0, import_react.useState)(false);
	const [isLiveChatOpen, setIsLiveChatOpen] = (0, import_react.useState)(false);
	const [isBlindDateOpen, setIsBlindDateOpen] = (0, import_react.useState)(false);
	const [isDomainHostingOpen, setIsDomainHostingOpen] = (0, import_react.useState)(false);
	const [isWebsiteSectionsOpen, setIsWebsiteSectionsOpen] = (0, import_react.useState)(false);
	const [websiteSectionTab, setWebsiteSectionTab] = (0, import_react.useState)("about");
	const [isArticlesModalOpen, setIsArticlesModalOpen] = (0, import_react.useState)(false);
	const [isNovelsModalOpen, setIsNovelsModalOpen] = (0, import_react.useState)(false);
	const [isAuthModalOpen, setIsAuthModalOpen] = (0, import_react.useState)(false);
	const [isHistoryModalOpen, setIsHistoryModalOpen] = (0, import_react.useState)(false);
	const [isPsychologyTestsOpen, setIsPsychologyTestsOpen] = (0, import_react.useState)(false);
	const [isIntelligenceModalOpen, setIsIntelligenceModalOpen] = (0, import_react.useState)(false);
	const [isUserProfileOpen, setIsUserProfileOpen] = (0, import_react.useState)(false);
	const [userProfileDashboardTab, setUserProfileDashboardTab] = (0, import_react.useState)("overview");
	const [isCoupleInviteOpen, setIsCoupleInviteOpen] = (0, import_react.useState)(false);
	const [isOnboardingWizardOpen, setIsOnboardingWizardOpen] = (0, import_react.useState)(false);
	const [isLegalModalOpen, setIsLegalModalOpen] = (0, import_react.useState)(false);
	const [legalModalTab, setLegalModalTab] = (0, import_react.useState)("privacy");
	const [isContactFeedbackOpen, setIsContactFeedbackOpen] = (0, import_react.useState)(false);
	const [isAnalyticsOpen, setIsAnalyticsOpen] = (0, import_react.useState)(false);
	const [isBookClubOpen, setIsBookClubOpen] = (0, import_react.useState)(false);
	const [savedTestsCount, setSavedTestsCount] = (0, import_react.useState)(0);
	const [currentPage, setCurrentPage] = (0, import_react.useState)("home");
	const [activeNovelId, setActiveNovelId] = (0, import_react.useState)("room_104_cipher");
	const [activeChapterIndex, setActiveChapterIndex] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const handleRouteChange = () => {
			const rawHash = window.location.hash.toLowerCase().replace("#/", "").replace("#", "").trim();
			const rawPath = window.location.pathname.toLowerCase().replace(/^\/+|\/+$/g, "").trim();
			const queryPage = (new URLSearchParams(window.location.search).get("page") || "").toLowerCase().trim();
			const parts = (rawHash || queryPage || rawPath).split("/");
			const section = parts[0];
			if (section === "about" || section === "about-us") setCurrentPage("about");
			else if (section === "how-it-works" || section === "howitworks") setCurrentPage("how-it-works");
			else if (section === "privacy" || section === "privacy-policy" || section === "privacypolicy") setCurrentPage("privacy");
			else if (section === "terms" || section === "terms-of-service" || section === "tos") setCurrentPage("terms");
			else if (section === "contact" || section === "contact-us") setCurrentPage("contact");
			else if (section === "faq") setCurrentPage("faq");
			else if (section === "methodology" || section === "sources") setCurrentPage("methodology");
			else if (section === "disclaimer") setCurrentPage("disclaimer");
			else if (section === "admin" || section === "admin-cms") setCurrentPage("admin-cms");
			else if (section === "articles" || section === "research") {
				if (parts[1]) try {
					sessionStorage.setItem("mirat_open_article_id", decodeURIComponent(parts[1]));
				} catch {}
				setCurrentPage("articles");
			} else if (section === "community" || section === "book-club" || section === "salon") {
				setIsBookClubOpen(true);
				setCurrentPage("home");
			} else if (section === "how-results-are-calculated" || section === "scoring-guide" || section === "how-tests-work" || section === "scoring") setCurrentPage("how-results-are-calculated");
			else if (section === "personality-tests" || section === "personality" || section === "mbti" || section === "big-five") setCurrentPage("personality-tests");
			else if (section === "compatibility" || section === "partner-detector" || section === "partner") setCurrentPage("compatibility");
			else if (section === "novels") {
				if (parts[1]) {
					setActiveNovelId(parts[1]);
					if (parts[2] === "chapter" && parts[3]) {
						const chNum = parseInt(parts[3], 10);
						setActiveChapterIndex(Math.max(0, (isNaN(chNum) ? 1 : chNum) - 1));
						setCurrentPage("chapter-reader");
					} else setCurrentPage("novel-detail");
				} else setCurrentPage("novels");
			} else setCurrentPage("home");
		};
		handleRouteChange();
		window.addEventListener("hashchange", handleRouteChange);
		window.addEventListener("popstate", handleRouteChange);
		return () => {
			window.removeEventListener("hashchange", handleRouteChange);
			window.removeEventListener("popstate", handleRouteChange);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (currentPage === "compatibility" && quizQuestions.length === 0) __vitePreload(() => import("./data-compatibility-s3wwWF9Q.js").then((n) => n.d).then((m) => {
			setQuizQuestions(m.QUIZ_QUESTIONS);
		}), __vite__mapDeps([1]));
	}, [currentPage, quizQuestions.length]);
	const handleNavigatePage = (page) => {
		soundManager.playTap();
		const validPages = [
			"about",
			"how-it-works",
			"privacy",
			"terms",
			"contact",
			"faq",
			"methodology",
			"disclaimer",
			"novels",
			"admin-cms",
			"personality-tests",
			"articles",
			"compatibility",
			"how-results-are-calculated"
		];
		if (page === "community" || page === "book-club" || page === "salon") {
			setIsBookClubOpen(true);
			return;
		}
		if (validPages.includes(page)) {
			setCurrentPage(page);
			window.location.hash = `#/${page}`;
		} else {
			setCurrentPage("home");
			if (window.location.hash) history.pushState(null, "", window.location.pathname);
		}
		window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
	};
	const handleSelectNovel = (novelId) => {
		soundManager.playTap();
		setActiveNovelId(novelId);
		setCurrentPage("novel-detail");
		window.location.hash = `#/novels/${novelId}`;
		window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
	};
	const handleReadChapter = (novelId, chapterIdx) => {
		soundManager.playTap();
		setActiveNovelId(novelId);
		setActiveChapterIndex(chapterIdx);
		setCurrentPage("chapter-reader");
		window.location.hash = `#/novels/${novelId}/chapter/${chapterIdx + 1}`;
		window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
	};
	(0, import_react.useEffect)(() => {
		let isMounted = true;
		try {
			const rawProfile = localStorage.getItem("mirat_persistent_user_profile");
			if (rawProfile) {
				const parsedProfile = JSON.parse(rawProfile);
				if (parsedProfile && typeof parsedProfile === "object") setProfile((prev) => prev || parsedProfile);
			}
			const rawSaved = localStorage.getItem("mirat_saved_results_local_v1");
			const rawUnified = localStorage.getItem("mirat_unified_test_history_v2");
			const savedLen = rawSaved ? JSON.parse(rawSaved)?.length || 0 : 0;
			const unifiedLen = rawUnified ? JSON.parse(rawUnified)?.length || 0 : 0;
			setSavedTestsCount(Math.max(savedLen, unifiedLen));
		} catch {}
		const ua = typeof navigator !== "undefined" && navigator.userAgent || "";
		if (Boolean(typeof navigator !== "undefined" && navigator.webdriver || /Chrome-Lighthouse|PageSpeed|PTST|HeadlessChrome|Googlebot|InspectionTool|GTmetrix/i.test(ua))) return;
		const timer = setTimeout(async () => {
			if (!isMounted) return;
			try {
				const { trackSiteVisit } = await __vitePreload(async () => {
					const { trackSiteVisit } = await import("./analyticsService-BLTJzcv7.js");
					return { trackSiteVisit };
				}, __vite__mapDeps([66,3,1]));
				if (!isMounted) return;
				trackSiteVisit();
				const hasCloudFlag = localStorage.getItem("mirat_has_cloud_data") === "1";
				if (user || hasCloudFlag) {
					const historySvc = await __vitePreload(() => import("./userHistoryService-6N9Zh8ed.js").then((n) => n.p), __vite__mapDeps([9,1,3,0,10]));
					if (!isMounted) return;
					const [session, savedResults, unifiedHistory] = await Promise.all([
						historySvc.loadPersistentUserSession(user),
						historySvc.fetchUserSavedResults(user),
						historySvc.fetchUnifiedTestHistory(user)
					]);
					if (!isMounted) return;
					if (session.profile) setProfile((prev) => prev || session.profile);
					const totalSaved = Math.max(savedResults?.length || 0, unifiedHistory?.length || 0);
					setSavedTestsCount(totalSaved);
				}
			} catch {}
		}, 1500);
		return () => {
			isMounted = false;
			clearTimeout(timer);
		};
	}, [user]);
	const handleOpenContactFeedback = () => {
		soundManager.playTap();
		setIsContactFeedbackOpen(true);
	};
	const handleOpenAnalytics = () => {
		if (!isOwner) return;
		soundManager.playTap();
		setIsAnalyticsOpen(true);
	};
	const handleOpenPrivacyPolicy = () => {
		soundManager.playTap();
		setLegalModalTab("privacy");
		setIsLegalModalOpen(true);
	};
	const handleOpenTermsOfService = () => {
		soundManager.playTap();
		setLegalModalTab("terms");
		setIsLegalModalOpen(true);
	};
	const handleOpenArticles = () => {
		soundManager.playTap();
		setIsArticlesModalOpen(true);
	};
	const handleOpenNovels = () => {
		soundManager.playTap();
		setIsNovelsModalOpen(true);
	};
	const handleOpenIntelligenceTests = () => {
		soundManager.playTap();
		setIsIntelligenceModalOpen(true);
	};
	const handleOpenOnboardingWizard = () => {
		soundManager.playTap();
		setIsOnboardingWizardOpen(true);
	};
	const handleOnboardingSelectDestination = (goal) => {
		setIsOnboardingWizardOpen(false);
		if (goal === "partner_compatibility") {
			handleNavigatePage("compatibility");
			if (step !== "profile") handleReset();
		} else if (goal === "intelligence_test") setIsIntelligenceModalOpen(true);
		else if (goal === "personality_assessment") setIsPsychologyTestsOpen(true);
		else if (goal === "blind_date") setIsBlindDateOpen(true);
		else if (goal === "articles_science") setIsArticlesModalOpen(true);
		else if (goal === "novels_investigation") setIsNovelsModalOpen(true);
	};
	const handleOpenUserDashboard = (tab = "overview") => {
		soundManager.playTap();
		setUserProfileDashboardTab(tab);
		setIsUserProfileOpen(true);
	};
	const handleLoadHistoricalResult = (savedProfile, savedResult) => {
		soundManager.playResultReveal();
		setProfile(savedProfile);
		setResult(savedResult);
		setIsResultUnlocked(true);
		setStep("result");
		setCurrentPage("compatibility");
		window.location.hash = "#/compatibility";
		window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
	};
	const handleOpenWebsiteSection = (tab = "about") => {
		soundManager.playTap();
		setWebsiteSectionTab(tab);
		setIsWebsiteSectionsOpen(true);
	};
	const handleStart = async (userProfile) => {
		soundManager.playPageTransition();
		setProfile(userProfile);
		__vitePreload(() => import("./userHistoryService-6N9Zh8ed.js").then((n) => n.p).then((m) => m.savePersistentUserProfile(userProfile, user)), __vite__mapDeps([9,1,3,0,10]));
		if (quizQuestions.length === 0) {
			const m = await __vitePreload(() => import("./data-compatibility-s3wwWF9Q.js").then((n) => n.d), __vite__mapDeps([1]));
			setQuizQuestions(m.QUIZ_QUESTIONS);
		}
		setStep("quiz");
		window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
	};
	const handleQuizComplete = async (quizAnswers, quizDetectedLocation) => {
		if (!profile) return;
		soundManager.playPageTransition();
		setAnswers(quizAnswers);
		setStep("analyzing");
		window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
		const startTime = Date.now();
		const [{ detectUserLocationAndNationality, getNationalityEntryByCountry }, { getRealisticPortrait }, { calculateRealCompatibility }] = await Promise.all([
			__vitePreload(() => import("./locationNationalityDetector-u5K3h3nb.js"), []),
			__vitePreload(() => import("./portraits-C-n5yeJZ.js"), []),
			__vitePreload(() => import("./realScoringEngine-B-6Eyb1e.js"), [])
		]);
		const resolvedLocation = quizDetectedLocation || await detectUserLocationAndNationality({
			partnerGender: profile.partnerGender,
			fallbackCountry: profile.country,
			answers: quizAnswers
		}) || getNationalityEntryByCountry(profile.country, profile.partnerGender);
		const activeProfile = {
			...profile,
			country: resolvedLocation.countryNameAr || profile.country,
			ethnicity: resolvedLocation.ethnicityTag || profile.ethnicity,
			detectedCountryCode: resolvedLocation.countryCode,
			detectedNationalityAr: resolvedLocation.nationalityAr,
			detectedNationalityEn: resolvedLocation.nationalityEn,
			detectedEthnicTraitsPrompt: resolvedLocation.ethnicFacialTraitsPromptEn,
			detectedEthnicTraitsAr: resolvedLocation.ethnicFacialTraitsDescriptionAr,
			isLocationAutoDetected: true
		};
		setProfile(activeProfile);
		const historySvc = await __vitePreload(() => import("./userHistoryService-6N9Zh8ed.js").then((n) => n.p), __vite__mapDeps([9,1,3,0,10]));
		historySvc.savePersistentUserProfile(activeProfile, user);
		let finalImageUrl = getRealisticPortrait(activeProfile.ethnicity, activeProfile.partnerGender, activeProfile.userAge, activeProfile.country).url;
		const calculatedScoring = calculateRealCompatibility(activeProfile, quizAnswers);
		try {
			const json = await (await fetch("/api/analyze-partner", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					userGender: activeProfile.userGender,
					partnerGender: activeProfile.partnerGender,
					userAge: activeProfile.userAge,
					userName: activeProfile.userName,
					country: activeProfile.country,
					ethnicity: activeProfile.ethnicity,
					educationLevel: activeProfile.educationLevel,
					lifestyleOutlook: activeProfile.lifestyleOutlook,
					partnerFeaturesPreference: activeProfile.partnerFeaturesPreference,
					detectedCountryCode: activeProfile.detectedCountryCode,
					detectedNationalityAr: activeProfile.detectedNationalityAr,
					detectedNationalityEn: activeProfile.detectedNationalityEn,
					detectedEthnicTraitsPrompt: activeProfile.detectedEthnicTraitsPrompt,
					detectedEthnicTraitsAr: activeProfile.detectedEthnicTraitsAr,
					answers: quizAnswers
				})
			})).json();
			let analysisData;
			if (json && json.data) {
				analysisData = json.data;
				analysisData.compatibilityScore = calculatedScoring.compatibilityScore;
				analysisData.intellectualScore = calculatedScoring.intellectualScore;
				analysisData.sociologicalScore = calculatedScoring.sociologicalScore;
				analysisData.emotionalScore = calculatedScoring.emotionalScore;
				analysisData.lifestyleScore = calculatedScoring.lifestyleScore;
				analysisData.partnerTraits = calculatedScoring.partnerTraits;
				analysisData.scoringBreakdown = json.data.scoringBreakdown || calculatedScoring;
				analysisData.isRealCalculated = true;
				analysisData.detectedNationalityAr = analysisData.detectedNationalityAr || activeProfile.detectedNationalityAr;
				analysisData.detectedEthnicTraitsAr = analysisData.detectedEthnicTraitsAr || activeProfile.detectedEthnicTraitsAr;
			} else throw new Error("Analysis payload empty");
			try {
				const imgJson = await (await fetch("/api/generate-image", {
					method: "POST",
					headers: { "Content-Type": "application/json" },
					body: JSON.stringify({
						prompt: analysisData.imagePrompt,
						partnerGender: activeProfile.partnerGender,
						userAge: activeProfile.userAge,
						country: activeProfile.country,
						ethnicity: activeProfile.ethnicity,
						educationLevel: activeProfile.educationLevel,
						lifestyleOutlook: activeProfile.lifestyleOutlook,
						partnerFeaturesPreference: activeProfile.partnerFeaturesPreference,
						detectedCountryCode: activeProfile.detectedCountryCode,
						detectedNationalityAr: activeProfile.detectedNationalityAr,
						detectedNationalityEn: activeProfile.detectedNationalityEn,
						detectedEthnicTraitsPrompt: activeProfile.detectedEthnicTraitsPrompt
					})
				})).json();
				if (imgJson && imgJson.success && imgJson.imageUrl) finalImageUrl = imgJson.imageUrl;
			} catch (imgErr) {
				console.warn("AI image generation fallback triggered:", imgErr);
			}
			analysisData.imageUrl = finalImageUrl;
			historySvc.saveTestResultToHistory(user, activeProfile, analysisData).then(() => {
				setSavedTestsCount((prev) => prev + 1);
			});
			const elapsed = Date.now() - startTime;
			const delayNeeded = Math.max(0, 3200 - elapsed);
			setTimeout(() => {
				setResult(analysisData);
				setIsResultUnlocked(!isPinLockEnabled());
				setStep("result");
				soundManager.playResultReveal();
				window.scrollTo({
					top: 0,
					behavior: "smooth"
				});
			}, delayNeeded);
		} catch (err) {
			console.error("Quiz analysis error:", err);
			const fallbackResult = {
				proposedPartnerName: activeProfile.partnerGender === "female" ? "نـورة" : "فيـصل",
				nameMeaning: activeProfile.partnerGender === "female" ? "مشتق من النور والضياء؛ يعبر عن شخصية تجمع بين الرزانة الأصيلة، الإشراق، والذكاء الاجتماعي المحبوب." : "السيف القاطع الصارم في الحق؛ يعبر عن الشهامة، الوقار والقدرة على حماية واحتواء شريكته بحكمة.",
				personalityArchetype: "الروح الواعية والمفكر الاجتماعي المتزن",
				partnerArchetype: activeProfile.partnerGender === "female" ? "سيدة الرقي والهدوء الفكري الملهم" : "السند الحكيم والقيادي النبيل",
				compatibilityScore: calculatedScoring.compatibilityScore,
				intellectualScore: calculatedScoring.intellectualScore,
				sociologicalScore: calculatedScoring.sociologicalScore,
				emotionalScore: calculatedScoring.emotionalScore,
				lifestyleScore: calculatedScoring.lifestyleScore,
				detailedMatchReason: `بناءً على مقاييس التوافق الفكري والاجتماعي المحسوبة رياضياً بدقة خوارزمية (${calculatedScoring.compatibilityScore}%)، شخصيتك تمنحه الأمان والشغف، وشخصيته القادمة من أصول (${activeProfile.detectedNationalityAr || activeProfile.ethnicity}) في (${activeProfile.country}) تمنحك الدفء والاحتواء الصادق في كل تفصيلة.`,
				intellectualSynergy: `تتميز العلاقة بتناغم ذهني بنسبة (${calculatedScoring.intellectualScore}%)؛ حيث يتشارك الطرفان أسلوب التفكير العقلاني وتبادل الآراء بإصغاء ناضج مع رؤية مشتركة لبناء المستقبل.`,
				socialHarmony: `تحظى العلاقة بركيزة أسرية متينة بنسبة (${calculatedScoring.sociologicalScore}%) تتوافق مع عادات وتقاليد (${activeProfile.country}) الأصيلة، مع صيانة تامة لخصوصية واستقلال البيت الزوجي.`,
				attachmentStyle: "ارتباط آمن وتشاركي (Secure Attachment)",
				partnerTraits: calculatedScoring.partnerTraits,
				loveLanguage: "الوقت النوعي الخاص وكلمات التقدير المتبادلة",
				visualDescription: activeProfile.detectedEthnicTraitsAr || `ملامح أصيلة ووسيمة تعكس سحر (${activeProfile.ethnicity}) في (${activeProfile.country})، عينان دافئتان تنطقان بالصدق وابتسامة مريحة تلامس الروح.`,
				romanticAdvice: "التناغم الفكري بينكما كنز؛ حافظا دائماً على جلسات الحوار الهادئ دون هواتف وشاركا القرارات اليومية بروح الفريق.",
				partnerVibeQuote: activeProfile.partnerGender === "female" ? "«في عينيكِ وجدتُ وطناً وسكينة تغنيني عن العالم أجمع»" : "«معك فقط، أشعر أن الحياة تسير في اتجاهها الصحيح وأن قلبي في أمان تام»",
				imageUrl: finalImageUrl,
				scoringBreakdown: calculatedScoring,
				isRealCalculated: true,
				detectedNationalityAr: activeProfile.detectedNationalityAr,
				detectedEthnicTraitsAr: activeProfile.detectedEthnicTraitsAr
			};
			historySvc.saveTestResultToHistory(user, activeProfile, fallbackResult).then(() => {
				setSavedTestsCount((prev) => prev + 1);
			});
			setTimeout(() => {
				setResult(fallbackResult);
				setIsResultUnlocked(!isPinLockEnabled());
				setStep("result");
				soundManager.playResultReveal();
				window.scrollTo({
					top: 0,
					behavior: "smooth"
				});
			}, 2500);
		}
	};
	const handleRegenerateImage = async () => {
		if (!profile || !result) return;
		setIsRegeneratingImage(true);
		try {
			const { getRealisticPortrait } = await __vitePreload(async () => {
				const { getRealisticPortrait } = await import("./portraits-C-n5yeJZ.js");
				return { getRealisticPortrait };
			}, []);
			const curated = getRealisticPortrait(profile.ethnicity, profile.partnerGender, profile.userAge, profile.country);
			const json = await (await fetch("/api/generate-image", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					prompt: result.imagePrompt ? `${result.imagePrompt}, different candid angle, natural expression` : void 0,
					partnerGender: profile.partnerGender,
					userAge: profile.userAge,
					country: profile.country,
					ethnicity: profile.ethnicity,
					educationLevel: profile.educationLevel,
					lifestyleOutlook: profile.lifestyleOutlook,
					partnerFeaturesPreference: profile.partnerFeaturesPreference,
					detectedCountryCode: profile.detectedCountryCode,
					detectedNationalityAr: profile.detectedNationalityAr,
					detectedNationalityEn: profile.detectedNationalityEn,
					detectedEthnicTraitsPrompt: profile.detectedEthnicTraitsPrompt
				})
			})).json();
			if (json && json.success && json.imageUrl) {
				setResult({
					...result,
					imageUrl: json.imageUrl
				});
				setIsRegeneratingImage(false);
				return;
			}
			setResult({
				...result,
				imageUrl: curated.url
			});
		} catch {} finally {
			setIsRegeneratingImage(false);
		}
	};
	const handleReset = () => {
		soundManager.playPageTransition();
		setStep("profile");
		setProfile(null);
		setAnswers({});
		setResult(null);
		setIsResultUnlocked(false);
		window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		dir: direction,
		className: `min-h-screen ${theme === "light" ? "bg-white text-[#0f172a]" : "bg-[#0a0d14] text-[#f8fafc]"} flex flex-col selection:bg-blue-600 selection:text-white overflow-x-hidden transition-colors duration-300 ${isRTL ? "font-['Alexandria','Tajawal',sans-serif]" : "font-sans"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navbar, {
				onReset: handleReset,
				showReset: step !== "profile",
				onOpenLiveChat: () => setIsLiveChatOpen(true),
				onOpenBlindDate: () => setIsBlindDateOpen(true),
				onOpenDomainHosting: isOwner ? () => setIsDomainHostingOpen(true) : void 0,
				onOpenWebsiteSection: handleOpenWebsiteSection,
				onOpenAuth: () => setIsAuthModalOpen(true),
				onOpenHistory: () => handleOpenUserDashboard("history"),
				onOpenPsychologyTests: () => setIsPsychologyTestsOpen(true),
				onOpenIntelligenceTests: handleOpenIntelligenceTests,
				onOpenOnboardingWizard: handleOpenOnboardingWizard,
				onOpenUserDashboard: () => handleOpenUserDashboard("overview"),
				onOpenCoupleInvite: () => setIsCoupleInviteOpen(true),
				onOpenArticles: handleOpenArticles,
				onOpenNovels: handleOpenNovels,
				onOpenContactFeedback: handleOpenContactFeedback,
				onOpenAnalytics: isOwner ? handleOpenAnalytics : void 0,
				onNavigatePage: handleNavigatePage,
				onDataDeleted: () => setSavedTestsCount(0),
				currentPage
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "flex-1 flex flex-col justify-center py-4 relative",
				children: [currentPage === "home" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomePage, {
					onStart: (prof) => {
						handleStart(prof);
						setCurrentPage("compatibility");
						window.location.hash = "#/compatibility";
					},
					initialProfile: profile,
					savedTestsCount,
					onOpenSavedHistory: () => setIsHistoryModalOpen(true),
					onOpenBlindDate: () => setIsBlindDateOpen(true),
					onOpenDomainHosting: isOwner ? () => setIsDomainHostingOpen(true) : void 0,
					onOpenWebsiteSection: handleOpenWebsiteSection,
					onOpenPsychologyTests: () => setIsPsychologyTestsOpen(true),
					onOpenIntelligenceTests: handleOpenIntelligenceTests,
					onOpenUserDashboard: () => handleOpenUserDashboard("overview"),
					onOpenArticles: handleOpenArticles,
					onOpenNovels: handleOpenNovels,
					onOpenContactFeedback: handleOpenContactFeedback,
					onOpenCommunity: () => setIsBookClubOpen(true),
					onNavigatePage: handleNavigatePage
				}), currentPage !== "home" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_react.Suspense, {
					fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLoadingFallback, {}),
					children: [
						currentPage === "about" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AboutUsPage, {
							onBackToHome: () => handleNavigatePage("home"),
							onNavigatePage: handleNavigatePage,
							onStartQuiz: () => {
								handleReset();
								handleNavigatePage("compatibility");
							},
							onOpenPsychologyTests: () => setIsPsychologyTestsOpen(true),
							onOpenIntelligenceTests: handleOpenIntelligenceTests,
							onOpenArticles: handleOpenArticles,
							onOpenNovels: handleOpenNovels
						}),
						currentPage === "how-it-works" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HowItWorksPage, {
							onBackToHome: () => handleNavigatePage("home"),
							onNavigatePage: handleNavigatePage,
							onStartQuiz: () => {
								handleReset();
								handleNavigatePage("compatibility");
							},
							onOpenPsychologyTests: () => setIsPsychologyTestsOpen(true),
							onOpenIntelligenceTests: handleOpenIntelligenceTests
						}),
						currentPage === "privacy" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrivacyPolicyPage, {
							onBackToHome: () => handleNavigatePage("home"),
							onNavigatePage: handleNavigatePage
						}),
						currentPage === "terms" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TermsOfServicePage, {
							onBackToHome: () => handleNavigatePage("home"),
							onNavigatePage: handleNavigatePage
						}),
						currentPage === "contact" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactUsPage, {
							onBackToHome: () => handleNavigatePage("home"),
							onNavigatePage: handleNavigatePage
						}),
						currentPage === "faq" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FAQPage, {
							onBackToHome: () => handleNavigatePage("home"),
							onNavigatePage: handleNavigatePage
						}),
						currentPage === "methodology" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourcesMethodologyPage, {
							onBackToHome: () => handleNavigatePage("home"),
							onNavigatePage: handleNavigatePage
						}),
						currentPage === "disclaimer" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DisclaimerPage, {
							onBackToHome: () => handleNavigatePage("home"),
							onNavigatePage: handleNavigatePage
						}),
						currentPage === "novels" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NovelsDirectoryPage, {
							onBackToHome: () => handleNavigatePage("home"),
							onSelectNovel: handleSelectNovel,
							onReadChapter: handleReadChapter
						}),
						currentPage === "novel-detail" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NovelDetailPage, {
							novelId: activeNovelId,
							onBackToDirectory: () => handleNavigatePage("novels"),
							onReadChapter: handleReadChapter
						}),
						currentPage === "chapter-reader" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChapterReaderPage, {
							novelId: activeNovelId,
							chapterIndex: activeChapterIndex,
							onBackToNovel: () => handleSelectNovel(activeNovelId),
							onNavigateChapter: (idx) => handleReadChapter(activeNovelId, idx)
						}),
						currentPage === "admin-cms" && (isOwner ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminCMSPage, {
							onBackToHome: () => handleNavigatePage("home"),
							onOpenAnalyticsModal: handleOpenAnalytics
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomePage, {
							onStart: (prof) => {
								handleStart(prof);
								setCurrentPage("compatibility");
								window.location.hash = "#/compatibility";
							},
							initialProfile: profile,
							savedTestsCount,
							onOpenSavedHistory: () => setIsHistoryModalOpen(true),
							onOpenBlindDate: () => setIsBlindDateOpen(true),
							onOpenDomainHosting: void 0,
							onOpenWebsiteSection: handleOpenWebsiteSection,
							onOpenPsychologyTests: () => setIsPsychologyTestsOpen(true),
							onOpenIntelligenceTests: handleOpenIntelligenceTests,
							onOpenUserDashboard: () => handleOpenUserDashboard("overview"),
							onOpenArticles: handleOpenArticles,
							onOpenNovels: handleOpenNovels,
							onOpenContactFeedback: handleOpenContactFeedback,
							onOpenCommunity: () => setIsBookClubOpen(true),
							onNavigatePage: handleNavigatePage
						})),
						currentPage === "personality-tests" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonalityTestsPage, {
							onBackToHome: () => handleNavigatePage("home"),
							onNavigatePage: handleNavigatePage
						}),
						currentPage === "how-results-are-calculated" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HowTestResultsCalculatedPage, {
							onBackToHome: () => handleNavigatePage("home"),
							onNavigatePage: handleNavigatePage,
							onStartPersonalityTests: () => handleNavigatePage("personality-tests"),
							onStartCompatibilityTest: () => {
								handleReset();
								handleNavigatePage("compatibility");
							}
						}),
						currentPage === "articles" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArticlesEncyclopediaPage, {
							onBackToHome: () => handleNavigatePage("home"),
							onNavigatePage: handleNavigatePage
						}),
						currentPage === "compatibility" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "w-full transition-opacity duration-300",
							children: [
								step === "profile" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-full",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileStep, {
										onStart: handleStart,
										initialProfile: profile,
										savedTestsCount,
										onOpenSavedHistory: () => setIsHistoryModalOpen(true),
										onOpenBlindDate: () => setIsBlindDateOpen(true),
										onOpenDomainHosting: isOwner ? () => setIsDomainHostingOpen(true) : void 0,
										onOpenWebsiteSection: handleOpenWebsiteSection,
										onOpenPsychologyTests: () => setIsPsychologyTestsOpen(true),
										onOpenIntelligenceTests: handleOpenIntelligenceTests,
										onOpenUserDashboard: () => handleOpenUserDashboard("overview"),
										onOpenArticles: handleOpenArticles,
										onOpenNovels: handleOpenNovels,
										onOpenContactFeedback: handleOpenContactFeedback,
										onBackToHome: () => handleNavigatePage("home")
									})
								}, "profile"),
								step === "quiz" && quizQuestions.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-full",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuizStep, {
										questions: quizQuestions,
										profile,
										onComplete: handleQuizComplete,
										onBackToProfile: () => setStep("profile")
									})
								}, "quiz"),
								step === "analyzing" && profile && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-full",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnalyzingStep, { profile })
								}, "analyzing"),
								step === "result" && result && profile && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-full",
									children: !isResultUnlocked && isPinLockEnabled() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrivacyLockScreen, {
										onUnlock: () => {
											setIsResultUnlocked(true);
											window.scrollTo({
												top: 0,
												behavior: "smooth"
											});
										},
										onBackToHome: handleReset
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultStep, {
										result,
										profile,
										onRestart: handleReset,
										onRegenerateImage: handleRegenerateImage,
										isRegeneratingImage,
										onOpenLiveChat: () => setIsLiveChatOpen(true),
										onOpenBlindDate: () => setIsBlindDateOpen(true),
										onOpenAuth: () => setIsAuthModalOpen(true),
										onOpenHistory: () => setIsHistoryModalOpen(true),
										onOpenPsychologyTests: () => setIsPsychologyTestsOpen(true),
										onOpenIntelligenceTests: handleOpenIntelligenceTests,
										onOpenArticles: handleOpenArticles,
										onOpenNovels: handleOpenNovels,
										onOpenUserDashboard: () => handleOpenUserDashboard("overview"),
										onOpenCoupleInvite: () => setIsCoupleInviteOpen(true),
										onLockResult: () => {
											setIsResultUnlocked(false);
											window.scrollTo({
												top: 0,
												behavior: "smooth"
											});
										}
									})
								}, !isResultUnlocked && isPinLockEnabled() ? "result-locked" : "result-unlocked")
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_react.Suspense, {
				fallback: null,
				children: [
					isLiveChatOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveChatModal, {
						isOpen: isLiveChatOpen,
						onClose: () => setIsLiveChatOpen(false),
						profile,
						onOpenBlindDate: () => setIsBlindDateOpen(true)
					}),
					isBlindDateOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlindDateShowModal, {
						isOpen: isBlindDateOpen,
						onClose: () => setIsBlindDateOpen(false),
						profile,
						result
					}),
					isArticlesModalOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArticlesSectionModal, {
						isOpen: isArticlesModalOpen,
						onClose: () => setIsArticlesModalOpen(false),
						onOpenStandalonePage: () => handleNavigatePage("articles")
					}),
					isNovelsModalOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NovelsSectionModal, {
						isOpen: isNovelsModalOpen,
						onClose: () => setIsNovelsModalOpen(false)
					}),
					isOwner && isDomainHostingOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DomainHostingModal, {
						isOpen: isDomainHostingOpen,
						onClose: () => setIsDomainHostingOpen(false)
					}),
					isWebsiteSectionsOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WebsiteSectionsModal, {
						isOpen: isWebsiteSectionsOpen,
						onClose: () => setIsWebsiteSectionsOpen(false),
						initialTab: websiteSectionTab,
						onOpenBlindDate: () => {
							setIsWebsiteSectionsOpen(false);
							setIsBlindDateOpen(true);
						},
						onStartQuiz: () => {
							setIsWebsiteSectionsOpen(false);
							handleReset();
						}
					}),
					isAuthModalOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthModal, {
						isOpen: isAuthModalOpen,
						onClose: () => setIsAuthModalOpen(false)
					}),
					isHistoryModalOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SavedResultsHistoryModal, {
						isOpen: isHistoryModalOpen,
						onClose: () => setIsHistoryModalOpen(false),
						onOpenAuth: () => {
							setIsHistoryModalOpen(false);
							setIsAuthModalOpen(true);
						},
						onLoadHistoricalResult: handleLoadHistoricalResult
					}),
					isPsychologyTestsOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PsychologyTestsModal, {
						isOpen: isPsychologyTestsOpen,
						onClose: () => setIsPsychologyTestsOpen(false),
						userName: profile?.userName,
						onOpenDashboard: (tab) => {
							setIsPsychologyTestsOpen(false);
							handleOpenUserDashboard(tab || "overview");
						}
					}),
					isUserProfileOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserProfileDashboard, {
						isOpen: isUserProfileOpen,
						onClose: () => setIsUserProfileOpen(false),
						profile,
						result,
						initialTab: userProfileDashboardTab,
						onProfileUpdated: (newProf) => setProfile(newProf),
						onOpenPsychologyTests: () => {
							setIsUserProfileOpen(false);
							setIsPsychologyTestsOpen(true);
						},
						onOpenIntelligenceTest: () => {
							setIsUserProfileOpen(false);
							setIsIntelligenceModalOpen(true);
						},
						onOpenCoupleInvite: () => {
							setIsUserProfileOpen(false);
							setIsCoupleInviteOpen(true);
						},
						onOpenLiveChat: () => {
							setIsUserProfileOpen(false);
							setIsLiveChatOpen(true);
						}
					}),
					isCoupleInviteOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CoupleInviteModal, {
						isOpen: isCoupleInviteOpen,
						onClose: () => setIsCoupleInviteOpen(false),
						profile,
						result
					}),
					isIntelligenceModalOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntelligenceTestModal, {
						isOpen: isIntelligenceModalOpen,
						onClose: () => setIsIntelligenceModalOpen(false)
					}),
					isOnboardingWizardOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OnboardingWizardModal, {
						isOpen: isOnboardingWizardOpen,
						onClose: () => setIsOnboardingWizardOpen(false),
						onSelectDestination: handleOnboardingSelectDestination
					}),
					isLegalModalOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegalModal, {
						isOpen: isLegalModalOpen,
						onClose: () => setIsLegalModalOpen(false),
						initialTab: legalModalTab
					}),
					isContactFeedbackOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactFeedbackModal, {
						isOpen: isContactFeedbackOpen,
						onClose: () => setIsContactFeedbackOpen(false)
					}),
					isOwner && isAnalyticsOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnalyticsDashboardModal, {
						isOpen: isAnalyticsOpen,
						onClose: () => setIsAnalyticsOpen(false)
					}),
					isBookClubOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookClubCommunityModal, {
						isOpen: isBookClubOpen,
						onClose: () => setIsBookClubOpen(false)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_react.Suspense, {
				fallback: null,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CookieConsentBanner, {
					onOpenPrivacyPolicy: handleOpenPrivacyPolicy,
					onOpenTermsOfService: handleOpenTermsOfService
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {
					currentPage,
					onNavigatePage: handleNavigatePage,
					onResetHome: handleReset,
					onOpenBlindDate: () => setIsBlindDateOpen(true),
					onOpenPsychologyTests: () => setIsPsychologyTestsOpen(true),
					onOpenIntelligenceTests: handleOpenIntelligenceTests,
					onOpenUserDashboard: () => handleOpenUserDashboard("overview"),
					onOpenHistory: () => handleOpenUserDashboard("history"),
					onOpenArticles: handleOpenArticles,
					onOpenNovels: handleOpenNovels,
					onOpenCoupleInvite: () => setIsCoupleInviteOpen(true),
					onOpenDomainHosting: isOwner ? () => setIsDomainHostingOpen(true) : void 0,
					onOpenAnalytics: isOwner ? handleOpenAnalytics : void 0,
					onDataDeleted: () => setSavedTestsCount(0)
				})]
			})
		]
	});
}
function App() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LanguageProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppContent, {}) }) });
}
//#endregion
//#region src/main.tsx
(0, import_client.createRoot)(document.getElementById("root")).render(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(App, {}));
//#endregion
export { verifyPin as a, getInitialLanguage as c, useAppTheme as d, setPinLock as i, useLanguage as l, isPinLockEnabled as n, TestScoringTrustBanner as o, removePinCompletely as r, OFFICIAL_LOGO_URL as s, disablePinLock as t, useAuth as u };
