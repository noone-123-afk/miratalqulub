const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/pdfReportGenerator-BNu3pVmt.js","assets/index-C5uCeetQ.js","assets/rolldown-runtime-Bk_YeHJf.js","assets/vendor-react-Bm_EF59R.js","assets/vendor-icons-WoMClU7U.js","assets/sound-C_zXqyNA.js","assets/index.es-C20Q95Ms.js","assets/firebase-Cu7XUsbK.js","assets/firebaseAuth-D6LKvzXg.js","assets/index-DMmCvB5f.css"])))=>i.map(i=>d[i]);
import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { n as __vitePreload, o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { An as BookOpen, B as Send, D as Sparkles, Et as Layers, I as Share2, K as RotateCcw, Mn as Award, Nn as ArrowRight, Pn as ArrowLeft, Qt as Download, St as ListChecks, Tn as Briefcase, Wt as FileText, b as Target, bn as Check, cn as Clock, d as UserCheck, dn as CircleQuestionMark, mn as CircleCheck, p as TriangleAlert, r as X, rn as Copy, wt as Lightbulb } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import { d as useAppTheme, l as useLanguage, u as useAuth } from "./index-C5uCeetQ.js";
import { t as motion } from "./vendor-motion-BS7ODJw7.js";
import { t as db } from "./firebase-Cu7XUsbK.js";
import { s as setDoc, u as doc } from "./vendor-firebase-firestore-nFD0fmjQ.js";
import { u as saveUnifiedTestRecord } from "./userHistoryService-6N9Zh8ed.js";
import { a as calculateIntelligenceResults, i as LIKERT_OPTIONS, n as INTELLIGENCE_CATEGORIES, o as calculateObjectiveBatteryResult, r as INTELLIGENCE_QUESTIONS, s as getQuestionsForBattery, t as INTELLIGENCE_BATTERIES_CATALOG } from "./data-psychometrics-apCQkoIJ.js";
import { n as PsychometricAcademicIntro, r as ScientificClinicalDisclaimerBanner, t as PsychometricAcademicConclusion } from "./PsychometricAcademicFraming-DuCcNyEP.js";
//#region src/components/IntelligenceRadarChart.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var IntelligenceRadarChart = ({ scores, size = 380, highlightCategory, onSelectCategory }) => {
	const [hoveredCategory, setHoveredCategory] = (0, import_react.useState)(null);
	const categories = [
		"linguistic",
		"logical",
		"spatial",
		"kinesthetic",
		"musical",
		"interpersonal",
		"intrapersonal",
		"naturalistic",
		"existential"
	];
	const totalAxes = categories.length;
	const center = size / 2;
	const maxRadius = size / 2 - 55;
	const levels = [
		.25,
		.5,
		.75,
		1
	];
	const getCoordinates = (index, value) => {
		const angle = Math.PI * 2 / totalAxes * index - Math.PI / 2;
		const r = maxRadius * value;
		return {
			x: center + r * Math.cos(angle),
			y: center + r * Math.sin(angle),
			angle
		};
	};
	const scorePoints = categories.map((cat, idx) => {
		const pct = (scores[cat]?.percentage || 10) / 100;
		return getCoordinates(idx, Math.max(.1, Math.min(1, pct)));
	});
	const polygonPath = scorePoints.map((pt) => `${pt.x},${pt.y}`).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex flex-col items-center justify-center select-none w-full max-w-[420px] mx-auto",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: `0 0 ${size} ${size}`,
			className: "w-full h-auto overflow-visible filter drop-shadow-xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("defs", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
					id: "radarAreaGradient",
					x1: "0%",
					y1: "0%",
					x2: "100%",
					y2: "100%",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0%",
							stopColor: "#ec4899",
							stopOpacity: "0.45"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "50%",
							stopColor: "#8b5cf6",
							stopOpacity: "0.4"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "100%",
							stopColor: "#06b6d4",
							stopOpacity: "0.45"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("filter", {
					id: "radarGlow",
					x: "-20%",
					y: "-20%",
					width: "140%",
					height: "140%",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feGaussianBlur", {
						stdDeviation: "6",
						result: "blur"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "SourceGraphic",
						in2: "blur",
						operator: "over"
					})]
				})] }),
				levels.map((level, lvlIdx) => {
					const levelPoints = categories.map((_, idx) => {
						const { x, y } = getCoordinates(idx, level);
						return `${x},${y}`;
					}).join(" ");
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
						points: levelPoints,
						fill: lvlIdx === levels.length - 1 ? "rgba(15, 23, 42, 0.6)" : "none",
						stroke: "rgba(255, 255, 255, 0.12)",
						strokeWidth: lvlIdx === levels.length - 1 ? "1.5" : "1",
						strokeDasharray: lvlIdx < levels.length - 1 ? "3,3" : void 0
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("text", {
						x: center + 4,
						y: center - maxRadius * level + 11,
						fill: "rgba(148, 163, 184, 0.6)",
						fontSize: "9",
						fontFamily: "monospace",
						fontWeight: "bold",
						children: [Math.round(level * 100), "%"]
					})] }, lvlIdx);
				}),
				categories.map((cat, idx) => {
					const { x, y } = getCoordinates(idx, 1);
					const meta = INTELLIGENCE_CATEGORIES[cat];
					const isHighlighted = highlightCategory === cat || hoveredCategory === cat;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: center,
						y1: center,
						x2: x,
						y2: y,
						stroke: isHighlighted ? meta.color : "rgba(255, 255, 255, 0.15)",
						strokeWidth: isHighlighted ? "2" : "1",
						className: "transition-all duration-300"
					}, cat);
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.polygon, {
					initial: {
						opacity: 0,
						scale: .8
					},
					animate: {
						opacity: 1,
						scale: 1
					},
					transition: {
						duration: .8,
						ease: "easeOut"
					},
					points: polygonPath,
					fill: "url(#radarAreaGradient)",
					stroke: "#a855f7",
					strokeWidth: "2.5",
					filter: "url(#radarGlow)"
				}),
				categories.map((cat, idx) => {
					const pt = scorePoints[idx];
					const meta = INTELLIGENCE_CATEGORIES[cat];
					const isHighlighted = highlightCategory === cat || hoveredCategory === cat;
					scores[cat]?.percentage;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
						className: "cursor-pointer transition-transform",
						onMouseEnter: () => setHoveredCategory(cat),
						onMouseLeave: () => setHoveredCategory(null),
						onClick: () => onSelectCategory && onSelectCategory(cat),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: pt.x,
							cy: pt.y,
							r: isHighlighted ? "7" : "5",
							fill: meta.color,
							stroke: "#ffffff",
							strokeWidth: "2",
							className: "transition-all duration-200"
						}), isHighlighted && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: pt.x,
							cy: pt.y,
							r: "12",
							fill: meta.color,
							opacity: "0.35",
							className: "animate-ping"
						})]
					}, cat);
				}),
				categories.map((cat, idx) => {
					const { x, y } = getCoordinates(idx, 1.22);
					const meta = INTELLIGENCE_CATEGORIES[cat];
					const pct = scores[cat]?.percentage || 0;
					const isHighlighted = highlightCategory === cat || hoveredCategory === cat;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
						className: "cursor-pointer",
						onMouseEnter: () => setHoveredCategory(cat),
						onMouseLeave: () => setHoveredCategory(null),
						onClick: () => onSelectCategory && onSelectCategory(cat),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
								x,
								y: y - 8,
								textAnchor: "middle",
								fontSize: "14",
								className: "transition-transform duration-200",
								children: meta.icon
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
								x,
								y: y + 7,
								textAnchor: "middle",
								fill: isHighlighted ? "#ffffff" : "#cbd5e1",
								fontSize: "11",
								fontWeight: isHighlighted ? "800" : "600",
								fontFamily: "Alexandria, sans-serif",
								className: "transition-colors duration-200",
								children: meta.titleAr.split(" ")[1] || meta.titleAr
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("text", {
								x,
								y: y + 20,
								textAnchor: "middle",
								fill: meta.color,
								fontSize: "11",
								fontWeight: "900",
								fontFamily: "monospace",
								children: [pct, "%"]
							})
						]
					}, `label_${cat}`);
				})
			]
		}), hoveredCategory && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: {
				opacity: 0,
				y: 5
			},
			animate: {
				opacity: 1,
				y: 0
			},
			className: "mt-2 px-3 py-1.5 rounded-xl bg-slate-900/90 border border-purple-500/40 text-center shadow-lg backdrop-blur-md",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-xs font-bold text-white",
				children: [
					INTELLIGENCE_CATEGORIES[hoveredCategory].icon,
					" ",
					INTELLIGENCE_CATEGORIES[hoveredCategory].titleAr,
					":",
					" "
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-xs font-black text-rose-400 font-mono",
				children: [scores[hoveredCategory]?.percentage, "%"]
			})]
		})]
	});
};
//#endregion
//#region src/components/ViralShareModal.tsx
var ViralShareModal = ({ isOpen, onClose, titleAr, shareText, categoryTagAr = "مِـرآة القـلوب للتحليل النفسي والتوافق" }) => {
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [downloadedImg, setDownloadedImg] = (0, import_react.useState)(false);
	if (!isOpen) return null;
	const currentUrl = typeof window !== "undefined" ? window.location.origin : "https://miratalqulub.com";
	const fullShareMessage = `${shareText}\n\n🔗 جرب الاختبار بنفسك واكتشف خريطتك النفسية والمعرفية:\n${currentUrl}`;
	const handleCopy = () => {
		soundManager.playTap();
		if (navigator.clipboard) {
			navigator.clipboard.writeText(fullShareMessage);
			setCopied(true);
			setTimeout(() => setCopied(false), 2800);
		}
	};
	const handleDownloadShareImage = () => {
		soundManager.playTap();
		const canvas = document.createElement("canvas");
		canvas.width = 1080;
		canvas.height = 1080;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		ctx.direction = "rtl";
		ctx.textAlign = "center";
		const grad = ctx.createLinearGradient(0, 0, 1080, 1080);
		grad.addColorStop(0, "#0f0c20");
		grad.addColorStop(.5, "#1e1b4b");
		grad.addColorStop(1, "#311042");
		ctx.fillStyle = grad;
		ctx.fillRect(0, 0, 1080, 1080);
		ctx.strokeStyle = "rgba(168, 85, 247, 0.55)";
		ctx.lineWidth = 6;
		ctx.strokeRect(44, 44, 992, 992);
		ctx.fillStyle = "#c084fc";
		ctx.font = "bold 28px Alexandria, Tahoma, sans-serif";
		ctx.fillText("مِـرآة القـلوب • المختبر السيكومتري والمعرفي المعتمد", 540, 130);
		ctx.fillStyle = "#ffffff";
		ctx.font = "800 42px Alexandria, Tahoma, sans-serif";
		ctx.fillText(titleAr, 540, 200);
		ctx.fillStyle = "#f472b6";
		ctx.font = "bold 24px Alexandria, Tahoma, sans-serif";
		ctx.fillText(categoryTagAr, 540, 250);
		ctx.fillStyle = "rgba(15, 23, 42, 0.82)";
		ctx.fillRect(88, 300, 904, 580);
		ctx.strokeStyle = "rgba(236, 72, 153, 0.4)";
		ctx.lineWidth = 3;
		ctx.strokeRect(88, 300, 904, 580);
		ctx.fillStyle = "#f8fafc";
		ctx.font = "bold 28px Alexandria, Tahoma, sans-serif";
		const rawLines = shareText.split("\n").filter(Boolean);
		let y = 380;
		rawLines.forEach((rawLine) => {
			const words = rawLine.split(/\s+/);
			let current = "";
			words.forEach((w) => {
				const test = current ? `${current} ${w}` : w;
				if (ctx.measureText(test).width > 820 && current) {
					ctx.fillText(current, 540, y);
					y += 50;
					current = w;
				} else current = test;
			});
			if (current) {
				ctx.fillText(current, 540, y);
				y += 56;
			}
		});
		ctx.fillStyle = "#94a3b8";
		ctx.font = "22px Alexandria, Tahoma, sans-serif";
		ctx.fillText("الأردن - عمّان | one497303@gmail.com", 540, 960);
		canvas.toBlob((blob) => {
			if (!blob) return;
			const url = URL.createObjectURL(blob);
			const a = document.createElement("a");
			a.href = url;
			a.download = "بطاقة_نتيجة_مرآة_القلوب.png";
			document.body.appendChild(a);
			a.click();
			document.body.removeChild(a);
			URL.revokeObjectURL(url);
			setDownloadedImg(true);
			setTimeout(() => setDownloadedImg(false), 3e3);
		}, "image/png");
	};
	const whatsappHref = `https://api.whatsapp.com/send?text=${encodeURIComponent(fullShareMessage)}`;
	const telegramHref = `https://t.me/share/url?url=${encodeURIComponent(currentUrl)}&text=${encodeURIComponent(fullShareMessage)}`;
	const twitterHref = `https://twitter.com/intent/tweet?text=${encodeURIComponent(`${shareText}\n${currentUrl}\n#تحليل_شخصية #اختبار_ذكاء #مرآة_القلوب`)}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-[70] flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md overflow-hidden text-right",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: {
				opacity: 0,
				scale: .95,
				y: 15
			},
			animate: {
				opacity: 1,
				scale: 1,
				y: 0
			},
			exit: {
				opacity: 0,
				scale: .95,
				y: 15
			},
			className: "w-full max-w-lg bg-[#0f172a] border border-rose-500/30 rounded-3xl overflow-hidden shadow-2xl flex flex-col relative",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-4 sm:p-5 bg-gradient-to-r from-slate-900 via-rose-950/40 to-slate-900 border-b border-white/10 flex items-center justify-between shrink-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-9 h-9 rounded-xl bg-gradient-to-tr from-rose-500 to-pink-600 flex items-center justify-center text-white shadow-md",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "w-4 h-4" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center gap-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-extrabold text-sm sm:text-base text-white font-['Alexandria']",
							children: titleAr
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] text-slate-400",
						children: categoryTagAr
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onClose,
					"aria-label": "إغلاق نافذة المشاركة",
					title: "إغلاق",
					className: "p-2 rounded-full bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition cursor-pointer",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-5 h-5" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-4 sm:p-6 space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-4 rounded-2xl bg-slate-900/90 border border-white/10 space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between text-xs text-slate-400",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold text-rose-300",
								children: "بطاقة النتيجة المعتمدة:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px]",
								children: "جاهزة للنسخ أو التنزيل كصورة"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-slate-200 leading-relaxed font-sans whitespace-pre-line bg-black/40 p-3 rounded-xl border border-white/5",
							children: shareText
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-bold text-slate-300 block",
							children: "اختر منصة المشاركة الفورية:"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-3 gap-2.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: whatsappHref,
									target: "_blank",
									rel: "noopener noreferrer",
									onClick: () => soundManager.playTap(),
									className: "p-3 rounded-2xl bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-emerald-300 text-xs font-bold transition flex flex-col items-center justify-center gap-1.5 cursor-pointer shadow-md",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xl",
										children: "💬"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "واتساب" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: telegramHref,
									target: "_blank",
									rel: "noopener noreferrer",
									onClick: () => soundManager.playTap(),
									className: "p-3 rounded-2xl bg-sky-600/20 hover:bg-sky-600/30 border border-sky-500/40 text-sky-300 text-xs font-bold transition flex flex-col items-center justify-center gap-1.5 cursor-pointer shadow-md",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "w-5 h-5 text-sky-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تيليجرام" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: twitterHref,
									target: "_blank",
									rel: "noopener noreferrer",
									onClick: () => soundManager.playTap(),
									className: "p-3 rounded-2xl bg-slate-800 hover:bg-slate-700 border border-slate-600 text-white text-xs font-bold transition flex flex-col items-center justify-center gap-1.5 cursor-pointer shadow-md",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-base font-black font-mono",
										children: "𝕏"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "منصة X" })]
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 gap-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: handleDownloadShareImage,
							className: "w-full py-3 px-4 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs transition shadow-lg flex items-center justify-center gap-2 cursor-pointer",
							children: downloadedImg ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4 text-emerald-300" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تم تنزيل البطاقة PNG ✓" })] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تنزيل بطاقة النتيجة كصورة 📸" })] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: handleCopy,
							className: "w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-rose-600 via-pink-600 to-purple-600 hover:opacity-95 text-white font-extrabold text-xs transition shadow-lg shadow-rose-600/25 flex items-center justify-center gap-2 cursor-pointer",
							children: copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4 text-emerald-300" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تم النسخ للحافظة ✓" })] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "نسخ النص والرابط" })] })
						})]
					})
				]
			})]
		})
	});
};
//#endregion
//#region src/components/IntelligenceTestModal.tsx
function buildExecutiveSummaryText(iqLevel, topEQSkill, topMISkill) {
	return `بناءً على التقييم السيكومتري الشامل، يتمتع المختبَر بقدرة بارزة في "${topMISkill}" مدعومة بمهارة متميزة في "${topEQSkill}"، ومستوى أداء معرفي (${iqLevel}). هذا المزيج يشكل بصمة معرفية ووجدانية تؤهله للتميز في البيئات التي تتطلب تحليلاً عميقاً، قيادة متزنة، وتواصلاً إنسانياً ذكياً، مع قدرة عالية على تحويل الأفكار المعقدة إلى إنجازات عملية ملموسة.`;
}
var STORAGE_RESULT_KEY = "mirat_intelligence_test_result";
var STORAGE_ANSWERS_KEY = "mirat_intelligence_test_answers";
var STORAGE_OBJ_ANSWERS_KEY = "mirat_intelligence_obj_answers_";
var STORAGE_OBJ_RESULT_KEY = "mirat_intelligence_obj_result_";
var IntelligenceTestModal = ({ isOpen, onClose, onSaveResultToProfile }) => {
	const { user } = useAuth();
	const { language } = useLanguage();
	const { theme } = useAppTheme();
	const isAr = language === "ar";
	const isLight = theme === "light";
	const questionScrollRef = (0, import_react.useRef)(null);
	const [step, setStep] = (0, import_react.useState)("welcome");
	const [activeBattery, setActiveBattery] = (0, import_react.useState)("multiple_intelligences");
	const [gender, setGender] = (0, import_react.useState)("male");
	const [ageGroup, setAgeGroup] = (0, import_react.useState)("18-29");
	const [runnerViewMode, setRunnerViewMode] = (0, import_react.useState)("paged_5");
	const [answers, setAnswers] = (0, import_react.useState)({});
	const [objAnswers, setObjAnswers] = (0, import_react.useState)({});
	const [currentPage, setCurrentPage] = (0, import_react.useState)(0);
	const [activeCategoryDetail, setActiveCategoryDetail] = (0, import_react.useState)(null);
	const [unansweredWarning, setUnansweredWarning] = (0, import_react.useState)(false);
	const [showQuestionAudit, setShowQuestionAudit] = (0, import_react.useState)(true);
	const [auditFilter, setAuditFilter] = (0, import_react.useState)("all");
	const [timeLeftSeconds, setTimeLeftSeconds] = (0, import_react.useState)(1500);
	const [elapsedSeconds, setElapsedSeconds] = (0, import_react.useState)(0);
	const [isTimerActive, setIsTimerActive] = (0, import_react.useState)(false);
	const [testResult, setTestResult] = (0, import_react.useState)(null);
	const [objResult, setObjResult] = (0, import_react.useState)(null);
	const [isSavedToProfile, setIsSavedToProfile] = (0, import_react.useState)(false);
	const [isViralShareOpen, setIsViralShareOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		try {
			const savedRes = localStorage.getItem(STORAGE_RESULT_KEY);
			if (savedRes) setTestResult(JSON.parse(savedRes));
			const savedAns = localStorage.getItem(STORAGE_ANSWERS_KEY);
			if (savedAns) setAnswers(JSON.parse(savedAns));
		} catch {}
	}, []);
	(0, import_react.useEffect)(() => {
		if (activeBattery !== "multiple_intelligences") try {
			const savedObjAns = localStorage.getItem(`${STORAGE_OBJ_ANSWERS_KEY}${activeBattery}`);
			if (savedObjAns) setObjAnswers(JSON.parse(savedObjAns));
			else setObjAnswers({});
			const savedObjRes = localStorage.getItem(`${STORAGE_OBJ_RESULT_KEY}${activeBattery}`);
			if (savedObjRes) setObjResult(JSON.parse(savedObjRes));
			else setObjResult(null);
		} catch {
			setObjAnswers({});
		}
	}, [activeBattery]);
	(0, import_react.useEffect)(() => {
		if (step === "test" && questionScrollRef.current) questionScrollRef.current.scrollTo({
			top: 0,
			behavior: "smooth"
		});
	}, [
		currentPage,
		runnerViewMode,
		step
	]);
	(0, import_react.useEffect)(() => {
		let timer;
		if (isTimerActive && timeLeftSeconds > 0) timer = setInterval(() => {
			setTimeLeftSeconds((prev) => prev > 0 ? prev - 1 : 0);
			setElapsedSeconds((prev) => prev + 1);
		}, 1e3);
		return () => clearInterval(timer);
	}, [isTimerActive, timeLeftSeconds]);
	if (!isOpen) return null;
	const currentBatteryMeta = INTELLIGENCE_BATTERIES_CATALOG.find((b) => b.id === activeBattery) || INTELLIGENCE_BATTERIES_CATALOG[0];
	const isMultipleIntelligences = activeBattery === "multiple_intelligences";
	const activeMIQuestions = INTELLIGENCE_QUESTIONS;
	const activeObjQuestions = !isMultipleIntelligences ? getQuestionsForBattery(activeBattery) : [];
	const totalQuestionsCount = isMultipleIntelligences ? activeMIQuestions.length : activeObjQuestions.length;
	const questionsPerPage = runnerViewMode === "all_list" ? totalQuestionsCount : runnerViewMode === "single_1" ? 1 : 5;
	const totalPages = Math.max(1, Math.ceil(totalQuestionsCount / questionsPerPage));
	const safeCurrentPage = Math.min(currentPage, totalPages - 1);
	const currentMIQuestionsPage = isMultipleIntelligences ? activeMIQuestions.slice(safeCurrentPage * questionsPerPage, (safeCurrentPage + 1) * questionsPerPage) : [];
	const currentObjQuestionsPage = !isMultipleIntelligences ? activeObjQuestions.slice(safeCurrentPage * questionsPerPage, (safeCurrentPage + 1) * questionsPerPage) : [];
	const answeredCount = isMultipleIntelligences ? activeMIQuestions.filter((q) => answers[q.id] !== void 0).length : activeObjQuestions.filter((q) => objAnswers[q.id] !== void 0).length;
	const remainingCount = Math.max(0, totalQuestionsCount - answeredCount);
	const progressPercent = Math.round(answeredCount / Math.max(1, totalQuestionsCount) * 100);
	const handleSelectBattery = (battery) => {
		soundManager.playTap();
		setActiveBattery(battery);
		setUnansweredWarning(false);
		setStep("instructions");
	};
	const handleOpenSavedBatteryResult = (e, battery) => {
		e.stopPropagation();
		soundManager.playTap();
		setActiveBattery(battery);
		setUnansweredWarning(false);
		if (battery === "multiple_intelligences") {
			if (testResult) {
				setActiveCategoryDetail(testResult.primaryIntelligence);
				setStep("results");
			}
		} else try {
			const raw = localStorage.getItem(`${STORAGE_OBJ_RESULT_KEY}${battery}`);
			if (raw) {
				const parsed = JSON.parse(raw);
				setObjResult(parsed);
				setStep("results");
			}
		} catch {}
	};
	const handleDirectPDFForBattery = (e, battery) => {
		e.stopPropagation();
		soundManager.playTap();
		if (battery === "multiple_intelligences" && testResult) triggerMIPDFExport(testResult);
		else if (battery !== "multiple_intelligences") try {
			const raw = localStorage.getItem(`${STORAGE_OBJ_RESULT_KEY}${battery}`);
			if (raw) {
				const parsed = JSON.parse(raw);
				const meta = INTELLIGENCE_BATTERIES_CATALOG.find((b) => b.id === battery) || INTELLIGENCE_BATTERIES_CATALOG[1];
				triggerObjectivePDFExport(parsed, meta);
			}
		} catch {}
	};
	const handleStartTest = () => {
		soundManager.playTap();
		setCurrentPage(0);
		setUnansweredWarning(false);
		setElapsedSeconds(0);
		setTimeLeftSeconds(currentBatteryMeta.recommendedMinutes * 60);
		setIsTimerActive(true);
		setStep("test");
	};
	const handleResetBatteryAnswers = () => {
		soundManager.playTap();
		setUnansweredWarning(false);
		if (isMultipleIntelligences) {
			setAnswers({});
			try {
				localStorage.removeItem(STORAGE_ANSWERS_KEY);
			} catch {}
		} else {
			setObjAnswers({});
			try {
				localStorage.removeItem(`${STORAGE_OBJ_ANSWERS_KEY}${activeBattery}`);
			} catch {}
		}
		setCurrentPage(0);
	};
	const handleSelectMIAnswer = (questionId, val) => {
		soundManager.playTap();
		const updated = {
			...answers,
			[questionId]: val
		};
		setAnswers(updated);
		if (unansweredWarning) setUnansweredWarning(false);
		try {
			localStorage.setItem(STORAGE_ANSWERS_KEY, JSON.stringify(updated));
		} catch {}
	};
	const handleSelectObjAnswer = (questionId, optionId) => {
		soundManager.playTap();
		const updated = {
			...objAnswers,
			[questionId]: optionId
		};
		setObjAnswers(updated);
		if (unansweredWarning) setUnansweredWarning(false);
		try {
			localStorage.setItem(`${STORAGE_OBJ_ANSWERS_KEY}${activeBattery}`, JSON.stringify(updated));
		} catch {}
	};
	const handleSwitchViewMode = (mode) => {
		soundManager.playTap();
		setRunnerViewMode(mode);
		setCurrentPage(0);
	};
	const handleJumpToQuestionIndex = (zeroBasedQuestionIndex) => {
		soundManager.playTap();
		if (runnerViewMode === "all_list") {
			const el = document.getElementById(`intel-q-card-${zeroBasedQuestionIndex + 1}`);
			if (el) el.scrollIntoView({
				behavior: "smooth",
				block: "center"
			});
		} else {
			const targetPage = Math.floor(zeroBasedQuestionIndex / questionsPerPage);
			setCurrentPage(targetPage);
			setTimeout(() => {
				const el = document.getElementById(`intel-q-card-${zeroBasedQuestionIndex + 1}`);
				if (el) el.scrollIntoView({
					behavior: "smooth",
					block: "center"
				});
			}, 80);
		}
	};
	const handleJumpToFirstUnanswered = () => {
		soundManager.playTap();
		setUnansweredWarning(false);
		if (isMultipleIntelligences) {
			const idx = activeMIQuestions.findIndex((q) => answers[q.id] === void 0);
			if (idx >= 0) handleJumpToQuestionIndex(idx);
		} else {
			const idx = activeObjQuestions.findIndex((q) => objAnswers[q.id] === void 0);
			if (idx >= 0) handleJumpToQuestionIndex(idx);
		}
	};
	const handleNextPage = () => {
		soundManager.playTap();
		if (safeCurrentPage < totalPages - 1) setCurrentPage(safeCurrentPage + 1);
		else {
			if (answeredCount < totalQuestionsCount && !unansweredWarning) {
				setUnansweredWarning(true);
				return;
			}
			handleFinishTest(true);
		}
	};
	const handlePrevPage = () => {
		soundManager.playTap();
		if (safeCurrentPage > 0) setCurrentPage(safeCurrentPage - 1);
	};
	const handleFinishTest = (forceSubmit = false) => {
		if (!forceSubmit && answeredCount < totalQuestionsCount) {
			setUnansweredWarning(true);
			return;
		}
		soundManager.playRoundPass();
		setIsTimerActive(false);
		setUnansweredWarning(false);
		if (isMultipleIntelligences) {
			const result = calculateIntelligenceResults(answers, ageGroup, gender);
			setTestResult(result);
			setStep("results");
			setActiveCategoryDetail(result.primaryIntelligence);
			try {
				localStorage.setItem(STORAGE_RESULT_KEY, JSON.stringify(result));
			} catch {}
			saveUnifiedTestRecord(user, {
				testType: "intelligence",
				testTitleAr: `مقياس الذكاءات الـ 9: ${INTELLIGENCE_CATEGORIES[result.primaryIntelligence].titleAr}`,
				testCategoryAr: "الذكاءات المتعددة (هوارد جاردنر وماكينزي - 45 سؤالاً)",
				scoreOrArchetype: INTELLIGENCE_CATEGORIES[result.primaryIntelligence].titleAr,
				percentage: result.categoryScores[result.primaryIntelligence].percentage,
				badgeColor: INTELLIGENCE_CATEGORIES[result.primaryIntelligence].color,
				keyInsights: [`الذكاء السائد: ${INTELLIGENCE_CATEGORIES[result.primaryIntelligence].titleAr}`, ...INTELLIGENCE_CATEGORIES[result.primaryIntelligence].suggestedCareersAr.slice(0, 2).map((c) => `مهنة مقترحة: ${c}`)],
				snapshot: result
			}).catch(() => {});
		} else {
			const result = calculateObjectiveBatteryResult(activeBattery, objAnswers, elapsedSeconds || 120, ageGroup);
			setObjResult(result);
			setStep("results");
			try {
				localStorage.setItem(`${STORAGE_OBJ_RESULT_KEY}${activeBattery}`, JSON.stringify(result));
			} catch {}
			saveUnifiedTestRecord(user, {
				testType: "intelligence",
				testTitleAr: result.batteryTitleAr,
				testCategoryAr: currentBatteryMeta.scientificScaleName,
				scoreOrArchetype: `${result.classificationTitleAr} (${result.standardScore})`,
				percentage: result.overallPercentage,
				badgeColor: currentBatteryMeta.accentColor,
				keyInsights: [`الدرجة المعيارية: ${result.standardScore} (المئين ${result.percentileRank}%)`, ...result.strengthsAr.slice(0, 2)],
				snapshot: result
			}).catch(() => {});
		}
	};
	const handleSaveToProfile = async () => {
		soundManager.playTap();
		setIsSavedToProfile(true);
		if (isMultipleIntelligences && testResult) {
			if (onSaveResultToProfile) onSaveResultToProfile(testResult);
			try {
				await saveUnifiedTestRecord(user, {
					testType: "intelligence",
					testTitleAr: `مقياس الذكاءات الـ 9: ${INTELLIGENCE_CATEGORIES[testResult.primaryIntelligence].titleAr}`,
					testCategoryAr: "الذكاءات المتعددة (هوارد جاردنر - 45 سؤالاً)",
					scoreOrArchetype: INTELLIGENCE_CATEGORIES[testResult.primaryIntelligence].titleAr,
					percentage: testResult.categoryScores[testResult.primaryIntelligence].percentage,
					badgeColor: INTELLIGENCE_CATEGORIES[testResult.primaryIntelligence].color,
					keyInsights: [`الذكاء السائد: ${INTELLIGENCE_CATEGORIES[testResult.primaryIntelligence].titleAr}`, ...INTELLIGENCE_CATEGORIES[testResult.primaryIntelligence].suggestedCareersAr.slice(0, 2).map((c) => `مهنة مقترحة: ${c}`)],
					snapshot: testResult
				});
				if (user && user.uid) {
					const userRef = doc(db, "users", user.uid);
					await setDoc(userRef, { intelligenceProfile: {
						primaryIntelligence: testResult.primaryIntelligence,
						topThree: testResult.topThree,
						scores: testResult.categoryScores,
						completedAt: testResult.completedAt
					} }, { merge: true });
				}
			} catch (err) {
				console.warn("Could not sync intelligence to Firestore", err);
			}
		} else if (!isMultipleIntelligences && objResult) try {
			await saveUnifiedTestRecord(user, {
				testType: "intelligence",
				testTitleAr: objResult.batteryTitleAr,
				testCategoryAr: currentBatteryMeta.scientificScaleName,
				scoreOrArchetype: `${objResult.classificationTitleAr} (${objResult.standardScore})`,
				percentage: objResult.overallPercentage,
				badgeColor: currentBatteryMeta.accentColor,
				keyInsights: objResult.strengthsAr,
				snapshot: objResult
			});
		} catch {}
		setTimeout(() => setIsSavedToProfile(false), 3e3);
	};
	const triggerMIPDFExport = async (res) => {
		const { exportPsychometricReportAsPDF, generateExecutiveSummary } = await __vitePreload(async () => {
			const { exportPsychometricReportAsPDF, generateExecutiveSummary } = await import("./pdfReportGenerator-BNu3pVmt.js");
			return {
				exportPsychometricReportAsPDF,
				generateExecutiveSummary
			};
		}, __vite__mapDeps([0,1,2,3,4,5,6,7,8,9]));
		const primaryMeta = INTELLIGENCE_CATEGORIES[res.primaryIntelligence];
		const secondMeta = INTELLIGENCE_CATEGORIES[res.topThree[1]];
		const execSummary = generateExecutiveSummary(`معدل كلي ${res.overallAverage}%`, secondMeta.titleAr, primaryMeta.titleAr);
		exportPsychometricReportAsPDF({
			reportTitle: "التقرير السيكومتري الشامل للذكاءات المتعددة (9 ذكاءات • 45 سؤالاً)",
			subTitle: `البصمة المعرفية المهيمنة: ${primaryMeta.titleAr}`,
			scientificBasis: "Howard Gardner (1983/1999) & Walter McKenzie Inventory (45 Items)",
			completedAt: new Date(res.completedAt).toLocaleDateString("ar-SA"),
			overallScoreLabel: "المعدل المعرفي الكلي",
			overallScoreValue: `${res.overallAverage}%`,
			cognitiveFingerprintTitle: `البصمة المعرفية: ${primaryMeta.titleAr} + ${secondMeta.titleAr}`,
			executiveSummary: execSummary,
			metrics: Object.keys(INTELLIGENCE_CATEGORIES).map((cat) => ({
				label: `${INTELLIGENCE_CATEGORIES[cat].icon} ${INTELLIGENCE_CATEGORIES[cat].titleAr}`,
				scorePercent: res.categoryScores[cat]?.percentage || 0,
				rawText: `${res.categoryScores[cat]?.rawScore || 0}/25`,
				color: INTELLIGENCE_CATEGORIES[cat].color
			})),
			sections: res.topThree.map((cat, idx) => {
				const meta = INTELLIGENCE_CATEGORIES[cat];
				const pct = res.categoryScores[cat]?.percentage || 0;
				return {
					title: `المركز ${idx + 1}: ${meta.titleAr} (${pct}%)`,
					badge: meta.titleEn,
					content: `${meta.descriptionAr} — ${meta.scientificFoundationAr}`,
					items: [...meta.optimalLearningStylesAr.map((s) => `أسلوب التعلم الأمثل: ${s}`), ...meta.developmentExercisesAr.map((e) => `تمرين التطوير: ${e}`)]
				};
			}),
			careersOrRecommendations: primaryMeta.suggestedCareersAr
		});
	};
	const triggerObjectivePDFExport = async (res, meta) => {
		const { exportPsychometricReportAsPDF } = await __vitePreload(async () => {
			const { exportPsychometricReportAsPDF } = await import("./pdfReportGenerator-BNu3pVmt.js");
			return { exportPsychometricReportAsPDF };
		}, __vite__mapDeps([0,1,2,3,4,5,6,7,8,9]));
		exportPsychometricReportAsPDF({
			reportTitle: res.batteryTitleAr,
			subTitle: `${res.classificationTitleAr} — (${res.correctOrHighCount}/${res.totalQuestions} إجابة صحيحة)`,
			scientificBasis: `${meta.scientificScaleName} (${meta.theoristAr})`,
			completedAt: res.completedAt,
			overallScoreLabel: "الدرجة المعيارية (IQ/EQ)",
			overallScoreValue: `${res.standardScore} (المئين ${res.percentileRank}%)`,
			cognitiveFingerprintTitle: `${res.classificationTitleAr} • الدقة الموزونة ${res.overallPercentage}%`,
			executiveSummary: res.executiveSummaryAr,
			metrics: res.domainScores.map((d) => ({
				label: d.domainTitleAr,
				scorePercent: d.percentage,
				rawText: `${d.correctCount}/${d.totalCount}`,
				levelLabel: d.levelAr,
				color: d.color
			})),
			sections: [...res.domainScores.map((d) => ({
				title: `${d.domainTitleAr} (${d.correctCount}/${d.totalCount} إجابات صحيحة)`,
				badge: `${d.percentage}% • ${d.levelAr}`,
				content: d.interpretationAr
			})), {
				title: "ملخص التدقيق العلمي للإجابات (30 سؤالاً)",
				badge: `الدقة المباشرة: ${res.accuracyPercentage}%`,
				content: `أجاب المختبَر إجابة صحيحة/مثالية على (${res.correctOrHighCount}) من أصل (${res.totalQuestions}) سؤالاً في زمن قدره (${formatTimer(res.timeSpentSeconds)}).`,
				items: (res.questionReview || []).slice(0, 10).map((q) => `س${q.questionNumber} (${q.isCorrect ? "✓ صحيح" : "✗ خطأ"}): إجابتك «${q.selectedLabelAr}» | الصواب: «${q.correctLabelAr}»`)
			}],
			careersOrRecommendations: [...res.suggestedCareersAr.map((c) => `مسار مهني مقترح: ${c}`), ...res.growthRecommendationsAr.map((g) => `توصية تطويرية: ${g}`)],
			questionAudit: (res.questionReview || []).map((q) => ({
				questionNumber: q.questionNumber,
				questionText: q.promptAr,
				userAnswer: q.selectedLabelAr,
				correctAnswerOrTrait: `${q.domainTitleAr} • الصواب: ${q.correctLabelAr}`,
				isCorrectOrHigh: q.isCorrect,
				pointsEarned: q.isCorrect ? "✓ صحيح" : "✗ خطأ",
				explanationAr: q.explanationAr
			}))
		});
	};
	const handleDownloadPDFReport = async () => {
		soundManager.playTap();
		if (isMultipleIntelligences && testResult) await triggerMIPDFExport(testResult);
		else if (!isMultipleIntelligences && objResult) await triggerObjectivePDFExport(objResult, currentBatteryMeta);
	};
	const formatTimer = (secs) => {
		const m = Math.floor(secs / 60);
		const s = secs % 60;
		return `${m}:${s < 10 ? "0" : ""}${s}`;
	};
	const renderRavenMatrixVisual = (matrixId) => {
		if (!matrixId) return null;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "my-3 p-4 rounded-2xl bg-slate-900/95 border border-indigo-500/30 flex flex-col items-center justify-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-[11px] text-indigo-300 font-bold mb-2 flex items-center gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "🧩" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "لوحة مصفوفة رافين البصرية (Raven’s Progressive Matrix)" })]
				}),
				matrixId === "raven_matrix_1" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					viewBox: "0 0 240 240",
					className: "w-48 h-48 sm:w-56 sm:h-56",
					children: [
						0,
						1,
						2
					].map((row) => [
						0,
						1,
						2
					].map((col) => {
						const x = 15 + col * 72;
						const y = 15 + row * 72;
						const isMissing = row === 2 && col === 2;
						const count = row + col + 1;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x,
							y,
							width: "64",
							height: "64",
							rx: "10",
							fill: isMissing ? "rgba(99,102,241,0.18)" : "rgba(15,23,42,0.9)",
							stroke: isMissing ? "#818cf8" : "#475569",
							strokeWidth: "2",
							strokeDasharray: isMissing ? "4,3" : void 0
						}), isMissing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
							x: x + 32,
							y: y + 40,
							textAnchor: "middle",
							fill: "#a5b4fc",
							fontSize: "24",
							fontWeight: "bold",
							children: "؟"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							count >= 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: x + 32,
								cy: y + 32,
								r: "5",
								fill: "#38bdf8"
							}),
							count >= 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: x + 16,
								cy: y + 16,
								r: "5",
								fill: "#38bdf8"
							}),
							count >= 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: x + 48,
								cy: y + 48,
								r: "5",
								fill: "#38bdf8"
							}),
							count >= 4 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: x + 48,
								cy: y + 16,
								r: "5",
								fill: "#38bdf8"
							})
						] })] }, `${row}_${col}`);
					}))
				}),
				matrixId === "raven_matrix_2" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					viewBox: "0 0 240 100",
					className: "w-60 h-28",
					children: [
						0,
						1,
						2
					].map((col) => {
						const x = 15 + col * 72;
						const y = 18;
						const isMissing = col === 2;
						const rotation = col * 90;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x,
							y,
							width: "64",
							height: "64",
							rx: "10",
							fill: isMissing ? "rgba(99,102,241,0.18)" : "rgba(15,23,42,0.9)",
							stroke: isMissing ? "#818cf8" : "#475569",
							strokeWidth: "2"
						}), isMissing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
							x: x + 32,
							y: 58,
							textAnchor: "middle",
							fill: "#a5b4fc",
							fontSize: "24",
							fontWeight: "bold",
							children: "؟"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
							transform: `rotate(${rotation} ${x + 32} 50)`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: x + 32,
								y1: 68,
								x2: x + 32,
								y2: 34,
								stroke: "#ec4899",
								strokeWidth: "3.5",
								strokeLinecap: "round"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", {
								points: `${x + 22},44 ${x + 32},32 ${x + 42},44`,
								fill: "none",
								stroke: "#ec4899",
								strokeWidth: "3.5",
								strokeLinecap: "round",
								strokeLinejoin: "round"
							})]
						})] }, col);
					})
				}),
				matrixId === "raven_matrix_3" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
					viewBox: "0 0 240 100",
					className: "w-60 h-28",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "15",
							y: "18",
							width: "64",
							height: "64",
							rx: "10",
							fill: "rgba(15,23,42,0.9)",
							stroke: "#475569",
							strokeWidth: "2"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							x1: "47",
							y1: "26",
							x2: "47",
							y2: "74",
							stroke: "#38bdf8",
							strokeWidth: "3"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							x1: "25",
							y1: "74",
							x2: "69",
							y2: "26",
							stroke: "#a855f7",
							strokeWidth: "3"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "87",
							y: "18",
							width: "64",
							height: "64",
							rx: "10",
							fill: "rgba(15,23,42,0.9)",
							stroke: "#475569",
							strokeWidth: "2"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							x1: "119",
							y1: "26",
							x2: "119",
							y2: "74",
							stroke: "#38bdf8",
							strokeWidth: "3"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							x1: "97",
							y1: "26",
							x2: "141",
							y2: "74",
							stroke: "#10b981",
							strokeWidth: "3"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "159",
							y: "18",
							width: "64",
							height: "64",
							rx: "10",
							fill: "rgba(99,102,241,0.18)",
							stroke: "#818cf8",
							strokeWidth: "2",
							strokeDasharray: "4,3"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
							x: "191",
							y: "58",
							textAnchor: "middle",
							fill: "#a5b4fc",
							fontSize: "24",
							fontWeight: "bold",
							children: "؟"
						})
					]
				}),
				matrixId === "raven_matrix_4" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					viewBox: "0 0 240 240",
					className: "w-48 h-48 sm:w-56 sm:h-56",
					children: [
						{
							row: 0,
							col: 0,
							shape: "tri",
							fill: "outline"
						},
						{
							row: 0,
							col: 1,
							shape: "cir",
							fill: "striped"
						},
						{
							row: 0,
							col: 2,
							shape: "dia",
							fill: "solid"
						},
						{
							row: 1,
							col: 0,
							shape: "dia",
							fill: "striped"
						},
						{
							row: 1,
							col: 1,
							shape: "tri",
							fill: "solid"
						},
						{
							row: 1,
							col: 2,
							shape: "cir",
							fill: "outline"
						},
						{
							row: 2,
							col: 0,
							shape: "cir",
							fill: "outline"
						},
						{
							row: 2,
							col: 1,
							shape: "tri",
							fill: "striped"
						},
						{
							row: 2,
							col: 2,
							shape: "missing",
							fill: "missing"
						}
					].map((cell) => {
						const x = 15 + cell.col * 72;
						const y = 15 + cell.row * 72;
						const cx = x + 32;
						const cy = y + 32;
						const isMissing = cell.shape === "missing";
						const fillStyle = cell.fill === "solid" ? "#a855f7" : cell.fill === "striped" ? "rgba(56,189,248,0.35)" : "none";
						const strokeColor = cell.fill === "solid" ? "#c084fc" : cell.fill === "striped" ? "#38bdf8" : "#f43f5e";
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x,
							y,
							width: "64",
							height: "64",
							rx: "10",
							fill: isMissing ? "rgba(99,102,241,0.18)" : "rgba(15,23,42,0.9)",
							stroke: isMissing ? "#818cf8" : "#475569",
							strokeWidth: "2",
							strokeDasharray: isMissing ? "4,3" : void 0
						}), isMissing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
							x: cx,
							y: cy + 8,
							textAnchor: "middle",
							fill: "#a5b4fc",
							fontSize: "24",
							fontWeight: "bold",
							children: "؟"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							cell.shape === "cir" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx,
								cy,
								r: "17",
								fill: fillStyle,
								stroke: strokeColor,
								strokeWidth: "2.5"
							}),
							cell.shape === "tri" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
								points: `${cx},${cy - 18} ${cx - 18},${cy + 15} ${cx + 18},${cy + 15}`,
								fill: fillStyle,
								stroke: strokeColor,
								strokeWidth: "2.5"
							}),
							cell.shape === "dia" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
								points: `${cx},${cy - 18} ${cx + 18},${cy} ${cx},${cy + 18} ${cx - 18},${cy}`,
								fill: fillStyle,
								stroke: strokeColor,
								strokeWidth: "2.5"
							}),
							cell.fill === "striped" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: cx - 10,
								y1: cy,
								x2: cx + 10,
								y2: cy,
								stroke: strokeColor,
								strokeWidth: "2"
							})
						] })] }, `${cell.row}_${cell.col}`);
					})
				}),
				matrixId === "raven_matrix_5" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					viewBox: "0 0 240 240",
					className: "w-48 h-48 sm:w-56 sm:h-56",
					children: [
						0,
						1,
						2
					].map((row) => [
						0,
						1,
						2
					].map((col) => {
						const x = 15 + col * 72;
						const y = 15 + row * 72;
						const cx = x + 32;
						const cy = y + 32;
						const isMissing = row === 2 && col === 2;
						const sides = 4 + col;
						const dots = 3 - row;
						const pts = Array.from({ length: sides }).map((_, i) => {
							const ang = i * 2 * Math.PI / sides - Math.PI / 2;
							return `${(cx + 20 * Math.cos(ang)).toFixed(1)},${(cy + 20 * Math.sin(ang)).toFixed(1)}`;
						}).join(" ");
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x,
							y,
							width: "64",
							height: "64",
							rx: "10",
							fill: isMissing ? "rgba(99,102,241,0.18)" : "rgba(15,23,42,0.9)",
							stroke: isMissing ? "#818cf8" : "#475569",
							strokeWidth: "2",
							strokeDasharray: isMissing ? "4,3" : void 0
						}), isMissing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
							x: cx,
							y: cy + 8,
							textAnchor: "middle",
							fill: "#a5b4fc",
							fontSize: "24",
							fontWeight: "bold",
							children: "؟"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
								points: pts,
								fill: "rgba(16,185,129,0.12)",
								stroke: "#10b981",
								strokeWidth: "2"
							}),
							dots === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx,
								cy,
								r: "3.5",
								fill: "#fbbf24"
							}),
							dots === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: cx - 6,
								cy,
								r: "3.5",
								fill: "#fbbf24"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: cx + 6,
								cy,
								r: "3.5",
								fill: "#fbbf24"
							})] }),
							dots === 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
									cx: cx - 7,
									cy: cy + 4,
									r: "3.2",
									fill: "#fbbf24"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
									cx: cx + 7,
									cy: cy + 4,
									r: "3.2",
									fill: "#fbbf24"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
									cx,
									cy: cy - 6,
									r: "3.2",
									fill: "#fbbf24"
								})
							] })
						] })] }, `${row}_${col}`);
					}))
				}),
				matrixId === "raven_matrix_6" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					viewBox: "0 0 240 240",
					className: "w-48 h-48 sm:w-56 sm:h-56",
					children: [
						0,
						1,
						2
					].map((row) => [
						0,
						1,
						2
					].map((col) => {
						const x = 15 + col * 72;
						const y = 15 + row * 72;
						const isMissing = row === 2 && col === 2;
						const cornerIdx = (row * 2 + col) % 4;
						const cornerCoords = [
							{
								px: x + 16,
								py: y + 16
							},
							{
								px: x + 48,
								py: y + 16
							},
							{
								px: x + 48,
								py: y + 48
							},
							{
								px: x + 16,
								py: y + 48
							}
						][cornerIdx];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x,
							y,
							width: "64",
							height: "64",
							rx: "10",
							fill: isMissing ? "rgba(99,102,241,0.18)" : "rgba(15,23,42,0.9)",
							stroke: isMissing ? "#818cf8" : "#475569",
							strokeWidth: "2",
							strokeDasharray: isMissing ? "4,3" : void 0
						}), isMissing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
							x: x + 32,
							y: y + 40,
							textAnchor: "middle",
							fill: "#a5b4fc",
							fontSize: "24",
							fontWeight: "bold",
							children: "؟"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: x + 12,
							y: y + 12,
							width: "40",
							height: "40",
							fill: "none",
							stroke: "#334155",
							strokeWidth: "1",
							strokeDasharray: "2,2"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: cornerCoords.px,
							cy: cornerCoords.py,
							r: "7",
							fill: "#f43f5e"
						})] })] }, `${row}_${col}`);
					}))
				})
			]
		});
	};
	const filteredAuditQuestions = (objResult?.questionReview || []).filter((item) => {
		if (auditFilter === "correct") return item.isCorrect;
		if (auditFilter === "incorrect") return !item.isCorrect;
		return true;
	});
	const currentViralShareTitle = isMultipleIntelligences ? "مشاركة نتيجة مختبر الذكاءات المتعددة" : `مشاركة نتيجة ${objResult?.batteryTitleAr || "اختبار الذكاء"}`;
	const currentViralShareCategory = isMultipleIntelligences ? "مقياس الذكاءات المتعددة • Gardner & McKenzie (45 سؤالاً)" : `${currentBatteryMeta.scientificScaleName} (30 سؤالاً)`;
	const currentViralShareText = isMultipleIntelligences && testResult ? `🧠 خضت مقياس الذكاءات المتعددة (45 سؤالاً • 9 ذكاءات) في منصة مِـرآة القـلوب:\n🥇 ذكائي المهيمن: ${INTELLIGENCE_CATEGORIES[testResult.primaryIntelligence].icon} ${INTELLIGENCE_CATEGORIES[testResult.primaryIntelligence].titleAr} (${testResult.categoryScores[testResult.primaryIntelligence].percentage}%)\n🥈 الثاني: ${INTELLIGENCE_CATEGORIES[testResult.topThree[1]].icon} ${INTELLIGENCE_CATEGORIES[testResult.topThree[1]].titleAr} (${testResult.categoryScores[testResult.topThree[1]].percentage}%)\n🥉 الثالث: ${INTELLIGENCE_CATEGORIES[testResult.topThree[2]].icon} ${INTELLIGENCE_CATEGORIES[testResult.topThree[2]].titleAr} (${testResult.categoryScores[testResult.topThree[2]].percentage}%)\nمعدل الذكاء الكلي: ${testResult.overallAverage}%` : objResult ? `🧠 خضت «${objResult.batteryTitleAr}» (30 سؤالاً معيارياً) في منصة مِـرآة القـلوب:\n🏆 التصنيف: ${objResult.classificationTitleAr}\n📊 الدرجة المعيارية: ${objResult.standardScore} (المئين ${objResult.percentileRank}%)\n✅ الإجابات الصحيحة: ${objResult.correctOrHighCount}/${objResult.totalQuestions} (${objResult.overallPercentage}%)\n🥇 البعد الأقوى: ${objResult.domainScores[0]?.domainTitleAr} (${objResult.domainScores[0]?.percentage}%)` : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		dir: isAr ? "rtl" : "ltr",
		className: `fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 backdrop-blur-md overflow-hidden ${isAr ? "text-right" : "text-left"} ${isLight ? "bg-slate-900/60" : "bg-black/90"}`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: {
				opacity: 0,
				scale: .96,
				y: 15
			},
			animate: {
				opacity: 1,
				scale: 1,
				y: 0
			},
			exit: {
				opacity: 0,
				scale: .96,
				y: 15
			},
			className: `w-full max-w-5xl h-[95vh] max-h-[920px] border rounded-3xl overflow-hidden shadow-2xl flex flex-col relative ${isLight ? "bg-slate-900 border-purple-400/40 text-white" : "bg-slate-950 border-purple-500/30 text-white"}`,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-3.5 sm:p-4 bg-gradient-to-r from-purple-950 via-slate-900 to-indigo-950 border-b border-white/10 flex items-center justify-between shrink-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-600 via-pink-600 to-cyan-500 p-0.5 shadow-md flex items-center justify-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-full h-full bg-[#120d24] rounded-[14px] flex items-center justify-center text-lg",
								children: "🧠"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-extrabold text-sm sm:text-base text-white font-['Alexandria']",
								children: isAr ? "مختبر مقاييس الذكاء والقدرات المعرفية الاستكشافي" : "Exploratory Cognitive & Intelligence Batteries Lab"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline text-[11px] text-purple-300",
								children: "Gardner • Raven • WAIS • Bar-On • MSCEIT • CogAT"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-gray-300",
							children: isAr ? "4 بطاريات علمية استكشافية (135 سؤالاً محكماً: 30 إلى 45 سؤالاً لكل اختبار) مع تحميل PDF مباشر" : "4 Exploratory Scientific Batteries (135 Validated Items) with Instant PDF Export"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [step === "test" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1.5 px-3 py-1 rounded-xl bg-black/40 border border-white/15 text-xs text-amber-300 font-mono font-bold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatTimer(timeLeftSeconds) })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: onClose,
							"aria-label": "إغلاق نافذة اختبار الذكاء",
							title: "إغلاق",
							className: "p-2 rounded-full bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white transition cursor-pointer",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-5 h-5" })
						})]
					})]
				}),
				step === "welcome" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 overflow-y-auto p-4 sm:p-7 space-y-6 custom-scrollbar max-w-5xl mx-auto w-full",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScientificClinicalDisclaimerBanner, { testType: "intelligence" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PsychometricAcademicIntro, {
							variant: "modal",
							focusScope: "intelligence"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-5 sm:p-6 rounded-3xl bg-gradient-to-r from-purple-950/70 via-slate-900 to-indigo-950/70 border border-purple-500/30 space-y-3 shadow-xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 text-xs font-bold text-purple-300",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-4 h-4 text-purple-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "منظومة التقييم السيكومتري والمعرفي الشامل (135 سؤالاً علمياً محكماً)" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-lg sm:text-2xl font-black text-white font-['Alexandria']",
									children: "اختر البطارية العلمية المعتمدة لاكتشاف بصمتك المعرفية والانفعالية بدقة 100%"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs sm:text-sm text-gray-300 leading-relaxed",
									children: [
										"تم بناء هذه البطاريات الأربع وفق المعايير السيكومترية العالمية: نظرية الذكاءات التسعة لـ ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "هوارد جاردنر وماكينزي (45 سؤالاً)" }),
										"، ومصفوفات ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "رافين المتتابعة ونموذج كاتل-هورن-كارول CHC لقياس الـ IQ (30 سؤالاً)" }),
										"، ومقياس ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "بار-أون وماير-سالوفي للذكاء العاطفي MSCEIT (30 سؤالاً)" }),
										"، وبطارية ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "CogAT & Wonderlic للقدرات المهنية (30 سؤالاً)" }),
										" مع تصحيح علمي تفصيلي وتصدير PDF مباشر."
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 sm:p-5 rounded-3xl bg-white/5 border border-white/10 space-y-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
								className: "text-xs font-black text-white flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "👤 ضبط المعيار السيكومتري والفئة العمرية:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] text-gray-400 font-normal",
									children: "(يُستخدم لمقارنة درجتك الخام بجدول المعايير العمرية Norm Tables)"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-gray-300 mb-1.5",
									children: "الجنس:"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setGender("male"),
										className: `p-2.5 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${gender === "male" ? "bg-blue-600/30 border-blue-500 text-blue-200 shadow-md" : "bg-black/30 border-white/10 text-gray-400 hover:text-white"}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "👨 ذكر" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setGender("female"),
										className: `p-2.5 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${gender === "female" ? "bg-pink-600/30 border-pink-500 text-pink-200 shadow-md" : "bg-black/30 border-white/10 text-gray-400 hover:text-white"}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "👩 أنثى" })
									})]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-gray-300 mb-1.5",
									children: "الفئة العمرية:"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-2 sm:grid-cols-4 gap-1.5",
									children: [
										{
											key: "12-17",
											label: "12-17 سنة"
										},
										{
											key: "18-29",
											label: "18-29 سنة"
										},
										{
											key: "30-49",
											label: "30-49 سنة"
										},
										{
											key: "50+",
											label: "50+ سنة"
										}
									].map((ag) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setAgeGroup(ag.key),
										className: `p-2 rounded-xl border text-[11px] text-center transition cursor-pointer font-bold ${ageGroup === ag.key ? "bg-purple-600/30 border-purple-500 text-purple-200 shadow-md" : "bg-black/30 border-white/10 text-gray-400 hover:text-white"}`,
										children: ag.label
									}, ag.key))
								})] })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center justify-between",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
									className: "text-sm font-black text-white flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "w-4 h-4 text-purple-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "البطاريات العلمية الأربع المعتمدة (إجمالي 135 سؤالاً):" })]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 md:grid-cols-2 gap-4",
								children: INTELLIGENCE_BATTERIES_CATALOG.map((bat) => {
									let savedProgressCount = 0;
									let hasSavedResult = false;
									let savedSummaryBadge = "";
									try {
										if (bat.id === "multiple_intelligences") {
											savedProgressCount = Object.keys(answers).length;
											if (testResult) {
												hasSavedResult = true;
												savedSummaryBadge = `${INTELLIGENCE_CATEGORIES[testResult.primaryIntelligence].titleAr} (${testResult.overallAverage}%)`;
											}
										} else {
											const rawAns = localStorage.getItem(`${STORAGE_OBJ_ANSWERS_KEY}${bat.id}`);
											if (rawAns) savedProgressCount = Object.keys(JSON.parse(rawAns)).length;
											const rawRes = localStorage.getItem(`${STORAGE_OBJ_RESULT_KEY}${bat.id}`);
											if (rawRes) {
												const parsedRes = JSON.parse(rawRes);
												hasSavedResult = true;
												savedSummaryBadge = `الدرجة ${parsedRes.standardScore} • الدقة ${parsedRes.overallPercentage}%`;
											}
										}
									} catch {}
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										onClick: () => handleSelectBattery(bat.id),
										className: "p-5 rounded-3xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-purple-400/50 transition cursor-pointer flex flex-col justify-between group shadow-lg",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-2.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-between text-xs text-slate-300",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-2xl",
														children: bat.icon
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "px-2.5 py-1 rounded-full bg-purple-500/15 border border-purple-500/30 text-purple-200 font-bold",
														children: [
															bat.questionCount,
															" سؤالاً · ",
															bat.recommendedMinutes,
															" دقيقة"
														]
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
													className: "font-black text-base text-white group-hover:text-purple-300 transition font-['Alexandria']",
													children: bat.titleAr
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs text-gray-300 leading-relaxed",
													children: bat.descriptionAr
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "text-[11px] text-purple-300 pt-1",
													children: ["المرجع العلمي: ", bat.theoristAr]
												}),
												hasSavedResult && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "p-2.5 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 flex items-center justify-between gap-2 text-[11px]",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-emerald-300 font-bold",
														children: ["✓ آخر نتيجة: ", savedSummaryBadge]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-1.5 shrink-0",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															type: "button",
															onClick: (e) => handleOpenSavedBatteryResult(e, bat.id),
															className: "px-2.5 py-1 rounded-lg bg-emerald-600/30 hover:bg-emerald-600/50 border border-emerald-400/40 text-emerald-100 font-bold cursor-pointer",
															children: "عرض النتيجة 📊"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															type: "button",
															onClick: (e) => handleDirectPDFForBattery(e, bat.id),
															className: "px-2.5 py-1 rounded-lg bg-indigo-600/40 hover:bg-indigo-600/60 border border-indigo-400/40 text-indigo-100 font-bold cursor-pointer",
															children: "PDF 📄"
														})]
													})]
												})
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "pt-4 mt-4 border-t border-white/10 flex items-center justify-between text-xs",
											children: [savedProgressCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-emerald-400 font-bold",
												children: [
													"محفوظ تلقائياً (",
													savedProgressCount,
													"/",
													bat.questionCount,
													" سؤالاً)"
												]
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-gray-400",
												children: [bat.questionCount, " سؤالاً معيارياً • حفظ فوري"]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-extrabold text-white group-hover:text-purple-300 flex items-center gap-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "معاينة التعليمات والبدء" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "w-4 h-4" })]
											})]
										})]
									}, bat.id);
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PsychometricAcademicConclusion, { variant: "modal" })
					]
				}),
				step === "instructions" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 overflow-y-auto p-5 sm:p-8 space-y-6 custom-scrollbar max-w-3xl mx-auto w-full",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => setStep("welcome"),
							className: "flex items-center gap-1.5 text-xs text-gray-400 hover:text-white transition cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "العودة لقائمة البطاريات الأربع" : "Back to All 4 Batteries" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScientificClinicalDisclaimerBanner, {
							testType: "intelligence",
							testTitleAr: currentBatteryMeta.titleAr,
							testTitleEn: currentBatteryMeta.scientificScaleName
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-6 rounded-3xl bg-gradient-to-br from-slate-900 via-purple-950/50 to-slate-900 border border-purple-500/40 space-y-4 shadow-2xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-xs text-purple-300",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: currentBatteryMeta.scientificScaleName }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "px-3 py-1 rounded-full bg-purple-500/20 border border-purple-400/30 font-bold",
										children: [
											totalQuestionsCount,
											" سؤالاً كاملاً · ",
											currentBatteryMeta.recommendedMinutes,
											" دقيقة"
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "text-xl sm:text-2xl font-black text-white font-['Alexandria']",
									children: [
										currentBatteryMeta.icon,
										" ",
										currentBatteryMeta.titleAr
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs sm:text-sm text-gray-300 leading-relaxed",
									children: currentBatteryMeta.descriptionAr
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-black/40 border border-white/10 space-y-2.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
										className: "text-xs font-black text-amber-300",
										children: [
											"📋 تعليمات الاختبار والمنهجية السيكومترية (",
											totalQuestionsCount,
											" سؤالاً):"
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
										className: "text-xs text-gray-200 space-y-2 list-disc list-inside leading-relaxed",
										children: [currentBatteryMeta.instructionsAr.map((inst, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: inst }, i)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
											"يمكنك التبديل أثناء الاختبار بين ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "عرض الصفحات (5 أسئلة)" }),
											" أو",
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [
												"عرض جميع الأسئلة الـ ",
												totalQuestionsCount,
												" في قائمة واحدة"
											] }),
											" أو التنقل عبر خريطة الأسئلة التفاعلية."
										] })]
									})]
								}),
								answeredCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 flex flex-col sm:flex-row items-center justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs text-emerald-200",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "💾 تم العثور على جلسة محفوظة تلقائياً:" }),
											" لقد أجبت مسبقاً على (",
											answeredCount,
											" من ",
											totalQuestionsCount,
											" سؤالاً). يمكنك استئناف الاختبار أو البدء من جديد."
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: handleResetBatteryAnswers,
										className: "px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-200 text-xs font-bold shrink-0 cursor-pointer",
										children: "مسح والبدء من الصفر"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "pt-3 flex flex-wrap items-center justify-between gap-3",
									children: [(isMultipleIntelligences && testResult || !isMultipleIntelligences && objResult) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => setStep("results"),
											className: "px-4 py-3 rounded-2xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs transition cursor-pointer",
											children: "عرض تقرير نتيجتي السابقة 📊"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: handleDownloadPDFReport,
											className: "px-4 py-3 rounded-2xl bg-indigo-600/30 hover:bg-indigo-600/50 border border-indigo-400/40 text-indigo-200 font-bold text-xs transition cursor-pointer flex items-center gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تحميل PDF 📄" })]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: handleStartTest,
										className: "px-8 py-3.5 rounded-2xl bg-gradient-to-r from-purple-600 via-pink-600 to-indigo-600 hover:opacity-95 text-white font-black text-xs sm:text-sm transition shadow-xl cursor-pointer flex items-center gap-2 mr-auto",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: answeredCount > 0 && answeredCount < totalQuestionsCount ? `استئناف الاختبار (${answeredCount}/${totalQuestionsCount})` : `بدء الاختبار الآن (${totalQuestionsCount} سؤالاً)` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "w-4 h-4" })]
									})]
								})
							]
						})
					]
				}),
				step === "test" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 flex flex-col overflow-hidden",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "px-4 py-2.5 bg-black/50 border-b border-white/10 space-y-2.5 shrink-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-2 text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-bold text-purple-300",
												children: currentBatteryMeta.titleAr
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-gray-500",
												children: "·"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-white font-bold",
												children: [
													"إجمالي الأسئلة: ",
													totalQuestionsCount,
													" سؤالاً"
												]
											}),
											runnerViewMode !== "all_list" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-gray-500",
												children: "·"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-amber-300 font-bold",
												children: [
													"صفحة ",
													safeCurrentPage + 1,
													" من ",
													totalPages
												]
											})] })
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-white/10",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => handleSwitchViewMode("paged_5"),
												className: `px-2.5 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer ${runnerViewMode === "paged_5" ? "bg-purple-600 text-white" : "text-gray-400 hover:text-white"}`,
												children: "5 أسئلة بالصفحة"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => handleSwitchViewMode("single_1"),
												className: `px-2.5 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer ${runnerViewMode === "single_1" ? "bg-purple-600 text-white" : "text-gray-400 hover:text-white"}`,
												children: "سؤال تلو الآخر"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => handleSwitchViewMode("all_list"),
												className: `px-2.5 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer ${runnerViewMode === "all_list" ? "bg-purple-600 text-white" : "text-gray-400 hover:text-white"}`,
												children: [
													"جميع الـ ",
													totalQuestionsCount,
													" سؤالاً"
												]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[11px] font-mono text-emerald-400 font-bold",
											children: [
												"تمت الإجابة: ",
												answeredCount,
												" / ",
												totalQuestionsCount,
												" (",
												progressPercent,
												"%)"
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-24 sm:w-32 h-2 bg-white/10 rounded-full overflow-hidden",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "h-full bg-gradient-to-r from-purple-500 to-emerald-400 rounded-full transition-all duration-300",
												style: { width: `${progressPercent}%` }
											})
										})]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1 overflow-x-auto pb-1 custom-scrollbar",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] text-gray-400 shrink-0 ml-1",
									children: "خريطة الأسئلة:"
								}), Array.from({ length: totalQuestionsCount }).map((_, idx) => {
									const qId = isMultipleIntelligences ? activeMIQuestions[idx]?.id : activeObjQuestions[idx]?.id;
									const isAnswered = isMultipleIntelligences ? answers[qId] !== void 0 : objAnswers[qId] !== void 0;
									const isOnCurrentPage = runnerViewMode !== "all_list" && idx >= safeCurrentPage * questionsPerPage && idx < (safeCurrentPage + 1) * questionsPerPage;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => handleJumpToQuestionIndex(idx),
										title: `الانتقال إلى السؤال ${idx + 1}`,
										className: `w-6 h-6 rounded-lg text-[10px] font-mono font-bold shrink-0 transition cursor-pointer flex items-center justify-center border ${isAnswered ? isOnCurrentPage ? "bg-emerald-500 text-slate-950 border-white shadow-sm" : "bg-emerald-500/25 text-emerald-300 border-emerald-500/40" : isOnCurrentPage ? "bg-purple-600 text-white border-purple-300 shadow-sm" : "bg-white/5 text-gray-400 border-white/10 hover:text-white"}`,
										children: idx + 1
									}, idx);
								})]
							})]
						}),
						unansweredWarning && remainingCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-4 mt-3 p-3.5 rounded-2xl bg-amber-950/90 border border-amber-500/50 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs text-amber-200 flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "w-4 h-4 text-amber-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "تنبيه دقة القياس:" }),
									" تبقى لديك (",
									remainingCount,
									") سؤالاً بدون إجابة من أصل (",
									totalQuestionsCount,
									"). للحصول على درجة معيارية ونسبة مئوية دقيقة 100% يُنصح بالإجابة على جميع الأسئلة."
								] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 shrink-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: handleJumpToFirstUnanswered,
									className: "px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs cursor-pointer",
									children: "الانتقال للسؤال غير المجاب ⬅"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => handleFinishTest(true),
									className: "px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs cursor-pointer",
									children: "إنهاء واحتساب النتيجة الحالية"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							ref: questionScrollRef,
							className: "flex-1 overflow-y-auto p-4 sm:p-6 space-y-5 custom-scrollbar max-w-4xl mx-auto w-full",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScientificClinicalDisclaimerBanner, {
								testType: "intelligence",
								testTitleAr: currentBatteryMeta.titleAr,
								testTitleEn: currentBatteryMeta.scientificScaleName,
								compact: true
							}), isMultipleIntelligences ? currentMIQuestionsPage.map((question, qIdx) => {
								const questionGlobalIdx = safeCurrentPage * questionsPerPage + qIdx + 1;
								const catMeta = INTELLIGENCE_CATEGORIES[question.category];
								const selectedVal = answers[question.id];
								const questionText = gender === "female" && question.femaleTextAr ? question.femaleTextAr : question.textAr;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
									id: `intel-q-card-${questionGlobalIdx}`,
									initial: {
										opacity: 0,
										y: 10
									},
									animate: {
										opacity: 1,
										y: 0
									},
									transition: { delay: Math.min(qIdx * .02, .2) },
									className: `p-4 sm:p-5 rounded-3xl border transition space-y-3 ${selectedVal !== void 0 ? "bg-emerald-950/15 border-emerald-500/30" : "bg-white/5 border-white/10 hover:border-purple-500/30"}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-xs text-slate-400",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "px-2.5 py-0.5 rounded-lg bg-purple-500/20 border border-purple-500/30 font-mono font-bold text-purple-200",
														children: [
															"السؤال ",
															questionGlobalIdx,
															" من ",
															totalQuestionsCount
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														style: { color: catMeta.color },
														children: [
															catMeta.icon,
															" ",
															catMeta.titleAr
														]
													})
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[11px] text-gray-400",
												children: question.situationContextAr
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
											className: "text-sm sm:text-base font-extrabold text-white leading-relaxed font-['Alexandria']",
											children: [
												"«",
												questionText,
												"»"
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "grid grid-cols-1 sm:grid-cols-5 gap-2 pt-1",
											children: LIKERT_OPTIONS.map((opt) => {
												const isChosen = selectedVal === opt.value;
												return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													onClick: () => handleSelectMIAnswer(question.id, opt.value),
													className: `p-2.5 rounded-2xl border text-center transition cursor-pointer flex sm:flex-col items-center justify-between sm:justify-center gap-1.5 ${isChosen ? "bg-gradient-to-r sm:bg-gradient-to-b from-purple-600/40 to-pink-600/40 border-purple-400 text-white shadow-lg" : "bg-black/30 border-white/10 text-gray-400 hover:text-white hover:bg-white/5"}`,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-1.5 sm:gap-1",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-sm",
															children: opt.icon
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "text-xs font-bold",
															children: [
																opt.labelAr.split(" ")[0],
																" ",
																opt.labelAr.split(" ")[1] || ""
															]
														})]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-[10px] opacity-75 font-mono",
														children: [
															"(",
															opt.value,
															" درجات)"
														]
													})]
												}, opt.value);
											})
										})
									]
								}, question.id);
							}) : currentObjQuestionsPage.map((question, qIdx) => {
								const selectedOptId = objAnswers[question.id];
								const diffLabel = question.difficulty === 3 ? "مستوى متقدم ★★★" : question.difficulty === 2 ? "مستوى متوسط ★★" : "مستوى تأسيسي ★";
								const optionLetters = [
									"أ",
									"ب",
									"ج",
									"د"
								];
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
									id: `intel-q-card-${question.questionNumber}`,
									initial: {
										opacity: 0,
										y: 10
									},
									animate: {
										opacity: 1,
										y: 0
									},
									transition: { delay: Math.min(qIdx * .02, .2) },
									className: `p-4 sm:p-5 rounded-3xl border transition space-y-3 ${selectedOptId !== void 0 ? "bg-emerald-950/15 border-emerald-500/30" : "bg-white/5 border-white/10 hover:border-purple-500/30"}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-xs text-slate-400",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "px-2.5 py-0.5 rounded-lg bg-purple-500/20 border border-purple-500/30 font-mono font-bold text-purple-200",
														children: [
															"السؤال ",
															question.questionNumber,
															" من ",
															totalQuestionsCount
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-sky-300",
														children: question.domainTitleAr
													})
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[11px] text-amber-300 font-bold",
												children: diffLabel
											})]
										}),
										renderRavenMatrixVisual(question.matrixVisualId),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "text-sm sm:text-base font-extrabold text-white leading-relaxed font-['Alexandria']",
											children: question.promptAr
										}),
										question.subPromptAr && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-purple-300",
											children: question.subPromptAr
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1",
											children: question.options.map((opt, optIndex) => {
												const isChosen = selectedOptId === opt.id;
												return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													onClick: () => handleSelectObjAnswer(question.id, opt.id),
													className: `p-3.5 rounded-2xl border text-right transition cursor-pointer flex items-center justify-between gap-2.5 ${isChosen ? "bg-gradient-to-r from-purple-600/35 to-indigo-600/35 border-purple-400 text-white shadow-md" : "bg-black/30 border-white/10 text-gray-300 hover:text-white hover:bg-white/5"}`,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-2.5",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: `w-6 h-6 rounded-lg text-xs font-bold flex items-center justify-center shrink-0 ${isChosen ? "bg-purple-500 text-white" : "bg-white/10 text-gray-300"}`,
															children: optionLetters[optIndex] || optIndex + 1
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-xs sm:text-sm font-bold leading-relaxed",
															children: opt.labelAr
														})]
													}), isChosen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-4 h-4 text-emerald-400 shrink-0" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-4 h-4 rounded-full border border-white/25 shrink-0" })]
												}, opt.id);
											})
										})
									]
								}, question.id);
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 bg-slate-950 border-t border-white/10 flex items-center justify-between gap-3 shrink-0",
							children: [
								runnerViewMode !== "all_list" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									disabled: safeCurrentPage === 0,
									onClick: handlePrevPage,
									className: `px-4 py-2.5 rounded-xl border text-xs font-bold transition flex items-center gap-1.5 ${safeCurrentPage === 0 ? "opacity-30 cursor-not-allowed border-white/5 text-gray-500" : "bg-white/5 hover:bg-white/10 border-white/10 text-white cursor-pointer"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: runnerViewMode === "single_1" ? "السؤال السابق" : "الصفحة السابقة" })]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-emerald-300 font-bold",
									children: [
										"أنت تستعرض جميع الأسئلة الـ ",
										totalQuestionsCount,
										" كاملة"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setStep("welcome"),
									className: "text-xs text-gray-400 hover:text-white transition cursor-pointer",
									children: "حفظ والخروج المؤقت للقائمة"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: handleNextPage,
									className: "px-6 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 via-pink-600 to-indigo-600 hover:opacity-95 text-white font-extrabold text-xs transition shadow-lg shadow-purple-600/25 flex items-center gap-1.5 cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: safeCurrentPage < totalPages - 1 ? runnerViewMode === "single_1" ? `السؤال التالي (${safeCurrentPage + 2}/${totalPages})` : `الصفحة التالية (${safeCurrentPage + 2}/${totalPages})` : `إنهاء واستخراج التقرير الشامل (${answeredCount}/${totalQuestionsCount}) 📊` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "w-4 h-4" })]
								})
							]
						})
					]
				}),
				step === "results" && isMultipleIntelligences && testResult && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 overflow-y-auto p-4 sm:p-7 space-y-6 custom-scrollbar max-w-5xl mx-auto w-full",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-5 sm:p-6 rounded-3xl bg-gradient-to-r from-purple-950/80 via-slate-900 to-indigo-950/80 border border-purple-500/30 flex flex-col md:flex-row items-center justify-between gap-5 shadow-2xl",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2 text-center md:text-right",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center justify-center md:justify-start gap-2 text-xs text-emerald-300",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تقرير معتمد وفق مقياس جاردنر وماكينزي (9 ذكاءات • 45 سؤالاً)" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-gray-300",
												children: [
													"المعدل الكلي: ",
													testResult.overallAverage,
													"%"
												]
											}),
											testResult.answeredCount !== void 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-purple-300",
												children: [
													"الأسئلة المجابة: ",
													testResult.answeredCount,
													"/",
													testResult.totalQuestions || 45
												]
											})] })
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
										className: "text-lg sm:text-2xl font-black text-white font-['Alexandria']",
										children: [
											"ذكائك المهيمن هو:",
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-400 to-rose-400",
												children: INTELLIGENCE_CATEGORIES[testResult.primaryIntelligence].titleAr
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-gray-300 max-w-xl leading-relaxed",
										children: buildExecutiveSummaryText(`${testResult.overallAverage}%`, INTELLIGENCE_CATEGORIES[testResult.topThree[1]].titleAr, INTELLIGENCE_CATEGORIES[testResult.primaryIntelligence].titleAr)
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2 justify-center shrink-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: handleDownloadPDFReport,
										className: "px-4 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition shadow-lg flex items-center gap-1.5 cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تحميل التقرير PDF 📄" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: handleSaveToProfile,
										className: "px-4 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:opacity-95 text-white font-bold text-xs transition shadow-lg flex items-center gap-1.5 cursor-pointer",
										children: [isSavedToProfile ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isSavedToProfile ? "تم الحفظ ✓" : "حفظ بملفي" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setIsViralShareOpen(true),
										className: "px-4 py-2.5 rounded-2xl bg-gradient-to-r from-rose-600 to-pink-600 hover:opacity-95 text-white font-bold text-xs transition shadow-lg flex items-center gap-1.5 cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "مشاركة" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => setStep("welcome"),
										className: "p-2.5 rounded-2xl bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white transition border border-white/10 cursor-pointer",
										title: "العودة للبطاريات",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "w-4 h-4" })
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 lg:grid-cols-12 gap-5 items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "lg:col-span-6 p-4 rounded-3xl bg-white/5 border border-white/10 flex flex-col items-center justify-center shadow-lg",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "w-full flex items-center justify-between pb-2 mb-2 border-b border-white/10 text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-extrabold text-white",
										children: "الرسم البياني الراداري للذكاءات التسعة"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[11px] text-purple-300",
										children: "انقر على أي زاوية للتفصيل"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntelligenceRadarChart, {
									scores: testResult.categoryScores,
									highlightCategory: activeCategoryDetail,
									onSelectCategory: (cat) => setActiveCategoryDetail(cat)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "lg:col-span-6 space-y-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
									className: "text-xs font-black text-white flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "w-4 h-4 text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "ترتيب الذكاءات التسعة من الأعلى إلى الأقل:" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-2 max-h-[340px] overflow-y-auto pr-1 custom-scrollbar",
									children: Object.keys(INTELLIGENCE_CATEGORIES).sort((a, b) => testResult.categoryScores[b].percentage - testResult.categoryScores[a].percentage).map((cat, idx) => {
										const meta = INTELLIGENCE_CATEGORIES[cat];
										const score = testResult.categoryScores[cat];
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											onClick: () => setActiveCategoryDetail(cat),
											className: `p-3 rounded-2xl border transition cursor-pointer ${activeCategoryDetail === cat ? "bg-purple-600/20 border-purple-400 shadow-md" : "bg-white/5 border-white/10 hover:border-white/20"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between mb-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-2",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "text-xs font-mono text-slate-400",
															children: ["#", idx + 1]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: meta.icon }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "font-extrabold text-xs sm:text-sm text-white",
															children: meta.titleAr
														})
													]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "font-mono font-black text-xs text-rose-400",
													children: [
														score.percentage,
														"% (",
														score.rawScore,
														"/25)"
													]
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "w-full h-1.5 bg-black/40 rounded-full overflow-hidden",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: `h-full bg-gradient-to-r ${meta.gradient} rounded-full`,
													style: { width: `${score.percentage}%` }
												})
											})]
										}, cat);
									})
								})]
							})]
						}),
						activeCategoryDetail && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-5 sm:p-6 rounded-3xl bg-white/5 border border-purple-500/30 space-y-5 shadow-xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center justify-between pb-3 border-b border-white/10",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-2xl",
											children: INTELLIGENCE_CATEGORIES[activeCategoryDetail].icon
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
											className: "font-black text-white text-base font-['Alexandria']",
											children: [
												"التحليل العميق لـ ",
												INTELLIGENCE_CATEGORIES[activeCategoryDetail].titleAr,
												" (",
												testResult.categoryScores[activeCategoryDetail].percentage,
												"%)"
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] text-gray-400",
											children: INTELLIGENCE_CATEGORIES[activeCategoryDetail].scientificFoundationAr
										})] })]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-1 sm:grid-cols-3 gap-3",
									children: INTELLIGENCE_CATEGORIES[activeCategoryDetail].subSkills.map((sub) => {
										const subScore = testResult.subSkillScores[sub.key] || { percentage: 0 };
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-3.5 rounded-2xl bg-black/40 border border-white/10 space-y-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-between",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "font-bold text-xs text-white",
														children: sub.titleAr
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "font-mono font-black text-xs text-purple-400",
														children: [subScore.percentage, "%"]
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-[11px] text-gray-300 leading-relaxed",
													children: sub.descriptionAr
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "w-full h-1.5 bg-black/60 rounded-full overflow-hidden",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full",
														style: { width: `${subScore.percentage}%` }
													})
												})
											]
										}, sub.key);
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 md:grid-cols-2 gap-4 pt-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-4 rounded-2xl bg-indigo-950/20 border border-indigo-500/25 space-y-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h5", {
												className: "text-xs font-black text-indigo-300 flex items-center gap-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "w-4 h-4 text-indigo-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "المهن والوظائف الأنسب لهذا الذكاء:" })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
												className: "text-xs text-gray-300 space-y-1.5 pr-2 list-disc list-inside",
												children: INTELLIGENCE_CATEGORIES[activeCategoryDetail].suggestedCareersAr.map((career, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: career }, i))
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-4 rounded-2xl bg-emerald-950/20 border border-emerald-500/25 space-y-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h5", {
												className: "text-xs font-black text-emerald-300 flex items-center gap-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "w-4 h-4 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "طرق الدراسة والتعلم المثلى:" })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
												className: "text-xs text-gray-300 space-y-1.5 pr-2 list-disc list-inside",
												children: INTELLIGENCE_CATEGORIES[activeCategoryDetail].optimalLearningStylesAr.map((style, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: style }, i))
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-4 rounded-2xl bg-rose-950/20 border border-rose-500/25 space-y-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h5", {
												className: "text-xs font-black text-rose-300 flex items-center gap-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "w-4 h-4 text-rose-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "نقاط الضعف والتحديات المحتملة:" })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
												className: "text-xs text-gray-300 space-y-1.5 pr-2 list-disc list-inside",
												children: INTELLIGENCE_CATEGORIES[activeCategoryDetail].weaknessAndRisksAr.map((risk, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: risk }, i))
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-4 rounded-2xl bg-amber-950/20 border border-amber-500/25 space-y-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h5", {
												className: "text-xs font-black text-amber-300 flex items-center gap-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lightbulb, { className: "w-4 h-4 text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تمارين عملية لتطوير وتنمية هذا الذكاء:" })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
												className: "text-xs text-gray-300 space-y-1.5 pr-2 list-disc list-inside",
												children: INTELLIGENCE_CATEGORIES[activeCategoryDetail].developmentExercisesAr.map((exercise, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: exercise }, i))
											})]
										})
									]
								})
							]
						})
					]
				}),
				step === "results" && !isMultipleIntelligences && objResult && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 overflow-y-auto p-4 sm:p-7 space-y-6 custom-scrollbar max-w-5xl mx-auto w-full",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-5 sm:p-6 rounded-3xl bg-gradient-to-r from-indigo-950/80 via-slate-900 to-purple-950/80 border border-indigo-500/35 flex flex-col md:flex-row items-center justify-between gap-5 shadow-2xl",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2 text-center md:text-right",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center justify-center md:justify-start gap-2 text-xs text-sky-300",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: objResult.batteryTitleAr }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["الدرجة المعيارية: ", objResult.standardScore] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
												"المئين: ",
												objResult.percentileRank,
												"%"
											] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-emerald-300",
												children: [
													"الإجابات الصحيحة: ",
													objResult.correctOrHighCount,
													"/",
													objResult.totalQuestions
												]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-lg sm:text-2xl font-black text-white font-['Alexandria']",
										children: objResult.classificationTitleAr
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-gray-300 max-w-2xl leading-relaxed",
										children: objResult.executiveSummaryAr
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2 justify-center shrink-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: handleDownloadPDFReport,
										className: "px-4 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition shadow-lg flex items-center gap-1.5 cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تحميل التقرير PDF 📄" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: handleSaveToProfile,
										className: "px-4 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition shadow-lg flex items-center gap-1.5 cursor-pointer",
										children: [isSavedToProfile ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isSavedToProfile ? "تم الحفظ ✓" : "حفظ بملفي" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setIsViralShareOpen(true),
										className: "px-4 py-2.5 rounded-2xl bg-gradient-to-r from-rose-600 to-pink-600 hover:opacity-95 text-white font-bold text-xs transition shadow-lg flex items-center gap-1.5 cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "مشاركة" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setStep("welcome"),
										className: "px-4 py-2.5 rounded-2xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs transition cursor-pointer flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "اختبار آخر" })]
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 sm:grid-cols-5 gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-white/5 border border-white/10 text-center",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[11px] text-gray-400",
											children: "الدرجة المعيارية (IQ/EQ)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-2xl font-black text-purple-400 font-mono mt-1",
											children: objResult.standardScore
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[10px] text-gray-500 mt-0.5",
											children: "المتوسط المعياري: 100"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-white/5 border border-white/10 text-center",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[11px] text-gray-400",
											children: "الترتيب المئيني (Percentile)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-2xl font-black text-emerald-400 font-mono mt-1",
											children: [objResult.percentileRank, "%"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-[10px] text-gray-500 mt-0.5",
											children: [
												"أعلى من ",
												objResult.percentileRank,
												"% من العينة"
											]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-white/5 border border-white/10 text-center",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[11px] text-gray-400",
											children: "الإجابات الصحيحة"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-2xl font-black text-teal-400 font-mono mt-1",
											children: [
												objResult.correctOrHighCount,
												"/",
												objResult.totalQuestions
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-[10px] text-gray-500 mt-0.5",
											children: [
												"دقة مباشرة: ",
												objResult.accuracyPercentage ?? objResult.overallPercentage,
												"%"
											]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-white/5 border border-white/10 text-center",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[11px] text-gray-400",
											children: "النسبة الموزونة بالصعوبة"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-2xl font-black text-sky-400 font-mono mt-1",
											children: [objResult.overallPercentage, "%"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[10px] text-gray-500 mt-0.5",
											children: "موزونة بمعامل صعوبة الأسئلة"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-white/5 border border-white/10 text-center col-span-2 sm:col-span-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[11px] text-gray-400",
											children: "الزمن المستغرق"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-2xl font-black text-amber-400 font-mono mt-1",
											children: formatTimer(objResult.timeSpentSeconds)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-[10px] text-gray-500 mt-0.5",
											children: [
												"من أصل ",
												currentBatteryMeta.recommendedMinutes,
												":00 دقيقة"
											]
										})
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-5 rounded-3xl bg-white/5 border border-white/10 space-y-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
								className: "text-sm font-black text-white flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, { className: "w-4 h-4 text-purple-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تحليل الأبعاد المعرفية والفرعية للبطارية:" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 md:grid-cols-2 gap-4",
								children: objResult.domainScores.map((dom) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-black/40 border border-white/10 space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-bold text-white",
												children: dom.domainTitleAr
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-mono font-bold",
												style: { color: dom.color },
												children: [
													dom.percentage,
													"% (",
													dom.correctCount ?? 0,
													"/",
													dom.totalCount ?? 6,
													") · ",
													dom.levelAr
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-full h-2 bg-white/10 rounded-full overflow-hidden",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "h-full rounded-full",
												style: {
													width: `${dom.percentage}%`,
													backgroundColor: dom.color
												}
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] text-gray-300 leading-relaxed",
											children: dom.interpretationAr
										})
									]
								}, dom.domainKey))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 md:grid-cols-3 gap-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-emerald-950/20 border border-emerald-500/30 space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
										className: "text-xs font-black text-emerald-300",
										children: "✨ أبرز نقاط القوة:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "text-xs text-gray-300 space-y-1.5 list-disc list-inside",
										children: objResult.strengthsAr.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: s }, i))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-amber-950/20 border border-amber-500/30 space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
										className: "text-xs font-black text-amber-300",
										children: "💡 توصيات التطوير الذاتي:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "text-xs text-gray-300 space-y-1.5 list-disc list-inside",
										children: objResult.growthRecommendationsAr.map((g, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: g }, i))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-indigo-950/20 border border-indigo-500/30 space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
										className: "text-xs font-black text-indigo-300",
										children: "💼 المسارات المهنية الملائمة:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "text-xs text-gray-300 space-y-1.5 list-disc list-inside",
										children: objResult.suggestedCareersAr.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: c }, i))
									})]
								})
							]
						}),
						objResult.questionReview && objResult.questionReview.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-5 rounded-3xl bg-white/5 border border-purple-500/30 space-y-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListChecks, { className: "w-5 h-5 text-purple-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
										className: "text-sm font-black text-white",
										children: [
											"مراجعة الإجابات ومفتاح الحل العلمي المحكّم (",
											objResult.totalQuestions,
											" سؤالاً)"
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[11px] text-gray-400",
										children: "كشف تفصيلي شفاف لكل سؤال وإجابتك عليه مقارنة بالإجابة العلمية المعتمدة مع شرح القاعدة"
									})] })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-white/10 text-[11px]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => setAuditFilter("all"),
												className: `px-2.5 py-1 rounded-lg font-bold cursor-pointer ${auditFilter === "all" ? "bg-purple-600 text-white" : "text-gray-400 hover:text-white"}`,
												children: [
													"الكل (",
													objResult.questionReview.length,
													")"
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => setAuditFilter("correct"),
												className: `px-2.5 py-1 rounded-lg font-bold cursor-pointer ${auditFilter === "correct" ? "bg-emerald-600 text-white" : "text-gray-400 hover:text-white"}`,
												children: [
													"الصحيحة (",
													objResult.questionReview.filter((q) => q.isCorrect).length,
													")"
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => setAuditFilter("incorrect"),
												className: `px-2.5 py-1 rounded-lg font-bold cursor-pointer ${auditFilter === "incorrect" ? "bg-rose-600 text-white" : "text-gray-400 hover:text-white"}`,
												children: [
													"الخاطئة (",
													objResult.questionReview.filter((q) => !q.isCorrect).length,
													")"
												]
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setShowQuestionAudit((prev) => !prev),
										className: "px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-bold text-white cursor-pointer",
										children: showQuestionAudit ? "طي القائمة" : "عرض القائمة"
									})]
								})]
							}), showQuestionAudit && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-2.5 max-h-[420px] overflow-y-auto pr-1 custom-scrollbar",
								children: filteredAuditQuestions.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `p-3.5 rounded-2xl border text-xs space-y-2 ${item.isCorrect ? "bg-emerald-950/15 border-emerald-500/30" : "bg-rose-950/15 border-rose-500/30"}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: `px-2 py-0.5 rounded-md font-mono font-bold ${item.isCorrect ? "bg-emerald-500/20 text-emerald-300" : "bg-rose-500/20 text-rose-300"}`,
													children: [
														"سؤال ",
														item.questionNumber,
														" ",
														item.isCorrect ? "✓ إجابة صحيحة" : "✗ إجابة غير دقيقة"
													]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-sky-300 font-bold",
													children: item.domainTitleAr
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-mono text-[11px] text-gray-400",
												children: [
													"الدرجة: ",
													item.scoreEarned,
													"/100"
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-bold text-white leading-relaxed",
											children: item.promptAr
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-2 rounded-xl bg-black/40 border border-white/10",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-gray-400 block text-[10px]",
													children: "إجابتك المختارة:"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: `font-bold ${item.isCorrect ? "text-emerald-300" : "text-rose-300"}`,
													children: item.selectedLabelAr
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-2 rounded-xl bg-black/40 border border-emerald-500/25",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-gray-400 block text-[10px]",
													children: "الإجابة العلمية المعتمدة:"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-bold text-emerald-300",
													children: item.correctLabelAr
												})]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-[11px] text-indigo-200 bg-indigo-950/30 border border-indigo-500/20 rounded-xl p-2 flex items-start gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleQuestionMark, { className: "w-3.5 h-3.5 text-indigo-400 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "التفسير العلمي:" }),
												" ",
												item.explanationAr
											] })]
										})
									]
								}, item.questionNumber))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PsychometricAcademicConclusion, { variant: "modal" })
					]
				}),
				(testResult || objResult) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ViralShareModal, {
					isOpen: isViralShareOpen,
					onClose: () => setIsViralShareOpen(false),
					titleAr: currentViralShareTitle,
					shareText: currentViralShareText,
					categoryTagAr: currentViralShareCategory
				})
			]
		})
	});
};
//#endregion
export { IntelligenceTestModal };
