import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { An as BookOpen, C as Stethoscope, D as Sparkles, I as Share2, Mn as Award, Nn as ArrowRight, Rt as GraduationCap, S as Sun, Sn as Calendar, St as ListChecks, V as Search, Wt as FileText, Xt as ExternalLink, Z as Quote, _n as ChevronRight, bn as Check, cn as Clock, jn as BookMarked, r as X, st as Moon } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import { d as useAppTheme, l as useLanguage } from "./index-C5uCeetQ.js";
import { n as AnimatePresence, t as motion } from "./vendor-motion-BS7ODJw7.js";
import { a as ARTICLES_CATALOG, c as PLATFORM_INTRODUCTORY_ARTICLES, d as PDF_FOUR_NARRATIVE_ARTICLES, i as getFullContinuousAcademicText, l as EMOTIONAL_IQ_NARRATIVE_ARTICLES, o as getFullContinuousNarrativeText, r as ACADEMIC_PAPERS_CATALOG, s as CLINICAL_CHILDHOOD_ANXIETY_NARRATIVE_ARTICLES, u as RELATIONSHIP_FOUR_NARRATIVE_ARTICLES } from "./data-content-CCe8WBeA.js";
import { n as ReaderToolbar, t as FormattedContinuousManuscript } from "./ReaderToolbar-CBKPy1tK.js";
import { t as ArticleBottomSocialShare } from "./FullScreenResearchStudyModal-CzFzUkbF.js";
//#region src/components/ArticlesSectionModal.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var ArticlesSectionModal = ({ isOpen, onClose, initialArticleId, onOpenStandalonePage }) => {
	const { language, isRTL, toggleLanguage } = useLanguage();
	const [theme, toggleTheme] = useAppTheme();
	const isLight = theme === "light";
	const [activeTrack, setActiveTrack] = (0, import_react.useState)("narrative");
	const [selectedCategory, setSelectedCategory] = (0, import_react.useState)("all");
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [activeNarrative, setActiveNarrative] = (0, import_react.useState)(() => {
		if (initialArticleId) return ARTICLES_CATALOG.find((a) => a.id === initialArticleId) || null;
		return null;
	});
	const [activeAcademic, setActiveAcademic] = (0, import_react.useState)(() => {
		if (initialArticleId) return ACADEMIC_PAPERS_CATALOG.find((p) => p.id === initialArticleId) || null;
		return null;
	});
	const [copiedShare, setCopiedShare] = (0, import_react.useState)(false);
	const [copiedFullText, setCopiedFullText] = (0, import_react.useState)(false);
	const [copiedStoryFullText, setCopiedStoryFullText] = (0, import_react.useState)(false);
	const [readerFontSize, setReaderFontSize] = (0, import_react.useState)(17);
	const [readerViewMode, setReaderViewMode] = (0, import_react.useState)("segmented_and_continuous");
	const handleCopyFullText = (paper) => {
		soundManager.playTap();
		const fullText = getFullContinuousAcademicText(paper, language);
		if (navigator.clipboard) {
			navigator.clipboard.writeText(fullText);
			setCopiedFullText(true);
			setTimeout(() => setCopiedFullText(false), 2600);
		}
	};
	const handleCopyStoryFullText = (article) => {
		soundManager.playTap();
		const fullText = getFullContinuousNarrativeText(article, language);
		if (navigator.clipboard) {
			navigator.clipboard.writeText(fullText);
			setCopiedStoryFullText(true);
			setTimeout(() => setCopiedStoryFullText(false), 2600);
		}
	};
	if (!isOpen) return null;
	const categories = [
		{
			key: "all",
			labelAr: "جميع التخصصات",
			labelEn: "All Specialties",
			icon: "✨"
		},
		{
			key: "relationships",
			labelAr: "عيادة العلاقات والزواج",
			labelEn: "Relationships & Marriage",
			icon: "💑"
		},
		{
			key: "applied_psychology",
			labelAr: "علم النفس التطبيقي والعصبي",
			labelEn: "Applied & Neuro-Psychology",
			icon: "🧠"
		},
		{
			key: "self_growth",
			labelAr: "الهوية والاحتراق المبكر",
			labelEn: "Identity & Burnout Recovery",
			icon: "🌱"
		},
		{
			key: "emotional_iq",
			labelAr: "الذكاء العاطفي والتواصل",
			labelEn: "Emotional Intelligence (EQ)",
			icon: "🎯"
		}
	];
	const q = searchQuery.trim().toLowerCase();
	const filteredNarrativeArticles = ARTICLES_CATALOG.filter((art) => {
		const matchesCategory = selectedCategory === "all" || art.category === selectedCategory;
		const matchesQuery = !q || art.title.toLowerCase().includes(q) || art.titleEn.toLowerCase().includes(q) || art.summary.toLowerCase().includes(q) || art.summaryEn.toLowerCase().includes(q) || art.scientificFramework.toLowerCase().includes(q) || art.scientificFrameworkEn.toLowerCase().includes(q);
		return matchesCategory && matchesQuery;
	});
	const filteredAcademicPapers = ACADEMIC_PAPERS_CATALOG.filter((paper) => {
		const matchesCategory = selectedCategory === "all" || paper.category === selectedCategory;
		const matchesQuery = !q || paper.titleAr.toLowerCase().includes(q) || paper.titleEn.toLowerCase().includes(q) || paper.abstractAr.toLowerCase().includes(q) || paper.abstractEn.toLowerCase().includes(q) || paper.keywordsAr.some((k) => k.toLowerCase().includes(q)) || paper.keywordsEn.some((k) => k.toLowerCase().includes(q));
		return matchesCategory && matchesQuery;
	});
	const handleBackToList = () => {
		soundManager.playTap();
		setActiveNarrative(null);
		setActiveAcademic(null);
	};
	const handleShareContent = (title, summary) => {
		soundManager.playTap();
		const textToShare = `📖 ${title}\n${summary}\nhttps://miratalqulub.com/#/articles`;
		if (navigator.clipboard) {
			navigator.clipboard.writeText(textToShare);
			setCopiedShare(true);
			setTimeout(() => setCopiedShare(false), 2400);
		}
	};
	const isReading = Boolean(activeNarrative || activeAcademic);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-md overflow-hidden",
		dir: isRTL ? "rtl" : "ltr",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: {
				opacity: 0,
				scale: .96,
				y: 15
			},
			animate: {
				opacity: 1,
				scale: 1,
				y: 0
			},
			exit: {
				opacity: 0,
				scale: .96,
				y: 15
			},
			className: `w-full max-w-5xl h-[93vh] max-h-[890px] rounded-3xl overflow-hidden shadow-2xl flex flex-col relative border transition-colors ${isLight ? "bg-slate-50 border-slate-300 text-slate-900" : "bg-slate-950 border-purple-500/30 text-white"}`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `p-4 sm:p-5 border-b flex items-center justify-between shrink-0 ${isLight ? "bg-gradient-to-r from-indigo-50 via-white to-rose-50 border-slate-200" : "bg-gradient-to-r from-purple-950 via-slate-900 to-indigo-950 border-white/10"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-11 h-11 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-rose-500 flex items-center justify-center text-xl shadow-lg shadow-purple-500/25 shrink-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "w-5 h-5 text-white" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 flex-wrap",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: `text-base sm:text-lg font-black font-['Alexandria'] ${isLight ? "text-slate-900" : "text-white"}`,
							children: language === "ar" ? "موسوعة مرآة القلوب للمقالات والأبحاث النفسية" : "Mirror of Hearts Clinical & Academic Encyclopedia"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-600 dark:text-emerald-300 text-[10px] font-bold border border-emerald-500/30",
							children: language === "ar" ? "مراجع علمية موثقة APA 7th" : "APA 7th Peer-Reviewed"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: `text-[11px] mt-0.5 ${isLight ? "text-slate-600" : "text-gray-300"}`,
						children: language === "ar" ? "فصل برمجي وعلمي دقيق بين المقالات القصصية العيادية والأبحاث الأكاديمية المحكّمة" : "Distinct tracks for Clinical Narrative Case Articles & Full Academic Research Papers"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								soundManager.playTap();
								toggleTheme();
							},
							className: `px-3 py-1.5 rounded-xl text-xs font-bold border transition cursor-pointer flex items-center gap-1.5 ${isLight ? "bg-amber-50 hover:bg-amber-100 text-amber-900 border-amber-300" : "bg-white/10 hover:bg-white/20 text-amber-300 border-white/15"}`,
							title: language === "ar" ? "تبديل الوضع الليلي / النهاري" : "Toggle Dark / Light Mode",
							children: [isLight ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline",
								children: isLight ? language === "ar" ? "ليلي" : "Dark" : language === "ar" ? "نهاري" : "Light"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								soundManager.playTap();
								toggleLanguage();
							},
							className: `px-3 py-1.5 rounded-xl text-xs font-bold border transition cursor-pointer ${isLight ? "bg-white hover:bg-slate-100 text-slate-800 border-slate-300" : "bg-white/10 hover:bg-white/20 text-white border-white/15"}`,
							title: language === "ar" ? "Switch to English" : "التبديل إلى العربية",
							children: language === "ar" ? "EN 🇬🇧" : "عربي 🇸🇦"
						}),
						onOpenStandalonePage && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundManager.playTap();
								onClose();
								onOpenStandalonePage();
							},
							className: `hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition cursor-pointer ${isLight ? "bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border-indigo-200" : "bg-indigo-500/15 hover:bg-indigo-500/25 text-indigo-300 border-indigo-500/30"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "فتح كصفحة كاملة" : "Full Page View" })]
						}),
						isReading && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: handleBackToList,
							className: `flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${isLight ? "bg-slate-200 hover:bg-slate-300 text-slate-800" : "bg-white/10 hover:bg-white/20 text-gray-200"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: `w-3.5 h-3.5 ${!isRTL ? "rotate-180" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "الفهرس" : "Catalog" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								soundManager.playTap();
								onClose();
							},
							className: `p-2 rounded-xl transition cursor-pointer ${isLight ? "bg-slate-200 hover:bg-slate-300 text-slate-700" : "bg-white/10 hover:bg-white/20 text-gray-300 hover:text-white"}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-4 h-4" })
						})
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-1 overflow-y-auto p-4 sm:p-6 space-y-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, {
					mode: "wait",
					children: !isReading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
						initial: { opacity: 0 },
						animate: { opacity: 1 },
						exit: { opacity: 0 },
						className: "space-y-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `p-3.5 sm:p-4 rounded-2xl border space-y-2.5 ${isLight ? "bg-gradient-to-r from-teal-50/90 via-white to-emerald-50/80 border-teal-300" : "bg-gradient-to-r from-teal-950/55 via-slate-900/85 to-emerald-950/45 border-teal-500/35"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap items-center justify-between gap-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 flex-wrap",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "px-2 py-0.5 rounded-full text-[10px] font-black bg-teal-500/15 text-teal-800 dark:text-teal-300 border border-teal-500/30",
											children: ["🩺 ", language === "ar" ? `سلسلة علم النفس الإكلينيكي ونمو الطفل (${CLINICAL_CHILDHOOD_ANXIETY_NARRATIVE_ARTICLES.length} دراسات)` : `Clinical Psychology & Child Development (${CLINICAL_CHILDHOOD_ANXIETY_NARRATIVE_ARTICLES.length})`]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: `text-xs sm:text-sm font-black font-['Alexandria'] ${isLight ? "text-slate-900" : "text-white"}`,
											children: language === "ar" ? "تأثير الطفولة على البلوغ، تشريح القلق النفسي، والتفكير الزائد في ضوء الخصوصية الثقافية" : "Childhood Impact on Adulthood, Anatomy of Anxiety & Overthinking"
										})]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2",
									children: CLINICAL_CHILDHOOD_ANXIETY_NARRATIVE_ARTICLES.map((art, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											soundManager.playTap();
											setSelectedCategory(art.category);
											setActiveTrack("narrative");
											setActiveAcademic(null);
											setActiveNarrative(art);
										},
										className: `p-2.5 rounded-xl border text-start transition cursor-pointer flex flex-col justify-between gap-1.5 ${isLight ? "bg-white hover:bg-teal-50 border-slate-200 hover:border-teal-400 text-slate-900" : "bg-slate-950/70 hover:bg-teal-950/50 border-white/10 hover:border-teal-400/50 text-white"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-base",
												children: art.icon
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `px-1.5 py-0.5 rounded-full text-[9px] font-extrabold ${isLight ? "bg-teal-100 text-teal-800" : "bg-teal-500/20 text-teal-300"}`,
												children: language === "ar" ? `دراسة ${index + 1}` : `Study ${index + 1}`
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] font-black font-['Alexandria'] leading-snug line-clamp-2",
											children: language === "ar" ? art.title : art.titleEn
										})]
									}, art.id))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `p-3.5 sm:p-4 rounded-2xl border space-y-2.5 ${isLight ? "bg-gradient-to-r from-cyan-50/90 via-white to-indigo-50/80 border-cyan-200" : "bg-gradient-to-r from-cyan-950/50 via-slate-900/80 to-indigo-950/40 border-cyan-500/30"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap items-center justify-between gap-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 flex-wrap",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "px-2 py-0.5 rounded-full text-[10px] font-black bg-cyan-500/15 text-cyan-700 dark:text-cyan-300 border border-cyan-500/30",
											children: ["🔬 ", language === "ar" ? "المقالات التعريفية عن الموقع (مقالان)" : "Platform Introductory Articles (2)"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: `text-xs sm:text-sm font-black font-['Alexandria'] ${isLight ? "text-slate-900" : "text-white"}`,
											children: language === "ar" ? "الأسس العلمية لاختبارات مرآة القلوب وكيف تُبنى الاختبارات النفسية المعتمدة علمياً؟" : "Scientific Foundations of Mirror of Hearts & How Validated Psychological Tests Are Built"
										})]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-2",
									children: PLATFORM_INTRODUCTORY_ARTICLES.map((art, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											soundManager.playTap();
											setSelectedCategory("applied_psychology");
											setActiveTrack("narrative");
											setActiveAcademic(null);
											setActiveNarrative(art);
										},
										className: `p-2.5 rounded-xl border text-start transition cursor-pointer flex flex-col justify-between gap-1.5 ${isLight ? "bg-white hover:bg-cyan-50 border-slate-200 hover:border-cyan-400 text-slate-900" : "bg-slate-950/70 hover:bg-cyan-950/50 border-white/10 hover:border-cyan-400/50 text-white"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-base",
												children: art.icon
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `px-1.5 py-0.5 rounded-full text-[9px] font-extrabold ${isLight ? "bg-cyan-100 text-cyan-800" : "bg-cyan-500/20 text-cyan-300"}`,
												children: language === "ar" ? `المقال التعريفي ${index + 1}` : `Intro ${index + 1}`
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] font-black font-['Alexandria'] leading-snug line-clamp-2",
											children: language === "ar" ? art.title : art.titleEn
										})]
									}, art.id))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `p-3.5 sm:p-4 rounded-2xl border space-y-2.5 ${isLight ? "bg-gradient-to-r from-amber-50/90 via-white to-violet-50/80 border-amber-200" : "bg-gradient-to-r from-amber-950/50 via-slate-900/80 to-violet-950/40 border-amber-500/30"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap items-center justify-between gap-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 flex-wrap",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-500/15 text-amber-800 dark:text-amber-300 border border-amber-500/30",
											children: ["🧠 ", language === "ar" ? "قسم الذكاء العاطفي — 6 مقالات شاملة" : "Emotional IQ — 6 Articles Series"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: `text-xs sm:text-sm font-black font-['Alexandria'] ${isLight ? "text-slate-900" : "text-white"}`,
											children: language === "ar" ? "سلسلة الذكاء العاطفي: المفهوم العصبي، التشريح، القياس، الزواج، الثقة بالنفس، وإدارة الضغوط" : "Emotional Intelligence Series: Concept, Anatomy, Measurement, Marriage, Confidence & Stress"
										})]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2",
									children: EMOTIONAL_IQ_NARRATIVE_ARTICLES.map((art, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											soundManager.playTap();
											setSelectedCategory("emotional_iq");
											setActiveTrack("narrative");
											setActiveAcademic(null);
											setActiveNarrative(art);
										},
										className: `p-2.5 rounded-xl border text-start transition cursor-pointer flex flex-col justify-between gap-1.5 ${isLight ? "bg-white hover:bg-amber-50 border-slate-200 hover:border-amber-400 text-slate-900" : "bg-slate-950/70 hover:bg-amber-950/50 border-white/10 hover:border-amber-400/50 text-white"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-base",
												children: art.icon
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `px-1.5 py-0.5 rounded-full text-[9px] font-extrabold ${isLight ? "bg-amber-100 text-amber-800" : "bg-amber-500/20 text-amber-300"}`,
												children: language === "ar" ? `المقال ${index + 1}` : `Part ${index + 1}`
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] font-black font-['Alexandria'] leading-snug line-clamp-2",
											children: language === "ar" ? art.title : art.titleEn
										})]
									}, art.id))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `p-3.5 sm:p-4 rounded-2xl border space-y-2.5 ${isLight ? "bg-gradient-to-r from-rose-50/90 via-white to-amber-50/80 border-rose-200" : "bg-gradient-to-r from-rose-950/50 via-slate-900/80 to-purple-950/40 border-rose-500/30"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap items-center justify-between gap-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 flex-wrap",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "px-2 py-0.5 rounded-full text-[10px] font-black bg-rose-500/15 text-rose-700 dark:text-rose-300 border border-rose-500/30",
											children: ["💞 ", language === "ar" ? "قسم العلاقات — 4 مقالات" : "Relationships — 4 Articles"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: `text-xs sm:text-sm font-black font-['Alexandria'] ${isLight ? "text-slate-900" : "text-white"}`,
											children: language === "ar" ? "موسوعة العلاقات الواعية: التوافق العاطفي، أنماط التعلق، الحب الصحي، وأسباب فشل العلاقات" : "Conscious Relationships: Compatibility, Attachment, Healthy Love & Why Relationships Fail"
										})]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2",
									children: RELATIONSHIP_FOUR_NARRATIVE_ARTICLES.map((art, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											soundManager.playTap();
											setSelectedCategory("relationships");
											setActiveTrack("narrative");
											setActiveAcademic(null);
											setActiveNarrative(art);
										},
										className: `p-2.5 rounded-xl border text-start transition cursor-pointer flex flex-col justify-between gap-1.5 ${isLight ? "bg-white hover:bg-rose-50 border-slate-200 hover:border-rose-400 text-slate-900" : "bg-slate-950/70 hover:bg-rose-950/50 border-white/10 hover:border-rose-400/50 text-white"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-base",
												children: art.icon
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `px-1.5 py-0.5 rounded-full text-[9px] font-extrabold ${isLight ? "bg-rose-100 text-rose-800" : "bg-rose-500/20 text-rose-300"}`,
												children: language === "ar" ? `مقال ${index + 1}` : `Part ${index + 1}`
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] font-black font-['Alexandria'] leading-snug line-clamp-2",
											children: language === "ar" ? art.title : art.titleEn
										})]
									}, art.id))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `p-3.5 sm:p-4 rounded-2xl border space-y-2.5 ${isLight ? "bg-gradient-to-r from-indigo-50/90 via-white to-emerald-50/80 border-indigo-200" : "bg-gradient-to-r from-indigo-950/50 via-slate-900/80 to-emerald-950/40 border-indigo-500/30"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap items-center justify-between gap-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 flex-wrap",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "px-2 py-0.5 rounded-full text-[10px] font-black bg-indigo-500/15 text-indigo-700 dark:text-indigo-300 border border-indigo-500/30",
											children: ["📚 ", language === "ar" ? "سلسلة العوامل الخمسة (4 مقالات)" : "Big Five Series (4 Articles)"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: `text-xs sm:text-sm font-black font-['Alexandria'] ${isLight ? "text-slate-900" : "text-white"}`,
											children: language === "ar" ? "من النفس الباطنة إلى العقل القيادي: تحليل علمي متكامل لأنواع الشخصية عبر العوامل الخمسة" : "From the Inner Psyche to the Leadership Mind: Big Five Series"
										})]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2",
									children: PDF_FOUR_NARRATIVE_ARTICLES.map((art, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											soundManager.playTap();
											setActiveTrack("narrative");
											setActiveAcademic(null);
											setActiveNarrative(art);
										},
										className: `p-2.5 rounded-xl border text-start transition cursor-pointer flex flex-col justify-between gap-1.5 ${isLight ? "bg-white hover:bg-indigo-50 border-slate-200 hover:border-indigo-400 text-slate-900" : "bg-slate-950/70 hover:bg-indigo-950/50 border-white/10 hover:border-indigo-400/50 text-white"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-base",
												children: art.icon
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `px-1.5 py-0.5 rounded-full text-[9px] font-extrabold ${isLight ? "bg-indigo-100 text-indigo-800" : "bg-indigo-500/20 text-indigo-300"}`,
												children: language === "ar" ? `مقال ${index + 1}` : `Part ${index + 1}`
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] font-black font-['Alexandria'] leading-snug line-clamp-2",
											children: language === "ar" ? art.title : art.titleEn
										})]
									}, art.id))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										soundManager.playTap();
										setActiveTrack("academic");
									},
									className: `p-4 rounded-2xl border text-start transition cursor-pointer flex items-start gap-3.5 ${activeTrack === "academic" ? isLight ? "bg-gradient-to-r from-indigo-700 to-cyan-700 text-white border-indigo-600 shadow-lg" : "bg-gradient-to-r from-indigo-600/35 to-cyan-600/30 text-white border-cyan-400 shadow-lg shadow-cyan-500/10" : isLight ? "bg-white hover:bg-slate-100 text-slate-800 border-slate-200" : "bg-white/[0.03] hover:bg-white/[0.06] text-gray-300 border-white/10"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 ${activeTrack === "academic" ? "bg-white/20 text-white" : "bg-cyan-500/15 text-cyan-400"}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "w-5 h-5" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex-1 min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-black text-sm sm:text-base font-['Alexandria']",
												children: language === "ar" ? "أولاً: الأبحاث العلمية الكاملة (APA 7th)" : "First: Full Academic Research Papers"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: `px-2 py-0.5 rounded-full text-[10px] font-extrabold ${activeTrack === "academic" ? "bg-white/25 text-white" : "bg-cyan-500/20 text-cyan-400"}`,
												children: [
													ACADEMIC_PAPERS_CATALOG.length,
													" ",
													language === "ar" ? "أبحاث محكّمة" : "Papers"
												]
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: `text-xs mt-1 leading-relaxed ${activeTrack === "academic" ? "text-white/90" : isLight ? "text-slate-600" : "text-gray-400"}`,
											children: language === "ar" ? "دراسات أكاديمية رصينة متكاملة (أقسام البحث العلمي + النص الكامل المتواصل دون تجزئة + مراجع APA 7th)." : "Rigorous peer-reviewed structure (Segmented sections + Full continuous unsegmented manuscript + APA 7th)."
										})]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										soundManager.playTap();
										setActiveTrack("narrative");
									},
									className: `p-4 rounded-2xl border text-start transition cursor-pointer flex items-start gap-3.5 ${activeTrack === "narrative" ? isLight ? "bg-gradient-to-r from-rose-600 to-purple-600 text-white border-rose-500 shadow-lg" : "bg-gradient-to-r from-rose-600/30 to-purple-600/30 text-white border-rose-400 shadow-lg shadow-rose-500/10" : isLight ? "bg-white hover:bg-slate-100 text-slate-800 border-slate-200" : "bg-white/[0.03] hover:bg-white/[0.06] text-gray-300 border-white/10"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 ${activeTrack === "narrative" ? "bg-white/20 text-white" : "bg-rose-500/15 text-rose-400"}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stethoscope, { className: "w-5 h-5" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex-1 min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-black text-sm sm:text-base font-['Alexandria']",
												children: language === "ar" ? "ثانياً: المقالات القصصية العلمية" : "Second: Clinical Narrative Articles"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: `px-2 py-0.5 rounded-full text-[10px] font-extrabold ${activeTrack === "narrative" ? "bg-white/25 text-white" : "bg-rose-500/20 text-rose-400"}`,
												children: [
													ARTICLES_CATALOG.length,
													" ",
													language === "ar" ? "مقالاً" : "Articles"
												]
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: `text-xs mt-1 leading-relaxed ${activeTrack === "narrative" ? "text-white/90" : isLight ? "text-slate-600" : "text-gray-400"}`,
											children: language === "ar" ? "أسلوب سردي عيادي جذاب مبني على حالات واقعية من العيادة مع تحليل نفسي وأدوات تشخيصية عملية." : "Engaging clinical storytelling based on real therapy cases, psychological deconstruction, and diagnostic tools."
										})]
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: `w-4 h-4 text-gray-400 absolute top-3.5 ${isRTL ? "right-3.5" : "left-3.5"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "text",
										value: searchQuery,
										onChange: (e) => setSearchQuery(e.target.value),
										placeholder: language === "ar" ? "ابحث في المقالات والأبحاث (التوافق، الانهيار النرجسي، الذكاء العاطفي، الاحتراق، الهوية)..." : "Search clinical articles & research papers (compatibility, narcissistic collapse, EQ, burnout)...",
										className: `w-full ${isRTL ? "pr-10 pl-4" : "pl-10 pr-4"} py-3 rounded-2xl border text-xs sm:text-sm focus:outline-none transition ${isLight ? "bg-white border-slate-300 text-slate-900 placeholder-slate-400 focus:border-indigo-500" : "bg-white/5 border-white/15 text-white placeholder-gray-400 focus:border-purple-400"}`
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-thin",
									children: categories.map((cat) => {
										const isSelected = selectedCategory === cat.key;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => {
												soundManager.playTap();
												setSelectedCategory(cat.key);
											},
											className: `shrink-0 px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer ${isSelected ? "bg-gradient-to-r from-purple-600 to-rose-600 text-white shadow-md border border-purple-400/50" : isLight ? "bg-white hover:bg-slate-100 text-slate-700 border border-slate-200" : "bg-white/5 hover:bg-white/10 text-gray-300 border border-white/10"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: cat.icon }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? cat.labelAr : cat.labelEn })]
										}, cat.key);
									})
								})]
							}),
							activeTrack === "narrative" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 md:grid-cols-2 gap-4",
								children: filteredNarrativeArticles.map((art) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
									whileHover: {
										scale: 1.01,
										y: -2
									},
									onClick: () => {
										soundManager.playTap();
										setActiveNarrative(art);
									},
									className: `p-5 rounded-3xl border transition cursor-pointer flex flex-col justify-between space-y-4 group shadow-md ${isLight ? "bg-white hover:bg-rose-50/40 border-slate-200 hover:border-rose-400" : "bg-white/[0.03] hover:bg-white/[0.06] border-white/10 hover:border-rose-500/40"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between gap-2 flex-wrap",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "px-2.5 py-1 rounded-xl bg-rose-500/15 text-rose-600 dark:text-rose-300 text-[10px] font-bold border border-rose-500/30 flex items-center gap-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: art.icon }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? art.categoryLabelAr : art.categoryLabelEn })]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-1 text-[10px] text-amber-600 dark:text-amber-400 font-semibold",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "w-3 h-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? art.readTime : art.readTimeEn })]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: `text-sm sm:text-base font-extrabold leading-snug font-['Alexandria'] ${isLight ? "text-slate-900 group-hover:text-rose-600" : "text-white group-hover:text-rose-300"}`,
												children: language === "ar" ? art.title : art.titleEn
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: `text-xs line-clamp-3 leading-relaxed ${isLight ? "text-slate-600" : "text-gray-300"}`,
												children: language === "ar" ? art.summary : art.summaryEn
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `pt-3 border-t flex items-center justify-between text-xs ${isLight ? "border-slate-200" : "border-white/10"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-1 text-[10px] text-purple-600 dark:text-purple-300 font-medium truncate max-w-[65%]",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "w-3.5 h-3.5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "truncate",
												children: language === "ar" ? art.scientificFramework : art.scientificFrameworkEn
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-rose-600 dark:text-rose-400 font-bold flex items-center gap-1 shrink-0",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "قراءة القصة والتحليل" : "Read Clinical Story" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: `w-3.5 h-3.5 ${isRTL ? "rotate-180" : ""}` })]
										})]
									})]
								}, art.id))
							}),
							activeTrack === "academic" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 gap-4",
								children: filteredAcademicPapers.map((paper) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
									whileHover: {
										scale: 1.005,
										y: -2
									},
									onClick: () => {
										soundManager.playTap();
										setActiveAcademic(paper);
									},
									className: `p-5 sm:p-6 rounded-3xl border transition cursor-pointer flex flex-col justify-between space-y-4 group shadow-md ${isLight ? "bg-white hover:bg-indigo-50/40 border-slate-200 hover:border-indigo-400" : "bg-white/[0.03] hover:bg-white/[0.06] border-white/10 hover:border-cyan-500/40"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between gap-2 flex-wrap",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-2 flex-wrap",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "px-2.5 py-1 rounded-xl bg-cyan-500/15 text-cyan-700 dark:text-cyan-300 text-[10px] font-extrabold border border-cyan-500/30 flex items-center gap-1",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: paper.icon }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? paper.categoryLabelAr : paper.categoryLabelEn })]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "px-2.5 py-1 rounded-xl bg-indigo-500/15 text-indigo-700 dark:text-indigo-300 text-[10px] font-bold border border-indigo-500/30",
														children: language === "ar" ? paper.methodologyBadgeAr : paper.methodologyBadgeEn
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-2 text-[11px] text-amber-600 dark:text-amber-400 font-semibold",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? paper.readTimeAr : paper.readTimeEn })]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: `text-base sm:text-lg font-black leading-snug font-['Alexandria'] ${isLight ? "text-slate-900 group-hover:text-indigo-700" : "text-white group-hover:text-cyan-300"}`,
												children: language === "ar" ? paper.titleAr : paper.titleEn
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: `text-xs sm:text-sm line-clamp-3 leading-relaxed ${isLight ? "text-slate-600" : "text-gray-300"}`,
												children: language === "ar" ? paper.abstractAr : paper.abstractEn
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex flex-wrap gap-1.5 pt-1",
												children: (language === "ar" ? paper.keywordsAr : paper.keywordsEn).map((kw, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: `px-2 py-0.5 rounded-lg text-[10px] font-semibold ${isLight ? "bg-slate-100 text-slate-700 border border-slate-200" : "bg-white/5 text-gray-300 border border-white/10"}`,
													children: ["#", kw]
												}, idx))
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `pt-3 border-t flex items-center justify-between text-xs ${isLight ? "border-slate-200" : "border-white/10"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[11px] text-emerald-600 dark:text-emerald-400 font-bold",
											children: [
												"📚 ",
												paper.apaReferences.length,
												" ",
												language === "ar" ? "مرجعاً أكاديمياً موثقاً بصيغة APA 7th" : "Verified APA 7th Citations"
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-indigo-600 dark:text-cyan-400 font-extrabold flex items-center gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "استعراض الدراسة العلمية الكاملة" : "Read Full Research Paper" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: `w-4 h-4 ${isRTL ? "rotate-180" : ""}` })]
										})]
									})]
								}, paper.id))
							})
						]
					}, "catalog-view") : activeNarrative ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
						initial: {
							opacity: 0,
							y: 10
						},
						animate: {
							opacity: 1,
							y: 0
						},
						exit: {
							opacity: 0,
							y: -10
						},
						className: "max-w-3xl mx-auto space-y-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `p-6 rounded-3xl border space-y-4 shadow-xl ${isLight ? "bg-gradient-to-br from-rose-50 via-white to-purple-50 border-rose-200" : `bg-gradient-to-br ${activeNarrative.coverGradient} border-purple-500/30`}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "px-3 py-1 rounded-xl bg-rose-500/20 border border-rose-400/40 text-rose-700 dark:text-rose-200 text-xs font-extrabold flex items-center gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: activeNarrative.icon }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? activeNarrative.categoryLabelAr : activeNarrative.categoryLabelEn })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: `flex items-center gap-3 text-xs ${isLight ? "text-slate-600" : "text-gray-300"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex items-center gap-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "w-3.5 h-3.5 text-amber-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? activeNarrative.readTime : activeNarrative.readTimeEn })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex items-center gap-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "w-3.5 h-3.5 text-rose-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: activeNarrative.publishDate })]
											})]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: `text-xl sm:text-2xl font-black leading-tight font-['Alexandria'] ${isLight ? "text-slate-900" : "text-white"}`,
										children: language === "ar" ? activeNarrative.title : activeNarrative.titleEn
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: `text-sm leading-relaxed font-medium ${isLight ? "text-slate-700" : "text-gray-200"}`,
										children: language === "ar" ? activeNarrative.summary : activeNarrative.summaryEn
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `p-3.5 rounded-2xl border flex items-center justify-between gap-3 text-xs ${isLight ? "bg-white/90 border-slate-200 text-slate-800" : "bg-black/40 border-white/10 text-rose-200"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "w-4 h-4 text-rose-500 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: language === "ar" ? "الإطار العلمي المعتمد: " : "Scientific Framework: " }), language === "ar" ? activeNarrative.scientificFramework : activeNarrative.scientificFrameworkEn] })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: () => handleShareContent(language === "ar" ? activeNarrative.title : activeNarrative.titleEn, language === "ar" ? activeNarrative.summary : activeNarrative.summaryEn),
											className: "px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer shrink-0",
											children: [copiedShare ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: copiedShare ? language === "ar" ? "تم النسخ!" : "Copied!" : language === "ar" ? "مشاركة" : "Share" })]
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReaderToolbar, {
								fontSize: readerFontSize,
								onChangeFontSize: setReaderFontSize,
								viewMode: readerViewMode,
								onChangeViewMode: setReaderViewMode,
								shareTitle: language === "ar" ? activeNarrative.title : activeNarrative.titleEn,
								shareSummary: language === "ar" ? activeNarrative.summary : activeNarrative.summaryEn,
								shareUrl: "https://miratalqulub.com/#/articles",
								contentTypeLabelAr: "للقصة والسجل العيادي",
								contentTypeLabelEn: "Story"
							}),
							readerViewMode === "segmented_and_continuous" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-6 transition-all",
								style: { fontSize: `${readerFontSize}px` },
								children: [
									activeNarrative.clinicalCaseQuoteAr && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `p-5 rounded-3xl border-s-4 border-rose-500 space-y-2 ${isLight ? "bg-rose-50/70 text-slate-800 border border-rose-200" : "bg-rose-950/25 text-rose-100 border border-rose-500/20"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 text-rose-600 dark:text-rose-400 font-bold text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quote, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "مقتطف من جلسة العيادة الواقعية:" : "Clinical Session Case Excerpt:" })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "italic leading-relaxed font-medium",
											style: { fontSize: `${readerFontSize}px` },
											children: language === "ar" ? activeNarrative.clinicalCaseQuoteAr : activeNarrative.clinicalCaseQuoteEn
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `p-5 rounded-3xl border space-y-3 ${isLight ? "bg-amber-50 border-amber-200 text-slate-800" : "bg-amber-500/10 border-amber-500/30 text-gray-200"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 text-amber-600 dark:text-amber-300 font-extrabold text-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "الخلاصة الإكلينيكية وأبرز النقاط المستفادة:" : "Key Clinical Takeaways:" })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
											className: "space-y-2",
											style: { fontSize: `${Math.max(14, readerFontSize - 1)}px` },
											children: (language === "ar" ? activeNarrative.keyTakeaways : activeNarrative.keyTakeawaysEn).map((takeaway, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
												className: "flex items-start gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-amber-500 font-bold shrink-0",
													children: "✓"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "leading-relaxed",
													children: takeaway
												})]
											}, i))
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "space-y-4",
										children: activeNarrative.contentParagraphs.map((para, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: `p-5 rounded-2xl border space-y-2.5 ${isLight ? "bg-white border-slate-200 text-slate-800 shadow-sm" : "bg-white/[0.02] border-white/10 text-gray-200"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
												className: `font-extrabold font-['Alexandria'] flex items-center gap-2 ${isLight ? "text-slate-900" : "text-white"}`,
												style: { fontSize: `${readerFontSize + 2}px` },
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-2.5 h-2.5 rounded-full bg-rose-500 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? para.heading : para.headingEn })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: `leading-loose whitespace-pre-line ${isLight ? "text-slate-700" : "text-gray-300"}`,
												style: { fontSize: `${readerFontSize}px` },
												children: language === "ar" ? para.text : para.textEn
											})]
										}, i))
									}),
									activeNarrative.diagnosticTable && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `p-5 rounded-3xl border space-y-4 overflow-x-auto ${isLight ? "bg-white border-indigo-200 shadow-sm" : "bg-indigo-950/20 border-indigo-500/30"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
											className: `text-sm sm:text-base font-black font-['Alexandria'] ${isLight ? "text-indigo-900" : "text-indigo-300"}`,
											children: [
												"⚖️",
												" ",
												language === "ar" ? activeNarrative.diagnosticTable.titleAr : activeNarrative.diagnosticTable.titleEn
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
											className: "w-full text-xs sm:text-sm border-collapse",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
												className: isLight ? "bg-indigo-50 text-indigo-900 border-b border-indigo-200" : "bg-white/5 text-white border-b border-white/10",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-3 text-start font-bold",
														children: language === "ar" ? activeNarrative.diagnosticTable.col1Ar : activeNarrative.diagnosticTable.col1En
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-3 text-start font-bold text-emerald-600 dark:text-emerald-400",
														children: language === "ar" ? activeNarrative.diagnosticTable.col2Ar : activeNarrative.diagnosticTable.col2En
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-3 text-start font-bold text-rose-600 dark:text-rose-400",
														children: language === "ar" ? activeNarrative.diagnosticTable.col3Ar : activeNarrative.diagnosticTable.col3En
													})
												]
											}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: activeNarrative.diagnosticTable.rows.map((row, rIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
												className: `border-b ${isLight ? "border-slate-200" : "border-white/5"}`,
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-3 font-bold",
														children: language === "ar" ? row.criterionAr : row.criterionEn
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-3",
														children: language === "ar" ? row.naturalAr : row.naturalEn
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-3",
														children: language === "ar" ? row.manipulationAr : row.manipulationEn
													})
												]
											}, rIdx)) })]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `p-5 sm:p-6 rounded-3xl border space-y-3 shadow-lg ${isLight ? "bg-emerald-50/90 border-emerald-300 text-slate-900" : "bg-gradient-to-r from-emerald-950/60 via-slate-900 to-teal-950/60 border-emerald-500/35 text-gray-200"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 text-emerald-700 dark:text-emerald-300 font-black text-base",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "⚡" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "font-['Alexandria']",
												children: language === "ar" ? activeNarrative.practicalExercise.title : activeNarrative.practicalExercise.titleEn
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "space-y-2.5",
											children: (language === "ar" ? activeNarrative.practicalExercise.steps : activeNarrative.practicalExercise.stepsEn).map((st, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-start gap-2.5 text-xs sm:text-sm",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30 text-xs font-bold flex items-center justify-center shrink-0 mt-0.5",
													children: i + 1
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "leading-relaxed",
													children: st
												})]
											}, i))
										})]
									}),
									activeNarrative.conclusionAr && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `p-5 rounded-3xl border space-y-2 ${isLight ? "bg-purple-50 border-purple-200 text-slate-800" : "bg-purple-950/30 border-purple-500/30 text-purple-100"}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "leading-relaxed font-semibold",
											style: { fontSize: `${readerFontSize}px` },
											children: language === "ar" ? activeNarrative.conclusionAr : activeNarrative.conclusionEn
										})
									}),
									activeNarrative.apaReferences && activeNarrative.apaReferences.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `p-5 rounded-3xl border space-y-3 ${isLight ? "bg-slate-100 border-slate-300 text-slate-800" : "bg-slate-900/80 border-white/10 text-gray-300"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
											className: "font-extrabold text-sm flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookMarked, { className: "w-4 h-4 text-indigo-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "أبرز المراجع العلمية الحديثة المعتمدة في المقال (2023 - 2025):" : "Verified Modern Scientific References (2023–2025):" })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
											className: "space-y-3 text-xs",
											children: activeNarrative.apaReferences.map((ref, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
												className: `p-3 rounded-xl border ${isLight ? "bg-white border-slate-200" : "bg-black/30 border-white/5"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "font-mono text-[11px] font-bold text-indigo-600 dark:text-indigo-300 dir-ltr text-left",
													children: ref.citation
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-1 text-[11px] opacity-90",
													children: language === "ar" ? ref.noteAr : ref.noteEn
												})]
											}, idx))
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `p-5 sm:p-7 rounded-3xl border-2 space-y-4 shadow-xl ${isLight ? "bg-gradient-to-b from-rose-50/70 via-white to-slate-50 border-rose-300 text-slate-900" : "bg-gradient-to-b from-rose-950/35 via-slate-900/95 to-slate-950 border-rose-500/40 text-gray-100"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center justify-between gap-3 border-b pb-3 border-rose-200 dark:border-white/15",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-base sm:text-xl font-black font-['Alexandria'] text-rose-700 dark:text-rose-300",
											children: language === "ar" ? "📜 النص الكامل المتواصل للقصة / السجلات السريرية (دون تجزئة)" : "📜 Full Continuous Unsegmented Story Manuscript"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs opacity-80",
											children: language === "ar" ? "قراءة كاملة متصلة للقصة والسجلات السريرية من البداية إلى النهاية دون أي تجزئة." : "Complete continuous story reading without segmentation."
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => handleCopyStoryFullText(activeNarrative),
										className: "px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-extrabold text-xs flex items-center gap-1.5 transition cursor-pointer shadow-md shrink-0",
										children: [copiedStoryFullText ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: copiedStoryFullText ? language === "ar" ? "تم النسخ!" : "Copied!" : language === "ar" ? "نسخ النص الكامل للقصة" : "Copy Full Story Text" })]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `p-4 sm:p-6 rounded-2xl border select-text ${isLight ? "bg-white border-slate-200 text-slate-800 shadow-inner" : "bg-black/40 border-white/10 text-gray-200"}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormattedContinuousManuscript, {
										text: getFullContinuousNarrativeText(activeNarrative, language),
										fontSize: readerFontSize,
										isLight
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArticleBottomSocialShare, {
								title: language === "ar" ? activeNarrative.title : activeNarrative.titleEn,
								summary: language === "ar" ? activeNarrative.summary : activeNarrative.summaryEn,
								url: "https://miratalqulub.com/#/articles",
								isLight,
								language
							})
						]
					}, "narrative-reader") : activeAcademic ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
						initial: {
							opacity: 0,
							y: 10
						},
						animate: {
							opacity: 1,
							y: 0
						},
						exit: {
							opacity: 0,
							y: -10
						},
						className: "max-w-4xl mx-auto space-y-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `p-6 sm:p-7 rounded-3xl border space-y-4 shadow-xl ${isLight ? "bg-gradient-to-br from-indigo-50 via-white to-cyan-50 border-indigo-200" : `bg-gradient-to-br ${activeAcademic.coverGradient} border-cyan-500/35`}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "px-3 py-1 rounded-xl bg-cyan-500/20 border border-cyan-400/40 text-cyan-800 dark:text-cyan-200 text-xs font-extrabold flex items-center gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? activeAcademic.categoryLabelAr : activeAcademic.categoryLabelEn })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "px-3 py-1 rounded-xl bg-indigo-500/20 border border-indigo-400/40 text-indigo-800 dark:text-indigo-200 text-xs font-bold",
											children: language === "ar" ? activeAcademic.methodologyBadgeAr : activeAcademic.methodologyBadgeEn
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: `text-xl sm:text-2xl font-black leading-snug font-['Alexandria'] ${isLight ? "text-slate-900" : "text-white"}`,
										children: language === "ar" ? activeAcademic.titleAr : activeAcademic.titleEn
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: `text-xs font-semibold italic ${isLight ? "text-slate-500" : "text-gray-400"}`,
										children: language === "ar" ? activeAcademic.titleEn : activeAcademic.titleAr
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex flex-wrap gap-1.5 pt-1",
										children: (language === "ar" ? activeAcademic.keywordsAr : activeAcademic.keywordsEn).map((kw, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: `px-2.5 py-1 rounded-lg text-[11px] font-bold ${isLight ? "bg-indigo-100/80 text-indigo-900" : "bg-white/10 text-cyan-200"}`,
											children: ["#", kw]
										}, i))
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReaderToolbar, {
								fontSize: readerFontSize,
								onChangeFontSize: setReaderFontSize,
								viewMode: readerViewMode,
								onChangeViewMode: setReaderViewMode,
								shareTitle: language === "ar" ? activeAcademic.titleAr : activeAcademic.titleEn,
								shareSummary: language === "ar" ? activeAcademic.abstractAr : activeAcademic.abstractEn,
								shareUrl: "https://miratalqulub.com/#/articles",
								contentTypeLabelAr: "للبحث العلمي",
								contentTypeLabelEn: "Paper"
							}),
							readerViewMode === "segmented_and_continuous" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-6 transition-all",
								style: { fontSize: `${readerFontSize}px` },
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `p-5 sm:p-6 rounded-3xl border space-y-2.5 ${isLight ? "bg-amber-50/70 border-amber-200 text-slate-800" : "bg-amber-500/10 border-amber-500/30 text-gray-200"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
											className: "text-base font-black text-amber-700 dark:text-amber-300 font-['Alexandria'] flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "الملخص (Abstract)" : "Abstract" })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "leading-loose",
											style: { fontSize: `${readerFontSize}px` },
											children: language === "ar" ? activeAcademic.abstractAr : activeAcademic.abstractEn
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `p-5 sm:p-6 rounded-3xl border space-y-3 ${isLight ? "bg-white border-slate-200 text-slate-800 shadow-sm" : "bg-white/[0.02] border-white/10 text-gray-200"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-base sm:text-lg font-black text-indigo-600 dark:text-cyan-300 font-['Alexandria']",
											children: language === "ar" ? "1. المقدمة (Introduction)" : "1. Introduction"
										}), (language === "ar" ? activeAcademic.introductionAr : activeAcademic.introductionEn).map((p, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "leading-loose",
											style: { fontSize: `${readerFontSize}px` },
											children: p
										}, idx))]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `p-5 sm:p-6 rounded-3xl border space-y-4 ${isLight ? "bg-white border-slate-200 text-slate-800 shadow-sm" : "bg-white/[0.02] border-white/10 text-gray-200"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-base sm:text-lg font-black text-indigo-600 dark:text-cyan-300 font-['Alexandria']",
											children: language === "ar" ? "2. الإطار النظري والدراسات السابقة (Theoretical Framework)" : "2. Theoretical Framework"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "space-y-4",
											children: activeAcademic.theoreticalFramework.map((sec, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: `p-4 rounded-2xl border space-y-2 ${isLight ? "bg-slate-50 border-slate-200" : "bg-black/30 border-white/5"}`,
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
														className: "text-sm font-extrabold text-purple-700 dark:text-purple-300",
														children: [
															sec.sectionNumber,
															" ",
															language === "ar" ? sec.titleAr : sec.titleEn
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "leading-relaxed",
														style: { fontSize: `${readerFontSize}px` },
														children: language === "ar" ? sec.contentAr : sec.contentEn
													}),
													sec.subPointsAr && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
														className: "space-y-1.5 pt-2",
														style: { fontSize: `${Math.max(14, readerFontSize - 1)}px` },
														children: (language === "ar" ? sec.subPointsAr : sec.subPointsEn || []).map((pt, pIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
															className: "flex items-start gap-2",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-cyan-500 font-bold",
																children: "•"
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: pt })]
														}, pIdx))
													})
												]
											}, idx))
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `p-5 sm:p-6 rounded-3xl border space-y-3 ${isLight ? "bg-indigo-50/70 border-indigo-200 text-slate-800" : "bg-indigo-950/30 border-indigo-500/30 text-gray-200"}`,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
												className: "text-base sm:text-lg font-black text-indigo-700 dark:text-indigo-300 font-['Alexandria']",
												children: language === "ar" ? "3. منهجية البحث (Methodology)" : "3. Research Methodology"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-semibold",
												style: { fontSize: `${readerFontSize}px` },
												children: language === "ar" ? activeAcademic.methodology.approachAr : activeAcademic.methodology.approachEn
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
												className: "space-y-2",
												style: { fontSize: `${readerFontSize}px` },
												children: (language === "ar" ? activeAcademic.methodology.pillarsAr : activeAcademic.methodology.pillarsEn).map((pil, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
													className: "flex items-start gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "w-5 h-5 rounded-full bg-indigo-500/20 text-indigo-700 dark:text-indigo-300 text-xs font-bold flex items-center justify-center shrink-0 mt-0.5",
														children: idx + 1
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "leading-relaxed",
														children: pil
													})]
												}, idx))
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `p-5 sm:p-6 rounded-3xl border space-y-4 ${isLight ? "bg-white border-slate-200 text-slate-800 shadow-sm" : "bg-white/[0.02] border-white/10 text-gray-200"}`,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
												className: "text-base sm:text-lg font-black text-indigo-600 dark:text-cyan-300 font-['Alexandria']",
												children: language === "ar" ? "4. التحليل والمناقشة (Analysis and Discussion)" : "4. Analysis and Discussion"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "space-y-4",
												children: activeAcademic.analysisAndDiscussion.map((sec, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: `p-4 rounded-2xl border space-y-2 ${isLight ? "bg-slate-50 border-slate-200" : "bg-black/30 border-white/5"}`,
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
															className: "text-sm font-extrabold text-rose-700 dark:text-rose-300",
															children: [
																sec.sectionNumber,
																" ",
																language === "ar" ? sec.titleAr : sec.titleEn
															]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "leading-relaxed",
															style: { fontSize: `${readerFontSize}px` },
															children: language === "ar" ? sec.contentAr : sec.contentEn
														}),
														sec.subPointsAr && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
															className: "space-y-2 pt-2",
															style: { fontSize: `${Math.max(14, readerFontSize - 1)}px` },
															children: (language === "ar" ? sec.subPointsAr : sec.subPointsEn || []).map((pt, pIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
																className: "flex items-start gap-2",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "text-rose-500 font-bold",
																	children: "▪"
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "leading-relaxed",
																	children: pt
																})]
															}, pIdx))
														})
													]
												}, idx))
											}),
											activeAcademic.summaryTable && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: `mt-4 p-4 rounded-2xl border space-y-3 overflow-x-auto ${isLight ? "bg-indigo-50/60 border-indigo-200" : "bg-indigo-950/25 border-indigo-500/30"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
													className: "text-xs sm:text-sm font-black text-indigo-800 dark:text-cyan-300 font-['Alexandria']",
													children: [
														"📊",
														" ",
														language === "ar" ? activeAcademic.summaryTable.titleAr : activeAcademic.summaryTable.titleEn
													]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
													className: "w-full text-xs border-collapse",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
														className: isLight ? "bg-indigo-100/80 text-indigo-950 border-b border-indigo-200" : "bg-white/10 text-white border-b border-white/15",
														children: (language === "ar" ? activeAcademic.summaryTable.headersAr : activeAcademic.summaryTable.headersEn).map((hdr, hIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
															className: "p-2.5 text-start font-extrabold",
															children: hdr
														}, hIdx))
													}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: activeAcademic.summaryTable.rows.map((row, rIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
														className: `border-b ${isLight ? "border-indigo-100 bg-white/80" : "border-white/10 bg-black/20"}`,
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																className: "p-2.5 font-bold text-indigo-700 dark:text-cyan-300",
																children: language === "ar" ? row.col1Ar : row.col1En
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																className: "p-2.5",
																children: language === "ar" ? row.col2Ar : row.col2En
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																className: "p-2.5",
																children: language === "ar" ? row.col3Ar : row.col3En
															})
														]
													}, rIdx)) })]
												})]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `p-5 sm:p-6 rounded-3xl border space-y-2 ${isLight ? "bg-emerald-50 border-emerald-200 text-slate-800" : "bg-emerald-950/30 border-emerald-500/30 text-gray-200"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-base sm:text-lg font-black text-emerald-700 dark:text-emerald-300 font-['Alexandria']",
											children: language === "ar" ? "5. الخاتمة (Conclusion)" : "5. Conclusion"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "leading-loose",
											style: { fontSize: `${readerFontSize}px` },
											children: language === "ar" ? activeAcademic.conclusionAr : activeAcademic.conclusionEn
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `p-5 sm:p-6 rounded-3xl border space-y-4 ${isLight ? "bg-white border-slate-200 text-slate-800 shadow-sm" : "bg-white/[0.02] border-white/10 text-gray-200"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
											className: "text-base sm:text-lg font-black text-amber-600 dark:text-amber-300 font-['Alexandria'] flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListChecks, { className: "w-5 h-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "6. التوصيات (Recommendations)" : "6. Recommendations" })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "grid grid-cols-1 gap-3",
											children: activeAcademic.recommendations.map((rec, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: `p-4 rounded-2xl border space-y-2 ${isLight ? "bg-slate-50 border-slate-200" : "bg-black/30 border-white/5"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
													className: "text-xs sm:text-sm font-extrabold text-indigo-600 dark:text-cyan-300",
													children: language === "ar" ? rec.categoryAr : rec.categoryEn
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
													className: "space-y-1.5",
													style: { fontSize: `${Math.max(14, readerFontSize - 1)}px` },
													children: (language === "ar" ? rec.itemsAr : rec.itemsEn).map((item, iIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
														className: "flex items-start gap-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-emerald-500 font-bold",
															children: "✓"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "leading-relaxed",
															children: item
														})]
													}, iIdx))
												})]
											}, idx))
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `p-5 sm:p-6 rounded-3xl border space-y-3 ${isLight ? "bg-slate-100 border-slate-300 text-slate-800" : "bg-slate-900/90 border-white/15 text-gray-300"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
											className: "text-base font-black flex items-center gap-2 font-['Alexandria']",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookMarked, { className: "w-4 h-4 text-cyan-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "7. المراجع العلمية الموثقة (References - APA 7th Edition)" : "7. References (APA 7th Edition)" })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
											className: "space-y-2 text-xs font-mono dir-ltr text-left",
											children: activeAcademic.apaReferences.map((cite, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
												className: `p-2.5 rounded-xl border ${isLight ? "bg-white border-slate-200 text-slate-800" : "bg-black/40 border-white/5 text-cyan-100"}`,
												children: [
													idx + 1,
													". ",
													cite
												]
											}, idx))
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `p-5 sm:p-7 rounded-3xl border-2 space-y-4 shadow-xl ${isLight ? "bg-gradient-to-b from-indigo-50/70 via-white to-slate-50 border-indigo-300 text-slate-900" : "bg-gradient-to-b from-indigo-950/40 via-slate-900/95 to-slate-950 border-cyan-500/40 text-gray-100"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center justify-between gap-3 border-b pb-3 border-indigo-200 dark:border-white/15",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-base sm:text-xl font-black font-['Alexandria'] text-indigo-800 dark:text-cyan-300",
											children: language === "ar" ? "📜 النص الكامل المتواصل للبحث العلمي (دون تجزئة)" : "📜 Full Continuous Unsegmented Research Paper"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs opacity-80",
											children: language === "ar" ? "يُعرض هنا المقال العلمي كاملاً ومتواصلاً من البداية إلى النهاية دون أي تجزئة مع الحفاظ على التنسيق الأكاديمي والجداول والمراجع." : "The complete research manuscript is presented below continuously without segmentation."
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => handleCopyFullText(activeAcademic),
										className: "px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs flex items-center gap-1.5 transition cursor-pointer shadow-md shrink-0",
										children: [copiedFullText ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: copiedFullText ? language === "ar" ? "تم النسخ!" : "Copied!" : language === "ar" ? "نسخ النص الكامل للبحث" : "Copy Full Paper Text" })]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `p-4 sm:p-6 rounded-2xl border select-text ${isLight ? "bg-white border-slate-200 text-slate-800 shadow-inner" : "bg-black/40 border-white/10 text-gray-200"}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormattedContinuousManuscript, {
										text: getFullContinuousAcademicText(activeAcademic, language),
										fontSize: readerFontSize,
										isLight
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArticleBottomSocialShare, {
								title: language === "ar" ? activeAcademic.titleAr : activeAcademic.titleEn,
								summary: language === "ar" ? activeAcademic.abstractAr : activeAcademic.abstractEn,
								url: "https://miratalqulub.com/#/articles",
								isLight,
								language
							})
						]
					}, "academic-reader") : null
				})
			})]
		})
	});
};
//#endregion
export { ArticlesSectionModal };
