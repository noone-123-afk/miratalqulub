import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { An as BookOpen, H as ScrollText, Lt as Globe, Nn as ArrowRight, On as Bookmark, Pn as ArrowLeft, S as Sun, Sn as Calendar, Wt as FileText, _n as ChevronRight, a as VolumeX, bn as Check, cn as Clock, gt as MapPin, o as Volume2, st as Moon, vn as ChevronLeft } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import { d as useAppTheme, l as useLanguage } from "./index-C5uCeetQ.js";
import { n as getFullNovelContinuousText, t as NOVELS_CATALOG } from "./data-content-CCe8WBeA.js";
import { t as FormattedContinuousManuscript } from "./ReaderToolbar-CBKPy1tK.js";
import { r as getAllNovels } from "./novelsService-DylA4WsJ.js";
import { t as NovelCommentsSection } from "./NovelCommentsSection-BjwcZvs9.js";
import { t as PageSEO } from "./PageSEO-tUCGtj4d.js";
//#region src/pages/ChapterReaderPage.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var ChapterReaderPage = ({ novelId, chapterIndex, onBackToNovel, onNavigateChapter }) => {
	const { language, setLanguage, isRTL } = useLanguage();
	const { appTheme, toggleAppTheme } = useAppTheme();
	const [novel, setNovel] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [fontSize, setFontSize] = (0, import_react.useState)(19);
	const [readerTheme, setReaderTheme] = (0, import_react.useState)(appTheme === "light" ? "light" : "noir");
	const [isBookmarked, setIsBookmarked] = (0, import_react.useState)(false);
	const [isAmbiencePlaying, setIsAmbiencePlaying] = (0, import_react.useState)(false);
	const [isFullContinuousMode, setIsFullContinuousMode] = (0, import_react.useState)(false);
	const audioCtxRef = (0, import_react.useRef)(null);
	const oscRef = (0, import_react.useRef)(null);
	const gainRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		setReaderTheme(appTheme === "light" ? "light" : "noir");
	}, [appTheme]);
	(0, import_react.useEffect)(() => {
		let isMounted = true;
		getAllNovels().then((list) => {
			if (!isMounted) return;
			const found = list.find((n) => n.id === novelId) || NOVELS_CATALOG.find((n) => n.id === novelId);
			if (found) setNovel(found);
			setLoading(false);
		});
		try {
			const savedBookmark = localStorage.getItem(`mirat_novel_bookmark_${novelId}`);
			if (savedBookmark !== null && parseInt(savedBookmark, 10) === chapterIndex) setIsBookmarked(true);
			else setIsBookmarked(false);
		} catch {}
		window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
		return () => {
			isMounted = false;
			stopAmbience();
		};
	}, [novelId, chapterIndex]);
	const toggleAmbience = () => {
		soundManager.playTap();
		if (isAmbiencePlaying) {
			stopAmbience();
			setIsAmbiencePlaying(false);
		} else {
			startAmbience();
			setIsAmbiencePlaying(true);
		}
	};
	const startAmbience = () => {
		try {
			const AudioCtx = window.AudioContext || window.webkitAudioContext;
			if (!AudioCtx) return;
			const ctx = new AudioCtx();
			audioCtxRef.current = ctx;
			const osc = ctx.createOscillator();
			const gain = ctx.createGain();
			osc.type = "sine";
			osc.frequency.setValueAtTime(55, ctx.currentTime);
			gain.gain.setValueAtTime(.001, ctx.currentTime);
			gain.gain.exponentialRampToValueAtTime(.035, ctx.currentTime + 2);
			osc.connect(gain);
			gain.connect(ctx.destination);
			osc.start();
			oscRef.current = osc;
			gainRef.current = gain;
		} catch {}
	};
	const stopAmbience = () => {
		try {
			if (gainRef.current && audioCtxRef.current) gainRef.current.gain.linearRampToValueAtTime(.001, audioCtxRef.current.currentTime + .5);
			setTimeout(() => {
				try {
					oscRef.current?.stop();
					oscRef.current?.disconnect();
					gainRef.current?.disconnect();
					audioCtxRef.current?.close();
				} catch {}
			}, 550);
		} catch {}
	};
	const handleToggleBookmark = () => {
		soundManager.playTap();
		try {
			if (isBookmarked) {
				localStorage.removeItem(`mirat_novel_bookmark_${novelId}`);
				setIsBookmarked(false);
			} else {
				localStorage.setItem(`mirat_novel_bookmark_${novelId}`, chapterIndex.toString());
				setIsBookmarked(true);
			}
		} catch {}
	};
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-slate-400",
			children: language === "ar" ? "جارٍ تحضير الفصل..." : "Preparing chapter..."
		})
	});
	if (!novel || !novel.chapters || !novel.chapters[chapterIndex]) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center p-6 space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "w-12 h-12 text-slate-600" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xl font-bold",
				children: language === "ar" ? "الفصل غير متاح" : "Chapter Unavailable"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: onBackToNovel,
				className: "px-4 py-2 bg-rose-600 text-white rounded-xl text-sm font-semibold",
				children: language === "ar" ? "العودة لملف الرواية" : "Back to Novel"
			})
		]
	});
	const currentChapter = novel.chapters[chapterIndex];
	const hasPrev = chapterIndex > 0;
	const hasNext = chapterIndex < novel.chapters.length - 1;
	const displayNovelTitle = language === "en" && novel.titleEn ? novel.titleEn : novel.titleAr;
	const displayChapterTitle = language === "en" && currentChapter.titleEn ? currentChapter.titleEn : currentChapter.titleAr;
	const displayContent = language === "en" && currentChapter.contentEn ? currentChapter.contentEn : currentChapter.contentAr;
	const displayTime = language === "en" && novel.timeSettingEn ? novel.timeSettingEn : novel.timeSettingAr;
	const displayPlace = language === "en" && novel.placeSettingEn ? novel.placeSettingEn : novel.placeSettingAr;
	const isLightReader = readerTheme === "light";
	const themeClasses = {
		light: "bg-slate-50 text-slate-900",
		noir: "bg-slate-950 text-slate-100",
		cyber: "bg-[#090d16] text-[#e0e7ff]",
		amber: "bg-[#18130e] text-[#f7e6ce]"
	};
	const themePaperClasses = {
		light: "bg-white border-slate-200 text-slate-800 shadow-lg",
		noir: "bg-slate-900/60 border-slate-800/80 text-slate-200 shadow-2xl",
		cyber: "bg-[#0f172a]/70 border-cyan-900/40 text-slate-200 shadow-2xl",
		amber: "bg-[#231a12]/70 border-amber-900/40 text-[#ede0d4] shadow-2xl"
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		dir: isRTL ? "rtl" : "ltr",
		className: `min-h-screen ${themeClasses[readerTheme]} py-8 px-4 sm:px-6 lg:px-8 transition-colors duration-300 selection:bg-rose-500/30`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageSEO, {
			title: `${displayChapterTitle} - ${displayNovelTitle} | ${language === "ar" ? "مرآة القلوب" : "Mirror of Hearts"}`,
			description: currentChapter.synopsisAr,
			canonicalPath: `/#/novels/${novel.id}/chapter/${currentChapter.chapterNumber}`,
			language
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-4xl mx-auto space-y-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: `sticky top-2 z-30 backdrop-blur-md border rounded-2xl p-3 sm:p-4 shadow-xl flex flex-wrap items-center justify-between gap-3 ${isLightReader ? "bg-white/95 border-slate-200" : "bg-slate-900/90 border-slate-800"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								soundManager.playTap();
								onBackToNovel();
							},
							className: `p-2 rounded-xl transition-colors cursor-pointer ${isLightReader ? "bg-slate-100 hover:bg-slate-200 text-slate-700" : "bg-slate-800/80 hover:bg-slate-800 text-slate-300 hover:text-white"}`,
							title: language === "ar" ? "العودة لملف الرواية" : "Back to Novel",
							children: isRTL ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "w-4 h-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "w-4 h-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-rose-500 font-bold",
							children: displayNovelTitle
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: `text-xs sm:text-sm font-bold truncate max-w-[180px] sm:max-w-xs ${isLightReader ? "text-slate-900" : "text-white"}`,
							children: displayChapterTitle
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									soundManager.playTap();
									setIsFullContinuousMode((prev) => !prev);
								},
								className: `px-3 py-1.5 rounded-xl border text-xs font-extrabold flex items-center gap-1.5 transition cursor-pointer ${isFullContinuousMode ? "bg-indigo-600 text-white border-indigo-500 shadow-md" : isLightReader ? "bg-indigo-50 border-indigo-200 text-indigo-800 hover:bg-indigo-100" : "bg-indigo-950/70 border-indigo-500/40 text-cyan-200 hover:bg-indigo-900/80"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollText, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isFullContinuousMode ? language === "ar" ? "العودة لقراءة الفصول" : "Chapter View" : language === "ar" ? "📜 قراءة كاملة دون تجزئة" : "📜 Full Unsegmented" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => {
									soundManager.playTap();
									setLanguage(language === "ar" ? "en" : "ar");
								},
								className: `px-2.5 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1 cursor-pointer ${isLightReader ? "bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200" : "bg-slate-800/80 border-slate-700/60 text-slate-200 hover:bg-slate-700"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "w-3.5 h-3.5 text-cyan-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "EN" : "AR" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: toggleAmbience,
								className: `p-2 rounded-xl border text-xs flex items-center gap-1.5 transition-colors cursor-pointer ${isAmbiencePlaying ? "bg-rose-500/20 border-rose-500/50 text-rose-400" : isLightReader ? "bg-slate-100 border-slate-200 text-slate-600" : "bg-slate-800/80 border-slate-700/60 text-slate-400 hover:text-slate-200"}`,
								title: language === "ar" ? "المؤثرات الصوتية والتركيز" : "Ambient Focus Drone",
								children: isAmbiencePlaying ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "w-4 h-4 text-rose-500" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "w-4 h-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `flex items-center rounded-xl border p-0.5 ${isLightReader ? "bg-slate-100 border-slate-200" : "bg-slate-800/80 border-slate-700/60"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => {
											soundManager.playTap();
											setFontSize((prev) => Math.max(14, prev - 1));
										},
										className: "px-2 py-1 text-xs font-bold cursor-pointer",
										children: "A-"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[11px] px-1 text-slate-400 font-mono",
										children: fontSize
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => {
											soundManager.playTap();
											setFontSize((prev) => Math.min(28, prev + 1));
										},
										className: "px-2 py-1 text-xs font-bold cursor-pointer",
										children: "A+"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `flex items-center gap-1.5 p-1 rounded-xl border ${isLightReader ? "bg-slate-100 border-slate-200" : "bg-slate-800/80 border-slate-700/60"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => {
											setReaderTheme("light");
											if (appTheme !== "light") toggleAppTheme();
										},
										className: `p-1 rounded-lg flex items-center gap-1 text-[11px] font-bold cursor-pointer ${readerTheme === "light" ? "bg-white text-amber-600 shadow-sm" : "text-slate-400"}`,
										title: language === "ar" ? "الوضع النهاري الفاتح" : "Light Mode",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "w-3.5 h-3.5" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => {
											setReaderTheme("noir");
											if (appTheme !== "dark") toggleAppTheme();
										},
										className: `p-1 rounded-lg flex items-center gap-1 text-[11px] font-bold cursor-pointer ${readerTheme === "noir" ? "bg-slate-950 text-rose-400 shadow-sm" : "text-slate-400"}`,
										title: language === "ar" ? "الوضع الليلي الداكن" : "Dark Mode",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "w-3.5 h-3.5" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => setReaderTheme("amber"),
										className: `w-5 h-5 rounded-full bg-[#231a12] border cursor-pointer ${readerTheme === "amber" ? "border-amber-500 ring-1 ring-amber-500" : "border-slate-600"}`,
										title: language === "ar" ? "وضع الورق الدافئ" : "Warm Sepia"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: handleToggleBookmark,
								className: `p-2 rounded-xl border transition-colors cursor-pointer ${isBookmarked ? "bg-amber-500/20 border-amber-500/50 text-amber-500" : isLightReader ? "bg-slate-100 border-slate-200 text-slate-600" : "bg-slate-800/80 border-slate-700/60 text-slate-400 hover:text-slate-200"}`,
								title: language === "ar" ? "حفظ إشارة مرجعية" : "Save Bookmark",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: `w-4 h-4 ${isBookmarked ? "fill-amber-400" : ""}` })
							})
						]
					})]
				}),
				(displayTime || displayPlace) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `rounded-2xl border p-3.5 flex flex-wrap items-center justify-between gap-3 text-xs ${isLightReader ? "bg-white border-slate-200 text-slate-700 shadow-sm" : "bg-slate-900/60 border-slate-800/80 text-slate-300"}`,
					children: [displayTime && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "w-4 h-4 text-amber-500 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "text-amber-500",
							children: language === "ar" ? "الزمان: " : "Time: "
						}), displayTime] })]
					}), displayPlace && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "w-4 h-4 text-emerald-500 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "text-emerald-500",
							children: language === "ar" ? "المكان: " : "Place: "
						}), displayPlace] })]
					})]
				}),
				currentChapter.sceneIllustrationSvg && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl overflow-hidden bg-slate-950 border border-slate-800/80 p-3 shadow-md max-w-2xl mx-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-full h-48 sm:h-60 flex items-center justify-center",
						dangerouslySetInnerHTML: { __html: currentChapter.sceneIllustrationSvg }
					}), currentChapter.illustrationCaptionAr && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-center text-xs text-slate-300 mt-2 font-serif italic",
						children: currentChapter.illustrationCaptionAr
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center space-y-2 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-bold uppercase tracking-wider text-rose-500 px-3 py-1 rounded-full bg-rose-500/10 border border-rose-500/30",
							children: language === "ar" ? `الفصل ${currentChapter.chapterNumber}` : `Chapter ${currentChapter.chapterNumber}`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: `text-2xl sm:text-4xl font-black tracking-tight mt-2 ${isLightReader ? "text-slate-900" : "text-white"}`,
							children: displayChapterTitle
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-center gap-3 text-xs text-slate-400 pt-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										currentChapter.estimatedMinutes,
										" ",
										language === "ar" ? "دقيقة قراءة" : "min read"
									] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									currentChapter.wordsCount.toLocaleString(),
									" ",
									language === "ar" ? "كلمة" : "words"
								] })
							]
						})
					]
				}),
				isFullContinuousMode ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: `rounded-3xl border p-6 sm:p-12 leading-relaxed ${themePaperClasses[readerTheme]}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-6 pb-4 border-b border-rose-500/20 flex flex-wrap items-center justify-between gap-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/15 border border-indigo-500/30 text-indigo-500 dark:text-cyan-300 text-xs font-extrabold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollText, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "وضع القراءة الكاملة المتواصلة للقصة / الرواية (دون تجزئة)" : "Full Continuous Unsegmented Story Mode" })]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormattedContinuousManuscript, {
						text: getFullNovelContinuousText(novel, language),
						fontSize,
						isLight: isLightReader
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
					className: `rounded-3xl border p-6 sm:p-12 leading-relaxed font-serif ${themePaperClasses[readerTheme]}`,
					style: {
						fontSize: `${fontSize}px`,
						lineHeight: 1.95
					},
					children: displayContent.split("\n\n").map((block, pIdx) => {
						const trimmed = block.trim();
						if (!trimmed) return null;
						if (trimmed === "***" || trimmed === "---") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "my-8 flex items-center justify-center gap-3 opacity-50",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-12 h-px bg-current" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "✦ ✦ ✦" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-12 h-px bg-current" })
							]
						}, pIdx);
						if (trimmed.startsWith("## ")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl sm:text-2xl font-black text-rose-500 mt-8 mb-4 pb-2 border-b border-rose-500/20",
							children: trimmed.replace(/^##\s+/, "")
						}, pIdx);
						if (trimmed.startsWith("### ")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-lg sm:text-xl font-bold text-amber-500 mt-6 mb-3",
							children: trimmed.replace(/^###\s+/, "")
						}, pIdx);
						if (trimmed.startsWith(">")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
							className: `my-6 p-5 rounded-2xl border-r-4 rtl:border-r-4 ltr:border-l-4 ltr:border-r-0 border-rose-500 italic ${isLightReader ? "bg-rose-50/70 text-slate-800" : "bg-rose-950/20 text-rose-100"}`,
							children: trimmed.replace(/^>\s*/gm, "")
						}, pIdx);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-6 whitespace-pre-line",
							children: trimmed
						}, pIdx);
					})
				}),
				currentChapter.detectiveNotesAr && currentChapter.detectiveNotesAr.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `border border-amber-500/30 rounded-2xl p-5 space-y-2 ${isLightReader ? "bg-amber-50 text-slate-800" : "bg-slate-900/80 text-slate-200"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-amber-500 text-xs font-bold uppercase tracking-wider",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "ملاحظات التحقيق:" : "Investigative Observations:" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-1 text-xs list-disc list-inside",
						children: currentChapter.detectiveNotesAr.map((note, nIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: note }, nIdx))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `flex items-center justify-between border-t pt-6 ${isLightReader ? "border-slate-200" : "border-slate-800/80"}`,
					children: [
						hasPrev ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundManager.playTap();
								onNavigateChapter(chapterIndex - 1);
							},
							className: `inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border text-xs font-bold transition-colors cursor-pointer ${isLightReader ? "bg-white hover:bg-slate-100 border-slate-200 text-slate-800" : "bg-slate-900 hover:bg-slate-800 border-slate-800 text-slate-200"}`,
							children: [isRTL ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "w-4 h-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "الفصل السابق" : "Previous Chapter" })]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								soundManager.playTap();
								onBackToNovel();
							},
							className: "text-xs text-rose-500 font-bold hover:underline cursor-pointer",
							children: language === "ar" ? "فهرس الفصول وتفاصيل الرواية" : "Table of Contents"
						}),
						hasNext ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundManager.playTap();
								onNavigateChapter(chapterIndex + 1);
							},
							className: "inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-xs font-bold text-white transition-all shadow-md cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "الفصل التالي" : "Next Chapter" }), isRTL ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "w-4 h-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "w-4 h-4" })]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundManager.playTap();
								onBackToNovel();
							},
							className: "inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-bold text-white transition-all cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "اكتملت الرواية — العودة للملف" : "Completed Novel" })]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `border rounded-3xl p-6 mt-8 ${isLightReader ? "bg-white border-slate-200 shadow-sm" : "bg-slate-900/60 border-slate-800/80"}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NovelCommentsSection, {
						novelId: novel.id,
						novelTitle: displayNovelTitle
					})
				})
			]
		})]
	});
};
//#endregion
export { ChapterReaderPage };
