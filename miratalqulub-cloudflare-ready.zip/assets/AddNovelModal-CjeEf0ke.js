import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { An as BookOpen, D as Sparkles, F as ShieldAlert, W as Save, Wt as FileText, b as Target, d as UserCheck, et as Plus, h as Trash2, r as X, rt as PenLine } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import { u as useAuth } from "./index-C5uCeetQ.js";
import { t as motion } from "./vendor-motion-BS7ODJw7.js";
import { c as saveOrUpdateNovel } from "./novelsService-DylA4WsJ.js";
//#region src/components/AddNovelModal.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var COVER_PRESETS = {
	clinical_stories: `
    <svg viewBox="0 0 400 560" className="w-full h-full object-cover" xmlns="http://www.w3.org/2000/svg">
      <rect width="400" height="560" fill="#1e1b4b"/>
      <circle cx="200" cy="230" r="90" fill="#ec4899" opacity="0.25"/>
      <rect x="30" y="475" width="340" height="38" rx="8" fill="#312e81" stroke="#f472b6" stroke-width="1.5"/>
      <text x="200" y="500" font-family="sans-serif" font-size="13" font-weight="900" fill="#fdf2f8" text-anchor="middle">
        CLINICAL STORIES • مجموعات قصصية عيادية
      </text>
    </svg>
  `,
	romance: `
    <svg viewBox="0 0 400 560" className="w-full h-full object-cover" xmlns="http://www.w3.org/2000/svg">
      <rect width="400" height="560" fill="#06281e"/>
      <circle cx="200" cy="230" r="90" fill="#10b981" opacity="0.25"/>
      <rect x="30" y="475" width="340" height="38" rx="8" fill="#064e3b" stroke="#34d399" stroke-width="1.5"/>
      <text x="200" y="500" font-family="sans-serif" font-size="13" font-weight="900" fill="#ecfdf5" text-anchor="middle">
        ROMANCE &amp; HERITAGE • روايات رومانسية واجتماعية
      </text>
    </svg>
  `,
	crime_mystery: `
    <svg viewBox="0 0 400 560" className="w-full h-full object-cover" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="cov_cm_bg" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#0f051d"/>
          <stop offset="50%" stop-color="#1e1026"/>
          <stop offset="100%" stop-color="#2a0815"/>
        </linearGradient>
      </defs>
      <rect width="400" height="560" fill="url(#cov_cm_bg)"/>
      <ellipse cx="200" cy="220" rx="90" ry="90" fill="#f43f5e" opacity="0.3"/>
      <!-- Fingerprint lines -->
      <g stroke="#f43f5e" stroke-width="2.5" fill="none" opacity="0.8">
        <path d="M200,160 Q200,220 200,280"/>
        <path d="M185,175 Q175,220 188,290"/>
        <path d="M215,175 Q225,220 212,290"/>
        <path d="M170,195 Q160,230 176,305"/>
        <path d="M230,195 Q240,230 224,305"/>
      </g>
      <!-- Crime tape -->
      <g transform="rotate(-6, 200, 480)">
        <rect x="-30" y="460" width="460" height="32" fill="#fbbf24" opacity="0.9"/>
        <text x="200" y="482" font-family="monospace" font-size="12" font-weight="900" fill="#000" text-anchor="middle">
          CRIME SCENE INVESTIGATION • أدلة جنائية
        </text>
      </g>
    </svg>
  `,
	tactical_action: `
    <svg viewBox="0 0 400 560" className="w-full h-full object-cover" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="cov_ta_bg" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#1c0c04"/>
          <stop offset="100%" stop-color="#2d1305"/>
        </linearGradient>
      </defs>
      <rect width="400" height="560" fill="url(#cov_ta_bg)"/>
      <circle cx="200" cy="240" r="80" stroke="#f97316" stroke-width="2" fill="none" opacity="0.7"/>
      <circle cx="200" cy="240" r="30" stroke="#ef4444" stroke-width="2" fill="none" opacity="0.8"/>
      <line x1="100" y1="240" x2="300" y2="240" stroke="#f97316" stroke-width="2"/>
      <line x1="200" y1="140" x2="200" y2="340" stroke="#f97316" stroke-width="2"/>
      <polygon points="200,225 215,250 185,250" fill="#facc15"/>
      <rect x="30" y="475" width="340" height="38" rx="8" fill="#000" opacity="0.85" stroke="#f97316" stroke-width="1.5"/>
      <text x="200" y="500" font-family="sans-serif" font-size="13" font-weight="900" fill="#f97316" text-anchor="middle">
        TACTICAL MISSION • عمليات خاصة
      </text>
    </svg>
  `,
	sci_fi_future: `
    <svg viewBox="0 0 400 560" className="w-full h-full object-cover" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="cov_sf_bg" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#020617"/>
          <stop offset="100%" stop-color="#082f49"/>
        </linearGradient>
      </defs>
      <rect width="400" height="560" fill="url(#cov_sf_bg)"/>
      <ellipse cx="200" cy="220" rx="110" ry="35" fill="none" stroke="#38bdf8" stroke-width="4" opacity="0.9"/>
      <circle cx="200" cy="220" r="25" fill="#38bdf8"/>
      <line x1="200" y1="40" x2="200" y2="520" stroke="#bae6fd" stroke-width="2" opacity="0.8"/>
      <rect x="30" y="475" width="340" height="38" rx="8" fill="#020617" opacity="0.85" stroke="#38bdf8" stroke-width="1.5"/>
      <text x="200" y="500" font-family="sans-serif" font-size="13" font-weight="900" fill="#38bdf8" text-anchor="middle">
        FUTURE HORIZON • استشراف المستقبل
      </text>
    </svg>
  `,
	sci_fantasy: `
    <svg viewBox="0 0 400 560" className="w-full h-full object-cover" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="cov_fan_bg" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#1e1035"/>
          <stop offset="100%" stop-color="#3b0764"/>
        </linearGradient>
      </defs>
      <rect width="400" height="560" fill="url(#cov_fan_bg)"/>
      <polygon points="120,380 200,140 280,380" fill="#a855f7" opacity="0.4"/>
      <line x1="140" y1="200" x2="260" y2="200" stroke="#f0abfc" stroke-width="3"/>
      <circle cx="200" cy="140" r="10" fill="#ffffff"/>
      <rect x="30" y="475" width="340" height="38" rx="8" fill="#0f0728" opacity="0.85" stroke="#c084fc" stroke-width="1.5"/>
      <text x="200" y="500" font-family="sans-serif" font-size="13" font-weight="900" fill="#c084fc" text-anchor="middle">
        KINETIC BLADE • أكشن وخيال إبداعي
      </text>
    </svg>
  `
};
var AddNovelModal = ({ isOpen, onClose, onNovelCreated, initialNovel }) => {
	const { isOwner } = useAuth();
	const isEditMode = Boolean(initialNovel);
	const [titleAr, setTitleAr] = (0, import_react.useState)("");
	const [subtitleAr, setSubtitleAr] = (0, import_react.useState)("");
	const [genre, setGenre] = (0, import_react.useState)("crime_mystery");
	const [authorPersonaAr, setAuthorPersonaAr] = (0, import_react.useState)("المحقق ساري كنعان");
	const [authorTitleAr, setAuthorTitleAr] = (0, import_react.useState)("خبير التحقيقات الجنائية والعلوم السلوكية");
	const [synopsisAr, setSynopsisAr] = (0, import_react.useState)("");
	const [forensicThemeAr, setForensicThemeAr] = (0, import_react.useState)("الأدلة الجنائية، فحص البصمات والميكرو-تعبيرات");
	const [psychologicalFocusAr, setPsychologicalFocusAr] = (0, import_react.useState)("تحليل شخصية الجاني ودوافعه السيكولوجية");
	const [chapters, setChapters] = (0, import_react.useState)([]);
	const [selectedChapterIdx, setSelectedChapterIdx] = (0, import_react.useState)(0);
	const [chapterTitle, setChapterTitle] = (0, import_react.useState)("");
	const [chapterSynopsis, setChapterSynopsis] = (0, import_react.useState)("");
	const [chapterContent, setChapterContent] = (0, import_react.useState)("");
	const [clues, setClues] = (0, import_react.useState)([]);
	const [suspects, setSuspects] = (0, import_react.useState)([]);
	const [clueTitle, setClueTitle] = (0, import_react.useState)("");
	const [clueDesc, setClueDesc] = (0, import_react.useState)("");
	const [clueLab, setClueLab] = (0, import_react.useState)("");
	const [suspectName, setSuspectName] = (0, import_react.useState)("");
	const [suspectRole, setSuspectRole] = (0, import_react.useState)("");
	const [suspectAlibi, setSuspectAlibi] = (0, import_react.useState)("");
	const [suspectMotive, setSuspectMotive] = (0, import_react.useState)("");
	const [suspectMotiveRating, setSuspectMotiveRating] = (0, import_react.useState)(85);
	const [isSaving, setIsSaving] = (0, import_react.useState)(false);
	const [errorMessage, setErrorMessage] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (initialNovel) {
			setTitleAr(initialNovel.titleAr || "");
			setSubtitleAr(initialNovel.subtitleAr || "");
			setGenre(initialNovel.genre || "crime_mystery");
			setAuthorPersonaAr(initialNovel.authorPersonaAr || "المحقق ساري كنعان");
			setAuthorTitleAr(initialNovel.authorTitleAr || "خبير التحقيقات الجنائية والعلوم السلوكية");
			setSynopsisAr(initialNovel.synopsisAr || "");
			setForensicThemeAr(initialNovel.forensicThemeAr || "");
			setPsychologicalFocusAr(initialNovel.psychologicalFocusAr || "");
			const loadedChapters = initialNovel.chapters && initialNovel.chapters.length > 0 ? [...initialNovel.chapters] : [{
				chapterNumber: 1,
				titleAr: "الفصل الأول: البداية ومسرح الحادث",
				synopsisAr: "معاينة مسرح الجريمة الأولي وبدء استجواب الخيوط المتاحة.",
				contentAr: "",
				estimatedMinutes: 5,
				wordsCount: 500,
				sceneIllustrationSvg: COVER_PRESETS[initialNovel.genre || "crime_mystery"],
				illustrationCaptionAr: `مشهد من ${initialNovel.titleAr}`
			}];
			setChapters(loadedChapters);
			setSelectedChapterIdx(0);
			setChapterTitle(loadedChapters[0]?.titleAr || "");
			setChapterSynopsis(loadedChapters[0]?.synopsisAr || "");
			setChapterContent(loadedChapters[0]?.contentAr || "");
			const initialClues = [];
			loadedChapters.forEach((ch) => {
				if (ch.investigationClues) initialClues.push(...ch.investigationClues);
			});
			setClues(initialClues);
			setSuspects(initialNovel.suspectsDossier ? [...initialNovel.suspectsDossier] : []);
		} else {
			setTitleAr("");
			setSubtitleAr("");
			setGenre("crime_mystery");
			setAuthorPersonaAr("المحقق ساري كنعان");
			setAuthorTitleAr("خبير التحقيقات الجنائية والعلوم السلوكية");
			setSynopsisAr("");
			setForensicThemeAr("الأدلة الجنائية، فحص البصمات والميكرو-تعبيرات");
			setPsychologicalFocusAr("تحليل شخصية الجاني ودوافعه السيكولوجية");
			const defaultChapter = {
				chapterNumber: 1,
				titleAr: "الفصل الأول: البداية ومسرح الحادث",
				synopsisAr: "معاينة مسرح الجريمة الأولي وبدء استجواب الخيوط المتاحة.",
				contentAr: "",
				estimatedMinutes: 5,
				wordsCount: 0,
				sceneIllustrationSvg: COVER_PRESETS.crime_mystery,
				illustrationCaptionAr: "مسرح الأحداث الأول"
			};
			setChapters([defaultChapter]);
			setSelectedChapterIdx(0);
			setChapterTitle(defaultChapter.titleAr);
			setChapterSynopsis(defaultChapter.synopsisAr);
			setChapterContent("");
			setClues([]);
			setSuspects([]);
		}
		setErrorMessage("");
	}, [initialNovel, isOpen]);
	const handleSwitchChapter = (newIdx) => {
		const updated = [...chapters];
		if (updated[selectedChapterIdx]) {
			const words = chapterContent.trim().split(/\s+/).filter(Boolean).length;
			updated[selectedChapterIdx] = {
				...updated[selectedChapterIdx],
				titleAr: chapterTitle.trim() || `الفصل ${selectedChapterIdx + 1}`,
				synopsisAr: chapterSynopsis.trim(),
				contentAr: chapterContent,
				wordsCount: words,
				estimatedMinutes: Math.max(2, Math.round(words / 130))
			};
			setChapters(updated);
		}
		setSelectedChapterIdx(newIdx);
		if (updated[newIdx]) {
			setChapterTitle(updated[newIdx].titleAr);
			setChapterSynopsis(updated[newIdx].synopsisAr);
			setChapterContent(updated[newIdx].contentAr);
		}
	};
	const handleAddNewChapter = () => {
		soundManager.playTap();
		const updated = [...chapters];
		if (updated[selectedChapterIdx]) {
			const words = chapterContent.trim().split(/\s+/).filter(Boolean).length;
			updated[selectedChapterIdx] = {
				...updated[selectedChapterIdx],
				titleAr: chapterTitle.trim() || `الفصل ${selectedChapterIdx + 1}`,
				synopsisAr: chapterSynopsis.trim(),
				contentAr: chapterContent,
				wordsCount: words,
				estimatedMinutes: Math.max(2, Math.round(words / 130))
			};
		}
		const nextNum = updated.length + 1;
		const newChapter = {
			chapterNumber: nextNum,
			titleAr: `الفصل ${nextNum}: تطور الأحداث والمواجهة`,
			synopsisAr: "خيوط جديدة تتكشف في مسار القضية والتحقيق السيكولوجي.",
			contentAr: "",
			estimatedMinutes: 5,
			wordsCount: 0,
			sceneIllustrationSvg: COVER_PRESETS[genre],
			illustrationCaptionAr: `مشهد من الفصل ${nextNum}`
		};
		const nextList = [...updated, newChapter];
		setChapters(nextList);
		setSelectedChapterIdx(nextList.length - 1);
		setChapterTitle(newChapter.titleAr);
		setChapterSynopsis(newChapter.synopsisAr);
		setChapterContent("");
	};
	const handleRemoveChapter = (idxToRemove) => {
		if (chapters.length <= 1) return;
		soundManager.playTap();
		const filtered = chapters.filter((_, idx) => idx !== idxToRemove).map((ch, i) => ({
			...ch,
			chapterNumber: i + 1
		}));
		setChapters(filtered);
		const newIdx = Math.max(0, idxToRemove - 1);
		setSelectedChapterIdx(newIdx);
		setChapterTitle(filtered[newIdx].titleAr);
		setChapterSynopsis(filtered[newIdx].synopsisAr);
		setChapterContent(filtered[newIdx].contentAr);
	};
	const handleAddClue = () => {
		if (!clueTitle.trim() || !clueDesc.trim()) return;
		soundManager.playTap();
		const newClue = {
			id: `clue_${Date.now()}`,
			titleAr: clueTitle.trim(),
			type: "forensic",
			descriptionAr: clueDesc.trim(),
			forensicLabReportAr: clueLab.trim() || "فحص مخبري جنائي أثبت تطابق البصمات الجزيئية ومطياف الكتلة.",
			significanceLevel: "حاسم",
			status: "تم فحصها وتحريزها"
		};
		setClues([...clues, newClue]);
		setClueTitle("");
		setClueDesc("");
		setClueLab("");
	};
	const handleRemoveClue = (id) => {
		soundManager.playTap();
		setClues(clues.filter((c) => c.id !== id));
	};
	const handleAddSuspect = () => {
		if (!suspectName.trim() || !suspectRole.trim()) return;
		soundManager.playTap();
		const newSuspect = {
			nameAr: suspectName.trim(),
			roleAr: suspectRole.trim(),
			age: 35,
			alibiAr: suspectAlibi.trim() || "ادعى التواجد خارج موقع الحادث ساعة وقوع الجريمة.",
			psychologicalMotiveAr: suspectMotive.trim() || "دافع مالي وانتقامي نرجسي.",
			behavioralTraitsAr: ["برود انفعالي مدروس", "تجنب النظر المباشر عند ذكر التوقيت الجنائي"],
			motiveRating: suspectMotiveRating,
			status: suspectMotiveRating >= 80 ? "المشتبه به الرئيسي" : "محتجز للتحقيق"
		};
		setSuspects([...suspects, newSuspect]);
		setSuspectName("");
		setSuspectRole("");
		setSuspectAlibi("");
		setSuspectMotive("");
	};
	const handleRemoveSuspect = (idx) => {
		soundManager.playTap();
		setSuspects(suspects.filter((_, i) => i !== idx));
	};
	if (!isOpen) return null;
	if (!isOwner) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md text-right",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "p-6 rounded-3xl bg-slate-900 border border-red-500/30 max-w-md text-center space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "w-12 h-12 text-red-400 mx-auto" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-bold text-white text-base",
					children: "خاصية محصورة بمالك الموقع فقط"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-gray-300",
					children: "هذه اللوحة مخصصة لحساب مالك الموقع (one497303@gmail.com) لنشر وتعديل وحذف الروايات الرسمية."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onClose,
					className: "px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-bold transition cursor-pointer",
					children: "إغلاق"
				})
			]
		})
	});
	const handleSaveNovel = async (e) => {
		e.preventDefault();
		if (!titleAr.trim() || !synopsisAr.trim() || !chapterContent.trim()) {
			setErrorMessage("يرجى ملء عنوان الرواية، الملخص التشويقي، ونص الفصل الحالي على الأقل.");
			return;
		}
		setIsSaving(true);
		setErrorMessage("");
		soundManager.playTap();
		const updatedChapters = [...chapters];
		const currentWords = chapterContent.trim().split(/\s+/).filter(Boolean).length;
		updatedChapters[selectedChapterIdx] = {
			...updatedChapters[selectedChapterIdx] || {},
			chapterNumber: selectedChapterIdx + 1,
			titleAr: chapterTitle.trim() || `الفصل ${selectedChapterIdx + 1}`,
			synopsisAr: chapterSynopsis.trim() || "أحداث مشوقة ومكثفة.",
			contentAr: chapterContent.trim(),
			wordsCount: currentWords,
			estimatedMinutes: Math.max(2, Math.round(currentWords / 130)),
			sceneIllustrationSvg: updatedChapters[selectedChapterIdx]?.sceneIllustrationSvg || COVER_PRESETS[genre],
			illustrationCaptionAr: `مشهد من ${titleAr.trim()}`,
			detectiveNotesAr: updatedChapters[selectedChapterIdx]?.detectiveNotesAr || ["معاينة أولية تفيد بوجود تناقض واضح بين إفادة المشتبه به والأدلة المادية المحرزة.", "تم تحريز كافة العينات وإحالتها للمختبر الجنائي المركزي لمطابقة البصمات."],
			investigationClues: clues.length > 0 ? clues : void 0
		};
		const totalWords = updatedChapters.reduce((acc, ch) => acc + (ch.wordsCount || 0), 0);
		const totalMinutes = Math.max(3, Math.round(totalWords / 130));
		const genreLabels = {
			clinical_stories: {
				label: "مجموعات قصصية عيادية وسيكولوجية",
				color: "#ec4899"
			},
			romance: {
				label: "روايات رومانسية واجتماعية",
				color: "#10b981"
			},
			crime_mystery: {
				label: "غموض وجرائم جنائية",
				color: "#ef4444"
			},
			tactical_action: {
				label: "أكشن ومطاردات تكتيكية",
				color: "#f97316"
			},
			sci_fi_future: {
				label: "خيال علمي وتطوير ومستقبل",
				color: "#06b6d4"
			},
			sci_fantasy: {
				label: "أكشن وخيال إبداعي",
				color: "#8b5cf6"
			}
		};
		const savedNovel = {
			id: initialNovel ? initialNovel.id : `nov_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
			titleAr: titleAr.trim(),
			subtitleAr: subtitleAr.trim() || (isEditMode ? initialNovel?.subtitleAr || "" : "رواية تشويقية حصرية من مالك المنصة"),
			genre,
			genreLabelAr: genreLabels[genre].label,
			genreBadgeColor: genreLabels[genre].color,
			coverIllustrationSvg: initialNovel?.coverIllustrationSvg || COVER_PRESETS[genre],
			rating: initialNovel ? initialNovel.rating : 5,
			readsCount: initialNovel ? initialNovel.readsCount : 1,
			totalChapters: updatedChapters.length,
			totalWords: totalWords || currentWords,
			estimatedReadingTime: `${totalMinutes} دقيقة`,
			authorPersonaAr: authorPersonaAr.trim() || "المحقق ساري كنعان",
			authorTitleAr: authorTitleAr.trim() || "خبير التحقيقات الجنائية المعتمد",
			synopsisAr: synopsisAr.trim(),
			forensicThemeAr: forensicThemeAr.trim(),
			psychologicalFocusAr: psychologicalFocusAr.trim(),
			suspectsDossier: suspects.length > 0 ? suspects : void 0,
			chapters: updatedChapters
		};
		try {
			await saveOrUpdateNovel(savedNovel);
			soundManager.playRoundPass();
			onNovelCreated(savedNovel);
			onClose();
		} catch (err) {
			console.error("Error saving novel", err);
			setErrorMessage("حدث خطأ أثناء حفظ الرواية، يرجى المحاولة ثانية.");
		} finally {
			setIsSaving(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/90 backdrop-blur-md overflow-y-auto text-right",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: {
				opacity: 0,
				scale: .95,
				y: 15
			},
			animate: {
				opacity: 1,
				scale: 1,
				y: 0
			},
			exit: {
				opacity: 0,
				scale: .95,
				y: 15
			},
			className: "glass-panel w-full max-w-4xl rounded-3xl p-5 sm:p-7 border border-amber-500/40 shadow-2xl relative my-auto max-h-[92vh] flex flex-col overflow-hidden bg-slate-950",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between pb-4 border-b border-white/10 shrink-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 to-rose-600 flex items-center justify-center text-white shadow-lg",
						children: isEditMode ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "w-5 h-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "w-5 h-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30",
							children: "لوحة تحكم مالك الموقع 👑"
						}), isEditMode && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] font-bold text-rose-400",
							children: "وضع التعديل المباشر"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-extrabold text-white text-base sm:text-lg font-['Alexandria']",
						children: isEditMode ? `تعديل الرواية: ${titleAr || initialNovel?.titleAr}` : "كتابة ونشر رواية جديدة"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onClose,
					"aria-label": "إغلاق نافذة الرواية",
					title: "إغلاق",
					className: "p-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition cursor-pointer",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-5 h-5" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: handleSaveNovel,
				className: "flex-1 overflow-y-auto py-4 space-y-6 custom-scrollbar pr-1",
				children: [
					errorMessage && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-3 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-bold flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "w-4 h-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: errorMessage })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4 p-4 rounded-2xl bg-white/5 border border-white/10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
								className: "text-xs font-extrabold text-amber-400 flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "1. بيانات وهوية الرواية" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block text-xs font-bold text-gray-300 mb-1",
									children: ["عنوان الرواية ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-rose-400",
										children: "*"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									required: true,
									value: titleAr,
									onChange: (e) => setTitleAr(e.target.value),
									placeholder: "مثال: لغز خريطة الميكرون، بصمة الظل...",
									className: "w-full px-3 py-2 rounded-xl bg-black/40 border border-white/15 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-amber-400"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-gray-300 mb-1",
									children: "العنوان الفرعي / الشعار التشويقي"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									value: subtitleAr,
									onChange: (e) => setSubtitleAr(e.target.value),
									placeholder: "مثال: تحقيق جنائي مستحيل خلف الجدران الذكية",
									className: "w-full px-3 py-2 rounded-xl bg-black/40 border border-white/15 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-amber-400"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-bold text-gray-300 mb-1.5",
								children: "تصنيف الرواية (النوع الأدبي)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs",
								children: [
									{
										key: "crime_mystery",
										label: "جرائم وغموض",
										icon: "🔍"
									},
									{
										key: "tactical_action",
										label: "أكشن ومطاردات",
										icon: "🎯"
									},
									{
										key: "sci_fi_future",
										label: "خيال علمي ومستقبل",
										icon: "🚀"
									},
									{
										key: "sci_fantasy",
										label: "أكشن وخيال إبداعي",
										icon: "⚡"
									}
								].map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setGenre(g.key),
									className: `p-2.5 rounded-xl border text-center transition cursor-pointer flex items-center justify-center gap-1.5 font-bold ${genre === g.key ? "bg-amber-500/20 border-amber-400 text-amber-300 shadow-md" : "bg-black/30 border-white/10 text-gray-400 hover:text-white"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: g.icon }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: g.label })]
								}, g.key))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-gray-300 mb-1",
									children: "شخصية المحقق / الكاتب"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									value: authorPersonaAr,
									onChange: (e) => setAuthorPersonaAr(e.target.value),
									className: "w-full px-3 py-2 rounded-xl bg-black/40 border border-white/15 text-xs text-white focus:outline-none focus:border-amber-400"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-gray-300 mb-1",
									children: "صفة المحقق العلمية"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									value: authorTitleAr,
									onChange: (e) => setAuthorTitleAr(e.target.value),
									className: "w-full px-3 py-2 rounded-xl bg-black/40 border border-white/15 text-xs text-white focus:outline-none focus:border-amber-400"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-xs font-bold text-gray-300 mb-1",
								children: ["ملخص الرواية التشويقي (Synopsis) ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-rose-400",
									children: "*"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								required: true,
								rows: 3,
								value: synopsisAr,
								onChange: (e) => setSynopsisAr(e.target.value),
								placeholder: "اكتب ملخصاً مشوقاً يصف عقدة الجريمة، التحدي، ومسرح الأحداث الغامض...",
								className: "w-full px-3 py-2 rounded-xl bg-black/40 border border-white/15 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-amber-400 leading-relaxed"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-gray-300 mb-1",
									children: "المنهج الجنائي والأدلة"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									value: forensicThemeAr,
									onChange: (e) => setForensicThemeAr(e.target.value),
									placeholder: "مثال: البصمات، الفحص البيولوجي، السموم النادرة",
									className: "w-full px-3 py-2 rounded-xl bg-black/40 border border-white/15 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-amber-400"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-gray-300 mb-1",
									children: "التركيز السيكولوجي للجناة"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									value: psychologicalFocusAr,
									onChange: (e) => setPsychologicalFocusAr(e.target.value),
									placeholder: "مثال: تحليل نرجسية الجاني ومحاكاة الجريمة المثالية",
									className: "w-full px-3 py-2 rounded-xl bg-black/40 border border-white/15 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-amber-400"
								})] })]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4 p-4 rounded-2xl bg-white/5 border border-white/10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
									className: "text-xs font-extrabold text-rose-400 flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										"2. فصول الرواية (",
										chapters.length,
										" فصول)"
									] })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: handleAddNewChapter,
									className: "px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition flex items-center gap-1 cursor-pointer shadow-md",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "إضافة فصل جديد" })]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none",
								children: chapters.map((ch, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => handleSwitchChapter(idx),
										className: `px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1 shrink-0 ${selectedChapterIdx === idx ? "bg-rose-600 text-white shadow-md" : "bg-black/40 text-gray-400 hover:text-white border border-white/10"}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["الفصل ", idx + 1] })
									}), chapters.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => handleRemoveChapter(idx),
										className: "p-1 text-gray-500 hover:text-rose-400 transition cursor-pointer",
										title: "حذف هذا الفصل",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "w-3 h-3" })
									})]
								}, idx))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block text-xs font-bold text-gray-300 mb-1",
									children: ["عنوان الفصل ", selectedChapterIdx + 1]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									required: true,
									value: chapterTitle,
									onChange: (e) => setChapterTitle(e.target.value),
									placeholder: "مثال: البداية ومسرح الحادث الغامض",
									className: "w-full px-3 py-2 rounded-xl bg-black/40 border border-white/15 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-rose-400"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-gray-300 mb-1",
									children: "ملخص الفصل"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									value: chapterSynopsis,
									onChange: (e) => setChapterSynopsis(e.target.value),
									placeholder: "وصف مختصر لمجريات هذا الفصل",
									className: "w-full px-3 py-2 rounded-xl bg-black/40 border border-white/15 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-rose-400"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-xs font-bold text-gray-300",
									children: ["نص الفصل وسرد الأحداث ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-rose-400",
										children: "*"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[11px] text-gray-400 font-mono",
									children: [chapterContent.trim().split(/\s+/).filter(Boolean).length, " كلمة"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								required: true,
								rows: 9,
								value: chapterContent,
								onChange: (e) => setChapterContent(e.target.value),
								placeholder: "اكتب تفاصيل المشهد، حوارات التحقيق، استنتاجات المحقق، وصف مسرح الجريمة، والتوتر النفسي...",
								className: "w-full px-3 py-2.5 rounded-xl bg-black/50 border border-white/15 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-rose-400 leading-loose font-sans"
							})] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4 p-4 rounded-2xl bg-white/5 border border-white/10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
								className: "text-xs font-extrabold text-purple-400 flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"3. لوحة الأدلة الجنائية والمختبر (",
									clues.length,
									" أدلة)"
								] })]
							}),
							clues.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-2",
								children: clues.map((clue) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-start justify-between gap-3 text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "font-bold text-white flex items-center gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-purple-300",
												children: ["🔍 ", clue.titleAr]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] px-2 py-0.2 rounded-full bg-rose-500/20 text-rose-300",
												children: clue.significanceLevel
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-gray-300 text-[11px] mt-1",
											children: clue.descriptionAr
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-amber-400 text-[10px] font-mono mt-1",
											children: ["🔬 ", clue.forensicLabReportAr]
										})
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => handleRemoveClue(clue.id),
										className: "p-1.5 text-gray-400 hover:text-rose-400 transition cursor-pointer",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "w-4 h-4" })
									})]
								}, clue.id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3 rounded-xl bg-black/30 border border-white/5 space-y-2.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[11px] font-bold text-gray-300 block",
										children: "+ إضافة دليل جنائي جديد:"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											value: clueTitle,
											onChange: (e) => setClueTitle(e.target.value),
											placeholder: "اسم الدليل (مثال: ألياف كربونية دقيقة)",
											className: "px-3 py-1.5 rounded-lg bg-black/40 border border-white/10 text-xs text-white placeholder-gray-500"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											value: clueDesc,
											onChange: (e) => setClueDesc(e.target.value),
											placeholder: "وصف العثور عليه في مسرح الجريمة",
											className: "px-3 py-1.5 rounded-lg bg-black/40 border border-white/10 text-xs text-white placeholder-gray-500"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "text",
										value: clueLab,
										onChange: (e) => setClueLab(e.target.value),
										placeholder: "تقرير المختبر الجنائي (مثال: مطياف الكتلة يكشف مادة تيتانيوم مصهورة)",
										className: "w-full px-3 py-1.5 rounded-lg bg-black/40 border border-white/10 text-xs text-white placeholder-gray-500"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: handleAddClue,
										disabled: !clueTitle.trim() || !clueDesc.trim(),
										className: "px-3 py-1 rounded-lg bg-purple-600 hover:bg-purple-700 disabled:opacity-40 text-white text-xs font-bold transition cursor-pointer",
										children: "حفظ الدليل الجنائي"
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4 p-4 rounded-2xl bg-white/5 border border-white/10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
								className: "text-xs font-extrabold text-indigo-400 flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"4. الملف السيكولوجي للجناة والمشتبه بهم (",
									suspects.length,
									" أشخاص)"
								] })]
							}),
							suspects.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-2",
								children: suspects.map((s, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-start justify-between gap-3 text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "font-bold text-white flex items-center gap-1.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-indigo-300",
													children: ["👤 ", s.nameAr]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-[10px] text-gray-400",
													children: [
														"(",
														s.roleAr,
														")"
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-[10px] text-rose-300 px-2 py-0.2 rounded-full bg-rose-500/20",
													children: [
														"دافع ",
														s.motiveRating,
														"%"
													]
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-gray-300 text-[11px] mt-1",
											children: ["الغياب: ", s.alibiAr]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-rose-300 text-[11px] mt-0.5",
											children: ["الدافع: ", s.psychologicalMotiveAr]
										})
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => handleRemoveSuspect(idx),
										className: "p-1.5 text-gray-400 hover:text-rose-400 transition cursor-pointer",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "w-4 h-4" })
									})]
								}, idx))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3 rounded-xl bg-black/30 border border-white/5 space-y-2.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[11px] font-bold text-gray-300 block",
										children: "+ إضافة مشتبه به للملف السلوكي:"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											value: suspectName,
											onChange: (e) => setSuspectName(e.target.value),
											placeholder: "اسم المشتبه به",
											className: "px-3 py-1.5 rounded-lg bg-black/40 border border-white/10 text-xs text-white placeholder-gray-500"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											value: suspectRole,
											onChange: (e) => setSuspectRole(e.target.value),
											placeholder: "صفته أو عمله",
											className: "px-3 py-1.5 rounded-lg bg-black/40 border border-white/10 text-xs text-white placeholder-gray-500"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											value: suspectAlibi,
											onChange: (e) => setSuspectAlibi(e.target.value),
											placeholder: "حجة الغياب (Alibi)",
											className: "px-3 py-1.5 rounded-lg bg-black/40 border border-white/10 text-xs text-white placeholder-gray-500"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											value: suspectMotive,
											onChange: (e) => setSuspectMotive(e.target.value),
											placeholder: "الدافع السيكولوجي للجريمة",
											className: "px-3 py-1.5 rounded-lg bg-black/40 border border-white/10 text-xs text-white placeholder-gray-500"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "text-[11px] text-gray-300",
											children: [
												"مؤشر الدافع الجنائي (",
												suspectMotiveRating,
												"%):"
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "range",
											min: "20",
											max: "100",
											value: suspectMotiveRating,
											onChange: (e) => setSuspectMotiveRating(Number(e.target.value)),
											className: "flex-1 accent-rose-500 cursor-pointer"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: handleAddSuspect,
										disabled: !suspectName.trim() || !suspectRole.trim(),
										className: "px-3 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white text-xs font-bold transition cursor-pointer",
										children: "إضافة المشتبه به"
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pt-4 border-t border-white/10 flex items-center justify-between gap-3 shrink-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onClose,
							disabled: isSaving,
							className: "px-5 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white text-xs font-bold transition cursor-pointer",
							children: "إلغاء"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							disabled: isSaving,
							className: "px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-rose-600 to-purple-600 hover:opacity-95 text-white font-extrabold text-xs transition shadow-lg shadow-rose-600/25 flex items-center gap-2 cursor-pointer disabled:opacity-50",
							children: isSaving ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "جارٍ الحفظ والمزامنة..." })] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isEditMode ? "حفظ التعديلات والتحديث الفوري" : "نشر الرواية الآن في المكتبة" })] })
						})]
					})
				]
			})]
		})
	});
};
//#endregion
export { AddNovelModal as t };
