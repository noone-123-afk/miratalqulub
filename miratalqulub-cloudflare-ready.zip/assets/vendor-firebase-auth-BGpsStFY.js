import { o as openDB } from "./firebaseAuth-D6LKvzXg.js";
//#region node_modules/@firebase/util/dist/postinstall.mjs
/**
* @license
* Copyright 2025 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var getDefaultsFromPostinstall = () => void 0;
//#endregion
//#region node_modules/@firebase/util/dist/index.esm.js
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var stringToByteArray$1 = function(str) {
	const out = [];
	let p = 0;
	for (let i = 0; i < str.length; i++) {
		let c = str.charCodeAt(i);
		if (c < 128) out[p++] = c;
		else if (c < 2048) {
			out[p++] = c >> 6 | 192;
			out[p++] = c & 63 | 128;
		} else if ((c & 64512) === 55296 && i + 1 < str.length && (str.charCodeAt(i + 1) & 64512) === 56320) {
			c = 65536 + ((c & 1023) << 10) + (str.charCodeAt(++i) & 1023);
			out[p++] = c >> 18 | 240;
			out[p++] = c >> 12 & 63 | 128;
			out[p++] = c >> 6 & 63 | 128;
			out[p++] = c & 63 | 128;
		} else {
			out[p++] = c >> 12 | 224;
			out[p++] = c >> 6 & 63 | 128;
			out[p++] = c & 63 | 128;
		}
	}
	return out;
};
/**
* Turns an array of numbers into the string given by the concatenation of the
* characters to which the numbers correspond.
* @param bytes Array of numbers representing characters.
* @return Stringification of the array.
*/
var byteArrayToString = function(bytes) {
	const out = [];
	let pos = 0, c = 0;
	while (pos < bytes.length) {
		const c1 = bytes[pos++];
		if (c1 < 128) out[c++] = String.fromCharCode(c1);
		else if (c1 > 191 && c1 < 224) {
			const c2 = bytes[pos++];
			out[c++] = String.fromCharCode((c1 & 31) << 6 | c2 & 63);
		} else if (c1 > 239 && c1 < 365) {
			const c2 = bytes[pos++];
			const c3 = bytes[pos++];
			const c4 = bytes[pos++];
			const u = ((c1 & 7) << 18 | (c2 & 63) << 12 | (c3 & 63) << 6 | c4 & 63) - 65536;
			out[c++] = String.fromCharCode(55296 + (u >> 10));
			out[c++] = String.fromCharCode(56320 + (u & 1023));
		} else {
			const c2 = bytes[pos++];
			const c3 = bytes[pos++];
			out[c++] = String.fromCharCode((c1 & 15) << 12 | (c2 & 63) << 6 | c3 & 63);
		}
	}
	return out.join("");
};
var base64 = {
	/**
	* Maps bytes to characters.
	*/
	byteToCharMap_: null,
	/**
	* Maps characters to bytes.
	*/
	charToByteMap_: null,
	/**
	* Maps bytes to websafe characters.
	* @private
	*/
	byteToCharMapWebSafe_: null,
	/**
	* Maps websafe characters to bytes.
	* @private
	*/
	charToByteMapWebSafe_: null,
	/**
	* Our default alphabet, shared between
	* ENCODED_VALS and ENCODED_VALS_WEBSAFE
	*/
	ENCODED_VALS_BASE: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
	/**
	* Our default alphabet. Value 64 (=) is special; it means "nothing."
	*/
	get ENCODED_VALS() {
		return this.ENCODED_VALS_BASE + "+/=";
	},
	/**
	* Our websafe alphabet.
	*/
	get ENCODED_VALS_WEBSAFE() {
		return this.ENCODED_VALS_BASE + "-_.";
	},
	/**
	* Whether this browser supports the atob and btoa functions. This extension
	* started at Mozilla but is now implemented by many browsers. We use the
	* ASSUME_* variables to avoid pulling in the full useragent detection library
	* but still allowing the standard per-browser compilations.
	*
	*/
	HAS_NATIVE_SUPPORT: typeof atob === "function",
	/**
	* Base64-encode an array of bytes.
	*
	* @param input An array of bytes (numbers with
	*     value in [0, 255]) to encode.
	* @param webSafe Boolean indicating we should use the
	*     alternative alphabet.
	* @return The base64 encoded string.
	*/
	encodeByteArray(input, webSafe) {
		if (!Array.isArray(input)) throw Error("encodeByteArray takes an array as a parameter");
		this.init_();
		const byteToCharMap = webSafe ? this.byteToCharMapWebSafe_ : this.byteToCharMap_;
		const output = [];
		for (let i = 0; i < input.length; i += 3) {
			const byte1 = input[i];
			const haveByte2 = i + 1 < input.length;
			const byte2 = haveByte2 ? input[i + 1] : 0;
			const haveByte3 = i + 2 < input.length;
			const byte3 = haveByte3 ? input[i + 2] : 0;
			const outByte1 = byte1 >> 2;
			const outByte2 = (byte1 & 3) << 4 | byte2 >> 4;
			let outByte3 = (byte2 & 15) << 2 | byte3 >> 6;
			let outByte4 = byte3 & 63;
			if (!haveByte3) {
				outByte4 = 64;
				if (!haveByte2) outByte3 = 64;
			}
			output.push(byteToCharMap[outByte1], byteToCharMap[outByte2], byteToCharMap[outByte3], byteToCharMap[outByte4]);
		}
		return output.join("");
	},
	/**
	* Base64-encode a string.
	*
	* @param input A string to encode.
	* @param webSafe If true, we should use the
	*     alternative alphabet.
	* @return The base64 encoded string.
	*/
	encodeString(input, webSafe) {
		if (this.HAS_NATIVE_SUPPORT && !webSafe) return btoa(input);
		return this.encodeByteArray(stringToByteArray$1(input), webSafe);
	},
	/**
	* Base64-decode a string.
	*
	* @param input to decode.
	* @param webSafe True if we should use the
	*     alternative alphabet.
	* @return string representing the decoded value.
	*/
	decodeString(input, webSafe) {
		if (this.HAS_NATIVE_SUPPORT && !webSafe) return atob(input);
		return byteArrayToString(this.decodeStringToByteArray(input, webSafe));
	},
	/**
	* Base64-decode a string.
	*
	* In base-64 decoding, groups of four characters are converted into three
	* bytes.  If the encoder did not apply padding, the input length may not
	* be a multiple of 4.
	*
	* In this case, the last group will have fewer than 4 characters, and
	* padding will be inferred.  If the group has one or two characters, it decodes
	* to one byte.  If the group has three characters, it decodes to two bytes.
	*
	* @param input Input to decode.
	* @param webSafe True if we should use the web-safe alphabet.
	* @return bytes representing the decoded value.
	*/
	decodeStringToByteArray(input, webSafe) {
		this.init_();
		const charToByteMap = webSafe ? this.charToByteMapWebSafe_ : this.charToByteMap_;
		const output = [];
		for (let i = 0; i < input.length;) {
			const byte1 = charToByteMap[input.charAt(i++)];
			const byte2 = i < input.length ? charToByteMap[input.charAt(i)] : 0;
			++i;
			const byte3 = i < input.length ? charToByteMap[input.charAt(i)] : 64;
			++i;
			const byte4 = i < input.length ? charToByteMap[input.charAt(i)] : 64;
			++i;
			if (byte1 == null || byte2 == null || byte3 == null || byte4 == null) throw new DecodeBase64StringError();
			const outByte1 = byte1 << 2 | byte2 >> 4;
			output.push(outByte1);
			if (byte3 !== 64) {
				const outByte2 = byte2 << 4 & 240 | byte3 >> 2;
				output.push(outByte2);
				if (byte4 !== 64) {
					const outByte3 = byte3 << 6 & 192 | byte4;
					output.push(outByte3);
				}
			}
		}
		return output;
	},
	/**
	* Lazy static initialization function. Called before
	* accessing any of the static map variables.
	* @private
	*/
	init_() {
		if (!this.byteToCharMap_) {
			this.byteToCharMap_ = {};
			this.charToByteMap_ = {};
			this.byteToCharMapWebSafe_ = {};
			this.charToByteMapWebSafe_ = {};
			for (let i = 0; i < this.ENCODED_VALS.length; i++) {
				this.byteToCharMap_[i] = this.ENCODED_VALS.charAt(i);
				this.charToByteMap_[this.byteToCharMap_[i]] = i;
				this.byteToCharMapWebSafe_[i] = this.ENCODED_VALS_WEBSAFE.charAt(i);
				this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[i]] = i;
				if (i >= this.ENCODED_VALS_BASE.length) {
					this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(i)] = i;
					this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(i)] = i;
				}
			}
		}
	}
};
/**
* An error encountered while decoding base64 string.
*/
var DecodeBase64StringError = class extends Error {
	constructor() {
		super(...arguments);
		this.name = "DecodeBase64StringError";
	}
};
/**
* URL-safe base64 encoding
*/
var base64Encode = function(str) {
	const utf8Bytes = stringToByteArray$1(str);
	return base64.encodeByteArray(utf8Bytes, true);
};
/**
* URL-safe base64 encoding (without "." padding in the end).
* e.g. Used in JSON Web Token (JWT) parts.
*/
var base64urlEncodeWithoutPadding = function(str) {
	return base64Encode(str).replace(/\./g, "");
};
/**
* URL-safe base64 decoding
*
* NOTE: DO NOT use the global atob() function - it does NOT support the
* base64Url variant encoding.
*
* @param str To be decoded
* @return Decoded result, if possible
*/
var base64Decode = function(str) {
	try {
		return base64.decodeString(str, true);
	} catch (e) {
		console.error("base64Decode failed: ", e);
	}
	return null;
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Polyfill for `globalThis` object.
* @returns the `globalThis` object for the given environment.
* @public
*/
function getGlobal() {
	if (typeof self !== "undefined") return self;
	if (typeof window !== "undefined") return window;
	if (typeof global !== "undefined") return global;
	throw new Error("Unable to locate global object.");
}
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var getDefaultsFromGlobal = () => getGlobal().__FIREBASE_DEFAULTS__;
/**
* Attempt to read defaults from a JSON string provided to
* process(.)env(.)__FIREBASE_DEFAULTS__ or a JSON file whose path is in
* process(.)env(.)__FIREBASE_DEFAULTS_PATH__
* The dots are in parens because certain compilers (Vite?) cannot
* handle seeing that variable in comments.
* See https://github.com/firebase/firebase-js-sdk/issues/6838
*/
var getDefaultsFromEnvVariable = () => {
	if (typeof process === "undefined" || false) return;
	const defaultsJsonString = {}.__FIREBASE_DEFAULTS__;
	if (defaultsJsonString) return JSON.parse(defaultsJsonString);
};
var getDefaultsFromCookie = () => {
	if (typeof document === "undefined") return;
	let match;
	try {
		match = document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/);
	} catch (e) {
		return;
	}
	const decoded = match && base64Decode(match[1]);
	return decoded && JSON.parse(decoded);
};
/**
* Get the __FIREBASE_DEFAULTS__ object. It checks in order:
* (1) if such an object exists as a property of `globalThis`
* (2) if such an object was provided on a shell environment variable
* (3) if such an object exists in a cookie
* @public
*/
var getDefaults = () => {
	try {
		return getDefaultsFromPostinstall() || getDefaultsFromGlobal() || getDefaultsFromEnvVariable() || getDefaultsFromCookie();
	} catch (e) {
		/**
		* Catch-all for being unable to get __FIREBASE_DEFAULTS__ due
		* to any environment case we have not accounted for. Log to
		* info instead of swallowing so we can find these unknown cases
		* and add paths for them if needed.
		*/
		console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${e}`);
		return;
	}
};
/**
* Returns emulator host stored in the __FIREBASE_DEFAULTS__ object
* for the given product.
* @returns a URL host formatted like `127.0.0.1:9999` or `[::1]:4000` if available
* @public
*/
var getDefaultEmulatorHost = (productName) => getDefaults()?.emulatorHosts?.[productName];
/**
* Returns emulator hostname and port stored in the __FIREBASE_DEFAULTS__ object
* for the given product.
* @returns a pair of hostname and port like `["::1", 4000]` if available
* @public
*/
var getDefaultEmulatorHostnameAndPort = (productName) => {
	const host = getDefaultEmulatorHost(productName);
	if (!host) return;
	const separatorIndex = host.lastIndexOf(":");
	if (separatorIndex <= 0 || separatorIndex + 1 === host.length) throw new Error(`Invalid host ${host} with no separate hostname and port!`);
	const port = parseInt(host.substring(separatorIndex + 1), 10);
	if (host[0] === "[") return [host.substring(1, separatorIndex - 1), port];
	else return [host.substring(0, separatorIndex), port];
};
/**
* Returns Firebase app config stored in the __FIREBASE_DEFAULTS__ object.
* @public
*/
var getDefaultAppConfig = () => getDefaults()?.config;
/**
* Returns an experimental setting on the __FIREBASE_DEFAULTS__ object (properties
* prefixed by "_")
* @public
*/
var getExperimentalSetting = (name) => getDefaults()?.[`_${name}`];
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var Deferred = class {
	constructor() {
		this.reject = () => {};
		this.resolve = () => {};
		this.promise = new Promise((resolve, reject) => {
			this.resolve = resolve;
			this.reject = reject;
		});
	}
	/**
	* Our API internals are not promisified and cannot because our callback APIs have subtle expectations around
	* invoking promises inline, which Promises are forbidden to do. This method accepts an optional node-style callback
	* and returns a node-style callback which will resolve or reject the Deferred's promise.
	*/
	wrapCallback(callback) {
		return (error, value) => {
			if (error) this.reject(error);
			else this.resolve(value);
			if (typeof callback === "function") {
				this.promise.catch(() => {});
				if (callback.length === 1) callback(error);
				else callback(error, value);
			}
		};
	}
};
/**
* @license
* Copyright 2021 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function createMockUserToken(token, projectId) {
	if (token.uid) throw new Error("The \"uid\" field is no longer supported by mockUserToken. Please use \"sub\" instead for Firebase Auth User ID.");
	const header = {
		alg: "none",
		type: "JWT"
	};
	const project = projectId || "demo-project";
	const iat = token.iat || 0;
	const sub = token.sub || token.user_id;
	if (!sub) throw new Error("mockUserToken must contain 'sub' or 'user_id' field!");
	const payload = {
		iss: `https://securetoken.google.com/${project}`,
		aud: project,
		iat,
		exp: iat + 3600,
		auth_time: iat,
		sub,
		user_id: sub,
		firebase: {
			sign_in_provider: "custom",
			identities: {}
		},
		...token
	};
	return [
		base64urlEncodeWithoutPadding(JSON.stringify(header)),
		base64urlEncodeWithoutPadding(JSON.stringify(payload)),
		""
	].join(".");
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Returns navigator.userAgent string or '' if it's not defined.
* @return user agent string
*/
function getUA() {
	if (typeof navigator !== "undefined" && typeof navigator["userAgent"] === "string") return navigator["userAgent"];
	else return "";
}
/**
* Detect Cordova / PhoneGap / Ionic frameworks on a mobile device.
*
* Deliberately does not rely on checking `file://` URLs (as this fails PhoneGap
* in the Ripple emulator) nor Cordova `onDeviceReady`, which would normally
* wait for a callback.
*/
function isMobileCordova() {
	return typeof window !== "undefined" && !!(window["cordova"] || window["phonegap"] || window["PhoneGap"]) && /ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(getUA());
}
/**
* Detect Node.js.
*
* @return true if Node.js environment is detected or specified.
*/
function isNode() {
	const forceEnvironment = getDefaults()?.forceEnvironment;
	if (forceEnvironment === "node") return true;
	else if (forceEnvironment === "browser") return false;
	try {
		return Object.prototype.toString.call(global.process) === "[object process]";
	} catch (e) {
		return false;
	}
}
/**
* Detect Cloudflare Worker context.
*/
function isCloudflareWorker() {
	return typeof navigator !== "undefined" && navigator.userAgent === "Cloudflare-Workers";
}
function isBrowserExtension() {
	const runtime = typeof chrome === "object" ? chrome.runtime : typeof browser === "object" ? browser.runtime : void 0;
	return typeof runtime === "object" && runtime.id !== void 0;
}
/**
* Detect React Native.
*
* @return true if ReactNative environment is detected.
*/
function isReactNative() {
	return typeof navigator === "object" && navigator["product"] === "ReactNative";
}
/** Detects Internet Explorer. */
function isIE() {
	const ua = getUA();
	return ua.indexOf("MSIE ") >= 0 || ua.indexOf("Trident/") >= 0;
}
/** Returns true if we are running in Safari. */
function isSafari() {
	return !isNode() && !!navigator.userAgent && navigator.userAgent.includes("Safari") && !navigator.userAgent.includes("Chrome");
}
/**
* This method checks if indexedDB is supported by current browser/service worker context
* @return true if indexedDB is supported by current browser/service worker context
*/
function isIndexedDBAvailable() {
	try {
		return typeof indexedDB === "object";
	} catch (e) {
		return false;
	}
}
/**
* This method validates browser/sw context for indexedDB by opening a dummy indexedDB database and reject
* if errors occur during the database open operation.
*
* @throws exception if current browser/sw context can't run idb.open (ex: Safari iframe, Firefox
* private browsing)
*/
function validateIndexedDBOpenable() {
	return new Promise((resolve, reject) => {
		try {
			let preExist = true;
			const DB_CHECK_NAME = "validate-browser-context-for-indexeddb-analytics-module";
			const request = self.indexedDB.open(DB_CHECK_NAME);
			request.onsuccess = () => {
				request.result.close();
				if (!preExist) self.indexedDB.deleteDatabase(DB_CHECK_NAME);
				resolve(true);
			};
			request.onupgradeneeded = () => {
				preExist = false;
			};
			request.onerror = () => {
				reject(request.error?.message || "");
			};
		} catch (error) {
			reject(error);
		}
	});
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @fileoverview Standardized Firebase Error.
*
* Usage:
*
*   // TypeScript string literals for type-safe codes
*   type Err =
*     'unknown' |
*     'object-not-found'
*     ;
*
*   // Closure enum for type-safe error codes
*   // at-enum {string}
*   var Err = {
*     UNKNOWN: 'unknown',
*     OBJECT_NOT_FOUND: 'object-not-found',
*   }
*
*   let errors: Map<Err, string> = {
*     'generic-error': "Unknown error",
*     'file-not-found': "Could not find file: {$file}",
*   };
*
*   // Type-safe function - must pass a valid error code as param.
*   let error = new ErrorFactory<Err>('service', 'Service', errors);
*
*   ...
*   throw error.create(Err.GENERIC);
*   ...
*   throw error.create(Err.FILE_NOT_FOUND, {'file': fileName});
*   ...
*   // Service: Could not file file: foo.txt (service/file-not-found).
*
*   catch (e) {
*     assert(e.message === "Could not find file: foo.txt.");
*     if ((e as FirebaseError)?.code === 'service/file-not-found') {
*       console.log("Could not read file: " + e['file']);
*     }
*   }
*/
var ERROR_NAME = "FirebaseError";
var FirebaseError = class FirebaseError extends Error {
	constructor(code, message, customData) {
		super(message);
		this.code = code;
		this.customData = customData;
		/** The custom name for all FirebaseErrors. */
		this.name = ERROR_NAME;
		Object.setPrototypeOf(this, FirebaseError.prototype);
		if (Error.captureStackTrace) Error.captureStackTrace(this, ErrorFactory.prototype.create);
	}
};
var ErrorFactory = class {
	constructor(service, serviceName, errors) {
		this.service = service;
		this.serviceName = serviceName;
		this.errors = errors;
	}
	create(code, ...data) {
		const customData = data[0] || {};
		const fullCode = `${this.service}/${code}`;
		const template = this.errors[code];
		const message = template ? replaceTemplate(template, customData) : "Error";
		return new FirebaseError(fullCode, `${this.serviceName}: ${message} (${fullCode}).`, customData);
	}
};
function replaceTemplate(template, data) {
	try {
		let ptr = 0;
		let result = "";
		while (ptr < template.length) {
			const start = template.indexOf("{$", ptr);
			if (start === -1) {
				result += template.substring(ptr);
				break;
			}
			const end = template.indexOf("}", start + 2);
			if (end === -1) {
				result += template.substring(ptr);
				break;
			}
			const key = template.substring(start + 2, end);
			const value = data[key];
			result += template.substring(ptr, start) + (value != null ? String(value) : `<${key}?>`);
			ptr = end + 1;
		}
		return result;
	} catch (e) {
		return template;
	}
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function isEmpty(obj) {
	for (const key in obj) if (Object.prototype.hasOwnProperty.call(obj, key)) return false;
	return true;
}
/**
* Deep equal two objects. Support Arrays and Objects.
*/
function deepEqual(a, b) {
	if (a === b) return true;
	const aKeys = Object.keys(a);
	const bKeys = Object.keys(b);
	for (const k of aKeys) {
		if (!bKeys.includes(k)) return false;
		const aProp = a[k];
		const bProp = b[k];
		if (isObject(aProp) && isObject(bProp)) {
			if (!deepEqual(aProp, bProp)) return false;
		} else if (aProp !== bProp) return false;
	}
	for (const k of bKeys) if (!aKeys.includes(k)) return false;
	return true;
}
function isObject(thing) {
	return thing !== null && typeof thing === "object";
}
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Returns a querystring-formatted string (e.g. &arg=val&arg2=val2) from a
* params object (e.g. {arg: 'val', arg2: 'val2'})
* Note: You must prepend it with ? when adding it to a URL.
*/
function querystring(querystringParams) {
	const params = [];
	for (const [key, value] of Object.entries(querystringParams)) if (Array.isArray(value)) value.forEach((arrayVal) => {
		params.push(encodeURIComponent(key) + "=" + encodeURIComponent(arrayVal));
	});
	else params.push(encodeURIComponent(key) + "=" + encodeURIComponent(value));
	return params.length ? "&" + params.join("&") : "";
}
/**
* Decodes a querystring (e.g. ?arg=val&arg2=val2) into a params object
* (e.g. {arg: 'val', arg2: 'val2'})
*/
function querystringDecode(querystring) {
	const obj = {};
	querystring.replace(/^\?/, "").split("&").forEach((token) => {
		if (token) {
			const [key, value] = token.split("=");
			obj[decodeURIComponent(key)] = decodeURIComponent(value);
		}
	});
	return obj;
}
/**
* Extract the query string part of a URL, including the leading question mark (if present).
*/
function extractQuerystring(url) {
	const queryStart = url.indexOf("?");
	if (!queryStart) return "";
	const fragmentStart = url.indexOf("#", queryStart);
	return url.substring(queryStart, fragmentStart > 0 ? fragmentStart : void 0);
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Helper to make a Subscribe function (just like Promise helps make a
* Thenable).
*
* @param executor Function which can make calls to a single Observer
*     as a proxy.
* @param onNoObservers Callback when count of Observers goes to zero.
*/
function createSubscribe(executor, onNoObservers) {
	const proxy = new ObserverProxy(executor, onNoObservers);
	return proxy.subscribe.bind(proxy);
}
/**
* Implement fan-out for any number of Observers attached via a subscribe
* function.
*/
var ObserverProxy = class {
	/**
	* @param executor Function which can make calls to a single Observer
	*     as a proxy.
	* @param onNoObservers Callback when count of Observers goes to zero.
	*/
	constructor(executor, onNoObservers) {
		this.observers = [];
		this.unsubscribes = [];
		this.observerCount = 0;
		this.task = Promise.resolve();
		this.finalized = false;
		this.onNoObservers = onNoObservers;
		this.task.then(() => {
			executor(this);
		}).catch((e) => {
			this.error(e);
		});
	}
	next(value) {
		this.forEachObserver((observer) => {
			observer.next(value);
		});
	}
	error(error) {
		this.forEachObserver((observer) => {
			observer.error(error);
		});
		this.close(error);
	}
	complete() {
		this.forEachObserver((observer) => {
			observer.complete();
		});
		this.close();
	}
	/**
	* Subscribe function that can be used to add an Observer to the fan-out list.
	*
	* - We require that no event is sent to a subscriber synchronously to their
	*   call to subscribe().
	*/
	subscribe(nextOrObserver, error, complete) {
		let observer;
		if (nextOrObserver === void 0 && error === void 0 && complete === void 0) throw new Error("Missing Observer.");
		if (implementsAnyMethods(nextOrObserver, [
			"next",
			"error",
			"complete"
		])) observer = nextOrObserver;
		else observer = {
			next: nextOrObserver,
			error,
			complete
		};
		if (observer.next === void 0) observer.next = noop;
		if (observer.error === void 0) observer.error = noop;
		if (observer.complete === void 0) observer.complete = noop;
		const unsub = this.unsubscribeOne.bind(this, this.observers.length);
		if (this.finalized) this.task.then(() => {
			try {
				if (this.finalError) observer.error(this.finalError);
				else observer.complete();
			} catch (e) {}
		});
		this.observers.push(observer);
		return unsub;
	}
	unsubscribeOne(i) {
		if (this.observers === void 0 || this.observers[i] === void 0) return;
		delete this.observers[i];
		this.observerCount -= 1;
		if (this.observerCount === 0 && this.onNoObservers !== void 0) this.onNoObservers(this);
	}
	forEachObserver(fn) {
		if (this.finalized) return;
		for (let i = 0; i < this.observers.length; i++) this.sendOne(i, fn);
	}
	sendOne(i, fn) {
		this.task.then(() => {
			if (this.observers !== void 0 && this.observers[i] !== void 0) try {
				fn(this.observers[i]);
			} catch (e) {
				if (typeof console !== "undefined" && console.error) console.error(e);
			}
		});
	}
	close(err) {
		if (this.finalized) return;
		this.finalized = true;
		if (err !== void 0) this.finalError = err;
		this.task.then(() => {
			this.observers = void 0;
			this.onNoObservers = void 0;
		});
	}
};
/**
* Return true if the object passed in implements any of the named methods.
*/
function implementsAnyMethods(obj, methods) {
	if (typeof obj !== "object" || obj === null) return false;
	for (const method of methods) if (method in obj && typeof obj[method] === "function") return true;
	return false;
}
function noop() {}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2021 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function getModularInstance(service) {
	if (service && service._delegate) return service._delegate;
	else return service;
}
/**
* @license
* Copyright 2025 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Checks whether host is a cloud workstation or not.
* @public
*/
function isCloudWorkstation(url) {
	try {
		return (url.startsWith("http://") || url.startsWith("https://") ? new URL(url).hostname : url).endsWith(".cloudworkstations.dev");
	} catch {
		return false;
	}
}
/**
* Makes a fetch request to the given server.
* Mostly used for forwarding cookies in Firebase Studio.
* @public
*/
async function pingServer(endpoint) {
	return (await fetch(endpoint, { credentials: "include" })).ok;
}
/**
* @license
* Copyright 2025 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
//#endregion
//#region node_modules/@firebase/component/dist/esm/index.esm.js
/**
* Component for service name T, e.g. `auth`, `auth-internal`
*/
var Component = class {
	/**
	*
	* @param name The public service name, e.g. app, auth, firestore, database
	* @param instanceFactory Service factory responsible for creating the public interface
	* @param type whether the service provided by the component is public or private
	*/
	constructor(name, instanceFactory, type) {
		this.name = name;
		this.instanceFactory = instanceFactory;
		this.type = type;
		this.multipleInstances = false;
		/**
		* Properties to be added to the service namespace
		*/
		this.serviceProps = {};
		this.instantiationMode = "LAZY";
		this.onInstanceCreated = null;
	}
	setInstantiationMode(mode) {
		this.instantiationMode = mode;
		return this;
	}
	setMultipleInstances(multipleInstances) {
		this.multipleInstances = multipleInstances;
		return this;
	}
	setServiceProps(props) {
		this.serviceProps = props;
		return this;
	}
	setInstanceCreatedCallback(callback) {
		this.onInstanceCreated = callback;
		return this;
	}
};
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var DEFAULT_ENTRY_NAME$1 = "[DEFAULT]";
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Provider for instance for service name T, e.g. 'auth', 'auth-internal'
* NameServiceMapping[T] is an alias for the type of the instance
*/
var Provider = class {
	constructor(name, container) {
		this.name = name;
		this.container = container;
		this.component = null;
		this.instances = /* @__PURE__ */ new Map();
		this.instancesDeferred = /* @__PURE__ */ new Map();
		this.instancesOptions = /* @__PURE__ */ new Map();
		this.onInitCallbacks = /* @__PURE__ */ new Map();
	}
	/**
	* @param identifier A provider can provide multiple instances of a service
	* if this.component.multipleInstances is true.
	*/
	get(identifier) {
		const normalizedIdentifier = this.normalizeInstanceIdentifier(identifier);
		if (!this.instancesDeferred.has(normalizedIdentifier)) {
			const deferred = new Deferred();
			this.instancesDeferred.set(normalizedIdentifier, deferred);
			if (this.isInitialized(normalizedIdentifier) || this.shouldAutoInitialize()) try {
				const instance = this.getOrInitializeService({ instanceIdentifier: normalizedIdentifier });
				if (instance) deferred.resolve(instance);
			} catch (e) {}
		}
		return this.instancesDeferred.get(normalizedIdentifier).promise;
	}
	getImmediate(options) {
		const normalizedIdentifier = this.normalizeInstanceIdentifier(options?.identifier);
		const optional = options?.optional ?? false;
		if (this.isInitialized(normalizedIdentifier) || this.shouldAutoInitialize()) try {
			return this.getOrInitializeService({ instanceIdentifier: normalizedIdentifier });
		} catch (e) {
			if (optional) return null;
			else throw e;
		}
		else if (optional) return null;
		else throw Error(`Service ${this.name} is not available`);
	}
	getComponent() {
		return this.component;
	}
	setComponent(component) {
		if (component.name !== this.name) throw Error(`Mismatching Component ${component.name} for Provider ${this.name}.`);
		if (this.component) throw Error(`Component for ${this.name} has already been provided`);
		this.component = component;
		if (!this.shouldAutoInitialize()) return;
		if (isComponentEager(component)) try {
			this.getOrInitializeService({ instanceIdentifier: DEFAULT_ENTRY_NAME$1 });
		} catch (e) {}
		for (const [instanceIdentifier, instanceDeferred] of this.instancesDeferred.entries()) {
			const normalizedIdentifier = this.normalizeInstanceIdentifier(instanceIdentifier);
			try {
				const instance = this.getOrInitializeService({ instanceIdentifier: normalizedIdentifier });
				instanceDeferred.resolve(instance);
			} catch (e) {}
		}
	}
	clearInstance(identifier = DEFAULT_ENTRY_NAME$1) {
		this.instancesDeferred.delete(identifier);
		this.instancesOptions.delete(identifier);
		this.instances.delete(identifier);
	}
	async delete() {
		const services = Array.from(this.instances.values());
		await Promise.all([...services.filter((service) => "INTERNAL" in service).map((service) => service.INTERNAL.delete()), ...services.filter((service) => "_delete" in service).map((service) => service._delete())]);
	}
	isComponentSet() {
		return this.component != null;
	}
	isInitialized(identifier = DEFAULT_ENTRY_NAME$1) {
		return this.instances.has(identifier);
	}
	getOptions(identifier = DEFAULT_ENTRY_NAME$1) {
		return this.instancesOptions.get(identifier) || {};
	}
	initialize(opts = {}) {
		const { options = {} } = opts;
		const normalizedIdentifier = this.normalizeInstanceIdentifier(opts.instanceIdentifier);
		if (this.isInitialized(normalizedIdentifier)) throw Error(`${this.name}(${normalizedIdentifier}) has already been initialized`);
		if (!this.isComponentSet()) throw Error(`Component ${this.name} has not been registered yet`);
		const instance = this.getOrInitializeService({
			instanceIdentifier: normalizedIdentifier,
			options
		});
		for (const [instanceIdentifier, instanceDeferred] of this.instancesDeferred.entries()) if (normalizedIdentifier === this.normalizeInstanceIdentifier(instanceIdentifier)) instanceDeferred.resolve(instance);
		return instance;
	}
	/**
	*
	* @param callback - a function that will be invoked  after the provider has been initialized by calling provider.initialize().
	* The function is invoked SYNCHRONOUSLY, so it should not execute any longrunning tasks in order to not block the program.
	*
	* @param identifier An optional instance identifier
	* @returns a function to unregister the callback
	*/
	onInit(callback, identifier) {
		const normalizedIdentifier = this.normalizeInstanceIdentifier(identifier);
		const existingCallbacks = this.onInitCallbacks.get(normalizedIdentifier) ?? /* @__PURE__ */ new Set();
		existingCallbacks.add(callback);
		this.onInitCallbacks.set(normalizedIdentifier, existingCallbacks);
		const existingInstance = this.instances.get(normalizedIdentifier);
		if (existingInstance) callback(existingInstance, normalizedIdentifier);
		return () => {
			existingCallbacks.delete(callback);
		};
	}
	/**
	* Invoke onInit callbacks synchronously
	* @param instance the service instance`
	*/
	invokeOnInitCallbacks(instance, identifier) {
		const callbacks = this.onInitCallbacks.get(identifier);
		if (!callbacks) return;
		for (const callback of callbacks) try {
			callback(instance, identifier);
		} catch {}
	}
	getOrInitializeService({ instanceIdentifier, options = {} }) {
		let instance = this.instances.get(instanceIdentifier);
		if (!instance && this.component) {
			instance = this.component.instanceFactory(this.container, {
				instanceIdentifier: normalizeIdentifierForFactory(instanceIdentifier),
				options
			});
			this.instances.set(instanceIdentifier, instance);
			this.instancesOptions.set(instanceIdentifier, options);
			/**
			* Invoke onInit listeners.
			* Note this.component.onInstanceCreated is different, which is used by the component creator,
			* while onInit listeners are registered by consumers of the provider.
			*/
			this.invokeOnInitCallbacks(instance, instanceIdentifier);
			/**
			* Order is important
			* onInstanceCreated() should be called after this.instances.set(instanceIdentifier, instance); which
			* makes `isInitialized()` return true.
			*/
			if (this.component.onInstanceCreated) try {
				this.component.onInstanceCreated(this.container, instanceIdentifier, instance);
			} catch {}
		}
		return instance || null;
	}
	normalizeInstanceIdentifier(identifier = DEFAULT_ENTRY_NAME$1) {
		if (this.component) return this.component.multipleInstances ? identifier : DEFAULT_ENTRY_NAME$1;
		else return identifier;
	}
	shouldAutoInitialize() {
		return !!this.component && this.component.instantiationMode !== "EXPLICIT";
	}
};
function normalizeIdentifierForFactory(identifier) {
	return identifier === DEFAULT_ENTRY_NAME$1 ? void 0 : identifier;
}
function isComponentEager(component) {
	return component.instantiationMode === "EAGER";
}
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* ComponentContainer that provides Providers for service name T, e.g. `auth`, `auth-internal`
*/
var ComponentContainer = class {
	constructor(name) {
		this.name = name;
		this.providers = /* @__PURE__ */ new Map();
	}
	/**
	*
	* @param component Component being added
	* @param overwrite When a component with the same name has already been registered,
	* if overwrite is true: overwrite the existing component with the new component and create a new
	* provider with the new component. It can be useful in tests where you want to use different mocks
	* for different tests.
	* if overwrite is false: throw an exception
	*/
	addComponent(component) {
		const provider = this.getProvider(component.name);
		if (provider.isComponentSet()) throw new Error(`Component ${component.name} has already been registered with ${this.name}`);
		provider.setComponent(component);
	}
	addOrOverwriteComponent(component) {
		if (this.getProvider(component.name).isComponentSet()) this.providers.delete(component.name);
		this.addComponent(component);
	}
	/**
	* getProvider provides a type safe interface where it can only be called with a field name
	* present in NameServiceMapping interface.
	*
	* Firebase SDKs providing services should extend NameServiceMapping interface to register
	* themselves.
	*/
	getProvider(name) {
		if (this.providers.has(name)) return this.providers.get(name);
		const provider = new Provider(name, this);
		this.providers.set(name, provider);
		return provider;
	}
	getProviders() {
		return Array.from(this.providers.values());
	}
};
//#endregion
//#region node_modules/@firebase/logger/dist/esm/index.esm.js
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* A container for all of the Logger instances
*/
var instances = [];
/**
* The JS SDK supports 5 log levels and also allows a user the ability to
* silence the logs altogether.
*
* The order is a follows:
* DEBUG < VERBOSE < INFO < WARN < ERROR
*
* All of the log types above the current log level will be captured (i.e. if
* you set the log level to `INFO`, errors will still be logged, but `DEBUG` and
* `VERBOSE` logs will not)
*/
var LogLevel;
(function(LogLevel) {
	LogLevel[LogLevel["DEBUG"] = 0] = "DEBUG";
	LogLevel[LogLevel["VERBOSE"] = 1] = "VERBOSE";
	LogLevel[LogLevel["INFO"] = 2] = "INFO";
	LogLevel[LogLevel["WARN"] = 3] = "WARN";
	LogLevel[LogLevel["ERROR"] = 4] = "ERROR";
	LogLevel[LogLevel["SILENT"] = 5] = "SILENT";
})(LogLevel || (LogLevel = {}));
var levelStringToEnum = {
	"debug": LogLevel.DEBUG,
	"verbose": LogLevel.VERBOSE,
	"info": LogLevel.INFO,
	"warn": LogLevel.WARN,
	"error": LogLevel.ERROR,
	"silent": LogLevel.SILENT
};
/**
* The default log level
*/
var defaultLogLevel = LogLevel.INFO;
/**
* By default, `console.debug` is not displayed in the developer console (in
* chrome). To avoid forcing users to have to opt-in to these logs twice
* (i.e. once for firebase, and once in the console), we are sending `DEBUG`
* logs to the `console.log` function.
*/
var ConsoleMethod = {
	[LogLevel.DEBUG]: "log",
	[LogLevel.VERBOSE]: "log",
	[LogLevel.INFO]: "info",
	[LogLevel.WARN]: "warn",
	[LogLevel.ERROR]: "error"
};
/**
* The default log handler will forward DEBUG, VERBOSE, INFO, WARN, and ERROR
* messages on to their corresponding console counterparts (if the log method
* is supported by the current log level)
*/
var defaultLogHandler = (instance, logType, ...args) => {
	if (logType < instance.logLevel) return;
	const now = (/* @__PURE__ */ new Date()).toISOString();
	const method = ConsoleMethod[logType];
	if (method) console[method](`[${now}]  ${instance.name}:`, ...args);
	else throw new Error(`Attempted to log a message with an invalid logType (value: ${logType})`);
};
var Logger = class {
	/**
	* Gives you an instance of a Logger to capture messages according to
	* Firebase's logging scheme.
	*
	* @param name The name that the logs will be associated with
	*/
	constructor(name) {
		this.name = name;
		/**
		* The log level of the given Logger instance.
		*/
		this._logLevel = defaultLogLevel;
		/**
		* The main (internal) log handler for the Logger instance.
		* Can be set to a new function in internal package code but not by user.
		*/
		this._logHandler = defaultLogHandler;
		/**
		* The optional, additional, user-defined log handler for the Logger instance.
		*/
		this._userLogHandler = null;
		/**
		* Capture the current instance for later use
		*/
		instances.push(this);
	}
	get logLevel() {
		return this._logLevel;
	}
	set logLevel(val) {
		if (!(val in LogLevel)) throw new TypeError(`Invalid value "${val}" assigned to \`logLevel\``);
		this._logLevel = val;
	}
	setLogLevel(val) {
		this._logLevel = typeof val === "string" ? levelStringToEnum[val] : val;
	}
	get logHandler() {
		return this._logHandler;
	}
	set logHandler(val) {
		if (typeof val !== "function") throw new TypeError("Value assigned to `logHandler` must be a function");
		this._logHandler = val;
	}
	get userLogHandler() {
		return this._userLogHandler;
	}
	set userLogHandler(val) {
		this._userLogHandler = val;
	}
	/**
	* The functions below are all based on the `console` interface
	*/
	debug(...args) {
		this._userLogHandler && this._userLogHandler(this, LogLevel.DEBUG, ...args);
		this._logHandler(this, LogLevel.DEBUG, ...args);
	}
	log(...args) {
		this._userLogHandler && this._userLogHandler(this, LogLevel.VERBOSE, ...args);
		this._logHandler(this, LogLevel.VERBOSE, ...args);
	}
	info(...args) {
		this._userLogHandler && this._userLogHandler(this, LogLevel.INFO, ...args);
		this._logHandler(this, LogLevel.INFO, ...args);
	}
	warn(...args) {
		this._userLogHandler && this._userLogHandler(this, LogLevel.WARN, ...args);
		this._logHandler(this, LogLevel.WARN, ...args);
	}
	error(...args) {
		this._userLogHandler && this._userLogHandler(this, LogLevel.ERROR, ...args);
		this._logHandler(this, LogLevel.ERROR, ...args);
	}
};
//#endregion
//#region node_modules/@firebase/app/dist/esm/index.esm.js
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var PlatformLoggerServiceImpl = class {
	constructor(container) {
		this.container = container;
	}
	getPlatformInfoString() {
		return this.container.getProviders().map((provider) => {
			if (isVersionServiceProvider(provider)) {
				const service = provider.getImmediate();
				return `${service.library}/${service.version}`;
			} else return null;
		}).filter((logString) => logString).join(" ");
	}
};
/**
*
* @param provider check if this provider provides a VersionService
*
* NOTE: Using Provider<'app-version'> is a hack to indicate that the provider
* provides VersionService. The provider is not necessarily a 'app-version'
* provider.
*/
function isVersionServiceProvider(provider) {
	return provider.getComponent()?.type === "VERSION";
}
var name$q = "@firebase/app";
var version$1 = "0.16.3";
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var logger = new Logger("@firebase/app");
var name$p = "@firebase/app-compat";
var name$o = "@firebase/analytics-compat";
var name$n = "@firebase/analytics";
var name$m = "@firebase/app-check-compat";
var name$l = "@firebase/app-check";
var name$k = "@firebase/auth";
var name$j = "@firebase/auth-compat";
var name$i = "@firebase/database";
var name$h = "@firebase/data-connect";
var name$g = "@firebase/database-compat";
var name$f = "@firebase/functions";
var name$e = "@firebase/functions-compat";
var name$d = "@firebase/installations";
var name$c = "@firebase/installations-compat";
var name$b = "@firebase/messaging";
var name$a = "@firebase/messaging-compat";
var name$9 = "@firebase/performance";
var name$8 = "@firebase/performance-compat";
var name$7 = "@firebase/remote-config";
var name$6 = "@firebase/remote-config-compat";
var name$5 = "@firebase/storage";
var name$4 = "@firebase/storage-compat";
var name$3 = "@firebase/firestore";
var name$2 = "@firebase/ai";
var name$1 = "@firebase/firestore-compat";
var name$10 = "firebase";
var version$2 = "13.0.0";
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* The default app name
*
* @internal
*/
var DEFAULT_ENTRY_NAME = "[DEFAULT]";
var PLATFORM_LOG_STRING = {
	[name$q]: "fire-core",
	[name$p]: "fire-core-compat",
	[name$n]: "fire-analytics",
	[name$o]: "fire-analytics-compat",
	[name$l]: "fire-app-check",
	[name$m]: "fire-app-check-compat",
	[name$k]: "fire-auth",
	[name$j]: "fire-auth-compat",
	[name$i]: "fire-rtdb",
	[name$h]: "fire-data-connect",
	[name$g]: "fire-rtdb-compat",
	[name$f]: "fire-fn",
	[name$e]: "fire-fn-compat",
	[name$d]: "fire-iid",
	[name$c]: "fire-iid-compat",
	[name$b]: "fire-fcm",
	[name$a]: "fire-fcm-compat",
	[name$9]: "fire-perf",
	[name$8]: "fire-perf-compat",
	[name$7]: "fire-rc",
	[name$6]: "fire-rc-compat",
	[name$5]: "fire-gcs",
	[name$4]: "fire-gcs-compat",
	[name$3]: "fire-fst",
	[name$1]: "fire-fst-compat",
	[name$2]: "fire-vertex",
	"fire-js": "fire-js",
	[name$10]: "fire-js-all"
};
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @internal
*/
var _apps = /* @__PURE__ */ new Map();
/**
* @internal
*/
var _serverApps = /* @__PURE__ */ new Map();
/**
* Registered components.
*
* @internal
*/
var _components = /* @__PURE__ */ new Map();
/**
* @param component - the component being added to this app's container
*
* @internal
*/
function _addComponent(app, component) {
	try {
		app.container.addComponent(component);
	} catch (e) {
		logger.debug(`Component ${component.name} failed to register with FirebaseApp ${app.name}`, e);
	}
}
/**
*
* @param component - the component to register
* @returns whether or not the component is registered successfully
*
* @internal
*/
function _registerComponent(component) {
	const componentName = component.name;
	if (_components.has(componentName)) {
		logger.debug(`There were multiple attempts to register component ${componentName}.`);
		return false;
	}
	_components.set(componentName, component);
	for (const app of _apps.values()) _addComponent(app, component);
	for (const serverApp of _serverApps.values()) _addComponent(serverApp, component);
	return true;
}
/**
*
* @param app - FirebaseApp instance
* @param name - service name
*
* @returns the provider for the service with the matching name
*
* @internal
*/
function _getProvider(app, name) {
	const heartbeatController = app.container.getProvider("heartbeat").getImmediate({ optional: true });
	if (heartbeatController) heartbeatController.triggerHeartbeat();
	return app.container.getProvider(name);
}
/**
*
* @param obj - an object of type FirebaseApp.
*
* @returns true if the provided object is of type FirebaseServerAppImpl.
*
* @internal
*/
function _isFirebaseServerApp(obj) {
	if (obj === null || obj === void 0) return false;
	return obj.settings !== void 0;
}
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var ERROR_FACTORY = new ErrorFactory("app", "Firebase", {
	["no-app"]: "No Firebase App '{$appName}' has been created - call initializeApp() first",
	["bad-app-name"]: "Illegal App name: '{$appName}'",
	["duplicate-app"]: "Firebase App named '{$appName}' already exists with different {$mismatchedParam}. Existing: '{$oldValue}'. New: '{$newValue}'.",
	["app-deleted"]: "Firebase App named '{$appName}' already deleted",
	["server-app-deleted"]: "Firebase Server App has been deleted",
	["no-options"]: "Need to provide options, when not being deployed to hosting via source.",
	["invalid-app-argument"]: "firebase.{$appName}() takes either no argument or a Firebase App instance.",
	["invalid-log-argument"]: "First argument to `onLog` must be null or a function.",
	["idb-open"]: "Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.",
	["idb-get"]: "Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.",
	["idb-set"]: "Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.",
	["idb-delete"]: "Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.",
	["finalization-registry-not-supported"]: "FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.",
	["invalid-server-app-environment"]: "FirebaseServerApp is not for use in browser environments."
});
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var FirebaseAppImpl = class {
	constructor(options, config, container) {
		this._isDeleted = false;
		this._options = { ...options };
		this._config = { ...config };
		this._name = config.name;
		this._automaticDataCollectionEnabled = config.automaticDataCollectionEnabled;
		this._container = container;
		this.container.addComponent(new Component("app", () => this, "PUBLIC"));
	}
	get automaticDataCollectionEnabled() {
		this.checkDestroyed();
		return this._automaticDataCollectionEnabled;
	}
	set automaticDataCollectionEnabled(val) {
		this.checkDestroyed();
		this._automaticDataCollectionEnabled = val;
	}
	get name() {
		this.checkDestroyed();
		return this._name;
	}
	get options() {
		this.checkDestroyed();
		return this._options;
	}
	get config() {
		this.checkDestroyed();
		return this._config;
	}
	get container() {
		return this._container;
	}
	get isDeleted() {
		return this._isDeleted;
	}
	set isDeleted(val) {
		this._isDeleted = val;
	}
	/**
	* This function will throw an Error if the App has already been deleted -
	* use before performing API actions on the App.
	*/
	checkDestroyed() {
		if (this.isDeleted) throw ERROR_FACTORY.create("app-deleted", { appName: this._name });
	}
};
/**
* @license
* Copyright 2023 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* The current SDK version.
*
* @public
*/
var SDK_VERSION = version$2;
function initializeApp(_options, rawConfig = {}) {
	let options = _options;
	if (typeof rawConfig !== "object") rawConfig = { name: rawConfig };
	const config = {
		name: DEFAULT_ENTRY_NAME,
		automaticDataCollectionEnabled: true,
		...rawConfig
	};
	const name = config.name;
	if (typeof name !== "string" || !name) throw ERROR_FACTORY.create("bad-app-name", { appName: String(name) });
	options || (options = getDefaultAppConfig());
	if (!options) throw ERROR_FACTORY.create("no-options");
	const existingApp = _apps.get(name);
	if (existingApp) {
		if (!deepEqual(options, existingApp.options)) throw ERROR_FACTORY.create("duplicate-app", {
			appName: name,
			mismatchedParam: "options",
			oldValue: JSON.stringify(existingApp.options),
			newValue: JSON.stringify(options)
		});
		else if (!deepEqual(config, existingApp.config)) throw ERROR_FACTORY.create("duplicate-app", {
			appName: name,
			mismatchedParam: "config",
			oldValue: JSON.stringify(existingApp.config),
			newValue: JSON.stringify(config)
		});
		else return existingApp;
	}
	const container = new ComponentContainer(name);
	for (const component of _components.values()) container.addComponent(component);
	const newApp = new FirebaseAppImpl(options, config, container);
	_apps.set(name, newApp);
	return newApp;
}
/**
* Retrieves a {@link @firebase/app#FirebaseApp} instance.
*
* When called with no arguments, the default app is returned. When an app name
* is provided, the app corresponding to that name is returned.
*
* An exception is thrown if the app being retrieved has not yet been
* initialized.
*
* @example
* ```javascript
* // Return the default app
* const app = getApp();
* ```
*
* @example
* ```javascript
* // Return a named app
* const otherApp = getApp("otherApp");
* ```
*
* @param name - Optional name of the app to return. If no name is
*   provided, the default is `"[DEFAULT]"`.
*
* @returns The app corresponding to the provided app name.
*   If no app name is provided, the default app is returned.
*
* @public
*/
function getApp(name = DEFAULT_ENTRY_NAME) {
	const app = _apps.get(name);
	if (!app && name === "[DEFAULT]" && getDefaultAppConfig()) return initializeApp();
	if (!app) throw ERROR_FACTORY.create("no-app", { appName: name });
	return app;
}
/**
* A (read-only) array of all initialized apps.
* @public
*/
function getApps() {
	return Array.from(_apps.values());
}
/**
* Registers a library's name and version for platform logging purposes.
* @param library - Name of 1p or 3p library (e.g. firestore, angularfire)
* @param version - Current version of that library.
* @param variant - Bundle variant, e.g., node, rn, etc.
*
* @public
*/
function registerVersion(libraryKeyOrName, version, variant) {
	let library = PLATFORM_LOG_STRING[libraryKeyOrName] ?? libraryKeyOrName;
	if (variant) library += `-${variant}`;
	const libraryMismatch = library.match(/\s|\//);
	const versionMismatch = version.match(/\s|\//);
	if (libraryMismatch || versionMismatch) {
		const warning = [`Unable to register library "${library}" with version "${version}":`];
		if (libraryMismatch) warning.push(`library name "${library}" contains illegal characters (whitespace or "/")`);
		if (libraryMismatch && versionMismatch) warning.push("and");
		if (versionMismatch) warning.push(`version name "${version}" contains illegal characters (whitespace or "/")`);
		logger.warn(warning.join(" "));
		return;
	}
	_registerComponent(new Component(`${library}-version`, () => ({
		library,
		version
	}), "VERSION"));
}
/**
* @license
* Copyright 2021 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var DB_NAME$1 = "firebase-heartbeat-database";
var DB_VERSION$1 = 1;
var STORE_NAME = "firebase-heartbeat-store";
var dbPromise = null;
function getDbPromise() {
	if (!dbPromise) dbPromise = openDB(DB_NAME$1, DB_VERSION$1, { upgrade: (db, oldVersion) => {
		switch (oldVersion) {
			case 0: try {
				db.createObjectStore(STORE_NAME);
			} catch (e) {
				console.warn(e);
			}
		}
	} }).catch((e) => {
		throw ERROR_FACTORY.create("idb-open", { originalErrorMessage: e.message });
	});
	return dbPromise;
}
async function readHeartbeatsFromIndexedDB(app) {
	try {
		const tx = (await getDbPromise()).transaction(STORE_NAME);
		const result = await tx.objectStore(STORE_NAME).get(computeKey(app));
		await tx.done;
		return result;
	} catch (e) {
		if (e instanceof FirebaseError) logger.warn(e.message);
		else {
			const idbGetError = ERROR_FACTORY.create("idb-get", { originalErrorMessage: e?.message });
			logger.warn(idbGetError.message);
		}
	}
}
async function writeHeartbeatsToIndexedDB(app, heartbeatObject) {
	try {
		const tx = (await getDbPromise()).transaction(STORE_NAME, "readwrite");
		await tx.objectStore(STORE_NAME).put(heartbeatObject, computeKey(app));
		await tx.done;
	} catch (e) {
		if (e instanceof FirebaseError) logger.warn(e.message);
		else {
			const idbGetError = ERROR_FACTORY.create("idb-set", { originalErrorMessage: e?.message });
			logger.warn(idbGetError.message);
		}
	}
}
function computeKey(app) {
	return `${app.name}!${app.options.appId}`;
}
/**
* @license
* Copyright 2021 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var MAX_HEADER_BYTES = 1024;
var MAX_NUM_STORED_HEARTBEATS = 30;
var HeartbeatServiceImpl = class {
	constructor(container) {
		this.container = container;
		/**
		* In-memory cache for heartbeats, used by getHeartbeatsHeader() to generate
		* the header string.
		* Stores one record per date. This will be consolidated into the standard
		* format of one record per user agent string before being sent as a header.
		* Populated from indexedDB when the controller is instantiated and should
		* be kept in sync with indexedDB.
		* Leave public for easier testing.
		*/
		this._heartbeatsCache = null;
		const app = this.container.getProvider("app").getImmediate();
		this._storage = new HeartbeatStorageImpl(app);
		this._heartbeatsCachePromise = this._storage.read().then((result) => {
			this._heartbeatsCache = result;
			return result;
		});
	}
	/**
	* Called to report a heartbeat. The function will generate
	* a HeartbeatsByUserAgent object, update heartbeatsCache, and persist it
	* to IndexedDB.
	* Note that we only store one heartbeat per day. So if a heartbeat for today is
	* already logged, subsequent calls to this function in the same day will be ignored.
	*/
	async triggerHeartbeat() {
		try {
			const agent = this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString();
			const date = getUTCDateString();
			if (this._heartbeatsCache?.heartbeats == null) {
				this._heartbeatsCache = await this._heartbeatsCachePromise;
				if (this._heartbeatsCache?.heartbeats == null) return;
			}
			if (this._heartbeatsCache.lastSentHeartbeatDate === date || this._heartbeatsCache.heartbeats.some((singleDateHeartbeat) => singleDateHeartbeat.date === date)) return;
			else {
				this._heartbeatsCache.heartbeats.push({
					date,
					agent
				});
				if (this._heartbeatsCache.heartbeats.length > MAX_NUM_STORED_HEARTBEATS) {
					const earliestHeartbeatIdx = getEarliestHeartbeatIdx(this._heartbeatsCache.heartbeats);
					this._heartbeatsCache.heartbeats.splice(earliestHeartbeatIdx, 1);
				}
			}
			return this._storage.overwrite(this._heartbeatsCache);
		} catch (e) {
			logger.warn(e);
		}
	}
	/**
	* Returns a base64 encoded string which can be attached to the heartbeat-specific header directly.
	* It also clears all heartbeats from memory as well as in IndexedDB.
	*
	* NOTE: Consuming product SDKs should not send the header if this method
	* returns an empty string.
	*/
	async getHeartbeatsHeader() {
		try {
			if (this._heartbeatsCache === null) await this._heartbeatsCachePromise;
			if (this._heartbeatsCache?.heartbeats == null || this._heartbeatsCache.heartbeats.length === 0) return "";
			const date = getUTCDateString();
			const { heartbeatsToSend, unsentEntries } = extractHeartbeatsForHeader(this._heartbeatsCache.heartbeats);
			const headerString = base64urlEncodeWithoutPadding(JSON.stringify({
				version: 2,
				heartbeats: heartbeatsToSend
			}));
			this._heartbeatsCache.lastSentHeartbeatDate = date;
			if (unsentEntries.length > 0) {
				this._heartbeatsCache.heartbeats = unsentEntries;
				await this._storage.overwrite(this._heartbeatsCache);
			} else {
				this._heartbeatsCache.heartbeats = [];
				this._storage.overwrite(this._heartbeatsCache);
			}
			return headerString;
		} catch (e) {
			logger.warn(e);
			return "";
		}
	}
};
function getUTCDateString() {
	return (/* @__PURE__ */ new Date()).toISOString().substring(0, 10);
}
function extractHeartbeatsForHeader(heartbeatsCache, maxSize = MAX_HEADER_BYTES) {
	const heartbeatsToSend = [];
	let unsentEntries = heartbeatsCache.slice();
	for (const singleDateHeartbeat of heartbeatsCache) {
		const heartbeatEntry = heartbeatsToSend.find((hb) => hb.agent === singleDateHeartbeat.agent);
		if (!heartbeatEntry) {
			heartbeatsToSend.push({
				agent: singleDateHeartbeat.agent,
				dates: [singleDateHeartbeat.date]
			});
			if (countBytes(heartbeatsToSend) > maxSize) {
				heartbeatsToSend.pop();
				break;
			}
		} else {
			heartbeatEntry.dates.push(singleDateHeartbeat.date);
			if (countBytes(heartbeatsToSend) > maxSize) {
				heartbeatEntry.dates.pop();
				break;
			}
		}
		unsentEntries = unsentEntries.slice(1);
	}
	return {
		heartbeatsToSend,
		unsentEntries
	};
}
var HeartbeatStorageImpl = class {
	constructor(app) {
		this.app = app;
		this._canUseIndexedDBPromise = this.runIndexedDBEnvironmentCheck();
	}
	async runIndexedDBEnvironmentCheck() {
		if (!isIndexedDBAvailable()) return false;
		else return validateIndexedDBOpenable().then(() => true).catch(() => false);
	}
	/**
	* Read all heartbeats.
	*/
	async read() {
		if (!await this._canUseIndexedDBPromise) return { heartbeats: [] };
		else {
			const idbHeartbeatObject = await readHeartbeatsFromIndexedDB(this.app);
			if (idbHeartbeatObject?.heartbeats) return idbHeartbeatObject;
			else return { heartbeats: [] };
		}
	}
	async overwrite(heartbeatsObject) {
		if (!await this._canUseIndexedDBPromise) return;
		else {
			const existingHeartbeatsObject = await this.read();
			return writeHeartbeatsToIndexedDB(this.app, {
				lastSentHeartbeatDate: heartbeatsObject.lastSentHeartbeatDate ?? existingHeartbeatsObject.lastSentHeartbeatDate,
				heartbeats: heartbeatsObject.heartbeats
			});
		}
	}
	async add(heartbeatsObject) {
		if (!await this._canUseIndexedDBPromise) return;
		else {
			const existingHeartbeatsObject = await this.read();
			return writeHeartbeatsToIndexedDB(this.app, {
				lastSentHeartbeatDate: heartbeatsObject.lastSentHeartbeatDate ?? existingHeartbeatsObject.lastSentHeartbeatDate,
				heartbeats: [...existingHeartbeatsObject.heartbeats, ...heartbeatsObject.heartbeats]
			});
		}
	}
};
/**
* Calculate bytes of a HeartbeatsByUserAgent array after being wrapped
* in a platform logging header JSON object, stringified, and converted
* to base 64.
*/
function countBytes(heartbeatsCache) {
	return base64urlEncodeWithoutPadding(JSON.stringify({
		version: 2,
		heartbeats: heartbeatsCache
	})).length;
}
/**
* Returns the index of the heartbeat with the earliest date.
* If the heartbeats array is empty, -1 is returned.
*/
function getEarliestHeartbeatIdx(heartbeats) {
	if (heartbeats.length === 0) return -1;
	let earliestHeartbeatIdx = 0;
	let earliestHeartbeatDate = heartbeats[0].date;
	for (let i = 1; i < heartbeats.length; i++) if (heartbeats[i].date < earliestHeartbeatDate) {
		earliestHeartbeatDate = heartbeats[i].date;
		earliestHeartbeatIdx = i;
	}
	return earliestHeartbeatIdx;
}
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function registerCoreComponents(variant) {
	_registerComponent(new Component("platform-logger", (container) => new PlatformLoggerServiceImpl(container), "PRIVATE"));
	_registerComponent(new Component("heartbeat", (container) => new HeartbeatServiceImpl(container), "PRIVATE"));
	registerVersion(name$q, version$1, variant);
	registerVersion(name$q, version$1, "esm2020");
	registerVersion("fire-js", "");
}
/**
* Firebase App
*
* @remarks This package coordinates the communication between the different Firebase components
* @packageDocumentation
*/
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
registerCoreComponents("");
//#endregion
//#region node_modules/@firebase/webchannel-wrapper/dist/bloom-blob/esm/bloom_blob_es2018.js
var commonjsGlobal$1 = typeof globalThis !== "undefined" ? globalThis : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : {};
var bloom_blob_es2018 = {};
/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/
var Integer;
var Md5;
(function() {
	var h;
	/** @license
	
	Copyright The Closure Library Authors.
	SPDX-License-Identifier: Apache-2.0
	*/
	function k(d, a) {
		function c() {}
		c.prototype = a.prototype;
		d.F = a.prototype;
		d.prototype = new c();
		d.prototype.constructor = d;
		d.D = function(f, e, g) {
			for (var b = Array(arguments.length - 2), r = 2; r < arguments.length; r++) b[r - 2] = arguments[r];
			return a.prototype[e].apply(f, b);
		};
	}
	function l() {
		this.blockSize = -1;
	}
	function m() {
		this.blockSize = -1;
		this.blockSize = 64;
		this.g = Array(4);
		this.C = Array(this.blockSize);
		this.o = this.h = 0;
		this.u();
	}
	k(m, l);
	m.prototype.u = function() {
		this.g[0] = 1732584193;
		this.g[1] = 4023233417;
		this.g[2] = 2562383102;
		this.g[3] = 271733878;
		this.o = this.h = 0;
	};
	function n(d, a, c) {
		c || (c = 0);
		const f = Array(16);
		if (typeof a === "string") for (var e = 0; e < 16; ++e) f[e] = a.charCodeAt(c++) | a.charCodeAt(c++) << 8 | a.charCodeAt(c++) << 16 | a.charCodeAt(c++) << 24;
		else for (e = 0; e < 16; ++e) f[e] = a[c++] | a[c++] << 8 | a[c++] << 16 | a[c++] << 24;
		a = d.g[0];
		c = d.g[1];
		e = d.g[2];
		let g = d.g[3], b;
		b = a + (g ^ c & (e ^ g)) + f[0] + 3614090360 & 4294967295;
		a = c + (b << 7 & 4294967295 | b >>> 25);
		b = g + (e ^ a & (c ^ e)) + f[1] + 3905402710 & 4294967295;
		g = a + (b << 12 & 4294967295 | b >>> 20);
		b = e + (c ^ g & (a ^ c)) + f[2] + 606105819 & 4294967295;
		e = g + (b << 17 & 4294967295 | b >>> 15);
		b = c + (a ^ e & (g ^ a)) + f[3] + 3250441966 & 4294967295;
		c = e + (b << 22 & 4294967295 | b >>> 10);
		b = a + (g ^ c & (e ^ g)) + f[4] + 4118548399 & 4294967295;
		a = c + (b << 7 & 4294967295 | b >>> 25);
		b = g + (e ^ a & (c ^ e)) + f[5] + 1200080426 & 4294967295;
		g = a + (b << 12 & 4294967295 | b >>> 20);
		b = e + (c ^ g & (a ^ c)) + f[6] + 2821735955 & 4294967295;
		e = g + (b << 17 & 4294967295 | b >>> 15);
		b = c + (a ^ e & (g ^ a)) + f[7] + 4249261313 & 4294967295;
		c = e + (b << 22 & 4294967295 | b >>> 10);
		b = a + (g ^ c & (e ^ g)) + f[8] + 1770035416 & 4294967295;
		a = c + (b << 7 & 4294967295 | b >>> 25);
		b = g + (e ^ a & (c ^ e)) + f[9] + 2336552879 & 4294967295;
		g = a + (b << 12 & 4294967295 | b >>> 20);
		b = e + (c ^ g & (a ^ c)) + f[10] + 4294925233 & 4294967295;
		e = g + (b << 17 & 4294967295 | b >>> 15);
		b = c + (a ^ e & (g ^ a)) + f[11] + 2304563134 & 4294967295;
		c = e + (b << 22 & 4294967295 | b >>> 10);
		b = a + (g ^ c & (e ^ g)) + f[12] + 1804603682 & 4294967295;
		a = c + (b << 7 & 4294967295 | b >>> 25);
		b = g + (e ^ a & (c ^ e)) + f[13] + 4254626195 & 4294967295;
		g = a + (b << 12 & 4294967295 | b >>> 20);
		b = e + (c ^ g & (a ^ c)) + f[14] + 2792965006 & 4294967295;
		e = g + (b << 17 & 4294967295 | b >>> 15);
		b = c + (a ^ e & (g ^ a)) + f[15] + 1236535329 & 4294967295;
		c = e + (b << 22 & 4294967295 | b >>> 10);
		b = a + (e ^ g & (c ^ e)) + f[1] + 4129170786 & 4294967295;
		a = c + (b << 5 & 4294967295 | b >>> 27);
		b = g + (c ^ e & (a ^ c)) + f[6] + 3225465664 & 4294967295;
		g = a + (b << 9 & 4294967295 | b >>> 23);
		b = e + (a ^ c & (g ^ a)) + f[11] + 643717713 & 4294967295;
		e = g + (b << 14 & 4294967295 | b >>> 18);
		b = c + (g ^ a & (e ^ g)) + f[0] + 3921069994 & 4294967295;
		c = e + (b << 20 & 4294967295 | b >>> 12);
		b = a + (e ^ g & (c ^ e)) + f[5] + 3593408605 & 4294967295;
		a = c + (b << 5 & 4294967295 | b >>> 27);
		b = g + (c ^ e & (a ^ c)) + f[10] + 38016083 & 4294967295;
		g = a + (b << 9 & 4294967295 | b >>> 23);
		b = e + (a ^ c & (g ^ a)) + f[15] + 3634488961 & 4294967295;
		e = g + (b << 14 & 4294967295 | b >>> 18);
		b = c + (g ^ a & (e ^ g)) + f[4] + 3889429448 & 4294967295;
		c = e + (b << 20 & 4294967295 | b >>> 12);
		b = a + (e ^ g & (c ^ e)) + f[9] + 568446438 & 4294967295;
		a = c + (b << 5 & 4294967295 | b >>> 27);
		b = g + (c ^ e & (a ^ c)) + f[14] + 3275163606 & 4294967295;
		g = a + (b << 9 & 4294967295 | b >>> 23);
		b = e + (a ^ c & (g ^ a)) + f[3] + 4107603335 & 4294967295;
		e = g + (b << 14 & 4294967295 | b >>> 18);
		b = c + (g ^ a & (e ^ g)) + f[8] + 1163531501 & 4294967295;
		c = e + (b << 20 & 4294967295 | b >>> 12);
		b = a + (e ^ g & (c ^ e)) + f[13] + 2850285829 & 4294967295;
		a = c + (b << 5 & 4294967295 | b >>> 27);
		b = g + (c ^ e & (a ^ c)) + f[2] + 4243563512 & 4294967295;
		g = a + (b << 9 & 4294967295 | b >>> 23);
		b = e + (a ^ c & (g ^ a)) + f[7] + 1735328473 & 4294967295;
		e = g + (b << 14 & 4294967295 | b >>> 18);
		b = c + (g ^ a & (e ^ g)) + f[12] + 2368359562 & 4294967295;
		c = e + (b << 20 & 4294967295 | b >>> 12);
		b = a + (c ^ e ^ g) + f[5] + 4294588738 & 4294967295;
		a = c + (b << 4 & 4294967295 | b >>> 28);
		b = g + (a ^ c ^ e) + f[8] + 2272392833 & 4294967295;
		g = a + (b << 11 & 4294967295 | b >>> 21);
		b = e + (g ^ a ^ c) + f[11] + 1839030562 & 4294967295;
		e = g + (b << 16 & 4294967295 | b >>> 16);
		b = c + (e ^ g ^ a) + f[14] + 4259657740 & 4294967295;
		c = e + (b << 23 & 4294967295 | b >>> 9);
		b = a + (c ^ e ^ g) + f[1] + 2763975236 & 4294967295;
		a = c + (b << 4 & 4294967295 | b >>> 28);
		b = g + (a ^ c ^ e) + f[4] + 1272893353 & 4294967295;
		g = a + (b << 11 & 4294967295 | b >>> 21);
		b = e + (g ^ a ^ c) + f[7] + 4139469664 & 4294967295;
		e = g + (b << 16 & 4294967295 | b >>> 16);
		b = c + (e ^ g ^ a) + f[10] + 3200236656 & 4294967295;
		c = e + (b << 23 & 4294967295 | b >>> 9);
		b = a + (c ^ e ^ g) + f[13] + 681279174 & 4294967295;
		a = c + (b << 4 & 4294967295 | b >>> 28);
		b = g + (a ^ c ^ e) + f[0] + 3936430074 & 4294967295;
		g = a + (b << 11 & 4294967295 | b >>> 21);
		b = e + (g ^ a ^ c) + f[3] + 3572445317 & 4294967295;
		e = g + (b << 16 & 4294967295 | b >>> 16);
		b = c + (e ^ g ^ a) + f[6] + 76029189 & 4294967295;
		c = e + (b << 23 & 4294967295 | b >>> 9);
		b = a + (c ^ e ^ g) + f[9] + 3654602809 & 4294967295;
		a = c + (b << 4 & 4294967295 | b >>> 28);
		b = g + (a ^ c ^ e) + f[12] + 3873151461 & 4294967295;
		g = a + (b << 11 & 4294967295 | b >>> 21);
		b = e + (g ^ a ^ c) + f[15] + 530742520 & 4294967295;
		e = g + (b << 16 & 4294967295 | b >>> 16);
		b = c + (e ^ g ^ a) + f[2] + 3299628645 & 4294967295;
		c = e + (b << 23 & 4294967295 | b >>> 9);
		b = a + (e ^ (c | ~g)) + f[0] + 4096336452 & 4294967295;
		a = c + (b << 6 & 4294967295 | b >>> 26);
		b = g + (c ^ (a | ~e)) + f[7] + 1126891415 & 4294967295;
		g = a + (b << 10 & 4294967295 | b >>> 22);
		b = e + (a ^ (g | ~c)) + f[14] + 2878612391 & 4294967295;
		e = g + (b << 15 & 4294967295 | b >>> 17);
		b = c + (g ^ (e | ~a)) + f[5] + 4237533241 & 4294967295;
		c = e + (b << 21 & 4294967295 | b >>> 11);
		b = a + (e ^ (c | ~g)) + f[12] + 1700485571 & 4294967295;
		a = c + (b << 6 & 4294967295 | b >>> 26);
		b = g + (c ^ (a | ~e)) + f[3] + 2399980690 & 4294967295;
		g = a + (b << 10 & 4294967295 | b >>> 22);
		b = e + (a ^ (g | ~c)) + f[10] + 4293915773 & 4294967295;
		e = g + (b << 15 & 4294967295 | b >>> 17);
		b = c + (g ^ (e | ~a)) + f[1] + 2240044497 & 4294967295;
		c = e + (b << 21 & 4294967295 | b >>> 11);
		b = a + (e ^ (c | ~g)) + f[8] + 1873313359 & 4294967295;
		a = c + (b << 6 & 4294967295 | b >>> 26);
		b = g + (c ^ (a | ~e)) + f[15] + 4264355552 & 4294967295;
		g = a + (b << 10 & 4294967295 | b >>> 22);
		b = e + (a ^ (g | ~c)) + f[6] + 2734768916 & 4294967295;
		e = g + (b << 15 & 4294967295 | b >>> 17);
		b = c + (g ^ (e | ~a)) + f[13] + 1309151649 & 4294967295;
		c = e + (b << 21 & 4294967295 | b >>> 11);
		b = a + (e ^ (c | ~g)) + f[4] + 4149444226 & 4294967295;
		a = c + (b << 6 & 4294967295 | b >>> 26);
		b = g + (c ^ (a | ~e)) + f[11] + 3174756917 & 4294967295;
		g = a + (b << 10 & 4294967295 | b >>> 22);
		b = e + (a ^ (g | ~c)) + f[2] + 718787259 & 4294967295;
		e = g + (b << 15 & 4294967295 | b >>> 17);
		b = c + (g ^ (e | ~a)) + f[9] + 3951481745 & 4294967295;
		d.g[0] = d.g[0] + a & 4294967295;
		d.g[1] = d.g[1] + (e + (b << 21 & 4294967295 | b >>> 11)) & 4294967295;
		d.g[2] = d.g[2] + e & 4294967295;
		d.g[3] = d.g[3] + g & 4294967295;
	}
	m.prototype.v = function(d, a) {
		a === void 0 && (a = d.length);
		const c = a - this.blockSize, f = this.C;
		let e = this.h, g = 0;
		for (; g < a;) {
			if (e == 0) for (; g <= c;) n(this, d, g), g += this.blockSize;
			if (typeof d === "string") {
				for (; g < a;) if (f[e++] = d.charCodeAt(g++), e == this.blockSize) {
					n(this, f);
					e = 0;
					break;
				}
			} else for (; g < a;) if (f[e++] = d[g++], e == this.blockSize) {
				n(this, f);
				e = 0;
				break;
			}
		}
		this.h = e;
		this.o += a;
	};
	m.prototype.A = function() {
		var d = Array((this.h < 56 ? this.blockSize : this.blockSize * 2) - this.h);
		d[0] = 128;
		for (var a = 1; a < d.length - 8; ++a) d[a] = 0;
		a = this.o * 8;
		for (var c = d.length - 8; c < d.length; ++c) d[c] = a & 255, a /= 256;
		this.v(d);
		d = Array(16);
		a = 0;
		for (c = 0; c < 4; ++c) for (let f = 0; f < 32; f += 8) d[a++] = this.g[c] >>> f & 255;
		return d;
	};
	function p(d, a) {
		var c = q;
		return Object.prototype.hasOwnProperty.call(c, d) ? c[d] : c[d] = a(d);
	}
	function t(d, a) {
		this.h = a;
		const c = [];
		let f = true;
		for (let e = d.length - 1; e >= 0; e--) {
			const g = d[e] | 0;
			f && g == a || (c[e] = g, f = false);
		}
		this.g = c;
	}
	var q = {};
	function u(d) {
		return -128 <= d && d < 128 ? p(d, function(a) {
			return new t([a | 0], a < 0 ? -1 : 0);
		}) : new t([d | 0], d < 0 ? -1 : 0);
	}
	function v(d) {
		if (isNaN(d) || !isFinite(d)) return w;
		if (d < 0) return x(v(-d));
		const a = [];
		let c = 1;
		for (let f = 0; d >= c; f++) a[f] = d / c | 0, c *= 4294967296;
		return new t(a, 0);
	}
	function y(d, a) {
		if (d.length == 0) throw Error("number format error: empty string");
		a = a || 10;
		if (a < 2 || 36 < a) throw Error("radix out of range: " + a);
		if (d.charAt(0) == "-") return x(y(d.substring(1), a));
		if (d.indexOf("-") >= 0) throw Error("number format error: interior \"-\" character");
		const c = v(Math.pow(a, 8));
		let f = w;
		for (let g = 0; g < d.length; g += 8) {
			var e = Math.min(8, d.length - g);
			const b = parseInt(d.substring(g, g + e), a);
			e < 8 ? (e = v(Math.pow(a, e)), f = f.j(e).add(v(b))) : (f = f.j(c), f = f.add(v(b)));
		}
		return f;
	}
	var w = u(0), z = u(1), A = u(16777216);
	h = t.prototype;
	h.m = function() {
		if (B(this)) return -x(this).m();
		let d = 0, a = 1;
		for (let c = 0; c < this.g.length; c++) {
			const f = this.i(c);
			d += (f >= 0 ? f : 4294967296 + f) * a;
			a *= 4294967296;
		}
		return d;
	};
	h.toString = function(d) {
		d = d || 10;
		if (d < 2 || 36 < d) throw Error("radix out of range: " + d);
		if (C(this)) return "0";
		if (B(this)) return "-" + x(this).toString(d);
		const a = v(Math.pow(d, 6));
		var c = this;
		let f = "";
		for (;;) {
			const e = D(c, a).g;
			c = F(c, e.j(a));
			let g = ((c.g.length > 0 ? c.g[0] : c.h) >>> 0).toString(d);
			c = e;
			if (C(c)) return g + f;
			for (; g.length < 6;) g = "0" + g;
			f = g + f;
		}
	};
	h.i = function(d) {
		return d < 0 ? 0 : d < this.g.length ? this.g[d] : this.h;
	};
	function C(d) {
		if (d.h != 0) return false;
		for (let a = 0; a < d.g.length; a++) if (d.g[a] != 0) return false;
		return true;
	}
	function B(d) {
		return d.h == -1;
	}
	h.l = function(d) {
		d = F(this, d);
		return B(d) ? -1 : C(d) ? 0 : 1;
	};
	function x(d) {
		const a = d.g.length, c = [];
		for (let f = 0; f < a; f++) c[f] = ~d.g[f];
		return new t(c, ~d.h).add(z);
	}
	h.abs = function() {
		return B(this) ? x(this) : this;
	};
	h.add = function(d) {
		const a = Math.max(this.g.length, d.g.length), c = [];
		let f = 0;
		for (let e = 0; e <= a; e++) {
			let g = f + (this.i(e) & 65535) + (d.i(e) & 65535), b = (g >>> 16) + (this.i(e) >>> 16) + (d.i(e) >>> 16);
			f = b >>> 16;
			g &= 65535;
			b &= 65535;
			c[e] = b << 16 | g;
		}
		return new t(c, c[c.length - 1] & -2147483648 ? -1 : 0);
	};
	function F(d, a) {
		return d.add(x(a));
	}
	h.j = function(d) {
		if (C(this) || C(d)) return w;
		if (B(this)) return B(d) ? x(this).j(x(d)) : x(x(this).j(d));
		if (B(d)) return x(this.j(x(d)));
		if (this.l(A) < 0 && d.l(A) < 0) return v(this.m() * d.m());
		const a = this.g.length + d.g.length, c = [];
		for (var f = 0; f < 2 * a; f++) c[f] = 0;
		for (f = 0; f < this.g.length; f++) for (let e = 0; e < d.g.length; e++) {
			const g = this.i(f) >>> 16, b = this.i(f) & 65535, r = d.i(e) >>> 16, E = d.i(e) & 65535;
			c[2 * f + 2 * e] += b * E;
			G(c, 2 * f + 2 * e);
			c[2 * f + 2 * e + 1] += g * E;
			G(c, 2 * f + 2 * e + 1);
			c[2 * f + 2 * e + 1] += b * r;
			G(c, 2 * f + 2 * e + 1);
			c[2 * f + 2 * e + 2] += g * r;
			G(c, 2 * f + 2 * e + 2);
		}
		for (d = 0; d < a; d++) c[d] = c[2 * d + 1] << 16 | c[2 * d];
		for (d = a; d < 2 * a; d++) c[d] = 0;
		return new t(c, 0);
	};
	function G(d, a) {
		for (; (d[a] & 65535) != d[a];) d[a + 1] += d[a] >>> 16, d[a] &= 65535, a++;
	}
	function H(d, a) {
		this.g = d;
		this.h = a;
	}
	function D(d, a) {
		if (C(a)) throw Error("division by zero");
		if (C(d)) return new H(w, w);
		if (B(d)) return a = D(x(d), a), new H(x(a.g), x(a.h));
		if (B(a)) return a = D(d, x(a)), new H(x(a.g), a.h);
		if (d.g.length > 30) {
			if (B(d) || B(a)) throw Error("slowDivide_ only works with positive integers.");
			for (var c = z, f = a; f.l(d) <= 0;) c = I(c), f = I(f);
			var e = J(c, 1), g = J(f, 1);
			f = J(f, 2);
			for (c = J(c, 2); !C(f);) {
				var b = g.add(f);
				b.l(d) <= 0 && (e = e.add(c), g = b);
				f = J(f, 1);
				c = J(c, 1);
			}
			a = F(d, e.j(a));
			return new H(e, a);
		}
		for (e = w; d.l(a) >= 0;) {
			c = Math.max(1, Math.floor(d.m() / a.m()));
			f = Math.ceil(Math.log(c) / Math.LN2);
			f = f <= 48 ? 1 : Math.pow(2, f - 48);
			g = v(c);
			for (b = g.j(a); B(b) || b.l(d) > 0;) c -= f, g = v(c), b = g.j(a);
			C(g) && (g = z);
			e = e.add(g);
			d = F(d, b);
		}
		return new H(e, d);
	}
	h.B = function(d) {
		return D(this, d).h;
	};
	h.and = function(d) {
		const a = Math.max(this.g.length, d.g.length), c = [];
		for (let f = 0; f < a; f++) c[f] = this.i(f) & d.i(f);
		return new t(c, this.h & d.h);
	};
	h.or = function(d) {
		const a = Math.max(this.g.length, d.g.length), c = [];
		for (let f = 0; f < a; f++) c[f] = this.i(f) | d.i(f);
		return new t(c, this.h | d.h);
	};
	h.xor = function(d) {
		const a = Math.max(this.g.length, d.g.length), c = [];
		for (let f = 0; f < a; f++) c[f] = this.i(f) ^ d.i(f);
		return new t(c, this.h ^ d.h);
	};
	function I(d) {
		const a = d.g.length + 1, c = [];
		for (let f = 0; f < a; f++) c[f] = d.i(f) << 1 | d.i(f - 1) >>> 31;
		return new t(c, d.h);
	}
	function J(d, a) {
		const c = a >> 5;
		a %= 32;
		const f = d.g.length - c, e = [];
		for (let g = 0; g < f; g++) e[g] = a > 0 ? d.i(g + c) >>> a | d.i(g + c + 1) << 32 - a : d.i(g + c);
		return new t(e, d.h);
	}
	m.prototype.digest = m.prototype.A;
	m.prototype.reset = m.prototype.u;
	m.prototype.update = m.prototype.v;
	Md5 = bloom_blob_es2018.Md5 = m;
	t.prototype.add = t.prototype.add;
	t.prototype.multiply = t.prototype.j;
	t.prototype.modulo = t.prototype.B;
	t.prototype.compare = t.prototype.l;
	t.prototype.toNumber = t.prototype.m;
	t.prototype.toString = t.prototype.toString;
	t.prototype.getBits = t.prototype.i;
	t.fromNumber = v;
	t.fromString = y;
	Integer = bloom_blob_es2018.Integer = t;
}).apply(typeof commonjsGlobal$1 !== "undefined" ? commonjsGlobal$1 : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {});
//#endregion
//#region node_modules/@firebase/webchannel-wrapper/dist/webchannel-blob/esm/webchannel_blob_es2018.js
var commonjsGlobal = typeof globalThis !== "undefined" ? globalThis : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : {};
var webchannel_blob_es2018 = {};
/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/
var XhrIo;
var WebChannel;
var EventType;
var ErrorCode;
var Stat;
var Event;
var getStatEventTarget;
var createWebChannelTransport;
(function() {
	var h, aa = Object.defineProperty;
	function ba(a) {
		a = [
			"object" == typeof globalThis && globalThis,
			a,
			"object" == typeof window && window,
			"object" == typeof self && self,
			"object" == typeof commonjsGlobal && commonjsGlobal
		];
		for (var b = 0; b < a.length; ++b) {
			var c = a[b];
			if (c && c.Math == Math) return c;
		}
		throw Error("Cannot find global object");
	}
	var ca = ba(this);
	function da(a, b) {
		if (b) a: {
			var c = ca;
			a = a.split(".");
			for (var d = 0; d < a.length - 1; d++) {
				var e = a[d];
				if (!(e in c)) break a;
				c = c[e];
			}
			a = a[a.length - 1];
			d = c[a];
			b = b(d);
			b != d && b != null && aa(c, a, {
				configurable: true,
				writable: true,
				value: b
			});
		}
	}
	da("Symbol.dispose", function(a) {
		return a ? a : Symbol("Symbol.dispose");
	});
	da("Array.prototype.values", function(a) {
		return a ? a : function() {
			return this[Symbol.iterator]();
		};
	});
	da("Object.entries", function(a) {
		return a ? a : function(b) {
			var c = [], d;
			for (d in b) Object.prototype.hasOwnProperty.call(b, d) && c.push([d, b[d]]);
			return c;
		};
	});
	/** @license
	
	Copyright The Closure Library Authors.
	SPDX-License-Identifier: Apache-2.0
	*/
	var ea = ea || {}, l = this || self;
	function n(a) {
		var b = typeof a;
		return b == "object" && a != null || b == "function";
	}
	function fa(a, b, c) {
		return a.call.apply(a.bind, arguments);
	}
	function p(a, b, c) {
		p = fa;
		return p.apply(null, arguments);
	}
	function ha(a, b) {
		var c = Array.prototype.slice.call(arguments, 1);
		return function() {
			var d = c.slice();
			d.push.apply(d, arguments);
			return a.apply(this, d);
		};
	}
	function t(a, b) {
		function c() {}
		c.prototype = b.prototype;
		a.Z = b.prototype;
		a.prototype = new c();
		a.prototype.constructor = a;
		a.Ob = function(d, e, f) {
			for (var g = Array(arguments.length - 2), k = 2; k < arguments.length; k++) g[k - 2] = arguments[k];
			return b.prototype[e].apply(d, g);
		};
	}
	var ia = typeof AsyncContext !== "undefined" && typeof AsyncContext.Snapshot === "function" ? (a) => a && AsyncContext.Snapshot.wrap(a) : (a) => a;
	function ja(a) {
		const b = a.length;
		if (b > 0) {
			const c = Array(b);
			for (let d = 0; d < b; d++) c[d] = a[d];
			return c;
		}
		return [];
	}
	function ka(a, b) {
		for (let d = 1; d < arguments.length; d++) {
			const e = arguments[d];
			var c = typeof e;
			c = c != "object" ? c : e ? Array.isArray(e) ? "array" : c : "null";
			if (c == "array" || c == "object" && typeof e.length == "number") {
				c = a.length || 0;
				const f = e.length || 0;
				a.length = c + f;
				for (let g = 0; g < f; g++) a[c + g] = e[g];
			} else a.push(e);
		}
	}
	class la {
		constructor(a, b) {
			this.i = a;
			this.j = b;
			this.h = 0;
			this.g = null;
		}
		get() {
			let a;
			this.h > 0 ? (this.h--, a = this.g, this.g = a.next, a.next = null) : a = this.i();
			return a;
		}
	}
	function ma(a) {
		l.setTimeout(() => {
			throw a;
		}, 0);
	}
	function na() {
		var a = oa;
		let b = null;
		a.g && (b = a.g, a.g = a.g.next, a.g || (a.h = null), b.next = null);
		return b;
	}
	class pa {
		constructor() {
			this.h = this.g = null;
		}
		add(a, b) {
			const c = qa.get();
			c.set(a, b);
			this.h ? this.h.next = c : this.g = c;
			this.h = c;
		}
	}
	var qa = new la(() => new ra(), (a) => a.reset());
	class ra {
		constructor() {
			this.next = this.g = this.h = null;
		}
		set(a, b) {
			this.h = a;
			this.g = b;
			this.next = null;
		}
		reset() {
			this.next = this.g = this.h = null;
		}
	}
	let u, v = false, oa = new pa(), ta = () => {
		const a = Promise.resolve(void 0);
		u = () => {
			a.then(sa);
		};
	};
	function sa() {
		for (var a; a = na();) {
			try {
				a.h.call(a.g);
			} catch (c) {
				ma(c);
			}
			var b = qa;
			b.j(a);
			b.h < 100 && (b.h++, a.next = b.g, b.g = a);
		}
		v = false;
	}
	function w() {
		this.u = this.u;
		this.C = this.C;
	}
	w.prototype.u = false;
	w.prototype.dispose = function() {
		this.u || (this.u = true, this.N());
	};
	w.prototype[Symbol.dispose] = function() {
		this.dispose();
	};
	w.prototype.N = function() {
		if (this.C) for (; this.C.length;) this.C.shift()();
	};
	function x(a, b) {
		this.type = a;
		this.g = this.target = b;
		this.defaultPrevented = false;
	}
	x.prototype.h = function() {
		this.defaultPrevented = true;
	};
	var ua = function() {
		if (!l.addEventListener || !Object.defineProperty) return false;
		var a = false, b = Object.defineProperty({}, "passive", { get: function() {
			a = true;
		} });
		try {
			const c = () => {};
			l.addEventListener("test", c, b);
			l.removeEventListener("test", c, b);
		} catch (c) {}
		return a;
	}();
	function y(a) {
		return /^[\s\xa0]*$/.test(a);
	}
	function z(a, b) {
		x.call(this, a ? a.type : "");
		this.relatedTarget = this.g = this.target = null;
		this.button = this.screenY = this.screenX = this.clientY = this.clientX = 0;
		this.key = "";
		this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = false;
		this.state = null;
		this.pointerId = 0;
		this.pointerType = "";
		this.i = null;
		a && this.init(a, b);
	}
	t(z, x);
	z.prototype.init = function(a, b) {
		const c = this.type = a.type, d = a.changedTouches && a.changedTouches.length ? a.changedTouches[0] : null;
		this.target = a.target || a.srcElement;
		this.g = b;
		b = a.relatedTarget;
		b || (c == "mouseover" ? b = a.fromElement : c == "mouseout" && (b = a.toElement));
		this.relatedTarget = b;
		d ? (this.clientX = d.clientX !== void 0 ? d.clientX : d.pageX, this.clientY = d.clientY !== void 0 ? d.clientY : d.pageY, this.screenX = d.screenX || 0, this.screenY = d.screenY || 0) : (this.clientX = a.clientX !== void 0 ? a.clientX : a.pageX, this.clientY = a.clientY !== void 0 ? a.clientY : a.pageY, this.screenX = a.screenX || 0, this.screenY = a.screenY || 0);
		this.button = a.button;
		this.key = a.key || "";
		this.ctrlKey = a.ctrlKey;
		this.altKey = a.altKey;
		this.shiftKey = a.shiftKey;
		this.metaKey = a.metaKey;
		this.pointerId = a.pointerId || 0;
		this.pointerType = a.pointerType;
		this.state = a.state;
		this.i = a;
		a.defaultPrevented && z.Z.h.call(this);
	};
	z.prototype.h = function() {
		z.Z.h.call(this);
		const a = this.i;
		a.preventDefault ? a.preventDefault() : a.returnValue = false;
	};
	var B = "closure_listenable_" + (Math.random() * 1e6 | 0);
	var va = 0;
	function wa(a, b, c, d, e) {
		this.listener = a;
		this.proxy = null;
		this.src = b;
		this.type = c;
		this.capture = !!d;
		this.ha = e;
		this.key = ++va;
		this.da = this.fa = false;
	}
	function xa(a) {
		a.da = true;
		a.listener = null;
		a.proxy = null;
		a.src = null;
		a.ha = null;
	}
	function ya(a, b, c) {
		for (const d in a) b.call(c, a[d], d, a);
	}
	function Aa(a, b) {
		for (const c in a) b.call(void 0, a[c], c, a);
	}
	function Ba(a) {
		const b = {};
		for (const c in a) b[c] = a[c];
		return b;
	}
	const Ca = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");
	function Da(a, b) {
		let c, d;
		for (let e = 1; e < arguments.length; e++) {
			d = arguments[e];
			for (c in d) a[c] = d[c];
			for (let f = 0; f < Ca.length; f++) c = Ca[f], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c]);
		}
	}
	function Ea(a) {
		this.src = a;
		this.g = {};
		this.h = 0;
	}
	Ea.prototype.add = function(a, b, c, d, e) {
		const f = a.toString();
		a = this.g[f];
		a || (a = this.g[f] = [], this.h++);
		const g = Fa(a, b, d, e);
		g > -1 ? (b = a[g], c || (b.fa = false)) : (b = new wa(b, this.src, f, !!d, e), b.fa = c, a.push(b));
		return b;
	};
	function Ga(a, b) {
		const c = b.type;
		if (c in a.g) {
			var d = a.g[c], e = Array.prototype.indexOf.call(d, b, void 0), f;
			(f = e >= 0) && Array.prototype.splice.call(d, e, 1);
			f && (xa(b), a.g[c].length == 0 && (delete a.g[c], a.h--));
		}
	}
	function Fa(a, b, c, d) {
		for (let e = 0; e < a.length; ++e) {
			const f = a[e];
			if (!f.da && f.listener == b && f.capture == !!c && f.ha == d) return e;
		}
		return -1;
	}
	var Ha = "closure_lm_" + (Math.random() * 1e6 | 0), Ia = {};
	function Ka(a, b, c, d, e) {
		if (Array.isArray(b)) {
			for (let f = 0; f < b.length; f++) Ka(a, b[f], c, d, e);
			return null;
		}
		c = Ma(c);
		return a && a[B] ? a.J(b, c, n(d) ? !!d.capture : false, e) : Na(a, b, c, false, d, e);
	}
	function Na(a, b, c, d, e, f) {
		if (!b) throw Error("Invalid event type");
		const g = n(e) ? !!e.capture : !!e;
		let k = Oa(a);
		k || (a[Ha] = k = new Ea(a));
		c = k.add(b, c, d, g, f);
		if (c.proxy) return c;
		d = Pa();
		c.proxy = d;
		d.src = a;
		d.listener = c;
		if (a.addEventListener) ua || (e = g), e === void 0 && (e = false), a.addEventListener(b.toString(), d, e);
		else if (a.attachEvent) a.attachEvent(Qa(b.toString()), d);
		else if (a.addListener && a.removeListener) a.addListener(d);
		else throw Error("addEventListener and attachEvent are unavailable.");
		return c;
	}
	function Pa() {
		function a(c) {
			return b.call(a.src, a.listener, c);
		}
		const b = Ra;
		return a;
	}
	function Sa(a, b, c, d, e) {
		if (Array.isArray(b)) for (var f = 0; f < b.length; f++) Sa(a, b[f], c, d, e);
		else (d = n(d) ? !!d.capture : !!d, c = Ma(c), a && a[B]) ? (a = a.i, f = String(b).toString(), f in a.g && (b = a.g[f], c = Fa(b, c, d, e), c > -1 && (xa(b[c]), Array.prototype.splice.call(b, c, 1), b.length == 0 && (delete a.g[f], a.h--)))) : a && (a = Oa(a)) && (b = a.g[b.toString()], a = -1, b && (a = Fa(b, c, d, e)), (c = a > -1 ? b[a] : null) && Ta(c));
	}
	function Ta(a) {
		if (typeof a !== "number" && a && !a.da) {
			var b = a.src;
			if (b && b[B]) Ga(b.i, a);
			else {
				var c = a.type, d = a.proxy;
				b.removeEventListener ? b.removeEventListener(c, d, a.capture) : b.detachEvent ? b.detachEvent(Qa(c), d) : b.addListener && b.removeListener && b.removeListener(d);
				(c = Oa(b)) ? (Ga(c, a), c.h == 0 && (c.src = null, b[Ha] = null)) : xa(a);
			}
		}
	}
	function Qa(a) {
		return a in Ia ? Ia[a] : Ia[a] = "on" + a;
	}
	function Ra(a, b) {
		if (a.da) a = true;
		else {
			b = new z(b, this);
			const c = a.listener, d = a.ha || a.src;
			a.fa && Ta(a);
			a = c.call(d, b);
		}
		return a;
	}
	function Oa(a) {
		a = a[Ha];
		return a instanceof Ea ? a : null;
	}
	var Ua = "__closure_events_fn_" + (Math.random() * 1e9 >>> 0);
	function Ma(a) {
		if (typeof a === "function") return a;
		a[Ua] || (a[Ua] = function(b) {
			return a.handleEvent(b);
		});
		return a[Ua];
	}
	function C() {
		w.call(this);
		this.i = new Ea(this);
		this.M = this;
		this.G = null;
	}
	t(C, w);
	C.prototype[B] = true;
	C.prototype.removeEventListener = function(a, b, c, d) {
		Sa(this, a, b, c, d);
	};
	function D(a, b) {
		var c, d = a.G;
		if (d) for (c = []; d; d = d.G) c.push(d);
		a = a.M;
		d = b.type || b;
		if (typeof b === "string") b = new x(b, a);
		else if (b instanceof x) b.target = b.target || a;
		else {
			var e = b;
			b = new x(d, a);
			Da(b, e);
		}
		e = true;
		let f, g;
		if (c) for (g = c.length - 1; g >= 0; g--) f = b.g = c[g], e = Va(f, d, true, b) && e;
		f = b.g = a;
		e = Va(f, d, true, b) && e;
		e = Va(f, d, false, b) && e;
		if (c) for (g = 0; g < c.length; g++) f = b.g = c[g], e = Va(f, d, false, b) && e;
	}
	C.prototype.N = function() {
		C.Z.N.call(this);
		if (this.i) {
			var a = this.i;
			for (const c in a.g) {
				const d = a.g[c];
				for (let e = 0; e < d.length; e++) xa(d[e]);
				delete a.g[c];
				a.h--;
			}
		}
		this.G = null;
	};
	C.prototype.J = function(a, b, c, d) {
		return this.i.add(String(a), b, false, c, d);
	};
	C.prototype.K = function(a, b, c, d) {
		return this.i.add(String(a), b, true, c, d);
	};
	function Va(a, b, c, d) {
		b = a.i.g[String(b)];
		if (!b) return true;
		b = b.concat();
		let e = true;
		for (let f = 0; f < b.length; ++f) {
			const g = b[f];
			if (g && !g.da && g.capture == c) {
				const k = g.listener, q = g.ha || g.src;
				g.fa && Ga(a.i, g);
				e = k.call(q, d) !== false && e;
			}
		}
		return e && !d.defaultPrevented;
	}
	function Wa(a, b) {
		if (typeof a !== "function") if (a && typeof a.handleEvent == "function") a = p(a.handleEvent, a);
		else throw Error("Invalid listener argument");
		return Number(b) > 2147483647 ? -1 : l.setTimeout(a, b || 0);
	}
	function Xa(a) {
		a.g = Wa(() => {
			a.g = null;
			a.i && (a.i = false, Xa(a));
		}, a.l);
		const b = a.h;
		a.h = null;
		a.m.apply(null, b);
	}
	class Ya extends w {
		constructor(a, b) {
			super();
			this.m = a;
			this.l = b;
			this.h = null;
			this.i = false;
			this.g = null;
		}
		j(a) {
			this.h = arguments;
			this.g ? this.i = true : Xa(this);
		}
		N() {
			super.N();
			this.g && (l.clearTimeout(this.g), this.g = null, this.i = false, this.h = null);
		}
	}
	function E(a) {
		w.call(this);
		this.h = a;
		this.g = {};
	}
	t(E, w);
	var Za = [];
	function $a(a) {
		ya(a.g, function(b, c) {
			this.g.hasOwnProperty(c) && Ta(b);
		}, a);
		a.g = {};
	}
	E.prototype.N = function() {
		E.Z.N.call(this);
		$a(this);
	};
	E.prototype.handleEvent = function() {
		throw Error("EventHandler.handleEvent not implemented");
	};
	var ab = l.JSON.stringify;
	var cb = l.JSON.parse;
	var db = class {
		stringify(a) {
			return l.JSON.stringify(a, void 0);
		}
		parse(a) {
			return l.JSON.parse(a, void 0);
		}
	};
	function eb() {}
	function fb() {}
	var H = {
		OPEN: "a",
		hb: "b",
		ERROR: "c",
		tb: "d"
	};
	function gb() {
		x.call(this, "d");
	}
	t(gb, x);
	function hb() {
		x.call(this, "c");
	}
	t(hb, x);
	var I = {}, ib = null;
	function jb() {
		return ib = ib || new C();
	}
	I.Ia = "serverreachability";
	function kb(a) {
		x.call(this, I.Ia, a);
	}
	t(kb, x);
	function lb(a) {
		const b = jb();
		D(b, new kb(b));
	}
	I.STAT_EVENT = "statevent";
	function mb(a, b) {
		x.call(this, I.STAT_EVENT, a);
		this.stat = b;
	}
	t(mb, x);
	function J(a) {
		const b = jb();
		D(b, new mb(b, a));
	}
	I.Ja = "timingevent";
	function nb(a, b) {
		x.call(this, I.Ja, a);
		this.size = b;
	}
	t(nb, x);
	function ob(a, b) {
		if (typeof a !== "function") throw Error("Fn must not be null and must be a function");
		return l.setTimeout(function() {
			a();
		}, b);
	}
	function pb() {
		this.g = true;
	}
	pb.prototype.ua = function() {
		this.g = false;
	};
	function qb(a, b, c, d, e, f) {
		a.info(function() {
			if (a.g) if (f) {
				var g = "";
				var k = f.split("&");
				for (let m = 0; m < k.length; m++) {
					var q = k[m].split("=");
					if (q.length > 1) {
						const r = q[0];
						q = q[1];
						const A = r.split("_");
						g = A.length >= 2 && A[1] == "type" ? g + (r + "=" + q + "&") : g + (r + "=redacted&");
					}
				}
			} else g = null;
			else g = f;
			return "XMLHTTP REQ (" + d + ") [attempt " + e + "]: " + b + "\n" + c + "\n" + g;
		});
	}
	function rb(a, b, c, d, e, f, g) {
		a.info(function() {
			return "XMLHTTP RESP (" + d + ") [ attempt " + e + "]: " + b + "\n" + c + "\n" + f + " " + g;
		});
	}
	function K(a, b, c, d) {
		a.info(function() {
			return "XMLHTTP TEXT (" + b + "): " + sb(a, c) + (d ? " " + d : "");
		});
	}
	function tb(a, b) {
		a.info(function() {
			return "TIMEOUT: " + b;
		});
	}
	pb.prototype.info = function() {};
	function sb(a, b) {
		if (!a.g) return b;
		if (!b) return null;
		try {
			const f = JSON.parse(b);
			if (f) {
				for (a = 0; a < f.length; a++) if (Array.isArray(f[a])) {
					var c = f[a];
					if (!(c.length < 2)) {
						var d = c[1];
						if (Array.isArray(d) && !(d.length < 1)) {
							var e = d[0];
							if (e != "noop" && e != "stop" && e != "close") for (let g = 1; g < d.length; g++) d[g] = "";
						}
					}
				}
			}
			return ab(f);
		} catch (f) {
			return b;
		}
	}
	var ub = {
		NO_ERROR: 0,
		cb: 1,
		qb: 2,
		pb: 3,
		kb: 4,
		ob: 5,
		rb: 6,
		Ga: 7,
		TIMEOUT: 8,
		ub: 9
	};
	var vb = {
		ib: "complete",
		Fb: "success",
		ERROR: "error",
		Ga: "abort",
		xb: "ready",
		yb: "readystatechange",
		TIMEOUT: "timeout",
		sb: "incrementaldata",
		wb: "progress",
		lb: "downloadprogress",
		Nb: "uploadprogress"
	};
	var wb;
	function xb() {}
	t(xb, eb);
	xb.prototype.g = function() {
		return new XMLHttpRequest();
	};
	wb = new xb();
	function L(a) {
		return encodeURIComponent(String(a));
	}
	function yb(a) {
		var b = 1;
		a = a.split(":");
		const c = [];
		for (; b > 0 && a.length;) c.push(a.shift()), b--;
		a.length && c.push(a.join(":"));
		return c;
	}
	function N(a, b, c, d) {
		this.j = a;
		this.i = b;
		this.l = c;
		this.S = d || 1;
		this.V = new E(this);
		this.H = 45e3;
		this.J = null;
		this.o = false;
		this.u = this.B = this.A = this.M = this.F = this.T = this.D = null;
		this.G = [];
		this.g = null;
		this.C = 0;
		this.m = this.v = null;
		this.X = -1;
		this.K = false;
		this.P = 0;
		this.O = null;
		this.W = this.L = this.U = this.R = false;
		this.h = new zb();
	}
	function zb() {
		this.i = null;
		this.g = "";
		this.h = false;
	}
	var Ab = {}, Bb = {};
	function Cb(a, b, c) {
		a.M = 1;
		a.A = Db(O(b));
		a.u = c;
		a.R = true;
		Eb(a, null);
	}
	function Eb(a, b) {
		a.F = Date.now();
		Fb(a);
		a.B = O(a.A);
		var c = a.B, d = a.S;
		Array.isArray(d) || (d = [String(d)]);
		Gb(c.i, "t", d);
		a.C = 0;
		c = a.j.L;
		a.h = new zb();
		a.g = Hb(a.j, c ? b : null, !a.u);
		a.P > 0 && (a.O = new Ya(p(a.Y, a, a.g), a.P));
		b = a.V;
		c = a.g;
		d = a.ba;
		var e = "readystatechange";
		Array.isArray(e) || (e && (Za[0] = e.toString()), e = Za);
		for (let f = 0; f < e.length; f++) {
			const g = Ka(c, e[f], d || b.handleEvent, false, b.h || b);
			if (!g) break;
			b.g[g.key] = g;
		}
		b = a.J ? Ba(a.J) : {};
		a.u ? (a.v || (a.v = "POST"), b["Content-Type"] = "application/x-www-form-urlencoded", a.g.ea(a.B, a.v, a.u, b)) : (a.v = "GET", a.g.ea(a.B, a.v, null, b));
		lb();
		qb(a.i, a.v, a.B, a.l, a.S, a.u);
	}
	N.prototype.ba = function(a) {
		a = a.target;
		const b = this.O;
		b && P(a) == 3 ? b.j() : this.Y(a);
	};
	N.prototype.Y = function(a) {
		try {
			if (a == this.g) a: {
				const k = P(this.g), q = this.g.ya(), m = this.g.ca();
				if (!(k < 3) && (k != 3 || this.g && (this.h.h || this.g.la() || Ib(this.g)))) {
					this.K || k != 4 || q == 7 || (q == 8 || m <= 0 ? lb(3) : lb(2));
					Jb(this);
					var b = this.g.ca();
					this.X = b;
					var c = Kb(this);
					this.o = b == 200;
					rb(this.i, this.v, this.B, this.l, this.S, k, b);
					if (this.o) {
						if (this.U && !this.L) {
							b: {
								if (this.g) {
									var d, e = this.g;
									if ((d = e.g ? e.g.getResponseHeader("X-HTTP-Initial-Response") : null) && !y(d)) {
										var f = d;
										break b;
									}
								}
								f = null;
							}
							if (a = f) K(this.i, this.l, a, "Initial handshake response via X-HTTP-Initial-Response"), this.L = !0, Lb(this, a);
							else {
								this.o = !1;
								this.m = 3;
								J(12);
								Q(this);
								Mb(this);
								break a;
							}
						}
						if (this.R) {
							a = !0;
							let r;
							for (; !this.K && this.C < c.length;) if (r = Nb(this, c), r == Bb) {
								k == 4 && (this.m = 4, J(14), a = !1);
								K(this.i, this.l, null, "[Incomplete Response]");
								break;
							} else if (r == Ab) {
								this.m = 4;
								J(15);
								K(this.i, this.l, c, "[Invalid Chunk]");
								a = !1;
								break;
							} else K(this.i, this.l, r, null), Lb(this, r);
							Ob(this) && this.C != 0 && (this.h.g = this.h.g.slice(this.C), this.C = 0);
							k != 4 || c.length != 0 || this.h.h || (this.m = 1, J(16), a = !1);
							this.o = this.o && a;
							if (!a) K(this.i, this.l, c, "[Invalid Chunked Response]"), Q(this), Mb(this);
							else if (c.length > 0 && !this.W) {
								this.W = !0;
								var g = this.j;
								g.g == this && g.aa && !g.P && (g.j.info("Great, no buffering proxy detected. Bytes received: " + c.length), Pb(g), g.P = !0, J(11));
							}
						} else K(this.i, this.l, c, null), Lb(this, c);
						k == 4 && Q(this);
						this.o && !this.K && (k == 4 ? Qb(this.j, this) : (this.o = !1, Fb(this)));
					} else Rb(this.g), b == 400 && c.indexOf("Unknown SID") > 0 ? (this.m = 3, J(12)) : (this.m = 0, J(13)), Q(this), Mb(this);
				}
			}
		} catch (k) {}
	};
	function Kb(a) {
		if (!Ob(a)) return a.g.la();
		const b = Ib(a.g);
		if (b === "") return "";
		let c = "";
		const d = b.length, e = P(a.g) == 4;
		if (!a.h.i) {
			if (typeof TextDecoder === "undefined") return Q(a), Mb(a), "";
			a.h.i = new l.TextDecoder();
		}
		for (let f = 0; f < d; f++) a.h.h = true, c += a.h.i.decode(b[f], { stream: !(e && f == d - 1) });
		b.length = 0;
		a.h.g += c;
		a.C = 0;
		return a.h.g;
	}
	function Ob(a) {
		return a.g ? a.v == "GET" && a.M != 2 && a.j.Aa : false;
	}
	function Nb(a, b) {
		var c = a.C, d = b.indexOf("\n", c);
		if (d == -1) return Bb;
		c = Number(b.substring(c, d));
		if (isNaN(c)) return Ab;
		d += 1;
		if (d + c > b.length) return Bb;
		b = b.slice(d, d + c);
		a.C = d + c;
		return b;
	}
	N.prototype.cancel = function() {
		this.K = true;
		Q(this);
	};
	function Fb(a) {
		a.T = Date.now() + a.H;
		Sb(a, a.H);
	}
	function Sb(a, b) {
		if (a.D != null) throw Error("WatchDog timer not null");
		a.D = ob(p(a.aa, a), b);
	}
	function Jb(a) {
		a.D && (l.clearTimeout(a.D), a.D = null);
	}
	N.prototype.aa = function() {
		this.D = null;
		const a = Date.now();
		a - this.T >= 0 ? (tb(this.i, this.B), this.M != 2 && (lb(), J(17)), Q(this), this.m = 2, Mb(this)) : Sb(this, this.T - a);
	};
	function Mb(a) {
		a.j.I == 0 || a.K || Qb(a.j, a);
	}
	function Q(a) {
		Jb(a);
		var b = a.O;
		b && typeof b.dispose == "function" && b.dispose();
		a.O = null;
		$a(a.V);
		a.g && (b = a.g, a.g = null, b.abort(), b.dispose());
	}
	function Lb(a, b) {
		try {
			var c = a.j;
			if (c.I != 0 && (c.g == a || Tb(c.h, a))) {
				if (!a.L && Tb(c.h, a) && c.I == 3) {
					try {
						var d = c.Ba.g.parse(b);
					} catch (m) {
						d = null;
					}
					if (Array.isArray(d) && d.length == 3) {
						var e = d;
						if (e[0] == 0) {
							a: if (!c.v) {
								if (c.g) if (c.g.F + 3e3 < a.F) Ub(c), Vb(c);
								else break a;
								Wb(c);
								J(18);
							}
						} else c.xa = e[1], 0 < c.xa - c.K && e[2] < 37500 && c.F && c.A == 0 && !c.C && (c.C = ob(p(c.Va, c), 6e3));
						Xb(c.h) <= 1 && c.ta && (c.ta = void 0);
					} else R(c, 11);
				} else if ((a.L || c.g == a) && Ub(c), !y(b)) for (e = c.Ba.g.parse(b), b = 0; b < e.length; b++) {
					let m = e[b];
					const r = m[0];
					if (!(r <= c.K)) if (c.K = r, m = m[1], c.I == 2) if (m[0] == "c") {
						c.M = m[1];
						c.ba = m[2];
						const A = m[3];
						A != null && (c.ka = A, c.j.info("VER=" + c.ka));
						const M = m[4];
						M != null && (c.za = M, c.j.info("SVER=" + c.za));
						const F = m[5];
						F != null && typeof F === "number" && F > 0 && (d = 1.5 * F, c.O = d, c.j.info("backChannelRequestTimeoutMs_=" + d));
						d = c;
						const G = a.g;
						if (G) {
							const za = G.g ? G.g.getResponseHeader("X-Client-Wire-Protocol") : null;
							if (za) {
								var f = d.h;
								f.g || za.indexOf("spdy") == -1 && za.indexOf("quic") == -1 && za.indexOf("h2") == -1 || (f.j = f.l, f.g = /* @__PURE__ */ new Set(), f.h && (Yb(f, f.h), f.h = null));
							}
							if (d.G) {
								const bb = G.g ? G.g.getResponseHeader("X-HTTP-Session-Id") : null;
								bb && (d.wa = bb, S(d.J, d.G, bb));
							}
						}
						c.I = 3;
						c.l && c.l.ra();
						c.aa && (c.T = Date.now() - a.F, c.j.info("Handshake RTT: " + c.T + "ms"));
						d = c;
						var g = a;
						d.na = Zb(d, d.L ? d.ba : null, d.W);
						if (g.L) {
							$b(d.h, g);
							var k = g, q = d.O;
							q && (k.H = q);
							k.D && (Jb(k), Fb(k));
							d.g = g;
						} else ac(d);
						c.i.length > 0 && bc(c);
					} else m[0] != "stop" && m[0] != "close" || R(c, 7);
					else c.I == 3 && (m[0] == "stop" || m[0] == "close" ? m[0] == "stop" ? R(c, 7) : cc(c) : m[0] != "noop" && c.l && c.l.qa(m), c.A = 0);
				}
			}
			lb(4);
		} catch (m) {}
	}
	var dc = class {
		constructor(a, b) {
			this.g = a;
			this.map = b;
		}
	};
	function ec(a) {
		this.l = a || 10;
		l.PerformanceNavigationTiming ? (a = l.performance.getEntriesByType("navigation"), a = a.length > 0 && (a[0].nextHopProtocol == "hq" || a[0].nextHopProtocol == "h2")) : a = !!(l.chrome && l.chrome.loadTimes && l.chrome.loadTimes() && l.chrome.loadTimes().wasFetchedViaSpdy);
		this.j = a ? this.l : 1;
		this.g = null;
		this.j > 1 && (this.g = /* @__PURE__ */ new Set());
		this.h = null;
		this.i = [];
	}
	function fc(a) {
		return a.h ? true : a.g ? a.g.size >= a.j : false;
	}
	function Xb(a) {
		return a.h ? 1 : a.g ? a.g.size : 0;
	}
	function Tb(a, b) {
		return a.h ? a.h == b : a.g ? a.g.has(b) : false;
	}
	function Yb(a, b) {
		a.g ? a.g.add(b) : a.h = b;
	}
	function $b(a, b) {
		a.h && a.h == b ? a.h = null : a.g && a.g.has(b) && a.g.delete(b);
	}
	ec.prototype.cancel = function() {
		this.i = hc(this);
		if (this.h) this.h.cancel(), this.h = null;
		else if (this.g && this.g.size !== 0) {
			for (const a of this.g.values()) a.cancel();
			this.g.clear();
		}
	};
	function hc(a) {
		if (a.h != null) return a.i.concat(a.h.G);
		if (a.g != null && a.g.size !== 0) {
			let b = a.i;
			for (const c of a.g.values()) b = b.concat(c.G);
			return b;
		}
		return ja(a.i);
	}
	var ic = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");
	function jc(a, b) {
		if (a) {
			a = a.split("&");
			for (let c = 0; c < a.length; c++) {
				const d = a[c].indexOf("=");
				let e, f = null;
				d >= 0 ? (e = a[c].substring(0, d), f = a[c].substring(d + 1)) : e = a[c];
				b(e, f ? decodeURIComponent(f.replace(/\+/g, " ")) : "");
			}
		}
	}
	function T(a) {
		this.g = this.o = this.j = "";
		this.u = null;
		this.m = this.h = "";
		this.l = false;
		let b;
		a instanceof T ? (this.l = a.l, kc(this, a.j), this.o = a.o, this.g = a.g, lc(this, a.u), this.h = a.h, mc(this, nc(a.i)), this.m = a.m) : a && (b = String(a).match(ic)) ? (this.l = false, kc(this, b[1] || "", true), this.o = oc(b[2] || ""), this.g = oc(b[3] || "", true), lc(this, b[4]), this.h = oc(b[5] || "", true), mc(this, b[6] || "", true), this.m = oc(b[7] || "")) : (this.l = false, this.i = new pc(null, this.l));
	}
	T.prototype.toString = function() {
		const a = [];
		var b = this.j;
		b && a.push(qc(b, rc, true), ":");
		var c = this.g;
		if (c || b == "file") a.push("//"), (b = this.o) && a.push(qc(b, rc, true), "@"), a.push(L(c).replace(/%25([0-9a-fA-F]{2})/g, "%$1")), c = this.u, c != null && a.push(":", String(c));
		if (c = this.h) this.g && c.charAt(0) != "/" && a.push("/"), a.push(qc(c, c.charAt(0) == "/" ? sc : tc, true));
		(c = this.i.toString()) && a.push("?", c);
		(c = this.m) && a.push("#", qc(c, uc));
		return a.join("");
	};
	T.prototype.resolve = function(a) {
		const b = O(this);
		let c = !!a.j;
		c ? kc(b, a.j) : c = !!a.o;
		c ? b.o = a.o : c = !!a.g;
		c ? b.g = a.g : c = a.u != null;
		var d = a.h;
		if (c) lc(b, a.u);
		else if (c = !!a.h) {
			if (d.charAt(0) != "/") if (this.g && !this.h) d = "/" + d;
			else {
				var e = b.h.lastIndexOf("/");
				e != -1 && (d = b.h.slice(0, e + 1) + d);
			}
			e = d;
			if (e == ".." || e == ".") d = "";
			else if (e.indexOf("./") != -1 || e.indexOf("/.") != -1) {
				d = e.lastIndexOf("/", 0) == 0;
				e = e.split("/");
				const f = [];
				for (let g = 0; g < e.length;) {
					const k = e[g++];
					k == "." ? d && g == e.length && f.push("") : k == ".." ? ((f.length > 1 || f.length == 1 && f[0] != "") && f.pop(), d && g == e.length && f.push("")) : (f.push(k), d = true);
				}
				d = f.join("/");
			} else d = e;
		}
		c ? b.h = d : c = a.i.toString() !== "";
		c ? mc(b, nc(a.i)) : c = !!a.m;
		c && (b.m = a.m);
		return b;
	};
	function O(a) {
		return new T(a);
	}
	function kc(a, b, c) {
		a.j = c ? oc(b, true) : b;
		a.j && (a.j = a.j.replace(/:$/, ""));
	}
	function lc(a, b) {
		if (b) {
			b = Number(b);
			if (isNaN(b) || b < 0) throw Error("Bad port number " + b);
			a.u = b;
		} else a.u = null;
	}
	function mc(a, b, c) {
		b instanceof pc ? (a.i = b, vc(a.i, a.l)) : (c || (b = qc(b, wc)), a.i = new pc(b, a.l));
	}
	function S(a, b, c) {
		a.i.set(b, c);
	}
	function Db(a) {
		S(a, "zx", Math.floor(Math.random() * 2147483648).toString(36) + Math.abs(Math.floor(Math.random() * 2147483648) ^ Date.now()).toString(36));
		return a;
	}
	function oc(a, b) {
		return a ? b ? decodeURI(a.replace(/%25/g, "%2525")) : decodeURIComponent(a) : "";
	}
	function qc(a, b, c) {
		return typeof a === "string" ? (a = encodeURI(a).replace(b, xc), c && (a = a.replace(/%25([0-9a-fA-F]{2})/g, "%$1")), a) : null;
	}
	function xc(a) {
		a = a.charCodeAt(0);
		return "%" + (a >> 4 & 15).toString(16) + (a & 15).toString(16);
	}
	var rc = /[#\/\?@]/g, tc = /[#\?:]/g, sc = /[#\?]/g, wc = /[#\?@]/g, uc = /#/g;
	function pc(a, b) {
		this.h = this.g = null;
		this.i = a || null;
		this.j = !!b;
	}
	function U(a) {
		a.g || (a.g = /* @__PURE__ */ new Map(), a.h = 0, a.i && jc(a.i, function(b, c) {
			a.add(decodeURIComponent(b.replace(/\+/g, " ")), c);
		}));
	}
	h = pc.prototype;
	h.add = function(a, b) {
		U(this);
		this.i = null;
		a = V(this, a);
		let c = this.g.get(a);
		c || this.g.set(a, c = []);
		c.push(b);
		this.h += 1;
		return this;
	};
	function yc(a, b) {
		U(a);
		b = V(a, b);
		a.g.has(b) && (a.i = null, a.h -= a.g.get(b).length, a.g.delete(b));
	}
	function zc(a, b) {
		U(a);
		b = V(a, b);
		return a.g.has(b);
	}
	h.forEach = function(a, b) {
		U(this);
		this.g.forEach(function(c, d) {
			c.forEach(function(e) {
				a.call(b, e, d, this);
			}, this);
		}, this);
	};
	function Ac(a, b) {
		U(a);
		let c = [];
		if (typeof b === "string") zc(a, b) && (c = c.concat(a.g.get(V(a, b))));
		else for (a = Array.from(a.g.values()), b = 0; b < a.length; b++) c = c.concat(a[b]);
		return c;
	}
	h.set = function(a, b) {
		U(this);
		this.i = null;
		a = V(this, a);
		zc(this, a) && (this.h -= this.g.get(a).length);
		this.g.set(a, [b]);
		this.h += 1;
		return this;
	};
	h.get = function(a, b) {
		if (!a) return b;
		a = Ac(this, a);
		return a.length > 0 ? String(a[0]) : b;
	};
	function Gb(a, b, c) {
		yc(a, b);
		c.length > 0 && (a.i = null, a.g.set(V(a, b), ja(c)), a.h += c.length);
	}
	h.toString = function() {
		if (this.i) return this.i;
		if (!this.g) return "";
		const a = [], b = Array.from(this.g.keys());
		for (let d = 0; d < b.length; d++) {
			var c = b[d];
			const e = L(c);
			c = Ac(this, c);
			for (let f = 0; f < c.length; f++) {
				let g = e;
				c[f] !== "" && (g += "=" + L(c[f]));
				a.push(g);
			}
		}
		return this.i = a.join("&");
	};
	function nc(a) {
		const b = new pc();
		b.i = a.i;
		a.g && (b.g = new Map(a.g), b.h = a.h);
		return b;
	}
	function V(a, b) {
		b = String(b);
		a.j && (b = b.toLowerCase());
		return b;
	}
	function vc(a, b) {
		b && !a.j && (U(a), a.i = null, a.g.forEach(function(c, d) {
			const e = d.toLowerCase();
			d != e && (yc(this, d), Gb(this, e, c));
		}, a));
		a.j = b;
	}
	function Bc(a, b) {
		const c = new pb();
		if (l.Image) {
			const d = new Image();
			d.onload = ha(W, c, "TestLoadImage: loaded", true, b, d);
			d.onerror = ha(W, c, "TestLoadImage: error", false, b, d);
			d.onabort = ha(W, c, "TestLoadImage: abort", false, b, d);
			d.ontimeout = ha(W, c, "TestLoadImage: timeout", false, b, d);
			l.setTimeout(function() {
				if (d.ontimeout) d.ontimeout();
			}, 1e4);
			d.src = a;
		} else b(false);
	}
	function Cc(a, b) {
		const c = new pb(), d = new AbortController(), e = setTimeout(() => {
			d.abort();
			W(c, "TestPingServer: timeout", false, b);
		}, 1e4);
		fetch(a, { signal: d.signal }).then((f) => {
			clearTimeout(e);
			f.ok ? W(c, "TestPingServer: ok", true, b) : W(c, "TestPingServer: server error", false, b);
		}).catch(() => {
			clearTimeout(e);
			W(c, "TestPingServer: error", false, b);
		});
	}
	function W(a, b, c, d, e) {
		try {
			e && (e.onload = null, e.onerror = null, e.onabort = null, e.ontimeout = null), d(c);
		} catch (f) {}
	}
	function Dc() {
		this.g = new db();
	}
	function Ec(a) {
		this.i = a.Sb || null;
		this.h = a.ab || false;
	}
	t(Ec, eb);
	Ec.prototype.g = function() {
		return new Fc(this.i, this.h);
	};
	function Fc(a, b) {
		C.call(this);
		this.H = a;
		this.o = b;
		this.m = void 0;
		this.status = this.readyState = 0;
		this.responseType = this.responseText = this.response = this.statusText = "";
		this.onreadystatechange = null;
		this.A = new Headers();
		this.h = null;
		this.F = "GET";
		this.D = "";
		this.g = false;
		this.B = this.j = this.l = null;
		this.v = new AbortController();
	}
	t(Fc, C);
	h = Fc.prototype;
	h.open = function(a, b) {
		if (this.readyState != 0) throw this.abort(), Error("Error reopening a connection");
		this.F = a;
		this.D = b;
		this.readyState = 1;
		Gc(this);
	};
	h.send = function(a) {
		if (this.readyState != 1) throw this.abort(), Error("need to call open() first. ");
		if (this.v.signal.aborted) throw this.abort(), Error("Request was aborted.");
		this.g = true;
		const b = {
			headers: this.A,
			method: this.F,
			credentials: this.m,
			cache: void 0,
			signal: this.v.signal
		};
		a && (b.body = a);
		(this.H || l).fetch(new Request(this.D, b)).then(this.Pa.bind(this), this.ga.bind(this));
	};
	h.abort = function() {
		this.response = this.responseText = "";
		this.A = new Headers();
		this.status = 0;
		this.v.abort();
		this.j && this.j.cancel("Request was aborted.").catch(() => {});
		this.readyState >= 1 && this.g && this.readyState != 4 && (this.g = false, Hc(this));
		this.readyState = 0;
	};
	h.Pa = function(a) {
		if (this.g && (this.l = a, this.h || (this.status = this.l.status, this.statusText = this.l.statusText, this.h = a.headers, this.readyState = 2, Gc(this)), this.g && (this.readyState = 3, Gc(this), this.g))) if (this.responseType === "arraybuffer") a.arrayBuffer().then(this.Na.bind(this), this.ga.bind(this));
		else if (typeof l.ReadableStream !== "undefined" && "body" in a) {
			this.j = a.body.getReader();
			if (this.o) {
				if (this.responseType) throw Error("responseType must be empty for \"streamBinaryChunks\" mode responses.");
				this.response = [];
			} else this.response = this.responseText = "", this.B = new TextDecoder();
			Ic(this);
		} else a.text().then(this.Oa.bind(this), this.ga.bind(this));
	};
	function Ic(a) {
		a.j.read().then(a.Ma.bind(a)).catch(a.ga.bind(a));
	}
	h.Ma = function(a) {
		if (this.g) {
			if (this.o && a.value) this.response.push(a.value);
			else if (!this.o) {
				var b = a.value ? a.value : /* @__PURE__ */ new Uint8Array(0);
				if (b = this.B.decode(b, { stream: !a.done })) this.response = this.responseText += b;
			}
			a.done ? Hc(this) : Gc(this);
			this.readyState == 3 && Ic(this);
		}
	};
	h.Oa = function(a) {
		this.g && (this.response = this.responseText = a, Hc(this));
	};
	h.Na = function(a) {
		this.g && (this.response = a, Hc(this));
	};
	h.ga = function() {
		this.g && Hc(this);
	};
	function Hc(a) {
		a.readyState = 4;
		a.l = null;
		a.j = null;
		a.B = null;
		Gc(a);
	}
	h.setRequestHeader = function(a, b) {
		this.A.append(a, b);
	};
	h.getResponseHeader = function(a) {
		return this.h ? this.h.get(a.toLowerCase()) || "" : "";
	};
	h.getAllResponseHeaders = function() {
		if (!this.h) return "";
		const a = [], b = this.h.entries();
		for (var c = b.next(); !c.done;) c = c.value, a.push(c[0] + ": " + c[1]), c = b.next();
		return a.join("\r\n");
	};
	function Gc(a) {
		a.onreadystatechange && a.onreadystatechange.call(a);
	}
	Object.defineProperty(Fc.prototype, "withCredentials", {
		get: function() {
			return this.m === "include";
		},
		set: function(a) {
			this.m = a ? "include" : "same-origin";
		}
	});
	function Jc(a) {
		let b = "";
		ya(a, function(c, d) {
			b += d;
			b += ":";
			b += c;
			b += "\r\n";
		});
		return b;
	}
	function Kc(a, b, c) {
		a: {
			for (d in c) {
				var d = false;
				break a;
			}
			d = true;
		}
		d || (c = Jc(c), typeof a === "string" || S(a, b, c));
	}
	function X(a) {
		C.call(this);
		this.headers = /* @__PURE__ */ new Map();
		this.L = a || null;
		this.h = false;
		this.g = null;
		this.D = "";
		this.o = 0;
		this.l = "";
		this.j = this.B = this.v = this.A = false;
		this.m = null;
		this.F = "";
		this.H = false;
	}
	t(X, C);
	var Lc = /^https?$/i, Mc = ["POST", "PUT"];
	h = X.prototype;
	h.Fa = function(a) {
		this.H = a;
	};
	h.ea = function(a, b, c, d) {
		if (this.g) throw Error("[goog.net.XhrIo] Object is active with another request=" + this.D + "; newUri=" + a);
		b = b ? b.toUpperCase() : "GET";
		this.D = a;
		this.l = "";
		this.o = 0;
		this.A = false;
		this.h = true;
		this.g = this.L ? this.L.g() : wb.g();
		this.g.onreadystatechange = ia(p(this.Ca, this));
		try {
			this.B = !0, this.g.open(b, String(a), !0), this.B = !1;
		} catch (f) {
			Nc(this, f);
			return;
		}
		a = c || "";
		c = new Map(this.headers);
		if (d) if (Object.getPrototypeOf(d) === Object.prototype) for (var e in d) c.set(e, d[e]);
		else if (typeof d.keys === "function" && typeof d.get === "function") for (const f of d.keys()) c.set(f, d.get(f));
		else throw Error("Unknown input type for opt_headers: " + String(d));
		d = Array.from(c.keys()).find((f) => "content-type" == f.toLowerCase());
		e = l.FormData && a instanceof l.FormData;
		!(Array.prototype.indexOf.call(Mc, b, void 0) >= 0) || d || e || c.set("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
		for (const [f, g] of c) this.g.setRequestHeader(f, g);
		this.F && (this.g.responseType = this.F);
		"withCredentials" in this.g && this.g.withCredentials !== this.H && (this.g.withCredentials = this.H);
		try {
			this.m && (clearTimeout(this.m), this.m = null), this.v = !0, this.g.send(a), this.v = !1;
		} catch (f) {
			Nc(this, f);
		}
	};
	function Nc(a, b) {
		a.h = false;
		a.g && (a.j = true, a.g.abort(), a.j = false);
		a.l = b;
		a.o = 5;
		Oc(a);
		Pc(a);
	}
	function Oc(a) {
		a.A || (a.A = true, D(a, "complete"), D(a, "error"));
	}
	h.abort = function(a) {
		this.g && this.h && (this.h = false, this.j = true, this.g.abort(), this.j = false, this.o = a || 7, D(this, "complete"), D(this, "abort"), Pc(this));
	};
	h.N = function() {
		this.g && (this.h && (this.h = false, this.j = true, this.g.abort(), this.j = false), Pc(this, true));
		X.Z.N.call(this);
	};
	h.Ca = function() {
		this.u || (this.B || this.v || this.j ? Qc(this) : this.Xa());
	};
	h.Xa = function() {
		Qc(this);
	};
	function Qc(a) {
		if (a.h && typeof ea != "undefined") {
			if (a.v && P(a) == 4) setTimeout(a.Ca.bind(a), 0);
			else if (D(a, "readystatechange"), P(a) == 4) {
				a.h = false;
				try {
					const f = a.ca();
					a: switch (f) {
						case 200:
						case 201:
						case 202:
						case 204:
						case 206:
						case 304:
						case 1223:
							var b = !0;
							break a;
						default: b = !1;
					}
					var c;
					if (!(c = b)) {
						var d;
						if (d = f === 0) {
							let g = String(a.D).match(ic)[1] || null;
							!g && l.self && l.self.location && (g = l.self.location.protocol.slice(0, -1));
							d = !Lc.test(g ? g.toLowerCase() : "");
						}
						c = d;
					}
					if (c) D(a, "complete"), D(a, "success");
					else {
						a.o = 6;
						try {
							var e = P(a) > 2 ? a.g.statusText : "";
						} catch (g) {
							e = "";
						}
						a.l = e + " [" + a.ca() + "]";
						Oc(a);
					}
				} finally {
					Pc(a);
				}
			}
		}
	}
	function Pc(a, b) {
		if (a.g) {
			a.m && (clearTimeout(a.m), a.m = null);
			const c = a.g;
			a.g = null;
			b || D(a, "ready");
			try {
				c.onreadystatechange = null;
			} catch (d) {}
		}
	}
	h.isActive = function() {
		return !!this.g;
	};
	function P(a) {
		return a.g ? a.g.readyState : 0;
	}
	h.ca = function() {
		try {
			return P(this) > 2 ? this.g.status : -1;
		} catch (a) {
			return -1;
		}
	};
	h.la = function() {
		try {
			return this.g ? this.g.responseText : "";
		} catch (a) {
			return "";
		}
	};
	h.La = function(a) {
		if (this.g) {
			var b = this.g.responseText;
			a && b.indexOf(a) == 0 && (b = b.substring(a.length));
			return cb(b);
		}
	};
	function Ib(a) {
		try {
			if (!a.g) return null;
			if ("response" in a.g) return a.g.response;
			switch (a.F) {
				case "":
				case "text": return a.g.responseText;
				case "arraybuffer": if ("mozResponseArrayBuffer" in a.g) return a.g.mozResponseArrayBuffer;
			}
			return null;
		} catch (b) {
			return null;
		}
	}
	function Rb(a) {
		const b = {};
		a = (a.g && P(a) >= 2 ? a.g.getAllResponseHeaders() || "" : "").split("\r\n");
		for (let d = 0; d < a.length; d++) {
			if (y(a[d])) continue;
			var c = yb(a[d]);
			const e = c[0];
			c = c[1];
			if (typeof c !== "string") continue;
			c = c.trim();
			const f = b[e] || [];
			b[e] = f;
			f.push(c);
		}
		Aa(b, function(d) {
			return d.join(", ");
		});
	}
	h.ya = function() {
		return this.o;
	};
	h.Ha = function() {
		return typeof this.l === "string" ? this.l : String(this.l);
	};
	function Rc(a, b, c) {
		return c && c.internalChannelParams ? c.internalChannelParams[a] || b : b;
	}
	function Sc(a) {
		this.za = 0;
		this.i = [];
		this.j = new pb();
		this.ba = this.na = this.J = this.W = this.g = this.wa = this.G = this.H = this.u = this.U = this.o = null;
		this.Ya = this.V = 0;
		this.Sa = Rc("failFast", false, a);
		this.F = this.C = this.v = this.m = this.l = null;
		this.X = true;
		this.xa = this.K = -1;
		this.Y = this.A = this.D = 0;
		this.Qa = Rc("baseRetryDelayMs", 5e3, a);
		this.Za = Rc("retryDelaySeedMs", 1e4, a);
		this.Ta = Rc("forwardChannelMaxRetries", 2, a);
		this.va = Rc("forwardChannelRequestTimeoutMs", 2e4, a);
		this.ma = a && a.xmlHttpFactory || void 0;
		this.Ua = a && a.Rb || void 0;
		this.Aa = a && a.useFetchStreams || false;
		this.O = void 0;
		this.L = a && a.supportsCrossDomainXhr || false;
		this.M = "";
		this.h = new ec(a && a.concurrentRequestLimit);
		this.Ba = new Dc();
		this.S = a && a.fastHandshake || false;
		this.R = a && a.encodeInitMessageHeaders || false;
		this.S && this.R && (this.R = false);
		this.Ra = a && a.Pb || false;
		a && a.ua && this.j.ua();
		a && a.forceLongPolling && (this.X = false);
		this.aa = !this.S && this.X && a && a.detectBufferingProxy || false;
		this.ia = void 0;
		a && a.longPollingTimeout && a.longPollingTimeout > 0 && (this.ia = a.longPollingTimeout);
		this.ta = void 0;
		this.T = 0;
		this.P = false;
		this.ja = this.B = null;
	}
	h = Sc.prototype;
	h.ka = 8;
	h.I = 1;
	h.connect = function(a, b, c, d) {
		J(0);
		this.W = a;
		this.H = b || {};
		c && d !== void 0 && (this.H.OSID = c, this.H.OAID = d);
		this.F = this.X;
		this.J = Zb(this, null, this.W);
		bc(this);
	};
	function cc(a) {
		Tc(a);
		if (a.I == 3) {
			var b = a.V++, c = O(a.J);
			S(c, "SID", a.M);
			S(c, "RID", b);
			S(c, "TYPE", "terminate");
			Uc(a, c);
			b = new N(a, a.j, b);
			b.M = 2;
			b.A = Db(O(c));
			c = false;
			if (l.navigator && l.navigator.sendBeacon) try {
				c = l.navigator.sendBeacon(b.A.toString(), "");
			} catch (d) {}
			!c && l.Image && (new Image().src = b.A, c = true);
			c || (b.g = Hb(b.j, null), b.g.ea(b.A));
			b.F = Date.now();
			Fb(b);
		}
		Vc(a);
	}
	function Vb(a) {
		a.g && (Pb(a), a.g.cancel(), a.g = null);
	}
	function Tc(a) {
		Vb(a);
		a.v && (l.clearTimeout(a.v), a.v = null);
		Ub(a);
		a.h.cancel();
		a.m && (typeof a.m === "number" && l.clearTimeout(a.m), a.m = null);
	}
	function bc(a) {
		if (!fc(a.h) && !a.m) {
			a.m = true;
			var b = a.Ea;
			u || ta();
			v || (u(), v = true);
			oa.add(b, a);
			a.D = 0;
		}
	}
	function Wc(a, b) {
		if (Xb(a.h) >= a.h.j - (a.m ? 1 : 0)) return false;
		if (a.m) return a.i = b.G.concat(a.i), true;
		if (a.I == 1 || a.I == 2 || a.D >= (a.Sa ? 0 : a.Ta)) return false;
		a.m = ob(p(a.Ea, a, b), Xc(a, a.D));
		a.D++;
		return true;
	}
	h.Ea = function(a) {
		if (this.m) if (this.m = null, this.I == 1) {
			if (!a) {
				this.V = Math.floor(Math.random() * 1e5);
				a = this.V++;
				const e = new N(this, this.j, a);
				let f = this.o;
				this.U && (f ? (f = Ba(f), Da(f, this.U)) : f = this.U);
				this.u !== null || this.R || (e.J = f, f = null);
				if (this.S) a: {
					var b = 0;
					for (var c = 0; c < this.i.length; c++) {
						b: {
							var d = this.i[c];
							if ("__data__" in d.map && (d = d.map.__data__, typeof d === "string")) {
								d = d.length;
								break b;
							}
							d = void 0;
						}
						if (d === void 0) break;
						b += d;
						if (b > 4096) {
							b = c;
							break a;
						}
						if (b === 4096 || c === this.i.length - 1) {
							b = c + 1;
							break a;
						}
					}
					b = 1e3;
				}
				else b = 1e3;
				b = Yc(this, e, b);
				c = O(this.J);
				S(c, "RID", a);
				S(c, "CVER", 22);
				this.G && S(c, "X-HTTP-Session-Id", this.G);
				Uc(this, c);
				f && (this.R ? b = "headers=" + L(Jc(f)) + "&" + b : this.u && Kc(c, this.u, f));
				Yb(this.h, e);
				this.Ra && S(c, "TYPE", "init");
				this.S ? (S(c, "$req", b), S(c, "SID", "null"), e.U = true, Cb(e, c, null)) : Cb(e, c, b);
				this.I = 2;
			}
		} else this.I == 3 && (a ? Zc(this, a) : this.i.length == 0 || fc(this.h) || Zc(this));
	};
	function Zc(a, b) {
		var c;
		b ? c = b.l : c = a.V++;
		const d = O(a.J);
		S(d, "SID", a.M);
		S(d, "RID", c);
		S(d, "AID", a.K);
		Uc(a, d);
		a.u && a.o && Kc(d, a.u, a.o);
		c = new N(a, a.j, c, a.D + 1);
		a.u === null && (c.J = a.o);
		b && (a.i = b.G.concat(a.i));
		b = Yc(a, c, 1e3);
		c.H = Math.round(a.va * .5) + Math.round(a.va * .5 * Math.random());
		Yb(a.h, c);
		Cb(c, d, b);
	}
	function Uc(a, b) {
		a.H && ya(a.H, function(c, d) {
			S(b, d, c);
		});
		a.l && ya({}, function(c, d) {
			S(b, d, c);
		});
	}
	function Yc(a, b, c) {
		c = Math.min(a.i.length, c);
		const d = a.l ? p(a.l.Ka, a.l, a) : null;
		a: {
			var e = a.i;
			let k = -1;
			for (;;) {
				const q = ["count=" + c];
				k == -1 ? c > 0 ? (k = e[0].g, q.push("ofs=" + k)) : k = 0 : q.push("ofs=" + k);
				let m = true;
				for (let r = 0; r < c; r++) {
					var f = e[r].g;
					const A = e[r].map;
					f -= k;
					if (f < 0) k = Math.max(0, e[r].g - 100), m = false;
					else try {
						f = "req" + f + "_" || "";
						try {
							var g = A instanceof Map ? A : Object.entries(A);
							for (const [M, F] of g) {
								let G = F;
								n(F) && (G = ab(F));
								q.push(f + M + "=" + encodeURIComponent(G));
							}
						} catch (M) {
							throw q.push(f + "type=_badmap"), M;
						}
					} catch (M) {
						d && d(A);
					}
				}
				if (m) {
					g = q.join("&");
					break a;
				}
			}
			g = void 0;
		}
		a = a.i.splice(0, c);
		b.G = a;
		return g;
	}
	function ac(a) {
		if (!a.g && !a.v) {
			a.Y = 1;
			var b = a.Da;
			u || ta();
			v || (u(), v = true);
			oa.add(b, a);
			a.A = 0;
		}
	}
	function Wb(a) {
		if (a.g || a.v || a.A >= 3) return false;
		a.Y++;
		a.v = ob(p(a.Da, a), Xc(a, a.A));
		a.A++;
		return true;
	}
	h.Da = function() {
		this.v = null;
		$c(this);
		if (this.aa && !(this.P || this.g == null || this.T <= 0)) {
			var a = 4 * this.T;
			this.j.info("BP detection timer enabled: " + a);
			this.B = ob(p(this.Wa, this), a);
		}
	};
	h.Wa = function() {
		this.B && (this.B = null, this.j.info("BP detection timeout reached."), this.j.info("Buffering proxy detected and switch to long-polling!"), this.F = false, this.P = true, J(10), Vb(this), $c(this));
	};
	function Pb(a) {
		a.B != null && (l.clearTimeout(a.B), a.B = null);
	}
	function $c(a) {
		a.g = new N(a, a.j, "rpc", a.Y);
		a.u === null && (a.g.J = a.o);
		a.g.P = 0;
		var b = O(a.na);
		S(b, "RID", "rpc");
		S(b, "SID", a.M);
		S(b, "AID", a.K);
		S(b, "CI", a.F ? "0" : "1");
		!a.F && a.ia && S(b, "TO", a.ia);
		S(b, "TYPE", "xmlhttp");
		Uc(a, b);
		a.u && a.o && Kc(b, a.u, a.o);
		a.O && (a.g.H = a.O);
		var c = a.g;
		a = a.ba;
		c.M = 1;
		c.A = Db(O(b));
		c.u = null;
		c.R = true;
		Eb(c, a);
	}
	h.Va = function() {
		this.C != null && (this.C = null, Vb(this), Wb(this), J(19));
	};
	function Ub(a) {
		a.C != null && (l.clearTimeout(a.C), a.C = null);
	}
	function Qb(a, b) {
		var c = null;
		if (a.g == b) {
			Ub(a);
			Pb(a);
			a.g = null;
			var d = 2;
		} else if (Tb(a.h, b)) c = b.G, $b(a.h, b), d = 1;
		else return;
		if (a.I != 0) {
			if (b.o) if (d == 1) {
				c = b.u ? b.u.length : 0;
				b = Date.now() - b.F;
				var e = a.D;
				d = jb();
				D(d, new nb(d, c));
				bc(a);
			} else ac(a);
			else if (e = b.m, e == 3 || e == 0 && b.X > 0 || !(d == 1 && Wc(a, b) || d == 2 && Wb(a))) switch (c && c.length > 0 && (b = a.h, b.i = b.i.concat(c)), e) {
				case 1:
					R(a, 5);
					break;
				case 4:
					R(a, 10);
					break;
				case 3:
					R(a, 6);
					break;
				default: R(a, 2);
			}
		}
	}
	function Xc(a, b) {
		let c = a.Qa + Math.floor(Math.random() * a.Za);
		a.isActive() || (c *= 2);
		return c * b;
	}
	function R(a, b) {
		a.j.info("Error code " + b);
		if (b == 2) {
			var c = p(a.bb, a), d = a.Ua;
			const e = !d;
			d = new T(d || "//www.google.com/images/cleardot.gif");
			l.location && l.location.protocol == "http" || kc(d, "https");
			Db(d);
			e ? Bc(d.toString(), c) : Cc(d.toString(), c);
		} else J(2);
		a.I = 0;
		a.l && a.l.pa(b);
		Vc(a);
		Tc(a);
	}
	h.bb = function(a) {
		a ? (this.j.info("Successfully pinged google.com"), J(2)) : (this.j.info("Failed to ping google.com"), J(1));
	};
	function Vc(a) {
		a.I = 0;
		a.ja = [];
		if (a.l) {
			const b = hc(a.h);
			if (b.length != 0 || a.i.length != 0) ka(a.ja, b), ka(a.ja, a.i), a.h.i.length = 0, ja(a.i), a.i.length = 0;
			a.l.oa();
		}
	}
	function Zb(a, b, c) {
		var d = c instanceof T ? O(c) : new T(c);
		if (d.g != "") b && (d.g = b + "." + d.g), lc(d, d.u);
		else {
			var e = l.location;
			d = e.protocol;
			b = b ? b + "." + e.hostname : e.hostname;
			e = +e.port;
			const f = new T(null);
			d && kc(f, d);
			b && (f.g = b);
			e && lc(f, e);
			c && (f.h = c);
			d = f;
		}
		c = a.G;
		b = a.wa;
		c && b && S(d, c, b);
		S(d, "VER", a.ka);
		Uc(a, d);
		return d;
	}
	function Hb(a, b, c) {
		if (b && !a.L) throw Error("Can't create secondary domain capable XhrIo object.");
		b = a.Aa && !a.ma ? new X(new Ec({ ab: c })) : new X(a.ma);
		b.Fa(a.L);
		return b;
	}
	h.isActive = function() {
		return !!this.l && this.l.isActive(this);
	};
	function ad() {}
	h = ad.prototype;
	h.ra = function() {};
	h.qa = function() {};
	h.pa = function() {};
	h.oa = function() {};
	h.isActive = function() {
		return true;
	};
	h.Ka = function() {};
	function bd() {}
	bd.prototype.g = function(a, b) {
		return new Y(a, b);
	};
	function Y(a, b) {
		C.call(this);
		this.g = new Sc(b);
		this.l = a;
		this.h = b && b.messageUrlParams || null;
		a = b && b.messageHeaders || null;
		b && b.clientProtocolHeaderRequired && (a ? a["X-Client-Protocol"] = "webchannel" : a = { "X-Client-Protocol": "webchannel" });
		this.g.o = a;
		a = b && b.initMessageHeaders || null;
		b && b.messageContentType && (a ? a["X-WebChannel-Content-Type"] = b.messageContentType : a = { "X-WebChannel-Content-Type": b.messageContentType });
		b && b.sa && (a ? a["X-WebChannel-Client-Profile"] = b.sa : a = { "X-WebChannel-Client-Profile": b.sa });
		this.g.U = a;
		(a = b && b.Qb) && !y(a) && (this.g.u = a);
		this.A = b && b.supportsCrossDomainXhr || false;
		this.v = b && b.sendRawJson || false;
		(b = b && b.httpSessionIdParam) && !y(b) && (this.g.G = b, a = this.h, a !== null && b in a && (a = this.h, b in a && delete a[b]));
		this.j = new Z(this);
	}
	t(Y, C);
	Y.prototype.m = function() {
		this.g.l = this.j;
		this.A && (this.g.L = true);
		this.g.connect(this.l, this.h || void 0);
	};
	Y.prototype.close = function() {
		cc(this.g);
	};
	Y.prototype.o = function(a) {
		var b = this.g;
		if (typeof a === "string") {
			var c = {};
			c.__data__ = a;
			a = c;
		} else this.v && (c = {}, c.__data__ = ab(a), a = c);
		b.i.push(new dc(b.Ya++, a));
		b.I == 3 && bc(b);
	};
	Y.prototype.N = function() {
		this.g.l = null;
		delete this.j;
		cc(this.g);
		delete this.g;
		Y.Z.N.call(this);
	};
	function cd(a) {
		gb.call(this);
		a.__headers__ && (this.headers = a.__headers__, this.statusCode = a.__status__, delete a.__headers__, delete a.__status__);
		var b = a.__sm__;
		if (b) {
			a: {
				for (const c in b) {
					a = c;
					break a;
				}
				a = void 0;
			}
			if (this.i = a) a = this.i, b = b !== null && a in b ? b[a] : void 0;
			this.data = b;
		} else this.data = a;
	}
	t(cd, gb);
	function dd() {
		hb.call(this);
		this.status = 1;
	}
	t(dd, hb);
	function Z(a) {
		this.g = a;
	}
	t(Z, ad);
	Z.prototype.ra = function() {
		D(this.g, "a");
	};
	Z.prototype.qa = function(a) {
		D(this.g, new cd(a));
	};
	Z.prototype.pa = function(a) {
		D(this.g, new dd());
	};
	Z.prototype.oa = function() {
		D(this.g, "b");
	};
	bd.prototype.createWebChannel = bd.prototype.g;
	Y.prototype.send = Y.prototype.o;
	Y.prototype.open = Y.prototype.m;
	Y.prototype.close = Y.prototype.close;
	createWebChannelTransport = webchannel_blob_es2018.createWebChannelTransport = function() {
		return new bd();
	};
	getStatEventTarget = webchannel_blob_es2018.getStatEventTarget = function() {
		return jb();
	};
	Event = webchannel_blob_es2018.Event = I;
	Stat = webchannel_blob_es2018.Stat = {
		jb: 0,
		mb: 1,
		nb: 2,
		Hb: 3,
		Mb: 4,
		Jb: 5,
		Kb: 6,
		Ib: 7,
		Gb: 8,
		Lb: 9,
		PROXY: 10,
		NOPROXY: 11,
		Eb: 12,
		Ab: 13,
		Bb: 14,
		zb: 15,
		Cb: 16,
		Db: 17,
		fb: 18,
		eb: 19,
		gb: 20
	};
	ub.NO_ERROR = 0;
	ub.TIMEOUT = 8;
	ub.HTTP_ERROR = 6;
	ErrorCode = webchannel_blob_es2018.ErrorCode = ub;
	vb.COMPLETE = "complete";
	EventType = webchannel_blob_es2018.EventType = vb;
	fb.EventType = H;
	H.OPEN = "a";
	H.CLOSE = "b";
	H.ERROR = "c";
	H.MESSAGE = "d";
	C.prototype.listen = C.prototype.J;
	WebChannel = webchannel_blob_es2018.WebChannel = fb;
	webchannel_blob_es2018.FetchXmlHttpFactory = Ec;
	X.prototype.listenOnce = X.prototype.K;
	X.prototype.getLastError = X.prototype.Ha;
	X.prototype.getLastErrorCode = X.prototype.ya;
	X.prototype.getStatus = X.prototype.ca;
	X.prototype.getResponseJson = X.prototype.La;
	X.prototype.getResponseText = X.prototype.la;
	X.prototype.send = X.prototype.ea;
	X.prototype.setWithCredentials = X.prototype.Fa;
	XhrIo = webchannel_blob_es2018.XhrIo = X;
}).apply(typeof commonjsGlobal !== "undefined" ? commonjsGlobal : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {});
//#endregion
//#region node_modules/firebase/app/dist/esm/index.esm.js
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
registerVersion("firebase", "13.0.0", "app");
//#endregion
//#region node_modules/@firebase/auth/dist/esm/index-LY22yodV.js
/**
* @license
* Copyright 2021 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function _prodErrorMap() {
	return { ["dependent-sdk-initialized-before-auth"]: "Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK." };
}
/**
* A minimal error map with all verbose error messages stripped.
*
* See discussion at {@link AuthErrorMap}
*
* @public
*/
var prodErrorMap = _prodErrorMap;
var _DEFAULT_AUTH_ERROR_FACTORY = new ErrorFactory("auth", "Firebase", _prodErrorMap());
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var logClient = new Logger("@firebase/auth");
function _logWarn(msg, ...args) {
	if (logClient.logLevel <= LogLevel.WARN) logClient.warn(`Auth (${SDK_VERSION}): ${msg}`, ...args);
}
function _logError(msg, ...args) {
	if (logClient.logLevel <= LogLevel.ERROR) logClient.error(`Auth (${SDK_VERSION}): ${msg}`, ...args);
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function _fail(authOrCode, ...rest) {
	throw createErrorInternal(authOrCode, ...rest);
}
function _createError(authOrCode, ...rest) {
	return createErrorInternal(authOrCode, ...rest);
}
function _errorWithCustomMessage(auth, code, message) {
	return new ErrorFactory("auth", "Firebase", {
		...prodErrorMap(),
		[code]: message
	}).create(code, { appName: auth.name });
}
function _serverAppCurrentUserOperationNotSupportedError(auth) {
	return _errorWithCustomMessage(auth, "operation-not-supported-in-this-environment", "Operations that alter the current user are not supported in conjunction with FirebaseServerApp");
}
function _assertInstanceOf(auth, object, instance) {
	const constructorInstance = instance;
	if (!(object instanceof constructorInstance)) {
		if (constructorInstance.name !== object.constructor.name) _fail(auth, "argument-error");
		throw _errorWithCustomMessage(auth, "argument-error", `Type of ${object.constructor.name} does not match expected instance.Did you pass a reference from a different Auth SDK?`);
	}
}
function createErrorInternal(authOrCode, ...rest) {
	if (typeof authOrCode !== "string") {
		const code = rest[0];
		const fullParams = [...rest.slice(1)];
		if (fullParams[0]) fullParams[0].appName = authOrCode.name;
		return authOrCode._errorFactory.create(code, ...fullParams);
	}
	return _DEFAULT_AUTH_ERROR_FACTORY.create(authOrCode, ...rest);
}
function _assert(assertion, authOrCode, ...rest) {
	if (!assertion) throw createErrorInternal(authOrCode, ...rest);
}
/**
* Unconditionally fails, throwing an internal error with the given message.
*
* @param failure type of failure encountered
* @throws Error
*/
function debugFail(failure) {
	const message = `INTERNAL ASSERTION FAILED: ` + failure;
	_logError(message);
	throw new Error(message);
}
/**
* Fails if the given assertion condition is false, throwing an Error with the
* given message if it did.
*
* @param assertion
* @param message
*/
function debugAssert(assertion, message) {
	if (!assertion) debugFail(message);
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function _getCurrentUrl() {
	return typeof self !== "undefined" && self.location?.href || "";
}
function _isHttpOrHttps() {
	return _getCurrentScheme() === "http:" || _getCurrentScheme() === "https:";
}
function _getCurrentScheme() {
	return typeof self !== "undefined" && self.location?.protocol || null;
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Determine whether the browser is working online
*/
function _isOnline() {
	if (typeof navigator !== "undefined" && navigator && "onLine" in navigator && typeof navigator.onLine === "boolean" && (_isHttpOrHttps() || isBrowserExtension() || "connection" in navigator)) return navigator.onLine;
	return true;
}
function _getUserLanguage() {
	if (typeof navigator === "undefined") return null;
	const navigatorLanguage = navigator;
	return navigatorLanguage.languages && navigatorLanguage.languages[0] || navigatorLanguage.language || null;
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* A structure to help pick between a range of long and short delay durations
* depending on the current environment. In general, the long delay is used for
* mobile environments whereas short delays are used for desktop environments.
*/
var Delay = class {
	constructor(shortDelay, longDelay) {
		this.shortDelay = shortDelay;
		this.longDelay = longDelay;
		debugAssert(longDelay > shortDelay, "Short delay should be less than long delay!");
		this.isMobile = isMobileCordova() || isReactNative();
	}
	get() {
		if (!_isOnline()) return Math.min(5e3, this.shortDelay);
		return this.isMobile ? this.longDelay : this.shortDelay;
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function _emulatorUrl(config, path) {
	debugAssert(config.emulator, "Emulator should always be set here");
	const { url } = config.emulator;
	if (!path) return url;
	return `${url}${path.startsWith("/") ? path.slice(1) : path}`;
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var FetchProvider = class {
	static initialize(fetchImpl, headersImpl, responseImpl) {
		this.fetchImpl = fetchImpl;
		if (headersImpl) this.headersImpl = headersImpl;
		if (responseImpl) this.responseImpl = responseImpl;
	}
	static fetch() {
		if (this.fetchImpl) return this.fetchImpl;
		if (typeof self !== "undefined" && "fetch" in self) return self.fetch;
		if (typeof globalThis !== "undefined" && globalThis.fetch) return globalThis.fetch;
		if (typeof fetch !== "undefined") return fetch;
		debugFail("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill");
	}
	static headers() {
		if (this.headersImpl) return this.headersImpl;
		if (typeof self !== "undefined" && "Headers" in self) return self.Headers;
		if (typeof globalThis !== "undefined" && globalThis.Headers) return globalThis.Headers;
		if (typeof Headers !== "undefined") return Headers;
		debugFail("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill");
	}
	static response() {
		if (this.responseImpl) return this.responseImpl;
		if (typeof self !== "undefined" && "Response" in self) return self.Response;
		if (typeof globalThis !== "undefined" && globalThis.Response) return globalThis.Response;
		if (typeof Response !== "undefined") return Response;
		debugFail("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill");
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Map from errors returned by the server to errors to developer visible errors
*/
var SERVER_ERROR_MAP = {
	["CREDENTIAL_MISMATCH"]: "custom-token-mismatch",
	["MISSING_CUSTOM_TOKEN"]: "internal-error",
	["INVALID_IDENTIFIER"]: "invalid-email",
	["MISSING_CONTINUE_URI"]: "internal-error",
	["INVALID_PASSWORD"]: "wrong-password",
	["MISSING_PASSWORD"]: "missing-password",
	["INVALID_LOGIN_CREDENTIALS"]: "invalid-credential",
	["EMAIL_EXISTS"]: "email-already-in-use",
	["PASSWORD_LOGIN_DISABLED"]: "operation-not-allowed",
	["INVALID_IDP_RESPONSE"]: "invalid-credential",
	["INVALID_PENDING_TOKEN"]: "invalid-credential",
	["FEDERATED_USER_ID_ALREADY_LINKED"]: "credential-already-in-use",
	["MISSING_REQ_TYPE"]: "internal-error",
	["EMAIL_NOT_FOUND"]: "user-not-found",
	["RESET_PASSWORD_EXCEED_LIMIT"]: "too-many-requests",
	["EXPIRED_OOB_CODE"]: "expired-action-code",
	["INVALID_OOB_CODE"]: "invalid-action-code",
	["MISSING_OOB_CODE"]: "internal-error",
	["CREDENTIAL_TOO_OLD_LOGIN_AGAIN"]: "requires-recent-login",
	["INVALID_ID_TOKEN"]: "invalid-user-token",
	["TOKEN_EXPIRED"]: "user-token-expired",
	["USER_NOT_FOUND"]: "user-token-expired",
	["TOO_MANY_ATTEMPTS_TRY_LATER"]: "too-many-requests",
	["PASSWORD_DOES_NOT_MEET_REQUIREMENTS"]: "password-does-not-meet-requirements",
	["INVALID_CODE"]: "invalid-verification-code",
	["INVALID_SESSION_INFO"]: "invalid-verification-id",
	["INVALID_TEMPORARY_PROOF"]: "invalid-credential",
	["MISSING_SESSION_INFO"]: "missing-verification-id",
	["SESSION_EXPIRED"]: "code-expired",
	["MISSING_ANDROID_PACKAGE_NAME"]: "missing-android-pkg-name",
	["UNAUTHORIZED_DOMAIN"]: "unauthorized-continue-uri",
	["INVALID_OAUTH_CLIENT_ID"]: "invalid-oauth-client-id",
	["ADMIN_ONLY_OPERATION"]: "admin-restricted-operation",
	["INVALID_MFA_PENDING_CREDENTIAL"]: "invalid-multi-factor-session",
	["MFA_ENROLLMENT_NOT_FOUND"]: "multi-factor-info-not-found",
	["MISSING_MFA_ENROLLMENT_ID"]: "missing-multi-factor-info",
	["MISSING_MFA_PENDING_CREDENTIAL"]: "missing-multi-factor-session",
	["SECOND_FACTOR_EXISTS"]: "second-factor-already-in-use",
	["SECOND_FACTOR_LIMIT_EXCEEDED"]: "maximum-second-factor-count-exceeded",
	["BLOCKING_FUNCTION_ERROR_RESPONSE"]: "internal-error",
	["RECAPTCHA_NOT_ENABLED"]: "recaptcha-not-enabled",
	["MISSING_RECAPTCHA_TOKEN"]: "missing-recaptcha-token",
	["INVALID_RECAPTCHA_TOKEN"]: "invalid-recaptcha-token",
	["INVALID_RECAPTCHA_ACTION"]: "invalid-recaptcha-action",
	["MISSING_CLIENT_TYPE"]: "missing-client-type",
	["MISSING_RECAPTCHA_VERSION"]: "missing-recaptcha-version",
	["INVALID_RECAPTCHA_VERSION"]: "invalid-recaptcha-version",
	["INVALID_REQ_TYPE"]: "invalid-req-type"
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var CookieAuthProxiedEndpoints = [
	"/v1/accounts:signInWithCustomToken",
	"/v1/accounts:signInWithEmailLink",
	"/v1/accounts:signInWithIdp",
	"/v1/accounts:signInWithPassword",
	"/v1/accounts:signInWithPhoneNumber",
	"/v1/token"
];
var DEFAULT_API_TIMEOUT_MS = new Delay(3e4, 6e4);
function _addTidIfNecessary(auth, request) {
	if (auth.tenantId && !request.tenantId) return {
		...request,
		tenantId: auth.tenantId
	};
	return request;
}
async function _performApiRequest(auth, method, path, request, customErrorMap = {}) {
	return _performFetchWithErrorHandling(auth, customErrorMap, async () => {
		let body = {};
		let params = {};
		if (request) {
			if (method === "GET") params = request;
			else body = { body: JSON.stringify(request) };
		}
		const query = querystring({
			...params,
			key: auth.config.apiKey
		}).slice(1);
		const headers = await auth._getAdditionalHeaders();
		headers["Content-Type"] = "application/json";
		if (auth.languageCode) headers["X-Firebase-Locale"] = auth.languageCode;
		const fetchArgs = {
			method,
			headers,
			...body
		};
		if (!isCloudflareWorker()) fetchArgs.referrerPolicy = "strict-origin-when-cross-origin";
		if (auth.emulatorConfig && isCloudWorkstation(auth.emulatorConfig.host)) fetchArgs.credentials = "include";
		return FetchProvider.fetch()(await _getFinalTarget(auth, auth.config.apiHost, path, query), fetchArgs);
	});
}
async function _performFetchWithErrorHandling(auth, customErrorMap, fetchFn) {
	auth._canInitEmulator = false;
	const errorMap = {
		...SERVER_ERROR_MAP,
		...customErrorMap
	};
	try {
		const networkTimeout = new NetworkTimeout(auth);
		const response = await Promise.race([fetchFn(), networkTimeout.promise]);
		networkTimeout.clearNetworkTimeout();
		const json = await response.json();
		if ("needConfirmation" in json) throw _makeTaggedError(auth, "account-exists-with-different-credential", json);
		if (response.ok && !("errorMessage" in json)) return json;
		else {
			const [serverErrorCode, serverErrorMessage] = (response.ok ? json.errorMessage : json.error.message).split(" : ");
			if (serverErrorCode === "FEDERATED_USER_ID_ALREADY_LINKED") throw _makeTaggedError(auth, "credential-already-in-use", json);
			else if (serverErrorCode === "EMAIL_EXISTS") throw _makeTaggedError(auth, "email-already-in-use", json);
			else if (serverErrorCode === "USER_DISABLED") throw _makeTaggedError(auth, "user-disabled", json);
			const authError = errorMap[serverErrorCode] || serverErrorCode.toLowerCase().replace(/[_\s]+/g, "-");
			if (serverErrorMessage) throw _errorWithCustomMessage(auth, authError, serverErrorMessage);
			else _fail(auth, authError);
		}
	} catch (e) {
		if (e instanceof FirebaseError) throw e;
		_fail(auth, "network-request-failed", { "message": String(e) });
	}
}
async function _performSignInRequest(auth, method, path, request, customErrorMap = {}) {
	const serverResponse = await _performApiRequest(auth, method, path, request, customErrorMap);
	if ("mfaPendingCredential" in serverResponse) _fail(auth, "multi-factor-auth-required", { _serverResponse: serverResponse });
	return serverResponse;
}
async function _getFinalTarget(auth, host, path, query) {
	const base = `${host}${path}?${query}`;
	const authInternal = auth;
	const finalTarget = authInternal.config.emulator ? _emulatorUrl(auth.config, base) : `${auth.config.apiScheme}://${base}`;
	if (CookieAuthProxiedEndpoints.includes(path)) {
		await authInternal._persistenceManagerAvailable;
		if (authInternal._getPersistenceType() === "COOKIE") return authInternal._getPersistence()._getFinalTarget(finalTarget).toString();
	}
	return finalTarget;
}
function _parseEnforcementState(enforcementStateStr) {
	switch (enforcementStateStr) {
		case "ENFORCE": return "ENFORCE";
		case "AUDIT": return "AUDIT";
		case "OFF": return "OFF";
		default: return "ENFORCEMENT_STATE_UNSPECIFIED";
	}
}
var NetworkTimeout = class {
	clearNetworkTimeout() {
		clearTimeout(this.timer);
	}
	constructor(auth) {
		this.auth = auth;
		this.timer = null;
		this.promise = new Promise((_, reject) => {
			this.timer = setTimeout(() => {
				return reject(_createError(this.auth, "network-request-failed"));
			}, DEFAULT_API_TIMEOUT_MS.get());
		});
	}
};
function _makeTaggedError(auth, code, response) {
	const errorParams = { appName: auth.name };
	if (response.email) errorParams.email = response.email;
	if (response.phoneNumber) errorParams.phoneNumber = response.phoneNumber;
	const error = _createError(auth, code, errorParams);
	error.customData._tokenResponse = response;
	return error;
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function isEnterprise(grecaptcha) {
	return grecaptcha !== void 0 && grecaptcha.enterprise !== void 0;
}
var RecaptchaConfig = class {
	constructor(response) {
		/**
		* The reCAPTCHA site key.
		*/
		this.siteKey = "";
		/**
		* The list of providers and their enablement status for reCAPTCHA Enterprise.
		*/
		this.recaptchaEnforcementState = [];
		if (response.recaptchaKey === void 0) throw new Error("recaptchaKey undefined");
		this.siteKey = response.recaptchaKey.split("/")[3];
		this.recaptchaEnforcementState = response.recaptchaEnforcementState;
	}
	/**
	* Returns the reCAPTCHA Enterprise enforcement state for the given provider.
	*
	* @param providerStr - The provider whose enforcement state is to be returned.
	* @returns The reCAPTCHA Enterprise enforcement state for the given provider.
	*/
	getProviderEnforcementState(providerStr) {
		if (!this.recaptchaEnforcementState || this.recaptchaEnforcementState.length === 0) return null;
		for (const recaptchaEnforcementState of this.recaptchaEnforcementState) if (recaptchaEnforcementState.provider && recaptchaEnforcementState.provider === providerStr) return _parseEnforcementState(recaptchaEnforcementState.enforcementState);
		return null;
	}
	/**
	* Returns true if the reCAPTCHA Enterprise enforcement state for the provider is set to ENFORCE or AUDIT.
	*
	* @param providerStr - The provider whose enablement state is to be returned.
	* @returns Whether or not reCAPTCHA Enterprise protection is enabled for the given provider.
	*/
	isProviderEnabled(providerStr) {
		return this.getProviderEnforcementState(providerStr) === "ENFORCE" || this.getProviderEnforcementState(providerStr) === "AUDIT";
	}
	/**
	* Returns true if reCAPTCHA Enterprise protection is enabled in at least one provider, otherwise
	* returns false.
	*
	* @returns Whether or not reCAPTCHA Enterprise protection is enabled for at least one provider.
	*/
	isAnyProviderEnabled() {
		return this.isProviderEnabled("EMAIL_PASSWORD_PROVIDER") || this.isProviderEnabled("PHONE_PROVIDER");
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
async function getRecaptchaConfig(auth, request) {
	return _performApiRequest(auth, "GET", "/v2/recaptchaConfig", _addTidIfNecessary(auth, request));
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
async function deleteAccount(auth, request) {
	return _performApiRequest(auth, "POST", "/v1/accounts:delete", request);
}
async function getAccountInfo(auth, request) {
	return _performApiRequest(auth, "POST", "/v1/accounts:lookup", request);
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function utcTimestampToDateString(utcTimestamp) {
	if (!utcTimestamp) return;
	try {
		const date = new Date(Number(utcTimestamp));
		if (!isNaN(date.getTime())) return date.toUTCString();
	} catch (e) {}
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Returns a deserialized JSON Web Token (JWT) used to identify the user to a Firebase service.
*
* @remarks
* Returns the current token if it has not expired or if it will not expire in the next five
* minutes. Otherwise, this will refresh the token and return a new one.
*
* @param user - The user.
* @param forceRefresh - Force refresh regardless of token expiration.
*
* @public
*/
async function getIdTokenResult(user, forceRefresh = false) {
	const userInternal = getModularInstance(user);
	const token = await userInternal.getIdToken(forceRefresh);
	const claims = _parseToken(token);
	_assert(claims && claims.exp && claims.auth_time && claims.iat, userInternal.auth, "internal-error");
	const firebase = typeof claims.firebase === "object" ? claims.firebase : void 0;
	const signInProvider = firebase?.["sign_in_provider"];
	return {
		claims,
		token,
		authTime: utcTimestampToDateString(secondsStringToMilliseconds(claims.auth_time)),
		issuedAtTime: utcTimestampToDateString(secondsStringToMilliseconds(claims.iat)),
		expirationTime: utcTimestampToDateString(secondsStringToMilliseconds(claims.exp)),
		signInProvider: signInProvider || null,
		signInSecondFactor: firebase?.["sign_in_second_factor"] || null
	};
}
function secondsStringToMilliseconds(seconds) {
	return Number(seconds) * 1e3;
}
function _parseToken(token) {
	const [algorithm, payload, signature] = token.split(".");
	if (algorithm === void 0 || payload === void 0 || signature === void 0) {
		_logError("JWT malformed, contained fewer than 3 sections");
		return null;
	}
	try {
		const decoded = base64Decode(payload);
		if (!decoded) {
			_logError("Failed to decode base64 JWT payload");
			return null;
		}
		return JSON.parse(decoded);
	} catch (e) {
		_logError("Caught error parsing JWT payload as JSON", e?.toString());
		return null;
	}
}
/**
* Extract expiresIn TTL from a token by subtracting the expiration from the issuance.
*/
function _tokenExpiresIn(token) {
	const parsedToken = _parseToken(token);
	_assert(parsedToken, "internal-error");
	_assert(typeof parsedToken.exp !== "undefined", "internal-error");
	_assert(typeof parsedToken.iat !== "undefined", "internal-error");
	return Number(parsedToken.exp) - Number(parsedToken.iat);
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
async function _logoutIfInvalidated(user, promise, bypassAuthState = false) {
	if (bypassAuthState) return promise;
	try {
		return await promise;
	} catch (e) {
		if (e instanceof FirebaseError && isUserInvalidated(e)) {
			if (user.auth.currentUser === user) await user.auth.signOut();
		}
		throw e;
	}
}
function isUserInvalidated({ code }) {
	return code === `auth/user-disabled` || code === `auth/user-token-expired`;
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var ProactiveRefresh = class {
	constructor(user) {
		this.user = user;
		this.isRunning = false;
		this.timerId = null;
		this.errorBackoff = 3e4;
	}
	_start() {
		if (this.isRunning) return;
		this.isRunning = true;
		this.schedule();
	}
	_stop() {
		if (!this.isRunning) return;
		this.isRunning = false;
		if (this.timerId !== null) clearTimeout(this.timerId);
	}
	getInterval(wasError) {
		if (wasError) {
			const interval = this.errorBackoff;
			this.errorBackoff = Math.min(this.errorBackoff * 2, 96e4);
			return interval;
		} else {
			this.errorBackoff = 3e4;
			const interval = (this.user.stsTokenManager.expirationTime ?? 0) - Date.now() - 3e5;
			return Math.max(0, interval);
		}
	}
	schedule(wasError = false) {
		if (!this.isRunning) return;
		const interval = this.getInterval(wasError);
		this.timerId = setTimeout(async () => {
			await this.iteration();
		}, interval);
	}
	async iteration() {
		try {
			await this.user.getIdToken(true);
		} catch (e) {
			if (e?.code === `auth/network-request-failed`) this.schedule(true);
			return;
		}
		this.schedule();
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var UserMetadata = class {
	constructor(createdAt, lastLoginAt) {
		this.createdAt = createdAt;
		this.lastLoginAt = lastLoginAt;
		this._initializeTime();
	}
	_initializeTime() {
		this.lastSignInTime = utcTimestampToDateString(this.lastLoginAt);
		this.creationTime = utcTimestampToDateString(this.createdAt);
	}
	_copy(metadata) {
		this.createdAt = metadata.createdAt;
		this.lastLoginAt = metadata.lastLoginAt;
		this._initializeTime();
	}
	toJSON() {
		return {
			createdAt: this.createdAt,
			lastLoginAt: this.lastLoginAt
		};
	}
};
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
async function _reloadWithoutSaving(user) {
	const auth = user.auth;
	const response = await _logoutIfInvalidated(user, getAccountInfo(auth, { idToken: await user.getIdToken() }));
	_assert(response?.users.length, auth, "internal-error");
	const coreAccount = response.users[0];
	user._notifyReloadListener(coreAccount);
	const newProviderData = coreAccount.providerUserInfo?.length ? extractProviderData(coreAccount.providerUserInfo) : [];
	const providerData = mergeProviderData(user.providerData, newProviderData);
	const oldIsAnonymous = user.isAnonymous;
	const newIsAnonymous = !(user.email && coreAccount.passwordHash) && !providerData?.length;
	const isAnonymous = !oldIsAnonymous ? false : newIsAnonymous;
	const updates = {
		uid: coreAccount.localId,
		displayName: coreAccount.displayName || null,
		photoURL: coreAccount.photoUrl || null,
		email: coreAccount.email || null,
		emailVerified: coreAccount.emailVerified || false,
		phoneNumber: coreAccount.phoneNumber || null,
		tenantId: coreAccount.tenantId || null,
		providerData,
		metadata: new UserMetadata(coreAccount.createdAt, coreAccount.lastLoginAt),
		isAnonymous
	};
	Object.assign(user, updates);
}
/**
* Reloads user account data, if signed in.
*
* @param user - The user.
*
* @public
*/
async function reload(user) {
	const userInternal = getModularInstance(user);
	await _reloadWithoutSaving(userInternal);
	await userInternal.auth._persistUserIfCurrent(userInternal);
	userInternal.auth._notifyListenersIfCurrent(userInternal);
}
function mergeProviderData(original, newData) {
	return [...original.filter((o) => !newData.some((n) => n.providerId === o.providerId)), ...newData];
}
function extractProviderData(providers) {
	return providers.map(({ providerId, ...provider }) => {
		return {
			providerId,
			uid: provider.rawId || "",
			displayName: provider.displayName || null,
			email: provider.email || null,
			phoneNumber: provider.phoneNumber || null,
			photoURL: provider.photoUrl || null
		};
	});
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
async function requestStsToken(auth, refreshToken) {
	const response = await _performFetchWithErrorHandling(auth, {}, async () => {
		const body = querystring({
			"grant_type": "refresh_token",
			"refresh_token": refreshToken
		}).slice(1);
		const { tokenApiHost, apiKey } = auth.config;
		const url = await _getFinalTarget(auth, tokenApiHost, "/v1/token", `key=${apiKey}`);
		const headers = await auth._getAdditionalHeaders();
		headers["Content-Type"] = "application/x-www-form-urlencoded";
		const options = {
			method: "POST",
			headers,
			body
		};
		if (auth.emulatorConfig && isCloudWorkstation(auth.emulatorConfig.host)) options.credentials = "include";
		return FetchProvider.fetch()(url, options);
	});
	return {
		accessToken: response.access_token,
		expiresIn: response.expires_in,
		refreshToken: response.refresh_token
	};
}
async function revokeToken(auth, request) {
	return _performApiRequest(auth, "POST", "/v2/accounts:revokeToken", _addTidIfNecessary(auth, request));
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* We need to mark this class as internal explicitly to exclude it in the public typings, because
* it references AuthInternal which has a circular dependency with UserInternal.
*
* @internal
*/
var StsTokenManager = class StsTokenManager {
	constructor() {
		this.refreshToken = null;
		this.accessToken = null;
		this.expirationTime = null;
	}
	get isExpired() {
		return !this.expirationTime || Date.now() > this.expirationTime - 3e4;
	}
	updateFromServerResponse(response) {
		_assert(response.idToken, "internal-error");
		_assert(typeof response.idToken !== "undefined", "internal-error");
		_assert(typeof response.refreshToken !== "undefined", "internal-error");
		const expiresIn = "expiresIn" in response && typeof response.expiresIn !== "undefined" ? Number(response.expiresIn) : _tokenExpiresIn(response.idToken);
		this.updateTokensAndExpiration(response.idToken, response.refreshToken, expiresIn);
	}
	updateFromIdToken(idToken) {
		_assert(idToken.length !== 0, "internal-error");
		const expiresIn = _tokenExpiresIn(idToken);
		this.updateTokensAndExpiration(idToken, null, expiresIn);
	}
	async getToken(auth, forceRefresh = false) {
		if (!forceRefresh && this.accessToken && !this.isExpired) return this.accessToken;
		_assert(this.refreshToken, auth, "user-token-expired");
		if (this.refreshToken) {
			await this.refresh(auth, this.refreshToken);
			return this.accessToken;
		}
		return null;
	}
	clearRefreshToken() {
		this.refreshToken = null;
	}
	async refresh(auth, oldToken) {
		const { accessToken, refreshToken, expiresIn } = await requestStsToken(auth, oldToken);
		this.updateTokensAndExpiration(accessToken, refreshToken, Number(expiresIn));
	}
	updateTokensAndExpiration(accessToken, refreshToken, expiresInSec) {
		this.refreshToken = refreshToken || null;
		this.accessToken = accessToken || null;
		this.expirationTime = Date.now() + expiresInSec * 1e3;
	}
	static fromJSON(appName, object) {
		const { refreshToken, accessToken, expirationTime } = object;
		const manager = new StsTokenManager();
		if (refreshToken) {
			_assert(typeof refreshToken === "string", "internal-error", { appName });
			manager.refreshToken = refreshToken;
		}
		if (accessToken) {
			_assert(typeof accessToken === "string", "internal-error", { appName });
			manager.accessToken = accessToken;
		}
		if (expirationTime) {
			_assert(typeof expirationTime === "number", "internal-error", { appName });
			manager.expirationTime = expirationTime;
		}
		return manager;
	}
	toJSON() {
		return {
			refreshToken: this.refreshToken,
			accessToken: this.accessToken,
			expirationTime: this.expirationTime
		};
	}
	_assign(stsTokenManager) {
		this.accessToken = stsTokenManager.accessToken;
		this.refreshToken = stsTokenManager.refreshToken;
		this.expirationTime = stsTokenManager.expirationTime;
	}
	_clone() {
		return Object.assign(new StsTokenManager(), this.toJSON());
	}
	_performRefresh() {
		return debugFail("not implemented");
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function assertStringOrUndefined(assertion, appName) {
	_assert(typeof assertion === "string" || typeof assertion === "undefined", "internal-error", { appName });
}
var UserImpl = class UserImpl {
	constructor({ uid, auth, stsTokenManager, ...opt }) {
		this.providerId = "firebase";
		this.proactiveRefresh = new ProactiveRefresh(this);
		this.reloadUserInfo = null;
		this.reloadListener = null;
		this.uid = uid;
		this.auth = auth;
		this.stsTokenManager = stsTokenManager;
		this.accessToken = stsTokenManager.accessToken;
		this.displayName = opt.displayName || null;
		this.email = opt.email || null;
		this.emailVerified = opt.emailVerified || false;
		this.phoneNumber = opt.phoneNumber || null;
		this.photoURL = opt.photoURL || null;
		this.isAnonymous = opt.isAnonymous || false;
		this.tenantId = opt.tenantId || null;
		this.providerData = opt.providerData ? [...opt.providerData] : [];
		this.metadata = new UserMetadata(opt.createdAt || void 0, opt.lastLoginAt || void 0);
	}
	async getIdToken(forceRefresh) {
		const accessToken = await _logoutIfInvalidated(this, this.stsTokenManager.getToken(this.auth, forceRefresh));
		_assert(accessToken, this.auth, "internal-error");
		if (this.accessToken !== accessToken) {
			this.accessToken = accessToken;
			await this.auth._persistUserIfCurrent(this);
			this.auth._notifyListenersIfCurrent(this);
		}
		return accessToken;
	}
	getIdTokenResult(forceRefresh) {
		return getIdTokenResult(this, forceRefresh);
	}
	reload() {
		return reload(this);
	}
	_assign(user) {
		if (this === user) return;
		_assert(this.uid === user.uid, this.auth, "internal-error");
		this.displayName = user.displayName;
		this.photoURL = user.photoURL;
		this.email = user.email;
		this.emailVerified = user.emailVerified;
		this.phoneNumber = user.phoneNumber;
		this.isAnonymous = user.isAnonymous;
		this.tenantId = user.tenantId;
		this.providerData = user.providerData.map((userInfo) => ({ ...userInfo }));
		this.metadata._copy(user.metadata);
		this.stsTokenManager._assign(user.stsTokenManager);
	}
	_clone(auth) {
		const newUser = new UserImpl({
			...this,
			auth,
			stsTokenManager: this.stsTokenManager._clone()
		});
		newUser.metadata._copy(this.metadata);
		return newUser;
	}
	_onReload(callback) {
		_assert(!this.reloadListener, this.auth, "internal-error");
		this.reloadListener = callback;
		if (this.reloadUserInfo) {
			this._notifyReloadListener(this.reloadUserInfo);
			this.reloadUserInfo = null;
		}
	}
	_notifyReloadListener(userInfo) {
		if (this.reloadListener) this.reloadListener(userInfo);
		else this.reloadUserInfo = userInfo;
	}
	_startProactiveRefresh() {
		this.proactiveRefresh._start();
	}
	_stopProactiveRefresh() {
		this.proactiveRefresh._stop();
	}
	async _updateTokensIfNecessary(response, reload = false) {
		let tokensRefreshed = false;
		if (response.idToken && response.idToken !== this.stsTokenManager.accessToken) {
			this.stsTokenManager.updateFromServerResponse(response);
			tokensRefreshed = true;
		}
		if (reload) await _reloadWithoutSaving(this);
		await this.auth._persistUserIfCurrent(this);
		if (tokensRefreshed) this.auth._notifyListenersIfCurrent(this);
	}
	async delete() {
		if (_isFirebaseServerApp(this.auth.app)) return Promise.reject(_serverAppCurrentUserOperationNotSupportedError(this.auth));
		const idToken = await this.getIdToken();
		await _logoutIfInvalidated(this, deleteAccount(this.auth, { idToken }));
		this.stsTokenManager.clearRefreshToken();
		return this.auth.signOut();
	}
	toJSON() {
		return {
			uid: this.uid,
			email: this.email || void 0,
			emailVerified: this.emailVerified,
			displayName: this.displayName || void 0,
			isAnonymous: this.isAnonymous,
			photoURL: this.photoURL || void 0,
			phoneNumber: this.phoneNumber || void 0,
			tenantId: this.tenantId || void 0,
			providerData: this.providerData.map((userInfo) => ({ ...userInfo })),
			stsTokenManager: this.stsTokenManager.toJSON(),
			_redirectEventId: this._redirectEventId,
			...this.metadata.toJSON(),
			apiKey: this.auth.config.apiKey,
			appName: this.auth.name
		};
	}
	get refreshToken() {
		return this.stsTokenManager.refreshToken || "";
	}
	static _fromJSON(auth, object) {
		const displayName = object.displayName ?? void 0;
		const email = object.email ?? void 0;
		const phoneNumber = object.phoneNumber ?? void 0;
		const photoURL = object.photoURL ?? void 0;
		const tenantId = object.tenantId ?? void 0;
		const _redirectEventId = object._redirectEventId ?? void 0;
		const createdAt = object.createdAt ?? void 0;
		const lastLoginAt = object.lastLoginAt ?? void 0;
		const { uid, emailVerified, isAnonymous, providerData, stsTokenManager: plainObjectTokenManager } = object;
		_assert(uid && plainObjectTokenManager, auth, "internal-error");
		const stsTokenManager = StsTokenManager.fromJSON(this.name, plainObjectTokenManager);
		_assert(typeof uid === "string", auth, "internal-error");
		assertStringOrUndefined(displayName, auth.name);
		assertStringOrUndefined(email, auth.name);
		_assert(typeof emailVerified === "boolean", auth, "internal-error");
		_assert(typeof isAnonymous === "boolean", auth, "internal-error");
		assertStringOrUndefined(phoneNumber, auth.name);
		assertStringOrUndefined(photoURL, auth.name);
		assertStringOrUndefined(tenantId, auth.name);
		assertStringOrUndefined(_redirectEventId, auth.name);
		assertStringOrUndefined(createdAt, auth.name);
		assertStringOrUndefined(lastLoginAt, auth.name);
		const user = new UserImpl({
			uid,
			auth,
			email,
			emailVerified,
			displayName,
			isAnonymous,
			photoURL,
			phoneNumber,
			tenantId,
			stsTokenManager,
			createdAt,
			lastLoginAt
		});
		if (providerData && Array.isArray(providerData)) user.providerData = providerData.map((userInfo) => ({ ...userInfo }));
		if (_redirectEventId) user._redirectEventId = _redirectEventId;
		return user;
	}
	/**
	* Initialize a User from an idToken server response
	* @param auth
	* @param idTokenResponse
	*/
	static async _fromIdTokenResponse(auth, idTokenResponse, isAnonymous = false) {
		const stsTokenManager = new StsTokenManager();
		stsTokenManager.updateFromServerResponse(idTokenResponse);
		const user = new UserImpl({
			uid: idTokenResponse.localId,
			auth,
			stsTokenManager,
			isAnonymous
		});
		await _reloadWithoutSaving(user);
		return user;
	}
	/**
	* Initialize a User from an idToken server response
	* @param auth
	* @param idTokenResponse
	*/
	static async _fromGetAccountInfoResponse(auth, response, idToken) {
		const coreAccount = response.users[0];
		_assert(coreAccount.localId !== void 0, "internal-error");
		const providerData = coreAccount.providerUserInfo !== void 0 ? extractProviderData(coreAccount.providerUserInfo) : [];
		const isAnonymous = !(coreAccount.email && coreAccount.passwordHash) && !providerData?.length;
		const stsTokenManager = new StsTokenManager();
		stsTokenManager.updateFromIdToken(idToken);
		const user = new UserImpl({
			uid: coreAccount.localId,
			auth,
			stsTokenManager,
			isAnonymous
		});
		const updates = {
			uid: coreAccount.localId,
			displayName: coreAccount.displayName || null,
			photoURL: coreAccount.photoUrl || null,
			email: coreAccount.email || null,
			emailVerified: coreAccount.emailVerified || false,
			phoneNumber: coreAccount.phoneNumber || null,
			tenantId: coreAccount.tenantId || null,
			providerData,
			metadata: new UserMetadata(coreAccount.createdAt, coreAccount.lastLoginAt),
			isAnonymous: !(coreAccount.email && coreAccount.passwordHash) && !providerData?.length
		};
		Object.assign(user, updates);
		return user;
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var instanceCache = /* @__PURE__ */ new Map();
function _getInstance(cls) {
	debugAssert(cls instanceof Function, "Expected a class definition");
	let instance = instanceCache.get(cls);
	if (instance) {
		debugAssert(instance instanceof cls, "Instance stored in cache mismatched with class");
		return instance;
	}
	instance = new cls();
	instanceCache.set(cls, instance);
	return instance;
}
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var InMemoryPersistence = class {
	constructor() {
		this.type = "NONE";
		this.storage = {};
	}
	async _isAvailable() {
		return true;
	}
	async _set(key, value) {
		this.storage[key] = value;
	}
	async _get(key) {
		const value = this.storage[key];
		return value === void 0 ? null : value;
	}
	async _remove(key) {
		delete this.storage[key];
	}
	_addListener(_key, _listener) {}
	_removeListener(_key, _listener) {}
};
InMemoryPersistence.type = "NONE";
/**
* An implementation of {@link Persistence} of type 'NONE'.
*
* @public
*/
var inMemoryPersistence = InMemoryPersistence;
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function _persistenceKeyName(key, apiKey, appName) {
	return `firebase:${key}:${apiKey}:${appName}`;
}
var PersistenceUserManager = class PersistenceUserManager {
	constructor(persistence, auth, userKey) {
		this.persistence = persistence;
		this.auth = auth;
		this.userKey = userKey;
		const { config, name } = this.auth;
		this.fullUserKey = _persistenceKeyName(this.userKey, config.apiKey, name);
		this.fullPersistenceKey = _persistenceKeyName("persistence", config.apiKey, name);
		this.boundEventHandler = auth._onStorageEvent.bind(auth);
		try {
			this.persistence._addListener(this.fullUserKey, this.boundEventHandler);
		} catch {}
	}
	setCurrentUser(user) {
		return this.persistence._set(this.fullUserKey, user.toJSON());
	}
	async getCurrentUser() {
		const blob = await this.persistence._get(this.fullUserKey);
		if (!blob) return null;
		if (typeof blob === "string") {
			const response = await getAccountInfo(this.auth, { idToken: blob }).catch(() => void 0);
			if (!response) return null;
			return UserImpl._fromGetAccountInfoResponse(this.auth, response, blob);
		}
		return UserImpl._fromJSON(this.auth, blob);
	}
	removeCurrentUser() {
		return this.persistence._remove(this.fullUserKey);
	}
	savePersistenceForRedirect() {
		return this.persistence._set(this.fullPersistenceKey, this.persistence.type);
	}
	async setPersistence(newPersistence) {
		if (this.persistence === newPersistence) return;
		const currentUser = await this.getCurrentUser();
		await this.removeCurrentUser();
		this.persistence = newPersistence;
		if (currentUser) return this.setCurrentUser(currentUser);
	}
	delete() {
		try {
			this.persistence._removeListener(this.fullUserKey, this.boundEventHandler);
		} catch {}
	}
	static async create(auth, persistenceHierarchy, userKey = "authUser") {
		if (!persistenceHierarchy.length) return new PersistenceUserManager(_getInstance(inMemoryPersistence), auth, userKey);
		const availablePersistences = (await Promise.all(persistenceHierarchy.map(async (persistence) => {
			try {
				if (await persistence._isAvailable()) return persistence;
			} catch {
				return;
			}
		}))).filter((persistence) => persistence);
		let selectedPersistence = availablePersistences[0] || _getInstance(inMemoryPersistence);
		const key = _persistenceKeyName(userKey, auth.config.apiKey, auth.name);
		let userToMigrate = null;
		for (const persistence of persistenceHierarchy) try {
			const blob = await persistence._get(key);
			if (blob) {
				let user;
				if (typeof blob === "string") {
					const response = await getAccountInfo(auth, { idToken: blob }).catch(() => void 0);
					if (!response) break;
					user = await UserImpl._fromGetAccountInfoResponse(auth, response, blob);
				} else user = UserImpl._fromJSON(auth, blob);
				if (persistence !== selectedPersistence) userToMigrate = user;
				selectedPersistence = persistence;
				break;
			}
		} catch {}
		const migrationHierarchy = availablePersistences.filter((p) => p._shouldAllowMigration);
		if (!selectedPersistence._shouldAllowMigration || !migrationHierarchy.length) return new PersistenceUserManager(selectedPersistence, auth, userKey);
		selectedPersistence = migrationHierarchy[0];
		if (userToMigrate) await selectedPersistence._set(key, userToMigrate.toJSON());
		await Promise.all(persistenceHierarchy.map(async (persistence) => {
			if (persistence !== selectedPersistence) try {
				await persistence._remove(key);
			} catch {}
		}));
		return new PersistenceUserManager(selectedPersistence, auth, userKey);
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Determine the browser for the purposes of reporting usage to the API
*/
function _getBrowserName(userAgent) {
	const ua = userAgent.toLowerCase();
	if (ua.includes("opera/") || ua.includes("opr/") || ua.includes("opios/")) return "Opera";
	else if (_isIEMobile(ua)) return "IEMobile";
	else if (ua.includes("msie") || ua.includes("trident/")) return "IE";
	else if (ua.includes("edge/")) return "Edge";
	else if (_isFirefox(ua)) return "Firefox";
	else if (ua.includes("silk/")) return "Silk";
	else if (_isBlackBerry(ua)) return "Blackberry";
	else if (_isWebOS(ua)) return "Webos";
	else if (_isSafari(ua)) return "Safari";
	else if ((ua.includes("chrome/") || _isChromeIOS(ua)) && !ua.includes("edge/")) return "Chrome";
	else if (_isAndroid(ua)) return "Android";
	else {
		const matches = userAgent.match(/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/);
		if (matches?.length === 2) return matches[1];
	}
	return "Other";
}
function _isFirefox(ua = getUA()) {
	return /firefox\//i.test(ua);
}
function _isSafari(userAgent = getUA()) {
	const ua = userAgent.toLowerCase();
	return ua.includes("safari/") && !ua.includes("chrome/") && !ua.includes("crios/") && !ua.includes("android");
}
function _isChromeIOS(ua = getUA()) {
	return /crios\//i.test(ua);
}
function _isIEMobile(ua = getUA()) {
	return /iemobile/i.test(ua);
}
function _isAndroid(ua = getUA()) {
	return /android/i.test(ua);
}
function _isBlackBerry(ua = getUA()) {
	return /blackberry/i.test(ua);
}
function _isWebOS(ua = getUA()) {
	return /webos/i.test(ua);
}
function _isIOS(ua = getUA()) {
	return /iphone|ipad|ipod/i.test(ua) || /macintosh/i.test(ua) && /mobile/i.test(ua);
}
function _isIOSStandalone(ua = getUA()) {
	return _isIOS(ua) && !!window.navigator?.standalone;
}
function _isIE10() {
	return isIE() && document.documentMode === 10;
}
function _isMobileBrowser(ua = getUA()) {
	return _isIOS(ua) || _isAndroid(ua) || _isWebOS(ua) || _isBlackBerry(ua) || /windows phone/i.test(ua) || _isIEMobile(ua);
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function _getClientVersion(clientPlatform, frameworks = []) {
	let reportedPlatform;
	switch (clientPlatform) {
		case "Browser":
			reportedPlatform = _getBrowserName(getUA());
			break;
		case "Worker":
			reportedPlatform = `${_getBrowserName(getUA())}-${clientPlatform}`;
			break;
		default: reportedPlatform = clientPlatform;
	}
	const reportedFrameworks = frameworks.length ? frameworks.join(",") : "FirebaseCore-web";
	return `${reportedPlatform}/JsCore/${SDK_VERSION}/${reportedFrameworks}`;
}
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var AuthMiddlewareQueue = class {
	constructor(auth) {
		this.auth = auth;
		this.queue = [];
	}
	pushCallback(callback, onAbort) {
		const wrappedCallback = (user) => new Promise((resolve, reject) => {
			try {
				resolve(callback(user));
			} catch (e) {
				reject(e);
			}
		});
		wrappedCallback.onAbort = onAbort;
		this.queue.push(wrappedCallback);
		const index = this.queue.length - 1;
		return () => {
			this.queue[index] = () => Promise.resolve();
		};
	}
	async runMiddleware(nextUser) {
		if (this.auth.currentUser === nextUser) return;
		const onAbortStack = [];
		try {
			for (const beforeStateCallback of this.queue) {
				await beforeStateCallback(nextUser);
				if (beforeStateCallback.onAbort) onAbortStack.push(beforeStateCallback.onAbort);
			}
		} catch (e) {
			onAbortStack.reverse();
			for (const onAbort of onAbortStack) try {
				onAbort();
			} catch (_) {}
			throw this.auth._errorFactory.create("login-blocked", { originalMessage: e?.message });
		}
	}
};
/**
* @license
* Copyright 2023 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Fetches the password policy for the currently set tenant or the project if no tenant is set.
*
* @param auth Auth object.
* @param request Password policy request.
* @returns Password policy response.
*/
async function _getPasswordPolicy(auth, request = {}) {
	return _performApiRequest(auth, "GET", "/v2/passwordPolicy", _addTidIfNecessary(auth, request));
}
/**
* @license
* Copyright 2023 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var MINIMUM_MIN_PASSWORD_LENGTH = 6;
/**
* Stores password policy requirements and provides password validation against the policy.
*
* @internal
*/
var PasswordPolicyImpl = class {
	constructor(response) {
		const responseOptions = response.customStrengthOptions;
		this.customStrengthOptions = {};
		this.customStrengthOptions.minPasswordLength = responseOptions.minPasswordLength ?? MINIMUM_MIN_PASSWORD_LENGTH;
		if (responseOptions.maxPasswordLength) this.customStrengthOptions.maxPasswordLength = responseOptions.maxPasswordLength;
		if (responseOptions.containsLowercaseCharacter !== void 0) this.customStrengthOptions.containsLowercaseLetter = responseOptions.containsLowercaseCharacter;
		if (responseOptions.containsUppercaseCharacter !== void 0) this.customStrengthOptions.containsUppercaseLetter = responseOptions.containsUppercaseCharacter;
		if (responseOptions.containsNumericCharacter !== void 0) this.customStrengthOptions.containsNumericCharacter = responseOptions.containsNumericCharacter;
		if (responseOptions.containsNonAlphanumericCharacter !== void 0) this.customStrengthOptions.containsNonAlphanumericCharacter = responseOptions.containsNonAlphanumericCharacter;
		this.enforcementState = response.enforcementState;
		if (this.enforcementState === "ENFORCEMENT_STATE_UNSPECIFIED") this.enforcementState = "OFF";
		this.allowedNonAlphanumericCharacters = response.allowedNonAlphanumericCharacters?.join("") ?? "";
		this.forceUpgradeOnSignin = response.forceUpgradeOnSignin ?? false;
		this.schemaVersion = response.schemaVersion;
	}
	validatePassword(password) {
		const status = {
			isValid: true,
			passwordPolicy: this
		};
		this.validatePasswordLengthOptions(password, status);
		this.validatePasswordCharacterOptions(password, status);
		status.isValid && (status.isValid = status.meetsMinPasswordLength ?? true);
		status.isValid && (status.isValid = status.meetsMaxPasswordLength ?? true);
		status.isValid && (status.isValid = status.containsLowercaseLetter ?? true);
		status.isValid && (status.isValid = status.containsUppercaseLetter ?? true);
		status.isValid && (status.isValid = status.containsNumericCharacter ?? true);
		status.isValid && (status.isValid = status.containsNonAlphanumericCharacter ?? true);
		return status;
	}
	/**
	* Validates that the password meets the length options for the policy.
	*
	* @param password Password to validate.
	* @param status Validation status.
	*/
	validatePasswordLengthOptions(password, status) {
		const minPasswordLength = this.customStrengthOptions.minPasswordLength;
		const maxPasswordLength = this.customStrengthOptions.maxPasswordLength;
		if (minPasswordLength) status.meetsMinPasswordLength = password.length >= minPasswordLength;
		if (maxPasswordLength) status.meetsMaxPasswordLength = password.length <= maxPasswordLength;
	}
	/**
	* Validates that the password meets the character options for the policy.
	*
	* @param password Password to validate.
	* @param status Validation status.
	*/
	validatePasswordCharacterOptions(password, status) {
		this.updatePasswordCharacterOptionsStatuses(status, false, false, false, false);
		let passwordChar;
		for (let i = 0; i < password.length; i++) {
			passwordChar = password.charAt(i);
			this.updatePasswordCharacterOptionsStatuses(status, passwordChar >= "a" && passwordChar <= "z", passwordChar >= "A" && passwordChar <= "Z", passwordChar >= "0" && passwordChar <= "9", this.allowedNonAlphanumericCharacters.includes(passwordChar));
		}
	}
	/**
	* Updates the running validation status with the statuses for the character options.
	* Expected to be called each time a character is processed to update each option status
	* based on the current character.
	*
	* @param status Validation status.
	* @param containsLowercaseCharacter Whether the character is a lowercase letter.
	* @param containsUppercaseCharacter Whether the character is an uppercase letter.
	* @param containsNumericCharacter Whether the character is a numeric character.
	* @param containsNonAlphanumericCharacter Whether the character is a non-alphanumeric character.
	*/
	updatePasswordCharacterOptionsStatuses(status, containsLowercaseCharacter, containsUppercaseCharacter, containsNumericCharacter, containsNonAlphanumericCharacter) {
		if (this.customStrengthOptions.containsLowercaseLetter) status.containsLowercaseLetter || (status.containsLowercaseLetter = containsLowercaseCharacter);
		if (this.customStrengthOptions.containsUppercaseLetter) status.containsUppercaseLetter || (status.containsUppercaseLetter = containsUppercaseCharacter);
		if (this.customStrengthOptions.containsNumericCharacter) status.containsNumericCharacter || (status.containsNumericCharacter = containsNumericCharacter);
		if (this.customStrengthOptions.containsNonAlphanumericCharacter) status.containsNonAlphanumericCharacter || (status.containsNonAlphanumericCharacter = containsNonAlphanumericCharacter);
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var AuthImpl = class {
	constructor(app, heartbeatServiceProvider, appCheckServiceProvider, config) {
		this.app = app;
		this.heartbeatServiceProvider = heartbeatServiceProvider;
		this.appCheckServiceProvider = appCheckServiceProvider;
		this.config = config;
		this.currentUser = null;
		this.emulatorConfig = null;
		this.operations = Promise.resolve();
		this.authStateSubscription = new Subscription(this);
		this.idTokenSubscription = new Subscription(this);
		this.beforeStateQueue = new AuthMiddlewareQueue(this);
		this.redirectUser = null;
		this.isProactiveRefreshEnabled = false;
		this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION = 1;
		this._canInitEmulator = true;
		this._isInitialized = false;
		this._deleted = false;
		this._initializationPromise = null;
		this._popupRedirectResolver = null;
		this._errorFactory = _DEFAULT_AUTH_ERROR_FACTORY;
		this._agentRecaptchaConfig = null;
		this._tenantRecaptchaConfigs = {};
		this._projectPasswordPolicy = null;
		this._tenantPasswordPolicies = {};
		this._resolvePersistenceManagerAvailable = void 0;
		this.lastNotifiedUid = void 0;
		this.languageCode = null;
		this.tenantId = null;
		this.settings = { appVerificationDisabledForTesting: false };
		this.frameworks = [];
		this.name = app.name;
		this.clientVersion = config.sdkClientVersion;
		this._persistenceManagerAvailable = new Promise((resolve) => this._resolvePersistenceManagerAvailable = resolve);
	}
	_initializeWithPersistence(persistenceHierarchy, popupRedirectResolver) {
		if (popupRedirectResolver) this._popupRedirectResolver = _getInstance(popupRedirectResolver);
		this._initializationPromise = this.queue(async () => {
			if (this._deleted) return;
			try {
				this.persistenceManager = await PersistenceUserManager.create(this, persistenceHierarchy);
			} catch (e) {
				_logWarn(`Failed to initialize persistence: ${e}`);
				this.persistenceManager = await PersistenceUserManager.create(this, []);
			} finally {
				this._resolvePersistenceManagerAvailable?.();
			}
			if (this._deleted) return;
			if (this._popupRedirectResolver?._shouldInitProactively) try {
				await this._popupRedirectResolver._initialize(this);
			} catch (e) {}
			try {
				await this.initializeCurrentUser(popupRedirectResolver);
			} catch (e) {
				_logWarn(`Failed to initialize current user: ${e}`);
				await this.directlySetCurrentUser(null).catch(() => {});
			}
			this.lastNotifiedUid = this.currentUser?.uid || null;
			if (this._deleted) return;
			this._isInitialized = true;
		});
		return this._initializationPromise;
	}
	/**
	* If the persistence is changed in another window, the user manager will let us know
	*/
	async _onStorageEvent() {
		if (this._deleted) return;
		const user = await this.assertedPersistence.getCurrentUser();
		if (!this.currentUser && !user) return;
		if (this.currentUser && user && this.currentUser.uid === user.uid) {
			this._currentUser._assign(user);
			await this.currentUser.getIdToken();
			return;
		}
		await this._updateCurrentUser(user, true);
	}
	async initializeCurrentUserFromIdToken(idToken) {
		try {
			const response = await getAccountInfo(this, { idToken });
			const user = await UserImpl._fromGetAccountInfoResponse(this, response, idToken);
			await this.directlySetCurrentUser(user);
		} catch (err) {
			console.warn("FirebaseServerApp could not login user with provided authIdToken: ", err);
			await this.directlySetCurrentUser(null);
		}
	}
	async initializeCurrentUser(popupRedirectResolver) {
		if (_isFirebaseServerApp(this.app)) {
			const idToken = this.app.settings.authIdToken;
			if (idToken) return new Promise((resolve) => {
				setTimeout(() => this.initializeCurrentUserFromIdToken(idToken).then(resolve, resolve));
			});
			else return this.directlySetCurrentUser(null);
		}
		const previouslyStoredUser = await this.assertedPersistence.getCurrentUser();
		let futureCurrentUser = previouslyStoredUser;
		let needsTocheckMiddleware = false;
		if (popupRedirectResolver && this.config.authDomain) {
			await this.getOrInitRedirectPersistenceManager();
			const redirectUserEventId = this.redirectUser?._redirectEventId;
			const storedUserEventId = futureCurrentUser?._redirectEventId;
			const result = await this.tryRedirectSignIn(popupRedirectResolver);
			if ((!redirectUserEventId || redirectUserEventId === storedUserEventId) && result?.user) {
				futureCurrentUser = result.user;
				needsTocheckMiddleware = true;
			}
		}
		if (!futureCurrentUser) return this.directlySetCurrentUser(null);
		if (!futureCurrentUser._redirectEventId) {
			if (needsTocheckMiddleware) try {
				await this.beforeStateQueue.runMiddleware(futureCurrentUser);
			} catch (e) {
				futureCurrentUser = previouslyStoredUser;
				this._popupRedirectResolver._overrideRedirectResult(this, () => Promise.reject(e));
			}
			if (futureCurrentUser) return this.reloadAndSetCurrentUserOrClear(futureCurrentUser);
			else return this.directlySetCurrentUser(null);
		}
		_assert(this._popupRedirectResolver, this, "argument-error");
		await this.getOrInitRedirectPersistenceManager();
		if (this.redirectUser && this.redirectUser._redirectEventId === futureCurrentUser._redirectEventId) return this.directlySetCurrentUser(futureCurrentUser);
		return this.reloadAndSetCurrentUserOrClear(futureCurrentUser);
	}
	async tryRedirectSignIn(redirectResolver) {
		let result = null;
		try {
			result = await this._popupRedirectResolver._completeRedirectFn(this, redirectResolver, true);
		} catch (e) {
			await this._setRedirectUser(null);
		}
		return result;
	}
	async reloadAndSetCurrentUserOrClear(user) {
		try {
			await _reloadWithoutSaving(user);
		} catch (e) {
			const code = e?.code;
			if (code !== `auth/network-request-failed` && code !== `auth/too-many-requests` && !code?.startsWith(`auth/quota-exceeded`)) return this.directlySetCurrentUser(null);
		}
		return this.directlySetCurrentUser(user);
	}
	useDeviceLanguage() {
		this.languageCode = _getUserLanguage();
	}
	async _delete() {
		this._deleted = true;
	}
	async updateCurrentUser(userExtern) {
		if (_isFirebaseServerApp(this.app)) return Promise.reject(_serverAppCurrentUserOperationNotSupportedError(this));
		const user = userExtern ? getModularInstance(userExtern) : null;
		if (user) _assert(user.auth.config.apiKey === this.config.apiKey, this, "invalid-user-token");
		return this._updateCurrentUser(user && user._clone(this));
	}
	async _updateCurrentUser(user, skipBeforeStateCallbacks = false) {
		if (this._deleted) return;
		if (user) _assert(this.tenantId === user.tenantId, this, "tenant-id-mismatch");
		if (!skipBeforeStateCallbacks) await this.beforeStateQueue.runMiddleware(user);
		return this.queue(async () => {
			await this.directlySetCurrentUser(user);
			this.notifyAuthListeners();
		});
	}
	async signOut() {
		if (_isFirebaseServerApp(this.app)) return Promise.reject(_serverAppCurrentUserOperationNotSupportedError(this));
		await this.beforeStateQueue.runMiddleware(null);
		if (this.redirectPersistenceManager || this._popupRedirectResolver) await this._setRedirectUser(null);
		return this._updateCurrentUser(null, true);
	}
	setPersistence(persistence) {
		if (_isFirebaseServerApp(this.app)) return Promise.reject(_serverAppCurrentUserOperationNotSupportedError(this));
		return this.queue(async () => {
			await this.assertedPersistence.setPersistence(_getInstance(persistence));
		});
	}
	_getRecaptchaConfig() {
		if (this.tenantId == null) return this._agentRecaptchaConfig;
		else return this._tenantRecaptchaConfigs[this.tenantId];
	}
	async validatePassword(password) {
		if (!this._getPasswordPolicyInternal()) await this._updatePasswordPolicy();
		const passwordPolicy = this._getPasswordPolicyInternal();
		if (passwordPolicy.schemaVersion !== this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION) return Promise.reject(this._errorFactory.create("unsupported-password-policy-schema-version", {}));
		return passwordPolicy.validatePassword(password);
	}
	_getPasswordPolicyInternal() {
		if (this.tenantId === null) return this._projectPasswordPolicy;
		else return this._tenantPasswordPolicies[this.tenantId];
	}
	async _updatePasswordPolicy() {
		const passwordPolicy = new PasswordPolicyImpl(await _getPasswordPolicy(this));
		if (this.tenantId === null) this._projectPasswordPolicy = passwordPolicy;
		else this._tenantPasswordPolicies[this.tenantId] = passwordPolicy;
	}
	_getPersistenceType() {
		return this.assertedPersistence.persistence.type;
	}
	_getPersistence() {
		return this.assertedPersistence.persistence;
	}
	_updateErrorMap(errorMap) {
		this._errorFactory = new ErrorFactory("auth", "Firebase", errorMap());
	}
	onAuthStateChanged(nextOrObserver, error, completed) {
		return this.registerStateListener(this.authStateSubscription, nextOrObserver, error, completed);
	}
	beforeAuthStateChanged(callback, onAbort) {
		return this.beforeStateQueue.pushCallback(callback, onAbort);
	}
	onIdTokenChanged(nextOrObserver, error, completed) {
		return this.registerStateListener(this.idTokenSubscription, nextOrObserver, error, completed);
	}
	authStateReady() {
		return new Promise((resolve, reject) => {
			if (this.currentUser) resolve();
			else {
				const unsubscribe = this.onAuthStateChanged(() => {
					unsubscribe();
					resolve();
				}, reject);
			}
		});
	}
	/**
	* Revokes the given access token. Currently only supports Apple OAuth access tokens.
	*/
	async revokeAccessToken(token) {
		if (this.currentUser) {
			const request = {
				providerId: "apple.com",
				tokenType: "ACCESS_TOKEN",
				token,
				idToken: await this.currentUser.getIdToken()
			};
			if (this.tenantId != null) request.tenantId = this.tenantId;
			await revokeToken(this, request);
		}
	}
	toJSON() {
		return {
			apiKey: this.config.apiKey,
			authDomain: this.config.authDomain,
			appName: this.name,
			currentUser: this._currentUser?.toJSON()
		};
	}
	async _setRedirectUser(user, popupRedirectResolver) {
		const redirectManager = await this.getOrInitRedirectPersistenceManager(popupRedirectResolver);
		return user === null ? redirectManager.removeCurrentUser() : redirectManager.setCurrentUser(user);
	}
	async getOrInitRedirectPersistenceManager(popupRedirectResolver) {
		if (!this.redirectPersistenceManager) {
			const resolver = popupRedirectResolver && _getInstance(popupRedirectResolver) || this._popupRedirectResolver;
			_assert(resolver, this, "argument-error");
			this.redirectPersistenceManager = await PersistenceUserManager.create(this, [_getInstance(resolver._redirectPersistence)], "redirectUser");
			this.redirectUser = await this.redirectPersistenceManager.getCurrentUser();
		}
		return this.redirectPersistenceManager;
	}
	async _redirectUserForId(id) {
		if (this._isInitialized) await this.queue(async () => {});
		if (this._currentUser?._redirectEventId === id) return this._currentUser;
		if (this.redirectUser?._redirectEventId === id) return this.redirectUser;
		return null;
	}
	async _persistUserIfCurrent(user) {
		if (user === this.currentUser) return this.queue(async () => this.directlySetCurrentUser(user));
	}
	/** Notifies listeners only if the user is current */
	_notifyListenersIfCurrent(user) {
		if (user === this.currentUser) this.notifyAuthListeners();
	}
	_key() {
		return `${this.config.authDomain}:${this.config.apiKey}:${this.name}`;
	}
	_startProactiveRefresh() {
		this.isProactiveRefreshEnabled = true;
		if (this.currentUser) this._currentUser._startProactiveRefresh();
	}
	_stopProactiveRefresh() {
		this.isProactiveRefreshEnabled = false;
		if (this.currentUser) this._currentUser._stopProactiveRefresh();
	}
	/** Returns the current user cast as the internal type */
	get _currentUser() {
		return this.currentUser;
	}
	notifyAuthListeners() {
		if (!this._isInitialized) return;
		this.idTokenSubscription.next(this.currentUser);
		const currentUid = this.currentUser?.uid ?? null;
		if (this.lastNotifiedUid !== currentUid) {
			this.lastNotifiedUid = currentUid;
			this.authStateSubscription.next(this.currentUser);
		}
	}
	registerStateListener(subscription, nextOrObserver, error, completed) {
		if (this._deleted) return () => {};
		const cb = typeof nextOrObserver === "function" ? nextOrObserver : nextOrObserver.next.bind(nextOrObserver);
		let isUnsubscribed = false;
		const promise = this._isInitialized ? Promise.resolve() : this._initializationPromise;
		_assert(promise, this, "internal-error");
		promise.then(() => {
			if (isUnsubscribed) return;
			cb(this.currentUser);
		}).catch((err) => {
			if (isUnsubscribed) return;
			if (typeof nextOrObserver !== "function" && nextOrObserver.error) nextOrObserver.error(err);
			else if (error) error(err);
			else throw err;
		});
		if (typeof nextOrObserver === "function") {
			const unsubscribe = subscription.addObserver(nextOrObserver, error, completed);
			return () => {
				isUnsubscribed = true;
				unsubscribe();
			};
		} else {
			const unsubscribe = subscription.addObserver(nextOrObserver);
			return () => {
				isUnsubscribed = true;
				unsubscribe();
			};
		}
	}
	/**
	* Unprotected (from race conditions) method to set the current user. This
	* should only be called from within a queued callback. This is necessary
	* because the queue shouldn't rely on another queued callback.
	*/
	async directlySetCurrentUser(user) {
		if (this.currentUser && this.currentUser !== user) this._currentUser._stopProactiveRefresh();
		if (user && this.isProactiveRefreshEnabled) user._startProactiveRefresh();
		this.currentUser = user;
		if (this.persistenceManager) try {
			if (user) await this.persistenceManager.setCurrentUser(user);
			else await this.persistenceManager.removeCurrentUser();
		} catch (e) {
			const originalMessage = e?.message || String(e);
			const error = _errorWithCustomMessage(this, "internal-error", `An internal AuthError has occurred: ${originalMessage}`);
			error.customData = { originalError: e };
			throw error;
		}
	}
	queue(action) {
		this.operations = this.operations.then(action, action);
		return this.operations;
	}
	get assertedPersistence() {
		_assert(this.persistenceManager, this, "internal-error");
		return this.persistenceManager;
	}
	_logFramework(framework) {
		if (!framework || this.frameworks.includes(framework)) return;
		this.frameworks.push(framework);
		this.frameworks.sort();
		this.clientVersion = _getClientVersion(this.config.clientPlatform, this._getFrameworks());
	}
	_getFrameworks() {
		return this.frameworks;
	}
	async _getAdditionalHeaders() {
		const headers = { ["X-Client-Version"]: this.clientVersion };
		if (this.app.options.appId) headers["X-Firebase-gmpid"] = this.app.options.appId;
		const heartbeatsHeader = await this.heartbeatServiceProvider.getImmediate({ optional: true })?.getHeartbeatsHeader();
		if (heartbeatsHeader) headers["X-Firebase-Client"] = heartbeatsHeader;
		const appCheckToken = await this._getAppCheckToken();
		if (appCheckToken) headers["X-Firebase-AppCheck"] = appCheckToken;
		return headers;
	}
	async _getAppCheckToken() {
		if (_isFirebaseServerApp(this.app) && this.app.settings.appCheckToken) return this.app.settings.appCheckToken;
		const appCheckTokenResult = await this.appCheckServiceProvider.getImmediate({ optional: true })?.getToken();
		if (appCheckTokenResult?.error) _logWarn(`Error while retrieving App Check token: ${appCheckTokenResult.error}`);
		return appCheckTokenResult?.token;
	}
};
/**
* Method to be used to cast down to our private implementation of Auth.
* It will also handle unwrapping from the compat type if necessary
*
* @param auth Auth object passed in from developer
*/
function _castAuth(auth) {
	return getModularInstance(auth);
}
/** Helper class to wrap subscriber logic */
var Subscription = class {
	constructor(auth) {
		this.auth = auth;
		this.observer = null;
		this.addObserver = createSubscribe((observer) => this.observer = observer);
	}
	get next() {
		_assert(this.observer, this.auth, "internal-error");
		return this.observer.next.bind(this.observer);
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var externalJSProvider = {
	async loadJS() {
		throw new Error("Unable to load external scripts");
	},
	recaptchaV2Script: "",
	recaptchaEnterpriseScript: "",
	gapiScript: ""
};
function _setExternalJSProvider(p) {
	externalJSProvider = p;
}
function _loadJS(url) {
	return externalJSProvider.loadJS(url);
}
function _recaptchaEnterpriseScriptUrl() {
	return externalJSProvider.recaptchaEnterpriseScript;
}
function _gapiScriptUrl() {
	return externalJSProvider.gapiScript;
}
function _generateCallbackName(prefix) {
	return `__${prefix}${Math.floor(Math.random() * 1e6)}`;
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var MockGreCAPTCHATopLevel = class {
	constructor() {
		this.enterprise = new MockGreCAPTCHA();
	}
	ready(callback) {
		callback();
	}
	execute(_siteKey, _options) {
		return Promise.resolve("token");
	}
	render(_container, _parameters) {
		return "";
	}
};
var MockGreCAPTCHA = class {
	ready(callback) {
		callback();
	}
	execute(_siteKey, _options) {
		return Promise.resolve("token");
	}
	render(_container, _parameters) {
		return "";
	}
};
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var RECAPTCHA_ENTERPRISE_VERIFIER_TYPE = "recaptcha-enterprise";
var FAKE_TOKEN = "NO_RECAPTCHA";
var RECAPTCHA_ENTERPRISE_ONLOAD_CALLBACK_NAME = "onFirebaseAuthREInstanceReady";
var RecaptchaEnterpriseVerifier = class RecaptchaEnterpriseVerifier {
	/**
	*
	* @param authExtern - The corresponding Firebase {@link Auth} instance.
	*
	*/
	constructor(authExtern) {
		/**
		* Identifies the type of application verifier (e.g. "recaptcha-enterprise").
		*/
		this.type = RECAPTCHA_ENTERPRISE_VERIFIER_TYPE;
		this.auth = _castAuth(authExtern);
	}
	/**
	* Executes the verification process.
	*
	* @returns A Promise for a token that can be used to assert the validity of a request.
	*/
	async verify(action = "verify", forceRefresh = false) {
		async function retrieveSiteKey(auth) {
			if (!forceRefresh) {
				if (auth.tenantId == null && auth._agentRecaptchaConfig != null) return auth._agentRecaptchaConfig.siteKey;
				if (auth.tenantId != null && auth._tenantRecaptchaConfigs[auth.tenantId] !== void 0) return auth._tenantRecaptchaConfigs[auth.tenantId].siteKey;
			}
			return new Promise(async (resolve, reject) => {
				getRecaptchaConfig(auth, {
					clientType: "CLIENT_TYPE_WEB",
					version: "RECAPTCHA_ENTERPRISE"
				}).then((response) => {
					if (response.recaptchaKey === void 0) reject(/* @__PURE__ */ new Error("recaptcha Enterprise site key undefined"));
					else {
						const config = new RecaptchaConfig(response);
						if (auth.tenantId == null) auth._agentRecaptchaConfig = config;
						else auth._tenantRecaptchaConfigs[auth.tenantId] = config;
						return resolve(config.siteKey);
					}
				}).catch((error) => {
					reject(error);
				});
			});
		}
		function retrieveRecaptchaToken(siteKey, resolve, reject) {
			const grecaptcha = window.grecaptcha;
			if (isEnterprise(grecaptcha)) grecaptcha.enterprise.ready(() => {
				grecaptcha.enterprise.execute(siteKey, { action }).then((token) => {
					resolve(token);
				}).catch(() => {
					resolve(FAKE_TOKEN);
				});
			});
			else reject(Error("No reCAPTCHA enterprise script loaded."));
		}
		if (this.auth.settings.appVerificationDisabledForTesting) return new MockGreCAPTCHATopLevel().execute("siteKey", { action: "verify" });
		return new Promise((resolve, reject) => {
			retrieveSiteKey(this.auth).then(async (siteKey) => {
				if (!forceRefresh && isEnterprise(window.grecaptcha) && RecaptchaEnterpriseVerifier.scriptInjectionDeferred) {
					await RecaptchaEnterpriseVerifier.scriptInjectionDeferred.promise;
					retrieveRecaptchaToken(siteKey, resolve, reject);
				} else {
					if (typeof window === "undefined") {
						reject(/* @__PURE__ */ new Error("RecaptchaVerifier is only supported in browser"));
						return;
					}
					let url = _recaptchaEnterpriseScriptUrl();
					if (url.length !== 0) url += siteKey + `&onload=${RECAPTCHA_ENTERPRISE_ONLOAD_CALLBACK_NAME}`;
					RecaptchaEnterpriseVerifier.scriptInjectionDeferred = new Deferred();
					/**
					* Script attached to global window object that will be called
					* when the ReCAPTCHA Enterprise instance is ready.
					* grecaptcha.ready() is not reliable when there are multiple
					* scripts on the page, and script.onload only indicates the
					* script has downloaded, not that it has initialized.
					*/
					window[RECAPTCHA_ENTERPRISE_ONLOAD_CALLBACK_NAME] = () => {
						RecaptchaEnterpriseVerifier.scriptInjectionDeferred?.resolve();
					};
					_loadJS(url).then(() => RecaptchaEnterpriseVerifier.scriptInjectionDeferred?.promise).then(() => {
						retrieveRecaptchaToken(siteKey, resolve, reject);
					}).catch((error) => {
						reject(error);
					});
				}
			}).catch((error) => {
				reject(error);
			});
		});
	}
};
/**
* Deferred that resolves when script tag has been injected onto the page
* and the script is ready (grecaptcha.ready() and script.onload are not
* reliable indicators, so this resolves when the global
* `window[RECAPTCHA_ENTERPRISE_ONLOAD_CALLBACK_NAME]()` callback provided to the recaptcha url param "onload"
* is triggered).
* As a static variable this is applied to all instances of the class.
* This will cause an error if users try to create multiple RecaptchaVerifiers
* with different Recaptcha Enterprise sitekeys, which should be an
* unuspported use case.
*/
RecaptchaEnterpriseVerifier.scriptInjectionDeferred = null;
async function injectRecaptchaFields(auth, request, action, isCaptchaResp = false, isFakeToken = false) {
	const verifier = new RecaptchaEnterpriseVerifier(auth);
	let captchaResponse;
	if (isFakeToken) captchaResponse = FAKE_TOKEN;
	else try {
		captchaResponse = await verifier.verify(action);
	} catch (error) {
		captchaResponse = await verifier.verify(action, true);
	}
	const newRequest = { ...request };
	if (action === "mfaSmsEnrollment" || action === "mfaSmsSignIn") {
		if ("phoneEnrollmentInfo" in newRequest) {
			const phoneNumber = newRequest.phoneEnrollmentInfo.phoneNumber;
			const recaptchaToken = newRequest.phoneEnrollmentInfo.recaptchaToken;
			Object.assign(newRequest, { "phoneEnrollmentInfo": {
				phoneNumber,
				recaptchaToken,
				captchaResponse,
				"clientType": "CLIENT_TYPE_WEB",
				"recaptchaVersion": "RECAPTCHA_ENTERPRISE"
			} });
		} else if ("phoneSignInInfo" in newRequest) {
			const recaptchaToken = newRequest.phoneSignInInfo.recaptchaToken;
			Object.assign(newRequest, { "phoneSignInInfo": {
				recaptchaToken,
				captchaResponse,
				"clientType": "CLIENT_TYPE_WEB",
				"recaptchaVersion": "RECAPTCHA_ENTERPRISE"
			} });
		}
		return newRequest;
	}
	if (!isCaptchaResp) Object.assign(newRequest, { captchaResponse });
	else Object.assign(newRequest, { "captchaResp": captchaResponse });
	Object.assign(newRequest, { "clientType": "CLIENT_TYPE_WEB" });
	Object.assign(newRequest, { "recaptchaVersion": "RECAPTCHA_ENTERPRISE" });
	return newRequest;
}
async function handleRecaptchaFlow(authInstance, request, actionName, actionMethod, recaptchaAuthProvider) {
	if (recaptchaAuthProvider === "EMAIL_PASSWORD_PROVIDER") {
		if (authInstance._getRecaptchaConfig()?.isProviderEnabled("EMAIL_PASSWORD_PROVIDER")) return actionMethod(authInstance, await injectRecaptchaFields(authInstance, request, actionName, actionName === "getOobCode"));
		else return actionMethod(authInstance, request).catch(async (error) => {
			if (error.code === `auth/missing-recaptcha-token`) {
				console.log(`${actionName} is protected by reCAPTCHA Enterprise for this project. Automatically triggering the reCAPTCHA flow and restarting the flow.`);
				return actionMethod(authInstance, await injectRecaptchaFields(authInstance, request, actionName, actionName === "getOobCode"));
			} else return Promise.reject(error);
		});
	} else if (recaptchaAuthProvider === "PHONE_PROVIDER") {
		if (authInstance._getRecaptchaConfig()?.isProviderEnabled("PHONE_PROVIDER")) return actionMethod(authInstance, await injectRecaptchaFields(authInstance, request, actionName)).catch(async (error) => {
			if (authInstance._getRecaptchaConfig()?.getProviderEnforcementState("PHONE_PROVIDER") === "AUDIT") {
				if (error.code === `auth/missing-recaptcha-token` || error.code === `auth/invalid-app-credential`) {
					console.log(`Failed to verify with reCAPTCHA Enterprise. Automatically triggering the reCAPTCHA v2 flow to complete the ${actionName} flow.`);
					return actionMethod(authInstance, await injectRecaptchaFields(authInstance, request, actionName, false, true));
				}
			}
			return Promise.reject(error);
		});
		else return actionMethod(authInstance, await injectRecaptchaFields(authInstance, request, actionName, false, true));
	} else return Promise.reject(recaptchaAuthProvider + " provider is not supported.");
}
async function _initializeRecaptchaConfig(auth) {
	const authInternal = _castAuth(auth);
	const config = new RecaptchaConfig(await getRecaptchaConfig(authInternal, {
		clientType: "CLIENT_TYPE_WEB",
		version: "RECAPTCHA_ENTERPRISE"
	}));
	if (authInternal.tenantId == null) authInternal._agentRecaptchaConfig = config;
	else authInternal._tenantRecaptchaConfigs[authInternal.tenantId] = config;
	if (config.isAnyProviderEnabled()) new RecaptchaEnterpriseVerifier(authInternal).verify();
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Initializes an {@link Auth} instance with fine-grained control over
* {@link Dependencies}.
*
* @remarks
*
* This function allows more control over the {@link Auth} instance than
* {@link getAuth}. `getAuth` uses platform-specific defaults to supply
* the {@link Dependencies}. In general, `getAuth` is the easiest way to
* initialize Auth and works for most use cases. Use `initializeAuth` if you
* need control over which persistence layer is used, or to minimize bundle
* size if you're not using either `signInWithPopup` or `signInWithRedirect`.
*
* For example, if your app only uses anonymous accounts and you only want
* accounts saved for the current session, initialize `Auth` with:
*
* ```js
* const auth = initializeAuth(app, {
*   persistence: browserSessionPersistence,
*   popupRedirectResolver: undefined,
* });
* ```
*
* @public
*/
function initializeAuth(app, deps) {
	const provider = _getProvider(app, "auth");
	if (provider.isInitialized()) {
		const auth = provider.getImmediate();
		if (deepEqual(provider.getOptions(), deps ?? {})) return auth;
		else _fail(auth, "already-initialized");
	}
	return provider.initialize({ options: deps });
}
function _initializeAuthInstance(auth, deps) {
	const persistence = deps?.persistence || [];
	const hierarchy = (Array.isArray(persistence) ? persistence : [persistence]).map(_getInstance);
	if (deps?.errorMap) auth._updateErrorMap(deps.errorMap);
	auth._initializeWithPersistence(hierarchy, deps?.popupRedirectResolver);
}
/**
* Changes the {@link Auth} instance to communicate with the Firebase Auth Emulator, instead of production
* Firebase Auth services.
*
* @remarks
* This must be called synchronously immediately following the first call to
* {@link initializeAuth}.  Do not use with production credentials as emulator
* traffic is not encrypted.
*
*
* @example
* ```javascript
* connectAuthEmulator(auth, 'http://127.0.0.1:9099', { disableWarnings: true });
* ```
*
* @param auth - The {@link Auth} instance.
* @param url - The URL at which the emulator is running (eg, 'http://localhost:9099').
* @param options - Optional. `options.disableWarnings` defaults to `false`. Set it to
* `true` to disable the warning banner attached to the DOM.
*
* @public
*/
function connectAuthEmulator(auth, url, options) {
	const authInternal = _castAuth(auth);
	_assert(/^https?:\/\//.test(url), authInternal, "invalid-emulator-scheme");
	const disableWarnings = !!options?.disableWarnings;
	const protocol = extractProtocol(url);
	const { host, port } = extractHostAndPort(url);
	const portStr = port === null ? "" : `:${port}`;
	const emulator = { url: `${protocol}//${host}${portStr}/` };
	const emulatorConfig = Object.freeze({
		host,
		port,
		protocol: protocol.replace(":", ""),
		options: Object.freeze({ disableWarnings })
	});
	if (!authInternal._canInitEmulator) {
		_assert(authInternal.config.emulator && authInternal.emulatorConfig, authInternal, "emulator-config-failed");
		_assert(deepEqual(emulator, authInternal.config.emulator) && deepEqual(emulatorConfig, authInternal.emulatorConfig), authInternal, "emulator-config-failed");
		return;
	}
	authInternal.config.emulator = emulator;
	authInternal.emulatorConfig = emulatorConfig;
	authInternal.settings.appVerificationDisabledForTesting = true;
	if (isCloudWorkstation(host)) pingServer(`${protocol}//${host}${portStr}`);
	else if (!disableWarnings) emitEmulatorWarning();
}
function extractProtocol(url) {
	const protocolEnd = url.indexOf(":");
	return protocolEnd < 0 ? "" : url.substr(0, protocolEnd + 1);
}
function extractHostAndPort(url) {
	const protocol = extractProtocol(url);
	const authority = /(\/\/)?([^?#/]+)/.exec(url.substr(protocol.length));
	if (!authority) return {
		host: "",
		port: null
	};
	const hostAndPort = authority[2].split("@").pop() || "";
	const bracketedIPv6 = /^(\[[^\]]+\])(:|$)/.exec(hostAndPort);
	if (bracketedIPv6) {
		const host = bracketedIPv6[1];
		return {
			host,
			port: parsePort(hostAndPort.substr(host.length + 1))
		};
	} else {
		const [host, port] = hostAndPort.split(":");
		return {
			host,
			port: parsePort(port)
		};
	}
}
function parsePort(portStr) {
	if (!portStr) return null;
	const port = Number(portStr);
	if (isNaN(port)) return null;
	return port;
}
function emitEmulatorWarning() {
	function attachBanner() {
		const el = document.createElement("p");
		const sty = el.style;
		el.innerText = "Running in emulator mode. Do not use with production credentials.";
		sty.position = "fixed";
		sty.width = "100%";
		sty.backgroundColor = "#ffffff";
		sty.border = ".1em solid #000000";
		sty.color = "#b50000";
		sty.bottom = "0px";
		sty.left = "0px";
		sty.margin = "0px";
		sty.zIndex = "10000";
		sty.textAlign = "center";
		el.classList.add("firebase-emulator-warning");
		document.body.appendChild(el);
	}
	if (typeof console !== "undefined" && typeof console.info === "function") console.info("WARNING: You are using the Auth Emulator, which is intended for local testing only.  Do not use with production credentials.");
	if (typeof window !== "undefined" && typeof document !== "undefined") {
		if (document.readyState === "loading") window.addEventListener("DOMContentLoaded", attachBanner);
		else attachBanner();
	}
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Interface that represents the credentials returned by an {@link AuthProvider}.
*
* @remarks
* Implementations specify the details about each auth provider's credential requirements.
*
* @public
*/
var AuthCredential = class {
	/** @internal */
	constructor(providerId, signInMethod) {
		this.providerId = providerId;
		this.signInMethod = signInMethod;
	}
	/**
	* Returns a JSON-serializable representation of this object.
	*
	* @returns a JSON-serializable representation of this object.
	*/
	toJSON() {
		return debugFail("not implemented");
	}
	/** @internal */
	_getIdTokenResponse(_auth) {
		return debugFail("not implemented");
	}
	/** @internal */
	_linkToIdToken(_auth, _idToken) {
		return debugFail("not implemented");
	}
	/** @internal */
	_getReauthenticationResolver(_auth) {
		return debugFail("not implemented");
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
async function linkEmailPassword(auth, request) {
	return _performApiRequest(auth, "POST", "/v1/accounts:signUp", request);
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
async function signInWithPassword(auth, request) {
	return _performSignInRequest(auth, "POST", "/v1/accounts:signInWithPassword", _addTidIfNecessary(auth, request));
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
async function signInWithEmailLink$1(auth, request) {
	return _performSignInRequest(auth, "POST", "/v1/accounts:signInWithEmailLink", _addTidIfNecessary(auth, request));
}
async function signInWithEmailLinkForLinking(auth, request) {
	return _performSignInRequest(auth, "POST", "/v1/accounts:signInWithEmailLink", _addTidIfNecessary(auth, request));
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Interface that represents the credentials returned by {@link EmailAuthProvider} for
* {@link ProviderId}.PASSWORD
*
* @remarks
* Covers both {@link SignInMethod}.EMAIL_PASSWORD and
* {@link SignInMethod}.EMAIL_LINK.
*
* @public
*/
var EmailAuthCredential = class EmailAuthCredential extends AuthCredential {
	/** @internal */
	constructor(_email, _password, signInMethod, _tenantId = null) {
		super("password", signInMethod);
		this._email = _email;
		this._password = _password;
		this._tenantId = _tenantId;
	}
	/** @internal */
	static _fromEmailAndPassword(email, password) {
		return new EmailAuthCredential(email, password, "password");
	}
	/** @internal */
	static _fromEmailAndCode(email, oobCode, tenantId = null) {
		return new EmailAuthCredential(email, oobCode, "emailLink", tenantId);
	}
	/** {@inheritdoc AuthCredential.toJSON} */
	toJSON() {
		return {
			email: this._email,
			password: this._password,
			signInMethod: this.signInMethod,
			tenantId: this._tenantId
		};
	}
	/**
	* Static method to deserialize a JSON representation of an object into an {@link  AuthCredential}.
	*
	* @param json - Either `object` or the stringified representation of the object. When string is
	* provided, `JSON.parse` would be called first.
	*
	* @returns If the JSON input does not represent an {@link AuthCredential}, null is returned.
	*/
	static fromJSON(json) {
		const obj = typeof json === "string" ? JSON.parse(json) : json;
		if (obj?.email && obj?.password) {
			if (obj.signInMethod === "password") return this._fromEmailAndPassword(obj.email, obj.password);
			else if (obj.signInMethod === "emailLink") return this._fromEmailAndCode(obj.email, obj.password, obj.tenantId);
		}
		return null;
	}
	/** @internal */
	async _getIdTokenResponse(auth) {
		switch (this.signInMethod) {
			case "password": return handleRecaptchaFlow(auth, {
				returnSecureToken: true,
				email: this._email,
				password: this._password,
				clientType: "CLIENT_TYPE_WEB"
			}, "signInWithPassword", signInWithPassword, "EMAIL_PASSWORD_PROVIDER");
			case "emailLink": return signInWithEmailLink$1(auth, {
				email: this._email,
				oobCode: this._password
			});
			default: _fail(auth, "internal-error");
		}
	}
	/** @internal */
	async _linkToIdToken(auth, idToken) {
		switch (this.signInMethod) {
			case "password": return handleRecaptchaFlow(auth, {
				idToken,
				returnSecureToken: true,
				email: this._email,
				password: this._password,
				clientType: "CLIENT_TYPE_WEB"
			}, "signUpPassword", linkEmailPassword, "EMAIL_PASSWORD_PROVIDER");
			case "emailLink": return signInWithEmailLinkForLinking(auth, {
				idToken,
				email: this._email,
				oobCode: this._password
			});
			default: _fail(auth, "internal-error");
		}
	}
	/** @internal */
	_getReauthenticationResolver(auth) {
		return this._getIdTokenResponse(auth);
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
async function signInWithIdp(auth, request) {
	return _performSignInRequest(auth, "POST", "/v1/accounts:signInWithIdp", _addTidIfNecessary(auth, request));
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var IDP_REQUEST_URI$1 = "http://localhost";
/**
* Represents the OAuth credentials returned by an {@link OAuthProvider}.
*
* @remarks
* Implementations specify the details about each auth provider's credential requirements.
*
* @public
*/
var OAuthCredential = class OAuthCredential extends AuthCredential {
	constructor() {
		super(...arguments);
		this.pendingToken = null;
	}
	/** @internal */
	static _fromParams(params) {
		const cred = new OAuthCredential(params.providerId, params.signInMethod);
		if (params.idToken || params.accessToken) {
			if (params.idToken) cred.idToken = params.idToken;
			if (params.accessToken) cred.accessToken = params.accessToken;
			if (params.nonce && !params.pendingToken) cred.nonce = params.nonce;
			if (params.pendingToken) cred.pendingToken = params.pendingToken;
		} else if (params.oauthToken && params.oauthTokenSecret) {
			cred.accessToken = params.oauthToken;
			cred.secret = params.oauthTokenSecret;
		} else _fail("argument-error");
		return cred;
	}
	/** {@inheritdoc AuthCredential.toJSON}  */
	toJSON() {
		return {
			idToken: this.idToken,
			accessToken: this.accessToken,
			secret: this.secret,
			nonce: this.nonce,
			pendingToken: this.pendingToken,
			providerId: this.providerId,
			signInMethod: this.signInMethod
		};
	}
	/**
	* Static method to deserialize a JSON representation of an object into an
	* {@link  AuthCredential}.
	*
	* @param json - Input can be either Object or the stringified representation of the object.
	* When string is provided, JSON.parse would be called first.
	*
	* @returns If the JSON input does not represent an {@link  AuthCredential}, null is returned.
	*/
	static fromJSON(json) {
		const { providerId, signInMethod, ...rest } = typeof json === "string" ? JSON.parse(json) : json;
		if (!providerId || !signInMethod) return null;
		const cred = new OAuthCredential(providerId, signInMethod);
		cred.idToken = rest.idToken || void 0;
		cred.accessToken = rest.accessToken || void 0;
		cred.secret = rest.secret;
		cred.nonce = rest.nonce;
		cred.pendingToken = rest.pendingToken || null;
		return cred;
	}
	/** @internal */
	_getIdTokenResponse(auth) {
		return signInWithIdp(auth, this.buildRequest());
	}
	/** @internal */
	_linkToIdToken(auth, idToken) {
		const request = this.buildRequest();
		request.idToken = idToken;
		return signInWithIdp(auth, request);
	}
	/** @internal */
	_getReauthenticationResolver(auth) {
		const request = this.buildRequest();
		request.autoCreate = false;
		return signInWithIdp(auth, request);
	}
	buildRequest() {
		const request = {
			requestUri: IDP_REQUEST_URI$1,
			returnSecureToken: true
		};
		if (this.pendingToken) request.pendingToken = this.pendingToken;
		else {
			const postBody = {};
			if (this.idToken) postBody["id_token"] = this.idToken;
			if (this.accessToken) postBody["access_token"] = this.accessToken;
			if (this.secret) postBody["oauth_token_secret"] = this.secret;
			postBody["providerId"] = this.providerId;
			if (this.nonce && !this.pendingToken) postBody["nonce"] = this.nonce;
			request.postBody = querystring(postBody);
		}
		return request;
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
async function sendPhoneVerificationCode(auth, request) {
	return _performApiRequest(auth, "POST", "/v1/accounts:sendVerificationCode", _addTidIfNecessary(auth, request));
}
async function signInWithPhoneNumber$1(auth, request) {
	return _performSignInRequest(auth, "POST", "/v1/accounts:signInWithPhoneNumber", _addTidIfNecessary(auth, request));
}
async function linkWithPhoneNumber$1(auth, request) {
	const response = await _performSignInRequest(auth, "POST", "/v1/accounts:signInWithPhoneNumber", _addTidIfNecessary(auth, request));
	if (response.temporaryProof) throw _makeTaggedError(auth, "account-exists-with-different-credential", response);
	return response;
}
var VERIFY_PHONE_NUMBER_FOR_EXISTING_ERROR_MAP_ = { ["USER_NOT_FOUND"]: "user-not-found" };
async function verifyPhoneNumberForExisting(auth, request) {
	return _performSignInRequest(auth, "POST", "/v1/accounts:signInWithPhoneNumber", _addTidIfNecessary(auth, {
		...request,
		operation: "REAUTH"
	}), VERIFY_PHONE_NUMBER_FOR_EXISTING_ERROR_MAP_);
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Represents the credentials returned by {@link PhoneAuthProvider}.
*
* @public
*/
var PhoneAuthCredential = class PhoneAuthCredential extends AuthCredential {
	constructor(params) {
		super("phone", "phone");
		this.params = params;
	}
	/** @internal */
	static _fromVerification(verificationId, verificationCode) {
		return new PhoneAuthCredential({
			verificationId,
			verificationCode
		});
	}
	/** @internal */
	static _fromTokenResponse(phoneNumber, temporaryProof) {
		return new PhoneAuthCredential({
			phoneNumber,
			temporaryProof
		});
	}
	/** @internal */
	_getIdTokenResponse(auth) {
		return signInWithPhoneNumber$1(auth, this._makeVerificationRequest());
	}
	/** @internal */
	_linkToIdToken(auth, idToken) {
		return linkWithPhoneNumber$1(auth, {
			idToken,
			...this._makeVerificationRequest()
		});
	}
	/** @internal */
	_getReauthenticationResolver(auth) {
		return verifyPhoneNumberForExisting(auth, this._makeVerificationRequest());
	}
	/** @internal */
	_makeVerificationRequest() {
		const { temporaryProof, phoneNumber, verificationId, verificationCode } = this.params;
		if (temporaryProof && phoneNumber) return {
			temporaryProof,
			phoneNumber
		};
		return {
			sessionInfo: verificationId,
			code: verificationCode
		};
	}
	/** {@inheritdoc AuthCredential.toJSON} */
	toJSON() {
		const obj = { providerId: this.providerId };
		if (this.params.phoneNumber) obj.phoneNumber = this.params.phoneNumber;
		if (this.params.temporaryProof) obj.temporaryProof = this.params.temporaryProof;
		if (this.params.verificationCode) obj.verificationCode = this.params.verificationCode;
		if (this.params.verificationId) obj.verificationId = this.params.verificationId;
		return obj;
	}
	/** Generates a phone credential based on a plain object or a JSON string. */
	static fromJSON(json) {
		if (typeof json === "string") json = JSON.parse(json);
		const { verificationId, verificationCode, phoneNumber, temporaryProof } = json;
		if (!verificationCode && !verificationId && !phoneNumber && !temporaryProof) return null;
		return new PhoneAuthCredential({
			verificationId,
			verificationCode,
			phoneNumber,
			temporaryProof
		});
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Maps the mode string in action code URL to Action Code Info operation.
*
* @param mode
*/
function parseMode(mode) {
	switch (mode) {
		case "recoverEmail": return "RECOVER_EMAIL";
		case "resetPassword": return "PASSWORD_RESET";
		case "signIn": return "EMAIL_SIGNIN";
		case "verifyEmail": return "VERIFY_EMAIL";
		case "verifyAndChangeEmail": return "VERIFY_AND_CHANGE_EMAIL";
		case "revertSecondFactorAddition": return "REVERT_SECOND_FACTOR_ADDITION";
		default: return null;
	}
}
/**
* Helper to parse FDL links
*
* @param url
*/
function parseDeepLink(url) {
	const link = querystringDecode(extractQuerystring(url))["link"];
	const doubleDeepLink = link ? querystringDecode(extractQuerystring(link))["deep_link_id"] : null;
	const iOSDeepLink = querystringDecode(extractQuerystring(url))["deep_link_id"];
	return (iOSDeepLink ? querystringDecode(extractQuerystring(iOSDeepLink))["link"] : null) || iOSDeepLink || doubleDeepLink || link || url;
}
/**
* A utility class to parse email action URLs such as password reset, email verification,
* email link sign in, etc.
*
* @public
*/
var ActionCodeURL = class ActionCodeURL {
	/**
	* @param actionLink - The link from which to extract the URL.
	* @returns The {@link ActionCodeURL} object, or null if the link is invalid.
	*
	* @internal
	*/
	constructor(actionLink) {
		const searchParams = querystringDecode(extractQuerystring(actionLink));
		const apiKey = searchParams["apiKey"] ?? null;
		const code = searchParams["oobCode"] ?? null;
		const operation = parseMode(searchParams["mode"] ?? null);
		_assert(apiKey && code && operation, "argument-error");
		this.apiKey = apiKey;
		this.operation = operation;
		this.code = code;
		this.continueUrl = searchParams["continueUrl"] ?? null;
		this.languageCode = searchParams["lang"] ?? null;
		this.tenantId = searchParams["tenantId"] ?? null;
	}
	/**
	* Parses the email action link string and returns an {@link ActionCodeURL} if the link is valid,
	* otherwise returns null.
	*
	* @param link  - The email action link string.
	* @returns The {@link ActionCodeURL} object, or null if the link is invalid.
	*
	* @public
	*/
	static parseLink(link) {
		const actionLink = parseDeepLink(link);
		try {
			return new ActionCodeURL(actionLink);
		} catch {
			return null;
		}
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Provider for generating {@link EmailAuthCredential}.
*
* @public
*/
var EmailAuthProvider = class EmailAuthProvider {
	constructor() {
		/**
		* Always set to {@link ProviderId}.PASSWORD, even for email link.
		*/
		this.providerId = EmailAuthProvider.PROVIDER_ID;
	}
	/**
	* Initialize an {@link AuthCredential} using an email and password.
	*
	* @example
	* ```javascript
	* const authCredential = EmailAuthProvider.credential(email, password);
	* const userCredential = await signInWithCredential(auth, authCredential);
	* ```
	*
	* @example
	* ```javascript
	* const userCredential = await signInWithEmailAndPassword(auth, email, password);
	* ```
	*
	* @param email - Email address.
	* @param password - User account password.
	* @returns The auth provider credential.
	*/
	static credential(email, password) {
		return EmailAuthCredential._fromEmailAndPassword(email, password);
	}
	/**
	* Initialize an {@link AuthCredential} using an email and an email link after a sign in with
	* email link operation.
	*
	* @example
	* ```javascript
	* const authCredential = EmailAuthProvider.credentialWithLink(auth, email, emailLink);
	* const userCredential = await signInWithCredential(auth, authCredential);
	* ```
	*
	* @example
	* ```javascript
	* await sendSignInLinkToEmail(auth, email);
	* // Obtain emailLink from user.
	* const userCredential = await signInWithEmailLink(auth, email, emailLink);
	* ```
	*
	* @param auth - The {@link Auth} instance used to verify the link.
	* @param email - Email address.
	* @param emailLink - Sign-in email link.
	* @returns - The auth provider credential.
	*/
	static credentialWithLink(email, emailLink) {
		const actionCodeUrl = ActionCodeURL.parseLink(emailLink);
		_assert(actionCodeUrl, "argument-error");
		return EmailAuthCredential._fromEmailAndCode(email, actionCodeUrl.code, actionCodeUrl.tenantId);
	}
};
/**
* Always set to {@link ProviderId}.PASSWORD, even for email link.
*/
EmailAuthProvider.PROVIDER_ID = "password";
/**
* Always set to {@link SignInMethod}.EMAIL_PASSWORD.
*/
EmailAuthProvider.EMAIL_PASSWORD_SIGN_IN_METHOD = "password";
/**
* Always set to {@link SignInMethod}.EMAIL_LINK.
*/
EmailAuthProvider.EMAIL_LINK_SIGN_IN_METHOD = "emailLink";
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* The base class for all Federated providers (OAuth (including OIDC), SAML).
*
* This class is not meant to be instantiated directly.
*
* @public
*/
var FederatedAuthProvider = class {
	/**
	* Constructor for generic OAuth providers.
	*
	* @param providerId - Provider for which credentials should be generated.
	*/
	constructor(providerId) {
		this.providerId = providerId;
		/** @internal */
		this.defaultLanguageCode = null;
		/** @internal */
		this.customParameters = {};
	}
	/**
	* Set the language gode.
	*
	* @param languageCode - language code
	*/
	setDefaultLanguage(languageCode) {
		this.defaultLanguageCode = languageCode;
	}
	/**
	* Sets the OAuth custom parameters to pass in an OAuth request for popup and redirect sign-in
	* operations.
	*
	* @remarks
	* For a detailed list, check the reserved required OAuth 2.0 parameters such as `client_id`,
	* `redirect_uri`, `scope`, `response_type`, and `state` are not allowed and will be ignored.
	*
	* @param customOAuthParameters - The custom OAuth parameters to pass in the OAuth request.
	*/
	setCustomParameters(customOAuthParameters) {
		this.customParameters = customOAuthParameters;
		return this;
	}
	/**
	* Retrieve the current list of {@link CustomParameters}.
	*/
	getCustomParameters() {
		return this.customParameters;
	}
};
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Common code to all OAuth providers. This is separate from the
* {@link OAuthProvider} so that child providers (like
* {@link GoogleAuthProvider}) don't inherit the `credential` instance method.
* Instead, they rely on a static `credential` method.
*/
var BaseOAuthProvider = class extends FederatedAuthProvider {
	constructor() {
		super(...arguments);
		/** @internal */
		this.scopes = [];
	}
	/**
	* Add an OAuth scope to the credential.
	*
	* @param scope - Provider OAuth scope to add.
	*/
	addScope(scope) {
		if (!this.scopes.includes(scope)) this.scopes.push(scope);
		return this;
	}
	/**
	* Retrieve the current list of OAuth scopes.
	*/
	getScopes() {
		return [...this.scopes];
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Provider for generating an {@link OAuthCredential} for {@link ProviderId}.FACEBOOK.
*
* @example
* ```javascript
* // Sign in using a redirect.
* const provider = new FacebookAuthProvider();
* // Start a sign in process for an unauthenticated user.
* provider.addScope('user_birthday');
* await signInWithRedirect(auth, provider);
* // This will trigger a full page redirect away from your app
*
* // After returning from the redirect when your app initializes you can obtain the result
* const result = await getRedirectResult(auth);
* if (result) {
*   // This is the signed-in user
*   const user = result.user;
*   // This gives you a Facebook Access Token.
*   const credential = FacebookAuthProvider.credentialFromResult(result);
*   const token = credential.accessToken;
* }
* ```
*
* @example
* ```javascript
* // Sign in using a popup.
* const provider = new FacebookAuthProvider();
* provider.addScope('user_birthday');
* const result = await signInWithPopup(auth, provider);
*
* // The signed-in user info.
* const user = result.user;
* // This gives you a Facebook Access Token.
* const credential = FacebookAuthProvider.credentialFromResult(result);
* const token = credential.accessToken;
* ```
*
* @public
*/
var FacebookAuthProvider = class FacebookAuthProvider extends BaseOAuthProvider {
	constructor() {
		super("facebook.com");
	}
	/**
	* Creates a credential for Facebook.
	*
	* @example
	* ```javascript
	* // `event` from the Facebook auth.authResponseChange callback.
	* const credential = FacebookAuthProvider.credential(event.authResponse.accessToken);
	* const result = await signInWithCredential(credential);
	* ```
	*
	* @param accessToken - Facebook access token.
	*/
	static credential(accessToken) {
		return OAuthCredential._fromParams({
			providerId: FacebookAuthProvider.PROVIDER_ID,
			signInMethod: FacebookAuthProvider.FACEBOOK_SIGN_IN_METHOD,
			accessToken
		});
	}
	/**
	* Used to extract the underlying {@link OAuthCredential} from a {@link UserCredential}.
	*
	* @param userCredential - The user credential.
	*/
	static credentialFromResult(userCredential) {
		return FacebookAuthProvider.credentialFromTaggedObject(userCredential);
	}
	/**
	* Used to extract the underlying {@link OAuthCredential} from a {@link AuthError} which was
	* thrown during a sign-in, link, or reauthenticate operation.
	*
	* @param userCredential - The user credential.
	*/
	static credentialFromError(error) {
		return FacebookAuthProvider.credentialFromTaggedObject(error.customData || {});
	}
	static credentialFromTaggedObject({ _tokenResponse: tokenResponse }) {
		if (!tokenResponse || !("oauthAccessToken" in tokenResponse)) return null;
		if (!tokenResponse.oauthAccessToken) return null;
		try {
			return FacebookAuthProvider.credential(tokenResponse.oauthAccessToken);
		} catch {
			return null;
		}
	}
};
/** Always set to {@link SignInMethod}.FACEBOOK. */
FacebookAuthProvider.FACEBOOK_SIGN_IN_METHOD = "facebook.com";
/** Always set to {@link ProviderId}.FACEBOOK. */
FacebookAuthProvider.PROVIDER_ID = "facebook.com";
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Provider for generating an {@link OAuthCredential} for {@link ProviderId}.GOOGLE.
*
* @example
* ```javascript
* // Sign in using a redirect.
* const provider = new GoogleAuthProvider();
* // Start a sign in process for an unauthenticated user.
* provider.addScope('profile');
* provider.addScope('email');
* await signInWithRedirect(auth, provider);
* // This will trigger a full page redirect away from your app
*
* // After returning from the redirect when your app initializes you can obtain the result
* const result = await getRedirectResult(auth);
* if (result) {
*   // This is the signed-in user
*   const user = result.user;
*   // This gives you a Google Access Token.
*   const credential = GoogleAuthProvider.credentialFromResult(result);
*   const token = credential.accessToken;
* }
* ```
*
* @example
* ```javascript
* // Sign in using a popup.
* const provider = new GoogleAuthProvider();
* provider.addScope('profile');
* provider.addScope('email');
* const result = await signInWithPopup(auth, provider);
*
* // The signed-in user info.
* const user = result.user;
* // This gives you a Google Access Token.
* const credential = GoogleAuthProvider.credentialFromResult(result);
* const token = credential.accessToken;
* ```
*
* @public
*/
var GoogleAuthProvider = class GoogleAuthProvider extends BaseOAuthProvider {
	constructor() {
		super("google.com");
		this.addScope("profile");
	}
	/**
	* Creates a credential for Google. At least one of ID token and access token is required.
	*
	* @example
	* ```javascript
	* // \`googleUser\` from the onsuccess Google Sign In callback.
	* const credential = GoogleAuthProvider.credential(googleUser.getAuthResponse().id_token);
	* const result = await signInWithCredential(credential);
	* ```
	*
	* @param idToken - Google ID token.
	* @param accessToken - Google access token.
	*/
	static credential(idToken, accessToken) {
		return OAuthCredential._fromParams({
			providerId: GoogleAuthProvider.PROVIDER_ID,
			signInMethod: GoogleAuthProvider.GOOGLE_SIGN_IN_METHOD,
			idToken,
			accessToken
		});
	}
	/**
	* Used to extract the underlying {@link OAuthCredential} from a {@link UserCredential}.
	*
	* @param userCredential - The user credential.
	*/
	static credentialFromResult(userCredential) {
		return GoogleAuthProvider.credentialFromTaggedObject(userCredential);
	}
	/**
	* Used to extract the underlying {@link OAuthCredential} from a {@link AuthError} which was
	* thrown during a sign-in, link, or reauthenticate operation.
	*
	* @param userCredential - The user credential.
	*/
	static credentialFromError(error) {
		return GoogleAuthProvider.credentialFromTaggedObject(error.customData || {});
	}
	static credentialFromTaggedObject({ _tokenResponse: tokenResponse }) {
		if (!tokenResponse) return null;
		const { oauthIdToken, oauthAccessToken } = tokenResponse;
		if (!oauthIdToken && !oauthAccessToken) return null;
		try {
			return GoogleAuthProvider.credential(oauthIdToken, oauthAccessToken);
		} catch {
			return null;
		}
	}
};
/** Always set to {@link SignInMethod}.GOOGLE. */
GoogleAuthProvider.GOOGLE_SIGN_IN_METHOD = "google.com";
/** Always set to {@link ProviderId}.GOOGLE. */
GoogleAuthProvider.PROVIDER_ID = "google.com";
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Provider for generating an {@link OAuthCredential} for {@link ProviderId}.GITHUB.
*
* @remarks
* GitHub requires an OAuth 2.0 redirect, so you can either handle the redirect directly, or use
* the {@link signInWithPopup} handler:
*
* @example
* ```javascript
* // Sign in using a redirect.
* const provider = new GithubAuthProvider();
* // Start a sign in process for an unauthenticated user.
* provider.addScope('repo');
* await signInWithRedirect(auth, provider);
* // This will trigger a full page redirect away from your app
*
* // After returning from the redirect when your app initializes you can obtain the result
* const result = await getRedirectResult(auth);
* if (result) {
*   // This is the signed-in user
*   const user = result.user;
*   // This gives you a GitHub Access Token.
*   const credential = GithubAuthProvider.credentialFromResult(result);
*   const token = credential.accessToken;
* }
* ```
*
* @example
* ```javascript
* // Sign in using a popup.
* const provider = new GithubAuthProvider();
* provider.addScope('repo');
* const result = await signInWithPopup(auth, provider);
*
* // The signed-in user info.
* const user = result.user;
* // This gives you a GitHub Access Token.
* const credential = GithubAuthProvider.credentialFromResult(result);
* const token = credential.accessToken;
* ```
* @public
*/
var GithubAuthProvider = class GithubAuthProvider extends BaseOAuthProvider {
	constructor() {
		super("github.com");
	}
	/**
	* Creates a credential for GitHub.
	*
	* @param accessToken - GitHub access token.
	*/
	static credential(accessToken) {
		return OAuthCredential._fromParams({
			providerId: GithubAuthProvider.PROVIDER_ID,
			signInMethod: GithubAuthProvider.GITHUB_SIGN_IN_METHOD,
			accessToken
		});
	}
	/**
	* Used to extract the underlying {@link OAuthCredential} from a {@link UserCredential}.
	*
	* @param userCredential - The user credential.
	*/
	static credentialFromResult(userCredential) {
		return GithubAuthProvider.credentialFromTaggedObject(userCredential);
	}
	/**
	* Used to extract the underlying {@link OAuthCredential} from a {@link AuthError} which was
	* thrown during a sign-in, link, or reauthenticate operation.
	*
	* @param userCredential - The user credential.
	*/
	static credentialFromError(error) {
		return GithubAuthProvider.credentialFromTaggedObject(error.customData || {});
	}
	static credentialFromTaggedObject({ _tokenResponse: tokenResponse }) {
		if (!tokenResponse || !("oauthAccessToken" in tokenResponse)) return null;
		if (!tokenResponse.oauthAccessToken) return null;
		try {
			return GithubAuthProvider.credential(tokenResponse.oauthAccessToken);
		} catch {
			return null;
		}
	}
};
/** Always set to {@link SignInMethod}.GITHUB. */
GithubAuthProvider.GITHUB_SIGN_IN_METHOD = "github.com";
/** Always set to {@link ProviderId}.GITHUB. */
GithubAuthProvider.PROVIDER_ID = "github.com";
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Provider for generating an {@link OAuthCredential} for {@link ProviderId}.TWITTER.
*
* @example
* ```javascript
* // Sign in using a redirect.
* const provider = new TwitterAuthProvider();
* // Start a sign in process for an unauthenticated user.
* await signInWithRedirect(auth, provider);
* // This will trigger a full page redirect away from your app
*
* // After returning from the redirect when your app initializes you can obtain the result
* const result = await getRedirectResult(auth);
* if (result) {
*   // This is the signed-in user
*   const user = result.user;
*   // This gives you a Twitter Access Token and Secret.
*   const credential = TwitterAuthProvider.credentialFromResult(result);
*   const token = credential.accessToken;
*   const secret = credential.secret;
* }
* ```
*
* @example
* ```javascript
* // Sign in using a popup.
* const provider = new TwitterAuthProvider();
* const result = await signInWithPopup(auth, provider);
*
* // The signed-in user info.
* const user = result.user;
* // This gives you a Twitter Access Token and Secret.
* const credential = TwitterAuthProvider.credentialFromResult(result);
* const token = credential.accessToken;
* const secret = credential.secret;
* ```
*
* @public
*/
var TwitterAuthProvider = class TwitterAuthProvider extends BaseOAuthProvider {
	constructor() {
		super("twitter.com");
	}
	/**
	* Creates a credential for Twitter.
	*
	* @param token - Twitter access token.
	* @param secret - Twitter secret.
	*/
	static credential(token, secret) {
		return OAuthCredential._fromParams({
			providerId: TwitterAuthProvider.PROVIDER_ID,
			signInMethod: TwitterAuthProvider.TWITTER_SIGN_IN_METHOD,
			oauthToken: token,
			oauthTokenSecret: secret
		});
	}
	/**
	* Used to extract the underlying {@link OAuthCredential} from a {@link UserCredential}.
	*
	* @param userCredential - The user credential.
	*/
	static credentialFromResult(userCredential) {
		return TwitterAuthProvider.credentialFromTaggedObject(userCredential);
	}
	/**
	* Used to extract the underlying {@link OAuthCredential} from a {@link AuthError} which was
	* thrown during a sign-in, link, or reauthenticate operation.
	*
	* @param userCredential - The user credential.
	*/
	static credentialFromError(error) {
		return TwitterAuthProvider.credentialFromTaggedObject(error.customData || {});
	}
	static credentialFromTaggedObject({ _tokenResponse: tokenResponse }) {
		if (!tokenResponse) return null;
		const { oauthAccessToken, oauthTokenSecret } = tokenResponse;
		if (!oauthAccessToken || !oauthTokenSecret) return null;
		try {
			return TwitterAuthProvider.credential(oauthAccessToken, oauthTokenSecret);
		} catch {
			return null;
		}
	}
};
/** Always set to {@link SignInMethod}.TWITTER. */
TwitterAuthProvider.TWITTER_SIGN_IN_METHOD = "twitter.com";
/** Always set to {@link ProviderId}.TWITTER. */
TwitterAuthProvider.PROVIDER_ID = "twitter.com";
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
async function signUp(auth, request) {
	return _performSignInRequest(auth, "POST", "/v1/accounts:signUp", _addTidIfNecessary(auth, request));
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var UserCredentialImpl = class UserCredentialImpl {
	constructor(params) {
		this.user = params.user;
		this.providerId = params.providerId;
		this._tokenResponse = params._tokenResponse;
		this.operationType = params.operationType;
	}
	static async _fromIdTokenResponse(auth, operationType, idTokenResponse, isAnonymous = false) {
		const user = await UserImpl._fromIdTokenResponse(auth, idTokenResponse, isAnonymous);
		const providerId = providerIdForResponse(idTokenResponse);
		return new UserCredentialImpl({
			user,
			providerId,
			_tokenResponse: idTokenResponse,
			operationType
		});
	}
	static async _forOperation(user, operationType, response) {
		await user._updateTokensIfNecessary(response, true);
		const providerId = providerIdForResponse(response);
		return new UserCredentialImpl({
			user,
			providerId,
			_tokenResponse: response,
			operationType
		});
	}
};
function providerIdForResponse(response) {
	if (response.providerId) return response.providerId;
	if ("phoneNumber" in response) return "phone";
	return null;
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Asynchronously signs in as an anonymous user.
*
* @remarks
* If there is already an anonymous user signed in, that user will be returned; otherwise, a
* new anonymous user identity will be created and returned.
*
* This method is not supported by {@link Auth} instances created with a
* {@link @firebase/app#FirebaseServerApp}.
*
* @param auth - The {@link Auth} instance.
*
* @public
*/
async function signInAnonymously(auth) {
	if (_isFirebaseServerApp(auth.app)) return Promise.reject(_serverAppCurrentUserOperationNotSupportedError(auth));
	const authInternal = _castAuth(auth);
	await authInternal._initializationPromise;
	if (authInternal.currentUser?.isAnonymous) return new UserCredentialImpl({
		user: authInternal.currentUser,
		providerId: null,
		operationType: "signIn"
	});
	const response = await signUp(authInternal, { returnSecureToken: true });
	const userCredential = await UserCredentialImpl._fromIdTokenResponse(authInternal, "signIn", response, true);
	await authInternal._updateCurrentUser(userCredential.user);
	return userCredential;
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var MultiFactorError = class MultiFactorError extends FirebaseError {
	constructor(auth, error, operationType, user) {
		super(error.code, error.message);
		this.operationType = operationType;
		this.user = user;
		Object.setPrototypeOf(this, MultiFactorError.prototype);
		this.customData = {
			appName: auth.name,
			tenantId: auth.tenantId ?? void 0,
			_serverResponse: error.customData._serverResponse,
			operationType
		};
	}
	static _fromErrorAndOperation(auth, error, operationType, user) {
		return new MultiFactorError(auth, error, operationType, user);
	}
};
function _processCredentialSavingMfaContextIfNecessary(auth, operationType, credential, user) {
	return (operationType === "reauthenticate" ? credential._getReauthenticationResolver(auth) : credential._getIdTokenResponse(auth)).catch((error) => {
		if (error.code === `auth/multi-factor-auth-required`) throw MultiFactorError._fromErrorAndOperation(auth, error, operationType, user);
		throw error;
	});
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
async function _link$1(user, credential, bypassAuthState = false) {
	const response = await _logoutIfInvalidated(user, credential._linkToIdToken(user.auth, await user.getIdToken()), bypassAuthState);
	return UserCredentialImpl._forOperation(user, "link", response);
}
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
async function _reauthenticate(user, credential, bypassAuthState = false) {
	const { auth } = user;
	if (_isFirebaseServerApp(auth.app)) return Promise.reject(_serverAppCurrentUserOperationNotSupportedError(auth));
	const operationType = "reauthenticate";
	try {
		const response = await _logoutIfInvalidated(user, _processCredentialSavingMfaContextIfNecessary(auth, operationType, credential, user), bypassAuthState);
		_assert(response.idToken, auth, "internal-error");
		const parsed = _parseToken(response.idToken);
		_assert(parsed, auth, "internal-error");
		const { sub: localId } = parsed;
		_assert(user.uid === localId, auth, "user-mismatch");
		return UserCredentialImpl._forOperation(user, operationType, response);
	} catch (e) {
		if (e?.code === `auth/user-not-found`) _fail(auth, "user-mismatch");
		throw e;
	}
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
async function _signInWithCredential(auth, credential, bypassAuthState = false) {
	if (_isFirebaseServerApp(auth.app)) return Promise.reject(_serverAppCurrentUserOperationNotSupportedError(auth));
	const operationType = "signIn";
	const response = await _processCredentialSavingMfaContextIfNecessary(auth, operationType, credential);
	const userCredential = await UserCredentialImpl._fromIdTokenResponse(auth, operationType, response);
	if (!bypassAuthState) await auth._updateCurrentUser(userCredential.user);
	return userCredential;
}
/**
* Asynchronously signs in with the given credentials.
*
* @remarks
* An {@link AuthProvider} can be used to generate the credential.
*
* This method is not supported by {@link Auth} instances created with a
* {@link @firebase/app#FirebaseServerApp}.
*
* @param auth - The {@link Auth} instance.
* @param credential - The auth credential.
*
* @public
*/
async function signInWithCredential(auth, credential) {
	return _signInWithCredential(_castAuth(auth), credential);
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Updates the password policy cached in the {@link Auth} instance if a policy is already
* cached for the project or tenant.
*
* @remarks
* We only fetch the password policy if the password did not meet policy requirements and
* there is an existing policy cached. A developer must call validatePassword at least
* once for the cache to be automatically updated.
*
* @param auth - The {@link Auth} instance.
*
* @private
*/
async function recachePasswordPolicy(auth) {
	const authInternal = _castAuth(auth);
	if (authInternal._getPasswordPolicyInternal()) await authInternal._updatePasswordPolicy();
}
/**
* Creates a new user account associated with the specified email address and password.
*
* @remarks
* On successful creation of the user account, this user will also be signed in to your application.
*
* User account creation can fail if the account already exists or the password is invalid.
*
* This method is not supported on {@link Auth} instances created with a
* {@link @firebase/app#FirebaseServerApp}.
*
* Note: The email address acts as a unique identifier for the user and enables an email-based
* password reset. This function will create a new user account and set the initial user password.
*
* @param auth - The {@link Auth} instance.
* @param email - The user's email address.
* @param password - The user's chosen password.
*
* @public
*/
async function createUserWithEmailAndPassword(auth, email, password) {
	if (_isFirebaseServerApp(auth.app)) return Promise.reject(_serverAppCurrentUserOperationNotSupportedError(auth));
	const authInternal = _castAuth(auth);
	const response = await handleRecaptchaFlow(authInternal, {
		returnSecureToken: true,
		email,
		password,
		clientType: "CLIENT_TYPE_WEB"
	}, "signUpPassword", signUp, "EMAIL_PASSWORD_PROVIDER").catch((error) => {
		if (error.code === `auth/password-does-not-meet-requirements`) recachePasswordPolicy(auth);
		throw error;
	});
	const userCredential = await UserCredentialImpl._fromIdTokenResponse(authInternal, "signIn", response);
	await authInternal._updateCurrentUser(userCredential.user);
	return userCredential;
}
/**
* Asynchronously signs in using an email and password.
*
* @remarks
* Fails with an error if the email address and password do not match. When
* {@link https://cloud.google.com/identity-platform/docs/admin/email-enumeration-protection | Email Enumeration Protection}
* is enabled, this method fails with "auth/invalid-credential" in case of an invalid
* email/password.
*
* This method is not supported on {@link Auth} instances created with a
* {@link @firebase/app#FirebaseServerApp}.
*
* Note: The user's password is NOT the password used to access the user's email account. The
* email address serves as a unique identifier for the user, and the password is used to access
* the user's account in your Firebase project. See also: {@link createUserWithEmailAndPassword}.
*
*
* @param auth - The {@link Auth} instance.
* @param email - The users email address.
* @param password - The users password.
*
* @public
*/
function signInWithEmailAndPassword(auth, email, password) {
	if (_isFirebaseServerApp(auth.app)) return Promise.reject(_serverAppCurrentUserOperationNotSupportedError(auth));
	return signInWithCredential(getModularInstance(auth), EmailAuthProvider.credential(email, password)).catch(async (error) => {
		if (error.code === `auth/password-does-not-meet-requirements`) recachePasswordPolicy(auth);
		throw error;
	});
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Adds an observer for changes to the signed-in user's ID token.
*
* @remarks
* This includes sign-in, sign-out, and token refresh events.
* This will not be triggered automatically upon ID token expiration. Use {@link User.getIdToken} to refresh the ID token.
*
* @param auth - The {@link Auth} instance.
* @param nextOrObserver - callback triggered on change.
* @param error - Deprecated. This callback is never triggered. Errors
* on signing in/out can be caught in promises returned from
* sign-in/sign-out functions.
* @param completed - Deprecated. This callback is never triggered.
*
* @public
*/
function onIdTokenChanged(auth, nextOrObserver, error, completed) {
	return getModularInstance(auth).onIdTokenChanged(nextOrObserver, error, completed);
}
/**
* Adds a blocking callback that runs before an auth state change
* sets a new user.
*
* @param auth - The {@link Auth} instance.
* @param callback - callback triggered before new user value is set.
*   If this throws, it blocks the user from being set.
* @param onAbort - callback triggered if a later `beforeAuthStateChanged()`
*   callback throws, allowing you to undo any side effects.
*/
function beforeAuthStateChanged(auth, callback, onAbort) {
	return getModularInstance(auth).beforeAuthStateChanged(callback, onAbort);
}
/**
* Adds an observer for changes to the user's sign-in state.
*
* @remarks
* To keep the old behavior, see {@link onIdTokenChanged}.
*
* @param auth - The {@link Auth} instance.
* @param nextOrObserver - callback triggered on change.
* @param error - Deprecated. This callback is never triggered. Errors
* on signing in/out can be caught in promises returned from
* sign-in/sign-out functions.
* @param completed - Deprecated. This callback is never triggered.
*
* @public
*/
function onAuthStateChanged(auth, nextOrObserver, error, completed) {
	return getModularInstance(auth).onAuthStateChanged(nextOrObserver, error, completed);
}
/**
* Signs out the current user.
*
* @remarks
* This method is not supported by {@link Auth} instances created with a
* {@link @firebase/app#FirebaseServerApp}.
*
* @param auth - The {@link Auth} instance.
*
* @public
*/
function signOut(auth) {
	return getModularInstance(auth).signOut();
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function startEnrollPhoneMfa(auth, request) {
	return _performApiRequest(auth, "POST", "/v2/accounts/mfaEnrollment:start", _addTidIfNecessary(auth, request));
}
function finalizeEnrollPhoneMfa(auth, request) {
	return _performApiRequest(auth, "POST", "/v2/accounts/mfaEnrollment:finalize", _addTidIfNecessary(auth, request));
}
function startEnrollTotpMfa(auth, request) {
	return _performApiRequest(auth, "POST", "/v2/accounts/mfaEnrollment:start", _addTidIfNecessary(auth, request));
}
function finalizeEnrollTotpMfa(auth, request) {
	return _performApiRequest(auth, "POST", "/v2/accounts/mfaEnrollment:finalize", _addTidIfNecessary(auth, request));
}
var STORAGE_AVAILABLE_KEY = "__sak";
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var BrowserPersistenceClass = class {
	constructor(storageRetriever, type) {
		this.storageRetriever = storageRetriever;
		this.type = type;
	}
	_isAvailable() {
		try {
			if (!this.storage) return Promise.resolve(false);
			this.storage.setItem(STORAGE_AVAILABLE_KEY, "1");
			this.storage.removeItem(STORAGE_AVAILABLE_KEY);
			return Promise.resolve(true);
		} catch {
			return Promise.resolve(false);
		}
	}
	_set(key, value) {
		this.storage.setItem(key, JSON.stringify(value));
		return Promise.resolve();
	}
	_get(key) {
		const json = this.storage.getItem(key);
		return Promise.resolve(json ? JSON.parse(json) : null);
	}
	_remove(key) {
		this.storage.removeItem(key);
		return Promise.resolve();
	}
	get storage() {
		return this.storageRetriever();
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var _POLLING_INTERVAL_MS$1 = 1e3;
var IE10_LOCAL_STORAGE_SYNC_DELAY = 10;
var BrowserLocalPersistence = class extends BrowserPersistenceClass {
	constructor() {
		super(() => window.localStorage, "LOCAL");
		this.boundEventHandler = (event, poll) => this.onStorageEvent(event, poll);
		this.listeners = {};
		this.localCache = {};
		this.pollTimer = null;
		this.fallbackToPolling = _isMobileBrowser();
		this._shouldAllowMigration = true;
	}
	forAllChangedKeys(cb) {
		for (const key of Object.keys(this.listeners)) {
			const newValue = this.storage.getItem(key);
			const oldValue = this.localCache[key];
			if (newValue !== oldValue) cb(key, oldValue, newValue);
		}
	}
	onStorageEvent(event, poll = false) {
		if (!event.key) {
			this.forAllChangedKeys((key, _oldValue, newValue) => {
				this.notifyListeners(key, newValue);
			});
			return;
		}
		const key = event.key;
		if (poll) this.detachListener();
		else this.stopPolling();
		const triggerListeners = () => {
			const storedValue = this.storage.getItem(key);
			if (!poll && this.localCache[key] === storedValue) return;
			this.notifyListeners(key, storedValue);
		};
		const storedValue = this.storage.getItem(key);
		if (_isIE10() && storedValue !== event.newValue && event.newValue !== event.oldValue) setTimeout(triggerListeners, IE10_LOCAL_STORAGE_SYNC_DELAY);
		else triggerListeners();
	}
	notifyListeners(key, value) {
		this.localCache[key] = value;
		const listeners = this.listeners[key];
		if (listeners) for (const listener of Array.from(listeners)) listener(value ? JSON.parse(value) : value);
	}
	startPolling() {
		this.stopPolling();
		this.pollTimer = setInterval(() => {
			this.forAllChangedKeys((key, oldValue, newValue) => {
				this.onStorageEvent(new StorageEvent("storage", {
					key,
					oldValue,
					newValue
				}), true);
			});
		}, _POLLING_INTERVAL_MS$1);
	}
	stopPolling() {
		if (this.pollTimer) {
			clearInterval(this.pollTimer);
			this.pollTimer = null;
		}
	}
	attachListener() {
		window.addEventListener("storage", this.boundEventHandler);
	}
	detachListener() {
		window.removeEventListener("storage", this.boundEventHandler);
	}
	_addListener(key, listener) {
		if (Object.keys(this.listeners).length === 0) {
			if (this.fallbackToPolling) this.startPolling();
			else this.attachListener();
		}
		if (!this.listeners[key]) {
			this.listeners[key] = /* @__PURE__ */ new Set();
			this.localCache[key] = this.storage.getItem(key);
		}
		this.listeners[key].add(listener);
	}
	_removeListener(key, listener) {
		if (this.listeners[key]) {
			this.listeners[key].delete(listener);
			if (this.listeners[key].size === 0) delete this.listeners[key];
		}
		if (Object.keys(this.listeners).length === 0) {
			this.detachListener();
			this.stopPolling();
		}
	}
	async _set(key, value) {
		await super._set(key, value);
		this.localCache[key] = JSON.stringify(value);
	}
	async _get(key) {
		const value = await super._get(key);
		this.localCache[key] = JSON.stringify(value);
		return value;
	}
	async _remove(key) {
		await super._remove(key);
		delete this.localCache[key];
	}
};
BrowserLocalPersistence.type = "LOCAL";
/**
* An implementation of {@link Persistence} of type `LOCAL` using `localStorage`
* for the underlying storage.
*
* @public
*/
var browserLocalPersistence = BrowserLocalPersistence;
/**
* @license
* Copyright 2025 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var POLLING_INTERVAL_MS = 1e3;
function getDocumentCookie(name) {
	const escapedName = name.replace(/[\\^$.*+?()[\]{}|]/g, "\\$&");
	const matcher = RegExp(`${escapedName}=([^;]+)`);
	return document.cookie.match(matcher)?.[1] ?? null;
}
function getCookieName(key) {
	return `${window.location.protocol === "http:" ? "__dev_" : "__HOST-"}FIREBASE_${key.split(":")[3]}`;
}
var CookiePersistence = class {
	constructor() {
		this.type = "COOKIE";
		this.listenerUnsubscribes = /* @__PURE__ */ new Map();
	}
	_getFinalTarget(originalUrl) {
		const url = new URL(`${window.location.origin}/__cookies__`);
		url.searchParams.set("finalTarget", originalUrl);
		return url;
	}
	async _isAvailable() {
		if (typeof isSecureContext === "boolean" && !isSecureContext) return false;
		if (typeof navigator === "undefined" || typeof document === "undefined") return false;
		return navigator.cookieEnabled ?? true;
	}
	async _set(_key, _value) {}
	async _get(key) {
		if (!this._isAvailable()) return null;
		const name = getCookieName(key);
		if (window.cookieStore) return (await window.cookieStore.get(name))?.value;
		return getDocumentCookie(name);
	}
	async _remove(key) {
		if (!this._isAvailable()) return;
		if (!await this._get(key)) return;
		const name = getCookieName(key);
		document.cookie = `${name}=;Max-Age=34560000;Partitioned;Secure;SameSite=Strict;Path=/;Priority=High`;
		await fetch(`/__cookies__`, { method: "DELETE" }).catch(() => void 0);
	}
	_addListener(key, listener) {
		if (!this._isAvailable()) return;
		const name = getCookieName(key);
		if (window.cookieStore) {
			const cb = ((event) => {
				const changedCookie = event.changed.find((change) => change.name === name);
				if (changedCookie) listener(changedCookie.value);
				if (event.deleted.find((change) => change.name === name)) listener(null);
			});
			const unsubscribe = () => window.cookieStore.removeEventListener("change", cb);
			this.listenerUnsubscribes.set(listener, unsubscribe);
			return window.cookieStore.addEventListener("change", cb);
		}
		let lastValue = getDocumentCookie(name);
		const interval = setInterval(() => {
			const currentValue = getDocumentCookie(name);
			if (currentValue !== lastValue) {
				listener(currentValue);
				lastValue = currentValue;
			}
		}, POLLING_INTERVAL_MS);
		const unsubscribe = () => clearInterval(interval);
		this.listenerUnsubscribes.set(listener, unsubscribe);
	}
	_removeListener(_key, listener) {
		const unsubscribe = this.listenerUnsubscribes.get(listener);
		if (!unsubscribe) return;
		unsubscribe();
		this.listenerUnsubscribes.delete(listener);
	}
};
CookiePersistence.type = "COOKIE";
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var BrowserSessionPersistence = class extends BrowserPersistenceClass {
	constructor() {
		super(() => window.sessionStorage, "SESSION");
	}
	_addListener(_key, _listener) {}
	_removeListener(_key, _listener) {}
};
BrowserSessionPersistence.type = "SESSION";
/**
* An implementation of {@link Persistence} of `SESSION` using `sessionStorage`
* for the underlying storage.
*
* @public
*/
var browserSessionPersistence = BrowserSessionPersistence;
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Shim for Promise.allSettled, note the slightly different format of `fulfilled` vs `status`.
*
* @param promises - Array of promises to wait on.
*/
function _allSettled(promises) {
	return Promise.all(promises.map(async (promise) => {
		try {
			return {
				fulfilled: true,
				value: await promise
			};
		} catch (reason) {
			return {
				fulfilled: false,
				reason
			};
		}
	}));
}
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Interface class for receiving messages.
*
*/
var Receiver = class Receiver {
	constructor(eventTarget) {
		this.eventTarget = eventTarget;
		this.handlersMap = {};
		this.boundEventHandler = this.handleEvent.bind(this);
	}
	/**
	* Obtain an instance of a Receiver for a given event target, if none exists it will be created.
	*
	* @param eventTarget - An event target (such as window or self) through which the underlying
	* messages will be received.
	*/
	static _getInstance(eventTarget) {
		const existingInstance = this.receivers.find((receiver) => receiver.isListeningto(eventTarget));
		if (existingInstance) return existingInstance;
		const newInstance = new Receiver(eventTarget);
		this.receivers.push(newInstance);
		return newInstance;
	}
	isListeningto(eventTarget) {
		return this.eventTarget === eventTarget;
	}
	/**
	* Fans out a MessageEvent to the appropriate listeners.
	*
	* @remarks
	* Sends an {@link Status.ACK} upon receipt and a {@link Status.DONE} once all handlers have
	* finished processing.
	*
	* @param event - The MessageEvent.
	*
	*/
	async handleEvent(event) {
		const messageEvent = event;
		const { eventId, eventType, data } = messageEvent.data;
		const handlers = this.handlersMap[eventType];
		if (!handlers?.size) return;
		messageEvent.ports[0].postMessage({
			status: "ack",
			eventId,
			eventType
		});
		const response = await _allSettled(Array.from(handlers).map(async (handler) => handler(messageEvent.origin, data)));
		messageEvent.ports[0].postMessage({
			status: "done",
			eventId,
			eventType,
			response
		});
	}
	/**
	* Subscribe an event handler for a particular event.
	*
	* @param eventType - Event name to subscribe to.
	* @param eventHandler - The event handler which should receive the events.
	*
	*/
	_subscribe(eventType, eventHandler) {
		if (Object.keys(this.handlersMap).length === 0) this.eventTarget.addEventListener("message", this.boundEventHandler);
		if (!this.handlersMap[eventType]) this.handlersMap[eventType] = /* @__PURE__ */ new Set();
		this.handlersMap[eventType].add(eventHandler);
	}
	/**
	* Unsubscribe an event handler from a particular event.
	*
	* @param eventType - Event name to unsubscribe from.
	* @param eventHandler - Optional event handler, if none provided, unsubscribe all handlers on this event.
	*
	*/
	_unsubscribe(eventType, eventHandler) {
		if (this.handlersMap[eventType] && eventHandler) this.handlersMap[eventType].delete(eventHandler);
		if (!eventHandler || this.handlersMap[eventType].size === 0) delete this.handlersMap[eventType];
		if (Object.keys(this.handlersMap).length === 0) this.eventTarget.removeEventListener("message", this.boundEventHandler);
	}
};
Receiver.receivers = [];
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function _generateEventId(prefix = "", digits = 10) {
	let random = "";
	for (let i = 0; i < digits; i++) random += Math.floor(Math.random() * 10);
	return prefix + random;
}
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Interface for sending messages and waiting for a completion response.
*
*/
var Sender = class {
	constructor(target) {
		this.target = target;
		this.handlers = /* @__PURE__ */ new Set();
	}
	/**
	* Unsubscribe the handler and remove it from our tracking Set.
	*
	* @param handler - The handler to unsubscribe.
	*/
	removeMessageHandler(handler) {
		if (handler.messageChannel) {
			handler.messageChannel.port1.removeEventListener("message", handler.onMessage);
			handler.messageChannel.port1.close();
		}
		this.handlers.delete(handler);
	}
	/**
	* Send a message to the Receiver located at {@link target}.
	*
	* @remarks
	* We'll first wait a bit for an ACK , if we get one we will wait significantly longer until the
	* receiver has had a chance to fully process the event.
	*
	* @param eventType - Type of event to send.
	* @param data - The payload of the event.
	* @param timeout - Timeout for waiting on an ACK from the receiver.
	*
	* @returns An array of settled promises from all the handlers that were listening on the receiver.
	*/
	async _send(eventType, data, timeout = 50) {
		const messageChannel = typeof MessageChannel !== "undefined" ? new MessageChannel() : null;
		if (!messageChannel) throw new Error("connection_unavailable");
		let completionTimer;
		let handler;
		return new Promise((resolve, reject) => {
			const eventId = _generateEventId("", 20);
			messageChannel.port1.start();
			const ackTimer = setTimeout(() => {
				reject(/* @__PURE__ */ new Error("unsupported_event"));
			}, timeout);
			handler = {
				messageChannel,
				onMessage(event) {
					const messageEvent = event;
					if (messageEvent.data.eventId !== eventId) return;
					switch (messageEvent.data.status) {
						case "ack":
							clearTimeout(ackTimer);
							completionTimer = setTimeout(() => {
								reject(/* @__PURE__ */ new Error("timeout"));
							}, 3e3);
							break;
						case "done":
							clearTimeout(completionTimer);
							resolve(messageEvent.data.response);
							break;
						default:
							clearTimeout(ackTimer);
							clearTimeout(completionTimer);
							reject(/* @__PURE__ */ new Error("invalid_response"));
					}
				}
			};
			this.handlers.add(handler);
			messageChannel.port1.addEventListener("message", handler.onMessage);
			this.target.postMessage({
				eventType,
				eventId,
				data
			}, [messageChannel.port2]);
		}).finally(() => {
			if (handler) this.removeMessageHandler(handler);
		});
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Lazy accessor for window, since the compat layer won't tree shake this out,
* we need to make sure not to mess with window unless we have to
*/
function _window() {
	return window;
}
function _setWindowLocation(url) {
	_window().location.href = url;
}
/**
* @license
* Copyright 2020 Google LLC.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function _isWorker() {
	return typeof _window()["WorkerGlobalScope"] !== "undefined" && typeof _window()["importScripts"] === "function";
}
async function _getActiveServiceWorker() {
	if (!navigator?.serviceWorker) return null;
	try {
		return (await navigator.serviceWorker.ready).active;
	} catch {
		return null;
	}
}
function _getServiceWorkerController() {
	return navigator?.serviceWorker?.controller || null;
}
function _getWorkerGlobalScope() {
	return _isWorker() ? self : null;
}
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var DB_NAME = "firebaseLocalStorageDb";
var DB_VERSION = 1;
var DB_OBJECTSTORE_NAME = "firebaseLocalStorage";
var DB_DATA_KEYPATH = "fbase_key";
/**
* Promise wrapper for IDBRequest
*
* Unfortunately we can't cleanly extend Promise<T> since promises are not callable in ES6
*
*/
var DBPromise = class {
	constructor(request) {
		this.request = request;
	}
	toPromise() {
		return new Promise((resolve, reject) => {
			this.request.addEventListener("success", () => {
				resolve(this.request.result);
			});
			this.request.addEventListener("error", () => {
				reject(this.request.error);
			});
		});
	}
};
function getObjectStore(db, isReadWrite) {
	return db.transaction([DB_OBJECTSTORE_NAME], isReadWrite ? "readwrite" : "readonly").objectStore(DB_OBJECTSTORE_NAME);
}
function _deleteDatabase() {
	return new DBPromise(indexedDB.deleteDatabase(DB_NAME)).toPromise();
}
function _openDatabase() {
	const request = indexedDB.open(DB_NAME, DB_VERSION);
	return new Promise((resolve, reject) => {
		request.addEventListener("error", () => {
			reject(request.error);
		});
		request.addEventListener("upgradeneeded", () => {
			const db = request.result;
			try {
				db.createObjectStore(DB_OBJECTSTORE_NAME, { keyPath: DB_DATA_KEYPATH });
			} catch (e) {
				reject(e);
			}
		});
		request.addEventListener("success", async () => {
			const db = request.result;
			if (!db.objectStoreNames.contains(DB_OBJECTSTORE_NAME)) {
				db.close();
				await _deleteDatabase();
				resolve(await _openDatabase());
			} else resolve(db);
		});
	});
}
async function _putObject(db, key, value) {
	return new DBPromise(getObjectStore(db, true).put({
		[DB_DATA_KEYPATH]: key,
		value
	})).toPromise();
}
async function getObject(db, key) {
	const data = await new DBPromise(getObjectStore(db, false).get(key)).toPromise();
	return data === void 0 ? null : data.value;
}
function _deleteObject(db, key) {
	return new DBPromise(getObjectStore(db, true).delete(key)).toPromise();
}
var _POLLING_INTERVAL_MS = 800;
var _TRANSACTION_RETRY_COUNT = 3;
var IndexedDBLocalPersistence = class {
	registerLifecycleListeners() {
		if (typeof window !== "undefined" && typeof window.addEventListener === "function") {
			window.addEventListener("pagehide", this.onPageHide);
			window.addEventListener("pageshow", this.onPageShow);
		}
	}
	unregisterLifecycleListeners() {
		if (typeof window !== "undefined" && typeof window.removeEventListener === "function") {
			window.removeEventListener("pagehide", this.onPageHide);
			window.removeEventListener("pageshow", this.onPageShow);
		}
	}
	constructor() {
		this.type = "LOCAL";
		this.dbPromise = null;
		this._shouldAllowMigration = true;
		this.listeners = {};
		this.localCache = {};
		this.pollTimer = null;
		this.isClosing = false;
		this.pendingWrites = 0;
		this.receiver = null;
		this.sender = null;
		this.serviceWorkerReceiverAvailable = false;
		this.activeServiceWorker = null;
		this.onPageHide = () => {
			this.isClosing = true;
			this.stopPolling();
			if (this.dbPromise) {
				this.dbPromise.then((db) => db.close()).catch(() => {});
				this.dbPromise = null;
			}
		};
		this.onPageShow = () => {
			if (this.isClosing) {
				this.isClosing = false;
				if (Object.keys(this.listeners).length > 0) this.startPolling();
			}
		};
		this._workerInitializationPromise = this.initializeServiceWorkerMessaging().then(() => {}, () => {});
	}
	async _openDb() {
		if (this.dbPromise) return this.dbPromise;
		this.dbPromise = _openDatabase();
		this.dbPromise.catch(() => {
			this.dbPromise = null;
		});
		return this.dbPromise;
	}
	async _withRetries(op) {
		let numAttempts = 0;
		while (true) try {
			return await op(await this._openDb());
		} catch (e) {
			if (numAttempts++ > _TRANSACTION_RETRY_COUNT) throw e;
			if (this.dbPromise) {
				const dbPromise = this.dbPromise;
				this.dbPromise = null;
				try {
					(await dbPromise).close();
				} catch {}
			}
		}
	}
	/**
	* IndexedDB events do not propagate from the main window to the worker context.  We rely on a
	* postMessage interface to send these events to the worker ourselves.
	*/
	async initializeServiceWorkerMessaging() {
		return _isWorker() ? this.initializeReceiver() : this.initializeSender();
	}
	/**
	* As the worker we should listen to events from the main window.
	*/
	async initializeReceiver() {
		this.receiver = Receiver._getInstance(_getWorkerGlobalScope());
		this.receiver._subscribe("keyChanged", async (_origin, data) => {
			return { keyProcessed: (await this._poll()).includes(data.key) };
		});
		this.receiver._subscribe("ping", async (_origin, _data) => {
			return ["keyChanged"];
		});
	}
	/**
	* As the main window, we should let the worker know when keys change (set and remove).
	*
	* @remarks
	* {@link https://developer.mozilla.org/en-US/docs/Web/API/ServiceWorkerContainer/ready | ServiceWorkerContainer.ready}
	* may not resolve.
	*/
	async initializeSender() {
		this.activeServiceWorker = await _getActiveServiceWorker();
		if (!this.activeServiceWorker) return;
		this.sender = new Sender(this.activeServiceWorker);
		const results = await this.sender._send("ping", {}, 800);
		if (!results) return;
		if (results[0]?.fulfilled && results[0]?.value.includes("keyChanged")) this.serviceWorkerReceiverAvailable = true;
	}
	/**
	* Let the worker know about a changed key, the exact key doesn't technically matter since the
	* worker will just trigger a full sync anyway.
	*
	* @remarks
	* For now, we only support one service worker per page.
	*
	* @param key - Storage key which changed.
	*/
	async notifyServiceWorker(key) {
		if (!this.sender || !this.activeServiceWorker || _getServiceWorkerController() !== this.activeServiceWorker) return;
		try {
			await this.sender._send("keyChanged", { key }, this.serviceWorkerReceiverAvailable ? 800 : 50);
		} catch {}
	}
	async _isAvailable() {
		try {
			if (!indexedDB) return false;
			await this._withRetries(async (db) => {
				await _putObject(db, STORAGE_AVAILABLE_KEY, "1");
				await _deleteObject(db, STORAGE_AVAILABLE_KEY);
			});
			return true;
		} catch {}
		return false;
	}
	async _withPendingWrite(write) {
		this.pendingWrites++;
		try {
			await write();
		} finally {
			this.pendingWrites--;
		}
	}
	async _set(key, value) {
		return this._withPendingWrite(async () => {
			await this._withRetries((db) => _putObject(db, key, value));
			this.localCache[key] = value;
			return this.notifyServiceWorker(key);
		});
	}
	async _get(key) {
		const obj = await this._withRetries((db) => getObject(db, key));
		this.localCache[key] = obj;
		return obj;
	}
	async _remove(key) {
		return this._withPendingWrite(async () => {
			await this._withRetries((db) => _deleteObject(db, key));
			delete this.localCache[key];
			return this.notifyServiceWorker(key);
		});
	}
	async _poll() {
		if (this.isClosing) return [];
		try {
			const result = await this._withRetries((db) => {
				return new DBPromise(getObjectStore(db, false).getAll()).toPromise();
			});
			if (this.isClosing) return [];
			if (!result) return [];
			if (this.pendingWrites !== 0) return [];
			const keys = [];
			const keysInResult = /* @__PURE__ */ new Set();
			if (result.length !== 0) for (const { fbase_key: key, value } of result) {
				keysInResult.add(key);
				if (JSON.stringify(this.localCache[key]) !== JSON.stringify(value)) {
					this.notifyListeners(key, value);
					keys.push(key);
				}
			}
			for (const localKey of Object.keys(this.localCache)) if (this.localCache[localKey] && !keysInResult.has(localKey)) {
				this.notifyListeners(localKey, null);
				keys.push(localKey);
			}
			return keys;
		} catch (e) {
			if (!this.isClosing) _logWarn(`Firebase Auth cross-tab polling failed with error: ${e}`);
			return [];
		}
	}
	notifyListeners(key, newValue) {
		this.localCache[key] = newValue;
		const listeners = this.listeners[key];
		if (listeners) for (const listener of Array.from(listeners)) listener(newValue);
	}
	startPolling() {
		this.stopPolling();
		this.pollTimer = setInterval(async () => this._poll(), _POLLING_INTERVAL_MS);
	}
	stopPolling() {
		if (this.pollTimer) {
			clearInterval(this.pollTimer);
			this.pollTimer = null;
		}
	}
	_addListener(key, listener) {
		if (Object.keys(this.listeners).length === 0) {
			this.startPolling();
			this.registerLifecycleListeners();
		}
		if (!this.listeners[key]) {
			this.listeners[key] = /* @__PURE__ */ new Set();
			this._get(key);
		}
		this.listeners[key].add(listener);
	}
	_removeListener(key, listener) {
		if (this.listeners[key]) {
			this.listeners[key].delete(listener);
			if (this.listeners[key].size === 0) delete this.listeners[key];
		}
		if (Object.keys(this.listeners).length === 0) {
			this.stopPolling();
			this.unregisterLifecycleListeners();
		}
	}
};
IndexedDBLocalPersistence.type = "LOCAL";
/**
* An implementation of {@link Persistence} of type `LOCAL` using `indexedDB`
* for the underlying storage.
*
* @public
*/
var indexedDBLocalPersistence = IndexedDBLocalPersistence;
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function startSignInPhoneMfa(auth, request) {
	return _performApiRequest(auth, "POST", "/v2/accounts/mfaSignIn:start", _addTidIfNecessary(auth, request));
}
function finalizeSignInPhoneMfa(auth, request) {
	return _performApiRequest(auth, "POST", "/v2/accounts/mfaSignIn:finalize", _addTidIfNecessary(auth, request));
}
function finalizeSignInTotpMfa(auth, request) {
	return _performApiRequest(auth, "POST", "/v2/accounts/mfaSignIn:finalize", _addTidIfNecessary(auth, request));
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
_generateCallbackName("rcb");
new Delay(3e4, 6e4);
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var RECAPTCHA_VERIFIER_TYPE = "recaptcha";
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Returns a verification ID to be used in conjunction with the SMS code that is sent.
*
*/
async function _verifyPhoneNumber(auth, options, verifier) {
	if (!auth._getRecaptchaConfig()) try {
		await _initializeRecaptchaConfig(auth);
	} catch (error) {
		console.log("Failed to initialize reCAPTCHA Enterprise config. Triggering the reCAPTCHA v2 verification.");
	}
	try {
		let phoneInfoOptions;
		if (typeof options === "string") phoneInfoOptions = { phoneNumber: options };
		else phoneInfoOptions = options;
		if ("session" in phoneInfoOptions) {
			const session = phoneInfoOptions.session;
			if ("phoneNumber" in phoneInfoOptions) {
				_assert(session.type === "enroll", auth, "internal-error");
				const startPhoneMfaEnrollmentRequest = {
					idToken: session.credential,
					phoneEnrollmentInfo: {
						phoneNumber: phoneInfoOptions.phoneNumber,
						clientType: "CLIENT_TYPE_WEB"
					}
				};
				const startEnrollPhoneMfaActionCallback = async (authInstance, request) => {
					if (request.phoneEnrollmentInfo.captchaResponse === FAKE_TOKEN) {
						_assert(verifier?.type === RECAPTCHA_VERIFIER_TYPE, authInstance, "argument-error");
						return startEnrollPhoneMfa(authInstance, await injectRecaptchaV2Token(authInstance, request, verifier));
					}
					return startEnrollPhoneMfa(authInstance, request);
				};
				return (await handleRecaptchaFlow(auth, startPhoneMfaEnrollmentRequest, "mfaSmsEnrollment", startEnrollPhoneMfaActionCallback, "PHONE_PROVIDER").catch((error) => {
					return Promise.reject(error);
				})).phoneSessionInfo.sessionInfo;
			} else {
				_assert(session.type === "signin", auth, "internal-error");
				const mfaEnrollmentId = phoneInfoOptions.multiFactorHint?.uid || phoneInfoOptions.multiFactorUid;
				_assert(mfaEnrollmentId, auth, "missing-multi-factor-info");
				const startPhoneMfaSignInRequest = {
					mfaPendingCredential: session.credential,
					mfaEnrollmentId,
					phoneSignInInfo: { clientType: "CLIENT_TYPE_WEB" }
				};
				const startSignInPhoneMfaActionCallback = async (authInstance, request) => {
					if (request.phoneSignInInfo.captchaResponse === FAKE_TOKEN) {
						_assert(verifier?.type === RECAPTCHA_VERIFIER_TYPE, authInstance, "argument-error");
						return startSignInPhoneMfa(authInstance, await injectRecaptchaV2Token(authInstance, request, verifier));
					}
					return startSignInPhoneMfa(authInstance, request);
				};
				return (await handleRecaptchaFlow(auth, startPhoneMfaSignInRequest, "mfaSmsSignIn", startSignInPhoneMfaActionCallback, "PHONE_PROVIDER").catch((error) => {
					return Promise.reject(error);
				})).phoneResponseInfo.sessionInfo;
			}
		} else {
			const sendPhoneVerificationCodeRequest = {
				phoneNumber: phoneInfoOptions.phoneNumber,
				clientType: "CLIENT_TYPE_WEB"
			};
			const sendPhoneVerificationCodeActionCallback = async (authInstance, request) => {
				if (request.captchaResponse === FAKE_TOKEN) {
					_assert(verifier?.type === RECAPTCHA_VERIFIER_TYPE, authInstance, "argument-error");
					return sendPhoneVerificationCode(authInstance, await injectRecaptchaV2Token(authInstance, request, verifier));
				}
				return sendPhoneVerificationCode(authInstance, request);
			};
			return (await handleRecaptchaFlow(auth, sendPhoneVerificationCodeRequest, "sendVerificationCode", sendPhoneVerificationCodeActionCallback, "PHONE_PROVIDER").catch((error) => {
				return Promise.reject(error);
			})).sessionInfo;
		}
	} finally {
		verifier?._reset();
	}
}
async function injectRecaptchaV2Token(auth, request, recaptchaV2Verifier) {
	_assert(recaptchaV2Verifier.type === RECAPTCHA_VERIFIER_TYPE, auth, "argument-error");
	const recaptchaV2Token = await recaptchaV2Verifier.verify();
	_assert(typeof recaptchaV2Token === "string", auth, "argument-error");
	const newRequest = { ...request };
	if ("phoneEnrollmentInfo" in newRequest) {
		const phoneNumber = newRequest.phoneEnrollmentInfo.phoneNumber;
		const captchaResponse = newRequest.phoneEnrollmentInfo.captchaResponse;
		const clientType = newRequest.phoneEnrollmentInfo.clientType;
		const recaptchaVersion = newRequest.phoneEnrollmentInfo.recaptchaVersion;
		Object.assign(newRequest, { "phoneEnrollmentInfo": {
			phoneNumber,
			recaptchaToken: recaptchaV2Token,
			captchaResponse,
			clientType,
			recaptchaVersion
		} });
		return newRequest;
	} else if ("phoneSignInInfo" in newRequest) {
		const captchaResponse = newRequest.phoneSignInInfo.captchaResponse;
		const clientType = newRequest.phoneSignInInfo.clientType;
		const recaptchaVersion = newRequest.phoneSignInInfo.recaptchaVersion;
		Object.assign(newRequest, { "phoneSignInInfo": {
			recaptchaToken: recaptchaV2Token,
			captchaResponse,
			clientType,
			recaptchaVersion
		} });
		return newRequest;
	} else {
		Object.assign(newRequest, { "recaptchaToken": recaptchaV2Token });
		return newRequest;
	}
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Provider for generating an {@link PhoneAuthCredential}.
*
* @remarks
* `PhoneAuthProvider` does not work in a Node.js environment.
*
* @example
* ```javascript
* // 'recaptcha-container' is the ID of an element in the DOM.
* const applicationVerifier = new RecaptchaVerifier('recaptcha-container');
* const provider = new PhoneAuthProvider(auth);
* const verificationId = await provider.verifyPhoneNumber('+16505550101', applicationVerifier);
* // Obtain the verificationCode from the user.
* const phoneCredential = PhoneAuthProvider.credential(verificationId, verificationCode);
* const userCredential = await signInWithCredential(auth, phoneCredential);
* ```
*
* @public
*/
var PhoneAuthProvider = class PhoneAuthProvider {
	/**
	* @param auth - The Firebase {@link Auth} instance in which sign-ins should occur.
	*
	*/
	constructor(auth) {
		/** Always set to {@link ProviderId}.PHONE. */
		this.providerId = PhoneAuthProvider.PROVIDER_ID;
		this.auth = _castAuth(auth);
	}
	/**
	*
	* Starts a phone number authentication flow by sending a verification code to the given phone
	* number.
	*
	* @example
	* ```javascript
	* const provider = new PhoneAuthProvider(auth);
	* const verificationId = await provider.verifyPhoneNumber(phoneNumber, applicationVerifier);
	* // Obtain verificationCode from the user.
	* const authCredential = PhoneAuthProvider.credential(verificationId, verificationCode);
	* const userCredential = await signInWithCredential(auth, authCredential);
	* ```
	*
	* @example
	* An alternative flow is provided using the `signInWithPhoneNumber` method.
	* ```javascript
	* const confirmationResult = signInWithPhoneNumber(auth, phoneNumber, applicationVerifier);
	* // Obtain verificationCode from the user.
	* const userCredential = confirmationResult.confirm(verificationCode);
	* ```
	*
	* @param phoneInfoOptions - The user's {@link PhoneInfoOptions}. The phone number should be in
	* E.164 format (e.g. +16505550101).
	* @param applicationVerifier - An {@link ApplicationVerifier}, which prevents
	* requests from unauthorized clients. This SDK includes an implementation
	* based on reCAPTCHA v2, {@link RecaptchaVerifier}. If you've enabled
	* reCAPTCHA Enterprise bot protection in Enforce mode, this parameter is
	* optional; in all other configurations, the parameter is required.
	*
	* @returns A Promise for a verification ID that can be passed to
	* {@link PhoneAuthProvider.credential} to identify this flow.
	*/
	verifyPhoneNumber(phoneOptions, applicationVerifier) {
		return _verifyPhoneNumber(this.auth, phoneOptions, getModularInstance(applicationVerifier));
	}
	/**
	* Creates a phone auth credential, given the verification ID from
	* {@link PhoneAuthProvider.verifyPhoneNumber} and the code that was sent to the user's
	* mobile device.
	*
	* @example
	* ```javascript
	* const provider = new PhoneAuthProvider(auth);
	* const verificationId = provider.verifyPhoneNumber(phoneNumber, applicationVerifier);
	* // Obtain verificationCode from the user.
	* const authCredential = PhoneAuthProvider.credential(verificationId, verificationCode);
	* const userCredential = signInWithCredential(auth, authCredential);
	* ```
	*
	* @example
	* An alternative flow is provided using the `signInWithPhoneNumber` method.
	* ```javascript
	* const confirmationResult = await signInWithPhoneNumber(auth, phoneNumber, applicationVerifier);
	* // Obtain verificationCode from the user.
	* const userCredential = await confirmationResult.confirm(verificationCode);
	* ```
	*
	* @param verificationId - The verification ID returned from {@link PhoneAuthProvider.verifyPhoneNumber}.
	* @param verificationCode - The verification code sent to the user's mobile device.
	*
	* @returns The auth provider credential.
	*/
	static credential(verificationId, verificationCode) {
		return PhoneAuthCredential._fromVerification(verificationId, verificationCode);
	}
	/**
	* Generates an {@link AuthCredential} from a {@link UserCredential}.
	* @param userCredential - The user credential.
	*/
	static credentialFromResult(userCredential) {
		const credential = userCredential;
		return PhoneAuthProvider.credentialFromTaggedObject(credential);
	}
	/**
	* Returns an {@link AuthCredential} when passed an error.
	*
	* @remarks
	*
	* This method works for errors like
	* `auth/account-exists-with-different-credentials`. This is useful for
	* recovering when attempting to set a user's phone number but the number
	* in question is already tied to another account. For example, the following
	* code tries to update the current user's phone number, and if that
	* fails, links the user with the account associated with that number:
	*
	* ```js
	* const provider = new PhoneAuthProvider(auth);
	* const verificationId = await provider.verifyPhoneNumber(number, verifier);
	* try {
	*   const code = ''; // Prompt the user for the verification code
	*   await updatePhoneNumber(
	*       auth.currentUser,
	*       PhoneAuthProvider.credential(verificationId, code));
	* } catch (e) {
	*   if ((e as FirebaseError)?.code === 'auth/account-exists-with-different-credential') {
	*     const cred = PhoneAuthProvider.credentialFromError(e);
	*     await linkWithCredential(auth.currentUser, cred);
	*   }
	* }
	*
	* // At this point, auth.currentUser.phoneNumber === number.
	* ```
	*
	* @param error - The error to generate a credential from.
	*/
	static credentialFromError(error) {
		return PhoneAuthProvider.credentialFromTaggedObject(error.customData || {});
	}
	static credentialFromTaggedObject({ _tokenResponse: tokenResponse }) {
		if (!tokenResponse) return null;
		const { phoneNumber, temporaryProof } = tokenResponse;
		if (phoneNumber && temporaryProof) return PhoneAuthCredential._fromTokenResponse(phoneNumber, temporaryProof);
		return null;
	}
};
/** Always set to {@link ProviderId}.PHONE. */
PhoneAuthProvider.PROVIDER_ID = "phone";
/** Always set to {@link SignInMethod}.PHONE. */
PhoneAuthProvider.PHONE_SIGN_IN_METHOD = "phone";
/**
* @license
* Copyright 2021 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Chooses a popup/redirect resolver to use. This prefers the override (which
* is directly passed in), and falls back to the property set on the auth
* object. If neither are available, this function errors w/ an argument error.
*/
function _withDefaultResolver(auth, resolverOverride) {
	if (resolverOverride) return _getInstance(resolverOverride);
	_assert(auth._popupRedirectResolver, auth, "argument-error");
	return auth._popupRedirectResolver;
}
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var IdpCredential = class extends AuthCredential {
	constructor(params) {
		super("custom", "custom");
		this.params = params;
	}
	_getIdTokenResponse(auth) {
		return signInWithIdp(auth, this._buildIdpRequest());
	}
	_linkToIdToken(auth, idToken) {
		return signInWithIdp(auth, this._buildIdpRequest(idToken));
	}
	_getReauthenticationResolver(auth) {
		return signInWithIdp(auth, this._buildIdpRequest());
	}
	_buildIdpRequest(idToken) {
		const request = {
			requestUri: this.params.requestUri,
			sessionId: this.params.sessionId,
			postBody: this.params.postBody,
			tenantId: this.params.tenantId,
			pendingToken: this.params.pendingToken,
			returnSecureToken: true,
			returnIdpCredential: true
		};
		if (idToken) request.idToken = idToken;
		return request;
	}
};
function _signIn(params) {
	return _signInWithCredential(params.auth, new IdpCredential(params), params.bypassAuthState);
}
function _reauth(params) {
	const { auth, user } = params;
	_assert(user, auth, "internal-error");
	return _reauthenticate(user, new IdpCredential(params), params.bypassAuthState);
}
async function _link(params) {
	const { auth, user } = params;
	_assert(user, auth, "internal-error");
	return _link$1(user, new IdpCredential(params), params.bypassAuthState);
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Popup event manager. Handles the popup's entire lifecycle; listens to auth
* events
*/
var AbstractPopupRedirectOperation = class {
	constructor(auth, filter, resolver, user, bypassAuthState = false) {
		this.auth = auth;
		this.resolver = resolver;
		this.user = user;
		this.bypassAuthState = bypassAuthState;
		this.pendingPromise = null;
		this.eventManager = null;
		this.filter = Array.isArray(filter) ? filter : [filter];
	}
	execute() {
		return new Promise(async (resolve, reject) => {
			this.pendingPromise = {
				resolve,
				reject
			};
			try {
				this.eventManager = await this.resolver._initialize(this.auth);
				await this.onExecution();
				this.eventManager.registerConsumer(this);
			} catch (e) {
				this.reject(e);
			}
		});
	}
	async onAuthEvent(event) {
		const { urlResponse, sessionId, postBody, tenantId, error, type } = event;
		if (error) {
			this.reject(error);
			return;
		}
		const params = {
			auth: this.auth,
			requestUri: urlResponse,
			sessionId,
			tenantId: tenantId || void 0,
			postBody: postBody || void 0,
			user: this.user,
			bypassAuthState: this.bypassAuthState
		};
		try {
			this.resolve(await this.getIdpTask(type)(params));
		} catch (e) {
			this.reject(e);
		}
	}
	onError(error) {
		this.reject(error);
	}
	getIdpTask(type) {
		switch (type) {
			case "signInViaPopup":
			case "signInViaRedirect": return _signIn;
			case "linkViaPopup":
			case "linkViaRedirect": return _link;
			case "reauthViaPopup":
			case "reauthViaRedirect": return _reauth;
			default: _fail(this.auth, "internal-error");
		}
	}
	resolve(cred) {
		debugAssert(this.pendingPromise, "Pending promise was never set");
		this.pendingPromise.resolve(cred);
		this.unregisterAndCleanUp();
	}
	reject(error) {
		debugAssert(this.pendingPromise, "Pending promise was never set");
		this.pendingPromise.reject(error);
		this.unregisterAndCleanUp();
	}
	unregisterAndCleanUp() {
		if (this.eventManager) this.eventManager.unregisterConsumer(this);
		this.pendingPromise = null;
		this.cleanUp();
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var _POLL_WINDOW_CLOSE_TIMEOUT = new Delay(2e3, 1e4);
/**
* Authenticates a Firebase client using a popup-based OAuth authentication flow.
*
* @remarks
* If succeeds, returns the signed in user along with the provider's credential. If sign in was
* unsuccessful, returns an error object containing additional information about the error.
*
* This method does not work in a Node.js environment or with {@link Auth} instances created with a
* {@link @firebase/app#FirebaseServerApp}.
*
* @example
* ```javascript
* // Sign in using a popup.
* const provider = new FacebookAuthProvider();
* const result = await signInWithPopup(auth, provider);
*
* // The signed-in user info.
* const user = result.user;
* // This gives you a Facebook Access Token.
* const credential = provider.credentialFromResult(auth, result);
* const token = credential.accessToken;
* ```
*
* @param auth - The {@link Auth} instance.
* @param provider - The provider to authenticate. The provider has to be an {@link OAuthProvider}.
* Non-OAuth providers like {@link EmailAuthProvider} will throw an error.
* @param resolver - An instance of {@link PopupRedirectResolver}, optional
* if already supplied to {@link initializeAuth} or provided by {@link getAuth}.
*
* @public
*/
async function signInWithPopup(auth, provider, resolver) {
	if (_isFirebaseServerApp(auth.app)) return Promise.reject(_createError(auth, "operation-not-supported-in-this-environment"));
	const authInternal = _castAuth(auth);
	_assertInstanceOf(auth, provider, FederatedAuthProvider);
	return new PopupOperation(authInternal, "signInViaPopup", provider, _withDefaultResolver(authInternal, resolver)).executeNotNull();
}
/**
* Popup event manager. Handles the popup's entire lifecycle; listens to auth
* events
*
*/
var PopupOperation = class PopupOperation extends AbstractPopupRedirectOperation {
	constructor(auth, filter, provider, resolver, user) {
		super(auth, filter, resolver, user);
		this.provider = provider;
		this.authWindow = null;
		this.pollId = null;
		if (PopupOperation.currentPopupAction) PopupOperation.currentPopupAction.cancel();
		PopupOperation.currentPopupAction = this;
	}
	async executeNotNull() {
		const result = await this.execute();
		_assert(result, this.auth, "internal-error");
		return result;
	}
	async onExecution() {
		debugAssert(this.filter.length === 1, "Popup operations only handle one event");
		const eventId = _generateEventId();
		this.authWindow = await this.resolver._openPopup(this.auth, this.provider, this.filter[0], eventId);
		this.authWindow.associatedEvent = eventId;
		this.resolver._originValidation(this.auth).catch((e) => {
			this.reject(e);
		});
		this.resolver._isIframeWebStorageSupported(this.auth, (isSupported) => {
			if (!isSupported) this.reject(_createError(this.auth, "web-storage-unsupported"));
		});
		this.pollUserCancellation();
	}
	get eventId() {
		return this.authWindow?.associatedEvent || null;
	}
	cancel() {
		this.reject(_createError(this.auth, "cancelled-popup-request"));
	}
	cleanUp() {
		if (this.authWindow) this.authWindow.close();
		if (this.pollId) window.clearTimeout(this.pollId);
		this.authWindow = null;
		this.pollId = null;
		PopupOperation.currentPopupAction = null;
	}
	pollUserCancellation() {
		const poll = () => {
			if (this.authWindow?.window?.closed) {
				this.pollId = window.setTimeout(() => {
					this.pollId = null;
					this.reject(_createError(this.auth, "popup-closed-by-user"));
				}, 8e3);
				return;
			}
			this.pollId = window.setTimeout(poll, _POLL_WINDOW_CLOSE_TIMEOUT.get());
		};
		poll();
	}
};
PopupOperation.currentPopupAction = null;
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var PENDING_REDIRECT_KEY = "pendingRedirect";
var redirectOutcomeMap = /* @__PURE__ */ new Map();
var RedirectAction = class extends AbstractPopupRedirectOperation {
	constructor(auth, resolver, bypassAuthState = false) {
		super(auth, [
			"signInViaRedirect",
			"linkViaRedirect",
			"reauthViaRedirect",
			"unknown"
		], resolver, void 0, bypassAuthState);
		this.eventId = null;
	}
	/**
	* Override the execute function; if we already have a redirect result, then
	* just return it.
	*/
	async execute() {
		let readyOutcome = redirectOutcomeMap.get(this.auth._key());
		if (!readyOutcome) {
			try {
				const result = await _getAndClearPendingRedirectStatus(this.resolver, this.auth) ? await super.execute() : null;
				readyOutcome = () => Promise.resolve(result);
			} catch (e) {
				readyOutcome = () => Promise.reject(e);
			}
			redirectOutcomeMap.set(this.auth._key(), readyOutcome);
		}
		if (!this.bypassAuthState) redirectOutcomeMap.set(this.auth._key(), () => Promise.resolve(null));
		return readyOutcome();
	}
	async onAuthEvent(event) {
		if (event.type === "signInViaRedirect") return super.onAuthEvent(event);
		else if (event.type === "unknown") {
			this.resolve(null);
			return;
		}
		if (event.eventId) {
			const user = await this.auth._redirectUserForId(event.eventId);
			if (user) {
				this.user = user;
				return super.onAuthEvent(event);
			} else this.resolve(null);
		}
	}
	async onExecution() {}
	cleanUp() {}
};
async function _getAndClearPendingRedirectStatus(resolver, auth) {
	const key = pendingRedirectKey(auth);
	const persistence = resolverPersistence(resolver);
	if (!await persistence._isAvailable()) return false;
	const hasPendingRedirect = await persistence._get(key) === "true";
	await persistence._remove(key);
	return hasPendingRedirect;
}
function _overrideRedirectResult(auth, result) {
	redirectOutcomeMap.set(auth._key(), result);
}
function resolverPersistence(resolver) {
	return _getInstance(resolver._redirectPersistence);
}
function pendingRedirectKey(auth) {
	return _persistenceKeyName(PENDING_REDIRECT_KEY, auth.config.apiKey, auth.name);
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
async function _getRedirectResult(auth, resolverExtern, bypassAuthState = false) {
	if (_isFirebaseServerApp(auth.app)) return Promise.reject(_serverAppCurrentUserOperationNotSupportedError(auth));
	const authInternal = _castAuth(auth);
	const result = await new RedirectAction(authInternal, _withDefaultResolver(authInternal, resolverExtern), bypassAuthState).execute();
	if (result && !bypassAuthState) {
		delete result.user._redirectEventId;
		await authInternal._persistUserIfCurrent(result.user);
		await authInternal._setRedirectUser(null, resolverExtern);
	}
	return result;
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var EVENT_DUPLICATION_CACHE_DURATION_MS = 6e5;
var AuthEventManager = class {
	constructor(auth) {
		this.auth = auth;
		this.cachedEventUids = /* @__PURE__ */ new Set();
		this.consumers = /* @__PURE__ */ new Set();
		this.queuedRedirectEvent = null;
		this.hasHandledPotentialRedirect = false;
		this.lastProcessedEventTime = Date.now();
	}
	registerConsumer(authEventConsumer) {
		this.consumers.add(authEventConsumer);
		if (this.queuedRedirectEvent && this.isEventForConsumer(this.queuedRedirectEvent, authEventConsumer)) {
			this.sendToConsumer(this.queuedRedirectEvent, authEventConsumer);
			this.saveEventToCache(this.queuedRedirectEvent);
			this.queuedRedirectEvent = null;
		}
	}
	unregisterConsumer(authEventConsumer) {
		this.consumers.delete(authEventConsumer);
	}
	onEvent(event) {
		if (this.hasEventBeenHandled(event)) return false;
		let handled = false;
		this.consumers.forEach((consumer) => {
			if (this.isEventForConsumer(event, consumer)) {
				handled = true;
				this.sendToConsumer(event, consumer);
				this.saveEventToCache(event);
			}
		});
		if (this.hasHandledPotentialRedirect || !isRedirectEvent(event)) return handled;
		this.hasHandledPotentialRedirect = true;
		if (!handled) {
			this.queuedRedirectEvent = event;
			handled = true;
		}
		return handled;
	}
	sendToConsumer(event, consumer) {
		if (event.error && !isNullRedirectEvent(event)) {
			const code = event.error.code?.split("auth/")[1] || "internal-error";
			consumer.onError(_createError(this.auth, code));
		} else consumer.onAuthEvent(event);
	}
	isEventForConsumer(event, consumer) {
		const eventIdMatches = consumer.eventId === null || !!event.eventId && event.eventId === consumer.eventId;
		return consumer.filter.includes(event.type) && eventIdMatches;
	}
	hasEventBeenHandled(event) {
		if (Date.now() - this.lastProcessedEventTime >= EVENT_DUPLICATION_CACHE_DURATION_MS) this.cachedEventUids.clear();
		return this.cachedEventUids.has(eventUid(event));
	}
	saveEventToCache(event) {
		this.cachedEventUids.add(eventUid(event));
		this.lastProcessedEventTime = Date.now();
	}
};
function eventUid(e) {
	return [
		e.type,
		e.eventId,
		e.sessionId,
		e.tenantId
	].filter((v) => v).join("-");
}
function isNullRedirectEvent({ type, error }) {
	return type === "unknown" && error?.code === `auth/no-auth-event`;
}
function isRedirectEvent(event) {
	switch (event.type) {
		case "signInViaRedirect":
		case "linkViaRedirect":
		case "reauthViaRedirect": return true;
		case "unknown": return isNullRedirectEvent(event);
		default: return false;
	}
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
async function _getProjectConfig(auth, request = {}) {
	return _performApiRequest(auth, "GET", "/v1/projects", request);
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var IP_ADDRESS_REGEX = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
var HTTP_REGEX = /^https?/;
async function _validateOrigin(auth) {
	if (auth.config.emulator) return;
	const { authorizedDomains } = await _getProjectConfig(auth);
	for (const domain of authorizedDomains) try {
		if (matchDomain(domain)) return;
	} catch {}
	_fail(auth, "unauthorized-domain");
}
function matchDomain(expected) {
	const currentUrl = _getCurrentUrl();
	const { protocol, hostname } = new URL(currentUrl);
	if (expected.startsWith("chrome-extension://")) {
		const ceUrl = new URL(expected);
		if (ceUrl.hostname === "" && hostname === "") return protocol === "chrome-extension:" && expected.replace("chrome-extension://", "") === currentUrl.replace("chrome-extension://", "");
		return protocol === "chrome-extension:" && ceUrl.hostname === hostname;
	}
	if (!HTTP_REGEX.test(protocol)) return false;
	if (IP_ADDRESS_REGEX.test(expected)) return hostname === expected;
	const escapedDomainPattern = expected.replace(/\./g, "\\.");
	return new RegExp("^(.+\\." + escapedDomainPattern + "|" + escapedDomainPattern + ")$", "i").test(hostname);
}
/**
* @license
* Copyright 2020 Google LLC.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var NETWORK_TIMEOUT = new Delay(3e4, 6e4);
/**
* Reset unloaded GApi modules. If gapi.load fails due to a network error,
* it will stop working after a retrial. This is a hack to fix this issue.
*/
function resetUnloadedGapiModules() {
	const beacon = _window().___jsl;
	if (beacon?.H) for (const hint of Object.keys(beacon.H)) {
		beacon.H[hint].r = beacon.H[hint].r || [];
		beacon.H[hint].L = beacon.H[hint].L || [];
		beacon.H[hint].r = [...beacon.H[hint].L];
		if (beacon.CP) for (let i = 0; i < beacon.CP.length; i++) beacon.CP[i] = null;
	}
}
function loadGapi(auth) {
	return new Promise((resolve, reject) => {
		function loadGapiIframe() {
			resetUnloadedGapiModules();
			gapi.load("gapi.iframes", {
				callback: () => {
					resolve(gapi.iframes.getContext());
				},
				ontimeout: () => {
					resetUnloadedGapiModules();
					reject(_createError(auth, "network-request-failed"));
				},
				timeout: NETWORK_TIMEOUT.get()
			});
		}
		if (_window().gapi?.iframes?.Iframe) resolve(gapi.iframes.getContext());
		else if (!!_window().gapi?.load) loadGapiIframe();
		else {
			const cbName = _generateCallbackName("iframefcb");
			_window()[cbName] = () => {
				if (!!gapi.load) loadGapiIframe();
				else reject(_createError(auth, "network-request-failed"));
			};
			return _loadJS(`${_gapiScriptUrl()}?onload=${cbName}`).catch((e) => reject(e));
		}
	}).catch((error) => {
		cachedGApiLoader = null;
		throw error;
	});
}
var cachedGApiLoader = null;
function _loadGapi(auth) {
	cachedGApiLoader = cachedGApiLoader || loadGapi(auth);
	return cachedGApiLoader;
}
/**
* @license
* Copyright 2020 Google LLC.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var PING_TIMEOUT = new Delay(5e3, 15e3);
var IFRAME_PATH = "__/auth/iframe";
var EMULATED_IFRAME_PATH = "emulator/auth/iframe";
var IFRAME_ATTRIBUTES = {
	style: {
		position: "absolute",
		top: "-100px",
		width: "1px",
		height: "1px"
	},
	"aria-hidden": "true",
	tabindex: "-1"
};
var EID_FROM_APIHOST = /* @__PURE__ */ new Map([
	["identitytoolkit.googleapis.com", "p"],
	["staging-identitytoolkit.sandbox.googleapis.com", "s"],
	["test-identitytoolkit.sandbox.googleapis.com", "t"]
]);
function getIframeUrl(auth) {
	const config = auth.config;
	_assert(config.authDomain, auth, "auth-domain-config-required");
	const url = config.emulator ? _emulatorUrl(config, EMULATED_IFRAME_PATH) : `https://${auth.config.authDomain}/${IFRAME_PATH}`;
	const params = {
		apiKey: config.apiKey,
		appName: auth.name,
		v: SDK_VERSION
	};
	const eid = EID_FROM_APIHOST.get(auth.config.apiHost);
	if (eid) params.eid = eid;
	const frameworks = auth._getFrameworks();
	if (frameworks.length) params.fw = frameworks.join(",");
	return `${url}?${querystring(params).slice(1)}`;
}
async function _openIframe(auth) {
	const context = await _loadGapi(auth);
	const gapi = _window().gapi;
	_assert(gapi, auth, "internal-error");
	return context.open({
		where: document.body,
		url: getIframeUrl(auth),
		messageHandlersFilter: gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER,
		attributes: IFRAME_ATTRIBUTES,
		dontclear: true
	}, (iframe) => new Promise(async (resolve, reject) => {
		await iframe.restyle({ setHideOnLeave: false });
		const networkError = _createError(auth, "network-request-failed");
		const networkErrorTimer = _window().setTimeout(() => {
			reject(networkError);
		}, PING_TIMEOUT.get());
		function clearTimerAndResolve() {
			_window().clearTimeout(networkErrorTimer);
			resolve(iframe);
		}
		iframe.ping(clearTimerAndResolve).then(clearTimerAndResolve, () => {
			reject(networkError);
		});
	}));
}
/**
* @license
* Copyright 2020 Google LLC.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var BASE_POPUP_OPTIONS = {
	location: "yes",
	resizable: "yes",
	statusbar: "yes",
	toolbar: "no"
};
var DEFAULT_WIDTH = 500;
var DEFAULT_HEIGHT = 600;
var TARGET_BLANK = "_blank";
var FIREFOX_EMPTY_URL = "http://localhost";
var AuthPopup = class {
	constructor(window) {
		this.window = window;
		this.associatedEvent = null;
	}
	close() {
		if (this.window) try {
			this.window.close();
		} catch (e) {}
	}
};
function _open(auth, url, name, width = DEFAULT_WIDTH, height = DEFAULT_HEIGHT) {
	const top = Math.max((window.screen.availHeight - height) / 2, 0).toString();
	const left = Math.max((window.screen.availWidth - width) / 2, 0).toString();
	let target = "";
	const options = {
		...BASE_POPUP_OPTIONS,
		width: width.toString(),
		height: height.toString(),
		top,
		left
	};
	const ua = getUA().toLowerCase();
	if (name) target = _isChromeIOS(ua) ? TARGET_BLANK : name;
	if (_isFirefox(ua)) {
		url = url || FIREFOX_EMPTY_URL;
		options.scrollbars = "yes";
	}
	const optionsString = Object.entries(options).reduce((accum, [key, value]) => `${accum}${key}=${value},`, "");
	if (_isIOSStandalone(ua) && target !== "_self") {
		openAsNewWindowIOS(url || "", target);
		return new AuthPopup(null);
	}
	const newWin = window.open(url || "", target, optionsString);
	_assert(newWin, auth, "popup-blocked");
	try {
		newWin.focus();
	} catch (e) {}
	return new AuthPopup(newWin);
}
function openAsNewWindowIOS(url, target) {
	const el = document.createElement("a");
	el.href = url;
	el.target = target;
	const click = document.createEvent("MouseEvent");
	click.initMouseEvent("click", true, true, window, 1, 0, 0, 0, 0, false, false, false, false, 1, null);
	el.dispatchEvent(click);
}
/**
* @license
* Copyright 2021 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* URL for Authentication widget which will initiate the OAuth handshake
*
* @internal
*/
var WIDGET_PATH = "__/auth/handler";
/**
* URL for emulated environment
*
* @internal
*/
var EMULATOR_WIDGET_PATH = "emulator/auth/handler";
/**
* Fragment name for the App Check token that gets passed to the widget
*
* @internal
*/
var FIREBASE_APP_CHECK_FRAGMENT_ID = encodeURIComponent("fac");
async function _getRedirectUrl(auth, provider, authType, redirectUrl, eventId, additionalParams) {
	_assert(auth.config.authDomain, auth, "auth-domain-config-required");
	_assert(auth.config.apiKey, auth, "invalid-api-key");
	const params = {
		apiKey: auth.config.apiKey,
		appName: auth.name,
		authType,
		redirectUrl,
		v: SDK_VERSION,
		eventId
	};
	if (provider instanceof FederatedAuthProvider) {
		provider.setDefaultLanguage(auth.languageCode);
		params.providerId = provider.providerId || "";
		if (!isEmpty(provider.getCustomParameters())) params.customParameters = JSON.stringify(provider.getCustomParameters());
		for (const [key, value] of Object.entries(additionalParams || {})) params[key] = value;
	}
	if (provider instanceof BaseOAuthProvider) {
		const scopes = provider.getScopes().filter((scope) => scope !== "");
		if (scopes.length > 0) params.scopes = scopes.join(",");
	}
	if (auth.tenantId) params.tid = auth.tenantId;
	const paramsDict = params;
	for (const key of Object.keys(paramsDict)) if (paramsDict[key] === void 0) delete paramsDict[key];
	const appCheckToken = await auth._getAppCheckToken();
	const appCheckTokenFragment = appCheckToken ? `#${FIREBASE_APP_CHECK_FRAGMENT_ID}=${encodeURIComponent(appCheckToken)}` : "";
	return `${getHandlerBase(auth)}?${querystring(paramsDict).slice(1)}${appCheckTokenFragment}`;
}
function getHandlerBase({ config }) {
	if (!config.emulator) return `https://${config.authDomain}/${WIDGET_PATH}`;
	return _emulatorUrl(config, EMULATOR_WIDGET_PATH);
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* The special web storage event
*
*/
var WEB_STORAGE_SUPPORT_KEY = "webStorageSupport";
var BrowserPopupRedirectResolver = class {
	constructor() {
		this.eventManagers = {};
		this.iframes = {};
		this.originValidationPromises = {};
		this._redirectPersistence = browserSessionPersistence;
		this._completeRedirectFn = _getRedirectResult;
		this._overrideRedirectResult = _overrideRedirectResult;
	}
	async _openPopup(auth, provider, authType, eventId) {
		debugAssert(this.eventManagers[auth._key()]?.manager, "_initialize() not called before _openPopup()");
		return _open(auth, await _getRedirectUrl(auth, provider, authType, _getCurrentUrl(), eventId), _generateEventId());
	}
	async _openRedirect(auth, provider, authType, eventId) {
		await this._originValidation(auth);
		_setWindowLocation(await _getRedirectUrl(auth, provider, authType, _getCurrentUrl(), eventId));
		return new Promise(() => {});
	}
	_initialize(auth) {
		const key = auth._key();
		if (this.eventManagers[key]) {
			const { manager, promise } = this.eventManagers[key];
			if (manager) return Promise.resolve(manager);
			else {
				debugAssert(promise, "If manager is not set, promise should be");
				return promise;
			}
		}
		const promise = this.initAndGetManager(auth);
		this.eventManagers[key] = { promise };
		promise.catch(() => {
			delete this.eventManagers[key];
		});
		return promise;
	}
	async initAndGetManager(auth) {
		const iframe = await _openIframe(auth);
		const manager = new AuthEventManager(auth);
		iframe.register("authEvent", (iframeEvent) => {
			_assert(iframeEvent?.authEvent, auth, "invalid-auth-event");
			return { status: manager.onEvent(iframeEvent.authEvent) ? "ACK" : "ERROR" };
		}, gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER);
		this.eventManagers[auth._key()] = { manager };
		this.iframes[auth._key()] = iframe;
		return manager;
	}
	_isIframeWebStorageSupported(auth, cb) {
		this.iframes[auth._key()].send(WEB_STORAGE_SUPPORT_KEY, { type: WEB_STORAGE_SUPPORT_KEY }, (result) => {
			const isSupported = result?.[0]?.[WEB_STORAGE_SUPPORT_KEY];
			if (isSupported !== void 0) cb(!!isSupported);
			_fail(auth, "internal-error");
		}, gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER);
	}
	_originValidation(auth) {
		const key = auth._key();
		if (!this.originValidationPromises[key]) this.originValidationPromises[key] = _validateOrigin(auth);
		return this.originValidationPromises[key];
	}
	get _shouldInitProactively() {
		return _isMobileBrowser() || _isSafari() || _isIOS();
	}
};
/**
* An implementation of {@link PopupRedirectResolver} suitable for browser
* based applications.
*
* @remarks
* This method does not work in a Node.js environment.
*
* @public
*/
var browserPopupRedirectResolver = BrowserPopupRedirectResolver;
var MultiFactorAssertionImpl = class {
	constructor(factorId) {
		this.factorId = factorId;
	}
	_process(auth, session, displayName) {
		switch (session.type) {
			case "enroll": return this._finalizeEnroll(auth, session.credential, displayName);
			case "signin": return this._finalizeSignIn(auth, session.credential);
			default: return debugFail("unexpected MultiFactorSessionType");
		}
	}
};
/**
* {@inheritdoc PhoneMultiFactorAssertion}
*
* @public
*/
var PhoneMultiFactorAssertionImpl = class PhoneMultiFactorAssertionImpl extends MultiFactorAssertionImpl {
	constructor(credential) {
		super("phone");
		this.credential = credential;
	}
	/** @internal */
	static _fromCredential(credential) {
		return new PhoneMultiFactorAssertionImpl(credential);
	}
	/** @internal */
	_finalizeEnroll(auth, idToken, displayName) {
		return finalizeEnrollPhoneMfa(auth, {
			idToken,
			displayName,
			phoneVerificationInfo: this.credential._makeVerificationRequest()
		});
	}
	/** @internal */
	_finalizeSignIn(auth, mfaPendingCredential) {
		return finalizeSignInPhoneMfa(auth, {
			mfaPendingCredential,
			phoneVerificationInfo: this.credential._makeVerificationRequest()
		});
	}
};
/**
* Provider for generating a {@link PhoneMultiFactorAssertion}.
*
* @public
*/
var PhoneMultiFactorGenerator = class {
	constructor() {}
	/**
	* Provides a {@link PhoneMultiFactorAssertion} to confirm ownership of the phone second factor.
	*
	* @remarks
	* This method does not work in a Node.js environment.
	*
	* @param phoneAuthCredential - A credential provided by {@link PhoneAuthProvider.credential}.
	* @returns A {@link PhoneMultiFactorAssertion} which can be used with
	* {@link MultiFactorResolver.resolveSignIn}
	*/
	static assertion(credential) {
		return PhoneMultiFactorAssertionImpl._fromCredential(credential);
	}
};
/**
* The identifier of the phone second factor: `phone`.
*/
PhoneMultiFactorGenerator.FACTOR_ID = "phone";
/**
* Provider for generating a {@link TotpMultiFactorAssertion}.
*
* @public
*/
var TotpMultiFactorGenerator = class {
	/**
	* Provides a {@link TotpMultiFactorAssertion} to confirm ownership of
	* the TOTP (time-based one-time password) second factor.
	* This assertion is used to complete enrollment in TOTP second factor.
	*
	* @param secret A {@link TotpSecret} containing the shared secret key and other TOTP parameters.
	* @param oneTimePassword One-time password from TOTP App.
	* @returns A {@link TotpMultiFactorAssertion} which can be used with
	* {@link MultiFactorUser.enroll}.
	*/
	static assertionForEnrollment(secret, oneTimePassword) {
		return TotpMultiFactorAssertionImpl._fromSecret(secret, oneTimePassword);
	}
	/**
	* Provides a {@link TotpMultiFactorAssertion} to confirm ownership of the TOTP second factor.
	* This assertion is used to complete signIn with TOTP as the second factor.
	*
	* @param enrollmentId identifies the enrolled TOTP second factor.
	* @param oneTimePassword One-time password from TOTP App.
	* @returns A {@link TotpMultiFactorAssertion} which can be used with
	* {@link MultiFactorResolver.resolveSignIn}.
	*/
	static assertionForSignIn(enrollmentId, oneTimePassword) {
		return TotpMultiFactorAssertionImpl._fromEnrollmentId(enrollmentId, oneTimePassword);
	}
	/**
	* Returns a promise to {@link TotpSecret} which contains the TOTP shared secret key and other parameters.
	* Creates a TOTP secret as part of enrolling a TOTP second factor.
	* Used for generating a QR code URL or inputting into a TOTP app.
	* This method uses the auth instance corresponding to the user in the multiFactorSession.
	*
	* @param session The {@link MultiFactorSession} that the user is part of.
	* @returns A promise to {@link TotpSecret}.
	*/
	static async generateSecret(session) {
		const mfaSession = session;
		_assert(typeof mfaSession.user?.auth !== "undefined", "internal-error");
		const response = await startEnrollTotpMfa(mfaSession.user.auth, {
			idToken: mfaSession.credential,
			totpEnrollmentInfo: {}
		});
		return TotpSecret._fromStartTotpMfaEnrollmentResponse(response, mfaSession.user.auth);
	}
};
/**
* The identifier of the TOTP second factor: `totp`.
*/
TotpMultiFactorGenerator.FACTOR_ID = "totp";
var TotpMultiFactorAssertionImpl = class TotpMultiFactorAssertionImpl extends MultiFactorAssertionImpl {
	constructor(otp, enrollmentId, secret) {
		super("totp");
		this.otp = otp;
		this.enrollmentId = enrollmentId;
		this.secret = secret;
	}
	/** @internal */
	static _fromSecret(secret, otp) {
		return new TotpMultiFactorAssertionImpl(otp, void 0, secret);
	}
	/** @internal */
	static _fromEnrollmentId(enrollmentId, otp) {
		return new TotpMultiFactorAssertionImpl(otp, enrollmentId);
	}
	/** @internal */
	async _finalizeEnroll(auth, idToken, displayName) {
		_assert(typeof this.secret !== "undefined", auth, "argument-error");
		return finalizeEnrollTotpMfa(auth, {
			idToken,
			displayName,
			totpVerificationInfo: this.secret._makeTotpVerificationInfo(this.otp)
		});
	}
	/** @internal */
	async _finalizeSignIn(auth, mfaPendingCredential) {
		_assert(this.enrollmentId !== void 0 && this.otp !== void 0, auth, "argument-error");
		const totpVerificationInfo = { verificationCode: this.otp };
		return finalizeSignInTotpMfa(auth, {
			mfaPendingCredential,
			mfaEnrollmentId: this.enrollmentId,
			totpVerificationInfo
		});
	}
};
/**
* Provider for generating a {@link TotpMultiFactorAssertion}.
*
* Stores the shared secret key and other parameters to generate time-based OTPs.
* Implements methods to retrieve the shared secret key and generate a QR code URL.
* @public
*/
var TotpSecret = class TotpSecret {
	constructor(secretKey, hashingAlgorithm, codeLength, codeIntervalSeconds, enrollmentCompletionDeadline, sessionInfo, auth) {
		this.sessionInfo = sessionInfo;
		this.auth = auth;
		this.secretKey = secretKey;
		this.hashingAlgorithm = hashingAlgorithm;
		this.codeLength = codeLength;
		this.codeIntervalSeconds = codeIntervalSeconds;
		this.enrollmentCompletionDeadline = enrollmentCompletionDeadline;
	}
	/** @internal */
	static _fromStartTotpMfaEnrollmentResponse(response, auth) {
		return new TotpSecret(response.totpSessionInfo.sharedSecretKey, response.totpSessionInfo.hashingAlgorithm, response.totpSessionInfo.verificationCodeLength, response.totpSessionInfo.periodSec, new Date(response.totpSessionInfo.finalizeEnrollmentTime).toUTCString(), response.totpSessionInfo.sessionInfo, auth);
	}
	/** @internal */
	_makeTotpVerificationInfo(otp) {
		return {
			sessionInfo: this.sessionInfo,
			verificationCode: otp
		};
	}
	/**
	* Returns a QR code URL as described in
	* https://github.com/google/google-authenticator/wiki/Key-Uri-Format
	* This can be displayed to the user as a QR code to be scanned into a TOTP app like Google Authenticator.
	* If the optional parameters are unspecified, an accountName of <userEmail> and issuer of <firebaseAppName> are used.
	*
	* @param accountName the name of the account/app along with a user identifier.
	* @param issuer issuer of the TOTP (likely the app name).
	* @returns A QR code URL string.
	*/
	generateQrCodeUrl(accountName, issuer) {
		let useDefaults = false;
		if (_isEmptyString(accountName) || _isEmptyString(issuer)) useDefaults = true;
		if (useDefaults) {
			if (_isEmptyString(accountName)) accountName = this.auth.currentUser?.email || "unknownuser";
			if (_isEmptyString(issuer)) issuer = this.auth.name;
		}
		return `otpauth://totp/${issuer}:${accountName}?secret=${this.secretKey}&issuer=${issuer}&algorithm=${this.hashingAlgorithm}&digits=${this.codeLength}`;
	}
};
/** @internal */
function _isEmptyString(input) {
	return typeof input === "undefined" || input?.length === 0;
}
var name = "@firebase/auth";
var version = "1.13.7";
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var AuthInterop = class {
	constructor(auth) {
		this.auth = auth;
		this.internalListeners = /* @__PURE__ */ new Map();
	}
	getUid() {
		this.assertAuthConfigured();
		return this.auth.currentUser?.uid || null;
	}
	async getToken(forceRefresh) {
		this.assertAuthConfigured();
		await this.auth._initializationPromise;
		if (!this.auth.currentUser) return null;
		return { accessToken: await this.auth.currentUser.getIdToken(forceRefresh) };
	}
	addAuthTokenListener(listener) {
		this.assertAuthConfigured();
		if (this.internalListeners.has(listener)) return;
		const unsubscribe = this.auth.onIdTokenChanged((user) => {
			listener(user?.stsTokenManager.accessToken || null);
		});
		this.internalListeners.set(listener, unsubscribe);
		this.updateProactiveRefresh();
	}
	removeAuthTokenListener(listener) {
		this.assertAuthConfigured();
		const unsubscribe = this.internalListeners.get(listener);
		if (!unsubscribe) return;
		this.internalListeners.delete(listener);
		unsubscribe();
		this.updateProactiveRefresh();
	}
	assertAuthConfigured() {
		_assert(this.auth._initializationPromise, "dependent-sdk-initialized-before-auth");
	}
	updateProactiveRefresh() {
		if (this.internalListeners.size > 0) this.auth._startProactiveRefresh();
		else this.auth._stopProactiveRefresh();
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function getVersionForPlatform(clientPlatform) {
	switch (clientPlatform) {
		case "Node": return "node";
		case "ReactNative": return "rn";
		case "Worker": return "webworker";
		case "Cordova": return "cordova";
		case "WebExtension": return "web-extension";
		default: return;
	}
}
/** @internal */
function registerAuth(clientPlatform) {
	_registerComponent(new Component("auth", (container, { options: deps }) => {
		const app = container.getProvider("app").getImmediate();
		const heartbeatServiceProvider = container.getProvider("heartbeat");
		const appCheckServiceProvider = container.getProvider("app-check-internal");
		const { apiKey, authDomain } = app.options;
		_assert(apiKey && !apiKey.includes(":"), "invalid-api-key", { appName: app.name });
		const authInstance = new AuthImpl(app, heartbeatServiceProvider, appCheckServiceProvider, {
			apiKey,
			authDomain,
			clientPlatform,
			apiHost: "identitytoolkit.googleapis.com",
			tokenApiHost: "securetoken.googleapis.com",
			apiScheme: "https",
			sdkClientVersion: _getClientVersion(clientPlatform)
		});
		_initializeAuthInstance(authInstance, deps);
		return authInstance;
	}, "PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((container, _instanceIdentifier, _instance) => {
		container.getProvider("auth-internal").initialize();
	}));
	_registerComponent(new Component("auth-internal", (container) => {
		return ((auth) => new AuthInterop(auth))(_castAuth(container.getProvider("auth").getImmediate()));
	}, "PRIVATE").setInstantiationMode("EXPLICIT"));
	registerVersion(name, version, getVersionForPlatform(clientPlatform));
	registerVersion(name, version, "esm2020");
}
/**
* @license
* Copyright 2021 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var authIdTokenMaxAge = getExperimentalSetting("authIdTokenMaxAge") || 300;
var lastPostedIdToken = null;
var mintCookieFactory = (url) => async (user) => {
	const idTokenResult = user && await user.getIdTokenResult();
	const idTokenAge = idTokenResult && ((/* @__PURE__ */ new Date()).getTime() - Date.parse(idTokenResult.issuedAtTime)) / 1e3;
	if (idTokenAge && idTokenAge > authIdTokenMaxAge) return;
	const idToken = idTokenResult?.token;
	if (lastPostedIdToken === idToken) return;
	lastPostedIdToken = idToken;
	await fetch(url, {
		method: idToken ? "POST" : "DELETE",
		headers: idToken ? { "Authorization": `Bearer ${idToken}` } : {}
	});
};
/**
* Returns the Auth instance associated with the provided {@link @firebase/app#FirebaseApp}.
* If no instance exists, initializes an Auth instance with platform-specific default dependencies.
*
* @param app - The Firebase App.
*
* @public
*/
function getAuth(app = getApp()) {
	const provider = _getProvider(app, "auth");
	if (provider.isInitialized()) return provider.getImmediate();
	const auth = initializeAuth(app, {
		popupRedirectResolver: browserPopupRedirectResolver,
		persistence: [
			indexedDBLocalPersistence,
			browserLocalPersistence,
			browserSessionPersistence
		]
	});
	const authTokenSyncPath = getExperimentalSetting("authTokenSyncURL");
	if (authTokenSyncPath && typeof isSecureContext === "boolean" && isSecureContext) {
		const authTokenSyncUrl = new URL(authTokenSyncPath, location.origin);
		if (location.origin === authTokenSyncUrl.origin) {
			const mintCookie = mintCookieFactory(authTokenSyncUrl.toString());
			beforeAuthStateChanged(auth, mintCookie, () => mintCookie(auth.currentUser));
			onIdTokenChanged(auth, (user) => mintCookie(user));
		}
	}
	const authEmulatorHost = getDefaultEmulatorHost("auth");
	if (authEmulatorHost) connectAuthEmulator(auth, `http://${authEmulatorHost}`);
	return auth;
}
function getScriptParentElement() {
	return document.getElementsByTagName("head")?.[0] ?? document;
}
_setExternalJSProvider({
	loadJS(url) {
		return new Promise((resolve, reject) => {
			const el = document.createElement("script");
			el.setAttribute("src", url);
			el.onload = resolve;
			el.onerror = (e) => {
				const error = _createError("internal-error");
				error.customData = e;
				reject(error);
			};
			el.type = "text/javascript";
			el.charset = "UTF-8";
			getScriptParentElement().appendChild(el);
		});
	},
	gapiScript: "https://apis.google.com/js/api.js",
	recaptchaV2Script: "https://www.google.com/recaptcha/api.js",
	recaptchaEnterpriseScript: "https://www.google.com/recaptcha/enterprise.js?render="
});
registerAuth("Browser");
//#endregion
export { FirebaseError as A, getApp as C, LogLevel as D, registerVersion as E, getUA as F, isCloudWorkstation as I, isSafari as L, deepEqual as M, getDefaultEmulatorHostnameAndPort as N, Logger as O, getModularInstance as P, pingServer as R, _registerComponent as S, initializeApp as T, Integer as _, signInAnonymously as a, _getProvider as b, signOut as c, EventType as d, Stat as f, getStatEventTarget as g, createWebChannelTransport as h, onAuthStateChanged as i, createMockUserToken as j, Component as k, ErrorCode as l, XhrIo as m, createUserWithEmailAndPassword as n, signInWithEmailAndPassword as o, WebChannel as p, getAuth as r, signInWithPopup as s, GoogleAuthProvider as t, Event as u, Md5 as v, getApps as w, _isFirebaseServerApp as x, SDK_VERSION as y };
