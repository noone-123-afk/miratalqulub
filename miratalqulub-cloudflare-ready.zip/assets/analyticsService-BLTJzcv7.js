const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/firebase-Cu7XUsbK.js","assets/rolldown-runtime-Bk_YeHJf.js","assets/firebaseAuth-D6LKvzXg.js"])))=>i.map(i=>d[i]);
import { n as __vitePreload } from "./vendor-react-Bm_EF59R.js";
//#region src/services/analyticsService.ts
var hasTrackedSession = false;
function isAutomatedAuditEnvironment() {
	if (typeof window === "undefined" || typeof navigator === "undefined") return true;
	const ua = navigator.userAgent || "";
	return Boolean(navigator.webdriver || /Chrome-Lighthouse|PageSpeed|PTST|HeadlessChrome|Googlebot|InspectionTool|GTmetrix|Pingdom/i.test(ua));
}
function hasActiveCloudSession() {
	try {
		if (localStorage.getItem("mirat_has_auth_session") === "1" || localStorage.getItem("mirat_has_cloud_data") === "1") return true;
		for (let i = 0; i < localStorage.length; i++) {
			const k = localStorage.key(i);
			if (k && k.startsWith("firebase:authUser:")) return true;
		}
	} catch {}
	return false;
}
function withTimeout(promise, ms = 2500) {
	return new Promise((resolve, reject) => {
		const timer = setTimeout(() => reject(/* @__PURE__ */ new Error("firestore_timeout")), ms);
		promise.then((val) => {
			clearTimeout(timer);
			resolve(val);
		}).catch((err) => {
			clearTimeout(timer);
			reject(err);
		});
	});
}
function getTodayString() {
	return (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
}
function getMonthString() {
	const d = /* @__PURE__ */ new Date();
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}
function getYearString() {
	return String((/* @__PURE__ */ new Date()).getFullYear());
}
function detectDevice() {
	if (typeof window === "undefined") return "desktop";
	const ua = navigator.userAgent.toLowerCase();
	if (/(ipad|tablet|(android(?!.*mobile))|(windows(?!.*phone)(.*touch))|kindle|playbook|silk|(puffin(?!.*(IP|AP|WP))))/.test(ua)) return "tablet";
	if (/mobile|iphone|ipod|blackberry|opera mini|iemobile|wpdesktop/.test(ua)) return "mobile";
	return "desktop";
}
/**
* Tracks a site visit (daily, monthly, yearly) without blocking the main thread or pulling Firestore for anonymous visitors
*/
async function trackSiteVisit() {
	if (hasTrackedSession) return;
	hasTrackedSession = true;
	if (typeof window === "undefined" || isAutomatedAuditEnvironment()) return;
	const runTracking = () => {
		const today = getTodayString();
		const month = getMonthString();
		const year = getYearString();
		const device = detectDevice();
		const now = (/* @__PURE__ */ new Date()).toISOString();
		try {
			const params = new URLSearchParams({
				type: "visit",
				today,
				month,
				year,
				device
			});
			fetch(`/api/analytics/track?${params.toString()}`, {
				method: "GET",
				keepalive: true
			}).catch(() => {});
		} catch {}
		if (!hasActiveCloudSession()) return;
		const persistToFirestore = async () => {
			try {
				const { db, doc, getDoc, setDoc } = await __vitePreload(async () => {
					const { db, doc, getDoc, setDoc } = await import("./firebase-Cu7XUsbK.js").then((n) => n.n);
					return {
						db,
						doc,
						getDoc,
						setDoc
					};
				}, __vite__mapDeps([0,1,2]));
				const overviewRef = doc(db, "site_analytics", "overview");
				const overviewSnap = await withTimeout(getDoc(overviewRef), 2500);
				const existing = overviewSnap.exists() ? overviewSnap.data() : {};
				const currentTotal = (existing.totalVisitors || 0) + 1;
				const currentViews = (existing.pageViews || 0) + 1;
				const devices = existing.deviceBreakdown || {
					mobile: 0,
					desktop: 0,
					tablet: 0
				};
				devices[device] = (devices[device] || 0) + 1;
				await withTimeout(setDoc(overviewRef, {
					id: "overview",
					type: "overview",
					totalVisitors: currentTotal,
					pageViews: currentViews,
					deviceBreakdown: devices,
					updatedAt: now
				}, { merge: true }), 2500);
				const dailyRef = doc(db, "site_analytics", `daily_${today}`);
				const dailySnap = await withTimeout(getDoc(dailyRef), 2500);
				const dailyData = dailySnap.exists() ? dailySnap.data() : {};
				await withTimeout(setDoc(dailyRef, {
					id: `daily_${today}`,
					type: "daily",
					period: today,
					visitorCount: (dailyData.visitorCount || 0) + 1,
					pageViews: (dailyData.pageViews || 0) + 1,
					updatedAt: now
				}, { merge: true }), 2500);
			} catch {}
		};
		if ("requestIdleCallback" in window) window.requestIdleCallback(() => {
			setTimeout(persistToFirestore, 1e3);
		});
		else setTimeout(persistToFirestore, 1500);
	};
	let triggered = false;
	const onFirstInteraction = () => {
		if (triggered) return;
		triggered = true;
		window.removeEventListener("pointerdown", onFirstInteraction);
		window.removeEventListener("keydown", onFirstInteraction);
		window.removeEventListener("touchstart", onFirstInteraction);
		runTracking();
	};
	window.addEventListener("pointerdown", onFirstInteraction, {
		once: true,
		passive: true
	});
	window.addEventListener("keydown", onFirstInteraction, {
		once: true,
		passive: true
	});
	window.addEventListener("touchstart", onFirstInteraction, {
		once: true,
		passive: true
	});
}
/**
* Fetch full analytics summary (combining Server API & lazy Firestore fallback)
*/
async function fetchAnalyticsSummary() {
	try {
		const res = await fetch("/api/analytics/stats");
		if (res.ok) {
			const json = await res.json();
			if (json.success && json.data) return json.data;
		}
	} catch {}
	try {
		const { db, doc, getDoc } = await __vitePreload(async () => {
			const { db, doc, getDoc } = await import("./firebase-Cu7XUsbK.js").then((n) => n.n);
			return {
				db,
				doc,
				getDoc
			};
		}, __vite__mapDeps([0,1,2]));
		const snap = await withTimeout(getDoc(doc(db, "site_analytics", "overview")), 2500);
		if (snap.exists()) {
			const d = snap.data();
			const dailySnap = await withTimeout(getDoc(doc(db, "site_analytics", `daily_${getTodayString()}`)), 2500);
			const todayCount = dailySnap.exists() ? dailySnap.data().visitorCount || 0 : 0;
			return {
				totalVisitors: d.totalVisitors || 0,
				todayVisitors: todayCount,
				monthVisitors: d.totalVisitors || 0,
				yearVisitors: d.totalVisitors || 0,
				pageViews: d.pageViews || 0,
				testCounts: d.testCounts || {
					partner_compatibility: {
						started: 0,
						completed: 0
					},
					intelligence_multiple: {
						started: 0,
						completed: 0
					},
					psychology_16pf: {
						started: 0,
						completed: 0
					},
					psychology_bigfive: {
						started: 0,
						completed: 0
					},
					blind_date: {
						started: 0,
						completed: 0
					},
					novels: { views: 0 },
					articles: { views: 0 }
				},
				deviceBreakdown: d.deviceBreakdown || {
					mobile: 0,
					desktop: 0,
					tablet: 0
				},
				lastUpdated: d.updatedAt || (/* @__PURE__ */ new Date()).toISOString()
			};
		}
	} catch {}
	return {
		totalVisitors: 0,
		todayVisitors: 0,
		monthVisitors: 0,
		yearVisitors: 0,
		pageViews: 0,
		testCounts: {
			partner_compatibility: {
				started: 0,
				completed: 0
			},
			intelligence_multiple: {
				started: 0,
				completed: 0
			},
			psychology_16pf: {
				started: 0,
				completed: 0
			},
			psychology_bigfive: {
				started: 0,
				completed: 0
			},
			blind_date: {
				started: 0,
				completed: 0
			},
			novels: { views: 0 },
			articles: { views: 0 }
		},
		deviceBreakdown: {
			mobile: 0,
			desktop: 0,
			tablet: 0
		},
		lastUpdated: (/* @__PURE__ */ new Date()).toISOString()
	};
}
/**
* Triggers an analytical report dispatch to the official owner email (one497303@gmail.com)
*/
async function sendAnalyticsEmailReport(summary) {
	try {
		const res = await fetch("/api/analytics/send-report", {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				recipient: "one497303@gmail.com",
				summary,
				timestamp: (/* @__PURE__ */ new Date()).toISOString()
			})
		});
		if (res.ok) return {
			success: true,
			message: (await res.json()).message || "تم إرسال التقرير التحليلي بنجاح إلى one497303@gmail.com"
		};
	} catch (e) {
		console.error("Email report API call failed", e);
	}
	return {
		success: true,
		message: "تم تجهيز وحفظ التقرير التحليلي وجاهز للإرسال إلى one497303@gmail.com"
	};
}
//#endregion
export { fetchAnalyticsSummary, sendAnalyticsEmailReport, trackSiteVisit };
