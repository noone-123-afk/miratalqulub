const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/IntelligenceTestModal-CZZJt6S0.js","assets/rolldown-runtime-Bk_YeHJf.js","assets/vendor-react-Bm_EF59R.js","assets/vendor-icons-WoMClU7U.js","assets/sound-C_zXqyNA.js","assets/index-C5uCeetQ.js","assets/firebase-Cu7XUsbK.js","assets/firebaseAuth-D6LKvzXg.js","assets/userHistoryService-6N9Zh8ed.js","assets/PsychometricAcademicFraming-DuCcNyEP.js","assets/index-DMmCvB5f.css","assets/TieredAssessmentModule-u6C5tZZz.js"])))=>i.map(i=>d[i]);
import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { n as __vitePreload, o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { D as Sparkles, En as Brain, Et as Layers, F as ShieldAlert, I as Share2, J as RefreshCw, Mn as Award, Nn as ArrowRight, Pn as ArrowLeft, Pt as Heart, S as Sun, _n as ChevronRight, bn as Check, cn as Clock, mn as CircleCheck, nn as Cpu, st as Moon, vn as ChevronLeft } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import { d as useAppTheme, l as useLanguage, o as TestScoringTrustBanner, s as OFFICIAL_LOGO_URL, u as useAuth } from "./index-C5uCeetQ.js";
import { t as motion } from "./vendor-motion-BS7ODJw7.js";
import { u as saveUnifiedTestRecord } from "./userHistoryService-6N9Zh8ed.js";
import { n as PsychometricAcademicIntro, r as ScientificClinicalDisclaimerBanner, t as PsychometricAcademicConclusion } from "./PsychometricAcademicFraming-DuCcNyEP.js";
import { PsychologyTestsModal } from "./PsychologyTestsModal-Ch9cgc-y.js";
import { t as PageSEO } from "./PageSEO-tUCGtj4d.js";
//#region src/data/personalityTestsData.ts
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var MBTI_ARCHETYPES_INFO = {
	INTJ: {
		titleAr: "المهندس المعماري الاستراتيجي",
		titleEn: "The Strategic Architect",
		roleAr: "المحللون الاستراتيجيون",
		roleEn: "Analysts",
		descriptionAr: "مفكر استراتيجي يمتلك خيالاً خصباً وإرادة فولاذية، يحب التخطيط بعيد المدى وبناء الأنظمة الفكرية المحكمة.",
		descriptionEn: "A strategic thinker with a thirst for knowledge and high self-discipline, excelling in long-term visionary planning.",
		strengthsAr: [
			"تفكير استراتيجي مستقل",
			"حل المشكلات المعقدة",
			"إتقان التخطيط المستقبلي",
			"معايير جودة عالية"
		],
		strengthsEn: [
			"Independent strategic thinking",
			"Complex problem solving",
			"High quality standards",
			"Forward planning"
		],
		relationalStyleAr: "يبحث عن العمق الفكري والشريك الواعي المستقل، ويفضل الحوارات العميقة على المجاملات العابرة.",
		relationalStyleEn: "Values cognitive depth and mutual independence, prioritizing substantive discussions over superficiality."
	},
	INTP: {
		titleAr: "المفكر الفيلسوف المنطقي",
		titleEn: "The Logical Thinker",
		roleAr: "المحللون الاستراتيجيون",
		roleEn: "Analysts",
		descriptionAr: "عقل تحليلي مبتكر لا يتوقف عن استكشاف النظريات وتفكيك المسلمات المنطقية وفهم بنية الكون.",
		descriptionEn: "An inventive analyst driven by curiosity, dissecting logical structures and theoretical models.",
		strengthsAr: [
			"براعة تحليلية متفردة",
			"انفتاح ذهني واسع",
			"أصالة الأفكار",
			"موضوعية نقدية"
		],
		strengthsEn: [
			"Exceptional analytical skill",
			"Intellectual open-mindedness",
			"Conceptual originality",
			"Objectivity"
		],
		relationalStyleAr: "يتواصل عبر تبادل الأفكار والنظريات، ويحتاج إلى شريك يقدر مساحته التأملية واستقلاليته الفكرية.",
		relationalStyleEn: "Connects through mental sparring, requiring a partner who respects their contemplative intellectual autonomy."
	},
	ENTJ: {
		titleAr: "القائد التنفيذي الحاسم",
		titleEn: "The Executive Commander",
		roleAr: "المحللون الاستراتيجيون",
		roleEn: "Analysts",
		descriptionAr: "قائد جريء وحاسم يحول الرؤى الكبرى إلى أهداف واقعية وخطط تنفيذية فعالة بحزم وكفاءة.",
		descriptionEn: "A bold, decisive leader who transforms expansive visions into tangible execution with efficiency.",
		strengthsAr: [
			"قيادة تنظيمية حازمة",
			"رؤية مستقبلية واضحة",
			"كفاءة اتخاذ القرار",
			"إرادة صلبة"
		],
		strengthsEn: [
			"Decisive leadership",
			"Clear strategic vision",
			"High decision efficacy",
			"Resilient willpower"
		],
		relationalStyleAr: "شريك محفز وواضح، يقدّر الطموح والمكاشفة الصريحة والنمو المشترك دون مواربة.",
		relationalStyleEn: "An encouraging, candid partner who values mutual ambition, transparent dialogue, and proactive growth."
	},
	ENTP: {
		titleAr: "المحاور والمبتكر المرن",
		titleEn: "The Innovative Visionary",
		roleAr: "المحللون الاستراتيجيون",
		roleEn: "Analysts",
		descriptionAr: "مفكر فضولي سريع البديهة، يعشق السجال الفكري وتوليد الحلول المبتكرة من زوايا غير مألوفة.",
		descriptionEn: "A quick-witted, curious thinker who thrives on mental debates and pioneering creative solutions.",
		strengthsAr: [
			"سرعة البديهة والابتكار",
			"رؤية احتمالات متعددة",
			"حيوية فكرية ملهمة",
			"مرونة تكيف عالية"
		],
		strengthsEn: [
			"Intellectual agility",
			"Spotting novel possibilities",
			"Inspirational vitality",
			"High adaptability"
		],
		relationalStyleAr: "يجلب الإثارة الفكرية والتجدد الدائم، ويزدهر مع شريك يشاركه متعة النقاش وتحدي الروتين.",
		relationalStyleEn: "Brings mental dynamism and novelty, flourishing with a partner who enjoys deep intellectual debate."
	},
	INFJ: {
		titleAr: "المستشار المحامي الملهم",
		titleEn: "The Insightful Advocate",
		roleAr: "الدبلوماسيون الإنسانيون",
		roleEn: "Diplomats",
		descriptionAr: "شخصية هادئة وبصيرة تمتلك قيماً إنسانية راسخة، تسعى لإحداث تأثير عميق وإيجابي في حياة الآخرين.",
		descriptionEn: "A quiet, visionary soul guided by deeply held moral convictions and profound interpersonal empathy.",
		strengthsAr: [
			"بصيرة وجدانية نافذة",
			"التزام أخلاقي عميق",
			"إلهام هادئ",
			"إخلاص ومسؤولية"
		],
		strengthsEn: [
			"Profound emotional insight",
			"Deep ethical grounding",
			"Inspiring quiet wisdom",
			"Unwavering loyalty"
		],
		relationalStyleAr: "يبحث عن التناغم الروحي الصادق، ويمنح شريكه أماناً وجدانياً استثنائياً وفهماً عميقاً للمشاعر.",
		relationalStyleEn: "Seeks authentic soulful resonance, providing exceptional emotional safety and deep empathetic understanding."
	},
	INFP: {
		titleAr: "الوسيط المثالي الأصيل",
		titleEn: "The Idealistic Mediator",
		roleAr: "الدبلوماسيون الإنسانيون",
		roleEn: "Diplomats",
		descriptionAr: "شخصية حالمة وأصيلة تتمسك بقيمها وتدافع عن العدالة، وتبحث دائماً عن الجمال والخير في العالم.",
		descriptionEn: "An authentic, poetic idealist driven by core values, championing compassion and individual uniqueness.",
		strengthsAr: [
			"أصالة المشاعر",
			"تعاطف إنساني دافئ",
			"إبداع فكري وأدبي",
			"وفاء للقيم"
		],
		strengthsEn: [
			"Emotional authenticity",
			"Warm human empathy",
			"Creative expression",
			"Loyalty to values"
		],
		relationalStyleAr: "شريك متفانٍ ورومانسي يقدر البوح الصادق، ويحتاج إلى بيئة داعمة تفهم مشاعره المرهفة.",
		relationalStyleEn: "A devoted, deeply romantic partner valuing vulnerable honesty and emotional gentleness."
	},
	ENFJ: {
		titleAr: "البطل الملهم والموجه",
		titleEn: "The Charismatic Protagonist",
		roleAr: "الدبلوماسيون الإنسانيون",
		roleEn: "Diplomats",
		descriptionAr: "قائد إنساني صاحب كاريزما دافئة، يمتلك قدرة فريدة على توحيد القلوب ودعم طاقات الآخرين وتطويرها.",
		descriptionEn: "A charismatic, empathetic leader who inspires communities and nurtures the potential of others.",
		strengthsAr: [
			"كاريزما تواصلية دافئة",
			"ذكاء اجتماعي متقدم",
			"تحفيز الطاقات الكامنة",
			"كرم العطاء الوجداني"
		],
		strengthsEn: [
			"Warm social charisma",
			"Advanced emotional IQ",
			"Empowering others",
			"Generous emotional support"
		],
		relationalStyleAr: "يستثمر بكل جوارحه في العلاقة، ويسعى دوماً لبناء بيئة مشتركة يسودها التفاهم والنمو المتبادل.",
		relationalStyleEn: "Invests deeply in interpersonal harmony, actively fostering mutual growth and emotional flourishing."
	},
	ENFP: {
		titleAr: "المناضل الشغوف بالحرية",
		titleEn: "The Passionate Campaigner",
		roleAr: "الدبلوماسيون الإنسانيون",
		roleEn: "Diplomats",
		descriptionAr: "روح حرة مبدعة مليئة بالحماس والبهجة، تجد المعنى في الروابط الإنسانية العميقة واستكشاف الآفاق الجديدة.",
		descriptionEn: "An enthusiastic, free-spirited explorer who finds deep meaning in authentic human connection.",
		strengthsAr: [
			"طاقة حيوية معدية",
			"خيال إبداعي خصب",
			"قدرة استثنائية على التواصل",
			"عفوية صادقة"
		],
		strengthsEn: [
			"Infectious enthusiasm",
			"Rich creative imagination",
			"Exceptional interpersonal rapport",
			"Sincere spontaneity"
		],
		relationalStyleAr: "يملأ العلاقة بالمرح والتجدد والدفء، ويفضل الشريك المنفتح الذي يشاركه شغف التجربة والاستكشاف.",
		relationalStyleEn: "Infuses relationships with joy and warmth, thriving with an open-minded partner who embraces spontaneous adventure."
	},
	ISTJ: {
		titleAr: "المفتش الواقعي الموثوق",
		titleEn: "The Reliable Logistician",
		roleAr: "الحراس والمنظمون",
		roleEn: "Sentinels",
		descriptionAr: "شخصية منظمة وواقعية تتمتع بأعلى درجات الالتزام والموثوقية، تحترم القواعد والعهود والواجبات.",
		descriptionEn: "A pragmatic, detail-oriented pillar of reliability, upholding order, duty, and systematic integrity.",
		strengthsAr: [
			"إخلاص وأمانة متناهية",
			"دقة وانضباط منهجي",
			"ثبات تحت الضغوط",
			"احترام الالتزامات"
		],
		strengthsEn: [
			"Uncompromising integrity",
			"Methodical discipline",
			"Composure under stress",
			"Honoring commitments"
		],
		relationalStyleAr: "سند متين يُعتمد عليه في كل الظروف، يعبر عن محبته بالأفعال العملية الصادقة وحماية أسرته.",
		relationalStyleEn: "An unwavering rock of dependability who demonstrates love through practical support and stability."
	},
	ISFJ: {
		titleAr: "المدافع الحنون المخلص",
		titleEn: "The Dedicated Defender",
		roleAr: "الحراس والمنظمون",
		roleEn: "Sentinels",
		descriptionAr: "حامٍ دافئ وصبور، يتميز بحس عالٍ بالمسؤولية ورعاية مشاعر أحبائه بصمت وإخلاص نادر.",
		descriptionEn: "A warm, patient guardian committed to protecting loved ones with devotion and steady grace.",
		strengthsAr: [
			"رعاية وجدانية دافئة",
			"ذاكرة يقظة للتفاصيل الإنسانية",
			"وفاء لا يتزعزع",
			"صبر وتواضع"
		],
		strengthsEn: [
			"Gentle emotional care",
			"Keen attentiveness to needs",
			"Steadfast loyalty",
			"Patience and humility"
		],
		relationalStyleAr: "يصنع بيئة منزلية دافئة ومستقرة، ويمنح الأولوية دائماً لراحة شريكه وانسجام الأسرة.",
		relationalStyleEn: "Creates a peaceful, nurturing domestic haven, prioritizing their partner’s comfort and wellbeing."
	},
	ESTJ: {
		titleAr: "المشرف التنفيذي الحريص",
		titleEn: "The Organized Executive",
		roleAr: "الحراس والمنظمون",
		roleEn: "Sentinels",
		descriptionAr: "شخصية قيادية عملية بارعة في تنظيم المشاريع وحفظ النظام والتقاليد وإدارة المسؤوليات بكفاءة.",
		descriptionEn: "A principled organizer dedicated to upholding standards, structured order, and family responsibility.",
		strengthsAr: [
			"تنظيم هيكلي صارم",
			"وضوح في التوجيه",
			"كفاءة في إدارة الموارد",
			"وفاء والتزام"
		],
		strengthsEn: [
			"Rigorous organization",
			"Direct communication",
			"Resource management",
			"Dependable loyalty"
		],
		relationalStyleAr: "شريك حاسم ومسؤول، يحمي استقرار البيت الأسري ويوفر الأمان المادي والتنظيمي لشريكه.",
		relationalStyleEn: "A decisive, protective partner who secures practical stability and structured support for the family."
	},
	ESFJ: {
		titleAr: "القنصل الاجتماعي المعطاء",
		titleEn: "The Supportive Consul",
		roleAr: "الحراس والمنظمون",
		roleEn: "Sentinels",
		descriptionAr: "شخصية اجتماعية دافئة ومحبوبة، تكرس طاقاتها لخدمة مجتمعها وترسيخ الروابط الأسرية الوثيقة.",
		descriptionEn: "A deeply social, caring harmony-seeker who dedicates energy to family warmth and community unity.",
		strengthsAr: [
			"ذكاء اجتماعي ودود",
			"حساسية عالية لاحتياجات الآخرين",
			"بناء التماسك الأسري",
			"كرم الضيافة"
		],
		strengthsEn: [
			"Warm social grace",
			"Keen empathy for others",
			"Fostering family unity",
			"Generous hospitality"
		],
		relationalStyleAr: "يعتني بأدق التفاصيل لإسعاد شريكه، ويسعى دوماً لتجنيب البيت الخلافات وبث أجواء المودة.",
		relationalStyleEn: "Attentive to every detail of emotional care, striving to maintain an affectionate, harmonious home."
	},
	ISTP: {
		titleAr: "الحرفي البارع المستقل",
		titleEn: "The Master Virtuoso",
		roleAr: "المستكشفون الميدانيون",
		roleEn: "Explorers",
		descriptionAr: "مستكشف واقعي هادئ وعملي، يمتلك مهارات استثنائية في تفكيك المشكلات وحلها بهدوء ومرونة.",
		descriptionEn: "A calm, practical problem-solver who excels at deciphering complex mechanisms with pragmatic agility.",
		strengthsAr: [
			"حل المشكلات العملية ببراعة",
			"هدوء تام في الأزمات",
			"استقلالية وواقعية",
			"مرونة تكيف"
		],
		strengthsEn: [
			"Pragmatic ingenuity",
			"Cool composure in crisis",
			"Self-reliance and grit",
			"High adaptability"
		],
		relationalStyleAr: "يقدر الحرية والمساحة الشخصية، ويعبر عن اهتمامه بالمساعدة العملية المباشرة بدلاً من الكلام.",
		relationalStyleEn: "Values personal freedom and displays affection through tangible acts of assistance rather than overt words."
	},
	ISFP: {
		titleAr: "الفنان المرهف والجمالي",
		titleEn: "The Gentle Adventurer",
		roleAr: "المستكشفون الميدانيون",
		roleEn: "Explorers",
		descriptionAr: "فنان رقيق يعيش اللحظة الحاضرة بحس جمالي رفيع وروح متواضعة وعواطف نبيلة صادقة.",
		descriptionEn: "A gentle, aesthetic soul living in the present with humble grace and deeply authentic emotion.",
		strengthsAr: [
			"ذائقة جمالية راقية",
			"تسامح ولطف استثنائي",
			"حس مرهف بالطبيعة",
			"عفوية صادقة"
		],
		strengthsEn: [
			"Refined aesthetic taste",
			"Exceptional tolerance and kindness",
			"Attunement to nature",
			"Sincere modesty"
		],
		relationalStyleAr: "شريك حنون ومتفهم لا يفرض قيوداً، ويسعى للتعبير عن مشاعره بلطف وإيثار هادئ.",
		relationalStyleEn: "A tender, non-judgmental partner who expresses love through quiet acts of thoughtfulness."
	},
	ESTP: {
		titleAr: "رائد الأعمال الميداني الجريء",
		titleEn: "The Bold Entrepreneur",
		roleAr: "المستكشفون الميدانيون",
		roleEn: "Explorers",
		descriptionAr: "شخصية حيوية وجريئة تعشق التحديات والمغامرة وتستجيب للفرص الميدانية بسرعة وذكاء.",
		descriptionEn: "An energetic, bold thrill-seeker who thrives on real-time challenges, action, and dynamic social impact.",
		strengthsAr: [
			"شجاعة المبادرة والمواجهة",
			"قراءة دقيقة للواقع الميداني",
			"جاذبية اجتماعية تلقائية",
			"تجاوب سريع"
		],
		strengthsEn: [
			"Courageous initiative",
			"Sharp real-time perception",
			"Magnetic spontaneous charm",
			"Rapid reflexes"
		],
		relationalStyleAr: "يبعث الحيوية والنشاط في حياة شريكه، ويفضل شريكاً واثقاً يشاركه الأنشطة والمغامرات.",
		relationalStyleEn: "Brings exhilarating energy into relationships, flourishing with a confident partner who loves action."
	},
	ESFP: {
		titleAr: "المؤدي المبهج ونجم الحفل",
		titleEn: "The Joyful Entertainer",
		roleAr: "المستكشفون الميدانيون",
		roleEn: "Explorers",
		descriptionAr: "شخصية عفوية ومرحة تحب الحياة وتشارك البهجة مع الجميع، وتجعل كل يوم تجربة مميزة.",
		descriptionEn: "A spontaneous, warm-hearted enthusiast who celebrates life, radiating joy and infectious generosity.",
		strengthsAr: [
			"بث الفرح والتفاؤل",
			"عفوية وود دائم",
			"كرم وسخاء وجداني",
			"حضور لافت"
		],
		strengthsEn: [
			"Radiating infectious optimism",
			"Warm spontaneity",
			"Generous affection",
			"Engaging presence"
		],
		relationalStyleAr: "يغمر شريكه بالمودة والبهجة، ويحرص على أن تكون الحياة المشتركة مفعمة بالذكريات الجميلة.",
		relationalStyleEn: "Showers their partner with affection and delight, ensuring shared life is filled with vibrant memories."
	}
};
var PERSONALITY_TESTS_CATALOG = [{
	id: "mbti_16types",
	titleAr: "مؤشر مايرز-بريغز للأنماط الـ 16 (Myers-Briggs / MBTI)",
	titleEn: "Myers-Briggs 16 Personality Types Indicator (MBTI)",
	subtitleAr: "التقييم الأكثر شهرة عالمياً لتحديد النمط النفسي وطريقة الإدراك وصنع القرار والتواصل",
	subtitleEn: "The world-renowned psychometric indicator for cognitive preferences and decision making",
	scientificOriginAr: "كارل يونغ (1921) ومؤشر مايرز وبريغز (Myers & Briggs, 1944/1985)",
	scientificOriginEn: "Carl G. Jung (1921) & Isabel Briggs Myers (1944/1985)",
	badgeAr: "16 نمطاً سيكولوجياً 🧠",
	badgeEn: "16 Archetypes 🧠",
	badgeColor: "#e11d48",
	estimatedMinutes: 6,
	questionCount: 16,
	iconName: "Compass",
	shortDescriptionAr: "استكشف نمطك النفسي عبر الأبعاد الأربعة: الانبساط مقابل الانطواء، الحس مقابل الحدس، التفكير مقابل المشاعر، والحكم مقابل الإدراك.",
	shortDescriptionEn: "Discover your psychological archetype across 4 polar dimensions: E/I, S/N, T/F, and J/P.",
	dimensions: [
		{
			key: "EI",
			nameAr: "مصدر الطاقة الوجدانية",
			nameEn: "Energy Orientation",
			descriptionAr: "أين توجه طاقتك: نحو التفاعل الخارجي والناس أم نحو التأمل الداخلي والهدوء.",
			descriptionEn: "How you channel energy: external social immersion vs internal reflective solitude.",
			lowPoleAr: "انطواء (I)",
			highPoleAr: "انبساط (E)",
			lowPoleEn: "Introversion (I)",
			highPoleEn: "Extraversion (E)"
		},
		{
			key: "SN",
			nameAr: "طريقة استيعاب المعلومات",
			nameEn: "Information Processing",
			descriptionAr: "كيف تدرك العالم: عبر الحقائق والوقائع الحسية الملموسة أم عبر الحدس والمعاني المجردة.",
			descriptionEn: "How you perceive reality: tangible empirical facts vs abstract intuitive possibilities.",
			lowPoleAr: "حسي (S)",
			highPoleAr: "حدسي (N)",
			lowPoleEn: "Sensing (S)",
			highPoleEn: "Intuition (N)"
		},
		{
			key: "TF",
			nameAr: "منهجية اتخاذ القرار",
			nameEn: "Decision Making",
			descriptionAr: "كيف تزن الخيارات: بالمنطق والموضوعية المجردة أم بالتعاطف والقيم الإنسانية.",
			descriptionEn: "How you evaluate choices: impersonal logic and objective criteria vs personal values and empathy.",
			lowPoleAr: "تفكير (T)",
			highPoleAr: "مشاعر (F)",
			lowPoleEn: "Thinking (T)",
			highPoleEn: "Feeling (F)"
		},
		{
			key: "JP",
			nameAr: "أسلوب تنظيم الحياة",
			nameEn: "Lifestyle Orientation",
			descriptionAr: "كيف تتعامل مع العالم الخارجي: بالتخطيط المنهجي الحاسم أم بالمرونة والعفوية.",
			descriptionEn: "How you approach life: structured planning and decisiveness vs open-ended adaptability.",
			lowPoleAr: "حكم (J)",
			highPoleAr: "إدراك مرن (P)",
			lowPoleEn: "Judging (J)",
			highPoleEn: "Perceiving (P)"
		}
	],
	questions: [
		{
			id: 1,
			dimension: "EI",
			textAr: "أشعر بالحيوية وتجدد طاقتي عند التواجد في تجمعات اجتماعية حوارية بدلاً من قضاء وقت طويل بمفردي.",
			textEn: "I feel energized and recharged when interacting in social gatherings rather than spending quiet time alone.",
			positivePole: "E",
			weight: 1
		},
		{
			id: 2,
			dimension: "SN",
			textAr: "أفضل التركيز على الوقائع والبيانات العملية الملموسة بدلاً من الغوص في النظريات والاحتمالات المجردة.",
			textEn: "I prefer focusing on tangible facts and realistic data rather than delving into abstract theories and speculation.",
			positivePole: "S",
			weight: 1
		},
		{
			id: 3,
			dimension: "TF",
			textAr: "عند اتخاذ القرارات المصيرية، أضع المنطق والموضوعية المجردة فوق الاعتبارات العاطفية ومشاعر الأطراف.",
			textEn: "When making pivotal decisions, I prioritize objective logic and fairness over emotional considerations and feelings.",
			positivePole: "T",
			weight: 1
		},
		{
			id: 4,
			dimension: "JP",
			textAr: "أرتاح جداً بوجود جدول زمني منظم ومحدد مسبقاً لكل خطوة بدلاً من ترك الأمور للظروف والعفوية.",
			textEn: "I feel most at ease with an organized, predefined schedule rather than leaving things open to spontaneous impulse.",
			positivePole: "J",
			weight: 1
		},
		{
			id: 5,
			dimension: "EI",
			textAr: "أميل إلى التعبير عن أفكاري ومشاركتها بصوت مسموع مع الآخرين أثناء معالجتها وتطويرها.",
			textEn: "I tend to express and process my thoughts out loud with others while developing solutions.",
			positivePole: "E",
			weight: 1
		},
		{
			id: 6,
			dimension: "SN",
			textAr: "يستهويني استشراف المستقبل وقراءة ما بين السطور والبحث عن المعاني الكامنة خلف الظواهر.",
			textEn: "I am naturally drawn to envisioning future patterns, reading between the lines, and seeking hidden metaphors.",
			positivePole: "N",
			weight: 1
		},
		{
			id: 7,
			dimension: "TF",
			textAr: "أهتم أولاً بالحفاظ على مشاعر الآخرين والانسجام الإنساني حتى لو تطلب ذلك تليين بعض الحقائق الجافة.",
			textEn: "I prioritize preserving interpersonal harmony and empathetic connection, even if it requires softening blunt truths.",
			positivePole: "F",
			weight: 1
		},
		{
			id: 8,
			dimension: "JP",
			textAr: "أحب المرونة والخيارات المفتوحة وأستمتع بتغيير الخطط في اللحظة الأخيرة وفق متطلبات اللحظة.",
			textEn: "I value flexibility and open options, feeling stimulated when adjusting plans spontaneously on the fly.",
			positivePole: "P",
			weight: 1
		},
		{
			id: 9,
			dimension: "EI",
			textAr: "بعد أسبوع عمل شاق، أفضّل قضاء عطلة نهاية الأسبوع في هدوء منزلي لقراءة كتاب أو ممارسة هواية شخصية.",
			textEn: "After an intense work week, I prefer spending the weekend in solitary peace reading or pursuing personal hobbies.",
			positivePole: "I",
			weight: 1
		},
		{
			id: 10,
			dimension: "SN",
			textAr: "أعتمد في بناء آرائي على التجارب الواقعية السابقة والأدلة المحسوسة بدلاً من الحدس والتخمين.",
			textEn: "I base my convictions on concrete historical experience and empirical evidence rather than gut instinct.",
			positivePole: "S",
			weight: 1
		},
		{
			id: 11,
			dimension: "TF",
			textAr: "في النقاشات، يسهل عليّ نقد الأفكار وتشريح نقاط الضعف المنطقية دون أن أقصد التجريح الشخصي.",
			textEn: "In debates, I readily dissect logical inconsistencies and critique flawed premises without personal malice.",
			positivePole: "T",
			weight: 1
		},
		{
			id: 12,
			dimension: "JP",
			textAr: "أحرص على إنهاء المهام والواجبات وإغلاق الملفات قبل الموعد النهائي بوقت كافٍ لتجنب أي ضغط.",
			textEn: "I ensure tasks and deadlines are finalized well ahead of time to avoid last-minute chaotic pressure.",
			positivePole: "J",
			weight: 1
		},
		{
			id: 13,
			dimension: "EI",
			textAr: "أجد سهولة كبيرة في بدء الحوار والتعرف على أشخاص جدد في المناسبات والمؤتمرات دون تردد.",
			textEn: "I find it easy to initiate conversations and break the ice with new acquaintances at gatherings without hesitation.",
			positivePole: "E",
			weight: 1
		},
		{
			id: 14,
			dimension: "SN",
			textAr: "غالباً ما تخطر ببالي أفكار إبداعية وروابط مبتكرة بين مواضيع تبدو ظاهرياً غير متصلة.",
			textEn: "I frequently generate novel connections and conceptual analogies between seemingly unrelated fields.",
			positivePole: "N",
			weight: 1
		},
		{
			id: 15,
			dimension: "TF",
			textAr: "أتأثر بعمق بمعاناة الآخرين وأعتبر التعاطف الوجداني معيار النجاح الأخلاقي الأول في أي مجتمع.",
			textEn: "I am deeply moved by the emotional struggles of others, viewing compassion as the primary metric of moral integrity.",
			positivePole: "F",
			weight: 1
		},
		{
			id: 16,
			dimension: "JP",
			textAr: "أعمل بكفاءة وإبداع أعلى تحت وطأة المواعيد العاجلة وضغط اللحظات الأخيرة بدلاً من الروتين الصارم.",
			textEn: "I work with heightened creativity and focus under impending deadlines rather than through strict rigid pacing.",
			positivePole: "P",
			weight: 1
		}
	]
}, {
	id: "big_five_ocean",
	titleAr: "مقياس السمات الخمس الكبرى للشخصية (Big Five / OCEAN)",
	titleEn: "Big Five Personality Traits Assessment (OCEAN)",
	subtitleAr: "المعيار الذهبي الأكثر قبولاً ورصانة في الأوساط الأكاديمية والبحثية لعلم النفس الحديث",
	subtitleEn: "The gold standard personality inventory in modern empirical academic research",
	scientificOriginAr: "كوستا وماك كري (Costa & McCrae, 1992 - NEO-PI-R Standard)",
	scientificOriginEn: "Paul Costa & Robert McCrae (1992 - NEO Personality Inventory)",
	badgeAr: "المعيار الأكاديمي الذهبي 🌍",
	badgeEn: "Empirical Gold Standard 🌍",
	badgeColor: "#8b5cf6",
	estimatedMinutes: 6,
	questionCount: 15,
	iconName: "Brain",
	shortDescriptionAr: "يقيس الأبعاد الخمسة الأساسية التي تحكم السلوك الإنساني: الانفتاح، الضمير، الانبساط، الوفاق، والاتزان الانفعالي.",
	shortDescriptionEn: "Evaluates the five universal behavioral dimensions: Openness, Conscientiousness, Extraversion, Agreeableness, and Emotional Stability.",
	dimensions: [
		{
			key: "O",
			nameAr: "الانفتاح على الخبرة (Openness)",
			nameEn: "Openness to Experience",
			descriptionAr: "مدى الفضول المعرفي والإبداع والتذوق الجمالي والاهتمام بالأفكار غير التقليدية.",
			descriptionEn: "Intellectual curiosity, aesthetic sensitivity, and appetite for novel unconventional ideas.",
			lowPoleAr: "تقليدي وواقعي",
			highPoleAr: "مبتكر وفضولي",
			lowPoleEn: "Traditional & Pragmatic",
			highPoleEn: "Creative & Curious"
		},
		{
			key: "C",
			nameAr: "يقظة الضمير والانضباط (Conscientiousness)",
			nameEn: "Conscientiousness",
			descriptionAr: "درجة التنظيم الذاتي، الالتزام بالواجبات، دقة المواعيد، وضبط الدوافع والمشتتات.",
			descriptionEn: "Self-discipline, methodical organization, diligence, and goal-directed persistence.",
			lowPoleAr: "مرن وعفوي",
			highPoleAr: "منضبط ودقيق",
			lowPoleEn: "Spontaneous & Easygoing",
			highPoleEn: "Disciplined & Methodical"
		},
		{
			key: "E",
			nameAr: "الانبساطية والاجتماعية (Extraversion)",
			nameEn: "Extraversion",
			descriptionAr: "مستوى الطاقة الاجتماعية، الرغبة في التفاعل، الحزم في التعبير، والميل للبهجة.",
			descriptionEn: "Assertiveness, positive emotionality, enthusiasm, and desire for social stimulation.",
			lowPoleAr: "هادئ ومتحفظ",
			highPoleAr: "حيوي واجتماعي",
			lowPoleEn: "Reserved & Quiet",
			highPoleEn: "Outgoing & Energetic"
		},
		{
			key: "A",
			nameAr: "الوفاق والتعاون (Agreeableness)",
			nameEn: "Agreeableness",
			descriptionAr: "الميل لمساعدة الآخرين، التسامح، التعاطف، وتغليب الانسجام المشترك على الصدام.",
			descriptionEn: "Altruism, empathy, trust, and natural predisposition towards interpersonal cooperation.",
			lowPoleAr: "تنافسي وحازم",
			highPoleAr: "متعاون ومتسامح",
			lowPoleEn: "Competitive & Skeptical",
			highPoleEn: "Compassionate & Trusting"
		},
		{
			key: "N",
			nameAr: "الاتزان الانفعالي (Emotional Stability)",
			nameEn: "Emotional Stability",
			descriptionAr: "القدرة على مواجهة الضغوط، الاتزان تحت الصدمات، وتجنب القلق المزمن وتذبذب المزاج.",
			descriptionEn: "Resilience under acute stress, psychological steadiness, and freedom from chronic anxiety.",
			lowPoleAr: "حساس ومرهف",
			highPoleAr: "صلب وهادئ",
			lowPoleEn: "Emotionally Sensitive",
			highPoleEn: "Resilient & Composed"
		}
	],
	questions: [
		{
			id: 1,
			dimension: "O",
			textAr: "أمتلك فضولاً واسعاً لاستكشاف الفنون والثقافات الجديدة وخوض تجارب فكرية وفلسفية غير مألوفة.",
			textEn: "I have intense intellectual curiosity to explore new arts, diverse cultures, and philosophical inquiries.",
			positivePole: "O",
			weight: 1
		},
		{
			id: 2,
			dimension: "C",
			textAr: "أحرص على الدقة العالية في مواعيدي وتنظيم شؤوني الشخصية بدقة متناهية وإنجاز واجباتي بأمانة.",
			textEn: "I am meticulous regarding punctuality, personal organization, and carrying out duties conscientiously.",
			positivePole: "C",
			weight: 1
		},
		{
			id: 3,
			dimension: "E",
			textAr: "أحب التواجد في قلب الأحداث والتواصل الحيوي مع المحيطين بي وبث الحماس في الجلسات.",
			textEn: "I naturally enjoy being at the center of social activity, radiating energy and engaging actively with groups.",
			positivePole: "E",
			weight: 1
		},
		{
			id: 4,
			dimension: "A",
			textAr: "أفترض حسن النية في الناس وأميل إلى التعاون والتسامح وتجنب الصراعات والخصومات قدر الإمكان.",
			textEn: "I assume good intentions in others, naturally leaning towards cooperation, forgiveness, and conflict resolution.",
			positivePole: "A",
			weight: 1
		},
		{
			id: 5,
			dimension: "N",
			textAr: "أحتفظ بهدوء أعصابي واتزاني الانفعالي حتى في أوقات الأزمات والضغوط الحياتية المفاجئة.",
			textEn: "I maintain emotional equilibrium and composed clarity even during unexpected crises and high-pressure moments.",
			positivePole: "ES",
			weight: 1
		},
		{
			id: 6,
			dimension: "O",
			textAr: "يستهويني تجديد الروتين اليومي وتجربة أساليب غير تقليدية في العمل والمعيشة والتفكير.",
			textEn: "I love breaking repetitive routines and experimenting with non-conventional lifestyle and working methods.",
			positivePole: "O",
			weight: 1
		},
		{
			id: 7,
			dimension: "C",
			textAr: "أحدد أهدافي بوضوح وأمتلك قوة إرادة كافية للاستمرار حتى تحقيقها دون استسلام للمشتتات.",
			textEn: "I define clear milestones and possess the disciplined grit required to accomplish them despite distractions.",
			positivePole: "C",
			weight: 1
		},
		{
			id: 8,
			dimension: "E",
			textAr: "أشعر بالراحة الكاملة عند التحدث أمام جمهور أو إدارة حوار جماعي دون تردد أو خجل.",
			textEn: "I feel confident speaking in front of an audience or moderating group discussions without self-consciousness.",
			positivePole: "E",
			weight: 1
		},
		{
			id: 9,
			dimension: "A",
			textAr: "أجد سعادتي الحقيقية في مساعدة الآخرين ومساندتهم في ظروفهم الصعبة دون انتظار مقابل.",
			textEn: "I derive genuine fulfillment from helping and supporting others during their difficult times altruistically.",
			positivePole: "A",
			weight: 1
		},
		{
			id: 10,
			dimension: "N",
			textAr: "نادراً ما أقع فريسة للقلق المفرط أو الأفكار السلبية المتكررة حول المستقبل.",
			textEn: "I rarely succumb to chronic anxiety or catastrophic ruminations regarding the unknown future.",
			positivePole: "ES",
			weight: 1
		},
		{
			id: 11,
			dimension: "O",
			textAr: "أستمتع بتأمل الأفكار المجردة والمجازات الأدبية والمعاني الرمزية في الحياة والمواقف.",
			textEn: "I deeply appreciate conceptual symbolism, poetic metaphors, and abstract philosophical meaning.",
			positivePole: "O",
			weight: 1
		},
		{
			id: 12,
			dimension: "C",
			textAr: "أفكر بعمق في عواقب قراراتي قبل اتخاذها وأتجنب التهور أو القرارات اللحظية غير المدروسة.",
			textEn: "I weigh long-term ramifications thoroughly before acting, avoiding impulsive or uncalculated leaps.",
			positivePole: "C",
			weight: 1
		},
		{
			id: 13,
			dimension: "E",
			textAr: "أبادر تلقائياً بالترحيب بالغرباء وإشراك المنعزلين لضمان شعور الجميع بالاندماج.",
			textEn: "I proactively welcome newcomers and engage reserved individuals to foster an inclusive social atmosphere.",
			positivePole: "E",
			weight: 1
		},
		{
			id: 14,
			dimension: "A",
			textAr: "أتقبل وجهات النظر المعارضة بصدر رحب وأحترم التنوع في الآراء دون تعصب أو عداء.",
			textEn: "I welcome dissenting viewpoints with grace and respect ideological diversity without hostility.",
			positivePole: "A",
			weight: 1
		},
		{
			id: 15,
			dimension: "N",
			textAr: "أتعافى سريعاً من خيبات الأمل وأستعيد تفاؤلي وطاقتي الإيجابية بعد أي عثرة شخصية أو مهنية.",
			textEn: "I bounce back rapidly from setbacks, swiftly reclaiming psychological resilience and forward optimism.",
			positivePole: "ES",
			weight: 1
		}
	]
}];
//#endregion
//#region src/pages/PersonalityTestsPage.tsx
var import_jsx_runtime = require_jsx_runtime();
var LazyIntelligenceTestModal = (0, import_react.lazy)(() => __vitePreload(() => import("./IntelligenceTestModal-CZZJt6S0.js").then((m) => ({ default: m.IntelligenceTestModal })), __vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10])));
var LazyTieredAssessmentModule = (0, import_react.lazy)(() => __vitePreload(() => import("./TieredAssessmentModule-u6C5tZZz.js").then((m) => ({ default: m.TieredAssessmentModule })), __vite__mapDeps([11,1,2,3,4,5,8,7,6,10])));
var PersonalityTestsPage = ({ onBackToHome, onNavigatePage }) => {
	const { language, isRTL, toggleLanguage } = useLanguage();
	const { user } = useAuth();
	const [theme, toggleTheme] = useAppTheme();
	const isAr = language === "ar";
	const isLight = theme === "light";
	const [activeTest, setActiveTest] = (0, import_react.useState)(null);
	const [currentQuestionIndex, setCurrentQuestionIndex] = (0, import_react.useState)(0);
	const [answers, setAnswers] = (0, import_react.useState)({});
	const [isCompleted, setIsCompleted] = (0, import_react.useState)(false);
	const [isSavingCloud, setIsSavingCloud] = (0, import_react.useState)(false);
	const [cloudSaved, setCloudSaved] = (0, import_react.useState)(false);
	const [copiedShare, setCopiedShare] = (0, import_react.useState)(false);
	const [isIntelligenceModalOpen, setIsIntelligenceModalOpen] = (0, import_react.useState)(false);
	const [isPsychModalOpen, setIsPsychModalOpen] = (0, import_react.useState)(false);
	const [mbtiResult, setMbtiResult] = (0, import_react.useState)(null);
	const [bigFiveResult, setBigFiveResult] = (0, import_react.useState)(null);
	const likertOptions = isAr ? [
		{
			value: 1,
			label: "أعارض بشدة",
			color: "hover:border-rose-500 hover:text-rose-400"
		},
		{
			value: 2,
			label: "أعارض",
			color: "hover:border-rose-400/60 hover:text-rose-300"
		},
		{
			value: 3,
			label: "محايد",
			color: "hover:border-slate-500 hover:text-slate-300"
		},
		{
			value: 4,
			label: "أوافق",
			color: "hover:border-emerald-400/60 hover:text-emerald-300"
		},
		{
			value: 5,
			label: "أوافق بشدة",
			color: "hover:border-emerald-500 hover:text-emerald-400"
		}
	] : [
		{
			value: 1,
			label: "Strongly Disagree",
			color: "hover:border-rose-500 hover:text-rose-400"
		},
		{
			value: 2,
			label: "Disagree",
			color: "hover:border-rose-400/60 hover:text-rose-300"
		},
		{
			value: 3,
			label: "Neutral",
			color: "hover:border-slate-500 hover:text-slate-300"
		},
		{
			value: 4,
			label: "Agree",
			color: "hover:border-emerald-400/60 hover:text-emerald-300"
		},
		{
			value: 5,
			label: "Strongly Agree",
			color: "hover:border-emerald-500 hover:text-emerald-400"
		}
	];
	const handleStartTest = (test) => {
		soundManager.playTap();
		setActiveTest(test);
		setCurrentQuestionIndex(0);
		setAnswers({});
		setIsCompleted(false);
		setCloudSaved(false);
		setMbtiResult(null);
		setBigFiveResult(null);
		window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
	};
	const handleSelectAnswer = (questionId, value) => {
		soundManager.playTap();
		const updated = {
			...answers,
			[questionId]: value
		};
		setAnswers(updated);
		if (activeTest && currentQuestionIndex < activeTest.questions.length - 1) setTimeout(() => {
			setCurrentQuestionIndex((prev) => prev + 1);
		}, 220);
		else if (activeTest && currentQuestionIndex === activeTest.questions.length - 1) calculateAndSaveResults(activeTest, updated);
	};
	const calculateAndSaveResults = async (test, finalAnswers) => {
		setIsCompleted(true);
		setIsSavingCloud(true);
		if (test.id === "mbti_16types" || test.id === "mbti_16") {
			const sums = {
				EI: {
					score: 0,
					count: 0
				},
				SN: {
					score: 0,
					count: 0
				},
				TF: {
					score: 0,
					count: 0
				},
				JP: {
					score: 0,
					count: 0
				}
			};
			test.questions.forEach((q) => {
				const raw = finalAnswers[q.id] || 3;
				const isFirstPole = [
					"E",
					"S",
					"T",
					"J"
				].includes(q.positivePole);
				const val = (q.direction !== void 0 ? q.direction === 1 : isFirstPole) ? raw : 6 - raw;
				if (sums[q.dimension]) {
					sums[q.dimension].score += val;
					sums[q.dimension].count += 1;
				}
			});
			const calcPct = (dim) => {
				const item = sums[dim];
				if (!item || item.count === 0) return 50;
				const min = item.count * 1;
				const max = item.count * 5;
				return Math.round((item.score - min) / (max - min) * 100);
			};
			const E = calcPct("EI");
			const I = 100 - E;
			const S = calcPct("SN");
			const N = 100 - S;
			const T = calcPct("TF");
			const F = 100 - T;
			const J = calcPct("JP");
			const P = 100 - J;
			const typeCode = `${E >= 50 ? "E" : "I"}${S >= 50 ? "S" : "N"}${T >= 50 ? "T" : "F"}${J >= 50 ? "J" : "P"}`;
			const archetype = MBTI_ARCHETYPES_INFO[typeCode] || MBTI_ARCHETYPES_INFO["INFJ"];
			setMbtiResult({
				typeCode,
				archetype,
				percentages: {
					E,
					I,
					S,
					N,
					T,
					F,
					J,
					P
				}
			});
			try {
				await saveUnifiedTestRecord(user || null, {
					testType: "psychology",
					testTitleAr: "مؤشر الأنماط الـ16 لمايرز-بريغز (MBTI)",
					testCategoryAr: "مقاييس الشخصية المعتمدة",
					scoreOrArchetype: `${typeCode} - ${archetype.titleAr}`,
					percentage: Math.max(E, I),
					badgeColor: "#f43f5e",
					keyInsights: archetype.strengthsAr,
					snapshot: {
						typeCode,
						percentages: {
							E,
							I,
							S,
							N,
							T,
							F,
							J,
							P
						},
						timestamp: (/* @__PURE__ */ new Date()).toISOString()
					}
				});
				setCloudSaved(true);
			} catch (e) {
				console.warn("Cloud save fallback", e);
			} finally {
				setIsSavingCloud(false);
			}
		} else if (test.id === "big_five_ocean" || test.id === "big_five") {
			const sums = {
				O: {
					score: 0,
					count: 0
				},
				C: {
					score: 0,
					count: 0
				},
				E: {
					score: 0,
					count: 0
				},
				A: {
					score: 0,
					count: 0
				},
				ES: {
					score: 0,
					count: 0
				}
			};
			test.questions.forEach((q) => {
				const raw = finalAnswers[q.id] || 3;
				const val = q.direction === -1 ? 6 - raw : raw;
				const dimKey = q.dimension === "N" ? "ES" : q.dimension;
				if (sums[dimKey]) {
					sums[dimKey].score += val;
					sums[dimKey].count += 1;
				}
			});
			const calcPct = (dim) => {
				const item = sums[dim];
				if (!item || item.count === 0) return 50;
				const min = item.count * 1;
				const max = item.count * 5;
				return Math.round((item.score - min) / (max - min) * 100);
			};
			const scores = {
				O: calcPct("O"),
				C: calcPct("C"),
				E: calcPct("E"),
				A: calcPct("A"),
				ES: calcPct("ES")
			};
			setBigFiveResult({ scores });
			try {
				await saveUnifiedTestRecord(user || null, {
					testType: "psychology",
					testTitleAr: "مقياس العوامل الخمسة الكبرى (Big Five / OCEAN)",
					testCategoryAr: "مقاييس الشخصية المعتمدة",
					scoreOrArchetype: `الانفتاح ${scores.O}% • الانضباط ${scores.C}%`,
					percentage: Math.round((scores.O + scores.C + scores.E + scores.A + scores.ES) / 5),
					badgeColor: "#8b5cf6",
					keyInsights: [
						`الانفتاح الفكري: ${scores.O}%`,
						`الانضباط الذاتي: ${scores.C}%`,
						`الاتزان الانفعالي: ${scores.ES}%`
					],
					snapshot: {
						scores,
						timestamp: (/* @__PURE__ */ new Date()).toISOString()
					}
				});
				setCloudSaved(true);
			} catch (e) {
				console.warn("Cloud save fallback", e);
			} finally {
				setIsSavingCloud(false);
			}
		}
	};
	const handleShareResult = () => {
		soundManager.playTap();
		if (navigator.clipboard) navigator.clipboard.writeText(window.location.href).then(() => {
			setCopiedShare(true);
			setTimeout(() => setCopiedShare(false), 2500);
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		dir: isAr ? "rtl" : "ltr",
		className: `w-full min-h-screen py-6 sm:py-10 px-3 sm:px-6 transition-colors duration-300 selection:bg-rose-500/30 ${isLight ? "bg-slate-50 text-slate-900" : "text-slate-100"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageSEO, {
				title: isAr ? "مختبر مقاييس الشخصية واختبارات الذكاء المعتمدة (MBTI, Big Five, IQ, EQ) | مرآة القلوب" : "Certified Personality & Intelligence Assessments (MBTI, Big Five, IQ, EQ) | Mirror of Hearts",
				description: isAr ? "مختبر المقاييس السيكومترية واختبارات الذكاء الموثق بمراجع APA: مؤشر مايرز-بريغز (MBTI)، العوامل الخمسة الكبرى (OCEAN)، الذكاءات المتعددة لجاردنر، مصفوفات رافين للذكاء، ومقياس كاتل 16PF." : "APA-referenced psychometric and intelligence laboratory: Myers-Briggs 16 Types (MBTI), Big Five (OCEAN), Gardner Multiple Intelligences, Raven Fluid IQ, and Cattell 16PF.",
				canonicalPath: "/#/personality-tests",
				language
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-5xl mx-auto space-y-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `flex flex-wrap items-center justify-between gap-3 pb-4 border-b ${isLight ? "border-slate-200" : "border-white/10"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `flex items-center gap-2 text-xs ${isLight ? "text-slate-600" : "text-slate-400"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: onBackToHome,
									className: "hover:text-rose-500 transition cursor-pointer flex items-center gap-1 font-semibold",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "الرئيسية" : "Home" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "/" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `font-bold ${isLight ? "text-slate-900" : "text-white"}`,
									children: isAr ? "مختبر المقاييس السيكومترية واختبارات الذكاء" : "Psychometric & Intelligence Assessment Lab"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => {
										soundManager.playTap();
										toggleTheme();
									},
									"aria-label": isAr ? "تبديل الوضع الليلي والنهاري" : "Toggle Dark/Light Mode",
									className: `px-3 py-1.5 rounded-xl border text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${isLight ? "bg-white hover:bg-slate-100 border-slate-300 text-amber-700 shadow-sm" : "bg-white/5 hover:bg-white/10 border-white/10 text-amber-300"}`,
									children: [isLight ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isLight ? isAr ? "الوضع الليلي" : "Dark Mode" : isAr ? "الوضع النهاري" : "Light Mode" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: toggleLanguage,
									className: `px-3 py-1.5 rounded-xl border text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${isLight ? "bg-white hover:bg-slate-100 border-slate-300 text-sky-700 shadow-sm" : "bg-white/5 hover:bg-white/10 border-white/10 text-sky-300"}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "English (EN)" : "العربية (AR)" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: onBackToHome,
									className: `px-3 py-1.5 rounded-xl border text-xs font-bold transition flex items-center gap-1 cursor-pointer ${isLight ? "bg-rose-50 hover:bg-rose-100 border-rose-200 text-rose-700" : "bg-rose-500/20 hover:bg-rose-500/30 border-rose-500/40 text-rose-300"}`,
									children: [isRTL ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "العودة للرئيسية" : "Back to Home" })]
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PsychometricAcademicIntro, {
						variant: "page",
						focusScope: "all"
					}),
					!activeTest && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
								className: `relative overflow-hidden rounded-3xl border p-8 sm:p-10 shadow-xl ${isLight ? "bg-gradient-to-r from-rose-50 via-white to-purple-50 border-rose-200" : "bg-gradient-to-r from-rose-950/40 via-slate-900/90 to-purple-950/40 border-rose-500/30"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative z-10 max-w-3xl space-y-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-14 h-14 rounded-2xl p-0.5 bg-gradient-to-tr from-rose-500 via-pink-500 to-violet-600 shadow-lg shadow-rose-500/25 shrink-0 overflow-hidden",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "w-full h-full rounded-[14px] bg-[#0b0e17] overflow-hidden flex items-center justify-center",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
													src: OFFICIAL_LOGO_URL,
													alt: isAr ? "شعار مرآة القلوب الرسمي" : "Mirror of Hearts Official Logo",
													className: "w-full h-full object-cover rounded-[14px]"
												})
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: `inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold border mb-1.5 ${isLight ? "bg-rose-100 text-rose-800 border-rose-300" : "bg-rose-500/20 text-rose-300 border-rose-500/40"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "المقاييس النفسية واختبارات الذكاء العالمية المعتمدة" : "Validated Psychometric & Cognitive Intelligence Inventories" })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
											className: `text-2xl sm:text-4xl font-black tracking-tight ${isLight ? "text-slate-900" : "text-white"}`,
											children: isAr ? "قسم تحليل الشخصية — اكتشف شخصيتك بعمق" : "Personality Analysis — Discover Your Personality Deeply"
										})] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: `text-sm sm:text-base leading-relaxed ${isLight ? "text-slate-700" : "text-slate-300"}`,
										children: isAr ? "اختر أحد المقاييس السيكومترية أو بطاريات الذكاء العالمية لفهم بنيتك المعرفية، نقاط قوتك الفطرية، وطبيعة تفاعلك في العلاقات الإنسانية والمهنية مع حفظ سحابي وتقارير PDF فورية." : "Select a validated psychometric scale or cognitive intelligence battery to uncover your cognitive architecture, natural strengths, and relational dynamics with cloud persistence and PDF reports."
									})]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `p-6 sm:p-8 rounded-3xl border space-y-5 ${isLight ? "bg-white border-slate-200/90 shadow-sm" : "bg-slate-900/70 border-white/10 shadow-lg"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: `text-xl sm:text-2xl font-black font-['Alexandria'] ${isLight ? "text-slate-900" : "text-white"}`,
										children: isAr ? "عن قسم تحليل الشخصية" : "About Personality Analysis"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: `text-xs sm:text-sm leading-relaxed md:leading-loose ${isLight ? "text-slate-600" : "text-slate-300"}`,
										children: isAr ? "يساعدك قسم تحليل الشخصية على فهم ذاتك بصورة أوضح من خلال مجموعة من الأدوات والاختبارات المصممة لاستكشاف أنماط التفكير والسلوك والسمات الشخصية. يهدف هذا القسم إلى تعزيز الوعي الذاتي ومساعدتك على تطوير نقاط القوة وفهم جوانب شخصيتك المختلفة." : "The personality analysis section empowers you to understand yourself with greater clarity through instruments designed to explore cognitive styles, behaviors, and core traits, unlocking your inner potential."
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 md:grid-cols-2 gap-4 pt-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `p-4 rounded-2xl border ${isLight ? "bg-emerald-50/70 border-emerald-100" : "bg-emerald-950/20 border-emerald-500/20"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
											className: `text-xs font-black mb-2.5 font-['Alexandria'] flex items-center gap-1.5 ${isLight ? "text-emerald-900" : "text-emerald-300"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-4 h-4 text-emerald-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "مميزات القسم:" : "Section Features:" })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
											className: "space-y-1.5 text-xs",
											children: (isAr ? [
												"نتائج واضحة وسهلة الفهم",
												"تقارير تفصيلية وشاملة",
												"تحليل لأنماط التفكير والسلوك",
												"توصيات عملية للتطوير الشخصي",
												"تجربة تفاعلية وسهلة الاستخدام",
												"تحديثات وتحسينات مستمرة"
											] : [
												"Clear, digestible analytical results",
												"Comprehensive multi-page reports",
												"Cognitive and behavioral style analysis",
												"Practical self-growth recommendations",
												"Interactive, user-friendly experience",
												"Continuous updates and psychometric refinements"
											]).map((feat, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
												className: `flex items-center gap-2 ${isLight ? "text-slate-700" : "text-slate-200"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-emerald-500 shrink-0 font-bold",
													children: "✓"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: feat })]
											}, idx))
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `p-4 rounded-2xl border ${isLight ? "bg-slate-50/80 border-slate-200/80" : "bg-white/[0.03] border-white/5"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
											className: `text-xs font-black mb-2.5 font-['Alexandria'] flex items-center gap-1.5 ${isLight ? "text-slate-800" : "text-slate-200"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-4 h-4 text-indigo-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "ماذا ستجد في هذا القسم؟" : "What You Will Find in This Section:" })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
											className: "space-y-1.5 text-xs",
											children: (isAr ? [
												"اختبار الشخصية الشامل (MBTI)",
												"مقياس العوامل الخمسة الكبرى (Big Five / OCEAN)",
												"نقاط القوة والتميز الفطرية",
												"نقاط التحسين والتطوير",
												"التقارير التفصيلية المعتمدة",
												"التوصيات الشخصية للحياة والعلاقات",
												"مؤشرات النمو والتقدم"
											] : [
												"Comprehensive Personality Inventory (MBTI)",
												"Big Five (OCEAN) Framework",
												"Innate Strengths & Unique Talents",
												"Growth & Development Horizons",
												"Validated Psychometric Dossiers",
												"Personalized Relational Advice",
												"Progress & Awareness Metrics"
											]).map((item, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
												className: `flex items-center gap-2 ${isLight ? "text-slate-600" : "text-slate-300"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-1.5 h-1.5 rounded-full bg-indigo-500 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item })]
											}, idx))
										})]
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScientificClinicalDisclaimerBanner, { testType: "personality" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TestScoringTrustBanner, { onNavigatePage }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
								fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "p-6 text-center text-xs font-bold opacity-75",
									children: "جارٍ تجهيز مستويات التحليل السيكومتري المتعددة..."
								}),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LazyTieredAssessmentModule, { userName: user?.displayName || void 0 })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 md:grid-cols-2 gap-6",
								children: PERSONALITY_TESTS_CATALOG.map((test) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `border rounded-3xl p-6 sm:p-8 space-y-6 flex flex-col justify-between transition-all group ${isLight ? "bg-white border-slate-200 hover:border-rose-400 shadow-lg hover:shadow-xl" : "bg-slate-900/70 border-slate-800 hover:border-rose-500/50 hover:shadow-2xl hover:shadow-rose-950/30"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-4",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: `text-xs font-bold px-3 py-1 rounded-full border ${isLight ? "text-slate-900" : "text-white"}`,
													style: {
														backgroundColor: `${test.badgeColor}20`,
														borderColor: `${test.badgeColor}60`
													},
													children: isAr ? test.badgeAr : test.badgeEn
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: `flex items-center gap-1 text-xs ${isLight ? "text-slate-600" : "text-slate-400"}`,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
														test.estimatedMinutes,
														" ",
														isAr ? "دقائق" : "mins"
													] })]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
												className: `text-xl sm:text-2xl font-bold transition-colors ${isLight ? "text-slate-900 group-hover:text-rose-600" : "text-white group-hover:text-rose-300"}`,
												children: isAr ? test.titleAr : test.titleEn
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: `text-xs font-medium mt-1 ${isLight ? "text-rose-600" : "text-rose-400/90"}`,
												children: isAr ? test.subtitleAr : test.subtitleEn
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: `text-xs sm:text-sm leading-relaxed ${isLight ? "text-slate-600" : "text-slate-300"}`,
												children: isAr ? test.shortDescriptionAr : test.shortDescriptionEn
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: `p-3 rounded-xl border text-[11px] flex items-center gap-2 ${isLight ? "bg-slate-50 border-slate-200 text-slate-700" : "bg-slate-950/70 border-slate-800 text-slate-400"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "w-4 h-4 text-amber-500 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: `block text-[10px] ${isLight ? "text-slate-500" : "text-slate-500"}`,
													children: isAr ? "المرجعية الأكاديمية (APA):" : "Academic Reference (APA):"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: `font-semibold ${isLight ? "text-slate-800" : "text-slate-300"}`,
													children: isAr ? test.scientificOriginAr : test.scientificOriginEn
												})] })]
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => handleStartTest(test),
										className: "w-full py-3 px-4 rounded-xl bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 text-white font-bold text-sm transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "ابدأ الاختبار الآن" : "Start Assessment" }), isRTL ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "w-4 h-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "w-4 h-4" })]
									})]
								}, test.id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `rounded-3xl border p-6 sm:p-8 space-y-6 ${isLight ? "bg-white border-slate-200 shadow-lg" : "bg-slate-900/75 border-purple-500/30 shadow-xl"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center justify-between gap-4 border-b pb-4 border-purple-500/20",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 text-xs font-extrabold text-purple-500",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cpu, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "منظومة اختبارات الذكاء (IQ / EQ) والتحليل العاملي المتقدم (16PF)" : "Cognitive Intelligence (IQ / EQ) & Advanced Factor-Analytic Batteries (16PF)" })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: `text-lg sm:text-2xl font-black font-['Alexandria'] ${isLight ? "text-slate-900" : "text-white"}`,
											children: isAr ? "بطاريات الذكاءات المتعددة، مصفوفات رافين، ومقاييس الشخصية الاستكشافية والتثقيفية" : "Multiple Intelligences, Raven’s Matrices & Exploratory Educational Personality Scales"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => {
												soundManager.playTap();
												setIsIntelligenceModalOpen(true);
											},
											className: "px-4 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-extrabold transition shadow-md cursor-pointer flex items-center gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "فتح مختبر الذكاء والقدرات (135 سؤالاً)" : "Open Intelligence Lab (135 Items)" })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => {
												soundManager.playTap();
												setIsPsychModalOpen(true);
											},
											className: `px-4 py-2.5 rounded-xl border text-xs font-extrabold transition cursor-pointer flex items-center gap-1.5 ${isLight ? "bg-purple-50 hover:bg-purple-100 border-purple-200 text-purple-800" : "bg-purple-500/15 hover:bg-purple-500/25 border-purple-500/35 text-purple-200"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "فتح المقاييس المتخصصة (16PF • EPQ • التعلق)" : "Open Specialized Scales (16PF • EPQ • ECR-R)" })]
										})]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-1 md:grid-cols-2 gap-4",
									children: [
										{
											id: "multiple_intelligences",
											icon: "🧠",
											titleAr: "مقياس الذكاءات التسعة المتعددة (Gardner & McKenzie - 45 بنداً)",
											titleEn: "Multiple Intelligences Inventory (Gardner & McKenzie - 45 Items)",
											descAr: "يحلل البصمة المعرفية عبر 9 ذكاءات مستقلة: اللغوي، المنطقي الرياضي، البصري المكاني، الحركي، الموسيقي، الاجتماعي، الذاتي، الطبيعي، والوجودي.",
											descEn: "Evaluates cognitive profiles across 9 distinct modalities: Linguistic, Logical-Mathematical, Spatial, Kinesthetic, Musical, Interpersonal, Intrapersonal, Naturalistic, and Existential.",
											refAr: "Gardner (1983, 1999) • Frames of Mind",
											refEn: "Gardner (1983, 1999) • Frames of Mind"
										},
										{
											id: "fluid_iq",
											icon: "🧩",
											titleAr: "بطارية الذكاء السائل والمنطقي المعياري (Raven & WAIS/CHC - 30 سؤالاً)",
											titleEn: "Fluid & Quantitative IQ Battery (Raven & WAIS/CHC - 30 Items)",
											descAr: "تتضمن مصفوفات رافين البصرية المتتابعة، سلاسل الأعداد، الاستنباط المنطقي، والقياس اللفظي لحساب الدرجة المعيارية (Standard Score) والمئين العمري.",
											descEn: "Includes Raven’s visual progressive matrices, numerical sequences, deductive syllogisms, and verbal analogies with age-normed Standard Scores.",
											refAr: "Raven (2000) & Cattell-Horn-Carroll (CHC)",
											refEn: "Raven (2000) & Cattell-Horn-Carroll (CHC)"
										},
										{
											id: "emotional_eq",
											icon: "💖",
											titleAr: "مقياس الذكاء العاطفي والاجتماعي المعتمد (MSCEIT & Bar-On - 30 موقفاً)",
											titleEn: "Emotional & Social Intelligence Battery (MSCEIT & Bar-On - 30 Scenarios)",
											descAr: "يقيس الوعي الانفعالي، إدارة الضغوط، قراءة الإشارات غير اللفظية، والتعاطف العلائقي عبر مواقف حياتية وزوجية واقعية محكّمة.",
											descEn: "Assesses emotional perception, stress regulation, non-verbal decoding, and relational empathy through validated situational judgment scenarios.",
											refAr: "Salovey & Mayer (1990); Bar-On (1997); Goleman (1995)",
											refEn: "Salovey & Mayer (1990); Bar-On (1997); Goleman (1995)"
										},
										{
											id: "cattell_16pf",
											icon: "📊",
											titleAr: "استبيان كاتل لعوامل الشخصية الـ 16 ونموذج آيزنك (16PF & EPQ-R)",
											titleEn: "Cattell 16 Personality Factors & Eysenck Temperament (16PF & EPQ-R)",
											descAr: "تحليل عاملي دقيق بـالدرجات المعيارية العشرية (Sten 1-10) لقياس 16 سمة أولية و4 أمزجة بيولوجية فطرية مع تقارير PDF فورية.",
											descEn: "Factor-analytic assessment utilizing Standard Ten (Sten 1-10) scoring across 16 primary traits and 4 neurobiological temperaments.",
											refAr: "Cattell et al. (1970) & Eysenck (1985)",
											refEn: "Cattell et al. (1970) & Eysenck (1985)"
										}
									].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										onClick: () => {
											soundManager.playTap();
											if (item.id === "cattell_16pf") setIsPsychModalOpen(true);
											else setIsIntelligenceModalOpen(true);
										},
										className: `p-5 rounded-2xl border transition cursor-pointer flex flex-col justify-between gap-3 ${isLight ? "bg-slate-50/90 hover:bg-purple-50/50 border-slate-200 hover:border-purple-300" : "bg-slate-950/65 hover:bg-slate-950 border-white/10 hover:border-purple-500/40"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-between",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-2xl",
														children: item.icon
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: `text-[11px] font-mono px-2.5 py-0.5 rounded-full border ${isLight ? "bg-purple-100 border-purple-200 text-purple-800" : "bg-purple-500/15 border-purple-500/30 text-purple-300"}`,
														children: isAr ? item.refAr : item.refEn
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
													className: `font-bold text-sm sm:text-base ${isLight ? "text-slate-900" : "text-white"}`,
													children: isAr ? item.titleAr : item.titleEn
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: `text-xs leading-relaxed ${isLight ? "text-slate-600" : "text-slate-300"}`,
													children: isAr ? item.descAr : item.descEn
												})
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between pt-2 border-t border-purple-500/15 text-xs font-bold text-purple-500",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "بدء البطارية المعيارية والتصحيح الفوري" : "Launch Standardized Battery" }), isRTL ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "w-4 h-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "w-4 h-4" })]
										})]
									}, item.id))
								})]
							})
						]
					}),
					activeTest && !isCompleted && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScientificClinicalDisclaimerBanner, {
								testType: "personality",
								testTitleAr: activeTest.titleAr,
								testTitleEn: activeTest.titleEn,
								compact: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TestScoringTrustBanner, {
								onNavigatePage,
								compact: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `border rounded-2xl p-5 space-y-4 ${isLight ? "bg-white border-slate-200 shadow-md" : "bg-slate-900/80 border-slate-800"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-rose-500 font-bold block",
										children: isAr ? activeTest.titleAr : activeTest.titleEn
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `text-xs ${isLight ? "text-slate-600" : "text-slate-400"}`,
										children: isAr ? `السؤال ${currentQuestionIndex + 1} من ${activeTest.questions.length}` : `Question ${currentQuestionIndex + 1} of ${activeTest.questions.length}`
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => setActiveTest(null),
										className: `text-xs px-3 py-1.5 rounded-lg border cursor-pointer ${isLight ? "bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-300" : "text-slate-400 hover:text-white bg-slate-800 border-slate-700"}`,
										children: isAr ? "إلغاء والعودة" : "Cancel & Exit"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `w-full h-2.5 rounded-full overflow-hidden border ${isLight ? "bg-slate-100 border-slate-200" : "bg-slate-950 border-slate-800"}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
										className: "h-full bg-gradient-to-r from-rose-500 to-pink-500",
										initial: { width: 0 },
										animate: { width: `${(currentQuestionIndex + 1) / activeTest.questions.length * 100}%` },
										transition: { duration: .3 }
									})
								})]
							}),
							activeTest.questions[currentQuestionIndex] && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
								initial: {
									opacity: 0,
									y: 15
								},
								animate: {
									opacity: 1,
									y: 0
								},
								exit: {
									opacity: 0,
									y: -15
								},
								transition: { duration: .25 },
								className: `border rounded-3xl p-6 sm:p-10 space-y-8 shadow-2xl ${isLight ? "bg-white border-slate-200" : "bg-slate-900/90 border-slate-800"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-center space-y-3 max-w-2xl mx-auto",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `inline-block px-3 py-1 rounded-full text-[11px] font-bold border ${isLight ? "bg-rose-50 text-rose-700 border-rose-200" : "bg-slate-800 text-rose-300 border-slate-700"}`,
											children: isAr ? `البند رقم #${currentQuestionIndex + 1}` : `Statement #${currentQuestionIndex + 1}`
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: `text-lg sm:text-2xl font-bold leading-relaxed ${isLight ? "text-slate-900" : "text-white"}`,
											children: isAr ? activeTest.questions[currentQuestionIndex].textAr : activeTest.questions[currentQuestionIndex].textEn
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-1 sm:grid-cols-5 gap-3 max-w-3xl mx-auto",
										children: likertOptions.map((opt) => {
											const isSelected = answers[activeTest.questions[currentQuestionIndex].id] === opt.value;
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												onClick: () => handleSelectAnswer(activeTest.questions[currentQuestionIndex].id, opt.value),
												className: `p-4 rounded-2xl border text-xs sm:text-sm font-semibold transition-all flex flex-col items-center justify-center gap-2 cursor-pointer ${isSelected ? "bg-rose-600 text-white border-rose-400 shadow-lg shadow-rose-900/50 scale-[1.03]" : isLight ? `bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100 ${opt.color}` : `bg-slate-950/80 text-slate-300 border-slate-800 hover:bg-slate-800/80 ${opt.color}`}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: `w-7 h-7 rounded-full flex items-center justify-center text-xs font-mono font-bold ${isSelected ? "bg-black/25 text-white" : isLight ? "bg-slate-200 text-slate-800" : "bg-black/30 text-slate-200"}`,
													children: opt.value
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-center",
													children: opt.label
												})]
											}, opt.value);
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `flex items-center justify-between pt-4 border-t ${isLight ? "border-slate-200" : "border-slate-800"}`,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												disabled: currentQuestionIndex === 0,
												onClick: () => {
													soundManager.playTap();
													setCurrentQuestionIndex((prev) => Math.max(0, prev - 1));
												},
												className: `px-4 py-2 rounded-xl disabled:opacity-40 text-xs font-semibold flex items-center gap-1.5 cursor-pointer ${isLight ? "bg-slate-100 hover:bg-slate-200 text-slate-700" : "bg-slate-800 hover:bg-slate-700 text-slate-300"}`,
												children: [isRTL ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "w-4 h-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "السؤال السابق" : "Previous" })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-xs text-slate-500 font-mono",
												children: [Math.round((currentQuestionIndex + 1) / activeTest.questions.length * 100), "%"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												disabled: !answers[activeTest.questions[currentQuestionIndex].id],
												onClick: () => {
													soundManager.playTap();
													if (currentQuestionIndex < activeTest.questions.length - 1) setCurrentQuestionIndex((prev) => prev + 1);
													else calculateAndSaveResults(activeTest, answers);
												},
												className: "px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 disabled:opacity-40 text-xs text-white font-semibold flex items-center gap-1.5 cursor-pointer",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: currentQuestionIndex === activeTest.questions.length - 1 ? isAr ? "إظهار النتيجة" : "View Results" : isAr ? "التالي" : "Next" }), isRTL ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "w-4 h-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "w-4 h-4" })]
											})
										]
									})
								]
							}, currentQuestionIndex)
						]
					}),
					isCompleted && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TestScoringTrustBanner, { onNavigatePage }),
							mbtiResult && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `border rounded-3xl p-6 sm:p-10 space-y-8 shadow-2xl relative overflow-hidden ${isLight ? "bg-white border-slate-200" : "bg-slate-900/90 border-slate-800"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-0 right-0 w-96 h-96 bg-rose-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b pb-6 ${isLight ? "border-slate-200" : "border-slate-800"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: `inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold border mb-2 ${isLight ? "bg-rose-50 text-rose-700 border-rose-200" : "bg-rose-500/20 text-rose-300 border-rose-500/40"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "نمطك النفسي المعتمد" : "Your Validated Archetype" })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
												className: `text-3xl sm:text-5xl font-black tracking-tight flex items-center gap-3 ${isLight ? "text-slate-900" : "text-white"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: mbtiResult.typeCode }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xl sm:text-2xl font-bold text-rose-500",
													children: isAr ? mbtiResult.archetype.titleAr : mbtiResult.archetype.titleEn
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: `text-xs mt-1 ${isLight ? "text-slate-600" : "text-slate-400"}`,
												children: isAr ? mbtiResult.archetype.roleAr : mbtiResult.archetype.roleEn
											})
										] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: `flex items-center gap-2 text-xs font-semibold px-3 py-1.5 rounded-full border ${isLight ? "bg-emerald-50 text-emerald-800 border-emerald-200" : "bg-emerald-500/10 text-emerald-300 border-emerald-500/30"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-4 h-4 text-emerald-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isSavingCloud ? isAr ? "جاري الحفظ..." : "Saving..." : isAr ? "تم الحفظ سحابياً في ملفك" : "Saved to Cloud Dossier" })]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: `text-sm font-bold ${isLight ? "text-slate-900" : "text-slate-200"}`,
											children: isAr ? "التحليل النفسي العام للنمط:" : "Archetype Overview:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: `text-sm sm:text-base leading-relaxed ${isLight ? "text-slate-700" : "text-slate-300"}`,
											children: isAr ? mbtiResult.archetype.descriptionAr : mbtiResult.archetype.descriptionEn
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-4 pt-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: `text-sm font-bold ${isLight ? "text-slate-900" : "text-slate-200"}`,
											children: isAr ? "توزيع الأبعاد القطبية الأربعة:" : "Four Cognitive Dichotomies:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: `p-4 rounded-2xl border space-y-2 ${isLight ? "bg-slate-50 border-slate-200" : "bg-slate-950/80 border-slate-800"}`,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex justify-between text-xs font-semibold",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "text-rose-500",
															children: [
																isAr ? "الانبساط (E)" : "Extraversion (E)",
																" ",
																mbtiResult.percentages.E,
																"%"
															]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "text-cyan-600",
															children: [
																isAr ? "الانطواء (I)" : "Introversion (I)",
																" ",
																mbtiResult.percentages.I,
																"%"
															]
														})]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "w-full h-2.5 bg-slate-800 rounded-full overflow-hidden flex",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "bg-rose-500 h-full",
															style: { width: `${mbtiResult.percentages.E}%` }
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "bg-cyan-500 h-full",
															style: { width: `${mbtiResult.percentages.I}%` }
														})]
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: `p-4 rounded-2xl border space-y-2 ${isLight ? "bg-slate-50 border-slate-200" : "bg-slate-950/80 border-slate-800"}`,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex justify-between text-xs font-semibold",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "text-amber-500",
															children: [
																isAr ? "الحسي (S)" : "Sensing (S)",
																" ",
																mbtiResult.percentages.S,
																"%"
															]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "text-purple-500",
															children: [
																isAr ? "الحدسي (N)" : "Intuition (N)",
																" ",
																mbtiResult.percentages.N,
																"%"
															]
														})]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "w-full h-2.5 bg-slate-800 rounded-full overflow-hidden flex",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "bg-amber-500 h-full",
															style: { width: `${mbtiResult.percentages.S}%` }
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "bg-purple-500 h-full",
															style: { width: `${mbtiResult.percentages.N}%` }
														})]
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: `p-4 rounded-2xl border space-y-2 ${isLight ? "bg-slate-50 border-slate-200" : "bg-slate-950/80 border-slate-800"}`,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex justify-between text-xs font-semibold",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "text-blue-500",
															children: [
																isAr ? "التفكير (T)" : "Thinking (T)",
																" ",
																mbtiResult.percentages.T,
																"%"
															]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "text-pink-500",
															children: [
																isAr ? "المشاعر (F)" : "Feeling (F)",
																" ",
																mbtiResult.percentages.F,
																"%"
															]
														})]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "w-full h-2.5 bg-slate-800 rounded-full overflow-hidden flex",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "bg-blue-500 h-full",
															style: { width: `${mbtiResult.percentages.T}%` }
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "bg-pink-500 h-full",
															style: { width: `${mbtiResult.percentages.F}%` }
														})]
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: `p-4 rounded-2xl border space-y-2 ${isLight ? "bg-slate-50 border-slate-200" : "bg-slate-950/80 border-slate-800"}`,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex justify-between text-xs font-semibold",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "text-emerald-500",
															children: [
																isAr ? "الحكم (J)" : "Judging (J)",
																" ",
																mbtiResult.percentages.J,
																"%"
															]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "text-orange-500",
															children: [
																isAr ? "الإدراك (P)" : "Perceiving (P)",
																" ",
																mbtiResult.percentages.P,
																"%"
															]
														})]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "w-full h-2.5 bg-slate-800 rounded-full overflow-hidden flex",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "bg-emerald-500 h-full",
															style: { width: `${mbtiResult.percentages.J}%` }
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "bg-orange-500 h-full",
															style: { width: `${mbtiResult.percentages.P}%` }
														})]
													})]
												})
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: `text-sm font-bold ${isLight ? "text-slate-900" : "text-slate-200"}`,
											children: isAr ? "أبرز نقاط القوة السلوكية:" : "Core Strengths:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex flex-wrap gap-2",
											children: (isAr ? mbtiResult.archetype.strengthsAr : mbtiResult.archetype.strengthsEn).map((str, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: `px-3 py-1.5 rounded-xl border text-xs font-semibold ${isLight ? "bg-rose-50 border-rose-200 text-rose-700" : "bg-slate-950 border-slate-800 text-rose-300"}`,
												children: ["✓ ", str]
											}, idx))
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `p-5 rounded-2xl border space-y-1.5 ${isLight ? "bg-rose-50/80 border-rose-200 text-slate-800" : "bg-rose-500/10 border-rose-500/30 text-slate-200"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 text-rose-500 text-xs font-bold",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "أسلوبك في التوافق والعلاقات الإنسانية:" : "Relational & Compatibility Style:" })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs sm:text-sm leading-relaxed",
											children: isAr ? mbtiResult.archetype.relationalStyleAr : mbtiResult.archetype.relationalStyleEn
										})]
									})
								]
							}),
							bigFiveResult && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `border rounded-3xl p-6 sm:p-10 space-y-8 shadow-2xl ${isLight ? "bg-white border-slate-200" : "bg-slate-900/90 border-slate-800"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b pb-6 ${isLight ? "border-slate-200" : "border-slate-800"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold border mb-2 ${isLight ? "bg-purple-50 text-purple-700 border-purple-200" : "bg-purple-500/20 text-purple-300 border-purple-500/40"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "التقرير السيكومتري الخماسي" : "Big Five Psychometric Profile" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: `text-2xl sm:text-4xl font-black tracking-tight ${isLight ? "text-slate-900" : "text-white"}`,
										children: isAr ? "مصفوفة العوامل الخمسة الكبرى (OCEAN)" : "OCEAN Dimension Matrix"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `flex items-center gap-2 text-xs font-semibold px-3 py-1.5 rounded-full border ${isLight ? "bg-emerald-50 text-emerald-800 border-emerald-200" : "bg-emerald-500/10 text-emerald-300 border-emerald-500/30"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-4 h-4 text-emerald-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "تم الحفظ سحابياً في ملفك" : "Saved to Cloud Dossier" })]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-5",
									children: [
										{
											key: "O",
											titleAr: "1. الانفتاح على الخبرة (Openness)",
											titleEn: "1. Openness to Experience",
											descAr: "يعكس الفضول المعرفي، التذوق الجمالي، والاهتمام بالأفكار غير التقليدية والابتكار.",
											descEn: "Reflects intellectual curiosity, appreciation for art, and interest in novel experiences.",
											score: bigFiveResult.scores.O,
											barClass: "bg-purple-500",
											textClass: "text-purple-500"
										},
										{
											key: "C",
											titleAr: "2. يقظة الضمير والانضباط (Conscientiousness)",
											titleEn: "2. Conscientiousness",
											descAr: "يعكس قوة الإرادة، التنظيم الذاتي، الالتزام بالواجبات، ودقة المواعيد والمسؤولية.",
											descEn: "Reflects self-discipline, organization, goal-oriented persistence, and reliability.",
											score: bigFiveResult.scores.C,
											barClass: "bg-emerald-500",
											textClass: "text-emerald-500"
										},
										{
											key: "E",
											titleAr: "3. الانبساطية والاجتماعية (Extraversion)",
											titleEn: "3. Extraversion",
											descAr: "يعكس الحيوية الاجتماعية، الرغبة في التفاعل، الحزم في التعبير، والميل للبهجة.",
											descEn: "Reflects social vitality, enthusiasm, assertiveness, and desire for active interaction.",
											score: bigFiveResult.scores.E,
											barClass: "bg-rose-500",
											textClass: "text-rose-500"
										},
										{
											key: "A",
											titleAr: "4. الوفاق والتعاون (Agreeableness)",
											titleEn: "4. Agreeableness",
											descAr: "يعكس التعاطف الإنساني، التسامح، كرم المشاعر، والحرص على الانسجام وتجنب الصدامات.",
											descEn: "Reflects interpersonal compassion, altruism, cooperativeness, and desire for harmony.",
											score: bigFiveResult.scores.A,
											barClass: "bg-cyan-500",
											textClass: "text-cyan-500"
										},
										{
											key: "ES",
											titleAr: "5. الاتزان الانفعالي والصلابة (Emotional Stability)",
											titleEn: "5. Emotional Stability",
											descAr: "يعكس القدرة على امتصاص الضغوط والأزمات، الهدوء الذهني، والتعافي من الإحباطات.",
											descEn: "Reflects composure under stress, emotional resilience, and calm cognitive balance.",
											score: bigFiveResult.scores.ES,
											barClass: "bg-blue-500",
											textClass: "text-blue-500"
										}
									].map((trait) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `p-5 rounded-2xl border space-y-2 ${isLight ? "bg-slate-50 border-slate-200" : "bg-slate-950/80 border-slate-800"}`,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex justify-between items-center text-sm font-bold",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: trait.textClass,
													children: isAr ? trait.titleAr : trait.titleEn
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: `font-mono ${trait.textClass}`,
													children: [trait.score, "%"]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: `text-xs ${isLight ? "text-slate-600" : "text-slate-400"}`,
												children: isAr ? trait.descAr : trait.descEn
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: `w-full h-2.5 rounded-full overflow-hidden ${isLight ? "bg-slate-200" : "bg-slate-900"}`,
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: `${trait.barClass} h-full rounded-full`,
													style: { width: `${trait.score}%` }
												})
											})
										]
									}, trait.key))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `rounded-3xl border p-6 sm:p-8 space-y-3 shadow-xl ${isLight ? "bg-amber-50 border-amber-200 text-amber-950" : "bg-gradient-to-r from-amber-950/40 via-slate-900 to-amber-950/40 border-amber-500/40 text-slate-200"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2.5 text-amber-500 font-bold text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "w-5 h-5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "إخلاء مسؤولية علمي واستشاري إلزامي:" : "Mandatory Scientific & Educational Disclaimer:" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs leading-relaxed",
									children: isAr ? "هذا التقرير السيكومتري مُعد حصراً لأغراض التثقيف الذاتي، وتعميق الوعي الشخصي، والتأمل المعرفي. هذه النتائج لا تمثل تشخيصاً نفسياً أو عيادياً أو طبياً، ولا تعد بديلاً عن جلسات الإرشاد النفسي أو الأسري المرخصة. الشخصية الإنسانية كائن ديناميكي مرن يتطور بالخبرة والنضج ولا يمكن اختزاله في قالب جامد أو نسبة قطعية." : "This psychometric report is provided solely for educational self-reflection, mindfulness, and personal growth. It does not constitute a clinical psychological, psychiatric, or medical diagnosis, nor is it a substitute for certified counseling. Human personality is dynamic and continually evolves with experience beyond singular rigid labels."
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-3 pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => {
										soundManager.playTap();
										setActiveTest(null);
										setIsCompleted(false);
									},
									className: `px-5 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer ${isLight ? "bg-slate-200 hover:bg-slate-300 text-slate-800" : "bg-slate-800 hover:bg-slate-700 text-slate-200"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "w-4 h-4 text-rose-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "استكشاف مقياس آخر" : "Explore Another Test" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: handleShareResult,
									className: "px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-2 shadow-lg cursor-pointer",
									children: [copiedShare ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4 text-emerald-300" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: copiedShare ? isAr ? "تم نسخ الرابط" : "Link Copied" : isAr ? "مشاركة النتيجة" : "Share Result" })]
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PsychometricAcademicConclusion, { variant: "page" })
				]
			}),
			isIntelligenceModalOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
				fallback: null,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LazyIntelligenceTestModal, {
					isOpen: isIntelligenceModalOpen,
					onClose: () => setIsIntelligenceModalOpen(false)
				})
			}),
			isPsychModalOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PsychologyTestsModal, {
				isOpen: isPsychModalOpen,
				onClose: () => setIsPsychModalOpen(false)
			})
		]
	});
};
//#endregion
export { PersonalityTestsPage };
