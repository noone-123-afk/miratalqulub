import "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { Wt as FileText, d as UserCheck, h as Trash2, l as User, mn as CircleCheck, p as TriangleAlert, yt as LogIn } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
require_react();
var import_jsx_runtime = require_jsx_runtime();
var NavbarUserMenu = ({ isAr, isLight, user, confirmDeleteStep, isDeletingData, deleteSuccessToast, onSetConfirmDeleteStep, onPermanentDeleteData, onNavAction, onOpenUserDashboard, onOpenHistory, onOpenAuth }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `absolute top-full mt-2 w-80 rounded-2xl border p-3 shadow-2xl z-50 space-y-2 ${isAr ? "left-0 text-right" : "right-0 text-left"} ${isLight ? "bg-white border-slate-200 text-slate-800" : "bg-slate-950/95 border-violet-500/40 text-slate-100 backdrop-blur-xl"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `pb-2 border-b flex items-center justify-between ${isLight ? "border-slate-100" : "border-white/10"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `text-xs font-extrabold ${isLight ? "text-violet-800" : "text-violet-300"}`,
					children: isAr ? "مركز التحكم الشخصي والخصوصية" : "Personal Profile & Data Control"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `text-[10px] font-mono font-bold px-2 py-0.5 rounded ${isLight ? "bg-emerald-50 text-emerald-800" : "bg-emerald-500/20 text-emerald-200"}`,
					children: "TLS 1.3"
				})]
			}),
			onOpenUserDashboard && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => onNavAction(onOpenUserDashboard),
				className: `w-full p-2.5 rounded-xl transition flex items-center gap-2.5 text-xs font-bold cursor-pointer ${isLight ? "hover:bg-violet-50 text-slate-800" : "hover:bg-white/10 text-white"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "w-4 h-4 text-violet-500 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: isAr ? "لوحة ملفي السيكومتري الشامل" : "My Psychometric Dashboard" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `text-[10px] font-normal ${isLight ? "text-slate-700" : "text-slate-300"}`,
					children: isAr ? "استعراض بصمتك المعرفية وتقاريرك وتفضيلاتك" : "View your cognitive fingerprint, reports & preferences"
				})] })]
			}),
			onOpenHistory && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => onNavAction(onOpenHistory),
				className: `w-full p-2.5 rounded-xl transition flex items-center gap-2.5 text-xs font-bold cursor-pointer ${isLight ? "hover:bg-emerald-50 text-slate-800" : "hover:bg-white/10 text-white"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-4 h-4 text-emerald-500 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: isAr ? "سجل نتائجي المحفوظة وتصدير PDF" : "Saved Results History & PDF Export" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `text-[10px] font-normal ${isLight ? "text-slate-700" : "text-slate-300"}`,
					children: isAr ? "جميع اختبارات الشخصية والذكاء والتوافق السابقة" : "Access all past personality, IQ & compatibility records"
				})] })]
			}),
			onOpenAuth && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => onNavAction(onOpenAuth),
				className: `w-full p-2.5 rounded-xl transition flex items-center gap-2.5 text-xs font-bold cursor-pointer ${isLight ? "hover:bg-sky-50 text-slate-800" : "hover:bg-white/10 text-white"}`,
				children: [user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "w-4 h-4 text-sky-500 shrink-0" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogIn, { className: "w-4 h-4 text-sky-500 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: user ? isAr ? `حسابي المتصل (${user.displayName || user.email?.split("@")[0]})` : `Connected Account (${user.displayName || user.email?.split("@")[0]})` : isAr ? "تسجيل الدخول / مزامنة الحساب السحابي" : "Sign In / Cloud Account Sync" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `text-[10px] font-normal ${isLight ? "text-slate-700" : "text-slate-300"}`,
					children: isAr ? "لحفظ سجلاتك عبر أجهزتك المختلفة بأمان" : "Securely synchronize your records across devices"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `pt-2 border-t ${isLight ? "border-slate-200" : "border-white/10"}`,
				children: deleteSuccessToast ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `p-3 rounded-xl border text-xs font-bold flex items-center gap-2 ${isLight ? "bg-emerald-50 border-emerald-300 text-emerald-900" : "bg-emerald-500/20 border-emerald-500/40 text-emerald-200"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-4 h-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "تم حذف جميع بياناتك وسجلاتك نهائياً بنجاح." : "All your personal data and records have been permanently deleted." })]
				}) : !confirmDeleteStep ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						soundManager.playTap();
						onSetConfirmDeleteStep(true);
					},
					className: `w-full p-2.5 rounded-xl border transition flex items-center justify-between text-xs font-bold cursor-pointer ${isLight ? "bg-rose-50 hover:bg-rose-100 border-rose-300 text-rose-800" : "bg-rose-500/15 hover:bg-rose-500/25 border-rose-500/40 text-rose-200"}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "w-4 h-4 text-rose-500 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "حذف بياناتي وسجلاتي نهائياً" : "Delete My Data Permanently" })]
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `p-3 rounded-xl border space-y-2.5 ${isLight ? "bg-rose-50 border-rose-300 text-rose-950" : "bg-rose-950/60 border-rose-500/50 text-rose-100"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-2 text-[11px] leading-relaxed",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "w-4 h-4 text-rose-500 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "هل أنت متأكد؟ سيتم مسح جميع نتائجك المحفوظة وملفك الشخصي من المتصفح والسحابة نهائياً ولا يمكن التراجع." : "Are you sure? All saved test results and profile data will be permanently erased from local storage and cloud." })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: isDeletingData,
							onClick: onPermanentDeleteData,
							className: "flex-1 py-1.5 px-3 rounded-lg bg-rose-700 hover:bg-rose-600 disabled:bg-rose-800 disabled:opacity-80 text-white text-xs font-extrabold transition cursor-pointer",
							children: isDeletingData ? isAr ? "جاري الحذف..." : "Deleting..." : isAr ? "نعم، احذف نهائياً" : "Yes, Delete Forever"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onSetConfirmDeleteStep(false),
							className: `py-1.5 px-3 rounded-lg text-xs font-bold transition cursor-pointer ${isLight ? "bg-white border border-slate-300 text-slate-800" : "bg-slate-800 text-slate-200"}`,
							children: isAr ? "إلغاء" : "Cancel"
						})]
					})]
				})
			})
		]
	});
};
//#endregion
export { NavbarUserMenu };
