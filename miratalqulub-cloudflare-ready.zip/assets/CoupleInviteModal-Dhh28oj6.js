const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/ScientificVisualDashboards-BXG0MudB.js","assets/rolldown-runtime-Bk_YeHJf.js","assets/vendor-react-Bm_EF59R.js","assets/index-C5uCeetQ.js","assets/vendor-icons-WoMClU7U.js","assets/sound-C_zXqyNA.js","assets/react-redux-CuCZtN7g.js","assets/firebase-Cu7XUsbK.js","assets/firebaseAuth-D6LKvzXg.js","assets/index-DMmCvB5f.css","assets/pdfReportGenerator-BNu3pVmt.js","assets/index.es-C20Q95Ms.js"])))=>i.map(i=>d[i]);
import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { n as __vitePreload, o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { B as Send, D as Sparkles, En as Brain, Gt as FileDown, K as RotateCcw, Q as QrCode, U as Scale, bn as Check, ft as MessageCircle, j as SlidersVertical, kn as BookmarkCheck, mn as CircleCheck, r as X, rn as Copy, s as Users } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import { u as useAuth } from "./index-C5uCeetQ.js";
import { n as AnimatePresence, t as motion } from "./vendor-motion-BS7ODJw7.js";
import { a as loadUserPersonalQuestionnaire, t as COMMUNITY_PROFILES, u as QUIZ_QUESTIONS } from "./data-compatibility-s3wwWF9Q.js";
import { calculateDyadicCoupleCompatibility } from "./realScoringEngine-B-6Eyb1e.js";
import { c as profileFromQuestionnaireOrCommunity, s as compareTwoPsychometricProfiles, u as profileFromUnifiedRecord } from "./engine-comparison-CmI_l5ta.js";
import { a as fetchUnifiedTestHistory, u as saveUnifiedTestRecord } from "./userHistoryService-6N9Zh8ed.js";
//#region src/components/CoupleInviteModal.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var LazyScientificVisualDashboards = (0, import_react.lazy)(() => __vitePreload(() => import("./ScientificVisualDashboards-BXG0MudB.js").then((m) => ({ default: m.ScientificVisualDashboards })), __vite__mapDeps([0,1,2,3,4,5,6,7,8,9])));
var DYADIC_CORE_QUESTION_IDS = [
	1,
	2,
	3,
	4,
	6,
	7,
	8,
	10,
	12,
	15,
	16,
	20
];
var CoupleInviteModal = ({ isOpen, onClose, profile, result }) => {
	const { user } = useAuth();
	const [activeMode, setActiveMode] = (0, import_react.useState)("two_person_compare");
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [showQr, setShowQr] = (0, import_react.useState)(false);
	const [savedRecords, setSavedRecords] = (0, import_react.useState)([]);
	const [sourceAKey, setSourceAKey] = (0, import_react.useState)("questionnaire");
	const [sourceBKey, setSourceBKey] = (0, import_react.useState)("community:0");
	const [comparisonReport, setComparisonReport] = (0, import_react.useState)(null);
	const [comparisonSaved, setComparisonSaved] = (0, import_react.useState)(false);
	const [partnerAName, setPartnerAName] = (0, import_react.useState)(profile?.userName || "الطرف الأول");
	const [partnerBName, setPartnerBName] = (0, import_react.useState)(result?.proposedPartnerName || "الطرف الثاني");
	const [activePartnerTurn, setActivePartnerTurn] = (0, import_react.useState)("A");
	const [questionIdx, setQuestionIdx] = (0, import_react.useState)(0);
	const [partnerAAnswers, setPartnerAAnswers] = (0, import_react.useState)({});
	const [partnerBAnswers, setPartnerBAnswers] = (0, import_react.useState)({});
	const [dyadicReport, setDyadicReport] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!isOpen) return;
		let active = true;
		fetchUnifiedTestHistory(user).then((list) => {
			if (!active) return;
			const comparable = list.filter((r) => r.testType === "tiered_assessment" || r.testType === "psychology" || r.testType === "partner_compatibility");
			setSavedRecords(comparable);
			if (comparable.length > 0) setSourceAKey(`record:${comparable[0].id}`);
		}).catch(() => {});
		return () => {
			active = false;
		};
	}, [isOpen, user]);
	if (!isOpen) return null;
	const userName = profile?.userName || user?.displayName || "شريكك";
	const userGender = profile?.userGender || "male";
	const country = profile?.country || "المملكة العربية السعودية";
	const resolveSelectedProfile = (key, fallbackLabel) => {
		if (key.startsWith("record:")) {
			const recId = key.replace("record:", "");
			const found = savedRecords.find((r) => r.id === recId);
			if (found) return profileFromUnifiedRecord(found);
		}
		if (key.startsWith("community:")) {
			const idx = Number(key.replace("community:", "")) || 0;
			const member = COMMUNITY_PROFILES[idx] || COMMUNITY_PROFILES[0];
			return profileFromQuestionnaireOrCommunity(member, member.displayName);
		}
		if (key === "preset_divergent") return {
			personName: "نمط تحليلي متباين (عينة تباين)",
			personLabelAr: "نمط متباين",
			sourceType: "live_assessment",
			bigFive: {
				openness: 32,
				conscientiousness: 38,
				extraversion: 28,
				agreeableness: 35,
				emotionalStability: 30
			},
			hexaco: {
				honestyHumility: 40,
				emotionality: 78,
				extraversion: 30,
				agreeableness: 34,
				conscientiousness: 38,
				openness: 32
			},
			attachment: {
				anxiety: 76,
				avoidance: 72,
				styleAr: "ارتباط حذر متوتر"
			},
			emotionalIntelligence: 34,
			communicationStyle: {
				assertive: 30,
				reflective: 32,
				analytical: 74,
				expressive: 28,
				primaryAr: "التحفظ الصامت"
			},
			conflictResolution: {
				collaborating: 32,
				compromising: 35,
				accommodating: 30,
				competing: 78,
				avoiding: 74,
				primaryAr: "الانسحاب أو الحسم"
			},
			valuesScore: 42,
			lifeGoals: {
				familyStability: 36,
				careerGrowth: 84,
				intellectualDepth: 40,
				socialHarmony: 32,
				financialSecurity: 45
			},
			parentingOrientation: 38
		};
		const qData = loadUserPersonalQuestionnaire();
		return profileFromQuestionnaireOrCommunity(qData, profile?.userName || fallbackLabel);
	};
	const handleRunTwoPersonComparison = () => {
		soundManager.playResultReveal();
		setComparisonSaved(false);
		const profA = resolveSelectedProfile(sourceAKey, profile?.userName || "الشخص الأول");
		const profB = resolveSelectedProfile(sourceBKey, "الشخص الثاني");
		const computed = compareTwoPsychometricProfiles(profA, profB);
		setComparisonReport(computed);
	};
	const handleSaveComparisonRecord = async () => {
		if (!comparisonReport) return;
		soundManager.playTap();
		await saveUnifiedTestRecord(user || null, {
			testType: "personality_comparison",
			testTitleAr: `مقارنة: ${comparisonReport.personA.personName} ✕ ${comparisonReport.personB.personName}`,
			testCategoryAr: "مقارنة شخصيتين علمياً",
			scoreOrArchetype: `${comparisonReport.overallWeightedCompatibility}% • ${comparisonReport.compatibilityClassificationAr}`,
			percentage: comparisonReport.overallWeightedCompatibility,
			badgeColor: "#059669",
			keyInsights: comparisonReport.subIndices.map((s) => `${s.titleAr}: ${s.score}%`),
			snapshot: comparisonReport,
			standardizedScores: Object.fromEntries(comparisonReport.subIndices.map((s) => [s.key, s.score]))
		});
		setComparisonSaved(true);
	};
	const handleExportComparisonPdf = async () => {
		if (!comparisonReport) return;
		soundManager.playTap();
		const { exportPsychometricReportAsPDF } = await __vitePreload(async () => {
			const { exportPsychometricReportAsPDF } = await import("./pdfReportGenerator-BNu3pVmt.js");
			return { exportPsychometricReportAsPDF };
		}, __vite__mapDeps([10,3,1,2,4,5,11,7,8,9]));
		exportPsychometricReportAsPDF({
			reportTitle: "تقرير مقارنة شخصيتين عبر المحاور التسعة السيكومترية",
			subTitle: `${comparisonReport.personA.personName} ✕ ${comparisonReport.personB.personName} • ${comparisonReport.compatibilityClassificationAr}`,
			scientificBasis: comparisonReport.scientificReferences.join(" • "),
			userName: comparisonReport.personA.personName,
			completedAt: new Date(comparisonReport.createdAt).toLocaleDateString("ar-JO"),
			overallScoreLabel: "التوافق الإجمالي الموزون",
			overallScoreValue: `${comparisonReport.overallWeightedCompatibility}%`,
			cognitiveFingerprintTitle: "تحليل 6 مؤشرات توافقية + 9 محاور سيكومترية",
			executiveSummary: comparisonReport.executiveSummaryAr,
			metrics: comparisonReport.subIndices.map((sub) => ({
				label: sub.titleAr,
				scorePercent: sub.score,
				levelLabel: `وزن ${(sub.weight * 100).toFixed(0)}%`,
				rawText: sub.interpretationAr,
				color: "#059669"
			})),
			sections: comparisonReport.nineAxesBreakdown.map((ax) => ({
				title: ax.axisNameAr,
				badge: `توافق ${ax.matchScore}% (فارق ${ax.delta}%)`,
				content: ax.scientificNoteAr,
				items: [`${comparisonReport.personA.personName}: ${ax.personAScore}%`, `${comparisonReport.personB.personName}: ${ax.personBScore}%`]
			})),
			careersOrRecommendations: [...comparisonReport.sharedStrengthsAr, ...comparisonReport.growthRecommendationsAr],
			comparisonDualRadar: {
				personAName: comparisonReport.personA.personName,
				personBName: comparisonReport.personB.personName,
				axes: comparisonReport.nineAxesBreakdown
			}
		});
	};
	const dyadicQuestions = QUIZ_QUESTIONS.filter((q) => DYADIC_CORE_QUESTION_IDS.includes(q.id));
	const currentQ = dyadicQuestions[questionIdx] || dyadicQuestions[0];
	const sessionId = `cp_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
	const inviteLink = `${typeof window !== "undefined" ? window.location.origin : "https://miratalqulub.com"}/?${new URLSearchParams({
		coupleInvite: sessionId,
		inviter: userName,
		inviterGender: userGender,
		inviterCountry: country,
		inviterScore: String(result?.compatibilityScore || 92)
	}).toString()}`;
	const shareText = `أرسل لك ${userName} دعوة لإجراء تقييم التوافق الزواجي العلمي المزدوج على منصة «مِرآة القلوب»:\n${inviteLink}`;
	const handleCopy = () => {
		soundManager.playTap();
		navigator.clipboard.writeText(inviteLink);
		setCopied(true);
		setTimeout(() => setCopied(false), 3e3);
	};
	const handleSelectDyadicOption = (optionId) => {
		soundManager.playTap();
		if (activePartnerTurn === "A") {
			const nextA = {
				...partnerAAnswers,
				[currentQ.id]: optionId
			};
			setPartnerAAnswers(nextA);
			if (questionIdx + 1 < dyadicQuestions.length) setQuestionIdx(questionIdx + 1);
			else {
				setActivePartnerTurn("B");
				setQuestionIdx(0);
			}
		} else {
			const nextB = {
				...partnerBAnswers,
				[currentQ.id]: optionId
			};
			setPartnerBAnswers(nextB);
			if (questionIdx + 1 < dyadicQuestions.length) setQuestionIdx(questionIdx + 1);
			else {
				soundManager.playResultReveal();
				const computed = calculateDyadicCoupleCompatibility({
					userName: partnerAName,
					country
				}, partnerAAnswers, {
					userName: partnerBName,
					country
				}, nextB);
				setDyadicReport(computed);
			}
		}
	};
	const handleResetDyadic = () => {
		soundManager.playTap();
		setPartnerAAnswers({});
		setPartnerBAnswers({});
		setActivePartnerTurn("A");
		setQuestionIdx(0);
		setDyadicReport(null);
	};
	const handleExportDyadicPdf = async () => {
		if (!dyadicReport) return;
		soundManager.playTap();
		const { exportPsychometricReportAsPDF } = await __vitePreload(async () => {
			const { exportPsychometricReportAsPDF } = await import("./pdfReportGenerator-BNu3pVmt.js");
			return { exportPsychometricReportAsPDF };
		}, __vite__mapDeps([10,3,1,2,4,5,11,7,8,9]));
		exportPsychometricReportAsPDF({
			reportTitle: `تقرير التوافق العلمي المزدوج بين الشريكين (Dyadic Assessment)`,
			subTitle: `${dyadicReport.partnerAName} ✕ ${dyadicReport.partnerBName} • ${dyadicReport.stabilityClassificationAr}`,
			scientificBasis: "Kenny Dyadic Data Analysis (2006), Gottman Method (1999), Bowlby Attachment (ECR-R), Sternberg (1986), Bowen Family Systems, Klontz Financial Psychology",
			completedAt: (/* @__PURE__ */ new Date()).toLocaleDateString("ar-JO"),
			overallScoreLabel: "معامل التناغم الثنائي الموزون",
			overallScoreValue: `${dyadicReport.overallHarmonyScore}%`,
			cognitiveFingerprintTitle: `مؤشر التشابه القيمي (${dyadicReport.similarityIndex}%) • مؤشر التكامل الوظيفي (${dyadicReport.complementarityIndex}%)`,
			executiveSummary: dyadicReport.scientificRecommendationAr,
			metrics: dyadicReport.dimensions.map((d) => ({
				label: d.titleAr,
				scorePercent: d.harmonyPercentage,
				rawText: `${dyadicReport.partnerAName}: ${d.partnerAScore}% | ${dyadicReport.partnerBName}: ${d.partnerBScore}%`,
				levelLabel: d.synergyTypeAr,
				color: "#059669"
			})),
			sections: dyadicReport.dimensions.map((d) => ({
				title: `${d.titleAr} (${d.scientistAr})`,
				badge: `تناغم ${d.harmonyPercentage}% • ${d.synergyTypeAr}`,
				content: d.scientificInsightAr,
				items: [`درجة ${dyadicReport.partnerAName}: ${d.partnerAScore}%`, `درجة ${dyadicReport.partnerBName}: ${d.partnerBScore}%`]
			})),
			careersOrRecommendations: [...dyadicReport.strengthsAr, ...dyadicReport.growthAreasAr]
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto",
		dir: "rtl",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: {
				opacity: 0,
				scale: .95,
				y: 15
			},
			animate: {
				opacity: 1,
				scale: 1,
				y: 0
			},
			exit: {
				opacity: 0,
				scale: .95,
				y: 15
			},
			className: "glass-panel w-full max-w-2xl rounded-3xl p-5 sm:p-6 border border-white/20 shadow-2xl relative my-auto text-right max-h-[92vh] overflow-y-auto",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => {
						soundManager.playTap();
						onClose();
					},
					className: "absolute top-4 left-4 p-2 rounded-full bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white transition cursor-pointer",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-5 h-5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 mb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 via-teal-500 to-cyan-600 p-0.5 shadow-lg shadow-emerald-500/20 flex items-center justify-center shrink-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-full h-full bg-[#120d24] rounded-[14px] flex items-center justify-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scale, { className: "w-6 h-6 text-emerald-400" })
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 flex-wrap",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-extrabold text-base sm:text-lg text-white font-['Alexandria']",
							children: "مختبر التقييم العلمي المزدوج للتوافق بين الشريكين"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30",
							children: "Dyadic Psychometrics 🔬"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-gray-300 mt-0.5",
						children: "قياس التوافق الفعلي بين طرفين استناداً إلى 6 نماذج علمية محكمة (غوتمان، بولبي، ستيرنبرغ، بوين، شوارتز، كلونتز)"
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 sm:grid-cols-3 gap-2 p-1 rounded-2xl bg-black/40 border border-white/10 mb-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								soundManager.playTap();
								setActiveMode("two_person_compare");
							},
							className: `py-2 px-3 rounded-xl text-xs font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${activeMode === "two_person_compare" ? "bg-purple-600 text-white shadow-md" : "text-gray-400 hover:text-white"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersVertical, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "مقارنة شخصيتين (9 محاور)" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								soundManager.playTap();
								setActiveMode("dyadic_lab");
							},
							className: `py-2 px-3 rounded-xl text-xs font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${activeMode === "dyadic_lab" ? "bg-emerald-600 text-white shadow-md" : "text-gray-400 hover:text-white"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تقييم ثنائي مباشر" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								soundManager.playTap();
								setActiveMode("invite_link");
							},
							className: `py-2 px-3 rounded-xl text-xs font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${activeMode === "invite_link" ? "bg-rose-600 text-white shadow-md" : "text-gray-400 hover:text-white"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "رابط دعوة عن بُعد" })]
						})
					]
				}),
				activeMode === "two_person_compare" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-3 p-4 rounded-2xl bg-slate-900/90 border border-slate-700/80",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-[11px] font-bold text-purple-300 mb-1.5",
								children: "مصدر بيانات الشخص الأول (Person A):"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								"aria-label": "مصدر بيانات الشخص الأول",
								value: sourceAKey,
								onChange: (e) => setSourceAKey(e.target.value),
								className: "w-full px-3 py-2 rounded-xl bg-black/50 border border-white/15 text-xs text-white focus:outline-none focus:border-purple-400",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "questionnaire",
										children: "ملفي الشخصي الحالي (الاستبيان)"
									}),
									savedRecords.map((rec) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: `record:${rec.id}`,
										children: [
											"تقرير محفوظ: ",
											rec.testTitleAr.slice(0, 34),
											" (",
											rec.percentage,
											"%)"
										]
									}, `a_${rec.id}`)),
									COMMUNITY_PROFILES.slice(0, 6).map((cm, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: `community:${idx}`,
										children: [
											"ملف: ",
											cm.displayName,
											" — ",
											cm.country
										]
									}, `ca_${cm.id}`))
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-[11px] font-bold text-emerald-300 mb-1.5",
								children: "مصدر بيانات الشخص الثاني (Person B):"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								"aria-label": "مصدر بيانات الشخص الثاني",
								value: sourceBKey,
								onChange: (e) => setSourceBKey(e.target.value),
								className: "w-full px-3 py-2 rounded-xl bg-black/50 border border-white/15 text-xs text-white focus:outline-none focus:border-emerald-400",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "questionnaire",
										children: "ملفي الشخصي الحالي (مقارنة التطابق)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "preset_divergent",
										children: "ملف متباين عالي القلق والتنافس (لاختبار الفروق)"
									}),
									savedRecords.map((rec) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: `record:${rec.id}`,
										children: [
											"تقرير محفوظ: ",
											rec.testTitleAr.slice(0, 34),
											" (",
											rec.percentage,
											"%)"
										]
									}, `b_${rec.id}`)),
									COMMUNITY_PROFILES.slice(0, 8).map((cm, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: `community:${idx}`,
										children: [
											"ملف: ",
											cm.displayName,
											" — ",
											cm.country
										]
									}, `cb_${cm.id}`))
								]
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: handleRunTwoPersonComparison,
							className: "w-full py-3 px-5 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-emerald-600 hover:opacity-95 text-white text-xs sm:text-sm font-extrabold transition cursor-pointer shadow-lg flex items-center justify-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scale, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تشغيل محرك المقارنة السيكومترية عبر المحاور التسعة" })]
						}),
						comparisonReport && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-gradient-to-l from-purple-950/60 to-emerald-950/40 border border-purple-500/35 flex flex-col sm:flex-row items-center justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-[11px] text-purple-300 font-bold",
												children: [
													comparisonReport.personA.personName,
													" ✕ ",
													comparisonReport.personB.personName
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
												className: "text-base font-black text-white font-['Alexandria']",
												children: comparisonReport.compatibilityClassificationAr
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-slate-300 leading-relaxed",
												children: comparisonReport.executiveSummaryAr
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3.5 rounded-2xl bg-black/50 border border-emerald-400/40 text-center shrink-0 min-w-[120px]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[10px] text-slate-300",
											children: "التوافق العام"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-3xl font-black text-emerald-400 tabular-nums",
											children: [comparisonReport.overallWeightedCompatibility, "%"]
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-2.5",
									children: comparisonReport.subIndices.map((sub) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-1.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between gap-2 text-xs",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-extrabold text-white",
													children: sub.titleAr
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "font-black text-emerald-400 tabular-nums",
													children: [sub.score, "%"]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "w-full h-1.5 rounded-full bg-black/50 overflow-hidden",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "h-full rounded-full bg-gradient-to-r from-purple-500 to-emerald-500",
													style: { width: `${sub.score}%` }
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] text-slate-300 leading-relaxed",
												children: sub.interpretationAr
											})
										]
									}, sub.key))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3.5 rounded-2xl bg-slate-900/80 border border-white/10 space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs font-extrabold text-white",
										children: "تفصيل المحاور التسعة:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "space-y-1.5 max-h-60 overflow-y-auto",
										children: comparisonReport.nineAxesBreakdown.map((ax) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-2.5 rounded-xl bg-black/35 border border-white/5 text-[11px] space-y-1",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-between gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "font-bold text-white",
														children: ax.axisNameAr
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "font-black text-cyan-300 tabular-nums",
														children: [
															"تطابق ",
															ax.matchScore,
															"% (Δ ",
															ax.delta,
															"%)"
														]
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-4 text-slate-400 tabular-nums",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
														"أ: ",
														ax.personAScore,
														"%"
													] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
														"ب: ",
														ax.personBScore,
														"%"
													] })]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-slate-300",
													children: ax.scientificNoteAr
												})
											]
										}, ax.axisKey))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
									fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "p-4 text-center text-xs text-slate-400",
										children: "جارٍ رسم مخطط المقارنة السيكومترية..."
									}),
									children: (() => {
										const emptyCharts = {
											overallRadar: comparisonReport.nineAxesBreakdown.slice(0, 8).map((r) => ({
												subject: r.axisNameAr.split("(")[0].trim(),
												score: r.matchScore,
												fullMark: 100
											})),
											bigFiveRadar: [
												{
													trait: "O",
													score: comparisonReport.personA.bigFive.openness,
													benchmark: comparisonReport.personB.bigFive.openness,
													fullMark: 100
												},
												{
													trait: "C",
													score: comparisonReport.personA.bigFive.conscientiousness,
													benchmark: comparisonReport.personB.bigFive.conscientiousness,
													fullMark: 100
												},
												{
													trait: "E",
													score: comparisonReport.personA.bigFive.extraversion,
													benchmark: comparisonReport.personB.bigFive.extraversion,
													fullMark: 100
												},
												{
													trait: "A",
													score: comparisonReport.personA.bigFive.agreeableness,
													benchmark: comparisonReport.personB.bigFive.agreeableness,
													fullMark: 100
												},
												{
													trait: "ES",
													score: comparisonReport.personA.bigFive.emotionalStability,
													benchmark: comparisonReport.personB.bigFive.emotionalStability,
													fullMark: 100
												}
											],
											hexacoRadar: [
												{
													trait: "H",
													score: comparisonReport.personA.hexaco.honestyHumility,
													fullMark: 100
												},
												{
													trait: "E",
													score: comparisonReport.personA.hexaco.emotionality,
													fullMark: 100
												},
												{
													trait: "X",
													score: comparisonReport.personA.hexaco.extraversion,
													fullMark: 100
												},
												{
													trait: "A",
													score: comparisonReport.personA.hexaco.agreeableness,
													fullMark: 100
												},
												{
													trait: "C",
													score: comparisonReport.personA.hexaco.conscientiousness,
													fullMark: 100
												},
												{
													trait: "O",
													score: comparisonReport.personA.hexaco.openness,
													fullMark: 100
												}
											],
											emotionalIntelligence: [{
												branch: "الذكاء العاطفي (أ)",
												score: comparisonReport.personA.emotionalIntelligence,
												color: "#8b5cf6"
											}, {
												branch: "الذكاء العاطفي (ب)",
												score: comparisonReport.personB.emotionalIntelligence,
												color: "#10b981"
											}],
											attachment: {
												anxiety: comparisonReport.personA.attachment.anxiety,
												avoidance: comparisonReport.personA.attachment.avoidance,
												styleKey: "secure",
												styleAr: comparisonReport.personA.attachment.styleAr,
												styleEn: "Attachment"
											},
											communicationStyles: [{
												style: "الحزم",
												score: comparisonReport.personA.communicationStyle.assertive,
												color: "#3b82f6"
											}, {
												style: "الإنصات",
												score: comparisonReport.personA.communicationStyle.reflective,
												color: "#10b981"
											}],
											conflictModes: [
												{
													mode: "التعاون",
													score: comparisonReport.personA.conflictResolution.collaborating,
													fullMark: 100
												},
												{
													mode: "التسوية",
													score: comparisonReport.personA.conflictResolution.compromising,
													fullMark: 100
												},
												{
													mode: "التجنب",
													score: comparisonReport.personA.conflictResolution.avoiding,
													fullMark: 100
												}
											],
											lifeGoalsAlignment: [
												{
													domain: "الاستقرار الأسري",
													userScore: comparisonReport.personA.lifeGoals.familyStability,
													targetBenchmark: comparisonReport.personB.lifeGoals.familyStability
												},
												{
													domain: "النمو المهني",
													userScore: comparisonReport.personA.lifeGoals.careerGrowth,
													targetBenchmark: comparisonReport.personB.lifeGoals.careerGrowth
												},
												{
													domain: "العمق الفكري",
													userScore: comparisonReport.personA.lifeGoals.intellectualDepth,
													targetBenchmark: comparisonReport.personB.lifeGoals.intellectualDepth
												}
											],
											compatibilityMatrix: comparisonReport.nineAxesBreakdown.slice(0, 8).map((r) => ({
												axisA: r.axisNameAr.split("(")[0],
												axisB: "التناغم",
												synergyScore: r.matchScore,
												labelAr: r.axisNameAr.split("(")[0]
											}))
										};
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LazyScientificVisualDashboards, {
											charts: emptyCharts,
											userName: comparisonReport.personA.personName,
											comparisonOverlay: {
												personAName: comparisonReport.personA.personName,
												personBName: comparisonReport.personB.personName,
												axes: comparisonReport.nineAxesBreakdown
											}
										});
									})()
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center justify-between gap-2 pt-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: handleSaveComparisonRecord,
										className: `px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer ${comparisonSaved ? "bg-emerald-600 text-white" : "bg-purple-600 hover:bg-purple-500 text-white"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookmarkCheck, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: comparisonSaved ? "✓ تم الحفظ في سجل تقاريري" : "حفظ المقارنة في سجل تقاريري" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: handleExportComparisonPdf,
										className: "px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1.5 transition cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileDown, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تصدير تقرير المقارنة (PDF)" })]
									})]
								})
							]
						})
					]
				}) : activeMode === "dyadic_lab" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-4",
					children: !dyadicReport ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3 p-3.5 rounded-2xl bg-slate-900/90 border border-slate-700/80",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-[11px] font-bold text-emerald-300 mb-1",
								children: "اسم الطرف الأول:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								value: partnerAName,
								onChange: (e) => setPartnerAName(e.target.value),
								className: "w-full px-3 py-1.5 rounded-xl bg-black/40 border border-white/15 text-xs text-white focus:outline-none focus:border-emerald-400"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-[11px] font-bold text-cyan-300 mb-1",
								children: "اسم الطرف الثاني:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								value: partnerBName,
								onChange: (e) => setPartnerBName(e.target.value),
								className: "w-full px-3 py-1.5 rounded-xl bg-black/40 border border-white/15 text-xs text-white focus:outline-none focus:border-cyan-400"
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-3 rounded-2xl bg-gradient-to-l from-emerald-950/60 to-slate-900 border border-emerald-500/30 flex items-center justify-between text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "px-2.5 py-1 rounded-lg bg-emerald-500 text-slate-950 font-black",
									children: ["دور الإجابة الآن: ", activePartnerTurn === "A" ? partnerAName : partnerBName]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-slate-300",
									children: [
										"السؤال ",
										questionIdx + 1,
										" من ",
										dyadicQuestions.length
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] text-emerald-300 font-mono",
								children: currentQ.scientificDimension
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[11px] text-amber-300 font-semibold",
									children: currentQ.subtitle
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "text-sm sm:text-base font-extrabold text-white font-['Alexandria'] leading-snug",
									children: currentQ.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-2 pt-1",
									children: currentQ.options.map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => handleSelectDyadicOption(opt.id),
										className: "w-full p-3 rounded-xl bg-slate-900/90 hover:bg-emerald-950/50 border border-slate-700 hover:border-emerald-500/50 text-right transition cursor-pointer space-y-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-xs font-bold text-white",
											children: opt.text
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[11px] text-slate-400",
											children: opt.description
										})]
									}, opt.id))
								})
							]
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 flex flex-col sm:flex-row items-center justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-xs text-emerald-300 font-bold",
											children: [
												"نتيجة القياس السيكومتري المزدوج (",
												dyadicReport.partnerAName,
												" ✕ ",
												dyadicReport.partnerBName,
												")"
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "text-base font-black text-white font-['Alexandria']",
											children: dyadicReport.stabilityClassificationAr
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap items-center gap-3 text-[11px] text-slate-300 pt-1",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["مؤشر التشابه القيمي: ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
													className: "text-emerald-400",
													children: [dyadicReport.similarityIndex, "%"]
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["مؤشر التكامل الوظيفي: ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
													className: "text-cyan-400",
													children: [dyadicReport.complementarityIndex, "%"]
												})] })
											]
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3.5 rounded-2xl bg-black/50 border border-emerald-400/40 text-center shrink-0 min-w-[120px]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[10px] text-slate-300",
										children: "التناغم الثنائي"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-3xl font-black text-emerald-400 font-mono",
										children: [dyadicReport.overallHarmonyScore, "%"]
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-2.5",
								children: dyadicReport.dimensions.map((dim) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3.5 rounded-2xl bg-slate-900/90 border border-slate-700/80 space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-xs font-bold text-white",
												children: dim.titleAr
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[10px] text-slate-400",
												children: dim.scientistAr
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-left shrink-0",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-sm font-black text-emerald-400 font-mono",
													children: [dim.harmonyPercentage, "%"]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "block text-[10px] text-cyan-300",
													children: dim.synergyTypeAr
												})]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-2 gap-2 text-[11px] text-slate-300 bg-black/30 p-2 rounded-xl",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
												dyadicReport.partnerAName,
												": ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
													className: "text-white",
													children: [dim.partnerAScore, "%"]
												})
											] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
												dyadicReport.partnerBName,
												": ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
													className: "text-white",
													children: [dim.partnerBScore, "%"]
												})
											] })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] text-slate-300 leading-relaxed",
											children: dim.scientificInsightAr
										})
									]
								}, dim.id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3.5 rounded-2xl bg-slate-900 border border-slate-700 text-xs text-slate-200 leading-relaxed",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-emerald-400 block mb-1",
									children: "التوصية الإكلينيكية والتربوية للشريكين:"
								}), dyadicReport.scientificRecommendationAr]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-2 pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: handleExportDyadicPdf,
									className: "px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shadow-md",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileDown, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تحميل التقرير العلمي المزدوج (PDF)" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: handleResetDyadic,
									className: "px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "إعادة القياس المزدوج" })]
								})]
							})
						]
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-3.5 rounded-2xl bg-black/30 border border-white/10 mb-4 text-xs space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-bold text-gray-200 flex items-center gap-1.5 mb-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-3.5 h-3.5 text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "كيف تعمل دعوة التقييم العلمي عن بُعد؟" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px] text-gray-300",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-2 rounded-xl bg-white/5 border border-white/10 space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold text-rose-400",
										children: "1. مشاركة الرابط"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "ترسل الرابط المخصص لشريكك عبر واتساب أو تيليجرام." })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-2 rounded-xl bg-white/5 border border-white/10 space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold text-purple-400",
										children: "2. الإجابة المستقلة"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "يجيب الشريك على الـ 25 سؤالاً علمياً في التوافق الزواجي." })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-2 rounded-xl bg-white/5 border border-white/10 space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold text-emerald-400",
										children: "3. المقارنة العلمية"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "يتم احتساب معامل التناغم القيمي والتكامل السيكومتري بينكما." })]
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-bold text-gray-300 block",
							children: "رابط دعوتك الشخصي:"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 p-2 rounded-2xl bg-black/40 border border-white/15",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								readOnly: true,
								value: inviteLink,
								className: "bg-transparent text-xs text-rose-200 font-mono flex-1 outline-none px-2 select-all overflow-ellipsis"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
								whileHover: { scale: 1.05 },
								whileTap: { scale: .95 },
								onClick: handleCopy,
								className: `px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition cursor-pointer shrink-0 shadow-sm ${copied ? "bg-emerald-500 text-white" : "bg-rose-500 hover:bg-rose-600 text-white"}`,
								children: copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تم النسخ!" })] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "نسخ الرابط" })] })
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2.5 mb-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: `https://api.whatsapp.com/send?text=${encodeURIComponent(shareText)}`,
							target: "_blank",
							rel: "noopener noreferrer",
							onClick: () => soundManager.playTap(),
							className: "flex items-center justify-center gap-2 py-2.5 px-3 rounded-2xl bg-emerald-600/30 hover:bg-emerald-600/40 border border-emerald-500/40 text-emerald-300 font-bold text-xs transition cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "w-4 h-4 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "إرسال عبر WhatsApp" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: `https://t.me/share/url?url=${encodeURIComponent(inviteLink)}&text=${encodeURIComponent(shareText)}`,
							target: "_blank",
							rel: "noopener noreferrer",
							onClick: () => soundManager.playTap(),
							className: "flex items-center justify-center gap-2 py-2.5 px-3 rounded-2xl bg-sky-600/30 hover:bg-sky-600/40 border border-sky-500/40 text-sky-300 font-bold text-xs transition cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "w-4 h-4 text-sky-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "إرسال عبر Telegram" })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pt-3 border-t border-white/10 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundManager.playTap();
								setShowQr(!showQr);
							},
							className: "flex items-center gap-1.5 text-xs text-gray-300 hover:text-white transition cursor-pointer font-medium",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrCode, { className: "w-4 h-4 text-purple-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: showQr ? "إخفاء رمز QR" : "إظهار رمز QR للمسح من الهاتف" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-[11px] text-gray-400 flex items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-3.5 h-3.5 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "جلسة قياس مشفرة" })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: showQr && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
						initial: {
							opacity: 0,
							height: 0
						},
						animate: {
							opacity: 1,
							height: "auto"
						},
						exit: {
							opacity: 0,
							height: 0
						},
						className: "mt-3 p-4 rounded-2xl bg-white flex flex-col items-center justify-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(inviteLink)}`,
							alt: "Couple Invite QR Code",
							className: "w-40 h-40 rounded-xl shadow-md"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-gray-700 text-[11px] font-bold mt-2",
							children: "امسح الرمز بكاميرا الهاتف لفتح رابط الدعوة مباشرة"
						})]
					}) })
				] })
			]
		})
	});
};
//#endregion
export { CoupleInviteModal };
