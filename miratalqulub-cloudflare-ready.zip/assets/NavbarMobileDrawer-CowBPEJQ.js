import "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { An as BookOpen, En as Brain, Pt as Heart, h as Trash2 } from "./vendor-icons-WoMClU7U.js";
require_react();
var import_jsx_runtime = require_jsx_runtime();
var NavbarMobileDrawer = ({ isAr, isLight, confirmDeleteStep, onSetConfirmDeleteStep, onPermanentDeleteData, onNavAction, onNavigatePage, onReset, onOpenPsychologyTests, onOpenIntelligenceTests, onOpenBlindDate, onOpenArticles, onOpenNovels, onOpenUserDashboard, onOpenHistory }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `lg:hidden mt-3 pt-3 border-t overflow-hidden text-xs space-y-3 ${isLight ? "border-slate-200" : "border-white/10"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `p-3 rounded-2xl border space-y-2 ${isLight ? "bg-purple-50/60 border-purple-200" : "bg-purple-950/25 border-purple-500/30"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `font-extrabold flex items-center gap-1.5 ${isLight ? "text-purple-800" : "text-purple-300"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "١. استكشف ذاتك (مقاييس الشخصية والذكاء)" : "1. Explore Yourself (Personality & IQ)" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 gap-1.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onNavAction(() => onNavigatePage ? onNavigatePage("personality-tests") : onOpenPsychologyTests && onOpenPsychologyTests()),
							className: `p-2.5 rounded-xl border font-bold text-start cursor-pointer ${isLight ? "bg-white border-purple-200 text-slate-800" : "bg-slate-900/90 border-white/10 text-slate-100"}`,
							children: ["🧠 ", isAr ? "مقاييس الشخصية (MBTI & Big Five)" : "Personality Lab (MBTI & Big Five)"]
						}),
						onOpenIntelligenceTests && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onNavAction(onOpenIntelligenceTests),
							className: `p-2.5 rounded-xl border font-bold text-start cursor-pointer ${isLight ? "bg-white border-purple-200 text-slate-800" : "bg-slate-900/90 border-white/10 text-slate-100"}`,
							children: ["💡 ", isAr ? "اختبارات الذكاء المتعدد و رافين" : "Multiple Intelligences & IQ Lab"]
						}),
						onOpenPsychologyTests && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onNavAction(onOpenPsychologyTests),
							className: `p-2.5 rounded-xl border font-bold text-start sm:col-span-2 cursor-pointer ${isLight ? "bg-white border-purple-200 text-slate-800" : "bg-slate-900/90 border-white/10 text-slate-100"}`,
							children: [
								"📊",
								" ",
								isAr ? "المقاييس الإكلينيكية المتخصصة (16PF • EPQ • التعلق)" : "Specialized Clinical Scales (16PF • EPQ)"
							]
						}),
						onNavigatePage && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onNavAction(() => onNavigatePage("how-results-are-calculated")),
							className: `p-2.5 rounded-xl border font-bold text-start sm:col-span-2 cursor-pointer ${isLight ? "bg-emerald-50 border-emerald-200 text-emerald-900" : "bg-emerald-950/30 border-emerald-500/30 text-emerald-200"}`,
							children: [
								"🛡️",
								" ",
								isAr ? "كيف يتم حساب نتائج الاختبارات؟ (Big Five • HEXACO • Attachment • EQ)" : "How Are Test Results Calculated? (Big Five • HEXACO • Attachment • EQ)"
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `p-3 rounded-2xl border space-y-2 ${isLight ? "bg-rose-50/60 border-rose-200" : "bg-rose-950/25 border-rose-500/30"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `font-extrabold flex items-center gap-1.5 ${isLight ? "text-rose-800" : "text-rose-300"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "٢. اكتشف التوافق (كاشف التوافق و The Blind Date)" : "2. Discover Compatibility & The Blind Date" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onNavAction(() => {
							if (onNavigatePage) onNavigatePage("compatibility");
							if (onReset) onReset();
						}),
						className: `p-2.5 rounded-xl border font-bold text-start cursor-pointer ${isLight ? "bg-white border-rose-200 text-slate-800" : "bg-slate-900/90 border-white/10 text-slate-100"}`,
						children: ["💖 ", isAr ? "كاشف التوافق الفكري والعاطفي" : "Partner Compatibility Calculator"]
					}), onOpenBlindDate && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onNavAction(onOpenBlindDate),
						className: `p-2.5 rounded-xl border font-bold text-start cursor-pointer ${isLight ? "bg-white border-rose-200 text-slate-800" : "bg-slate-900/90 border-white/10 text-slate-100"}`,
						children: ["💬 ", isAr ? "اللقاء الأعمى (The Blind Date)" : "The Blind Date Experience"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `p-3 rounded-2xl border space-y-2 ${isLight ? "bg-emerald-50/60 border-emerald-200" : "bg-emerald-950/25 border-emerald-500/30"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `font-extrabold flex items-center gap-1.5 ${isLight ? "text-emerald-800" : "text-emerald-300"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "٣. هدية الواحة المعرفية والمقالات والروايات" : "3. Knowledge Oasis: Articles & Novels" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onNavAction(() => onNavigatePage ? onNavigatePage("articles") : onOpenArticles && onOpenArticles()),
						className: `p-2.5 rounded-xl border font-bold text-start cursor-pointer ${isLight ? "bg-white border-emerald-200 text-slate-800" : "bg-slate-900/90 border-white/10 text-slate-100"}`,
						children: ["📚 ", isAr ? "موسوعة المقالات والأبحاث المحكّمة" : "Clinical Articles & Research"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onNavAction(() => onNavigatePage ? onNavigatePage("novels") : onOpenNovels && onOpenNovels()),
						className: `p-2.5 rounded-xl border font-bold text-start cursor-pointer ${isLight ? "bg-white border-emerald-200 text-slate-800" : "bg-slate-900/90 border-white/10 text-slate-100"}`,
						children: ["🕵️‍♂️ ", isAr ? "مكتبة الروايات والتحقيقات" : "Novels & Forensic Library"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `p-3 rounded-2xl border space-y-2 ${isLight ? "bg-violet-50/70 border-violet-200" : "bg-violet-950/30 border-violet-500/30"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `font-extrabold flex items-center justify-between ${isLight ? "text-violet-800" : "text-violet-300"}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["👤 ", isAr ? "ملفي والتحكم بالبيانات" : "My Profile & Data Control"] })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-1.5",
						children: [onOpenUserDashboard && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onNavAction(onOpenUserDashboard),
							className: `p-2 rounded-xl border font-bold text-start cursor-pointer ${isLight ? "bg-white border-violet-200 text-slate-800" : "bg-slate-900 border-white/10 text-slate-100"}`,
							children: isAr ? "لوحة ملفي الشامل" : "Profile Dashboard"
						}), onOpenHistory && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onNavAction(onOpenHistory),
							className: `p-2 rounded-xl border font-bold text-start cursor-pointer ${isLight ? "bg-white border-violet-200 text-slate-800" : "bg-slate-900 border-white/10 text-slate-100"}`,
							children: isAr ? "سجل نتائجي المحفوظة" : "Saved History"
						})]
					}),
					!confirmDeleteStep ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onSetConfirmDeleteStep(true),
						className: `w-full p-2 rounded-xl border font-bold flex items-center justify-center gap-1.5 cursor-pointer ${isLight ? "bg-rose-50 border-rose-300 text-rose-800" : "bg-rose-500/20 border-rose-500/40 text-rose-200"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "حذف جميع بياناتي نهائياً" : "Delete All My Data Permanently" })]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `p-2.5 rounded-xl border space-y-2 ${isLight ? "bg-rose-50 border-rose-300 text-rose-950" : "bg-rose-950/60 border-rose-500/40 text-rose-100"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-bold",
							children: isAr ? "تأكيد المسح النهائي لجميع البيانات المحلية والسحابية؟" : "Confirm permanent erasure of all local and cloud data?"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: onPermanentDeleteData,
								className: "flex-1 py-1.5 rounded-lg bg-rose-700 text-white font-bold cursor-pointer",
								children: isAr ? "نعم، احذف نهائياً" : "Yes, Delete"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => onSetConfirmDeleteStep(false),
								className: "py-1.5 px-3 rounded-lg bg-slate-700 text-white font-bold cursor-pointer",
								children: isAr ? "إلغاء" : "Cancel"
							})]
						})]
					})
				]
			})
		]
	});
};
//#endregion
export { NavbarMobileDrawer };
