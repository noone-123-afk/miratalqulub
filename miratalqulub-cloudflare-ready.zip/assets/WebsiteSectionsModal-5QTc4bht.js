import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { An as BookOpen, B as Send, D as Sparkles, En as Brain, N as Shield, Pt as Heart, an as Compass, dn as CircleQuestionMark, mn as CircleCheck, r as X, ut as MessageSquare, w as Star, yn as ChevronDown } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import { n as AnimatePresence, t as motion } from "./vendor-motion-BS7ODJw7.js";
import { n as fetchFeedbackMessages, r as submitFeedbackMessage } from "./feedbackService-rknvSOxy.js";
//#region src/components/WebsiteSectionsModal.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var WebsiteSectionsModal = ({ isOpen, onClose, initialTab = "about", onOpenBlindDate, onStartQuiz }) => {
	const [activeTab, setActiveTab] = (0, import_react.useState)(initialTab);
	const [openFaqIndex, setOpenFaqIndex] = (0, import_react.useState)(null);
	if (!isOpen) return null;
	const faqs = [
		{
			q: "كيف تحدد المنصة مؤشرات التوافق الأسري والزواجي علمياً؟",
			a: "تعتمد المنصة على مقياس سيكومتري محكّم يتألف من 25 سؤالاً علمياً موزعة على 6 أطر مرجعية: نموذج البيت العلائقي المتين ومحاولات الإصلاح لجون غوتمان (Gottman, 1999)، ومقياس التعلق للراشدين (Bowlby & Fraley ECR-R)، ونظرية الحب الثلاثية لستيرنبرغ وعقلية النمو، ونظرية الأنساق الأسرية لبوين وهرم القيم لشوارتز، وعلم النفس المالي (Klontz, 2011)."
		},
		{
			q: "ما هو مختبر التقييم العلمي المزدوج للتوافق بين الشريكين (Dyadic Assessment)؟",
			a: "يتيح لك الموقع مقارنة إجابات الطرف الأول والطرف الثاني بشكل مباشر عبر نموذج التحليل الثنائي (Kenny Dyadic Data Analysis) لحساب معامل التقارب والانسجام الحقيقي بين الشريكين في 6 مقاييس فرعية وتصدير تقرير PDF علمي مفصل."
		},
		{
			q: "هل دردشة المتواجدين (الرادار) تجمعني بأشخاص حقيقيين فقط؟",
			a: "نعم، يعمل الرادار بنظام WebSockets في الوقت الحقيقي للربط بين المستخدمين الحقيقيين المتصلين فعلياً في نفس اللحظة، ولا يستخدم أي حسابات وهمية أو محاكاة آلية."
		},
		{
			q: "هل بياناتي الشخصية وإجاباتي محمية وسرية؟",
			a: "بكل تأكيد. نحن نطبق سياسة خصوصية صارمة: لا يتم بيع بياناتك لأي جهة خارجية، ويتم تشفير الاتصالات عبر بروتوكول TLS 1.3 مع إمكانية حفظ تقدمك محلياً وقفل نتيجتك برمز PIN سري."
		},
		{
			q: "كيف يتم احتساب درجات اختبارات الذكاء والشخصية في الموقع؟",
			a: "تتكون اختبارات الذكاء من 4 بطاريات قياسية (45 سؤالاً للذكاءات المتعددة الـ 9، و25 مصفوفة بصرية لاختبار رافن IQ، و25 سؤالاً للذكاء العاطفي EQ، و25 سؤالاً للقدرات المعرفية CogAT)، بالإضافة إلى 8 مقاييس شخصية محكّمة (20 إلى 32 سؤالاً لكل مقياس) مع معادلات تصحيح معيارية معلنة."
		},
		{
			q: "هل الموقع مجاني بالكامل؟",
			a: "نعم، المنصة مجانية ومفتوحة لجميع المستخدمين في الوطن العربي والعالم لنشر الوعي النفسي والأسري المبني على أسس علمية موثقة."
		}
	];
	const [realReviews, setRealReviews] = (0, import_react.useState)([]);
	const [loadingReviews, setLoadingReviews] = (0, import_react.useState)(false);
	const [reviewName, setReviewName] = (0, import_react.useState)("");
	const [reviewRole, setReviewRole] = (0, import_react.useState)("");
	const [reviewComment, setReviewComment] = (0, import_react.useState)("");
	const [reviewRating, setReviewRating] = (0, import_react.useState)(5);
	const [isSubmittingReview, setIsSubmittingReview] = (0, import_react.useState)(false);
	const [reviewSuccess, setReviewSuccess] = (0, import_react.useState)(false);
	import_react.useEffect(() => {
		if (isOpen && activeTab === "testimonials") {
			setLoadingReviews(true);
			fetchFeedbackMessages().then((msgs) => {
				setRealReviews(msgs);
			}).catch(() => {}).finally(() => setLoadingReviews(false));
		}
	}, [isOpen, activeTab]);
	const handleReviewSubmit = async (e) => {
		e.preventDefault();
		if (!reviewName.trim() || !reviewComment.trim()) return;
		soundManager.playTap();
		setIsSubmittingReview(true);
		try {
			await submitFeedbackMessage({
				name: reviewName.trim(),
				email: "user-review@miratalqulub.com",
				subject: reviewRole.trim() || "مشارك في اختبارات المنصة",
				message: reviewComment.trim(),
				category: "partner_experience",
				categoryLabelAr: reviewRole.trim() || "تجربة مستخدم حقيقية",
				rating: reviewRating
			});
			const updated = await fetchFeedbackMessages();
			setRealReviews(updated);
			setReviewName("");
			setReviewRole("");
			setReviewComment("");
			setReviewSuccess(true);
			soundManager.playRoundPass();
			setTimeout(() => setReviewSuccess(false), 3500);
		} catch (err) {
			console.error("Review submit error", err);
		} finally {
			setIsSubmittingReview(false);
		}
	};
	const articles = [
		{
			title: "أسرار التوافق الفكري قبل الزواج: كيف تكتشف الانسجام الحقيقي؟",
			readTime: "4 دقائق قراءة",
			tag: "علم النفس الأسري",
			icon: "🧠",
			summary: "التوافق الفكري لا يعني التطابق في الآراء، بل القدرة على إدارة الحوار والنضج في تقبل الاختلاف، وبناء أهداف حياتية مشتركة تدعم نمو الطرفين."
		},
		{
			title: "لغات الحب الخمس في الثقافة العربية: كيف يعبر كل شريك عن مشاعره؟",
			readTime: "5 دقائق قراءة",
			tag: "الذكاء العاطفي",
			icon: "💖",
			summary: "استكشاف كيفية ترجمة كلمات التشجيع، تقديم الخدمات، قضاء الوقت النوعي، تبادل الهدايا، والاحتواء في البيوت العربية المعاصرة."
		},
		{
			title: "العلامات الخضراء والحمراء في فترة التعارف والخطوبة",
			readTime: "6 دقائق قراءة",
			tag: "دليل العلاقات",
			icon: "🚦",
			summary: "مؤشرات الأمان النفسي: الوضوح والصدق، احترام الحدود الأسرية، والقدرة على الاعتذار، في مقابل السيطرة وتذبذب المشاعر."
		},
		{
			title: "كيف تختار شريك الحياة وفق التطلعات المستقبلية والطموح؟",
			readTime: "3 دقائق قراءة",
			tag: "تخطيط المستقبل",
			icon: "🚀",
			summary: "أهمية مناقشة إدارة الميزانية، الإقامة، عمل الطرفين، ورعاية الأبناء قبل الإقدام على خطوة الارتباط لضمان استقرار طويل المدى."
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: {
				opacity: 0,
				scale: .95,
				y: 15
			},
			animate: {
				opacity: 1,
				scale: 1,
				y: 0
			},
			exit: {
				opacity: 0,
				scale: .95,
				y: 15
			},
			className: "relative w-full max-w-4xl my-6 bg-gradient-to-b from-[#18112e] via-[#120d24] to-[#0c0916] border border-white/15 rounded-3xl p-5 sm:p-7 shadow-2xl text-white overflow-hidden max-h-[90vh] flex flex-col",
			dir: "rtl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => {
						soundManager.playTap();
						onClose();
					},
					className: "absolute top-4 left-4 p-2 rounded-full bg-white/10 hover:bg-white/20 text-gray-300 hover:text-white transition z-10 cursor-pointer",
					"aria-label": "إغلاق",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-5 h-5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center mb-5 shrink-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/20 border border-rose-500/30 text-rose-300 text-xs font-semibold mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-3.5 h-3.5 text-rose-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "موقع ومنصة مِـرآة القـلوب التفاعلية" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl sm:text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-rose-200 via-pink-100 to-violet-200 font-['Alexandria']",
							children: "استكشف المنصة والموقع"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-gray-400 text-xs sm:text-sm mt-1 max-w-lg mx-auto",
							children: "بوابتك المتكاملة لفهم خوارزميات التوافق، تجارب المستخدمين، والمقالات النفسية التوعوية."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-1.5 p-1.5 rounded-2xl bg-white/5 border border-white/10 mb-5 overflow-x-auto shrink-0 scrollbar-none",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundManager.playTap();
								setActiveTab("about");
							},
							className: `py-2 px-3 sm:px-4 rounded-xl text-xs sm:text-sm font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${activeTab === "about" ? "bg-gradient-to-r from-rose-600 to-pink-600 text-white shadow-md" : "text-gray-400 hover:text-white hover:bg-white/5"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "عن المنصة ورؤيتها" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundManager.playTap();
								setActiveTab("how-it-works");
							},
							className: `py-2 px-3 sm:px-4 rounded-xl text-xs sm:text-sm font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${activeTab === "how-it-works" ? "bg-gradient-to-r from-rose-600 to-pink-600 text-white shadow-md" : "text-gray-400 hover:text-white hover:bg-white/5"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "كيف تعمل الخوارزمية" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundManager.playTap();
								setActiveTab("testimonials");
							},
							className: `py-2 px-3 sm:px-4 rounded-xl text-xs sm:text-sm font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${activeTab === "testimonials" ? "bg-gradient-to-r from-rose-600 to-pink-600 text-white shadow-md" : "text-gray-400 hover:text-white hover:bg-white/5"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "w-4 h-4 text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "قصص نجاح ومراجعات" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundManager.playTap();
								setActiveTab("articles");
							},
							className: `py-2 px-3 sm:px-4 rounded-xl text-xs sm:text-sm font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${activeTab === "articles" ? "bg-gradient-to-r from-rose-600 to-pink-600 text-white shadow-md" : "text-gray-400 hover:text-white hover:bg-white/5"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "مقالات ونظريات التوافق" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundManager.playTap();
								setActiveTab("faq");
							},
							className: `py-2 px-3 sm:px-4 rounded-xl text-xs sm:text-sm font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${activeTab === "faq" ? "bg-gradient-to-r from-rose-600 to-pink-600 text-white shadow-md" : "text-gray-400 hover:text-white hover:bg-white/5"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleQuestionMark, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "الأسئلة الشائعة (FAQ)" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundManager.playTap();
								setActiveTab("privacy");
							},
							className: `py-2 px-3 sm:px-4 rounded-xl text-xs sm:text-sm font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${activeTab === "privacy" ? "bg-gradient-to-r from-rose-600 to-pink-600 text-white shadow-md" : "text-gray-400 hover:text-white hover:bg-white/5"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "الخصوصية والأمان" })]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 overflow-y-auto pr-1 pl-2 space-y-4",
					children: [
						activeTab === "about" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
							initial: {
								opacity: 0,
								y: 10
							},
							animate: {
								opacity: 1,
								y: 0
							},
							className: "space-y-4 text-xs sm:text-sm text-gray-300 leading-relaxed",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-rose-500/10 via-pink-500/5 to-purple-500/10 border border-rose-500/20",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
											className: "text-base sm:text-lg font-bold text-white mb-2 font-['Alexandria'] flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "w-5 h-5 text-rose-400 fill-rose-500/40" }), "رؤية مرآة القلوب: التعارف القائم على الوعي والتوافق القيمي"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-gray-300 text-xs sm:text-sm leading-relaxed mb-3",
											children: "انطلقت منصة «مرآة القلوب» استجابةً للحاجة إلى بيئة تعارف راقية وعصرية تجمع بين أصالة القيم وأحدث مقاييس التحليل النفسي والسلوكي المتطورة. نؤمن أن الزواج الناجح والشراكة المستدامة تبنى على تناغم فكري واجتماعي ونفسي عميق."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-3 rounded-xl bg-slate-900/80 border border-slate-700/60 text-xs text-slate-300 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-rose-400 font-bold block sm:inline ml-1",
												children: "إشراف وتطوير:"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "الموقع مشرف عليه ومُدار بواسطة مجموعة من المهندسين المتخصصين" })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-3 text-[11px] text-slate-400",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "الأردن - عمّان" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "font-mono text-blue-400",
														children: "one497303@gmail.com"
													})
												]
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-3 gap-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-4 rounded-2xl bg-white/[0.03] border border-white/10",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "w-8 h-8 rounded-xl bg-rose-500/20 text-rose-300 flex items-center justify-center mb-2.5 font-bold",
													children: "01"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
													className: "font-bold text-white mb-1",
													children: "العمق الفكري والأكاديمي"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-gray-400 text-xs",
													children: "قياس أسلوب التفكير، النضج في حل الخلافات، والتقارب الثقافي والمستوى الدراسي."
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-4 rounded-2xl bg-white/[0.03] border border-white/10",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "w-8 h-8 rounded-xl bg-pink-500/20 text-pink-300 flex items-center justify-center mb-2.5 font-bold",
													children: "02"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
													className: "font-bold text-white mb-1",
													children: "الانسجام المجتمعي والأسري"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-gray-400 text-xs",
													children: "احترام العادات والتقاليد والبيئة الثقافية الخاصة بكل بلد عربي وأصل اجتماعي."
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-4 rounded-2xl bg-white/[0.03] border border-white/10",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "w-8 h-8 rounded-xl bg-violet-500/20 text-violet-300 flex items-center justify-center mb-2.5 font-bold",
													children: "03"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
													className: "font-bold text-white mb-1",
													children: "طموحات المستقبل والأحلام"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-gray-400 text-xs",
													children: "تطابق التطلعات في إدارة المنزل وتربية الأبناء وتحقيق الأهداف المهنية المشتركة."
												})
											]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-white/[0.02] border border-white/5 flex flex-col sm:flex-row items-center justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-2xl",
											children: "💬"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "font-bold text-white text-xs sm:text-sm",
											children: "تجربة التعارف التفاعلي المباشر The Blind Date"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-gray-400 text-xs",
											children: "حيث تحجب المظاهر حتى يتأكد التوافق عبر 5 أسئلة متبادلة لكل مرحلة قبل إسقاط الستار!"
										})] })]
									}), onOpenBlindDate && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => {
											soundManager.playTap();
											onClose();
											onOpenBlindDate();
										},
										className: "px-4 py-2 rounded-xl bg-gradient-to-r from-rose-600 to-purple-600 text-white font-bold text-xs whitespace-nowrap active:scale-95 transition cursor-pointer",
										children: "خوض التجربة الآن 💬"
									})]
								})
							]
						}),
						activeTab === "how-it-works" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
							initial: {
								opacity: 0,
								y: 10
							},
							animate: {
								opacity: 1,
								y: 0
							},
							className: "space-y-4 text-xs sm:text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-4 rounded-2xl bg-purple-500/10 border border-purple-500/20",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-bold text-white text-base mb-1.5 font-['Alexandria']",
									children: "الركائز الأربع لخوارزمية التحليل ودراسة التوافق"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-gray-300 leading-relaxed text-xs",
									children: "يقوم محرك التحليل السلوكي بربط كل إجابة يقدمها المستخدم بمؤشرات توافق دقيقة تم تطويرها وفق دراسات علم الاجتماع الحديث:"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3.5 rounded-2xl bg-white/[0.03] border border-white/10 flex items-start gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-7 h-7 rounded-lg bg-blue-500/20 text-blue-300 flex items-center justify-center shrink-0 font-bold",
											children: "1"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "font-bold text-white text-xs sm:text-sm",
											children: "المعيار الفكري والإدراكي (Intellectual Synergy)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-gray-400 text-xs mt-0.5",
											children: "تحليل نمط التفكير المنطقي والعاطفي، وطريقة إدارة النقاشات وحل سوء الفهم باحترام متبادل."
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3.5 rounded-2xl bg-white/[0.03] border border-white/10 flex items-start gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-7 h-7 rounded-lg bg-pink-500/20 text-pink-300 flex items-center justify-center shrink-0 font-bold",
											children: "2"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "font-bold text-white text-xs sm:text-sm",
											children: "المعيار المجتمعي والعائلي (Sociological Harmony)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-gray-400 text-xs mt-0.5",
											children: "دراسة التناغم بين الأصول الثقافية والبيئة الأسرية، وأسلوب التواصل مع الأهل والأقارب واستقلال بيت الزوجية."
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3.5 rounded-2xl bg-white/[0.03] border border-white/10 flex items-start gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-300 flex items-center justify-center shrink-0 font-bold",
											children: "3"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "font-bold text-white text-xs sm:text-sm",
											children: "المعيار النفسي والأمان العاطفي (Emotional Security)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-gray-400 text-xs mt-0.5",
											children: "تقييم نمط التعلق (آمن، قلق، متجنب) والقدرة على منح الطرف الآخر الاحتواء والسكينة في الأوقات الصعبة."
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3.5 rounded-2xl bg-white/[0.03] border border-white/10 flex items-start gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-7 h-7 rounded-lg bg-amber-500/20 text-amber-300 flex items-center justify-center shrink-0 font-bold",
											children: "4"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "font-bold text-white text-xs sm:text-sm",
											children: "المعيار المستقبلي والطموحات (Aspirational Alignment)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-gray-400 text-xs mt-0.5",
											children: "التطابق في الرؤية المالية، نمط المعيشة، وتطلعات السفر والاستقرار وإنجاب الأطفال."
										})] })]
									})
								]
							})]
						}),
						activeTab === "testimonials" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
							initial: {
								opacity: 0,
								y: 10
							},
							animate: {
								opacity: 1,
								y: 0
							},
							className: "space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex text-amber-400",
											children: [...Array(5)].map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "w-4 h-4 fill-amber-400 text-amber-400" }, i))
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-bold text-white",
											children: "آراء وتجارب الزوار الحقيقية"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-gray-300",
										children: [
											"تُعرض فقط التعليقات الحقيقية المرسلة من المستخدمين (",
											realReviews.length,
											")"
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									onSubmit: handleReviewSubmit,
									className: "p-4 rounded-2xl bg-white/[0.04] border border-white/10 space-y-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
												className: "font-bold text-white text-xs sm:text-sm flex items-center gap-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquare, { className: "w-4 h-4 text-rose-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "شارك تجربتك الحقيقية مع المنصة:" })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex items-center gap-1",
												children: [
													1,
													2,
													3,
													4,
													5
												].map((st) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => setReviewRating(st),
													className: "p-0.5 cursor-pointer",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: `w-4 h-4 ${st <= reviewRating ? "fill-amber-400 text-amber-400" : "text-gray-600"}` })
												}, st))
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-1 sm:grid-cols-2 gap-2.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "text",
												value: reviewName,
												onChange: (e) => setReviewName(e.target.value),
												placeholder: "اسمك الكريم والمدينة...",
												required: true,
												className: "px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-rose-400"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "text",
												value: reviewRole,
												onChange: (e) => setReviewRole(e.target.value),
												placeholder: "المهنة أو الاختبار الذي خضته (اختياري)...",
												className: "px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-rose-400"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
											value: reviewComment,
											onChange: (e) => setReviewComment(e.target.value),
											rows: 2,
											placeholder: "اكتب رأيك الصادق وتجربتك الفعلية في اختبارات التوافق أو المقاييس النفسية...",
											required: true,
											className: "w-full p-3 rounded-xl bg-black/40 border border-white/10 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-rose-400 resize-none"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [reviewSuccess ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-emerald-400 text-xs font-bold",
												children: "✓ تم حفظ ونشر مشاركتك الحقيقية في قاعدة البيانات بنجاح!"
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[11px] text-gray-400",
												children: "تُحفظ المراجعات مباشرة في قاعدة بيانات الموقع بشفافية تامة."
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "submit",
												disabled: isSubmittingReview || !reviewName.trim() || !reviewComment.trim(),
												className: "px-4 py-1.5 rounded-xl bg-gradient-to-r from-rose-600 to-pink-600 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-50",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isSubmittingReview ? "جاري النشر..." : "نشر تجربتي" })]
											})]
										})
									]
								}),
								loadingReviews ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-center py-8 text-xs text-gray-400",
									children: "جاري استرجاع تجارب الزوار الحقيقية من قاعدة البيانات..."
								}) : realReviews.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-6 rounded-2xl bg-white/[0.02] border border-white/10 text-center space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs sm:text-sm font-bold text-white",
										children: "لا توجد تعليقات أو مراجعات منشورة حتى الآن"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-gray-400",
										children: "التزاماً بمصداقية المنصة، لا نعرض أي تعليقات افتراضية أو غير حقيقية. كن أول من يشارك تجربته الحقيقية أعلاه!"
									})]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-3",
									children: realReviews.map((rev) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-4 rounded-2xl bg-white/[0.03] border border-white/10 hover:border-white/20 transition",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between mb-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "w-8 h-8 rounded-full bg-rose-500/20 border border-rose-500/30 flex items-center justify-center text-rose-300 font-bold text-xs",
													children: rev.name.charAt(0)
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
													className: "font-bold text-white text-xs sm:text-sm",
													children: rev.name
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[11px] text-gray-400",
													children: rev.categoryLabelAr || rev.subject
												})] })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex items-center gap-1 text-amber-400 text-xs",
												children: [...Array(rev.rating || 5)].map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "w-3.5 h-3.5 fill-amber-400 text-amber-400" }, i))
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-gray-300 text-xs leading-relaxed",
											children: [
												"\"",
												rev.message,
												"\""
											]
										})]
									}, rev.id))
								})
							]
						}),
						activeTab === "articles" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
							initial: {
								opacity: 0,
								y: 10
							},
							animate: {
								opacity: 1,
								y: 0
							},
							className: "space-y-3",
							children: articles.map((art, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-4 rounded-2xl bg-white/[0.03] border border-white/10 hover:border-rose-500/30 hover:bg-white/[0.05] transition cursor-pointer group",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 mb-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xl",
												children: art.icon
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 text-[10px] font-bold",
												children: art.tag
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-gray-500 text-[10px] mr-auto",
												children: art.readTime
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: "font-bold text-white text-xs sm:text-sm group-hover:text-rose-200 transition mb-1 font-['Alexandria']",
										children: art.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-gray-400 text-xs leading-relaxed",
										children: art.summary
									})
								]
							}, idx))
						}),
						activeTab === "faq" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
							initial: {
								opacity: 0,
								y: 10
							},
							animate: {
								opacity: 1,
								y: 0
							},
							className: "space-y-2.5",
							children: faqs.map((faq, idx) => {
								const isOpen = openFaqIndex === idx;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-2xl bg-white/[0.03] border border-white/10 overflow-hidden transition",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => {
											soundManager.playTap();
											setOpenFaqIndex(isOpen ? null : idx);
										},
										className: "w-full p-3.5 text-right flex items-center justify-between text-xs sm:text-sm font-bold text-gray-200 hover:text-white transition cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleQuestionMark, { className: "w-4 h-4 text-rose-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: faq.q })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `w-4 h-4 text-gray-400 transition-transform duration-200 ${isOpen ? "rotate-180 text-rose-400" : ""}` })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: isOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
										initial: {
											height: 0,
											opacity: 0
										},
										animate: {
											height: "auto",
											opacity: 1
										},
										exit: {
											height: 0,
											opacity: 0
										},
										className: "px-4 pb-3.5 pt-1 text-xs text-gray-300 leading-relaxed border-t border-white/5 bg-black/20",
										children: faq.a
									}) })]
								}, idx);
							})
						}),
						activeTab === "privacy" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
							initial: {
								opacity: 0,
								y: 10
							},
							animate: {
								opacity: 1,
								y: 0
							},
							className: "space-y-4 text-xs sm:text-sm text-gray-300 leading-relaxed",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "font-bold text-emerald-300 text-sm sm:text-base mb-1.5 flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "w-4 h-4 text-emerald-400" }), "ميثاق الأمان وحماية الخصوصية الرقمية"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-gray-300 text-xs leading-relaxed",
									children: "نحن نعتبر خصوصية مشاعرك وإجاباتك أمانة قصوى. تطبق منصة مرآة القلوب معايير الأمان السحابية الرائدة عالمياً لضمان عدم تسريب أي معلومة."
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-200 text-xs font-semibold leading-relaxed",
										children: "«أي معلومات يتم مشاركتها مع الموقع هي واضحة وضمن موافقتك الشخصية، ولا يتم استخدامها، أو المساس بها، أو الإساءة لها، أو بيعها لأي جهات أخرى، وكل شيء يخضع لشروط وسياسة قوقل»."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3 rounded-xl bg-white/[0.03] border border-white/10 flex items-center gap-2.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-4 h-4 text-emerald-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تشفير كامل TLS 1.3 لجميع الاتصالات بين متصفحك وخوادم Google Cloud." })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3 rounded-xl bg-white/[0.03] border border-white/10 flex items-center gap-2.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-4 h-4 text-emerald-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "لا يتم بيع البيانات لأي شبكات إعلانية أو جهات خارجية على الإطلاق." })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3 rounded-xl bg-white/[0.03] border border-white/10 flex items-center gap-2.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-4 h-4 text-emerald-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تخلي المنصة مسؤوليتها عن أي نتائج يقرر المستخدم مشاركتها علناً بإرادته." })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3 rounded-xl bg-white/[0.03] border border-white/10 flex items-center gap-2.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-4 h-4 text-emerald-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "التواصل الرسمي مع إدارة الموقع: one497303@gmail.com (الأردن - عمّان)." })]
									})
								]
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 pt-3.5 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[11px] text-gray-400",
						children: "© 2026 مِـرآة القـلوب • الأردن - عمّان • جميع الحقوق محفوظة."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [onStartQuiz && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								soundManager.playTap();
								onClose();
								onStartQuiz();
							},
							className: "px-4 py-2 rounded-xl bg-gradient-to-r from-rose-500 to-pink-600 hover:from-rose-600 hover:to-pink-700 text-white text-xs font-bold transition active:scale-95 cursor-pointer",
							children: "بدء اختبار شريك الحياة 🔮"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								soundManager.playTap();
								onClose();
							},
							className: "px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition active:scale-95 cursor-pointer",
							children: "إغلاق"
						})]
					})]
				})
			]
		})
	}) });
};
//#endregion
export { WebsiteSectionsModal };
