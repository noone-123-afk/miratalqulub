import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { A as Smartphone, E as SquarePlus, Fn as Apple, I as Share2, mn as CircleCheck, r as X } from "./vendor-icons-WoMClU7U.js";
import { n as AnimatePresence, t as motion } from "./vendor-motion-BS7ODJw7.js";
//#region src/hooks/usePWAInstall.ts
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
function usePWAInstall() {
	const [deferredPrompt, setDeferredPrompt] = (0, import_react.useState)(null);
	const [isInstalled, setIsInstalled] = (0, import_react.useState)(false);
	const [isIOS, setIsIOS] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const isStandalone = window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === true;
		setIsInstalled(isStandalone);
		const userAgent = window.navigator.userAgent.toLowerCase();
		const isIOSDevice = /iphone|ipad|ipod/.test(userAgent);
		setIsIOS(isIOSDevice);
		const handleBeforeInstallPrompt = (e) => {
			e.preventDefault();
			setDeferredPrompt(e);
		};
		const handleAppInstalled = () => {
			setIsInstalled(true);
			setDeferredPrompt(null);
		};
		window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
		window.addEventListener("appinstalled", handleAppInstalled);
		return () => {
			window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
			window.removeEventListener("appinstalled", handleAppInstalled);
		};
	}, []);
	const install = async () => {
		if (!deferredPrompt) return false;
		await deferredPrompt.prompt();
		const { outcome } = await deferredPrompt.userChoice;
		if (outcome === "accepted") {
			setIsInstalled(true);
			setDeferredPrompt(null);
			return true;
		}
		return false;
	};
	return {
		isInstallable: !!deferredPrompt,
		isInstalled,
		isIOS,
		install
	};
}
//#endregion
//#region src/components/PWAInstallModal.tsx
var import_jsx_runtime = require_jsx_runtime();
var PWAInstallModal = ({ isOpen, onClose }) => {
	const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: isOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4",
		dir: "rtl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
			initial: { opacity: 0 },
			animate: { opacity: 1 },
			exit: { opacity: 0 },
			transition: { duration: .2 },
			onClick: onClose,
			className: "fixed inset-0 bg-black/75 backdrop-blur-md"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: {
				opacity: 0,
				scale: .9,
				y: 15
			},
			animate: {
				opacity: 1,
				scale: 1,
				y: 0
			},
			exit: {
				opacity: 0,
				scale: .9,
				y: 15
			},
			transition: {
				type: "spring",
				damping: 25,
				stiffness: 350
			},
			className: "relative w-full max-w-md rounded-3xl glass-panel-glow bg-[#15102a] p-6 text-white shadow-2xl border border-rose-500/30 z-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
					whileHover: { scale: 1.1 },
					whileTap: { scale: .9 },
					onClick: onClose,
					className: "absolute top-4 left-4 p-2 rounded-full bg-white/10 hover:bg-white/20 transition text-gray-300 cursor-pointer",
					"aria-label": "إغلاق",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-5 h-5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center mt-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-16 h-16 mx-auto rounded-2xl bg-gradient-to-tr from-rose-500 to-violet-600 flex items-center justify-center shadow-lg shadow-rose-500/30 mb-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, { className: "w-8 h-8 text-white" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-2xl font-bold text-white mb-2",
							children: "تثبيت التطبيق على هاتفك"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-gray-300 mb-6",
							children: "استمتع بتجربة تطبيق كامل وسريع بدون إنترنت أو متصفح، يعمل مثل تطبيقات الآيفون والأندرويد الرسمية!"
						})
					]
				}),
				isInstalled ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center py-4 bg-emerald-500/20 border border-emerald-500/30 rounded-2xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-10 h-10 text-emerald-400 mx-auto mb-2" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-emerald-300 font-semibold",
						children: "التطبيق مثبت بالفعل على جهازك!"
					})]
				}) : isIOS ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 bg-white/5 rounded-2xl p-4 border border-white/10 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 text-rose-400 font-semibold mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Apple, { className: "w-5 h-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "خطوات التثبيت على أجهزة iPhone و iPad:" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-7 h-7 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center shrink-0 font-bold",
								children: "1"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-gray-200 pt-0.5",
								children: [
									"اضغط على زر ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "text-white",
										children: "المشاركة"
									}),
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "w-4 h-4 inline mx-1 text-sky-400" }),
									" في شريط متصفح سفاري بالأسفل."
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-7 h-7 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center shrink-0 font-bold",
								children: "2"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-gray-200 pt-0.5",
								children: [
									"مرر للأسفل واختر ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "text-white",
										children: "إضافة إلى الصفحة الرئيسية"
									}),
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SquarePlus, { className: "w-4 h-4 inline mx-1 text-emerald-400" }),
									" (Add to Home Screen)."
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-7 h-7 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center shrink-0 font-bold",
								children: "3"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-gray-200 pt-0.5",
								children: [
									"اضغط على ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "text-white",
										children: "إضافة (Add)"
									}),
									" في الزاوية العلوية، وسيظهر التطبيق على شاشة هاتفك فوراً!"
								]
							})]
						})
					]
				}) : isInstallable ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
						whileHover: { scale: 1.02 },
						whileTap: { scale: .98 },
						onClick: async () => {
							await install();
							onClose();
						},
						className: "w-full py-3.5 px-4 rounded-2xl font-bold bg-gradient-to-r from-rose-500 via-pink-500 to-violet-600 hover:opacity-95 text-white shadow-lg shadow-rose-500/30 flex items-center justify-center gap-2 transition cursor-pointer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, { className: "w-5 h-5" }), "تثبيت الآن بنقرة واحدة (Android)"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-center text-gray-400",
						children: "متوافق مع أجهزة سامسونج، شاومي، هواوي، جوجل بيكسل، وغيرها."
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-3 bg-white/5 rounded-2xl p-4 text-xs text-gray-300",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"لتثبيت التطبيق، يمكنك أيضاً الضغط على قائمة المتصفح (نقاط القائمة ⋮) واختيار ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "\"تثبيت التطبيق\"" }),
						" أو ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "\"الإضافة إلى الشاشة الرئيسية\"" }),
						"."
					] })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
					whileHover: { scale: 1.01 },
					whileTap: { scale: .99 },
					onClick: onClose,
					className: "w-full mt-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-gray-300 text-sm font-medium transition cursor-pointer",
					children: "حسناً، فهمت"
				})
			]
		})]
	}) });
};
//#endregion
export { PWAInstallModal };
