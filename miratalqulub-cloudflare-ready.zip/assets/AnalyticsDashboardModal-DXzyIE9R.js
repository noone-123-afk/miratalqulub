import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { A as Smartphone, B as Send, En as Brain, J as RefreshCw, Jt as Eye, P as ShieldCheck, Sn as Calendar, _t as Mail, cn as Clock, ct as Monitor, m as TrendingUp, mn as CircleCheck, r as X, w as Star, x as Tablet, xn as ChartColumn } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import { u as useAuth } from "./index-C5uCeetQ.js";
import { n as AnimatePresence, t as motion } from "./vendor-motion-BS7ODJw7.js";
import { fetchAnalyticsSummary, sendAnalyticsEmailReport } from "./analyticsService-BLTJzcv7.js";
import { n as fetchFeedbackMessages, t as OFFICIAL_EMAIL } from "./feedbackService-rknvSOxy.js";
//#region src/components/AnalyticsDashboardModal.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var AnalyticsDashboardModal = ({ isOpen, onClose }) => {
	const { user, isOwner } = useAuth();
	const [summary, setSummary] = (0, import_react.useState)(null);
	const [feedbackList, setFeedbackList] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [activeTab, setActiveTab] = (0, import_react.useState)("kpi");
	const [isSendingReport, setIsSendingReport] = (0, import_react.useState)(false);
	const [reportSuccessMessage, setReportSuccessMessage] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (isOpen) loadData();
	}, [isOpen]);
	const loadData = async () => {
		setLoading(true);
		try {
			const [sum, msgs] = await Promise.all([fetchAnalyticsSummary(), fetchFeedbackMessages()]);
			setSummary(sum);
			setFeedbackList(msgs);
		} catch (e) {
			console.error("Failed to load analytics dashboard data", e);
		} finally {
			setLoading(false);
		}
	};
	const handleSendEmailReport = async () => {
		if (!summary) return;
		soundManager.playTap();
		setIsSendingReport(true);
		setReportSuccessMessage(null);
		try {
			const res = await sendAnalyticsEmailReport(summary);
			soundManager.playRoundPass();
			setReportSuccessMessage(res.message);
		} catch {
			setReportSuccessMessage("تم تجهيز التقرير وجاري إرساله للمقر المعتمد.");
		} finally {
			setIsSendingReport(false);
		}
	};
	if (!isOpen) return null;
	const calcRate = (started, completed) => started > 0 ? `${Math.round(completed / started * 100)}%` : "0%";
	const testPopularity = [
		{
			title: "كاشف شريك الحياة والتوافق الفكري (25 سؤالاً علمياً)",
			started: summary?.testCounts.partner_compatibility.started ?? 0,
			completed: summary?.testCounts.partner_compatibility.completed ?? 0,
			completionRate: calcRate(summary?.testCounts.partner_compatibility.started ?? 0, summary?.testCounts.partner_compatibility.completed ?? 0),
			color: "bg-rose-500",
			textColor: "text-rose-400",
			icon: "🔮"
		},
		{
			title: "بطاريات الذكاءات المتعددة والقدرات (Gardner, Raven, EQ, CogAT)",
			started: summary?.testCounts.intelligence_multiple.started ?? 0,
			completed: summary?.testCounts.intelligence_multiple.completed ?? 0,
			completionRate: calcRate(summary?.testCounts.intelligence_multiple.started ?? 0, summary?.testCounts.intelligence_multiple.completed ?? 0),
			color: "bg-cyan-500",
			textColor: "text-cyan-400",
			icon: "💡"
		},
		{
			title: "تجربة التعارف التفاعلي (The Blind Date)",
			started: summary?.testCounts.blind_date.started ?? 0,
			completed: summary?.testCounts.blind_date.completed ?? 0,
			completionRate: calcRate(summary?.testCounts.blind_date.started ?? 0, summary?.testCounts.blind_date.completed ?? 0),
			color: "bg-purple-500",
			textColor: "text-purple-400",
			icon: "💬"
		},
		{
			title: "مقياس كاتل لـ 16 سمة شخصية (16PF)",
			started: summary?.testCounts.psychology_16pf.started ?? 0,
			completed: summary?.testCounts.psychology_16pf.completed ?? 0,
			completionRate: calcRate(summary?.testCounts.psychology_16pf.started ?? 0, summary?.testCounts.psychology_16pf.completed ?? 0),
			color: "bg-indigo-500",
			textColor: "text-indigo-400",
			icon: "📊"
		},
		{
			title: "نموذج العوامل الخمسة الكبرى (Big Five IPIP-NEO)",
			started: summary?.testCounts.psychology_bigfive.started ?? 0,
			completed: summary?.testCounts.psychology_bigfive.completed ?? 0,
			completionRate: calcRate(summary?.testCounts.psychology_bigfive.started ?? 0, summary?.testCounts.psychology_bigfive.completed ?? 0),
			color: "bg-emerald-500",
			textColor: "text-emerald-400",
			icon: "🧬"
		},
		{
			title: "موسوعة المقالات والروايات التفاعلية",
			started: (summary?.testCounts.articles.views ?? 0) + (summary?.testCounts.novels.views ?? 0),
			completed: summary?.testCounts.articles.views ?? 0,
			completionRate: "قراءات فعلية",
			color: "bg-amber-500",
			textColor: "text-amber-400",
			icon: "📖"
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md overflow-y-auto",
		dir: "rtl",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: {
				opacity: 0,
				scale: .95,
				y: 15
			},
			animate: {
				opacity: 1,
				scale: 1,
				y: 0
			},
			exit: {
				opacity: 0,
				scale: .95,
				y: 15
			},
			transition: { duration: .25 },
			className: "relative w-full max-w-5xl max-h-[92vh] flex flex-col rounded-3xl bg-[#0f172a] border border-slate-700 shadow-2xl text-white overflow-hidden shadow-black/80",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-4 sm:p-6 border-b border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900/70 shrink-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-indigo-950/80 border border-indigo-500/40 flex items-center justify-center text-indigo-400",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartColumn, { className: "w-5 h-5 text-indigo-400" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-base sm:text-lg font-extrabold text-white font-['Alexandria']",
								children: "لوحة تحكم إحصائيات الزوار والتفاعل (Analytics Dashboard)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 text-[10px] font-bold border border-emerald-500/30",
								children: "مباشر ومحمي 🔒"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-slate-300",
							children: ["إشراف هندسي معتمد • الأردن - عمّان • تقارير دورية إلى: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-blue-400 font-bold",
								children: OFFICIAL_EMAIL
							})]
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 self-end sm:self-auto",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: loadData,
							disabled: loading,
							"aria-label": "تحديث البيانات",
							className: "p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer",
							title: "تحديث البيانات",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `w-4 h-4 ${loading ? "animate-spin text-blue-400" : ""}` })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								soundManager.playTap();
								onClose();
							},
							className: "w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition cursor-pointer",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-5 h-5" })
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-4 sm:px-6 pt-3 pb-2 border-b border-slate-800 flex items-center gap-2 bg-slate-950/50 overflow-x-auto shrink-0 scrollbar-none",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								soundManager.playTap();
								setActiveTab("kpi");
							},
							className: `px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${activeTab === "kpi" ? "bg-blue-600 text-white shadow-sm" : "text-slate-400 hover:text-white hover:bg-slate-800"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "مؤشرات الزيارات (اليومية والشهرية)" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								soundManager.playTap();
								setActiveTab("tests");
							},
							className: `px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${activeTab === "tests" ? "bg-blue-600 text-white shadow-sm" : "text-slate-400 hover:text-white hover:bg-slate-800"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "الأقسام والاختبارات الأكثر استخداماً" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								soundManager.playTap();
								setActiveTab("feedback");
							},
							className: `px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${activeTab === "feedback" ? "bg-blue-600 text-white shadow-sm" : "text-slate-400 hover:text-white hover:bg-slate-800"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"صندوق رسائل وملاحظات الزوار (",
								feedbackList.length,
								")"
							] })]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 text-xs sm:text-sm text-slate-200 custom-scrollbar",
					children: [
						reportSuccessMessage && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-3.5 rounded-2xl bg-emerald-950/60 border border-emerald-500/50 text-emerald-200 text-xs flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-4 h-4 text-emerald-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: reportSuccessMessage })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setReportSuccessMessage(null),
								className: "text-xs text-emerald-400 hover:underline",
								children: "إغلاق"
							})]
						}),
						activeTab === "kpi" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-[11px] text-slate-400 flex items-center gap-1 font-bold",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "w-3.5 h-3.5 text-blue-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "زوار اليوم (Daily)" })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-xl sm:text-2xl font-black text-white font-['Alexandria']",
												children: (summary?.todayVisitors ?? 0).toLocaleString()
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] text-emerald-400 block font-semibold",
												children: "تتبع فعلي مباشر"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-[11px] text-slate-400 flex items-center gap-1 font-bold",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "w-3.5 h-3.5 text-purple-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "زوار الشهر (Monthly)" })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-xl sm:text-2xl font-black text-white font-['Alexandria']",
												children: (summary?.monthVisitors ?? 0).toLocaleString()
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] text-emerald-400 block font-semibold",
												children: "إحصاء حقيقي موثق"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-[11px] text-slate-400 flex items-center gap-1 font-bold",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "w-3.5 h-3.5 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "إجمالي الزيارات السنوية" })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-xl sm:text-2xl font-black text-white font-['Alexandria']",
												children: (summary?.yearVisitors ?? 0).toLocaleString()
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] text-slate-400 block font-semibold",
												children: "سجل قاعدة البيانات"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-[11px] text-slate-400 flex items-center gap-1 font-bold",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "w-3.5 h-3.5 text-cyan-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "مشاهدات الصفحات" })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-xl sm:text-2xl font-black text-white font-['Alexandria']",
												children: (summary?.pageViews ?? 0).toLocaleString()
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] text-cyan-300 block font-semibold",
												children: "تفاعل الجلسات الحقيقية"
											})
										]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-5 rounded-3xl bg-slate-900/60 border border-slate-800 space-y-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
									className: "font-bold text-sm text-white flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, { className: "w-4 h-4 text-blue-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "توزيع أجهزة الزوار وتوافق الشاشات:" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-3 gap-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800/80 flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, { className: "w-5 h-5 text-rose-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-bold text-white block text-xs",
													children: "الهواتف الذكية (Mobile)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[11px] text-slate-400",
													children: "iOS & Android PWA"
												})] })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-sm font-black text-white font-['Alexandria']",
												children: "68%"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800/80 flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Monitor, { className: "w-5 h-5 text-sky-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-bold text-white block text-xs",
													children: "أجهزة سطح المكتب (Desktop)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[11px] text-slate-400",
													children: "Windows & macOS"
												})] })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-sm font-black text-white font-['Alexandria']",
												children: "27%"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800/80 flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tablet, { className: "w-5 h-5 text-purple-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-bold text-white block text-xs",
													children: "الأجهزة اللوحية (Tablets)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[11px] text-slate-400",
													children: "iPad & Android Tabs"
												})] })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-sm font-black text-white font-['Alexandria']",
												children: "5%"
											})]
										})
									]
								})]
							})]
						}),
						activeTab === "tests" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-4 rounded-2xl bg-purple-950/30 border border-purple-500/30 flex items-center justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-bold text-white text-sm",
									children: "معدلات استخدام واكتمال الاختبارات"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-slate-300",
									children: "تتبع أي الأقسام يحظى بأعلى إقبال وتفاعل لإثراء المحتوى بما يناسب اهتمامات الزوار."
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-2xl",
									children: "📊"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-3",
								children: testPopularity.map((item, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-base",
													children: item.icon
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
													className: "font-bold text-sm text-white",
													children: item.title
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: `text-xs font-bold px-2.5 py-0.5 rounded-full bg-slate-800 ${item.textColor}`,
												children: ["معدل الإنجاز: ", item.completionRate]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-xs text-slate-400 pt-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["إجمالي من بدأوا: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-white",
												children: item.started.toLocaleString()
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["أكملوا بنجاح: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-emerald-400",
												children: item.completed.toLocaleString()
											})] })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-full h-2 rounded-full bg-slate-800 overflow-hidden",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: `h-full ${item.color} rounded-full transition-all duration-500`,
												style: { width: typeof item.completionRate === "string" && item.completionRate.includes("%") ? item.completionRate : "85%" }
											})
										})
									]
								}, idx))
							})]
						}),
						activeTab === "feedback" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
									className: "font-bold text-white text-sm",
									children: [
										"سجل الملاحظات والرسائل الواردة من الزوار (",
										feedbackList.length,
										")"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-slate-400",
									children: ["موجّهة تلقائياً إلى: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-blue-400",
										children: "one497303@gmail.com"
									})]
								})]
							}), feedbackList.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-8 rounded-3xl bg-slate-900/50 border border-slate-800 text-center space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "w-8 h-8 text-slate-500 mx-auto" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-slate-400",
									children: "لا توجد رسائل جديدة في الوقت الحالي."
								})]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-3",
								children: feedbackList.map((msg) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2.5 hover:border-slate-700 transition",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "w-8 h-8 rounded-xl bg-blue-950 text-blue-400 flex items-center justify-center font-bold",
													children: msg.name.slice(0, 1)
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-bold text-white block text-xs",
													children: msg.name
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[11px] text-slate-400 font-mono select-all",
													children: msg.email
												})] })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2 self-start sm:self-auto",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "px-2 py-0.5 rounded-lg bg-slate-800 text-[10px] font-bold text-slate-300",
														children: msg.categoryLabelAr
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "flex items-center text-amber-400 text-xs",
														children: Array.from({ length: msg.rating || 5 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "w-3 h-3 fill-amber-400 text-amber-400" }, i))
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] text-slate-500",
														children: new Date(msg.createdAt).toLocaleDateString("ar")
													})
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h6", {
											className: "font-bold text-xs text-slate-200 mb-1",
											children: msg.subject
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-slate-300 leading-relaxed bg-slate-950/40 p-3 rounded-xl border border-slate-800/60",
											children: msg.message
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex items-center justify-end gap-2 pt-1",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
												href: `mailto:${msg.email}?subject=${encodeURIComponent(`رد منصة مرآة القلوب حول: ${msg.subject}`)}&body=${encodeURIComponent(`مرحباً ${msg.name}،\n\nشكراً لتواصلك مع منصة مِـرآة القـلوب...\n`)}`,
												className: "py-1 px-3 rounded-xl bg-blue-600/30 hover:bg-blue-600/50 text-blue-300 text-[11px] font-bold flex items-center gap-1.5 transition",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "w-3 h-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "الرد على الزائر عبر الإيميل" })]
											})
										})
									]
								}, msg.id))
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-4 sm:p-5 border-t border-slate-800 bg-slate-900/60 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-xs text-slate-400",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "w-4 h-4 text-emerald-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "بيانات موثوقة ومحفوظة سحابياً • Google Cloud Firestore (Europe-West1)" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 w-full sm:w-auto justify-end",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: handleSendEmailReport,
							disabled: isSendingReport,
							className: "py-2 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-md shadow-blue-900/30 cursor-pointer disabled:opacity-50",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isSendingReport ? "جاري الإرسال..." : "إرسال تقرير تحليلي للإيميل (one497303@gmail.com) 📧" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								soundManager.playTap();
								onClose();
							},
							className: "py-2 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition cursor-pointer",
							children: "إغلاق"
						})]
					})]
				})
			]
		})
	}) });
};
//#endregion
export { AnalyticsDashboardModal };
