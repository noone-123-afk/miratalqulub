const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/ScientificVisualDashboards-BXG0MudB.js","assets/rolldown-runtime-Bk_YeHJf.js","assets/vendor-react-Bm_EF59R.js","assets/index-C5uCeetQ.js","assets/vendor-icons-WoMClU7U.js","assets/sound-C_zXqyNA.js","assets/react-redux-CuCZtN7g.js","assets/firebase-Cu7XUsbK.js","assets/firebaseAuth-D6LKvzXg.js","assets/index-DMmCvB5f.css","assets/pdfReportGenerator-BNu3pVmt.js","assets/index.es-C20Q95Ms.js"])))=>i.map(i=>d[i]);
import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { n as __vitePreload, o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { B as Send, Ct as Linkedin, D as Sparkles, En as Brain, Gt as FileDown, I as Share2, Jt as Eye, K as RotateCcw, Lt as Globe, Mn as Award, Nt as History, P as ShieldCheck, Pt as Heart, Sn as Calendar, V as Search, Vt as Funnel, an as Compass, b as Target, bn as Check, bt as Lock, et as Plus, ft as MessageCircle, h as Trash2, j as SlidersVertical, l as User, ln as ClipboardCheck, m as TrendingUp, mn as CircleCheck, nt as Phone, p as TriangleAlert, r as X, rn as Copy, rt as PenLine, s as Users, xn as ChartColumn } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import { u as useAuth } from "./index-C5uCeetQ.js";
import { n as AnimatePresence, t as motion } from "./vendor-motion-BS7ODJw7.js";
import { a as loadUserPersonalQuestionnaire, n as QUESTIONNAIRE_OPTIONS, o as saveUserPersonalQuestionnaire, r as calculateMemberPsychometricMatch, t as COMMUNITY_PROFILES } from "./data-compatibility-s3wwWF9Q.js";
import { a as fetchUnifiedTestHistory, c as savePersistentUserProfile, d as saveUserPsychologyReport, f as setPublicProfileStatus, i as fetchPublicCommunityProfiles, r as deleteUnifiedTestRecord, t as buildTemporalEvolutionSummary } from "./userHistoryService-6N9Zh8ed.js";
import { n as calculatePsychometricReport, r as getQuestionsForAssessment } from "./psychologySuiteData-C3h0jv6_.js";
import { _ as Tooltip, d as CartesianGrid, f as Radar, h as PolarGrid, i as LineChart, m as PolarRadiusAxis, n as RadarChart, o as YAxis, p as PolarAngleAxis, s as XAxis, u as Line, v as Legend, y as ResponsiveContainer } from "./vendor-charts-Z9-zx-pq.js";
import { t as SkeletonLoader } from "./SkeletonLoader-Dpq6Gy3u.js";
//#region src/components/UserProfileDashboard.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var LazyScientificVisualDashboards = (0, import_react.lazy)(() => __vitePreload(() => import("./ScientificVisualDashboards-BXG0MudB.js").then((m) => ({ default: m.ScientificVisualDashboards })), __vite__mapDeps([0,1,2,3,4,5,6,7,8,9])));
function openExternalShareUrl(url) {
	const a = document.createElement("a");
	a.href = url;
	a.target = "_blank";
	a.rel = "noopener noreferrer";
	document.body.appendChild(a);
	a.click();
	document.body.removeChild(a);
}
var UserProfileDashboard = ({ isOpen, onClose, profile, result, onOpenPsychologyTests, onOpenIntelligenceTest, onOpenCoupleInvite, onOpenLiveChat, onProfileUpdated, initialTab = "overview" }) => {
	const { user } = useAuth();
	const [isPublic, setIsPublic] = (0, import_react.useState)(() => {
		try {
			return localStorage.getItem("is_user_public_profile") === "true";
		} catch {
			return false;
		}
	});
	const [whatsappContact, setWhatsappContact] = (0, import_react.useState)(() => {
		try {
			return localStorage.getItem("user_contact_whatsapp") || "";
		} catch {
			return "";
		}
	});
	const [copiedLink, setCopiedLink] = (0, import_react.useState)(false);
	const [activeTab, setActiveTab] = (0, import_react.useState)(initialTab);
	const [matchFilter, setMatchFilter] = (0, import_react.useState)("all");
	const [genderFilter, setGenderFilter] = (0, import_react.useState)("all");
	const [matchSearchQuery, setMatchSearchQuery] = (0, import_react.useState)("");
	const [selectedMemberToCompare, setSelectedMemberToCompare] = (0, import_react.useState)(null);
	const [rawCommunityMembers, setRawCommunityMembers] = (0, import_react.useState)(COMMUNITY_PROFILES);
	const [testHistory, setTestHistory] = (0, import_react.useState)([]);
	const [loadingHistory, setLoadingHistory] = (0, import_react.useState)(false);
	const [historyFilter, setHistoryFilter] = (0, import_react.useState)("all");
	const [historyTierFilter, setHistoryTierFilter] = (0, import_react.useState)("all");
	const [historySearchQuery, setHistorySearchQuery] = (0, import_react.useState)("");
	const [reopenedRecord, setReopenedRecord] = (0, import_react.useState)(null);
	const [deletingId, setDeletingId] = (0, import_react.useState)(null);
	const [report, setReport] = (0, import_react.useState)(() => {
		try {
			const cached = localStorage.getItem("latest_psychology_report");
			if (cached) return JSON.parse(cached);
		} catch {}
		return calculatePsychometricReport("big_five", {}, profile?.userName || "المستخدم");
	});
	const [cattellReport, setCattellReport] = (0, import_react.useState)(() => {
		try {
			const cached16 = localStorage.getItem("psychology_report_sixteen_pf");
			if (cached16) return JSON.parse(cached16);
		} catch {}
		return calculatePsychometricReport("sixteen_pf", {}, profile?.userName || "المستخدم");
	});
	const [isTaking16PFInline, setIsTaking16PFInline] = (0, import_react.useState)(false);
	const [inline16PFAnswers, setInline16PFAnswers] = (0, import_react.useState)({});
	const [cattellViewMode, setCattellViewMode] = (0, import_react.useState)("all16");
	const [inline16PFMissing, setInline16PFMissing] = (0, import_react.useState)([]);
	const [questionnaire, setQuestionnaire] = (0, import_react.useState)(() => loadUserPersonalQuestionnaire(profile, null));
	const [questionnaireSavedToast, setQuestionnaireSavedToast] = (0, import_react.useState)(false);
	const [customStrengthInput, setCustomStrengthInput] = (0, import_react.useState)("");
	const [customInterestInput, setCustomInterestInput] = (0, import_react.useState)("");
	const [customAspirationInput, setCustomAspirationInput] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (!isOpen) return;
		let latestRep = null;
		try {
			const cached = localStorage.getItem("latest_psychology_report");
			if (cached) {
				latestRep = JSON.parse(cached);
				if (latestRep) setReport(latestRep);
			}
			const cached16 = localStorage.getItem("psychology_report_sixteen_pf");
			if (cached16) {
				const parsed16 = JSON.parse(cached16);
				if (parsed16) setCattellReport(parsed16);
			}
		} catch {}
		setQuestionnaire(loadUserPersonalQuestionnaire(profile, latestRep));
	}, [isOpen, profile]);
	(0, import_react.useEffect)(() => {
		if (initialTab) setActiveTab(initialTab);
	}, [initialTab]);
	(0, import_react.useEffect)(() => {
		if (!isOpen) return;
		fetchPublicCommunityProfiles().then((realList) => {
			setRawCommunityMembers(realList);
		});
		const loadHistory = async () => {
			setLoadingHistory(true);
			try {
				const records = await fetchUnifiedTestHistory(user);
				setTestHistory(records);
			} catch (e) {
				console.warn("Could not load test history", e);
			} finally {
				setLoadingHistory(false);
			}
		};
		loadHistory();
	}, [
		isOpen,
		activeTab,
		user
	]);
	if (!isOpen) return null;
	const userName = questionnaire.fullName?.trim() || profile?.userName || user?.displayName || "المستخدم";
	const userAge = questionnaire.userAge || profile?.userAge || 26;
	const userGender = questionnaire.userGender || profile?.userGender || "male";
	const country = questionnaire.country || profile?.country || "المملكة العربية السعودية";
	const city = questionnaire.city?.trim() || country;
	const effectiveStrengths = [
		...questionnaire.selectedStrengths,
		...questionnaire.customStrengths,
		...questionnaire.stressResponseStyle ? [`أسلوب إدارة الضغوط: ${questionnaire.stressResponseStyle}`] : [],
		...questionnaire.decisionMakingStyle ? [`منهجية اتخاذ القرار: ${questionnaire.decisionMakingStyle}`] : [],
		...report.isCompleted ? report.userStrengthsAr.slice(0, 3) : [],
		...cattellReport.isCompleted ? cattellReport.userStrengthsAr.slice(0, 2) : []
	].filter((v, i, arr) => Boolean(v) && arr.indexOf(v) === i);
	const effectiveInterests = [
		...questionnaire.selectedInterests,
		...questionnaire.customInterests,
		...questionnaire.intellectualPassion ? [`الشغف المعرفي والفكري: ${questionnaire.intellectualPassion}`] : [],
		...questionnaire.weekendRoutinePreference ? [`نمط قضاء الأوقات اليومية والإجازات: ${questionnaire.weekendRoutinePreference}`] : [],
		...report.isCompleted ? report.userInterestsAr.slice(0, 2) : []
	].filter((v, i, arr) => Boolean(v) && arr.indexOf(v) === i);
	const effectiveAspirations = [
		...questionnaire.selectedMaritalAspirations,
		...questionnaire.customMaritalAspirations,
		...questionnaire.maritalHomeAtmosphere ? [`أجواء البيت الزوجي المنشودة: ${questionnaire.maritalHomeAtmosphere}`] : [],
		...questionnaire.financialManagementVision ? [`الرؤية المالية للأسرة: ${questionnaire.financialManagementVision}`] : [],
		...questionnaire.conflictResolutionProtocol ? [`منهجية حل الخلافات الزوجية: ${questionnaire.conflictResolutionProtocol}`] : [],
		...questionnaire.parentingAndFamilyVision ? [`الرؤية التربوية والأسرية: ${questionnaire.parentingAndFamilyVision}`] : [],
		...questionnaire.primaryLoveLanguage ? [`لغة الحب والتقدير الأساسية: ${questionnaire.primaryLoveLanguage}`] : []
	].filter((v, i, arr) => Boolean(v) && arr.indexOf(v) === i);
	const getCore5Dimensions = () => {
		const activeRep = cattellReport.isCompleted ? cattellReport : report;
		const findS = (keys, fb) => {
			for (const k of keys) {
				const d = activeRep.dimensionScores.find((x) => x.key === k);
				if (d) return d.score;
			}
			if (activeRep.cattellGlobalFactors) for (const k of keys) {
				const g = activeRep.cattellGlobalFactors.find((x) => x.key === k);
				if (g) return g.score;
			}
			return fb;
		};
		return {
			extraversion: findS([
				"extraversion",
				"global_extraversion",
				"eysenck_extraversion",
				"warmth"
			], 72),
			emotionalStability: findS([
				"emotional_stability",
				"global_stability",
				"eysenck_stability",
				"stability"
			], 78),
			openness: findS([
				"openness",
				"global_sensitivity",
				"openness_to_change",
				"reasoning"
			], 80),
			agreeableness: findS([
				"agreeableness",
				"eysenck_empathy",
				"warmth",
				"social_empathy"
			], 84),
			conscientiousness: findS([
				"conscientiousness",
				"global_self_control",
				"rule_consciousness",
				"perfectionism"
			], 82)
		};
	};
	const handleSaveQuestionnaire = async () => {
		soundManager.playRoundPass();
		saveUserPersonalQuestionnaire(questionnaire);
		setQuestionnaire((prev) => ({
			...prev,
			isCompleted: true
		}));
		setQuestionnaireSavedToast(true);
		setTimeout(() => setQuestionnaireSavedToast(false), 3500);
		const updatedProfile = {
			userGender: questionnaire.userGender,
			partnerGender: questionnaire.userGender === "male" ? "female" : "male",
			userAge: questionnaire.userAge,
			country: questionnaire.country,
			ethnicity: profile?.ethnicity || "عربي",
			educationLevel: questionnaire.educationAndCareer,
			lifestyleOutlook: questionnaire.maritalHomeAtmosphere,
			partnerFeaturesPreference: questionnaire.partnerCorePersonalityType,
			userName: questionnaire.fullName || profile?.userName,
			userBirthDate: profile?.userBirthDate
		};
		await savePersistentUserProfile(updatedProfile, user);
		if (onProfileUpdated) onProfileUpdated(updatedProfile);
		if (isPublic) await setPublicProfileStatus(user, true, {
			displayName: userName,
			userGender,
			userAge,
			country,
			city,
			archetype: cattellReport.isCompleted ? cattellReport.primaryArchetypeAr : report.primaryArchetypeAr,
			contactWhatsapp: whatsappContact,
			bio: questionnaire.personalBio,
			strengths: effectiveStrengths.slice(0, 6),
			interests: effectiveInterests.slice(0, 6),
			aspirations: effectiveAspirations.slice(0, 6),
			idealPartnerNeeds: questionnaire.partnerEmotionalNeedsFromThem,
			communicationStyle: questionnaire.partnerCommunicationPreference,
			dimensionScores: getCore5Dimensions()
		});
	};
	const sixteenPFQuestions = getQuestionsForAssessment("sixteen_pf");
	const handleCompleteInline16PF = async () => {
		const missing = [];
		sixteenPFQuestions.forEach((q, idx) => {
			if (!inline16PFAnswers[q.id]) missing.push(idx);
		});
		if (missing.length > 0) {
			soundManager.playTap();
			setInline16PFMissing(missing);
			return;
		}
		setInline16PFMissing([]);
		const new16Report = calculatePsychometricReport("sixteen_pf", inline16PFAnswers, userName);
		soundManager.playRoundPass();
		setCattellReport(new16Report);
		setReport(new16Report);
		setIsTaking16PFInline(false);
		await saveUserPsychologyReport(user, new16Report, profile);
		const updatedRecords = await fetchUnifiedTestHistory(user);
		setTestHistory(updatedRecords);
	};
	const handleExportFullDashboardPDF = async () => {
		soundManager.playTap();
		const { exportPsychometricReportAsPDF } = await __vitePreload(async () => {
			const { exportPsychometricReportAsPDF } = await import("./pdfReportGenerator-BNu3pVmt.js");
			return { exportPsychometricReportAsPDF };
		}, __vite__mapDeps([10,3,1,2,4,5,11,7,8,9]));
		const activeRep = cattellReport.isCompleted ? cattellReport : report;
		exportPsychometricReportAsPDF({
			reportTitle: `الملف الشخصي السيكومتري والزوجي الشامل — ${userName}`,
			subTitle: "Comprehensive Psychometric, 16PF & Marital Compatibility Dossier",
			scientificBasis: "مبني على إجابات المستخدم الفعلية، مقياس كاتل للعوامل الـ 16 (16PF)، العوامل الخمسة الكبرى (Big Five)، ونظرية غوتمان وبولبي للتوافق الزوجي",
			userName: `${userName} (${userAge} سنة • ${country})`,
			completedAt: (/* @__PURE__ */ new Date()).toLocaleDateString("ar-JO"),
			overallScoreLabel: "مؤشر النضج والاتزان السيكومتري العام",
			overallScoreValue: `${activeRep.totalScore}% (المئين ${activeRep.overallPercentile}%)`,
			cognitiveFingerprintTitle: activeRep.primaryArchetypeAr,
			executiveSummary: `${questionnaire.personalBio ? `النبذة الشخصية: ${questionnaire.personalBio} — ` : ""}${activeRep.summaryAr || activeRep.validityMessageAr}`,
			metrics: cattellReport.dimensionScores.map((d) => ({
				label: d.factorCode ? `[${d.factorCode}] ${d.labelAr}` : d.labelAr,
				scorePercent: d.score,
				levelLabel: d.stenScore ? `${d.levelAr} (Sten ${d.stenScore}/10)` : d.levelAr,
				rawText: d.plainExplanationAr ? `${d.plainExplanationAr} — ${d.analysisAr}` : d.analysisAr,
				color: d.color || "#8b5cf6"
			})),
			sections: [
				{
					title: "1. صفاتي ونقاط قوتي السلوكية (Behavioral Strengths)",
					badge: "من إجاباتك الشخصية والسيكومترية",
					content: `المستوى التعليمي والمهني: ${questionnaire.educationAndCareer || "غير محدد"} | أسلوب إدارة الضغوط: ${questionnaire.stressResponseStyle}`,
					items: effectiveStrengths
				},
				{
					title: "2. اهتماماتي وشغفي اليومي (Daily Interests & Passions)",
					badge: "نمط الحياة والشغف المعرفي",
					content: `الشغف الفكري: ${questionnaire.intellectualPassion} | روتين نهاية الأسبوع: ${questionnaire.weekendRoutinePreference}`,
					items: effectiveInterests
				},
				{
					title: "3. تطلعاتي المستقبلية للعش الزوجي (Marital Nest Vision)",
					badge: "رؤية الأسرة والحوار والمالية",
					content: `لغة الحب الأساسية: ${questionnaire.primaryLoveLanguage}`,
					items: effectiveAspirations
				},
				{
					title: "4. مواصفات شريك الحياة المناسب (Ideal Life Partner Profile)",
					badge: questionnaire.partnerCorePersonalityType,
					content: `الاحتياجات العاطفية: ${questionnaire.partnerEmotionalNeedsFromThem} — أسلوب الحوار المفضل: ${questionnaire.partnerCommunicationPreference}`,
					items: [
						`الفئة العمرية المفضلة للشريك: ${questionnaire.preferredPartnerAgeRange}`,
						...questionnaire.partnerEssentialTraits.map((t) => `صفة أساسية مطلوبة: ${t}`),
						...questionnaire.partnerGreenFlags.map((g) => `مؤشر توافق إيجابي (Green Flag): ${g}`),
						...questionnaire.partnerRedFlags.map((r) => `مؤشر تنافر مرفوض (Red Flag): ${r}`)
					]
				},
				...cattellReport.cattellGlobalFactors ? [{
					title: "5. العوامل العالمية الخمسة الكبرى في مقياس كاتل (16PF Global Factors)",
					badge: "Raymond Cattell 16PF",
					content: "الخلاصة العاملية المبسطة لغير المختصين:",
					items: cattellReport.cattellGlobalFactors.map((gf) => `${gf.labelAr} (${gf.score}% • Sten ${gf.sten}/10): ${gf.plainExplanationAr}`)
				}] : []
			],
			careersOrRecommendations: cattellReport.userAspirationsAr || report.userAspirationsAr || [],
			questionAudit: (activeRep.questionAudit || []).map((qa) => ({
				questionNumber: qa.questionNumber,
				questionText: qa.promptAr,
				userAnswer: qa.selectedOptionAr,
				correctAnswerOrTrait: `${qa.traitMeasuredAr} (${qa.scientificTraitEn})`,
				isCorrectOrHigh: qa.scoreWeight >= 3,
				pointsEarned: `${qa.scoreWeight}/${qa.maxWeight}`
			}))
		});
	};
	const handleDownloadHistoryRecordPDF = async (rec) => {
		soundManager.playTap();
		const { exportPsychometricReportAsPDF } = await __vitePreload(async () => {
			const { exportPsychometricReportAsPDF } = await import("./pdfReportGenerator-BNu3pVmt.js");
			return { exportPsychometricReportAsPDF };
		}, __vite__mapDeps([10,3,1,2,4,5,11,7,8,9]));
		const snap = rec.snapshot;
		if (rec.testType === "tiered_assessment" && snap && snap.subscales) {
			exportPsychometricReportAsPDF({
				reportTitle: `${snap.tierTitleAr || rec.testTitleAr} — سجل تقاريري`,
				subTitle: `${snap.archetypeTitleAr || rec.scoreOrArchetype}`,
				scientificBasis: (snap.scientificReferences || []).join(" • ") || "النماذج السيكومترية الثمانية",
				userName: snap.userName || userName,
				completedAt: new Date(rec.createdAt).toLocaleDateString("ar-JO"),
				overallScoreLabel: "مؤشر النضج السيكومتري",
				overallScoreValue: `${snap.overallMaturityIndex || rec.percentage}%`,
				cognitiveFingerprintTitle: `اتساق ${snap.consistencyIndex || 90}% • المئين ${snap.overallPercentile || rec.percentage}%`,
				executiveSummary: snap.executiveSummaryAr || rec.testCategoryAr,
				metrics: (snap.subscales || []).slice(0, 14).map((s) => ({
					label: s.labelAr,
					scorePercent: s.percentage,
					levelLabel: `Sten ${s.stenScore}/10`,
					rawText: s.interpretationAr,
					color: s.color || "#8b5cf6"
				})),
				sections: [
					{
						title: "بنية الشخصية والتحليل النوعي",
						content: `${snap.personalityDescriptionAr || ""} ${snap.communicationStyleAr || ""}`,
						items: snap.strengthsAr || rec.keyInsights || []
					},
					...snap.thinkingStyleAnalysisAr ? [{
						title: "نمط التفكير واتخاذ القرار والتعلق",
						content: `${snap.thinkingStyleAnalysisAr} ${snap.attachmentAnalysisAr || ""}`
					}] : [],
					...snap.valuesAndBeliefsAr ? [{
						title: "الملف الاحترافي طويل الأمد",
						content: `${snap.valuesAndBeliefsAr} ${snap.longTermMaritalCompatibilityAr || ""}`
					}] : []
				],
				careersOrRecommendations: snap.improvementAreasAr || rec.keyInsights || [],
				disclaimerText: snap.scientificDisclaimerAr,
				visualCharts: snap.visualCharts
			});
			return;
		}
		if (rec.testType === "personality_comparison" && snap && snap.nineAxesBreakdown) {
			exportPsychometricReportAsPDF({
				reportTitle: rec.testTitleAr,
				subTitle: snap.compatibilityClassificationAr || "مقارنة شخصيتين علمياً",
				scientificBasis: (snap.scientificReferences || []).join(" • "),
				userName: `${snap.personA?.personName || ""} ✕ ${snap.personB?.personName || ""}`,
				completedAt: new Date(rec.createdAt).toLocaleDateString("ar-JO"),
				overallScoreLabel: "التوافق الموزون الكلي",
				overallScoreValue: `${snap.overallWeightedCompatibility || rec.percentage}%`,
				cognitiveFingerprintTitle: "مقارنة 9 محاور سيكومترية و6 مؤشرات توافقية",
				executiveSummary: snap.executiveSummaryAr || rec.scoreOrArchetype,
				metrics: (snap.subIndices || []).map((sub) => ({
					label: sub.titleAr,
					scorePercent: sub.score,
					levelLabel: `وزن ${Math.round((sub.weight || .16) * 100)}%`,
					rawText: sub.interpretationAr,
					color: "#059669"
				})),
				sections: (snap.nineAxesBreakdown || []).map((ax) => ({
					title: ax.axisNameAr,
					badge: `توافق ${ax.matchScore}%`,
					content: ax.scientificNoteAr
				})),
				careersOrRecommendations: [...snap.sharedStrengthsAr || [], ...snap.growthRecommendationsAr || []],
				comparisonDualRadar: {
					personAName: snap.personA?.personName || "الشخص الأول",
					personBName: snap.personB?.personName || "الشخص الثاني",
					axes: snap.nineAxesBreakdown
				}
			});
			return;
		}
		if (rec.testType === "psychology" && snap && snap.dimensionScores) {
			exportPsychometricReportAsPDF({
				reportTitle: snap.testTitleAr || rec.testTitleAr,
				subTitle: "Psychometric Assessment Report",
				scientificBasis: "مختبر المقاييس النفسية والسيكومترية المعتمد",
				userName,
				completedAt: new Date(rec.createdAt).toLocaleDateString("ar-JO"),
				overallScoreLabel: "النتيجة الكلية والنمط السيكومتري",
				overallScoreValue: `${rec.percentage}% — ${rec.scoreOrArchetype}`,
				cognitiveFingerprintTitle: snap.primaryArchetypeAr || rec.scoreOrArchetype,
				executiveSummary: snap.summaryAr || snap.validityMessageAr || rec.testCategoryAr,
				metrics: (snap.dimensionScores || []).map((d) => ({
					label: d.factorCode ? `[${d.factorCode}] ${d.labelAr}` : d.labelAr,
					scorePercent: d.score || 75,
					levelLabel: d.stenScore ? `${d.levelAr} (Sten ${d.stenScore}/10)` : d.levelAr || "متوازن",
					rawText: d.plainExplanationAr ? `${d.plainExplanationAr} — ${d.analysisAr}` : d.analysisAr || "",
					color: d.color || "#8b5cf6"
				})),
				sections: [...snap.userStrengthsAr?.length ? [{
					title: "نقاط القوة المرصودة في هذا الاختبار",
					content: "السمات البارزة وفق إجاباتك:",
					items: snap.userStrengthsAr
				}] : []],
				careersOrRecommendations: snap.userAspirationsAr || rec.keyInsights || []
			});
			return;
		}
		if (rec.testType === "intelligence" && snap) {
			exportPsychometricReportAsPDF({
				reportTitle: rec.testTitleAr,
				subTitle: "Standardized Intelligence & Cognitive Battery Report",
				scientificBasis: snap.scientificBasisAr || "مختبر القياس العقلي والمعرفي المعتمد",
				userName,
				completedAt: new Date(rec.createdAt).toLocaleDateString("ar-JO"),
				overallScoreLabel: "الدرجة المعيارية والترتيب المئيني",
				overallScoreValue: rec.scoreOrArchetype,
				cognitiveFingerprintTitle: snap.cognitiveFingerprintTitle || rec.testTitleAr,
				executiveSummary: snap.executiveSummary || snap.cognitiveFingerprintSummary || rec.testCategoryAr,
				metrics: (snap.allScores || snap.subScales || []).map((s) => ({
					label: s.titleAr || s.labelAr || "بعد معرفي",
					scorePercent: s.percentage || s.score || rec.percentage,
					levelLabel: s.levelLabel || "متميز",
					rawText: s.descriptionAr || s.analysisAr || "",
					color: s.color || "#3b82f6"
				})),
				sections: [{
					title: "أبرز المؤشرات المعرفية المرصودة",
					content: "خلاصة الأداء العقلي والمعرفي في هذا الاختبار:",
					items: rec.keyInsights || []
				}],
				careersOrRecommendations: snap.topStrengths?.[0]?.careersAr || rec.keyInsights || []
			});
			return;
		}
		exportPsychometricReportAsPDF({
			reportTitle: rec.testTitleAr,
			subTitle: rec.testCategoryAr,
			scientificBasis: "منظومة التوافق السيكومتري والاجتماعي المعتمدة",
			userName,
			completedAt: new Date(rec.createdAt).toLocaleDateString("ar-JO"),
			overallScoreLabel: "نسبة التوافق الكلية",
			overallScoreValue: `${rec.percentage}% (${rec.scoreOrArchetype})`,
			cognitiveFingerprintTitle: rec.scoreOrArchetype,
			executiveSummary: snap?.romanticAdvice || snap?.detailedMatchReason || `تقرير توافق محفوظ بتاريخ ${new Date(rec.createdAt).toLocaleDateString("ar-JO")}.`,
			metrics: [
				{
					label: "التوافق الفكري والمعرفي",
					scorePercent: snap?.intellectualScore || rec.percentage,
					levelLabel: "مرتفع",
					rawText: "انسجام في الرؤى وطريقة اتخاذ القرارات المشتركة.",
					color: "#3b82f6"
				},
				{
					label: "التوافق الاجتماعي والقيمي",
					scorePercent: snap?.sociologicalScore || rec.percentage,
					levelLabel: "مرتفع",
					rawText: "توافق في العادات والتقاليد والروابط الأسرية.",
					color: "#10b981"
				},
				{
					label: "الذكاء العاطفي والاستقرار",
					scorePercent: snap?.emotionalScore || rec.percentage,
					levelLabel: "مرتفع",
					rawText: "قدرة على الاحتواء الوجداني وحل الخلافات بمودة.",
					color: "#f43f5e"
				},
				{
					label: "انسجام نمط الحياة والأهداف",
					scorePercent: snap?.lifestyleScore || rec.percentage,
					levelLabel: "مرتفع",
					rawText: "تقارب في إدارة الحياة اليومية والتطلعات المستقبلية.",
					color: "#a855f7"
				}
			],
			sections: [{
				title: "أبرز السمات والمؤشرات المسجلة",
				content: snap?.partnerVibeQuote || "مؤشرات التوافق:",
				items: rec.keyInsights || snap?.partnerTraits || []
			}]
		});
	};
	const handleDeleteHistoryItem = async (recordId) => {
		soundManager.playTap();
		setDeletingId(recordId);
		try {
			await deleteUnifiedTestRecord(user, recordId);
			setTestHistory((prev) => prev.filter((r) => r.id !== recordId));
		} catch (err) {
			console.warn("Failed to delete history record", err);
		} finally {
			setDeletingId(null);
		}
	};
	const handleTogglePublic = async (newVal) => {
		soundManager.playTap();
		setIsPublic(newVal);
		try {
			localStorage.setItem("is_user_public_profile", newVal ? "true" : "false");
		} catch {}
		await setPublicProfileStatus(user, newVal, {
			displayName: userName,
			userGender,
			userAge,
			country,
			city,
			archetype: cattellReport.isCompleted ? cattellReport.primaryArchetypeAr : report.primaryArchetypeAr,
			contactWhatsapp: whatsappContact,
			bio: questionnaire.personalBio,
			strengths: effectiveStrengths.slice(0, 6),
			interests: effectiveInterests.slice(0, 6),
			aspirations: effectiveAspirations.slice(0, 6),
			idealPartnerNeeds: questionnaire.partnerEmotionalNeedsFromThem,
			communicationStyle: questionnaire.partnerCommunicationPreference,
			dimensionScores: getCore5Dimensions()
		});
	};
	const handleSaveWhatsapp = async () => {
		soundManager.playTap();
		try {
			localStorage.setItem("user_contact_whatsapp", whatsappContact);
		} catch {}
		if (isPublic) await setPublicProfileStatus(user, true, {
			displayName: userName,
			userGender,
			userAge,
			country,
			city,
			archetype: cattellReport.isCompleted ? cattellReport.primaryArchetypeAr : report.primaryArchetypeAr,
			contactWhatsapp: whatsappContact,
			bio: questionnaire.personalBio,
			strengths: effectiveStrengths.slice(0, 6),
			interests: effectiveInterests.slice(0, 6),
			aspirations: effectiveAspirations.slice(0, 6),
			idealPartnerNeeds: questionnaire.partnerEmotionalNeedsFromThem,
			communicationStyle: questionnaire.partnerCommunicationPreference,
			dimensionScores: getCore5Dimensions()
		});
	};
	const publicProfileUrl = `${typeof window !== "undefined" ? window.location.origin : "https://miratalqulub.com"}/?publicProfile=${encodeURIComponent(userName)}&country=${encodeURIComponent(country)}&archetype=${encodeURIComponent(cattellReport.isCompleted ? cattellReport.primaryArchetypeAr : report.primaryArchetypeAr)}`;
	const shareText = `🔮 تفضل بالاطلاع على ملفي السيكومتري المعتمد ومواصفات شريكي المناسب على منصة «مِرآة القلوب»:\n\n👤 الاسم: ${userName}\n👑 النمط النفسي: ${cattellReport.isCompleted ? cattellReport.primaryArchetypeAr : report.primaryArchetypeAr}\n🌍 البلد: ${country}\n\nتصفح ملفي واكتشف مدى توافقنا للتواصل:\n${publicProfileUrl}`;
	const handleCopyLink = () => {
		soundManager.playTap();
		navigator.clipboard.writeText(publicProfileUrl);
		setCopiedLink(true);
		setTimeout(() => setCopiedLink(false), 3e3);
	};
	const activeRadarSource = cattellReport.isCompleted ? cattellReport.cattellGlobalFactors?.map((g) => ({
		subject: g.labelAr.split(":")[1]?.split("(")[0]?.trim() || g.labelAr,
		score: g.score,
		fullMark: 100
	})) || [] : report.dimensionScores.map((dim) => ({
		subject: dim.labelAr.split("(")[0].trim(),
		score: dim.score,
		fullMark: 100
	}));
	const activeMatchingReport = cattellReport.isCompleted ? cattellReport : report;
	const computedCommunityMembers = rawCommunityMembers.map((m) => calculateMemberPsychometricMatch(m, activeMatchingReport, questionnaire)).sort((a, b) => b.compatibilityScore - a.compatibilityScore);
	const filteredMembers = computedCommunityMembers.filter((m) => {
		if (matchFilter === "complementary" && m.category !== "complementary" && m.category !== "both") return false;
		if (matchFilter === "similar" && m.category !== "similar" && m.category !== "both") return false;
		if (genderFilter !== "all" && m.userGender !== genderFilter) return false;
		if (matchSearchQuery.trim()) {
			const q = matchSearchQuery.trim().toLowerCase();
			if (!`${m.displayName} ${m.country} ${m.city} ${m.archetype} ${m.interests.join(" ")} ${m.strengths.join(" ")}`.toLowerCase().includes(q)) return false;
		}
		return true;
	});
	const toggleArrayItem = (list, item) => {
		if (list.includes(item)) return list.filter((x) => x !== item);
		return [...list, item];
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: {
				opacity: 0,
				scale: .95,
				y: 15
			},
			animate: {
				opacity: 1,
				scale: 1,
				y: 0
			},
			exit: {
				opacity: 0,
				scale: .95,
				y: 15
			},
			className: "glass-panel w-full max-w-5xl rounded-3xl p-4 sm:p-6 border border-white/20 shadow-2xl relative my-auto text-right max-h-[94vh] flex flex-col overflow-hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3 pb-3.5 mb-3 border-b border-white/10 shrink-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-11 h-11 rounded-2xl bg-gradient-to-tr from-purple-500 via-pink-500 to-rose-500 p-0.5 shadow-lg shadow-purple-500/25 flex items-center justify-center shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-full h-full bg-[#120d24] rounded-[14px] flex items-center justify-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "w-6 h-6 text-purple-400" })
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 flex-wrap",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-extrabold text-base sm:text-xl text-white font-['Alexandria']",
								children: "لوحة الملف الشخصي السيكومتري (UserProfileDashboard)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30",
								children: "مبني على إجاباتك الحقيقية + PDF مفعل 🔬"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-gray-300",
							children: "صفاتك السلوكية، اهتماماتك اليومية، تطلعات العش الزوجي، مقياس كاتل (16PF)، وشبكة المتوافقين للتواصل"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: handleExportFullDashboardPDF,
							className: "px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs transition flex items-center gap-1.5 cursor-pointer shadow-md",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileDown, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تحميل الملف السيكومتري الشامل PDF 📄" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								soundManager.playTap();
								onClose();
							},
							className: "p-2 rounded-full bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white transition cursor-pointer",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-5 h-5" })
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1.5 p-1 rounded-2xl bg-black/40 border border-white/10 mb-4 shrink-0 overflow-x-auto text-xs font-bold scrollbar-none",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundManager.playTab();
								setActiveTab("overview");
							},
							className: `flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition cursor-pointer shrink-0 ${activeTab === "overview" ? "bg-purple-600 text-white shadow-md" : "text-gray-400 hover:text-white"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "سماتي، اهتماماتي وتطلعاتي" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundManager.playTab();
								setActiveTab("questionnaire");
							},
							className: `flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition cursor-pointer shrink-0 ${activeTab === "questionnaire" ? "bg-amber-500 text-slate-950 font-extrabold shadow-md" : "text-amber-300 hover:text-white bg-amber-500/10 border border-amber-500/30"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "استبيان بياناتي وتطلعاتي ✍️" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundManager.playTab();
								setActiveTab("cattell_16pf");
							},
							className: `flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition cursor-pointer shrink-0 ${activeTab === "cattell_16pf" ? "bg-indigo-600 text-white shadow-md" : "text-indigo-300 hover:text-white bg-indigo-500/10 border border-indigo-500/20"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersVertical, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "مقياس كاتل لـ 16 سمة (16PF) 📊" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundManager.playTab();
								setActiveTab("partner");
							},
							className: `flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition cursor-pointer shrink-0 ${activeTab === "partner" ? "bg-gradient-to-r from-rose-500 to-pink-600 text-white shadow-md" : "text-gray-400 hover:text-white"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "شريك حياتي المناسب 💖" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundManager.playTab();
								setActiveTab("matches");
							},
							className: `flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition cursor-pointer shrink-0 ${activeTab === "matches" ? "bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-md" : "text-gray-400 hover:text-white"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "اكتشف من يشبهك أو يتوافق معك للتواصل 🤝" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundManager.playTab();
								setActiveTab("history");
							},
							className: `flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition cursor-pointer shrink-0 ${activeTab === "history" ? "bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md" : "text-gray-400 hover:text-white"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "سجل وتطور اختباراتي 📈" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundManager.playTab();
								setActiveTab("share");
							},
							className: `flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition cursor-pointer shrink-0 ${activeTab === "share" ? "bg-blue-600 text-white shadow-md" : "text-gray-400 hover:text-white"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "نشر صفحتي 🌐" })]
						})
					]
				}),
				activeTab === "overview" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 overflow-y-auto pr-1 space-y-4 custom-scrollbar",
					children: [
						!questionnaire.isCompleted && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-2xl bg-amber-950/50 border border-amber-500/40 flex flex-col sm:flex-row items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1 text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 text-xs sm:text-sm font-extrabold text-amber-300",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardCheck, { className: "w-4 h-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تحري الدقة العلمية في بياناتك الشخصية والزوجية" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-gray-200 leading-relaxed",
									children: "لضمان أن تعبر خانات (صفاتي ونقاط قوتي السلوكية، اهتماماتي وشغفي اليومي، تطلعاتي المستقبلية للعش الزوجي، ومواصفات شريك الحياة) عن إجاباتك الحقيقية بدقة 100%، قم بتعبئة أسئلة الاستبيان الشخصي المخصص وإجراء مقياس كاتل (16PF)."
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 shrink-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										soundManager.playTap();
										setActiveTab("questionnaire");
									},
									className: "px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs transition cursor-pointer shadow-md whitespace-nowrap",
									children: "تعبئة أسئلة ملفي الشخصي الآن ✍️"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										soundManager.playTap();
										setActiveTab("cattell_16pf");
									},
									className: "px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition cursor-pointer whitespace-nowrap",
									children: "مقياس كاتل 16PF 📊"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-purple-500/15 via-pink-500/15 to-rose-500/15 border border-purple-500/30 flex flex-col sm:flex-row items-center justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5 text-center sm:text-right",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-center sm:justify-start gap-2 flex-wrap",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
												className: "font-black text-lg sm:text-xl text-white font-['Alexandria']",
												children: [
													userName,
													" (",
													userAge,
													" عاماً)"
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-xs px-2.5 py-0.5 rounded-full bg-white/10 text-gray-200 border border-white/15",
												children: [
													country,
													" ",
													questionnaire.city ? `• ${questionnaire.city}` : ""
												]
											}),
											questionnaire.educationAndCareer && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs px-2.5 py-0.5 rounded-full bg-purple-500/20 text-purple-200 border border-purple-500/30",
												children: questionnaire.educationAndCareer
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-bold text-rose-300",
										children: cattellReport.isCompleted ? cattellReport.primaryArchetypeAr : report.primaryArchetypeAr
									}),
									questionnaire.personalBio ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-white/90 max-w-2xl leading-relaxed bg-black/30 p-2.5 rounded-xl border border-white/10",
										children: [
											"«",
											questionnaire.personalBio,
											"»"
										]
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-gray-300 max-w-xl",
										children: cattellReport.isCompleted ? cattellReport.validityMessageAr : report.validityMessageAr
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2 shrink-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => {
										soundManager.playTap();
										setActiveTab("questionnaire");
									},
									className: "px-3.5 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400/40 text-amber-200 text-xs font-bold transition cursor-pointer flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تعديل إجاباتي الشخصية" })]
								}), onOpenPsychologyTests && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => {
										soundManager.playTap();
										onOpenPsychologyTests();
									},
									className: "px-3.5 py-2 rounded-xl bg-purple-500/25 hover:bg-purple-500/35 border border-purple-400/40 text-purple-200 text-xs font-bold transition cursor-pointer shadow-sm",
									children: "إجراء مقياس نفسي معتمد 🔬"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 md:grid-cols-3 gap-3.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-white/5 border border-emerald-500/30 flex flex-col justify-between space-y-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-1.5 text-xs font-bold text-emerald-300",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-4 h-4 text-emerald-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "صفاتي ونقاط قوتي السلوكية:" })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => setActiveTab("questionnaire"),
												className: "text-[10px] text-emerald-300 hover:underline flex items-center gap-0.5 cursor-pointer",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "w-3 h-3" }), " تحديد/تعديل"]
											})]
										}), effectiveStrengths.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-3 rounded-xl bg-black/30 border border-white/10 text-xs text-gray-400 space-y-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "لم تقم بتحديد صفاتك ونقاط قوتك السلوكية بعد." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setActiveTab("questionnaire"),
												className: "px-3 py-1.5 rounded-lg bg-emerald-600 text-white font-bold text-[11px] cursor-pointer",
												children: "+ أجب عن أسئلة صفاتي السلوكية الآن"
											})]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
											className: "space-y-1.5 text-xs text-gray-200 leading-relaxed",
											children: effectiveStrengths.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
												className: "flex items-start gap-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-emerald-400 mt-0.5 font-bold",
													children: "✓"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: s })]
											}, i))
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "pt-2 border-t border-white/10 flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											value: customStrengthInput,
											onChange: (e) => setCustomStrengthInput(e.target.value),
											placeholder: "أضف صفة أو نقطة قوة تميزك...",
											className: "flex-1 bg-black/40 border border-white/15 rounded-xl px-2.5 py-1.5 text-[11px] text-white outline-none focus:border-emerald-400"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => {
												if (!customStrengthInput.trim()) return;
												soundManager.playTap();
												const updated = {
													...questionnaire,
													isCompleted: true,
													customStrengths: [...questionnaire.customStrengths, customStrengthInput.trim()]
												};
												setQuestionnaire(updated);
												saveUserPersonalQuestionnaire(updated);
												setCustomStrengthInput("");
											},
											className: "p-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer",
											title: "إضافة فورية",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "w-3.5 h-3.5" })
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-white/5 border border-sky-500/30 flex flex-col justify-between space-y-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-1.5 text-xs font-bold text-sky-300",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "w-4 h-4 text-sky-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "اهتماماتي وشغفي اليومي:" })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => setActiveTab("questionnaire"),
												className: "text-[10px] text-sky-300 hover:underline flex items-center gap-0.5 cursor-pointer",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "w-3 h-3" }), " تحديد/تعديل"]
											})]
										}), effectiveInterests.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-3 rounded-xl bg-black/30 border border-white/10 text-xs text-gray-400 space-y-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "لم تقم بتحديد اهتماماتك وشغفك اليومي بعد." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setActiveTab("questionnaire"),
												className: "px-3 py-1.5 rounded-lg bg-sky-600 text-white font-bold text-[11px] cursor-pointer",
												children: "+ اختر اهتماماتك وشغفك اليومي الآن"
											})]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
											className: "space-y-1.5 text-xs text-gray-200 leading-relaxed",
											children: effectiveInterests.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
												className: "flex items-start gap-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-sky-400 mt-0.5 font-bold",
													children: "•"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item })]
											}, i))
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "pt-2 border-t border-white/10 flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											value: customInterestInput,
											onChange: (e) => setCustomInterestInput(e.target.value),
											placeholder: "أضف هواية أو شغفاً يومياً...",
											className: "flex-1 bg-black/40 border border-white/15 rounded-xl px-2.5 py-1.5 text-[11px] text-white outline-none focus:border-sky-400"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => {
												if (!customInterestInput.trim()) return;
												soundManager.playTap();
												const updated = {
													...questionnaire,
													isCompleted: true,
													customInterests: [...questionnaire.customInterests, customInterestInput.trim()]
												};
												setQuestionnaire(updated);
												saveUserPersonalQuestionnaire(updated);
												setCustomInterestInput("");
											},
											className: "p-1.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white cursor-pointer",
											title: "إضافة فورية",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "w-3.5 h-3.5" })
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-white/5 border border-amber-500/30 flex flex-col justify-between space-y-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-1.5 text-xs font-bold text-amber-300",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, { className: "w-4 h-4 text-amber-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تطلعاتي المستقبلية للعش الزوجي:" })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => setActiveTab("questionnaire"),
												className: "text-[10px] text-amber-300 hover:underline flex items-center gap-0.5 cursor-pointer",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "w-3 h-3" }), " تحديد/تعديل"]
											})]
										}), effectiveAspirations.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-3 rounded-xl bg-black/30 border border-white/10 text-xs text-gray-400 space-y-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "لم تقم بتحديد تطلعاتك المستقبلية للعش الزوجي بعد." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setActiveTab("questionnaire"),
												className: "px-3 py-1.5 rounded-lg bg-amber-500 text-slate-950 font-bold text-[11px] cursor-pointer",
												children: "+ حدد رؤيتك للعش الزوجي الآن"
											})]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
											className: "space-y-1.5 text-xs text-gray-200 leading-relaxed",
											children: effectiveAspirations.map((asp, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
												className: "flex items-start gap-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-amber-400 mt-0.5 font-bold",
													children: "★"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: asp })]
											}, i))
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "pt-2 border-t border-white/10 flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											value: customAspirationInput,
											onChange: (e) => setCustomAspirationInput(e.target.value),
											placeholder: "أضف تطلعاً أو شرطاً للعش الزوجي...",
											className: "flex-1 bg-black/40 border border-white/15 rounded-xl px-2.5 py-1.5 text-[11px] text-white outline-none focus:border-amber-400"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => {
												if (!customAspirationInput.trim()) return;
												soundManager.playTap();
												const updated = {
													...questionnaire,
													isCompleted: true,
													customMaritalAspirations: [...questionnaire.customMaritalAspirations, customAspirationInput.trim()]
												};
												setQuestionnaire(updated);
												saveUserPersonalQuestionnaire(updated);
												setCustomAspirationInput("");
											},
											className: "p-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 cursor-pointer",
											title: "إضافة فورية",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "w-3.5 h-3.5" })
										})]
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 lg:grid-cols-2 gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-4 rounded-3xl bg-black/25 border border-white/10 flex flex-col items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "w-full flex items-center justify-between mb-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
										className: "font-bold text-xs text-gray-300 flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "w-3.5 h-3.5 text-purple-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "المخطط الراداري للسمات السيكومترية المقاسة:" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] font-mono text-purple-300",
										children: cattellReport.isCompleted ? "مقياس كاتل 16PF ✓" : report.testTitleAr
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-full h-64 my-auto ltr-preserve",
									dir: "ltr",
									"data-keep-dir": "true",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
										width: "100%",
										height: "100%",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(RadarChart, {
											data: activeRadarSource,
											outerRadius: "72%",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarGrid, {
													stroke: "rgba(255,255,255,0.15)",
													strokeDasharray: "3 3"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarAngleAxis, {
													dataKey: "subject",
													tick: {
														fill: "#e2e8f0",
														fontSize: 10,
														fontWeight: 700
													}
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarRadiusAxis, {
													angle: 30,
													domain: [0, 100],
													stroke: "rgba(255,255,255,0.2)",
													tick: {
														fill: "#94a3b8",
														fontSize: 8
													}
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
													backgroundColor: "#120d24",
													border: "1px solid rgba(255,255,255,0.2)",
													borderRadius: "12px",
													color: "#fff",
													textAlign: "right"
												} }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radar, {
													name: "مستوى السمة",
													dataKey: "score",
													stroke: "#a855f7",
													strokeWidth: 2.5,
													fill: "#c084fc",
													fillOpacity: .45
												})
											]
										})
									})
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-4 rounded-3xl bg-black/25 border border-white/10 space-y-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
										className: "font-bold text-xs text-gray-300 flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "w-3.5 h-3.5 text-rose-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "الأبعاد النفسية والاجتماعية المقاسة:" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setActiveTab("cattell_16pf"),
										className: "text-[11px] text-purple-300 hover:text-white font-bold cursor-pointer",
										children: "عرض تقرير كاتل 16PF الكامل ←"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-2.5 max-h-56 overflow-y-auto pr-1 custom-scrollbar",
									children: (cattellReport.isCompleted ? cattellReport : report).dimensionScores.map((dim) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1 p-2 rounded-xl bg-white/5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between text-xs",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-bold text-gray-200",
													children: dim.labelAr
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-1.5 font-mono",
													children: [dim.stenScore && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-[10px] px-1.5 py-0.5 rounded bg-white/10 text-amber-300",
														children: [
															"Sten ",
															dim.stenScore,
															"/10"
														]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "font-bold text-purple-300",
														children: [dim.score, "%"]
													})]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "w-full h-1.5 bg-black/50 rounded-full overflow-hidden",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "h-full rounded-full transition-all duration-500",
													style: {
														width: `${dim.score}%`,
														backgroundColor: dim.color || "#a855f7"
													}
												})
											}),
											dim.plainExplanationAr && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[11px] text-emerald-300 font-medium",
												children: ["✨ ", dim.plainExplanationAr]
											})
										]
									}, dim.key))
								})]
							})]
						})
					]
				}),
				activeTab === "questionnaire" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 overflow-y-auto pr-1 space-y-5 custom-scrollbar",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-2xl bg-gradient-to-r from-amber-500/20 via-purple-500/15 to-rose-500/15 border border-amber-500/40 flex flex-col sm:flex-row items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "font-extrabold text-sm sm:text-base text-white flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "w-4 h-4 text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "استبيان بناء وتحديث الملف الشخصي والسيكومتري الدقيق (مبني على إجاباتك الحقيقية)" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-gray-200 mt-1",
								children: "أجب عن الأسئلة التالية وحدد اختياراتك بدقة؛ ليتم تعبئة كافة خانات ملفك الشخصي، تطلعات العش الزوجي، ومواصفات شريك الحياة وحساب نسب التوافق مع الأعضاء بناءً على ما تقوله أنت فعلياً."
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: handleSaveQuestionnaire,
								className: "px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold text-xs transition cursor-pointer shadow-lg shrink-0",
								children: "حفظ واعتماد بياناتي وإجاباتي ✓"
							})]
						}),
						questionnaireSavedToast && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-3 rounded-xl bg-emerald-500/20 border border-emerald-400 text-emerald-200 text-xs font-bold flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-4 h-4 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تم حفظ جميع إجاباتك وتحديث خانات ملفك الشخصي ومواصفات شريك الحياة وحسابات التوافق بنجاح!" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-bold text-xs sm:text-sm text-purple-300 border-b border-white/10 pb-2",
									children: "أولاً: البيانات الشخصية والتعريفية الدقيقة"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-gray-300 mb-1 font-bold",
											children: "الاسم أو اللقب:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											value: questionnaire.fullName,
											onChange: (e) => setQuestionnaire({
												...questionnaire,
												fullName: e.target.value
											}),
											placeholder: "اكتب اسمك أو لقبك...",
											className: "w-full px-3 py-2 rounded-xl bg-black/40 border border-white/15 text-white outline-none focus:border-purple-400"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-gray-300 mb-1 font-bold",
											children: "العمر (بالسنوات):"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "number",
											min: 18,
											max: 80,
											value: questionnaire.userAge,
											onChange: (e) => setQuestionnaire({
												...questionnaire,
												userAge: Number(e.target.value) || 26
											}),
											className: "w-full px-3 py-2 rounded-xl bg-black/40 border border-white/15 text-white font-mono outline-none focus:border-purple-400"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-gray-300 mb-1 font-bold",
											children: "الجنس:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											"aria-label": "الجنس",
											title: "الجنس",
											value: questionnaire.userGender,
											onChange: (e) => setQuestionnaire({
												...questionnaire,
												userGender: e.target.value
											}),
											className: "w-full px-3 py-2 rounded-xl bg-black/60 border border-white/15 text-white outline-none focus:border-purple-400",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "male",
												children: "ذكر"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "female",
												children: "أنثى"
											})]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-gray-300 mb-1 font-bold",
											children: "البلد:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											value: questionnaire.country,
											onChange: (e) => setQuestionnaire({
												...questionnaire,
												country: e.target.value
											}),
											className: "w-full px-3 py-2 rounded-xl bg-black/40 border border-white/15 text-white outline-none focus:border-purple-400"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-gray-300 mb-1 font-bold",
											children: "المدينة:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											value: questionnaire.city,
											onChange: (e) => setQuestionnaire({
												...questionnaire,
												city: e.target.value
											}),
											placeholder: "مثال: عمّان، الرياض، جدة...",
											className: "w-full px-3 py-2 rounded-xl bg-black/40 border border-white/15 text-white outline-none focus:border-purple-400"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-gray-300 mb-1 font-bold",
											children: "المؤهل العلمي ومجال العمل:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											value: questionnaire.educationAndCareer,
											onChange: (e) => setQuestionnaire({
												...questionnaire,
												educationAndCareer: e.target.value
											}),
											placeholder: "مثال: بكالوريوس هندسة / ماجستير إدارة...",
											className: "w-full px-3 py-2 rounded-xl bg-black/40 border border-white/15 text-white outline-none focus:border-purple-400"
										})] })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-gray-300 mb-1 font-bold",
										children: "نبذة شخصية صادقة تعبر عنك (تظهر في ملفك):"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										rows: 2,
										value: questionnaire.personalBio,
										onChange: (e) => setQuestionnaire({
											...questionnaire,
											personalBio: e.target.value
										}),
										placeholder: "اكتب بضعة أسطر تصف شخصيتك، قيمك في الحياة، وما تبحث عنه بصدق...",
										className: "w-full px-3 py-2 rounded-xl bg-black/40 border border-white/15 text-white outline-none focus:border-purple-400"
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-2xl bg-white/5 border border-emerald-500/30 space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-bold text-xs sm:text-sm text-emerald-300 border-b border-white/10 pb-2",
									children: "ثانياً: أسئلة «صفاتي ونقاط قوتي السلوكية» (وفق مقياس VIA وBig Five)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-gray-200 mb-1 font-bold",
										children: "1. كيف تتعامل سلوكياً عند مواجهة ضغوط أو أزمات مفاجئة؟"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										"aria-label": "طريقة التعامل السلوكي مع الضغوط والأزمات",
										title: "طريقة التعامل السلوكي مع الضغوط والأزمات",
										value: questionnaire.stressResponseStyle,
										onChange: (e) => setQuestionnaire({
											...questionnaire,
											stressResponseStyle: e.target.value
										}),
										className: "w-full px-3 py-2 rounded-xl bg-black/60 border border-white/15 text-white outline-none",
										children: QUESTIONNAIRE_OPTIONS.stressResponseOptions.map((opt, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: opt,
											children: opt
										}, i))
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-gray-200 mb-1 font-bold",
										children: "2. ما هو أسلوبك المفضل في اتخاذ القرارات المهمة؟"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										"aria-label": "الأسلوب المفضل في اتخاذ القرارات المهمة",
										title: "الأسلوب المفضل في اتخاذ القرارات المهمة",
										value: questionnaire.decisionMakingStyle,
										onChange: (e) => setQuestionnaire({
											...questionnaire,
											decisionMakingStyle: e.target.value
										}),
										className: "w-full px-3 py-2 rounded-xl bg-black/60 border border-white/15 text-white outline-none",
										children: QUESTIONNAIRE_OPTIONS.decisionMakingOptions.map((opt, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: opt,
											children: opt
										}, i))
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-gray-200 font-bold",
										children: "3. اختر الصفات ونقاط القوة السلوكية التي تنطبق عليك فعلياً (يمكنك اختيار أكثر من صفة):"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-2",
										children: QUESTIONNAIRE_OPTIONS.strengthsCatalog.map((str) => {
											const checked = questionnaire.selectedStrengths.includes(str);
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => setQuestionnaire({
													...questionnaire,
													selectedStrengths: toggleArrayItem(questionnaire.selectedStrengths, str)
												}),
												className: `p-2.5 rounded-xl border text-right text-xs transition flex items-center justify-between cursor-pointer ${checked ? "bg-emerald-600/30 border-emerald-400 text-white font-bold" : "bg-black/30 border-white/10 text-gray-300 hover:bg-white/5"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: str }), checked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4 text-emerald-400 shrink-0 mr-1" })]
											}, str);
										})
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-2xl bg-white/5 border border-sky-500/30 space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-bold text-xs sm:text-sm text-sky-300 border-b border-white/10 pb-2",
									children: "ثالثاً: أسئلة «اهتماماتي وشغفي اليومي» (وفق نموذج هولاند RIASEC وأسلوب الحياة)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-gray-200 mb-1 font-bold",
										children: "1. ما هي المجالات الفكرية أو المعرفية التي تثير شغفك في النقاش؟"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "text",
										value: questionnaire.intellectualPassion,
										onChange: (e) => setQuestionnaire({
											...questionnaire,
											intellectualPassion: e.target.value
										}),
										placeholder: "مثال: علم النفس، الأدب، التقنية، ريادة الأعمال، التاريخ...",
										className: "w-full px-3 py-2 rounded-xl bg-black/40 border border-white/15 text-white outline-none"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-gray-200 mb-1 font-bold",
										children: "2. كيف تفضل قضاء وقت فراغك وعطلة نهاية الأسبوع؟"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "text",
										value: questionnaire.weekendRoutinePreference,
										onChange: (e) => setQuestionnaire({
											...questionnaire,
											weekendRoutinePreference: e.target.value
										}),
										placeholder: "مثال: جلسة هادئة في البيت، السفر والطبيعة، زيارة العائلة...",
										className: "w-full px-3 py-2 rounded-xl bg-black/40 border border-white/15 text-white outline-none"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-gray-200 font-bold",
										children: "3. حدد اهتماماتك وهواياتك اليومية المفضلة:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-2",
										children: QUESTIONNAIRE_OPTIONS.interestsCatalog.map((interest) => {
											const checked = questionnaire.selectedInterests.includes(interest);
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => setQuestionnaire({
													...questionnaire,
													selectedInterests: toggleArrayItem(questionnaire.selectedInterests, interest)
												}),
												className: `p-2.5 rounded-xl border text-right text-xs transition flex items-center justify-between cursor-pointer ${checked ? "bg-sky-600/30 border-sky-400 text-white font-bold" : "bg-black/30 border-white/10 text-gray-300 hover:bg-white/5"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: interest }), checked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4 text-sky-400 shrink-0 mr-1" })]
											}, interest);
										})
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-2xl bg-white/5 border border-amber-500/30 space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-bold text-xs sm:text-sm text-amber-300 border-b border-white/10 pb-2",
									children: "رابعاً: أسئلة «تطلعاتي المستقبلية للعش الزوجي» (وفق نظرية البيت الزوجي المتين لجون غوتمان)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-gray-200 mb-1 font-bold",
											children: "1. ما هي الأجواء العامة التي تتطلع لبنائها في بيتك الزوجي؟"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
											"aria-label": "الأجواء العامة للبيت الزوجي",
											title: "الأجواء العامة للبيت الزوجي",
											value: questionnaire.maritalHomeAtmosphere,
											onChange: (e) => setQuestionnaire({
												...questionnaire,
												maritalHomeAtmosphere: e.target.value
											}),
											className: "w-full px-3 py-2 rounded-xl bg-black/60 border border-white/15 text-white outline-none",
											children: QUESTIONNAIRE_OPTIONS.maritalHomeAtmosphereOptions.map((opt, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: opt,
												children: opt
											}, i))
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-gray-200 mb-1 font-bold",
											children: "2. ما هي رؤيتك للإدارة المالية والميزانية في الأسرة؟"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
											"aria-label": "رؤية الإدارة المالية والميزانية في الأسرة",
											title: "رؤية الإدارة المالية والميزانية في الأسرة",
											value: questionnaire.financialManagementVision,
											onChange: (e) => setQuestionnaire({
												...questionnaire,
												financialManagementVision: e.target.value
											}),
											className: "w-full px-3 py-2 rounded-xl bg-black/60 border border-white/15 text-white outline-none",
											children: QUESTIONNAIRE_OPTIONS.financialVisionOptions.map((opt, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: opt,
												children: opt
											}, i))
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-gray-200 mb-1 font-bold",
											children: "3. ما هو بروتوكول حل الخلافات الزوجية الذي ترتاح له؟"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
											"aria-label": "بروتوكول حل الخلافات الزوجية",
											title: "بروتوكول حل الخلافات الزوجية",
											value: questionnaire.conflictResolutionProtocol,
											onChange: (e) => setQuestionnaire({
												...questionnaire,
												conflictResolutionProtocol: e.target.value
											}),
											className: "w-full px-3 py-2 rounded-xl bg-black/60 border border-white/15 text-white outline-none",
											children: QUESTIONNAIRE_OPTIONS.conflictProtocolOptions.map((opt, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: opt,
												children: opt
											}, i))
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-gray-200 mb-1 font-bold",
											children: "4. ما هي لغة الحب والتقدير الأساسية التي تسعد قلبك؟"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
											"aria-label": "لغة الحب والتقدير الأساسية",
											title: "لغة الحب والتقدير الأساسية",
											value: questionnaire.primaryLoveLanguage,
											onChange: (e) => setQuestionnaire({
												...questionnaire,
												primaryLoveLanguage: e.target.value
											}),
											className: "w-full px-3 py-2 rounded-xl bg-black/60 border border-white/15 text-white outline-none",
											children: QUESTIONNAIRE_OPTIONS.loveLanguagesOptions.map((opt, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: opt,
												children: opt
											}, i))
										})] })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-gray-200 font-bold",
										children: "5. اختر التطلعات والأولويات التي تود تحقيقها في عشك الزوجي:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-2",
										children: QUESTIONNAIRE_OPTIONS.maritalAspirationsCatalog.map((asp) => {
											const checked = questionnaire.selectedMaritalAspirations.includes(asp);
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => setQuestionnaire({
													...questionnaire,
													selectedMaritalAspirations: toggleArrayItem(questionnaire.selectedMaritalAspirations, asp)
												}),
												className: `p-2.5 rounded-xl border text-right text-xs transition flex items-center justify-between cursor-pointer ${checked ? "bg-amber-500/30 border-amber-400 text-white font-bold" : "bg-black/30 border-white/10 text-gray-300 hover:bg-white/5"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: asp }), checked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4 text-amber-400 shrink-0 mr-1" })]
											}, asp);
										})
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-2xl bg-white/5 border border-rose-500/30 space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-bold text-xs sm:text-sm text-rose-300 border-b border-white/10 pb-2",
									children: "خامساً: أسئلة «مواصفات شريك الحياة المناسب» (وفق اختيارك والتكامل السيكومتري)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-gray-200 mb-1 font-bold",
											children: "1. ما هي الشخصية الأساسية التي تتمناها في شريك حياتك؟"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											value: questionnaire.partnerCorePersonalityType,
											onChange: (e) => setQuestionnaire({
												...questionnaire,
												partnerCorePersonalityType: e.target.value
											}),
											className: "w-full px-3 py-2 rounded-xl bg-black/40 border border-white/15 text-white outline-none"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-gray-200 mb-1 font-bold",
											children: "2. الفئة العمرية المفضلة لشريك الحياة:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											value: questionnaire.preferredPartnerAgeRange,
											onChange: (e) => setQuestionnaire({
												...questionnaire,
												preferredPartnerAgeRange: e.target.value
											}),
											className: "w-full px-3 py-2 rounded-xl bg-black/40 border border-white/15 text-white outline-none"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-gray-200 mb-1 font-bold",
											children: "3. أهم احتياجاتك العاطفية التي تنتظرها من شريك حياتك:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											value: questionnaire.partnerEmotionalNeedsFromThem,
											onChange: (e) => setQuestionnaire({
												...questionnaire,
												partnerEmotionalNeedsFromThem: e.target.value
											}),
											className: "w-full px-3 py-2 rounded-xl bg-black/40 border border-white/15 text-white outline-none"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-gray-200 mb-1 font-bold",
											children: "4. أسلوب التواصل والحوار المفضل مع الشريك:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											value: questionnaire.partnerCommunicationPreference,
											onChange: (e) => setQuestionnaire({
												...questionnaire,
												partnerCommunicationPreference: e.target.value
											}),
											className: "w-full px-3 py-2 rounded-xl bg-black/40 border border-white/15 text-white outline-none"
										})] })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-emerald-300 font-bold",
										children: "5. الصفات الأساسية والمؤشرات الإيجابية المطلوبة في الشريك (Green Flags):"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-2",
										children: QUESTIONNAIRE_OPTIONS.partnerEssentialTraitsCatalog.map((tr) => {
											const checked = questionnaire.partnerEssentialTraits.includes(tr);
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => setQuestionnaire({
													...questionnaire,
													partnerEssentialTraits: toggleArrayItem(questionnaire.partnerEssentialTraits, tr)
												}),
												className: `p-2.5 rounded-xl border text-right text-xs transition flex items-center justify-between cursor-pointer ${checked ? "bg-emerald-600/30 border-emerald-400 text-white font-bold" : "bg-black/30 border-white/10 text-gray-300"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: tr }), checked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4 text-emerald-400 shrink-0 mr-1" })]
											}, tr);
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-rose-300 font-bold",
										children: "6. المؤشرات السلبية المرفوضة تماماً في الشريك (Red Flags):"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-2",
										children: QUESTIONNAIRE_OPTIONS.partnerRedFlagsCatalog.map((rf) => {
											const checked = questionnaire.partnerRedFlags.includes(rf);
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => setQuestionnaire({
													...questionnaire,
													partnerRedFlags: toggleArrayItem(questionnaire.partnerRedFlags, rf)
												}),
												className: `p-2.5 rounded-xl border text-right text-xs transition flex items-center justify-between cursor-pointer ${checked ? "bg-rose-600/30 border-rose-400 text-white font-bold" : "bg-black/30 border-white/10 text-gray-300"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: rf }), checked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4 text-rose-400 shrink-0 mr-1" })]
											}, rf);
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "pt-3 flex justify-end",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => {
											handleSaveQuestionnaire();
											setActiveTab("overview");
										},
										className: "px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-extrabold text-xs cursor-pointer shadow-lg",
										children: "حفظ جميع إجاباتي وعرض ملفي الشخصي المحدث ✓"
									})
								})
							]
						})
					]
				}),
				activeTab === "cattell_16pf" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 overflow-y-auto pr-1 space-y-4 custom-scrollbar",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-indigo-950/60 via-purple-950/60 to-slate-900 border border-indigo-500/40 flex flex-col sm:flex-row items-center justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 flex-wrap",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-black text-base sm:text-lg text-white font-['Alexandria']",
									children: "مقياس كاتل لـ 16 سمة (16PF) - تقرير مبسط لغير المختصين"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-indigo-500/25 text-indigo-200 border border-indigo-400/40",
									children: "Raymond B. Cattell 16PF (Sten 1-10)"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-gray-300 leading-relaxed max-w-2xl",
								children: "يقيس هذا الاختبار العالمي 16 سمة أولية للشخصية (العوامل A إلى Q4) بالإضافة إلى العوامل العالمية الخمسة الكبرى، ويترجم كل درجة معيارية (Sten 1-10) إلى لغة يومية مبسطة توضح سلوكك في الحياة والزواج."
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2 shrink-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									soundManager.playTap();
									setIsTaking16PFInline((prev) => !prev);
								},
								className: "px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs transition cursor-pointer shadow-md flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isTaking16PFInline ? "العودة لعرض التقرير" : cattellReport.isCompleted ? "إعادة / تعديل إجابات مقياس 16PF" : "ابدأ الإجابة على أسئلة 16PF الآن (32 سؤالاً)" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: async () => {
									soundManager.playTap();
									const { exportPsychometricReportAsPDF } = await __vitePreload(async () => {
										const { exportPsychometricReportAsPDF } = await import("./pdfReportGenerator-BNu3pVmt.js");
										return { exportPsychometricReportAsPDF };
									}, __vite__mapDeps([10,3,1,2,4,5,11,7,8,9]));
									exportPsychometricReportAsPDF({
										reportTitle: "تقرير مقياس كاتل للعوامل الـ 16 للشخصية (Cattell 16PF)",
										subTitle: "16PF Fifth Edition — Simplified Non-Specialist Report",
										scientificBasis: "Raymond B. Cattell (1949/1993) — 16 Primary Factors + 5 Global Second-Order Factors (Sten 1-10)",
										userName,
										completedAt: cattellReport.completionDate,
										overallScoreLabel: "متوسط الاتزان العاملي والمئين المعياري",
										overallScoreValue: `${cattellReport.totalScore}% (المئين ${cattellReport.overallPercentile}%)`,
										cognitiveFingerprintTitle: cattellReport.primaryArchetypeAr,
										executiveSummary: `${cattellReport.summaryAr} — ${cattellReport.validityMessageAr}`,
										metrics: cattellReport.dimensionScores.map((d) => ({
											label: d.factorCode ? `[${d.factorCode}] ${d.labelAr}` : d.labelAr,
											scorePercent: d.score,
											levelLabel: `${d.levelAr} (Sten ${d.stenScore || 6}/10)`,
											rawText: `${d.plainExplanationAr || ""} — ${d.analysisAr}`,
											color: d.color || "#8b5cf6"
										})),
										sections: cattellReport.cattellGlobalFactors ? [{
											title: "العوامل العالمية الخمسة الكبرى (5 Global Factors)",
											badge: "تحليل الدرجة الثانية",
											content: "الأبعاد الكبرى المستخلصة من تفاعل السمات الـ 16:",
											items: cattellReport.cattellGlobalFactors.map((g) => `${g.labelAr} (${g.score}% • Sten ${g.sten}/10): ${g.plainExplanationAr}`)
										}] : [],
										careersOrRecommendations: cattellReport.userAspirationsAr
									});
								},
								className: "px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs transition cursor-pointer flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileDown, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تحميل تقرير 16PF PDF 📄" })]
							})]
						})]
					}), isTaking16PFInline ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-4 rounded-3xl bg-black/40 border border-indigo-500/40 space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between border-b border-white/10 pb-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-bold text-sm text-white",
									children: "أسئلة مقياس كاتل للعوامل الـ 16 للشخصية (32 موقفاً سلوكياً واقعياً)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-indigo-200",
									children: "أجب عن جميع الأسئلة الـ 32 بصدق لتظهر درجاتك الحقيقية في السمات الـ 16 بالدرجة المعيارية Sten (1-10)"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs font-mono font-bold text-emerald-400",
									children: [
										"تمت الإجابة على ",
										Object.keys(inline16PFAnswers).length,
										" / ",
										sixteenPFQuestions.length
									]
								})]
							}),
							inline16PFMissing.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3 rounded-xl bg-rose-950/60 border border-rose-500/50 text-xs text-rose-200 flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "w-4 h-4 text-rose-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"يُرجى الإجابة على جميع الأسئلة الـ 32 لضمان دقة التقرير (تبقى",
									" ",
									inline16PFMissing.length,
									" سؤالاً، أولها سؤال #",
									inline16PFMissing[0] + 1,
									")."
								] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-3 max-h-[52vh] overflow-y-auto pr-1 custom-scrollbar",
								children: sixteenPFQuestions.map((q, idx) => {
									const isMiss = inline16PFMissing.includes(idx);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `p-3.5 rounded-2xl border ${isMiss ? "bg-rose-950/30 border-rose-500/60" : "bg-white/5 border-white/10"} space-y-2`,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between text-xs",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "font-bold text-indigo-300 font-mono",
													children: ["سؤال #", idx + 1]
												}), inline16PFAnswers[q.id] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[11px] text-emerald-400 font-bold",
													children: "✓ تمت الإجابة"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs sm:text-sm font-bold text-white",
												children: q.promptAr
											}),
											q.subPromptAr && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[11px] text-indigo-200/80",
												children: ["💡 ", q.subPromptAr]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "grid grid-cols-1 gap-1.5 pt-1",
												children: q.options.map((opt) => {
													const sel = inline16PFAnswers[q.id] === opt.id;
													return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														type: "button",
														onClick: () => {
															soundManager.playTap();
															setInline16PFAnswers((prev) => ({
																...prev,
																[q.id]: opt.id
															}));
														},
														className: `p-2.5 rounded-xl border text-right text-xs transition flex items-center justify-between cursor-pointer ${sel ? "bg-indigo-600/40 border-indigo-400 text-white font-bold" : "bg-black/30 border-white/10 text-gray-300 hover:bg-white/10"}`,
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: opt.textAr }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "text-[10px] font-mono text-indigo-300 mr-2 shrink-0",
															children: [
																"[",
																opt.traitLabel,
																"]"
															]
														})]
													}, opt.id);
												})
											})
										]
									}, q.id);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "pt-2 flex justify-end",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: handleCompleteInline16PF,
									className: "px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-extrabold text-xs cursor-pointer shadow-lg",
									children: "حساب وإصدار تقرير كاتل 16PF الدقيق الآن ✓"
								})
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [
							!cattellReport.isCompleted && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3.5 rounded-2xl bg-amber-950/40 border border-amber-500/40 flex items-center justify-between gap-3 text-xs text-amber-200",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "⚠️ ملاحظة: لم تقم بإجراء اختبار كاتل (16PF) بعد — الدرجات المعروضة أدناه تمثل خط المنتصف المحايد (50% / Sten 5). اضغط على «ابدأ الإجابة على أسئلة 16PF الآن» أعلاه لحساب سماتك الـ 16 الحقيقية بدقة." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setIsTaking16PFInline(true),
									className: "px-3 py-1.5 rounded-xl bg-amber-500 text-slate-950 font-extrabold shrink-0 cursor-pointer",
									children: "ابدأ الاختبار الآن"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-bold text-gray-300",
									children: "اختر طريقة عرض التقرير المبسط لغير المختصين:"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center p-1 rounded-xl bg-black/50 border border-white/10 text-xs font-bold",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setCattellViewMode("all16"),
											className: `px-3 py-1 rounded-lg transition cursor-pointer ${cattellViewMode === "all16" ? "bg-indigo-600 text-white" : "text-gray-400 hover:text-white"}`,
											children: "السمات الـ 16 الكاملة (A - Q4) 📊"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setCattellViewMode("global5"),
											className: `px-3 py-1 rounded-lg transition cursor-pointer ${cattellViewMode === "global5" ? "bg-indigo-600 text-white" : "text-gray-400 hover:text-white"}`,
											children: "العوامل العالمية الـ 5 الكبرى 🌍"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setCattellViewMode("clusters"),
											className: `px-3 py-1 rounded-lg transition cursor-pointer ${cattellViewMode === "clusters" ? "bg-indigo-600 text-white" : "text-gray-400 hover:text-white"}`,
											children: "المجموعات الـ 4 المبسطة 🧩"
										})
									]
								})]
							}),
							cattellViewMode === "all16" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 md:grid-cols-2 gap-3",
								children: cattellReport.dimensionScores.map((dim) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-black/35 border border-white/10 space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-extrabold text-xs sm:text-sm text-white",
												children: dim.labelAr
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-1.5 font-mono shrink-0",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-[10px] px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-bold",
													children: [
														"Sten ",
														dim.stenScore || 6,
														"/10"
													]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "font-black text-sm text-purple-300",
													children: [dim.score, "%"]
												})]
											})]
										}),
										dim.lowPoleAr && dim.highPoleAr && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-[10px] text-gray-400 font-medium",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["القطب المنخفض: ", dim.lowPoleAr] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["القطب المرتفع: ", dim.highPoleAr] })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-full h-2 bg-black/60 rounded-full overflow-hidden",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "h-full rounded-full transition-all duration-500",
												style: {
													width: `${dim.score}%`,
													backgroundColor: dim.color || "#6366f1"
												}
											})
										}),
										dim.plainExplanationAr && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-xs text-emerald-200 font-medium leading-relaxed",
											children: [
												"✨ ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "التفسير المبسط لغير المختصين:" }),
												" ",
												dim.plainExplanationAr
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] text-gray-300 leading-relaxed",
											children: dim.analysisAr
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[11px] text-amber-300",
											children: ["💍 تطبيق زوجي: ", dim.adviceAr]
										})
									]
								}, dim.key))
							}),
							cattellViewMode === "global5" && cattellReport.cattellGlobalFactors && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-3",
								children: cattellReport.cattellGlobalFactors.map((gf) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-black/35 border border-white/10 space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-extrabold text-sm text-white",
												children: gf.labelAr
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2 font-mono text-xs",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300",
													children: [
														"Sten ",
														gf.sten,
														"/10"
													]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "font-black text-white",
													children: [gf.score, "%"]
												})]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-[11px] text-gray-400",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: gf.lowPoleAr }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: gf.highPoleAr })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-full h-2 bg-black/60 rounded-full overflow-hidden",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "h-full rounded-full",
												style: {
													width: `${gf.score}%`,
													backgroundColor: gf.color
												}
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs text-emerald-200 font-semibold",
											children: ["💡 المعنى المبسط: ", gf.plainExplanationAr]
										})
									]
								}, gf.key))
							}),
							cattellViewMode === "clusters" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-3.5",
								children: [
									{
										title: "1. أسلوب التواصل والتفاعل الإنساني 💬",
										keys: [
											"warmth",
											"liveliness",
											"social_boldness",
											"privateness"
										],
										desc: "يجمع عوامل الدفء (A)، الحيوية (F)، الجرأة الاجتماعية (H)، وحفظ الخصوصية (N) ليوضح كيف تتواصل عاطفياً واجتماعياً.",
										color: "#f43f5e"
									},
									{
										title: "2. الصلابة العاطفية وإدارة الضغوط 🛡️",
										keys: [
											"stability",
											"vigilance",
											"apprehension",
											"tension"
										],
										desc: "يجمع عوامل قوة الأنا (C)، اليقظة (L)، الاطمئنان (O)، والسكينة (Q4) ليوضح مدى ثباتك الانفعالي وقت الأزمات.",
										color: "#10b981"
									},
									{
										title: "3. التفكير التحليلي والخيال والتجديد 💡",
										keys: [
											"reasoning",
											"sensitivity",
											"abstractedness",
											"openness_to_change"
										],
										desc: "يجمع عوامل المنطق التحليلي (B)، رهافة الحس (I)، الخيال (M)، والانفتاح على التطوير (Q1).",
										color: "#38bdf8"
									},
									{
										title: "4. القيادة والانضباط وأسلوب الحياة ⚖️",
										keys: [
											"dominance",
											"rule_consciousness",
											"self_reliance",
											"perfectionism"
										],
										desc: "يجمع عوامل القيادة (E)، الضمير الحي (G)، الاستقلالية (Q2)، والدقة التنظيمية (Q3).",
										color: "#a855f7"
									}
								].map((cl, idx) => {
									const matched = cattellReport.dimensionScores.filter((d) => cl.keys.includes(d.key));
									const avg = Math.round(matched.reduce((acc, c) => acc + c.score, 0) / Math.max(1, matched.length));
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-4 rounded-2xl bg-black/35 border border-white/10 space-y-2.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
													className: "font-bold text-xs sm:text-sm text-white",
													children: cl.title
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "font-black text-xs font-mono px-2.5 py-0.5 rounded-lg",
													style: {
														backgroundColor: `${cl.color}25`,
														color: cl.color
													},
													children: [avg, "%"]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-gray-300 leading-relaxed",
												children: cl.desc
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "space-y-1.5 pt-2 border-t border-white/10",
												children: matched.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-between text-[11px] text-gray-200",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: m.labelAr.split("(")[0] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "font-mono text-purple-300",
														children: [
															m.score,
															"% (Sten ",
															m.stenScore,
															"/10)"
														]
													})]
												}, m.key))
											})
										]
									}, idx);
								})
							})
						]
					})]
				}),
				activeTab === "partner" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 overflow-y-auto pr-1 space-y-4 custom-scrollbar",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-rose-500/20 via-pink-500/20 to-purple-500/20 border border-rose-500/30 flex flex-col sm:flex-row items-center justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5 text-center sm:text-right",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "px-3 py-1 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 font-bold text-xs inline-block",
										children: "تحليل مواصفات شريك الحياة المناسب (وفق إجاباتك والتكامل السيكومتري) 💍"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-black text-lg sm:text-xl text-white font-['Alexandria']",
										children: questionnaire.partnerCorePersonalityType || activeMatchingReport.idealPartnerProfile.recommendedArchetypeAr
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-gray-200 max-w-2xl leading-relaxed",
										children: [
											"الفئة العمرية المفضلة: ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: questionnaire.preferredPartnerAgeRange }),
											" • تم استخلاص هذه المواصفات من إجاباتك المباشرة في الاستبيان الزوجي بالتكامل مع نتائجك السيكومترية في مقياس كاتل (16PF) والعوامل الخمسة."
										]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setActiveTab("questionnaire"),
								className: "px-3.5 py-2 rounded-xl bg-rose-500 hover:bg-rose-400 text-white font-bold text-xs transition cursor-pointer shrink-0 flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تعديل مواصفات شريكي" })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 md:grid-cols-2 gap-3.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5 text-xs font-bold text-rose-300",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-4 h-4 text-rose-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "الصفات الأساسية والسمات المتكاملة المطلوبة في الشريك:" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "space-y-2 text-xs text-gray-200 leading-relaxed",
									children: [...questionnaire.partnerEssentialTraits, ...activeMatchingReport.idealPartnerProfile.complementaryTraits.slice(0, 2)].filter((v, i, a) => Boolean(v) && a.indexOf(v) === i).map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-start gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-1.5 h-1.5 rounded-full bg-rose-400 mt-1.5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t })]
									}, i))
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5 text-xs font-bold text-purple-300",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "w-4 h-4 text-purple-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "احتياجاتك العاطفية وأسلوب الحوار الأنسب مع الشريك:" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2.5 text-xs text-gray-200 leading-relaxed",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3 rounded-xl bg-purple-500/10 border border-purple-500/20",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-purple-300 block mb-1",
											children: "الحاجة للأمان النفسي والاحتواء:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: questionnaire.partnerEmotionalNeedsFromThem })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3 rounded-xl bg-sky-500/10 border border-sky-500/20",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-sky-300 block mb-1",
											children: "أسلوب التواصل وحل الخلافات المفضل:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: questionnaire.partnerCommunicationPreference })]
									})]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 md:grid-cols-2 gap-3.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/25 space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5 text-xs font-bold text-emerald-300",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-4 h-4 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "مؤشرات التوافق الإيجابي (Green Flags) التي تبحث عنها:" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "space-y-1.5 text-xs text-gray-200 leading-relaxed",
									children: questionnaire.partnerGreenFlags.map((g, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-start gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-emerald-400 font-bold",
											children: "✓"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: g })]
									}, i))
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-4 rounded-2xl bg-rose-500/10 border border-rose-500/25 space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5 text-xs font-bold text-rose-300",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "w-4 h-4 text-rose-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "مؤشرات التنافر المرفوضة (Red Flags) لتجنبها:" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "space-y-1.5 text-xs text-gray-200 leading-relaxed",
									children: questionnaire.partnerRedFlags.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-start gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-rose-400 font-bold",
											children: "✕"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: r })]
									}, i))
								})]
							})]
						})
					]
				}),
				activeTab === "matches" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 overflow-y-auto pr-1 space-y-4 custom-scrollbar",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-emerald-500/15 via-teal-500/15 to-purple-500/15 border border-emerald-500/30 space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col sm:flex-row items-center justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "font-extrabold text-sm sm:text-base text-white flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "w-4 h-4 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "اكتشف من يشبهك أو يتوافق معك للتواصل (خوارزمية التوافق السيكومتري)" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-gray-300 mt-0.5",
									children: "يتم حساب نسب التوافق التكاملي والتشابه النمطي رياضياً بناءً على إجاباتك في الاستبيان الشخصي وسماتك الـ 16 (Cattell 16PF / Big Five)."
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 shrink-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-bold text-gray-300",
										children: isPublic ? "ملفي مفعل للتعارف 🟢" : "ملف خاص 🔒"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => handleTogglePublic(!isPublic),
										className: `relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${isPublic ? "bg-emerald-500" : "bg-gray-700"}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${isPublic ? "-translate-x-6" : "-translate-x-1"}` })
									})]
								})]
							}), isPublic && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "pt-2 border-t border-white/10 flex flex-col sm:flex-row items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5 text-xs text-gray-300 shrink-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "w-3.5 h-3.5 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "رقم الواتساب للتواصل (اختياري):" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 flex-1 w-full sm:w-auto",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "text",
										value: whatsappContact,
										onChange: (e) => setWhatsappContact(e.target.value),
										placeholder: "مثال: +966501234567",
										className: "px-3 py-1.5 rounded-xl bg-black/40 border border-emerald-500/30 text-white text-xs outline-none flex-1 font-mono"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: handleSaveWhatsapp,
										className: "px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition cursor-pointer shrink-0",
										children: "حفظ وتحديث بطاقتي"
									})]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1 p-1 rounded-2xl bg-black/30 border border-white/10 text-xs font-bold overflow-x-auto",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => {
											soundManager.playTab();
											setMatchFilter("all");
										},
										className: `px-3 py-1 rounded-xl transition cursor-pointer ${matchFilter === "all" ? "bg-purple-600 text-white shadow-sm" : "text-gray-400 hover:text-white"}`,
										children: [
											"جميع المتوافقين (",
											computedCommunityMembers.length,
											")"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => {
											soundManager.playTab();
											setMatchFilter("complementary");
										},
										className: `px-3 py-1 rounded-xl transition cursor-pointer ${matchFilter === "complementary" ? "bg-rose-600 text-white shadow-sm" : "text-gray-400 hover:text-white"}`,
										children: "التوافق التكاملي للزواج 💍"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => {
											soundManager.playTab();
											setMatchFilter("similar");
										},
										className: `px-3 py-1 rounded-xl transition cursor-pointer ${matchFilter === "similar" ? "bg-sky-600 text-white shadow-sm" : "text-gray-400 hover:text-white"}`,
										children: "المتشابهون في النمط والاهتمامات 🤝"
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									"aria-label": "تصفية الأعضاء حسب الجنس",
									title: "تصفية الأعضاء حسب الجنس",
									value: genderFilter,
									onChange: (e) => setGenderFilter(e.target.value),
									className: "px-2.5 py-1.5 rounded-xl bg-black/40 border border-white/15 text-xs text-white outline-none",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "all",
											children: "الجنس: الكل"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "female",
											children: "إناث"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "male",
											children: "ذكور"
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "w-3.5 h-3.5 text-gray-400 absolute right-2.5 top-2" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "text",
										value: matchSearchQuery,
										onChange: (e) => setMatchSearchQuery(e.target.value),
										placeholder: "ابحث بالبلد أو الاهتمام...",
										className: "pr-8 pl-3 py-1.5 rounded-xl bg-black/40 border border-white/15 text-xs text-white outline-none w-44"
									})]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-1 md:grid-cols-2 gap-3.5",
							children: filteredMembers.map((member) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-4 rounded-3xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-purple-500/40 transition flex flex-col justify-between space-y-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: member.avatarUrl,
											alt: member.displayName,
											className: "w-14 h-14 rounded-2xl object-cover border-2 border-purple-500/40 shrink-0 shadow-md"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex-1 min-w-0",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-between gap-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
														className: "font-extrabold text-sm text-white truncate",
														children: member.displayName
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30 shrink-0",
														children: member.archetypeBadge
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-[11px] text-rose-300 font-semibold truncate",
													children: member.archetype
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "text-[10px] text-gray-400",
													children: [
														member.country,
														" • ",
														member.city,
														" (",
														member.userAge,
														" سنة)"
													]
												})
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-gray-300 leading-relaxed",
										children: member.bio
									}),
									member.sharedHighlightsWithUser && member.sharedHighlightsWithUser.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] font-bold text-emerald-300 block",
											children: "نقاط التشابه والتلاقي المباشر مع إجاباتك:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex flex-wrap gap-1",
											children: member.sharedHighlightsWithUser.slice(0, 2).map((sh, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-[10px] px-2 py-0.5 rounded-lg bg-emerald-500/15 text-emerald-200 border border-emerald-500/30",
												children: ["✓ ", sh]
											}, idx))
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-2.5 rounded-2xl bg-black/40 border border-white/10 space-y-1.5 text-xs",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-gray-300 font-bold flex items-center gap-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "w-3.5 h-3.5 text-rose-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "معامل التوافق التكاملي للزواج:" })]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "font-black text-rose-300 font-mono text-sm",
													children: [member.compatibilityScore, "%"]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "w-full h-1.5 bg-black/50 rounded-full overflow-hidden",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "h-full bg-gradient-to-r from-purple-500 to-rose-500 rounded-full",
													style: { width: `${member.compatibilityScore}%` }
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between text-[10px] text-gray-400 pt-0.5 font-mono",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
													"معامل التشابه السيكومتري: ",
													member.similarityScore,
													"%"
												] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: member.attachmentStyleAr || "ارتباط آمن" })]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 pt-1 border-t border-white/10",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => {
													soundManager.playTap();
													setSelectedMemberToCompare(member);
												},
												className: "flex-1 py-2 px-2.5 rounded-xl bg-indigo-600/30 hover:bg-indigo-600/50 border border-indigo-500/40 text-indigo-200 font-bold text-xs transition flex items-center justify-center gap-1 cursor-pointer",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تحليل التوافق المقارن" })]
											}),
											member.contactOptions.whatsapp && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => {
													soundManager.playTap();
													const msg = `مرحباً ${member.displayName}، اطلعت على ملفك السيكومتري المتوافق معي بنسبة ${member.compatibilityScore}% على منصة «مِرآة القلوب» وأود التواصل معك 🌸`;
													openExternalShareUrl(`https://api.whatsapp.com/send?phone=${member.contactOptions.whatsapp}&text=${encodeURIComponent(msg)}`);
												},
												className: "py-2 px-2.5 rounded-xl bg-emerald-600/30 hover:bg-emerald-600/40 border border-emerald-500/40 text-emerald-300 font-bold text-xs transition flex items-center justify-center gap-1 cursor-pointer",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "w-3.5 h-3.5 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "واتساب" })]
											}),
											onOpenLiveChat && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => {
													soundManager.playTap();
													onClose();
													onOpenLiveChat();
												},
												className: "py-2 px-3 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs transition flex items-center justify-center gap-1 cursor-pointer shadow-sm",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "دردشة حية" })
											}),
											onOpenCoupleInvite && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => {
													soundManager.playTap();
													onClose();
													onOpenCoupleInvite();
												},
												className: "py-2 px-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-gray-200 font-bold text-xs transition cursor-pointer",
												title: "دعوة لخوض اختبار التوافق الثنائي",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "دعوة 💑" })
											})
										]
									})
								]
							}, member.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: selectedMemberToCompare && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
							initial: { opacity: 0 },
							animate: { opacity: 1 },
							exit: { opacity: 0 },
							className: "fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-sm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "w-full max-w-2xl rounded-3xl bg-[#140e28] border border-purple-500/40 p-5 space-y-4 text-right max-h-[88vh] overflow-y-auto",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between border-b border-white/10 pb-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
											className: "font-extrabold text-base text-white",
											children: [
												"المقارنة السيكومترية الدقيقة: ",
												userName,
												" ✕",
												" ",
												selectedMemberToCompare.displayName
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs text-purple-300",
											children: [
												"نسبة التوافق التكاملي: ",
												selectedMemberToCompare.compatibilityScore,
												"% • نسبة التشابه النمطي: ",
												selectedMemberToCompare.similarityScore,
												"%"
											]
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setSelectedMemberToCompare(null),
											className: "p-1.5 rounded-full bg-white/10 text-gray-300 hover:text-white cursor-pointer",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-4 h-4" })
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
											className: "font-bold text-xs text-gray-300",
											children: "مقارنة الأبعاد الخمسة الكبرى للشخصية (أنت مقابل الشريك):"
										}), (() => {
											const u5 = getCore5Dimensions();
											const m5 = selectedMemberToCompare.dimensionScores;
											return [
												{
													label: "الانبساط والحيوية الاجتماعية",
													u: u5.extraversion,
													m: m5.extraversion
												},
												{
													label: "الاستقرار الانفعالي وقوة الأنا",
													u: u5.emotionalStability,
													m: m5.emotionalStability
												},
												{
													label: "الانفتاح الفكري والتطوير",
													u: u5.openness,
													m: m5.openness
												},
												{
													label: "التعاطف والوفاق العلائقي",
													u: u5.agreeableness,
													m: m5.agreeableness
												},
												{
													label: "اليقظة والضمير والتنظيم",
													u: u5.conscientiousness,
													m: m5.conscientiousness
												}
											].map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-2.5 rounded-xl bg-black/40 border border-white/10 text-xs space-y-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-between font-bold text-white",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: r.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "font-mono text-[11px] text-purple-300",
														children: [
															"أنت: ",
															r.u,
															"% | الطرف الآخر: ",
															r.m,
															"% (الفرق: ",
															Math.abs(r.u - r.m),
															"%)"
														]
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "grid grid-cols-2 gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "h-1.5 bg-white/10 rounded-full overflow-hidden",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "h-full bg-purple-500 rounded-full",
															style: { width: `${r.u}%` }
														})
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "h-1.5 bg-white/10 rounded-full overflow-hidden",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "h-full bg-emerald-500 rounded-full",
															style: { width: `${r.m}%` }
														})
													})]
												})]
											}, i));
										})()]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-3 rounded-xl bg-white/5 border border-white/10 space-y-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-emerald-300 block",
												children: "أبرز صفاته ونقاط قوته:"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
												className: "space-y-1 text-gray-200",
												children: selectedMemberToCompare.strengths.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["• ", s] }, i))
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-3 rounded-xl bg-white/5 border border-white/10 space-y-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-amber-300 block",
												children: "تطلعاته للعش الزوجي:"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
												className: "space-y-1 text-gray-200",
												children: selectedMemberToCompare.aspirations.map((a, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["• ", a] }, i))
											})]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-end gap-2 pt-2",
										children: [onOpenLiveChat && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => {
												setSelectedMemberToCompare(null);
												onClose();
												onOpenLiveChat();
											},
											className: "px-4 py-2 rounded-xl bg-purple-600 text-white font-bold text-xs cursor-pointer",
											children: "بدء محادثة تفاعلية الآن 💬"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setSelectedMemberToCompare(null),
											className: "px-4 py-2 rounded-xl bg-white/10 text-gray-200 font-bold text-xs cursor-pointer",
											children: "إغلاق"
										})]
									})
								]
							})
						}) })
					]
				}),
				activeTab === "history" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 overflow-y-auto pr-1 space-y-4 custom-scrollbar",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-emerald-950/40 via-teal-950/30 to-blue-950/40 border border-emerald-500/30 flex flex-col sm:flex-row items-center justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5 text-center sm:text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-center sm:justify-start gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
										className: "font-black text-lg sm:text-xl text-white font-['Alexandria'] flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "w-5 h-5 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "سجل تقاريري وتطور اختباراتي (مع التتبع الزمني وPDF)" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30",
										children: "محفوظ وموثق 🔒"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-gray-300 max-w-xl",
									children: "تتبع جميع تقاريرك النفسية ومستويات التحليل (سريع، متقدم، احترافي) ومقارنات الشخصيتين، مع إعادة فتح أي تقرير كامل وتصوّر التطور الزمني."
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 shrink-0",
								children: [onOpenIntelligenceTest && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => {
										soundManager.playTap();
										onOpenIntelligenceTest();
									},
									className: "px-3 py-2 rounded-xl bg-blue-600/30 hover:bg-blue-600/50 border border-blue-400/40 text-blue-200 text-xs font-bold transition cursor-pointer shadow-sm",
									children: "+ اختبار ذكاء جديد"
								}), onOpenPsychologyTests && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => {
										soundManager.playTap();
										onOpenPsychologyTests();
									},
									className: "px-3 py-2 rounded-xl bg-emerald-600/30 hover:bg-emerald-600/50 border border-emerald-400/40 text-emerald-200 text-xs font-bold transition cursor-pointer shadow-sm",
									children: "+ اختبار نفسي جديد"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-3 gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3.5 rounded-2xl bg-black/40 border border-white/10 flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-purple-300 shrink-0",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "w-5 h-5" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[11px] text-gray-400 block font-bold",
										children: "إجمالي الاختبارات المحفوظة"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-lg font-black text-white font-mono",
										children: [testHistory.length, " اختبار"]
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3.5 rounded-2xl bg-black/40 border border-white/10 flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-300 shrink-0",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartColumn, { className: "w-5 h-5" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[11px] text-gray-400 block font-bold",
										children: "متوسط الاتزان والأداء السيكومتري"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-lg font-black text-emerald-400 font-mono",
										children: [testHistory.length > 0 ? Math.round(testHistory.reduce((acc, curr) => acc + (curr.percentage || 0), 0) / testHistory.length) : cattellReport.totalScore, "%"]
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3.5 rounded-2xl bg-black/40 border border-white/10 flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "w-10 h-10 rounded-xl bg-blue-500/20 border border-blue-500/30 flex items-center justify-center text-blue-300 shrink-0",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "w-5 h-5" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[11px] text-gray-400 block font-bold",
										children: "حالة المزامنة والخصوصية"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-bold text-blue-300",
										children: user ? "سحابي ومحمي (Firebase)" : "محفوظ محلياً + جلسة الزائر"
									})] })]
								})
							]
						}),
						(() => {
							const evolution = buildTemporalEvolutionSummary(testHistory);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-4 sm:p-5 rounded-3xl bg-black/45 border border-white/10 space-y-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
											className: "font-extrabold text-sm text-white flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "w-4 h-4 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "منحنى تتبع التغير مع الزمن (العام الماضي ← الشهر الماضي ← اليوم)" })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] text-gray-300 mt-0.5",
											children: evolution.trendInsightAr
										})] }), onOpenCoupleInvite && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => {
												soundManager.playTap();
												onOpenCoupleInvite();
											},
											className: "px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition cursor-pointer",
											children: "مقارنة شخصيتين من سجل تقاريري ⚖️"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-3 gap-2 text-xs",
										children: evolution.buckets.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-2.5 rounded-xl bg-white/5 border border-white/10 text-center",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-[11px] text-gray-400 font-bold",
													children: b.periodLabelAr
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-lg font-black text-emerald-400 tabular-nums",
													children: b.count > 0 ? `${b.avgScore}%` : "—"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "text-[10px] text-gray-400",
													children: [b.count, " اختبار"]
												})
											]
										}, b.periodKey))
									}),
									testHistory.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "w-full h-52 ltr-preserve",
										dir: "ltr",
										"data-keep-dir": "true",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
											width: "100%",
											height: "100%",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
												data: evolution.buckets,
												margin: {
													top: 8,
													right: 16,
													left: -12,
													bottom: 4
												},
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, { stroke: "rgba(255,255,255,0.08)" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
														dataKey: "periodLabelAr",
														tick: {
															fill: "#cbd5e1",
															fontSize: 11
														}
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
														domain: [0, 100],
														tick: {
															fill: "#cbd5e1",
															fontSize: 10
														}
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
														backgroundColor: "#0f172a",
														border: "1px solid rgba(139,92,246,0.45)",
														borderRadius: "12px",
														color: "#f8fafc",
														fontSize: "12px"
													} }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, { wrapperStyle: { fontSize: "11px" } }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
														type: "monotone",
														dataKey: "avgScore",
														name: "المعدل العام %",
														stroke: "#10b981",
														strokeWidth: 2.5,
														dot: { r: 4 }
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
														type: "monotone",
														dataKey: "emotionalAvg",
														name: "النضج النفسي %",
														stroke: "#ec4899",
														strokeWidth: 2
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
														type: "monotone",
														dataKey: "relationalAvg",
														name: "التوافق العلائقي %",
														stroke: "#8b5cf6",
														strokeWidth: 2
													})
												]
											})
										})
									})
								]
							});
						})(),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-3 gap-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative sm:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "w-4 h-4 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									"aria-label": "ابحث في سجل تقاريري",
									placeholder: "ابحث باسم الاختبار، النمط السيكومتري، أو المستوى...",
									value: historySearchQuery,
									onChange: (e) => setHistorySearchQuery(e.target.value),
									className: "w-full pr-9 pl-3 py-2 rounded-xl bg-black/40 border border-white/15 text-xs text-white placeholder-gray-400 focus:outline-none focus:border-purple-400"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								"aria-label": "تصفية حسب مستوى التحليل",
								value: historyTierFilter,
								onChange: (e) => setHistoryTierFilter(e.target.value),
								className: "px-3 py-2 rounded-xl bg-black/40 border border-white/15 text-xs text-white focus:outline-none focus:border-purple-400",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "all",
										children: "كل مستويات التحليل"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "quick",
										children: "التحليل السريع (32)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "advanced",
										children: "التحليل المتقدم (144)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "professional",
										children: "التحليل الاحترافي (288)"
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none text-xs font-bold",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-gray-400 text-xs shrink-0 flex items-center gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { className: "w-3.5 h-3.5" }), " تصنيف:"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => setHistoryFilter("all"),
									className: `px-3 py-1.5 rounded-xl transition cursor-pointer shrink-0 ${historyFilter === "all" ? "bg-white/20 text-white font-black" : "bg-white/5 text-gray-400 hover:text-white"}`,
									children: [
										"الكل (",
										testHistory.length,
										")"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => setHistoryFilter("tiered_assessment"),
									className: `px-3 py-1.5 rounded-xl transition cursor-pointer shrink-0 ${historyFilter === "tiered_assessment" ? "bg-indigo-600 text-white font-black" : "bg-white/5 text-gray-400 hover:text-white"}`,
									children: [
										"التحليل متعدد المستويات (",
										testHistory.filter((t) => t.testType === "tiered_assessment").length,
										")"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => setHistoryFilter("personality_comparison"),
									className: `px-3 py-1.5 rounded-xl transition cursor-pointer shrink-0 ${historyFilter === "personality_comparison" ? "bg-teal-600 text-white font-black" : "bg-white/5 text-gray-400 hover:text-white"}`,
									children: [
										"مقارنة شخصيتين (",
										testHistory.filter((t) => t.testType === "personality_comparison").length,
										")"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => setHistoryFilter("intelligence"),
									className: `px-3 py-1.5 rounded-xl transition cursor-pointer shrink-0 ${historyFilter === "intelligence" ? "bg-blue-600 text-white font-black" : "bg-white/5 text-gray-400 hover:text-white"}`,
									children: [
										"اختبارات الذكاء (",
										testHistory.filter((t) => t.testType === "intelligence").length,
										")"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => setHistoryFilter("psychology"),
									className: `px-3 py-1.5 rounded-xl transition cursor-pointer shrink-0 ${historyFilter === "psychology" ? "bg-emerald-600 text-white font-black" : "bg-white/5 text-gray-400 hover:text-white"}`,
									children: [
										"المقاييس النفسية (",
										testHistory.filter((t) => t.testType === "psychology").length,
										")"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => setHistoryFilter("partner_compatibility"),
									className: `px-3 py-1.5 rounded-xl transition cursor-pointer shrink-0 ${historyFilter === "partner_compatibility" ? "bg-purple-600 text-white font-black" : "bg-white/5 text-gray-400 hover:text-white"}`,
									children: [
										"توافق الشريك (",
										testHistory.filter((t) => t.testType === "partner_compatibility").length,
										")"
									]
								})
							]
						}),
						loadingHistory ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-3 pt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkeletonLoader, {
								type: "history_card",
								count: 3
							})
						}) : testHistory.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-8 rounded-3xl bg-black/30 border border-white/10 text-center space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-14 h-14 mx-auto rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-gray-400",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "w-7 h-7 text-purple-400" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: "font-bold text-base text-white",
										children: "لا توجد اختبارات مسجلة حتى الآن"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-gray-400 max-w-md mx-auto",
										children: "ابدأ رحلتك المعرفية الآن بإجراء أحد اختبارات الذكاء أو مقاييس الشخصية المعتمدة أو مستويات التحليل؛ ليتم حفظ سجلك الشخصي وتحميل تقاريرك بصيغة PDF."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center justify-center gap-2 pt-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => {
												soundManager.playTap();
												setActiveTab("cattell_16pf");
												setIsTaking16PFInline(true);
											},
											className: "px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition cursor-pointer",
											children: "📊 إجراء مقياس كاتل 16PF الآن"
										}),
										onOpenIntelligenceTest && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => {
												soundManager.playTap();
												onOpenIntelligenceTest();
											},
											className: "px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition cursor-pointer",
											children: "💡 اختبارات الذكاء المعتمدة"
										}),
										onOpenPsychologyTests && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => {
												soundManager.playTap();
												onOpenPsychologyTests();
											},
											className: "px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition cursor-pointer",
											children: "🧠 مقاييس الشخصية ومستويات التحليل"
										})
									]
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-3 pt-1",
							children: testHistory.filter((rec) => historyFilter === "all" ? true : rec.testType === historyFilter).filter((rec) => historyTierFilter === "all" ? true : rec.analysisTier === historyTierFilter).filter((rec) => {
								const q = historySearchQuery.trim().toLowerCase();
								if (!q) return true;
								return rec.testTitleAr.toLowerCase().includes(q) || rec.scoreOrArchetype.toLowerCase().includes(q) || rec.testCategoryAr.toLowerCase().includes(q);
							}).map((rec) => {
								const dateFormatted = new Date(rec.createdAt).toLocaleDateString("ar-SA", {
									year: "numeric",
									month: "long",
									day: "numeric",
									hour: "2-digit",
									minute: "2-digit"
								});
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 sm:p-5 rounded-2xl bg-black/40 border border-white/10 hover:border-white/20 transition-all space-y-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-start justify-between gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border",
												style: {
													backgroundColor: `${rec.badgeColor || "#059669"}20`,
													borderColor: `${rec.badgeColor || "#059669"}50`,
													color: rec.badgeColor || "#059669"
												},
												children: rec.testType === "intelligence" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-5 h-5" }) : rec.testType === "psychology" || rec.testType === "tiered_assessment" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "w-5 h-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "w-5 h-5" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2 flex-wrap",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
													className: "font-extrabold text-sm sm:text-base text-white font-['Alexandria']",
													children: rec.testTitleAr
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[11px] text-gray-300 font-semibold",
													children: rec.testCategoryAr
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[11px] text-gray-400 flex items-center gap-1.5 mt-0.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "w-3 h-3 text-gray-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: dateFormatted })]
											})] })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap items-center gap-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "px-3 py-1 rounded-xl text-xs font-black shrink-0 border tabular-nums",
													style: {
														backgroundColor: `${rec.badgeColor || "#059669"}25`,
														borderColor: `${rec.badgeColor || "#059669"}40`,
														color: rec.badgeColor || "#34d399"
													},
													children: rec.scoreOrArchetype
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													onClick: () => {
														soundManager.playTap();
														setReopenedRecord(rec);
													},
													className: "px-3 py-1.5 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/35 border border-indigo-400/40 text-indigo-200 text-xs font-bold transition flex items-center gap-1 cursor-pointer",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "فتح التقرير الكامل" })]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													onClick: () => handleDownloadHistoryRecordPDF(rec),
													className: "px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/35 border border-amber-400/40 text-amber-200 text-xs font-bold transition flex items-center gap-1 cursor-pointer",
													title: "تحميل هذا التقرير بصيغة PDF",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileDown, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تحميل PDF" })]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => handleDeleteHistoryItem(rec.id),
													disabled: deletingId === rec.id,
													"aria-label": "حذف هذا السجل",
													title: "حذف هذا السجل",
													className: "p-2 rounded-xl bg-white/5 hover:bg-rose-500/20 text-gray-400 hover:text-rose-300 transition cursor-pointer",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "w-4 h-4" })
												})
											]
										})]
									}), rec.keyInsights && rec.keyInsights.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex flex-wrap gap-1.5 pt-1",
										children: rec.keyInsights.map((ins, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[11px] px-2.5 py-0.5 rounded-lg bg-white/5 text-gray-300 border border-white/10",
											children: ["✓ ", ins]
										}, i))
									})]
								}, rec.id);
							})
						}),
						reopenedRecord && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "fixed inset-0 z-[70] flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md overflow-y-auto",
							dir: "rtl",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "w-full max-w-4xl rounded-3xl bg-slate-900 border border-white/20 p-5 sm:p-7 space-y-5 max-h-[90vh] overflow-y-auto text-white shadow-2xl",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start justify-between gap-3 pb-3 border-b border-white/10",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-xs text-purple-300 font-bold",
												children: [
													reopenedRecord.testCategoryAr,
													" · ",
													new Date(reopenedRecord.createdAt).toLocaleDateString("ar-JO")
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-lg sm:text-xl font-black font-['Alexandria'] mt-0.5",
												children: reopenedRecord.testTitleAr
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-sm font-extrabold text-emerald-400 mt-1",
												children: reopenedRecord.scoreOrArchetype
											})
										] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 shrink-0",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => handleDownloadHistoryRecordPDF(reopenedRecord),
												className: "px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-extrabold cursor-pointer flex items-center gap-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileDown, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "PDF" })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setReopenedRecord(null),
												"aria-label": "إغلاق التقرير المحفوظ",
												className: "p-2 rounded-full bg-white/10 hover:bg-white/20 text-white cursor-pointer",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-5 h-5" })
											})]
										})]
									}),
									reopenedRecord.snapshot?.executiveSummaryAr && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-4 rounded-2xl bg-white/5 border border-white/10 text-xs sm:text-sm leading-relaxed space-y-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: reopenedRecord.snapshot.executiveSummaryAr }),
											reopenedRecord.snapshot.personalityDescriptionAr && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-slate-300",
												children: reopenedRecord.snapshot.personalityDescriptionAr
											}),
											reopenedRecord.snapshot.valuesAndBeliefsAr && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-purple-200",
												children: reopenedRecord.snapshot.valuesAndBeliefsAr
											})
										]
									}),
									reopenedRecord.keyInsights && reopenedRecord.keyInsights.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-4 rounded-2xl bg-emerald-950/30 border border-emerald-500/25 space-y-1.5 text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-extrabold text-emerald-300",
											children: "أبرز المؤشرات المستخلصة:"
										}), reopenedRecord.keyInsights.map((k, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["• ", k] }, idx))]
									}),
									reopenedRecord.snapshot?.visualCharts && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
										fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "p-6 text-center text-xs text-slate-300",
											children: "جارٍ تحميل الرسوم البيانية المحفوظة..."
										}),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LazyScientificVisualDashboards, {
											charts: reopenedRecord.snapshot.visualCharts,
											userName: reopenedRecord.snapshot.userName || userName
										})
									}),
									reopenedRecord.testType === "personality_comparison" && reopenedRecord.snapshot?.nineAxesBreakdown && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "space-y-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs",
											children: (reopenedRecord.snapshot.subIndices || []).map((sub) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-3 rounded-xl bg-white/5 border border-white/10",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex justify-between font-bold",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: sub.titleAr }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-emerald-400 tabular-nums",
														children: [sub.score, "%"]
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-[11px] text-slate-300 mt-1",
													children: sub.interpretationAr
												})]
											}, sub.key))
										})
									})
								]
							})
						})
					]
				}),
				activeTab === "share" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 overflow-y-auto pr-1 space-y-4 custom-scrollbar",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-5 rounded-3xl bg-black/30 border border-white/10 space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "font-extrabold text-sm sm:text-base text-white flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "w-4 h-4 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "نشر ومشاركة ملفي الشخصي عبر رابط مخصص" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-gray-300 mt-0.5",
								children: "يمكنك مشاركة نتائج اختبارك، صفاتك السلوكية، اهتماماتك، وتطلعاتك ومواصفات شريكك المناسب مع الآخرين"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => handleTogglePublic(!isPublic),
								className: `relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${isPublic ? "bg-emerald-500" : "bg-gray-700"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${isPublic ? "-translate-x-6" : "-translate-x-1"}` })
							})]
						}), isPublic ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3 pt-2 border-t border-white/10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 p-2 rounded-2xl bg-black/40 border border-emerald-500/30",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									readOnly: true,
									value: publicProfileUrl,
									className: "bg-transparent text-xs text-emerald-200 font-mono flex-1 outline-none px-2 select-all overflow-ellipsis"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: handleCopyLink,
									className: `px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition cursor-pointer shrink-0 shadow-sm ${copiedLink ? "bg-emerald-500 text-white" : "bg-purple-600 hover:bg-purple-700 text-white"}`,
									children: copiedLink ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تم النسخ!" })] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "نسخ الرابط" })] })
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-bold text-gray-300 block",
									children: "مشاركة مباشرة على منصات السوشيل ميديا:"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 sm:grid-cols-5 gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: () => openExternalShareUrl(`https://api.whatsapp.com/send?text=${encodeURIComponent(shareText)}`),
											className: "py-2 px-3 rounded-xl bg-emerald-600/30 hover:bg-emerald-600/40 border border-emerald-500/40 text-emerald-300 text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "w-3.5 h-3.5 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "واتساب" })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => openExternalShareUrl(`https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}`),
											className: "py-2 px-3 rounded-xl bg-sky-500/20 hover:bg-sky-500/30 border border-sky-400/30 text-sky-200 text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "𝕏 تويتر" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: () => openExternalShareUrl(`https://t.me/share/url?url=${encodeURIComponent(publicProfileUrl)}&text=${encodeURIComponent(shareText)}`),
											className: "py-2 px-3 rounded-xl bg-blue-500/20 hover:bg-blue-500/30 border border-blue-400/30 text-blue-200 text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "w-3.5 h-3.5 text-blue-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تليجرام" })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => openExternalShareUrl(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(publicProfileUrl)}`),
											className: "py-2 px-3 rounded-xl bg-indigo-600/25 hover:bg-indigo-600/35 border border-indigo-500/30 text-indigo-200 text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "فيسبوك" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: () => openExternalShareUrl(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(publicProfileUrl)}`),
											className: "py-2 px-3 rounded-xl bg-blue-700/25 hover:bg-blue-700/35 border border-blue-600/30 text-blue-200 text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Linkedin, { className: "w-3.5 h-3.5 text-blue-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "لينكد إن" })]
										})
									]
								})]
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-3 rounded-2xl bg-white/5 border border-white/10 text-xs text-gray-400 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "w-4 h-4 text-gray-500 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "ملفك الشخصي حالياً خاص ومحمي ولا يظهر للآخرين إلا عند تفعيل خيار النشر أعلاه." })]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-5 sm:p-6 rounded-3xl bg-gradient-to-tr from-[#16102a] via-[#1f1538] to-[#120d20] border border-white/15 shadow-xl space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between pb-2 border-b border-white/10",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-gray-400 font-bold",
									children: "معاينة بطاقة ملفك العامة للآخرين:"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] px-2.5 py-0.5 rounded-full bg-purple-500/20 text-purple-300 font-bold border border-purple-500/30",
									children: "Public Social Preview"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-14 h-14 rounded-2xl bg-gradient-to-tr from-purple-500 via-pink-500 to-rose-500 flex items-center justify-center text-white text-xl font-bold shadow-lg",
									children: userName.charAt(0)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: "font-extrabold text-base sm:text-lg text-white font-['Alexandria']",
										children: userName
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-rose-300 font-semibold",
										children: cattellReport.isCompleted ? cattellReport.primaryArchetypeAr : report.primaryArchetypeAr
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[11px] text-gray-400",
										children: [
											country,
											" • ",
											userAge,
											" سنة"
										]
									})
								] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3.5 rounded-2xl bg-black/40 border border-white/10 text-xs text-gray-300 space-y-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "text-purple-300 block text-xs",
										children: "مواصفات الشريك المناسب حسب اختياراتك:"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: questionnaire.partnerCorePersonalityType }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "pt-2 flex flex-wrap gap-1.5",
										children: questionnaire.partnerEssentialTraits.slice(0, 3).map((tr, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[10px] px-2 py-0.5 rounded-full bg-white/5 border border-white/10 text-gray-300",
											children: ["✓ ", tr]
										}, i))
									})
								]
							})
						]
					})]
				})
			]
		})
	});
};
//#endregion
export { UserProfileDashboard };
