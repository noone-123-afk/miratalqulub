const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/userHistoryService-6N9Zh8ed.js","assets/rolldown-runtime-Bk_YeHJf.js","assets/vendor-react-Bm_EF59R.js","assets/firebaseAuth-D6LKvzXg.js","assets/firebase-Cu7XUsbK.js"])))=>i.map(i=>d[i]);
import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { n as __vitePreload, o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { Ot as Languages, P as ShieldCheck, S as Sun, _t as Mail, an as Compass, h as Trash2, jt as Info, l as User, mn as CircleCheck, p as TriangleAlert, st as Moon } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import { d as useAppTheme, l as useLanguage, s as OFFICIAL_LOGO_URL, u as useAuth } from "./index-C5uCeetQ.js";
//#region src/components/Footer.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var Footer = ({ currentPage = "home", onNavigatePage, onResetHome, onOpenBlindDate, onOpenPsychologyTests, onOpenIntelligenceTests, onOpenUserDashboard, onOpenHistory, onOpenArticles, onOpenNovels, onOpenCoupleInvite, onOpenDomainHosting, onOpenAdSense, onOpenAnalytics, onDataDeleted }) => {
	const { language, toggleLanguage, t } = useLanguage();
	const { user, isOwner } = useAuth();
	const [theme, toggleTheme] = useAppTheme();
	const isAr = language === "ar";
	const isLight = theme === "light";
	const [confirmDelete, setConfirmDelete] = (0, import_react.useState)(false);
	const [isDeleting, setIsDeleting] = (0, import_react.useState)(false);
	const [deleteSuccess, setDeleteSuccess] = (0, import_react.useState)(false);
	const handlePermanentDelete = async () => {
		soundManager.playTap();
		setIsDeleting(true);
		try {
			const { purgeAllUserDataPermanently } = await __vitePreload(async () => {
				const { purgeAllUserDataPermanently } = await import("./userHistoryService-6N9Zh8ed.js").then((n) => n.p);
				return { purgeAllUserDataPermanently };
			}, __vite__mapDeps([0,1,2,3,4]));
			await purgeAllUserDataPermanently(user);
			setIsDeleting(false);
			setConfirmDelete(false);
			setDeleteSuccess(true);
			if (onDataDeleted) onDataDeleted();
			onResetHome();
			setTimeout(() => setDeleteSuccess(false), 3500);
		} catch {
			setIsDeleting(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		dir: isAr ? "rtl" : "ltr",
		className: `w-full border-t pt-12 pb-8 text-xs transition-colors duration-300 ${isLight ? "bg-slate-100/95 border-slate-200 text-slate-700" : "bg-[#08060f]/95 border-white/10 text-slate-300 backdrop-blur-md"}`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-7xl mx-auto px-4 sm:px-6 space-y-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `p-5 sm:p-6 rounded-3xl border flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 ${isLight ? "bg-white border-slate-200/90 shadow-sm" : "bg-slate-900/75 border-white/10 shadow-xl"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2 max-w-2xl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-11 h-11 rounded-2xl p-0.5 bg-gradient-to-tr from-rose-500 via-pink-500 to-violet-600 shadow-md shadow-rose-500/20 shrink-0 overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: OFFICIAL_LOGO_URL,
									alt: isAr ? "شعار مرآة القلوب" : "Mirror of Hearts Logo",
									width: 44,
									height: 44,
									loading: "lazy",
									decoding: "async",
									referrerPolicy: "no-referrer",
									className: "w-full h-full object-cover rounded-[14px]"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `font-extrabold text-base sm:text-lg font-['Alexandria'] ${isLight ? "text-slate-900" : "text-white"}`,
								children: isAr ? "مِـرآة القـلوب | Mirror of Hearts (miratalqulub.com)" : "Mirror of Hearts | مرآة القلوب (miratalqulub.com)"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: `text-xs leading-relaxed ${isLight ? "text-slate-600" : "text-slate-300"}`,
							children: isAr ? "منصة عربية مستقلة رائدة تعتمد على المقاييس السيكومترية الموثقة بمراجع APA، واختبارات الذكاء المتعدد، وتحليل التوافق الفكري والعاطفي، مع واحة معرفية شاملة للمقالات والأبحاث والروايات الأدبية." : "An independent platform integrating APA-referenced psychometric inventories, multiple intelligences batteries, and relational compatibility algorithms with a comprehensive literary and academic knowledge oasis."
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `w-full lg:w-auto min-w-[300px] p-4 rounded-2xl border space-y-3 ${isLight ? "bg-violet-50/70 border-violet-200" : "bg-violet-950/25 border-violet-500/30"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "w-4 h-4 text-violet-500 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `font-extrabold text-xs sm:text-sm font-['Alexandria'] ${isLight ? "text-violet-950" : "text-violet-200"}`,
										children: isAr ? "ملفي والتحكم الشخصي بالبيانات" : "My Profile & Personal Data Control"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											soundManager.playTap();
											toggleLanguage();
										},
										"aria-label": isAr ? "تغيير اللغة إلى الإنجليزية" : "Switch language to Arabic",
										title: isAr ? "تغيير اللغة إلى الإنجليزية" : "Switch language to Arabic",
										className: `px-2 py-1 rounded-lg border text-[11px] font-bold cursor-pointer flex items-center gap-1 ${isLight ? "bg-white border-slate-200 text-sky-700" : "bg-slate-900 border-white/10 text-sky-300"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Languages, { className: "w-3 h-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "EN" : "AR" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => {
											soundManager.playTap();
											toggleTheme();
										},
										"aria-label": theme === "dark" ? isAr ? "تفعيل الوضع النهاري" : "Switch to Light Mode" : isAr ? "تفعيل الوضع الليلي" : "Switch to Dark Mode",
										title: theme === "dark" ? isAr ? "تفعيل الوضع النهاري" : "Switch to Light Mode" : isAr ? "تفعيل الوضع الليلي" : "Switch to Dark Mode",
										className: `px-2 py-1 rounded-lg border text-[11px] font-bold cursor-pointer flex items-center gap-1 ${isLight ? "bg-white border-slate-200 text-amber-700" : "bg-slate-900 border-white/10 text-amber-300"}`,
										children: theme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "w-3 h-3" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "w-3 h-3" })
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										soundManager.playTap();
										onOpenUserDashboard();
									},
									className: "px-3.5 py-2 rounded-xl bg-gradient-to-r from-violet-700 to-rose-700 hover:from-violet-600 hover:to-rose-600 text-white font-extrabold text-xs transition cursor-pointer shadow-sm flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "فتح لوحة ملفي وسجلاتي" : "Open My Profile & Dossier" })]
								}), !confirmDelete && !deleteSuccess && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										soundManager.playTap();
										setConfirmDelete(true);
									},
									className: `px-3 py-2 rounded-xl border font-bold text-xs transition cursor-pointer flex items-center gap-1.5 ${isLight ? "bg-rose-50 hover:bg-rose-100 border-rose-300 text-rose-800" : "bg-rose-500/20 hover:bg-rose-500/30 border-rose-500/40 text-rose-200"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "w-3.5 h-3.5 text-rose-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "حذف بياناتي نهائياً" : "Delete Data Permanently" })]
								})]
							}),
							deleteSuccess && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `p-2.5 rounded-xl border text-xs font-bold flex items-center gap-2 ${isLight ? "bg-emerald-50 border-emerald-300 text-emerald-900" : "bg-emerald-500/20 border-emerald-500/40 text-emerald-200"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-4 h-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "تم مسح جميع بياناتك وسجلاتك المحلية والسحابية نهائياً." : "All local and cloud records have been permanently deleted." })]
							}),
							confirmDelete && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `p-3 rounded-xl border space-y-2 ${isLight ? "bg-rose-50 border-rose-300 text-rose-950" : "bg-rose-950/60 border-rose-500/50 text-rose-100"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start gap-2 text-[11px] leading-relaxed",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "w-4 h-4 text-rose-500 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "تأكيد الحذف النهائي: سيتم مسح ملفك الشخصي وجميع نتائج اختباراتك من المتصفح والسحابة فوراً دون إمكانية الاسترجاع." : "Confirm permanent deletion: Your profile and all test records will be immediately erased from browser and cloud storage." })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										disabled: isDeleting,
										onClick: handlePermanentDelete,
										className: "px-3 py-1.5 rounded-lg bg-rose-700 hover:bg-rose-600 disabled:bg-rose-800 disabled:opacity-80 text-white font-extrabold text-xs cursor-pointer",
										children: isDeleting ? isAr ? "جاري المسح..." : "Deleting..." : isAr ? "تأكيد الحذف النهائي" : "Confirm Permanent Delete"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setConfirmDelete(false),
										className: `px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${isLight ? "bg-white border border-slate-300 text-slate-700" : "bg-slate-800 text-slate-300"}`,
										children: isAr ? "تراجع" : "Cancel"
									})]
								})]
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `p-6 sm:p-8 rounded-3xl border transition-all duration-300 ${isLight ? "bg-white border-slate-200/90 shadow-sm" : "bg-slate-900/60 border-white/10 shadow-lg"}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 md:grid-cols-3 gap-8 text-start",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `w-8 h-8 rounded-xl flex items-center justify-center border ${isLight ? "bg-indigo-50 border-indigo-200 text-indigo-700" : "bg-indigo-500/15 border-indigo-500/30 text-indigo-300"}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "w-4 h-4" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: `font-black text-sm font-['Alexandria'] ${isLight ? "text-slate-900" : "text-white"}`,
										children: isAr ? "روابط الموقع" : "Site Links"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
									className: "space-y-2.5 text-xs font-bold",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => {
												soundManager.playTap();
												onNavigatePage("home");
												onResetHome();
											},
											className: `transition cursor-pointer flex items-center gap-2 ${currentPage === "home" ? isLight ? "text-indigo-800" : "text-indigo-300" : isLight ? "text-slate-700 hover:text-indigo-800" : "text-slate-200 hover:text-indigo-300"}`,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "الرئيسية" : "Home" })
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => {
												soundManager.playTap();
												onNavigatePage("personality-tests");
											},
											className: `transition cursor-pointer flex items-center gap-2 ${currentPage === "personality-tests" ? isLight ? "text-indigo-800" : "text-indigo-300" : isLight ? "text-slate-700 hover:text-indigo-800" : "text-slate-200 hover:text-indigo-300"}`,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "قسم تحليل الشخصية" : "Personality Analysis" })
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => {
												soundManager.playTap();
												onNavigatePage("compatibility");
											},
											className: `transition cursor-pointer flex items-center gap-2 ${currentPage === "compatibility" ? isLight ? "text-indigo-800" : "text-indigo-300" : isLight ? "text-slate-700 hover:text-indigo-800" : "text-slate-200 hover:text-indigo-300"}`,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "قسم كاشف شريك الحياة" : "Partner Compatibility Detector" })
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => {
												soundManager.playTap();
												onOpenIntelligenceTests();
											},
											className: `transition cursor-pointer flex items-center gap-2 ${isLight ? "text-slate-700 hover:text-indigo-600" : "text-slate-200 hover:text-indigo-300"}`,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "قسم اختبارات الذكاء" : "Intelligence Tests" })
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => {
												soundManager.playTap();
												onNavigatePage("articles");
											},
											className: `transition cursor-pointer flex items-center gap-2 ${currentPage === "articles" ? isLight ? "text-indigo-800" : "text-indigo-300" : isLight ? "text-slate-700 hover:text-indigo-800" : "text-slate-200 hover:text-indigo-300"}`,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "قسم المقالات المعرفية والأبحاث" : "Articles & Research" })
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => {
												soundManager.playTap();
												onNavigatePage("novels");
											},
											className: `transition cursor-pointer flex items-center gap-2 ${currentPage === "novels" ? isLight ? "text-indigo-800" : "text-indigo-300" : isLight ? "text-slate-700 hover:text-indigo-800" : "text-slate-200 hover:text-indigo-300"}`,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "قسم الروايات والقصص" : "Novels & Stories" })
										}) })
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `w-8 h-8 rounded-xl flex items-center justify-center border ${isLight ? "bg-purple-50 border-purple-200 text-purple-700" : "bg-purple-500/15 border-purple-500/30 text-purple-300"}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "w-4 h-4" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: `font-black text-sm font-['Alexandria'] ${isLight ? "text-slate-900" : "text-white"}`,
										children: isAr ? "معلومات المنصة" : "Platform Info"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
									className: "space-y-2.5 text-xs font-bold",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => {
												soundManager.playTap();
												onNavigatePage("about");
											},
											className: `transition cursor-pointer flex items-center gap-2 ${currentPage === "about" ? "text-purple-600" : isLight ? "text-slate-700 hover:text-purple-600" : "text-slate-200 hover:text-purple-300"}`,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "من نحن (About Us)" : "About Us" })
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => {
												soundManager.playTap();
												onNavigatePage("methodology");
											},
											className: `transition cursor-pointer flex items-center gap-2 ${currentPage === "methodology" ? "text-purple-600" : isLight ? "text-slate-700 hover:text-purple-600" : "text-slate-200 hover:text-purple-300"}`,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "المنهجية العلمية والمصادر (APA)" : "Scientific Methodology & APA Sources" })
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => {
												soundManager.playTap();
												onNavigatePage("how-results-are-calculated");
											},
											className: `transition cursor-pointer flex items-center gap-2 ${currentPage === "how-results-are-calculated" ? isLight ? "text-purple-800" : "text-purple-300" : isLight ? "text-slate-700 hover:text-purple-800" : "text-slate-200 hover:text-purple-300"}`,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "كيف يتم حساب نتائج الاختبارات؟ (Big Five • HEXACO • Attachment • EQ)" : "How Are Test Results Calculated? (Big Five • HEXACO • Attachment • EQ)" })
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => {
												soundManager.playTap();
												onNavigatePage("how-it-works");
											},
											className: `transition cursor-pointer flex items-center gap-2 ${currentPage === "how-it-works" ? "text-purple-600" : isLight ? "text-slate-700 hover:text-purple-600" : "text-slate-200 hover:text-purple-300"}`,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "كيف تعمل خوارزمية التوافق؟" : "How the Compatibility Engine Works" })
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => {
												soundManager.playTap();
												onNavigatePage("faq");
											},
											className: `transition cursor-pointer flex items-center gap-2 ${currentPage === "faq" ? "text-purple-600" : isLight ? "text-slate-700 hover:text-purple-600" : "text-slate-200 hover:text-purple-300"}`,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "الأسئلة الشائعة (FAQ)" : "Frequently Asked Questions" })
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => {
												soundManager.playTap();
												onNavigatePage("contact");
											},
											className: `transition cursor-pointer flex items-center gap-2 ${currentPage === "contact" ? "text-purple-600" : isLight ? "text-slate-700 hover:text-purple-600" : "text-slate-200 hover:text-purple-300"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "w-3.5 h-3.5 text-sky-500 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "اتصل بنا (Contact Us)" : "Contact Us" })]
										}) })
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `w-8 h-8 rounded-xl flex items-center justify-center border ${isLight ? "bg-emerald-50 border-emerald-200 text-emerald-700" : "bg-emerald-500/15 border-emerald-500/30 text-emerald-300"}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "w-4 h-4" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: `font-black text-sm font-['Alexandria'] ${isLight ? "text-slate-900" : "text-white"}`,
										children: isAr ? "القانونية والخصوصية" : "Legal & Privacy"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
									className: "space-y-2.5 text-xs font-bold",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => {
												soundManager.playTap();
												onNavigatePage("privacy");
											},
											className: `transition cursor-pointer flex items-center gap-2 ${currentPage === "privacy" ? isLight ? "text-emerald-800" : "text-emerald-300" : isLight ? "text-slate-700 hover:text-emerald-800" : "text-slate-200 hover:text-emerald-300"}`,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "سياسة الخصوصية (Privacy Policy)" : "Privacy Policy" })
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => {
												soundManager.playTap();
												onNavigatePage("terms");
											},
											className: `transition cursor-pointer flex items-center gap-2 ${currentPage === "terms" ? isLight ? "text-emerald-800" : "text-emerald-300" : isLight ? "text-slate-700 hover:text-emerald-800" : "text-slate-200 hover:text-emerald-300"}`,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "شروط الاستخدام (Terms of Service)" : "Terms of Service" })
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => {
												soundManager.playTap();
												onNavigatePage("disclaimer");
											},
											className: `transition cursor-pointer flex items-center gap-2 ${currentPage === "disclaimer" ? isLight ? "text-amber-800" : "text-amber-300" : isLight ? "text-slate-700 hover:text-amber-800" : "text-slate-200 hover:text-amber-300"}`,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "إخلاء المسؤولية العلمي والقانوني" : "Clinical & Legal Disclaimer" })
										}) }),
										isOwner && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
											className: "pt-1",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => onNavigatePage("admin-cms"),
												className: `font-bold transition cursor-pointer flex items-center gap-1.5 ${isLight ? "text-amber-800 hover:text-amber-900" : "text-amber-300 hover:text-amber-200"}`,
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["🛡️ ", isAr ? "مركز إدارة المحتوى وتحميل ملفات الموقع" : "CMS & Website Files Download"] })
											})
										})
									]
								})]
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `p-4 rounded-2xl border text-xs flex items-start gap-3 ${isLight ? "bg-amber-50/90 border-amber-200 text-amber-950" : "bg-amber-500/10 border-amber-500/30 text-amber-200"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-base shrink-0",
						children: "⚠️"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-0.5 leading-relaxed",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-bold block",
							children: isAr ? "تنبيه قانوني واستشاري إلزامي:" : "Mandatory Legal & Educational Disclaimer:"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: `text-[11px] ${isLight ? "text-amber-900/90" : "text-slate-300"}`,
							children: isAr ? "النتائج، والمقاييس، والتقارير، والتحليلات المقدمة داخل موقع «مرآة القلوب» هي لأغراض معرفية وتثقيفية واستكشافية فقط، وليست استشارات نفسية أو قانونية أو طبية أو مهنية مرخصة، ولا تمثل بأي حال من الأحوال ضماناً لنجاح أو استمرار أي علاقة أو ارتباط." : "The results, assessments, and reports provided within Mirror of Hearts are strictly for educational, informational, and self-reflection purposes. They do not constitute licensed psychological, clinical, legal, or medical counseling."
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `pt-6 border-t flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] font-medium ${isLight ? "border-slate-300 text-slate-700" : "border-white/10 text-slate-300"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 flex-wrap justify-center sm:justify-start",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("footer_rights") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "تشفير قياسي TLS 1.3" : "TLS 1.3 Encrypted" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Google Cloud Platform (Europe-West1)" })
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: `flex items-center gap-1.5 font-bold ${isLight ? "text-emerald-800" : "text-emerald-300"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `w-2 h-2 rounded-full ${isLight ? "bg-emerald-700" : "bg-emerald-400"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("cloud_status") })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("ssl_verified") })]
					})]
				})
			]
		})
	});
};
//#endregion
export { Footer };
