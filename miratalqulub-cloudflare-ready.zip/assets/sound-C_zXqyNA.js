//#region src/utils/sound.ts
var SoundManager = class {
	constructor() {
		this._enabled = true;
		this.ctx = null;
	}
	getContext() {
		if (!this._enabled || typeof window === "undefined") return null;
		if (!this.ctx) {
			const AudioCtx = window.AudioContext || window.webkitAudioContext;
			if (!AudioCtx) return null;
			try {
				this.ctx = new AudioCtx();
			} catch {
				return null;
			}
		}
		if (this.ctx.state === "suspended") this.ctx.resume().catch(() => {});
		return this.ctx;
	}
	playTone(freq, duration, volume = .12, startOffset = 0, type = "sine") {
		const ctx = this.getContext();
		if (!ctx) return;
		try {
			const now = ctx.currentTime + startOffset;
			const osc = ctx.createOscillator();
			const gain = ctx.createGain();
			osc.type = type;
			osc.frequency.setValueAtTime(freq, now);
			gain.gain.setValueAtTime(1e-4, now);
			gain.gain.linearRampToValueAtTime(volume, now + .015);
			gain.gain.exponentialRampToValueAtTime(1e-4, now + duration);
			osc.connect(gain);
			gain.connect(ctx.destination);
			osc.start(now);
			osc.stop(now + duration + .02);
		} catch {}
	}
	get enabled() {
		return this._enabled;
	}
	set enabled(val) {
		this._enabled = val;
	}
	toggle() {
		this._enabled = !this._enabled;
		return this._enabled;
	}
	playPageTransition() {
		if (!this._enabled) return;
		this.playTone(698.46, .28, .08, 0);
		this.playTone(880, .32, .07, .04);
		this.playTone(1046.5, .36, .06, .08);
	}
	playNext() {
		this.playPageTransition();
	}
	playResultReveal() {
		if (!this._enabled) return;
		[
			659.25,
			830.61,
			987.77,
			1318.51,
			1661.22
		].forEach((freq, idx) => {
			this.playTone(freq, .55, .09, idx * .11);
		});
	}
	playCelebration() {
		this.playResultReveal();
	}
	playTap() {
		if (!this._enabled) return;
		this.playTone(520, .055, .07, 0);
	}
	playTab() {
		if (!this._enabled) return;
		this.playTone(784, .08, .06, 0);
	}
	playRoundPass() {
		if (!this._enabled) return;
		[
			523.25,
			659.25,
			783.99,
			1046.5
		].forEach((freq, idx) => {
			this.playTone(freq, .35, .09, idx * .1);
		});
	}
	playApplause() {
		this.playRoundPass();
	}
	playHeartbeat() {
		if (!this._enabled) return;
		this.playTone(65, .18, .18, 0);
		this.playTone(55, .22, .14, .22);
	}
};
var soundManager = new SoundManager();
//#endregion
export { soundManager as t };
