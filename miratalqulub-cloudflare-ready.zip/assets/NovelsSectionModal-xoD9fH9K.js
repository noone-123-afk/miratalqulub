import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { An as BookOpen, Ht as Flame, I as Share2, Nn as ArrowRight, On as Bookmark, Pn as ArrowLeft, V as Search, Wt as FileText, _n as ChevronRight, a as VolumeX, b as Target, bn as Check, d as UserCheck, et as Plus, h as Trash2, p as TriangleAlert, r as X, rt as PenLine, tn as Crown, ut as MessageSquare, vn as ChevronLeft } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import { l as useLanguage, u as useAuth } from "./index-C5uCeetQ.js";
import { n as AnimatePresence, t as motion } from "./vendor-motion-BS7ODJw7.js";
import { t as NOVELS_CATALOG } from "./data-content-CCe8WBeA.js";
import { n as deleteOwnerNovel, r as getAllNovels } from "./novelsService-DylA4WsJ.js";
import { t as NovelCommentsSection } from "./NovelCommentsSection-BjwcZvs9.js";
import { t as AddNovelModal } from "./AddNovelModal-CjeEf0ke.js";
//#region src/components/NovelsSectionModal.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var NovelsSectionModal = ({ isOpen, onClose, initialNovelId }) => {
	const { language, isRTL, t } = useLanguage();
	const { isOwner } = useAuth();
	const [novelsList, setNovelsList] = (0, import_react.useState)(NOVELS_CATALOG);
	const [selectedGenre, setSelectedGenre] = (0, import_react.useState)("all");
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [activeNovel, setActiveNovel] = (0, import_react.useState)(null);
	const [currentChapterIndex, setCurrentChapterIndex] = (0, import_react.useState)(0);
	const [readerTab, setReaderTab] = (0, import_react.useState)("narrative");
	const [fontSize, setFontSize] = (0, import_react.useState)(17);
	const [readerTheme, setReaderTheme] = (0, import_react.useState)("noir");
	const [copiedShare, setCopiedShare] = (0, import_react.useState)(false);
	const [savedBookmarks, setSavedBookmarks] = (0, import_react.useState)({});
	const [isAmbiencePlaying, setIsAmbiencePlaying] = (0, import_react.useState)(false);
	const [ambienceType, setAmbienceType] = (0, import_react.useState)("rain");
	const [isAddOrEditModalOpen, setIsAddOrEditModalOpen] = (0, import_react.useState)(false);
	const [novelToEdit, setNovelToEdit] = (0, import_react.useState)(null);
	const [deletingNovel, setDeletingNovel] = (0, import_react.useState)(null);
	const [isDeleting, setIsDeleting] = (0, import_react.useState)(false);
	const audioCtxRef = (0, import_react.useRef)(null);
	const ambienceNodesRef = (0, import_react.useRef)(null);
	const refreshNovels = async () => {
		try {
			const merged = await getAllNovels();
			if (merged && merged.length > 0) {
				setNovelsList(merged);
				if (activeNovel) {
					const fresh = merged.find((n) => n.id === activeNovel.id);
					if (fresh) setActiveNovel(fresh);
				}
			}
		} catch {}
	};
	(0, import_react.useEffect)(() => {
		if (isOpen) refreshNovels();
	}, [isOpen]);
	(0, import_react.useEffect)(() => {
		if (initialNovelId && novelsList.length > 0) {
			const target = novelsList.find((n) => n.id === initialNovelId);
			if (target) {
				setActiveNovel(target);
				setCurrentChapterIndex(0);
			}
		}
	}, [initialNovelId, novelsList]);
	(0, import_react.useEffect)(() => {
		try {
			const stored = localStorage.getItem("mirat_novels_bookmarks");
			if (stored) setSavedBookmarks(JSON.parse(stored));
		} catch {}
	}, []);
	(0, import_react.useEffect)(() => {
		return () => {
			stopAmbience();
		};
	}, []);
	if (!isOpen) return null;
	const startAmbience = (type) => {
		stopAmbience();
		try {
			const ctx = new (window.AudioContext || window.webkitAudioContext)();
			audioCtxRef.current = ctx;
			const masterGain = ctx.createGain();
			masterGain.gain.setValueAtTime(.08, ctx.currentTime);
			masterGain.connect(ctx.destination);
			if (type === "rain") {
				const bufferSize = ctx.sampleRate * 2;
				const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
				const data = buffer.getChannelData(0);
				let b0 = 0, b1 = 0, b2 = 0;
				for (let i = 0; i < bufferSize; i++) {
					const white = Math.random() * 2 - 1;
					b0 = .99886 * b0 + white * .0555179;
					b1 = .99332 * b1 + white * .0750759;
					b2 = .969 * b2 + white * .153852;
					data[i] = (b0 + b1 + b2) * .15;
				}
				const noiseSource = ctx.createBufferSource();
				noiseSource.buffer = buffer;
				noiseSource.loop = true;
				const filter = ctx.createBiquadFilter();
				filter.type = "lowpass";
				filter.frequency.setValueAtTime(800, ctx.currentTime);
				noiseSource.connect(filter);
				filter.connect(masterGain);
				noiseSource.start();
				ambienceNodesRef.current = {
					gain: masterGain,
					noise: noiseSource
				};
			} else if (type === "pulse") {
				const osc = ctx.createOscillator();
				osc.type = "sine";
				osc.frequency.setValueAtTime(55, ctx.currentTime);
				const lfo = ctx.createOscillator();
				lfo.type = "sine";
				lfo.frequency.setValueAtTime(1.2, ctx.currentTime);
				ctx.createGain().gain.setValueAtTime(.06, ctx.currentTime);
				lfo.connect(masterGain.gain);
				osc.connect(masterGain);
				osc.start();
				lfo.start();
				ambienceNodesRef.current = {
					osc,
					gain: masterGain
				};
			} else {
				const osc = ctx.createOscillator();
				osc.type = "sawtooth";
				osc.frequency.setValueAtTime(110, ctx.currentTime);
				const filter = ctx.createBiquadFilter();
				filter.type = "lowpass";
				filter.frequency.setValueAtTime(320, ctx.currentTime);
				osc.connect(filter);
				filter.connect(masterGain);
				osc.start();
				ambienceNodesRef.current = {
					osc,
					gain: masterGain
				};
			}
			setIsAmbiencePlaying(true);
			setAmbienceType(type);
		} catch {
			setIsAmbiencePlaying(false);
		}
	};
	const stopAmbience = () => {
		if (audioCtxRef.current) {
			try {
				audioCtxRef.current.close();
			} catch {}
			audioCtxRef.current = null;
		}
		ambienceNodesRef.current = null;
		setIsAmbiencePlaying(false);
	};
	const toggleAmbience = (type) => {
		soundManager.playTap();
		if (isAmbiencePlaying && ambienceType === type) stopAmbience();
		else startAmbience(type);
	};
	const genresList = [
		{
			key: "all",
			labelAr: "جميع الروايات",
			icon: "✨"
		},
		{
			key: "romance",
			labelAr: "روايات رومانسية واجتماعية",
			icon: "🌸"
		},
		{
			key: "crime_mystery",
			labelAr: "روايات التحقيقات الجنائية",
			icon: "🔍"
		},
		{
			key: "sci_fi_future",
			labelAr: "روايات خيال علمي وتكنولوجيا",
			icon: "🚀"
		},
		{
			key: "tactical_action",
			labelAr: "روايات أكشن ومطاردات تكتيكية",
			icon: "🎯"
		},
		{
			key: "sci_fantasy",
			labelAr: "خيال علمي وفانتازيا",
			icon: "⚔️"
		}
	];
	const filteredNovels = novelsList.filter((nov) => {
		const matchesGenre = selectedGenre === "all" || nov.genre === selectedGenre;
		const q = searchQuery.trim().toLowerCase();
		const matchesQuery = !q || nov.titleAr.toLowerCase().includes(q) || nov.subtitleAr.toLowerCase().includes(q) || nov.synopsisAr.toLowerCase().includes(q) || nov.authorPersonaAr.toLowerCase().includes(q) || nov.forensicThemeAr.toLowerCase().includes(q);
		return matchesGenre && matchesQuery;
	});
	const handleOpenNovel = (novel, chapterIdx = 0) => {
		soundManager.playTap();
		setActiveNovel(novel);
		setCurrentChapterIndex(chapterIdx);
		setReaderTab("narrative");
	};
	const handleBackToCatalog = () => {
		soundManager.playTap();
		setActiveNovel(null);
		stopAmbience();
	};
	const handleToggleBookmark = (novelId, chapIdx) => {
		soundManager.playTap();
		const updated = {
			...savedBookmarks,
			[novelId]: chapIdx
		};
		setSavedBookmarks(updated);
		try {
			localStorage.setItem("mirat_novels_bookmarks", JSON.stringify(updated));
		} catch {}
	};
	const handleShareNovel = (novel, chapter) => {
		soundManager.playTap();
		const url = typeof window !== "undefined" ? window.location.origin : "https://miratalqulub.com";
		const textToShare = chapter ? `📖 أقرأ الآن في رواية "${novel.titleAr}" - ${chapter.titleAr}\n${novel.subtitleAr}\nمنصة مِـرآة القـلوب للروايات والتحقيقات التشويقية:\n${url}` : `🔥 رواية تشويقية رائعة: "${novel.titleAr}"\n${novel.synopsisAr}\nاكتشف تفاصيل الجريمة والتحقيق الجنائي:\n${url}`;
		if (navigator.clipboard) {
			navigator.clipboard.writeText(textToShare);
			setCopiedShare(true);
			setTimeout(() => setCopiedShare(false), 2600);
		}
	};
	const handleOpenCreateNovel = () => {
		soundManager.playTap();
		setNovelToEdit(null);
		setIsAddOrEditModalOpen(true);
	};
	const handleOpenEditNovel = (novel, e) => {
		if (e) e.stopPropagation();
		soundManager.playTap();
		setNovelToEdit(novel);
		setIsAddOrEditModalOpen(true);
	};
	const handleOpenDeleteConfirm = (novel, e) => {
		if (e) e.stopPropagation();
		soundManager.playTap();
		setDeletingNovel(novel);
	};
	const handleConfirmDelete = async () => {
		if (!deletingNovel) return;
		setIsDeleting(true);
		soundManager.playTap();
		try {
			await deleteOwnerNovel(deletingNovel.id);
			soundManager.playRoundPass();
			if (activeNovel?.id === deletingNovel.id) setActiveNovel(null);
			setDeletingNovel(null);
			await refreshNovels();
		} catch (err) {
			console.error("Error deleting novel", err);
		} finally {
			setIsDeleting(false);
		}
	};
	const handleNovelSaved = (savedNovel) => {
		refreshNovels();
	};
	const currentChapter = activeNovel && activeNovel.chapters ? activeNovel.chapters[currentChapterIndex] : null;
	const isCurrentBookmarked = activeNovel && savedBookmarks[activeNovel.id] === currentChapterIndex;
	const currentThemeStyle = {
		noir: {
			bg: "bg-[#090b14]",
			text: "text-slate-100",
			panel: "bg-slate-900/90",
			border: "border-rose-900/40",
			accent: "text-rose-400"
		},
		cyber: {
			bg: "bg-[#030712]",
			text: "text-cyan-50",
			panel: "bg-slate-950/90",
			border: "border-cyan-500/30",
			accent: "text-cyan-400"
		},
		amber: {
			bg: "bg-[#181410]",
			text: "text-[#f5ede3]",
			panel: "bg-[#211a14]/90",
			border: "border-amber-700/40",
			accent: "text-amber-400"
		}
	}[readerTheme];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/90 backdrop-blur-md overflow-hidden text-right",
		dir: isRTL ? "rtl" : "ltr",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: {
				opacity: 0,
				scale: .96,
				y: 15
			},
			animate: {
				opacity: 1,
				scale: 1,
				y: 0
			},
			exit: {
				opacity: 0,
				scale: .96,
				y: 15
			},
			className: "w-full max-w-5xl h-[94vh] max-h-[880px] bg-slate-950 border border-purple-500/30 rounded-3xl overflow-hidden shadow-2xl flex flex-col relative",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-3.5 sm:p-4 bg-gradient-to-r from-purple-950 via-slate-900 to-rose-950 border-b border-white/10 flex items-center justify-between shrink-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-10 h-10 rounded-2xl bg-gradient-to-tr from-rose-600 via-purple-600 to-amber-500 p-0.5 shadow-md flex items-center justify-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-full h-full bg-[#120d24] rounded-[14px] flex items-center justify-center text-lg",
								children: "🕵️‍♂️"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-extrabold text-sm sm:text-base text-white font-['Alexandria']",
									children: "قسم الروايات التشويقية والتحقيقات الجنائية"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30",
									children: "غموض • أكشن • خيال علمي 🔍"
								}),
								isOwner && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 hidden sm:inline-flex items-center gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crown, { className: "w-3 h-3 text-amber-400" }), "صلاحيات المالك مفعلة"]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-gray-300",
							children: "روايات احترافية طويلة بأسلوب محقق جنائي خبير، تفاصيل الأدلة، سيكولوجية الجناة والخيال العلمي"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [isOwner && !activeNovel && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: handleOpenCreateNovel,
							className: "px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-rose-600 hover:opacity-90 text-white text-xs font-black transition flex items-center gap-1.5 cursor-pointer shadow-lg shadow-amber-500/20",
							title: "إضافة رواية جديدة بصفتك مالك الموقع",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "w-4 h-4" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline",
									children: "إضافة رواية جديدة"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "sm:hidden",
									children: "إضافة"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								soundManager.playTap();
								stopAmbience();
								onClose();
							},
							className: "p-2 rounded-full bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white transition cursor-pointer",
							title: "إغلاق",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-5 h-5" })
						})]
					})]
				}),
				!activeNovel && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 overflow-y-auto p-3 sm:p-5 space-y-4 custom-scrollbar",
					children: [
						filteredNovels.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-red-950/60 via-purple-950/50 to-slate-900 border border-rose-500/30 flex flex-col md:flex-row items-center justify-between gap-4 shadow-xl",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2 max-w-xl",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 text-xs text-amber-300 font-bold",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, { className: "w-4 h-4 text-rose-400" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "رواية الشهر الأكثر قراءة وتشويقاً:" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-[10px] text-gray-400",
												children: [
													"· ",
													filteredNovels[0].readsCount || 28450,
													" قارئ"
												]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-base sm:text-xl font-black text-white font-['Alexandria']",
										children: filteredNovels[0].titleAr
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-gray-300 leading-relaxed",
										children: filteredNovels[0].synopsisAr
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3 text-[11px] text-gray-400 pt-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
											"⏱️ ",
											filteredNovels[0].totalChapters,
											" فصول كاملة · ",
											filteredNovels[0].estimatedReadingTime
										] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["🔬 ", filteredNovels[0].forensicThemeAr] })]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 w-full md:w-auto shrink-0",
								children: [isOwner && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: (e) => handleOpenEditNovel(filteredNovels[0], e),
									className: "px-3 py-2.5 rounded-2xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs transition flex items-center gap-1.5 cursor-pointer border border-white/15",
									title: "تعديل الرواية المميزة",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "w-3.5 h-3.5 text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تعديل" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => handleOpenNovel(filteredNovels[0], 0),
									className: "flex-1 md:flex-initial px-5 py-2.5 rounded-2xl bg-gradient-to-r from-rose-600 via-pink-600 to-purple-600 hover:opacity-95 text-white font-extrabold text-xs transition shadow-lg shadow-rose-600/25 flex items-center justify-center gap-2 cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "ابدأ قراءة الرواية الآن" })]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "w-4 h-4 text-gray-400 absolute right-3.5 top-1/2 -translate-y-1/2" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									value: searchQuery,
									onChange: (e) => setSearchQuery(e.target.value),
									placeholder: "ابحث بالعنوان، اسم المحقق، الكلمات المفتاحية، أو نوع الجريمة...",
									className: "w-full pr-10 pl-4 py-2.5 rounded-2xl bg-white/5 border border-white/10 text-xs text-white placeholder-gray-400 focus:outline-none focus:border-rose-400/50 transition"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center gap-1.5 p-1 rounded-2xl bg-black/40 border border-white/10 overflow-x-auto text-xs font-bold scrollbar-none",
								children: genresList.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => {
										soundManager.playTab();
										setSelectedGenre(g.key);
									},
									className: `px-3 py-1.5 rounded-xl transition cursor-pointer shrink-0 flex items-center gap-1.5 ${selectedGenre === g.key ? "bg-rose-600 text-white shadow-md" : "text-gray-400 hover:text-white"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: g.icon }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: g.labelAr })]
								}, g.key))
							})]
						}),
						filteredNovels.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-8 text-center space-y-3 rounded-3xl bg-white/5 border border-white/10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-gray-400 text-xs",
								children: "لا توجد روايات تطابق هذا البحث أو التصنيف حالياً."
							}), isOwner && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: handleOpenCreateNovel,
								className: "px-4 py-2 rounded-xl bg-rose-600 text-white text-xs font-bold transition hover:bg-rose-700 cursor-pointer",
								children: "+ إضافة رواية جديدة الآن"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-1 md:grid-cols-2 gap-4",
							children: filteredNovels.map((novel) => {
								const isBookmarked = savedBookmarks[novel.id] !== void 0;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
									whileHover: {
										scale: 1.015,
										y: -3
									},
									className: "p-4 sm:p-5 rounded-3xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-rose-500/40 transition flex flex-col justify-between group shadow-md relative",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between text-xs text-gray-400 mb-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-1.5",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "font-bold text-[11px]",
															style: { color: novel.genreBadgeColor },
															children: novel.genreLabelAr
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: novel.authorPersonaAr })
													]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-1 text-amber-400 font-bold",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "★" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: novel.rating })]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex gap-3 mb-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "w-20 h-28 sm:w-24 sm:h-32 rounded-2xl overflow-hidden shrink-0 border border-white/15 shadow-inner",
													dangerouslySetInnerHTML: { __html: novel.coverIllustrationSvg }
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "space-y-1 flex-1 min-w-0",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
															className: "font-extrabold text-sm sm:text-base text-white group-hover:text-rose-300 transition line-clamp-2 font-['Alexandria']",
															children: novel.titleAr
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "text-xs text-gray-300 line-clamp-2 leading-relaxed",
															children: novel.subtitleAr
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "text-[11px] text-gray-400 pt-1 flex items-center gap-2",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["⏱️ ", novel.estimatedReadingTime] }),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [novel.totalChapters, " فصول"] }),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [novel.totalWords ? novel.totalWords.toLocaleString() : "5,000", " كلمة"] })
															]
														})
													]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "p-2.5 rounded-xl bg-black/30 border border-white/5 text-[11px] space-y-1 mb-3",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "text-gray-300",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-rose-400 font-bold",
														children: "المنهج الجنائي: "
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-gray-300",
														children: novel.forensicThemeAr
													})]
												})
											})
										] }),
										isOwner && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mb-3 p-2 rounded-xl bg-amber-500/10 border border-amber-500/25 flex items-center justify-between gap-2 text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-1 text-amber-300 font-bold text-[11px]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crown, { className: "w-3 h-3 text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "إدارة المالك:" })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													onClick: (e) => handleOpenEditNovel(novel, e),
													className: "px-2.5 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 font-bold text-[11px] transition flex items-center gap-1 cursor-pointer border border-amber-500/30",
													title: "تعديل نصوص وفصول هذه الرواية",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "w-3 h-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تعديل" })]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													onClick: (e) => handleOpenDeleteConfirm(novel, e),
													className: "px-2.5 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 font-bold text-[11px] transition flex items-center gap-1 cursor-pointer border border-rose-500/30",
													title: "حذف هذه الرواية نهائياً من المكتبة",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "w-3 h-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "حذف" })]
												})]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "pt-3 border-t border-white/10 flex items-center justify-between gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex items-center gap-1",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => handleShareNovel(novel),
													className: "p-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white transition cursor-pointer",
													title: "مشاركة الرواية",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "w-4 h-4" })
												})
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												onClick: () => handleOpenNovel(novel, savedBookmarks[novel.id] || 0),
												className: "px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-md",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isBookmarked ? "متابعة القراءة 🔖" : "قراءة الرواية" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "w-3.5 h-3.5 group-hover:-translate-x-1 transition-transform" })]
											})]
										})
									]
								}, novel.id);
							})
						})
					]
				}),
				activeNovel && currentChapter && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `flex-1 flex flex-col overflow-hidden ${currentThemeStyle.bg} ${currentThemeStyle.text}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `px-4 py-2.5 ${currentThemeStyle.panel} border-b ${currentThemeStyle.border} flex flex-wrap items-center justify-between gap-2 shrink-0 text-xs`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: handleBackToCatalog,
										className: "flex items-center gap-1 text-gray-400 hover:text-white transition cursor-pointer font-bold",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "المكتبة" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-gray-500",
										children: "|"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-extrabold text-white truncate max-w-[200px] sm:max-w-xs font-['Alexandria']",
										children: activeNovel.titleAr
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-gray-400 text-[11px] hidden sm:inline",
										children: [
											"(الفصل ",
											currentChapter.chapterNumber,
											" من ",
											activeNovel.totalChapters,
											")"
										]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1.5 sm:gap-2",
								children: [
									isOwner && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1 bg-amber-500/15 border border-amber-500/30 p-0.5 rounded-xl",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: () => handleOpenEditNovel(activeNovel),
											className: "px-2 py-1 rounded-lg text-[11px] font-bold text-amber-300 hover:bg-amber-500/20 transition cursor-pointer flex items-center gap-1",
											title: "تعديل فصول الرواية الحالية",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "w-3 h-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "hidden sm:inline",
												children: "تعديل الرواية"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => handleOpenDeleteConfirm(activeNovel),
											className: "p-1 rounded-lg text-rose-400 hover:bg-rose-500/20 transition cursor-pointer",
											title: "حذف هذه الرواية",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "w-3.5 h-3.5" })
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1 bg-black/40 p-0.5 rounded-xl border border-white/10",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												onClick: () => toggleAmbience("rain"),
												className: `px-2 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer flex items-center gap-1 ${isAmbiencePlaying && ambienceType === "rain" ? "bg-rose-600 text-white" : "text-gray-400 hover:text-white"}`,
												title: "أجواء المطر النوار والتحقيق",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "🌧️" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "hidden md:inline",
													children: "مطر نوار"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												onClick: () => toggleAmbience("pulse"),
												className: `px-2 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer flex items-center gap-1 ${isAmbiencePlaying && ambienceType === "pulse" ? "bg-rose-600 text-white" : "text-gray-400 hover:text-white"}`,
												title: "نبضات التوتر الحابسة للأنفاس",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "💓" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "hidden md:inline",
													children: "نبض التوتر"
												})]
											}),
											isAmbiencePlaying && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: stopAmbience,
												"aria-label": "كتم الصوت",
												className: "p-1 rounded-lg text-rose-400 hover:text-white",
												title: "كتم الصوت",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "w-3.5 h-3.5" })
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center bg-black/40 rounded-xl border border-white/10 p-0.5 text-xs",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => setFontSize(Math.max(14, fontSize - 1)),
												className: "px-2 py-0.5 text-gray-300 hover:text-white cursor-pointer font-bold",
												title: "تصغير الخط",
												children: "A-"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "px-1 text-[10px] text-gray-400 font-mono",
												children: fontSize
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => setFontSize(Math.min(24, fontSize + 1)),
												className: "px-2 py-0.5 text-gray-300 hover:text-white cursor-pointer font-bold",
												title: "تكبير الخط",
												children: "A+"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center bg-black/40 rounded-xl border border-white/10 p-0.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => setReaderTheme("noir"),
												className: `w-5 h-5 rounded-lg flex items-center justify-center text-[10px] cursor-pointer ${readerTheme === "noir" ? "bg-rose-600 text-white" : "text-gray-400"}`,
												title: "ثيم محقق نوار (داكن أحمر)",
												children: "🕵️"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => setReaderTheme("cyber"),
												className: `w-5 h-5 rounded-lg flex items-center justify-center text-[10px] cursor-pointer ${readerTheme === "cyber" ? "bg-cyan-600 text-white" : "text-gray-400"}`,
												title: "ثيم سايبر الفضاء (أزرق سماوي)",
												children: "🚀"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => setReaderTheme("amber"),
												className: `w-5 h-5 rounded-lg flex items-center justify-center text-[10px] cursor-pointer ${readerTheme === "amber" ? "bg-amber-600 text-white" : "text-gray-400"}`,
												title: "ثيم المخطوطة الدافئة (عنبر كلاسيكي)",
												children: "📜"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => handleToggleBookmark(activeNovel.id, currentChapterIndex),
										className: `p-1.5 rounded-xl border transition cursor-pointer ${isCurrentBookmarked ? "bg-amber-500/20 border-amber-500/40 text-amber-300" : "bg-white/5 border-white/10 text-gray-400 hover:text-white"}`,
										title: isCurrentBookmarked ? "الفصل محفوظ في إشاراتك" : "حفظ موضع القراءة",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "w-4 h-4" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => handleShareNovel(activeNovel, currentChapter),
										className: "p-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-gray-300 hover:text-white transition cursor-pointer",
										title: "مشاركة الفصل",
										children: copiedShare ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4 text-emerald-400" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "w-4 h-4" })
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `px-4 py-2 ${currentThemeStyle.panel} border-b ${currentThemeStyle.border} flex items-center justify-between overflow-x-auto text-xs font-bold gap-2 shrink-0 scrollbar-none`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setReaderTab("narrative"),
										className: `px-3 py-1.5 rounded-xl transition cursor-pointer flex items-center gap-1.5 ${readerTab === "narrative" ? "bg-rose-600 text-white shadow-md" : "text-gray-400 hover:text-white"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "نص الرواية والفصول" })]
									}),
									currentChapter.investigationClues && currentChapter.investigationClues.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setReaderTab("evidence_board"),
										className: `px-3 py-1.5 rounded-xl transition cursor-pointer flex items-center gap-1.5 ${readerTab === "evidence_board" ? "bg-purple-600 text-white shadow-md" : "text-gray-400 hover:text-white"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, { className: "w-3.5 h-3.5 text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
											"لوحة الأدلة والتحقيق الجنائي (",
											currentChapter.investigationClues.length,
											")"
										] })]
									}),
									activeNovel.suspectsDossier && activeNovel.suspectsDossier.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setReaderTab("suspects"),
										className: `px-3 py-1.5 rounded-xl transition cursor-pointer flex items-center gap-1.5 ${readerTab === "suspects" ? "bg-indigo-600 text-white shadow-md" : "text-gray-400 hover:text-white"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "w-3.5 h-3.5 text-sky-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
											"الملف السيكولوجي للجناة (",
											activeNovel.suspectsDossier.length,
											")"
										] })]
									}),
									currentChapter.detectiveNotesAr && currentChapter.detectiveNotesAr.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setReaderTab("notes"),
										className: `px-3 py-1.5 rounded-xl transition cursor-pointer flex items-center gap-1.5 ${readerTab === "notes" ? "bg-amber-600 text-white shadow-md" : "text-gray-400 hover:text-white"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-3.5 h-3.5 text-amber-300" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "ملاحظات المحقق الميدانية" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setReaderTab("comments"),
										className: `px-3 py-1.5 rounded-xl transition cursor-pointer flex items-center gap-1.5 ${readerTab === "comments" ? "bg-emerald-600 text-white shadow-md" : "text-gray-400 hover:text-white"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquare, { className: "w-3.5 h-3.5 text-emerald-300" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تعليقات وانطباعات القراء 💬" })]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1 shrink-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										disabled: currentChapterIndex === 0,
										onClick: () => {
											soundManager.playTap();
											setCurrentChapterIndex(currentChapterIndex - 1);
										},
										className: `p-1.5 rounded-lg border transition ${currentChapterIndex === 0 ? "opacity-30 cursor-not-allowed border-white/5" : "hover:bg-white/10 border-white/10 text-white cursor-pointer"}`,
										title: "الفصل السابق",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "w-4 h-4" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[11px] text-gray-300 px-1 font-mono",
										children: [
											currentChapterIndex + 1,
											" / ",
											activeNovel.totalChapters
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										disabled: currentChapterIndex === activeNovel.totalChapters - 1,
										onClick: () => {
											soundManager.playTap();
											setCurrentChapterIndex(currentChapterIndex + 1);
										},
										className: `p-1.5 rounded-lg border transition ${currentChapterIndex === activeNovel.totalChapters - 1 ? "opacity-30 cursor-not-allowed border-white/5" : "hover:bg-white/10 border-white/10 text-white cursor-pointer"}`,
										title: "الفصل التالي",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "w-4 h-4" })
									})
								]
							})]
						}),
						readerTab === "narrative" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1 overflow-y-auto p-4 sm:p-7 space-y-6 custom-scrollbar max-w-4xl mx-auto w-full",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5 pb-3 border-b border-white/10",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-xs text-gray-400",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: currentThemeStyle.accent,
												children: [
													activeNovel.titleAr,
													" · الفصل ",
													currentChapter.chapterNumber
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
												"⏱️ قراءة ",
												currentChapter.estimatedMinutes,
												" دقيقة · ",
												currentChapter.wordsCount,
												" كلمة"
											] })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-lg sm:text-2xl font-black text-white font-['Alexandria']",
											children: currentChapter.titleAr
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs text-gray-300 leading-relaxed italic",
											children: [
												"«",
												currentChapter.synopsisAr,
												"»"
											]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-2xl overflow-hidden border border-white/15 shadow-xl bg-black/40",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "w-full h-56 sm:h-72",
										dangerouslySetInnerHTML: { __html: currentChapter.sceneIllustrationSvg }
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-2.5 bg-black/70 text-center text-xs text-gray-300 border-t border-white/10",
										children: ["🎨 ", currentChapter.illustrationCaptionAr]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "leading-loose space-y-4 tracking-normal",
									style: { fontSize: `${fontSize}px` },
									children: currentChapter.contentAr.trim().split("\n\n").map((paragraph, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-justify indent-6",
										children: paragraph
									}, idx))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											disabled: currentChapterIndex === 0,
											onClick: () => {
												soundManager.playTap();
												setCurrentChapterIndex(currentChapterIndex - 1);
												window.scrollTo({
													top: 0,
													behavior: "smooth"
												});
											},
											className: `w-full sm:w-auto px-4 py-2.5 rounded-xl border font-bold transition flex items-center justify-center gap-1.5 ${currentChapterIndex === 0 ? "opacity-30 cursor-not-allowed border-white/5" : "bg-white/5 hover:bg-white/10 border-white/10 text-white cursor-pointer"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "الفصل السابق" })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex items-center gap-2",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												onClick: () => handleToggleBookmark(activeNovel.id, currentChapterIndex),
												className: `px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${isCurrentBookmarked ? "bg-amber-500/20 text-amber-300 border border-amber-500/40" : "bg-white/5 text-gray-300 hover:text-white border border-white/10"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isCurrentBookmarked ? "الفصل محفوظ ✓" : "حفظ الفصل الحالي" })]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											disabled: currentChapterIndex === activeNovel.totalChapters - 1,
											onClick: () => {
												soundManager.playTap();
												setCurrentChapterIndex(currentChapterIndex + 1);
												window.scrollTo({
													top: 0,
													behavior: "smooth"
												});
											},
											className: `w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-purple-600 text-white font-black transition flex items-center justify-center gap-1.5 shadow-md ${currentChapterIndex === activeNovel.totalChapters - 1 ? "opacity-30 cursor-not-allowed" : "hover:opacity-95 cursor-pointer"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "الفصل التالي" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "w-4 h-4" })]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "pt-8 border-t border-white/15",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NovelCommentsSection, {
										novelId: activeNovel.id,
										novelTitle: activeNovel.titleAr
									})
								})
							]
						}),
						readerTab === "evidence_board" && currentChapter.investigationClues && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 custom-scrollbar max-w-4xl mx-auto w-full",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3.5 rounded-2xl bg-purple-500/15 border border-purple-500/30 flex items-start gap-2.5 text-xs text-purple-200",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, { className: "w-4 h-4 text-purple-400 mt-0.5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-extrabold text-white",
									children: "لوحة الأدلة والتحقيق الجنائي للمحقق:"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "leading-relaxed",
									children: "هنا تجد نتائج الفحص المخبري الجنائي، مطياف الكتلة، البصمات، وسجلات الاتصال المحرزة رسمياً في مسرح الجريمة لهذا الفصل."
								})] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 md:grid-cols-2 gap-3.5",
								children: currentChapter.investigationClues.map((clue) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2.5 shadow-md",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30",
												children: [clue.significanceLevel, " 🔥"]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-[10px] text-gray-400 font-mono",
												children: ["الحالة: ", clue.status]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "font-bold text-sm text-white font-['Alexandria']",
											children: clue.titleAr
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-gray-300 leading-relaxed",
											children: clue.descriptionAr
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-3 rounded-xl bg-black/40 border border-white/5 text-[11px] space-y-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-amber-400 font-bold block",
												children: "🔬 التقرير المخبري الجنائي:"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-gray-300 leading-relaxed font-mono",
												children: clue.forensicLabReportAr
											})]
										})
									]
								}, clue.id))
							})]
						}),
						readerTab === "suspects" && activeNovel.suspectsDossier && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 custom-scrollbar max-w-4xl mx-auto w-full",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3.5 rounded-2xl bg-indigo-500/15 border border-indigo-500/30 flex items-start gap-2.5 text-xs text-indigo-200",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "w-4 h-4 text-indigo-400 mt-0.5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-extrabold text-white",
									children: "الملف السيكولوجي للجناة والمشتبه بهم:"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "leading-relaxed",
									children: "دراسة نفسية وسلوكية معمقة لكل شخصية تحيط بمسرح الجريمة، مع قياس درجة الدافع والانفعال النفسي المسجل."
								})] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 md:grid-cols-3 gap-3.5",
								children: activeNovel.suspectsDossier.map((suspect, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2.5 shadow-md flex flex-col justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: `text-[10px] font-bold px-2 py-0.5 rounded-full border ${suspect.status === "المشتبه به الرئيسي" ? "bg-rose-500/20 text-rose-300 border-rose-500/40" : "bg-amber-500/20 text-amber-300 border-amber-500/40"}`,
													children: suspect.status
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-[11px] text-gray-400",
													children: [suspect.age, " سنة"]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
												className: "font-bold text-sm text-white font-['Alexandria']",
												children: suspect.nameAr
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[11px] text-purple-300 block",
												children: suspect.roleAr
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-2 rounded-xl bg-black/40 text-[11px] space-y-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-gray-400 block font-bold",
													children: "حجة الغياب (Alibi):"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-gray-300 leading-relaxed",
													children: suspect.alibiAr
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-2 rounded-xl bg-black/40 text-[11px] space-y-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-rose-400 block font-bold",
													children: "الدافع السيكولوجي:"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-gray-300 leading-relaxed",
													children: suspect.psychologicalMotiveAr
												})]
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "pt-2 border-t border-white/10",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-[11px] mb-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-gray-400",
												children: "مؤشر الدافع الجنائي:"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-black text-rose-400 font-mono",
												children: [suspect.motiveRating, "%"]
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-full h-1.5 bg-black/50 rounded-full overflow-hidden",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "h-full bg-gradient-to-r from-amber-500 to-rose-500 rounded-full",
												style: { width: `${suspect.motiveRating}%` }
											})
										})]
									})]
								}, idx))
							})]
						}),
						readerTab === "notes" && currentChapter.detectiveNotesAr && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 custom-scrollbar max-w-4xl mx-auto w-full",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3.5 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-start gap-2.5 text-xs text-amber-200",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-4 h-4 text-amber-400 mt-0.5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-extrabold text-white",
									children: "مذكرات المحقق الميدانية:"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "leading-relaxed",
									children: "الاستنتاجات الاستنباطية والملاحظات الدقيقة المسجلة في دفتر المباحث الجنائية لحظة بلحظة."
								})] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-3",
								children: currentChapter.detectiveNotesAr.map((note, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-white/5 border border-white/10 flex items-start gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "w-7 h-7 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center justify-center font-mono font-bold text-xs shrink-0 mt-0.5",
										children: idx + 1
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs sm:text-sm text-gray-200 leading-relaxed font-sans",
										children: note
									})]
								}, idx))
							})]
						}),
						readerTab === "comments" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex-1 overflow-y-auto p-4 sm:p-7 custom-scrollbar max-w-4xl mx-auto w-full",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NovelCommentsSection, {
								novelId: activeNovel.id,
								novelTitle: activeNovel.titleAr
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: deletingNovel && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm text-right",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
						initial: {
							opacity: 0,
							scale: .95
						},
						animate: {
							opacity: 1,
							scale: 1
						},
						exit: {
							opacity: 0,
							scale: .95
						},
						className: "p-6 rounded-3xl bg-slate-900 border border-rose-500/40 max-w-md w-full shadow-2xl space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-12 h-12 rounded-2xl bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center justify-center mx-auto",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "w-6 h-6" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center space-y-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-extrabold text-white text-base",
										children: "تأكيد حذف الرواية"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-gray-300 leading-relaxed",
										children: [
											"هل أنت متأكد من رغبتك في حذف رواية",
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-bold text-rose-300",
												children: [
													"«",
													deletingNovel.titleAr,
													"»"
												]
											}),
											" نهائياً؟"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[11px] text-gray-400",
										children: "لن تظهر هذه الرواية للزوار والقراء في المكتبة بعد الحذف."
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-center gap-3 pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									disabled: isDeleting,
									onClick: () => setDeletingNovel(null),
									className: "px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-gray-300 text-xs font-bold transition cursor-pointer",
									children: "تراجع وإلغاء"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									disabled: isDeleting,
									onClick: handleConfirmDelete,
									className: "px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-black transition flex items-center gap-1.5 cursor-pointer shadow-lg shadow-rose-600/30 disabled:opacity-50",
									children: isDeleting ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "جارٍ الحذف..." }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تأكيد الحذف نهائياً" })] })
								})]
							})
						]
					})
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: isAddOrEditModalOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddNovelModal, {
					isOpen: isAddOrEditModalOpen,
					onClose: () => setIsAddOrEditModalOpen(false),
					onNovelCreated: handleNovelSaved,
					initialNovel: novelToEdit
				}) })
			]
		})
	});
};
//#endregion
export { NovelsSectionModal };
