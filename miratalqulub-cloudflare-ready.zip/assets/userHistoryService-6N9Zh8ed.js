const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/rolldown-runtime-Bk_YeHJf.js"])))=>i.map(i=>d[i]);
import { n as __exportAll } from "./rolldown-runtime-Bk_YeHJf.js";
import { n as __vitePreload } from "./vendor-react-Bm_EF59R.js";
import { i as isAutomatedAuditEnvironment, n as auth } from "./firebaseAuth-D6LKvzXg.js";
import { t as db } from "./firebase-Cu7XUsbK.js";
import { a as orderBy, l as collection, n as getDoc, o as query, r as getDocs, s as setDoc, t as deleteDoc, u as doc } from "./vendor-firebase-firestore-nFD0fmjQ.js";
//#region src/services/userHistoryService.ts
var userHistoryService_exports = /* @__PURE__ */ __exportAll({
	OperationType: () => OperationType,
	buildTemporalEvolutionSummary: () => buildTemporalEvolutionSummary,
	deleteSavedResultFromHistory: () => deleteSavedResultFromHistory,
	deleteUnifiedTestRecord: () => deleteUnifiedTestRecord,
	fetchPublicCommunityProfiles: () => fetchPublicCommunityProfiles,
	fetchUnifiedTestHistory: () => fetchUnifiedTestHistory,
	fetchUserSavedResults: () => fetchUserSavedResults,
	getEffectiveOwnerId: () => getEffectiveOwnerId,
	getOrCreateVisitorId: () => getOrCreateVisitorId,
	handleFirestoreError: () => handleFirestoreError,
	loadPersistentUserSession: () => loadPersistentUserSession,
	purgeAllUserDataPermanently: () => purgeAllUserDataPermanently,
	savePersistentUserProfile: () => savePersistentUserProfile,
	saveTestResultToHistory: () => saveTestResultToHistory,
	saveUnifiedTestRecord: () => saveUnifiedTestRecord,
	saveUserPsychologyReport: () => saveUserPsychologyReport,
	setPublicProfileStatus: () => setPublicProfileStatus
});
var OperationType = /* @__PURE__ */ function(OperationType) {
	OperationType["CREATE"] = "create";
	OperationType["UPDATE"] = "update";
	OperationType["DELETE"] = "delete";
	OperationType["LIST"] = "list";
	OperationType["GET"] = "get";
	OperationType["WRITE"] = "write";
	return OperationType;
}({});
function handleFirestoreError(error, operationType, path) {
	const errInfo = {
		error: error instanceof Error ? error.message : String(error),
		operationType,
		path,
		authInfo: {
			userId: auth?.currentUser?.uid || null,
			email: auth?.currentUser?.email || null
		}
	};
	console.warn("Firestore Operation Advisory:", JSON.stringify(errInfo));
}
function withFirestoreTimeout(promise, ms = 2500) {
	return new Promise((resolve, reject) => {
		const timer = setTimeout(() => reject(/* @__PURE__ */ new Error("firestore_timeout")), ms);
		promise.then((val) => {
			clearTimeout(timer);
			resolve(val);
		}).catch((err) => {
			clearTimeout(timer);
			reject(err);
		});
	});
}
var VISITOR_ID_STORAGE_KEY = "mirat_persistent_visitor_id";
var VISITOR_PROFILE_STORAGE_KEY = "mirat_persistent_user_profile";
var VISITOR_LATEST_RESULT_KEY = "mirat_persistent_latest_result";
var CLOUD_SYNC_FLAG_KEY = "mirat_has_cloud_data";
function hasVisitorCloudData() {
	try {
		return localStorage.getItem(CLOUD_SYNC_FLAG_KEY) === "1";
	} catch {
		return false;
	}
}
function markVisitorCloudData() {
	try {
		localStorage.setItem(CLOUD_SYNC_FLAG_KEY, "1");
	} catch {}
}
/**
* Generates or retrieves a persistent visitor ID so returning visitors always keep their database records
*/
function getOrCreateVisitorId() {
	try {
		let vid = localStorage.getItem(VISITOR_ID_STORAGE_KEY);
		if (!vid || !/^[a-zA-Z0-9_-]+$/.test(vid)) {
			vid = `vis_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
			localStorage.setItem(VISITOR_ID_STORAGE_KEY, vid);
		}
		return vid;
	} catch {
		return "vis_default_session";
	}
}
function getEffectiveOwnerId(user) {
	return user?.uid || getOrCreateVisitorId();
}
/**
* Saves the visitor/user's demographic profile preferences to both LocalStorage and Firestore
*/
async function savePersistentUserProfile(profile, user) {
	const now = (/* @__PURE__ */ new Date()).toISOString();
	const visitorId = getOrCreateVisitorId();
	try {
		localStorage.setItem(VISITOR_PROFILE_STORAGE_KEY, JSON.stringify(profile));
	} catch {}
	if (isAutomatedAuditEnvironment()) return;
	try {
		const visRef = doc(db, "visitor_sessions", visitorId);
		await withFirestoreTimeout(setDoc(visRef, {
			visitorId,
			profile,
			updatedAt: now
		}, { merge: true }), 2500);
		markVisitorCloudData();
	} catch {}
	if (user?.uid) try {
		const userRef = doc(db, "users", user.uid);
		await withFirestoreTimeout(setDoc(userRef, {
			id: user.uid,
			email: user.email || "",
			displayName: user.displayName || profile.userName || "مستخدم مِرآة القلوب",
			profile,
			updatedAt: now,
			createdAt: now
		}, { merge: true }), 2500);
	} catch {}
}
/**
* Restores a returning visitor or user's saved profile and latest state from Firestore or LocalStorage
*/
async function loadPersistentUserSession(user) {
	let localProfile = null;
	let localResult = null;
	try {
		const rawProf = localStorage.getItem(VISITOR_PROFILE_STORAGE_KEY);
		if (rawProf) localProfile = JSON.parse(rawProf);
		const rawRes = localStorage.getItem(VISITOR_LATEST_RESULT_KEY);
		if (rawRes) localResult = JSON.parse(rawRes);
	} catch {}
	if (isAutomatedAuditEnvironment()) return {
		profile: localProfile,
		latestResult: localResult
	};
	if (user?.uid) try {
		const userSnap = await withFirestoreTimeout(getDoc(doc(db, "users", user.uid)), 2500);
		if (userSnap.exists()) {
			const data = userSnap.data();
			if (data.profile) {
				localProfile = data.profile;
				localStorage.setItem(VISITOR_PROFILE_STORAGE_KEY, JSON.stringify(localProfile));
			}
			if (data.latestResult) {
				localResult = data.latestResult;
				localStorage.setItem(VISITOR_LATEST_RESULT_KEY, JSON.stringify(localResult));
			}
		}
	} catch {}
	if (hasVisitorCloudData()) {
		const visitorId = getOrCreateVisitorId();
		try {
			const visSnap = await withFirestoreTimeout(getDoc(doc(db, "visitor_sessions", visitorId)), 2500);
			if (visSnap.exists()) {
				const data = visSnap.data();
				if (data.profile && !localProfile) {
					localProfile = data.profile;
					localStorage.setItem(VISITOR_PROFILE_STORAGE_KEY, JSON.stringify(localProfile));
				}
				if (data.latestResult && !localResult) {
					localResult = data.latestResult;
					localStorage.setItem(VISITOR_LATEST_RESULT_KEY, JSON.stringify(localResult));
				}
				if (Array.isArray(data.testHistory) && data.testHistory.length > 0) {
					const key = `offline_test_history_${getEffectiveOwnerId(user)}`;
					if (!localStorage.getItem(key)) localStorage.setItem(key, JSON.stringify(data.testHistory));
				}
				if (Array.isArray(data.results) && data.results.length > 0) {
					const key = `offline_results_${getEffectiveOwnerId(user)}`;
					if (!localStorage.getItem(key)) localStorage.setItem(key, JSON.stringify(data.results));
				}
			}
		} catch {}
	}
	return {
		profile: localProfile,
		latestResult: localResult
	};
}
async function saveTestResultToHistory(user, profile, result) {
	const resultId = `res_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
	const now = (/* @__PURE__ */ new Date()).toISOString();
	const ownerId = getEffectiveOwnerId(user);
	const visitorId = getOrCreateVisitorId();
	try {
		localStorage.setItem(VISITOR_PROFILE_STORAGE_KEY, JSON.stringify(profile));
		localStorage.setItem(VISITOR_LATEST_RESULT_KEY, JSON.stringify(result));
	} catch {}
	const traitsList = Array.isArray(result.partnerTraits) ? result.partnerTraits.map((t) => typeof t === "string" ? t : t.title || t.trait || "") : [];
	const resultDocData = {
		id: resultId,
		userId: ownerId,
		createdAt: now,
		partnerName: result.proposedPartnerName || result.partnerName || "الشريك المتوافق",
		partnerGender: profile.partnerGender || "female",
		userGender: profile.userGender || "male",
		userAge: profile.userAge || 26,
		country: profile.country || "المملكة العربية السعودية",
		compatibilityScore: result.compatibilityScore || 92,
		intellectualScore: result.intellectualScore || 90,
		sociologicalScore: result.sociologicalScore || 91,
		emotionalScore: result.emotionalScore || 93,
		lifestyleScore: result.lifestyleScore || 89,
		partnerTraits: traitsList,
		loveLanguage: result.loveLanguage || "",
		romanticAdvice: result.romanticAdvice || "",
		partnerVibeQuote: result.partnerVibeQuote || "",
		imageUrl: result.imageUrl || "",
		visualDescription: result.visualDescription || "",
		profileSnapshot: profile,
		fullResultSnapshot: result
	};
	let updatedLocalResults = [resultDocData];
	try {
		const localKey = `offline_results_${ownerId}`;
		updatedLocalResults = [resultDocData, ...JSON.parse(localStorage.getItem(localKey) || "[]").filter((r) => r.id !== resultId)].slice(0, 30);
		localStorage.setItem(localKey, JSON.stringify(updatedLocalResults));
		localStorage.setItem(`offline_results_${visitorId}`, JSON.stringify(updatedLocalResults));
	} catch (e) {
		console.error("Local backup failed", e);
	}
	if (user?.uid) try {
		const userRef = doc(db, "users", user.uid);
		await setDoc(userRef, {
			id: user.uid,
			email: user.email || "",
			displayName: user.displayName || profile.userName || "مستخدم مِرآة القلوب",
			profile,
			latestResult: result,
			updatedAt: now,
			createdAt: now
		}, { merge: true });
		const resultRef = doc(db, "users", user.uid, "results", resultId);
		await setDoc(resultRef, resultDocData);
	} catch (err) {
		console.warn("Could not save result to user Firestore doc, continuing to visitor session", err);
	}
	try {
		const visRef = doc(db, "visitor_sessions", visitorId);
		await setDoc(visRef, {
			visitorId,
			profile,
			latestResult: result,
			results: updatedLocalResults.slice(0, 15),
			updatedAt: now
		}, { merge: true });
		markVisitorCloudData();
	} catch (err) {
		console.warn("Could not sync result to visitor_sessions in Firestore", err);
	}
	try {
		await saveUnifiedTestRecord(user || null, {
			testType: "partner_compatibility",
			testTitleAr: `توافق الشريك: ${resultDocData.partnerName}`,
			testCategoryAr: "التوافق الفكري والروحي",
			scoreOrArchetype: `${resultDocData.compatibilityScore}% توافق`,
			percentage: resultDocData.compatibilityScore,
			badgeColor: "#2563eb",
			keyInsights: traitsList.slice(0, 3),
			snapshot: resultDocData
		});
	} catch (err) {
		console.warn("Could not mirror to unified test history", err);
	}
	return resultId;
}
async function fetchUserSavedResults(user) {
	const ownerId = getEffectiveOwnerId(user);
	const visitorId = getOrCreateVisitorId();
	if (!isAutomatedAuditEnvironment()) {
		if (user?.uid) try {
			const resultsCol = collection(db, "users", user.uid, "results");
			const q = query(resultsCol, orderBy("createdAt", "desc"));
			const snapshot = await withFirestoreTimeout(getDocs(q), 2500);
			const items = [];
			snapshot.forEach((d) => {
				items.push(d.data());
			});
			if (items.length > 0) {
				try {
					localStorage.setItem(`offline_results_${user.uid}`, JSON.stringify(items));
				} catch {}
				return items;
			}
		} catch {}
		if (hasVisitorCloudData()) try {
			const visSnap = await withFirestoreTimeout(getDoc(doc(db, "visitor_sessions", visitorId)), 2500);
			if (visSnap.exists()) {
				const data = visSnap.data();
				if (Array.isArray(data.results) && data.results.length > 0) {
					try {
						localStorage.setItem(`offline_results_${ownerId}`, JSON.stringify(data.results));
					} catch {}
					return data.results;
				}
			}
		} catch {}
	}
	try {
		const local = localStorage.getItem(`offline_results_${ownerId}`) || localStorage.getItem(`offline_results_${visitorId}`);
		if (local) return JSON.parse(local);
	} catch (e) {
		console.error("Offline cache read error", e);
	}
	return [];
}
async function deleteSavedResultFromHistory(user, resultId) {
	const ownerId = getEffectiveOwnerId(user);
	const visitorId = getOrCreateVisitorId();
	if (user?.uid) try {
		const resultRef = doc(db, "users", user.uid, "results", resultId);
		await deleteDoc(resultRef);
	} catch {}
	try {
		const localKey = `offline_results_${ownerId}`;
		const filtered = JSON.parse(localStorage.getItem(localKey) || "[]").filter((r) => r.id !== resultId);
		localStorage.setItem(localKey, JSON.stringify(filtered));
		localStorage.setItem(`offline_results_${visitorId}`, JSON.stringify(filtered));
		const visRef = doc(db, "visitor_sessions", visitorId);
		await setDoc(visRef, {
			visitorId,
			results: filtered,
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		}, { merge: true });
	} catch (e) {
		console.error("Local cache delete error", e);
	}
}
async function saveUserPsychologyReport(user, report, profile) {
	const now = (/* @__PURE__ */ new Date()).toISOString();
	const visitorId = getOrCreateVisitorId();
	try {
		localStorage.setItem("latest_psychology_report", JSON.stringify(report));
		localStorage.setItem(`psychology_report_${report.testId}`, JSON.stringify(report));
		if (user?.uid) localStorage.setItem(`offline_psych_report_${user.uid}`, JSON.stringify(report));
	} catch (e) {
		console.error("Failed to cache psychology report locally", e);
	}
	try {
		const visRef = doc(db, "visitor_sessions", visitorId);
		await setDoc(visRef, {
			visitorId,
			psychologyReport: report,
			updatedAt: now
		}, { merge: true });
		markVisitorCloudData();
	} catch {}
	if (user?.uid) try {
		const userRef = doc(db, "users", user.uid);
		await setDoc(userRef, {
			id: user.uid,
			displayName: user.displayName || profile?.userName || "المستخدم",
			email: user.email || "",
			archetype: report.primaryArchetypeAr,
			psychologyReport: report,
			updatedAt: now,
			createdAt: now
		}, { merge: true });
	} catch (err) {
		console.warn("Could not persist psychology report to Firestore user doc:", err);
	}
	try {
		await saveUnifiedTestRecord(user || null, {
			testType: "psychology",
			testTitleAr: report.testTitleAr || "مقياس الشخصية المعتمد",
			testCategoryAr: report.testCategoryAr || "المقاييس النفسية والسيكومترية",
			scoreOrArchetype: report.primaryArchetypeAr || `${report.totalScore}%`,
			percentage: report.totalScore || 85,
			badgeColor: report.badgeColor || "#059669",
			keyInsights: [`النمط السيكومتري: ${report.primaryArchetypeAr || "متوازن"}`, ...report.dimensionScores?.slice(0, 2).map((d) => `${d.labelAr}: ${d.score}%`) || []],
			snapshot: report
		});
	} catch (err) {
		console.warn("Could not mirror psychology report to unified test history", err);
	}
}
async function setPublicProfileStatus(user, isPublic, profileData) {
	const now = (/* @__PURE__ */ new Date()).toISOString();
	const profileId = getEffectiveOwnerId(user);
	const publicRef = doc(db, "public_profiles", profileId);
	if (isPublic) try {
		await setDoc(publicRef, {
			id: profileId,
			displayName: profileData.displayName,
			userGender: profileData.userGender,
			userAge: profileData.userAge,
			country: profileData.country,
			city: profileData.city || profileData.country || "المدينة",
			archetype: profileData.archetype,
			contactWhatsapp: profileData.contactWhatsapp || "",
			bio: profileData.bio || "",
			strengths: profileData.strengths || [],
			interests: profileData.interests || [],
			aspirations: profileData.aspirations || [],
			idealPartnerNeeds: profileData.idealPartnerNeeds || "",
			communicationStyle: profileData.communicationStyle || "",
			dimensionScores: profileData.dimensionScores || {
				extraversion: 70,
				emotionalStability: 75,
				openness: 75,
				agreeableness: 78,
				conscientiousness: 76
			},
			isDiscoverable: true,
			createdAt: now,
			updatedAt: now
		}, { merge: true });
	} catch {}
	else try {
		await deleteDoc(publicRef);
	} catch {}
	try {
		localStorage.setItem(`is_public_profile_${profileId}`, isPublic ? "true" : "false");
		if (profileData.contactWhatsapp) localStorage.setItem("user_contact_whatsapp", profileData.contactWhatsapp);
	} catch {}
}
/**
* Fetches real opted-in public user profiles from Firestore /public_profiles
* combined with scientific reference archetype profiles
*/
async function fetchPublicCommunityProfiles() {
	const { COMMUNITY_PROFILES } = await __vitePreload(async () => {
		const { COMMUNITY_PROFILES } = await import("./data-compatibility-s3wwWF9Q.js").then((n) => n.i);
		return { COMMUNITY_PROFILES };
	}, __vite__mapDeps([0]));
	try {
		const snap = await getDocs(collection(db, "public_profiles"));
		const list = [];
		snap.forEach((d) => {
			const data = d.data();
			if (data && data.isDiscoverable !== false && data.displayName) list.push({
				id: d.id,
				displayName: data.displayName,
				userGender: data.userGender || "male",
				userAge: Number(data.userAge) || 26,
				country: data.country || "الأردن",
				city: data.city || data.country || "عمّان",
				avatarUrl: data.avatarUrl || (data.userGender === "female" ? "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=85" : "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=85"),
				archetype: data.archetype || "شخصية متزنة ومتوافقة",
				archetypeBadge: "عضو مسجل ✓",
				category: "both",
				compatibilityScore: 88,
				similarityScore: 85,
				bio: data.bio || `عضو مسجل في منصة مرآة القلوب من ${data.country || "الوطن العربي"} يشارك ملفه السيكومتري للتوافق.`,
				strengths: Array.isArray(data.strengths) && data.strengths.length > 0 ? data.strengths : [
					"تواصل صادق",
					"توافق قيمي",
					"وضوح فكري"
				],
				interests: Array.isArray(data.interests) && data.interests.length > 0 ? data.interests : ["الحوار الفكري", "بناء أسرة متناغمة"],
				aspirations: Array.isArray(data.aspirations) && data.aspirations.length > 0 ? data.aspirations : ["شراكة حياة واعية ومستقرة"],
				idealPartnerNeeds: data.idealPartnerNeeds || "شريك متفهم يقدر الاحترام المتبادل والحوار الهادئ",
				communicationStyle: data.communicationStyle || "حوار صريح وهادئ",
				contactOptions: {
					whatsapp: data.contactWhatsapp || void 0,
					allowDirectChat: true,
					allowInvite: true
				},
				dimensionScores: data.dimensionScores || {
					extraversion: 72,
					emotionalStability: 80,
					openness: 78,
					agreeableness: 82,
					conscientiousness: 80
				}
			});
		});
		return [...list, ...COMMUNITY_PROFILES];
	} catch {
		return [...COMMUNITY_PROFILES];
	}
}
function buildTemporalEvolutionSummary(records, nowMs = Date.now()) {
	const oneDayMs = 864e5;
	const thirtyDaysMs = 30 * oneDayMs;
	const yearMs = 365 * oneDayMs;
	const startOfToday = new Date(nowMs);
	startOfToday.setHours(0, 0, 0, 0);
	const todayCutoff = startOfToday.getTime();
	const monthCutoff = nowMs - thirtyDaysMs;
	const yearCutoff = nowMs - yearMs;
	const yearRecords = [];
	const monthRecords = [];
	const todayRecords = [];
	records.forEach((r) => {
		const ts = new Date(r.createdAt).getTime();
		if (!Number.isFinite(ts)) return;
		if (ts >= todayCutoff) todayRecords.push(r);
		else if (ts >= monthCutoff) monthRecords.push(r);
		else if (ts >= yearCutoff) yearRecords.push(r);
		else yearRecords.push(r);
	});
	const summarize = (key, labelAr, list) => {
		if (list.length === 0) return {
			periodKey: key,
			periodLabelAr: labelAr,
			avgScore: 0,
			count: 0,
			emotionalAvg: 0,
			cognitiveAvg: 0,
			relationalAvg: 0
		};
		const avgAll = Math.round(list.reduce((s, r) => s + (Number(r.percentage) || 0), 0) / list.length);
		const pickByType = (types, fallback) => {
			const sub = list.filter((r) => types.includes(r.testType));
			if (sub.length === 0) return fallback;
			return Math.round(sub.reduce((s, r) => s + (Number(r.percentage) || 0), 0) / sub.length);
		};
		return {
			periodKey: key,
			periodLabelAr: labelAr,
			avgScore: avgAll,
			count: list.length,
			emotionalAvg: pickByType(["psychology", "tiered_assessment"], avgAll),
			cognitiveAvg: pickByType(["intelligence", "tiered_assessment"], avgAll),
			relationalAvg: pickByType(["partner_compatibility", "personality_comparison"], avgAll)
		};
	};
	const bYear = summarize("year", "العام الماضي", yearRecords);
	const bMonth = summarize("month", "الشهر الماضي", monthRecords);
	const bToday = summarize("today", "اليوم", todayRecords);
	const baseline = bYear.count > 0 ? bYear.avgScore : bMonth.count > 0 ? bMonth.avgScore : bToday.avgScore;
	const trendDelta = (bToday.count > 0 ? bToday.avgScore : bMonth.count > 0 ? bMonth.avgScore : bYear.avgScore) - baseline;
	const trendDirection = trendDelta >= 3 ? "up" : trendDelta <= -3 ? "down" : "steady";
	const trendInsightAr = records.length === 0 ? "ابدأ بإجراء أول اختبار نفسي أو توافقي لتفعيل رسم منحنى التطور الزمني عبر اليوم والشهر والعام." : trendDirection === "up" ? `تطور إيجابي بمقدار +${trendDelta}% مقارنة بسجلاتك الأقدم، مما يعكس تنامياً في الوعي العاطفي والاستقرار العلائقي.` : trendDirection === "down" ? `انخفاض طفيف بمقدار ${trendDelta}% مقارنة بالمعدل الأقدم؛ قد يرتبط بضغوط ظرفية أو خوض مقاييس أعمق لأول مرة.` : "ثبات سيكومتري مستقر عبر الفترات الزمنية يعكس وضوحاً راسخاً في السمات والقيم الشخصية.";
	return {
		buckets: [
			bYear,
			bMonth,
			bToday
		],
		trendDelta,
		trendDirection,
		trendInsightAr
	};
}
async function saveUnifiedTestRecord(user, record) {
	const recordId = `test_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
	const now = (/* @__PURE__ */ new Date()).toISOString();
	const ownerId = getEffectiveOwnerId(user);
	const visitorId = getOrCreateVisitorId();
	const fullRecord = {
		...record,
		id: recordId,
		userId: ownerId,
		createdAt: now
	};
	let updatedHistory = [fullRecord];
	try {
		const localKey = `offline_test_history_${ownerId}`;
		updatedHistory = [fullRecord, ...JSON.parse(localStorage.getItem(localKey) || "[]")].slice(0, 50);
		localStorage.setItem(localKey, JSON.stringify(updatedHistory));
		localStorage.setItem(`offline_test_history_${visitorId}`, JSON.stringify(updatedHistory));
		localStorage.setItem("offline_test_history_guest", JSON.stringify(updatedHistory));
	} catch (e) {
		console.error("Local backup failed", e);
	}
	if (user?.uid) try {
		const testDocRef = doc(db, "users", user.uid, "test_history", recordId);
		await setDoc(testDocRef, fullRecord);
	} catch (err) {
		handleFirestoreError(err, "write", `users/${user.uid}/test_history/${recordId}`);
	}
	try {
		const visRef = doc(db, "visitor_sessions", visitorId);
		await setDoc(visRef, {
			visitorId,
			testHistory: updatedHistory.slice(0, 25),
			updatedAt: now
		}, { merge: true });
		markVisitorCloudData();
	} catch (err) {
		console.warn("Could not sync test_history to visitor_sessions in Firestore", err);
	}
	return recordId;
}
async function fetchUnifiedTestHistory(user) {
	const ownerId = getEffectiveOwnerId(user);
	const visitorId = getOrCreateVisitorId();
	if (!isAutomatedAuditEnvironment()) {
		if (user?.uid) try {
			const historyCol = collection(db, "users", user.uid, "test_history");
			const q = query(historyCol, orderBy("createdAt", "desc"));
			const snapshot = await withFirestoreTimeout(getDocs(q), 2500);
			const items = [];
			snapshot.forEach((d) => {
				items.push(d.data());
			});
			if (items.length > 0) {
				try {
					localStorage.setItem(`offline_test_history_${user.uid}`, JSON.stringify(items));
				} catch {}
				return items;
			}
		} catch {}
		if (hasVisitorCloudData()) try {
			const visSnap = await withFirestoreTimeout(getDoc(doc(db, "visitor_sessions", visitorId)), 2500);
			if (visSnap.exists()) {
				const data = visSnap.data();
				if (Array.isArray(data.testHistory) && data.testHistory.length > 0) {
					try {
						localStorage.setItem(`offline_test_history_${ownerId}`, JSON.stringify(data.testHistory));
					} catch {}
					return data.testHistory;
				}
			}
		} catch {}
	}
	try {
		const local = localStorage.getItem(`offline_test_history_${ownerId}`) || localStorage.getItem(`offline_test_history_${visitorId}`) || localStorage.getItem("offline_test_history_guest");
		if (local) {
			const parsed = JSON.parse(local);
			if (Array.isArray(parsed) && parsed.length > 0) return parsed;
		}
	} catch {}
	try {
		const compResults = await fetchUserSavedResults(user);
		if (compResults.length > 0) return compResults.map((c) => ({
			id: c.id,
			userId: c.userId,
			testType: "partner_compatibility",
			testTitleAr: `توافق الشريك: ${c.partnerName}`,
			testCategoryAr: "التوافق الفكري والاجتماعي",
			scoreOrArchetype: `${c.compatibilityScore}% توافق`,
			percentage: c.compatibilityScore,
			createdAt: c.createdAt,
			badgeColor: "#2563eb",
			keyInsights: c.partnerTraits.slice(0, 3),
			snapshot: c
		}));
	} catch {}
	return [];
}
async function deleteUnifiedTestRecord(user, recordId) {
	const ownerId = getEffectiveOwnerId(user);
	const visitorId = getOrCreateVisitorId();
	if (user?.uid) try {
		const testDocRef = doc(db, "users", user.uid, "test_history", recordId);
		await deleteDoc(testDocRef);
	} catch {}
	try {
		const localKey = `offline_test_history_${ownerId}`;
		const filtered = JSON.parse(localStorage.getItem(localKey) || localStorage.getItem(`offline_test_history_${visitorId}`) || "[]").filter((r) => r.id !== recordId);
		localStorage.setItem(localKey, JSON.stringify(filtered));
		localStorage.setItem(`offline_test_history_${visitorId}`, JSON.stringify(filtered));
		localStorage.setItem("offline_test_history_guest", JSON.stringify(filtered));
		const visRef = doc(db, "visitor_sessions", visitorId);
		await setDoc(visRef, {
			visitorId,
			testHistory: filtered,
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		}, { merge: true });
	} catch {}
}
/**
* Permanently deletes all local and cloud psychometric, intelligence, compatibility, and profile data for the user
*/
async function purgeAllUserDataPermanently(user) {
	const visitorId = getOrCreateVisitorId();
	const ownerId = getEffectiveOwnerId(user);
	try {
		await deleteDoc(doc(db, "visitor_sessions", visitorId));
	} catch {}
	if (user?.uid) {
		try {
			const historySnap = await getDocs(collection(db, "users", user.uid, "test_history"));
			for (const d of historySnap.docs) await deleteDoc(d.ref);
		} catch {}
		try {
			const savedSnap = await getDocs(collection(db, "users", user.uid, "saved_results"));
			for (const d of savedSnap.docs) await deleteDoc(d.ref);
		} catch {}
		try {
			const psychSnap = await getDocs(collection(db, "users", user.uid, "psychology_reports"));
			for (const d of psychSnap.docs) await deleteDoc(d.ref);
		} catch {}
		try {
			await deleteDoc(doc(db, "users", user.uid));
		} catch {}
	}
	try {
		const keysToRemove = [];
		for (let i = 0; i < localStorage.length; i++) {
			const k = localStorage.key(i);
			if (k && (k.startsWith("mirat_") || k.startsWith("offline_") || k.includes("intelligence") || k.includes("psych") || k.includes(ownerId) || k.includes(visitorId)) && k !== "mirat_al_quloob_theme" && k !== "mirat_language") keysToRemove.push(k);
		}
		keysToRemove.forEach((k) => localStorage.removeItem(k));
		localStorage.removeItem(VISITOR_PROFILE_STORAGE_KEY);
		localStorage.removeItem(VISITOR_LATEST_RESULT_KEY);
		localStorage.removeItem(VISITOR_ID_STORAGE_KEY);
	} catch {}
}
//#endregion
export { fetchUnifiedTestHistory as a, savePersistentUserProfile as c, saveUserPsychologyReport as d, setPublicProfileStatus as f, fetchPublicCommunityProfiles as i, saveTestResultToHistory as l, deleteSavedResultFromHistory as n, fetchUserSavedResults as o, userHistoryService_exports as p, deleteUnifiedTestRecord as r, purgeAllUserDataPermanently as s, buildTemporalEvolutionSummary as t, saveUnifiedTestRecord as u };
