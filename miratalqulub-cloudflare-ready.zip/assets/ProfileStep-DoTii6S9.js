import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { D as Sparkles, Kt as FileCheck2, Lt as Globe, Nn as ArrowRight, Nt as History, P as ShieldCheck, Pn as ArrowLeft, Pt as Heart, Rt as GraduationCap, Sn as Calendar, bn as Check, c as UsersRound, dt as MessageSquareHeart, en as Database, hn as CircleAlert, kt as Landmark, l as User, rt as PenLine, yn as ChevronDown } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import { d as useAppTheme, l as useLanguage, o as TestScoringTrustBanner, s as OFFICIAL_LOGO_URL } from "./index-C5uCeetQ.js";
import { n as AnimatePresence, t as motion } from "./vendor-motion-BS7ODJw7.js";
import { c as EDUCATION_LEVELS, l as LIFESTYLE_OUTLOOKS, s as COUNTRIES_LIST } from "./data-compatibility-s3wwWF9Q.js";
import { r as ScientificClinicalDisclaimerBanner } from "./PsychometricAcademicFraming-DuCcNyEP.js";
import { n as getGenerationalCohort } from "./socioculturalScience-BtpE3Kxg.js";
import { detectUserLocationAndNationality, getNationalityEntryByCountry } from "./locationNationalityDetector-u5K3h3nb.js";
//#region src/components/ProfileStep.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var CULTURAL_REGIONAL_OPTIONS = [
	{
		id: "gulf",
		tag: "خليجي",
		labelAr: "ثقافة خليجية (قيم الكرم الأصيل، الترابط الأسري، والوقار الاجتماعي)",
		labelEn: "Gulf Cultural Heritage (Hospitality, strong family kinship, and social dignity)"
	},
	{
		id: "levantine",
		tag: "شامي",
		labelAr: "ثقافة شامية (الدفء الأسري، الدبلوماسية الاجتماعية، والتذوق الثقافي)",
		labelEn: "Levantine Cultural Heritage (Warmth, social diplomacy, and cultural appreciation)"
	},
	{
		id: "egyptian",
		tag: "مصري",
		labelAr: "ثقافة مصرية (الروح المرحة، الألفة الاجتماعية، والمرونة الحياتية)",
		labelEn: "Egyptian Cultural Heritage (Humor, social familiarity, and adaptive resilience)"
	},
	{
		id: "maghreb",
		tag: "مغاربي",
		labelAr: "ثقافة مغاربية (الأصالة المتوسطية، الاعتزاز بالهوية، والانفتاح الثقافي)",
		labelEn: "Maghreb Cultural Heritage (Mediterranean authenticity, identity pride, and openness)"
	},
	{
		id: "iraqi",
		tag: "عراقي",
		labelAr: "ثقافة رافدينية عراقية (الشهامة، العمق الفكري والأدبي، والوفاء العائلي)",
		labelEn: "Mesopotamian / Iraqi Heritage (Chivalry, literary depth, and family loyalty)"
	},
	{
		id: "nile_valley",
		tag: "وادي النيل",
		labelAr: "ثقافة وادي النيل (الطيبة الفطرية، التكافل المجتمعي، والسكينة الروحية)",
		labelEn: "Nile Valley Heritage (Innate kindness, communal solidarity, and serenity)"
	},
	{
		id: "mediterranean",
		tag: "تركي/أوراسي",
		labelAr: "ثقافة متوسطية / أوراسية (التوازن بين الأصالة الشرقية والحداثة العملية)",
		labelEn: "Mediterranean / Eurasian Heritage (Balance of Eastern traditions and modern pragmatism)"
	},
	{
		id: "global",
		tag: "عالمي",
		labelAr: "ثقافة عالمية متعددة الروافد (انفتاح فكري وحوار عابر للثقافات)",
		labelEn: "Global / Multicultural Outlook (Cross-cultural dialogue and intellectual openness)"
	}
];
var BILINGUAL_EDUCATION_OPTIONS = [
	{
		value: EDUCATION_LEVELS[0],
		labelAr: "تعليم جامعي عالي (بكالوريوس فما فوق)",
		labelEn: "University Degree (Bachelor’s or higher)"
	},
	{
		value: EDUCATION_LEVELS[1],
		labelAr: "دراسات عليا وأبحاث (ماجستير / دكتوراه)",
		labelEn: "Postgraduate & Academic Research (Master’s / PhD)"
	},
	{
		value: EDUCATION_LEVELS[2],
		labelAr: "تخصص تقني أو مهني متقدم وريادة أعمال",
		labelEn: "Advanced Technical / Professional & Entrepreneurship"
	},
	{
		value: EDUCATION_LEVELS[3],
		labelAr: "مثقف وشغوف بالتعلم الذاتي وتطوير الفكر",
		labelEn: "Autodidact & Lifelong Intellectual Learner"
	}
];
var BILINGUAL_LIFESTYLE_OPTIONS = [
	{
		value: LIFESTYLE_OUTLOOKS[0],
		labelAr: "بيئة عائلية مترابطة مع الحفاظ على استقلالية وخصوصية الحياة الزوجية",
		labelEn: "Close family ties balanced with strong marital privacy and autonomy"
	},
	{
		value: LIFESTYLE_OUTLOOKS[1],
		labelAr: "بيئة عصرية طموحة تركز على النجاح المهني المشترك والشغف بالسفر والمعرفة",
		labelEn: "Ambitious modern lifestyle focused on mutual career growth and travel"
	},
	{
		value: LIFESTYLE_OUTLOOKS[2],
		labelAr: "بيئة أسرية هادئة تميل للاستقرار والسكينة وتأسيس بيت دافئ متوازن",
		labelEn: "Calm home-centered environment prioritizing serenity and stability"
	},
	{
		value: LIFESTYLE_OUTLOOKS[3],
		labelAr: "بيئة اجتماعية منفتحة تكثر فيها المبادرات الثقافية والصداقات الراقية",
		labelEn: "Socially active lifestyle rich in cultural events and refined friendships"
	}
];
var CORE_VALUES_OPTIONS = [
	{
		id: "serenity_respect",
		labelAr: "السكينة الروحية، المودة، والاحترام المتبادل كأولوية قصوى",
		labelEn: "Emotional serenity, mutual affection, and unconditional respect"
	},
	{
		id: "intellectual_growth",
		labelAr: "النمو الفكري والمهني المشترك والحوار الثقافي المستمر",
		labelEn: "Shared intellectual & career growth with continuous dialogue"
	},
	{
		id: "family_authenticity",
		labelAr: "الأصالة القيمية، التماسك الأسري، وتنشئة جيل متزن أخلاقياً",
		labelEn: "Value authenticity, family cohesion, and nurturing balanced children"
	},
	{
		id: "autonomy_partnership",
		labelAr: "الشراكة المرنة واحترام المساحة الشخصية والاستقلالية الناضجة",
		labelEn: "Flexible partnership respecting personal space and mature autonomy"
	}
];
var COMMUNICATION_CONFLICT_OPTIONS = [
	{
		id: "calm_analytical",
		labelAr: "الحوار الهادئ المباشر وتحليل أسباب الخلاف بموضوعية بعيداً عن اللوم (نموذج غوتمان)",
		labelEn: "Calm direct dialogue analyzing root causes objectively without blame (Gottman model)"
	},
	{
		id: "pause_then_resolve",
		labelAr: "التهدئة الانفعالية المؤقتة عند التوتر ثم العودة للنقاش الودّي المنظم",
		labelEn: "Brief emotional cooling-off period followed by structured, warm resolution"
	},
	{
		id: "empathy_reassurance",
		labelAr: "المصارحة الوجدانية الفورية وتغليب الاحتواء العاطفي وطمأنة الشريك أولاً",
		labelEn: "Immediate emotional reassurance and empathetic validation before problem-solving"
	},
	{
		id: "pragmatic_compromise",
		labelAr: "البحث العملي السريع عن حلول وسط عادلة وتجاوز التفاصيل الجانبية الصغيرة",
		labelEn: "Pragmatic, rapid compromise focusing on fair solutions over minor details"
	}
];
var FINANCIAL_FAMILY_VISION_OPTIONS = [
	{
		id: "shared_transparent_budget",
		labelAr: "تخطيط مالي تشاركي وميزانية أسرية موحدة بشفافية كاملة وأهداف ادخارية مشتركة",
		labelEn: "Joint financial planning, transparent unified household budget, and shared savings goals"
	},
	{
		id: "hybrid_autonomy_pool",
		labelAr: "صندوق التزامات أسرية مشترك مع احتفاظ كل شريك بذمته واستقلاليته المالية الخاصة",
		labelEn: "Shared household expense pool while maintaining individual financial autonomy"
	},
	{
		id: "quality_of_life_investment",
		labelAr: "أولوية الاستثمار في جودة الحياة اليومية، التعليم النوعي، والتجارب الأسرية الملهمة",
		labelEn: "Prioritizing investment in quality of life, education, and enriching family experiences"
	},
	{
		id: "long_term_security",
		labelAr: "الادخار الاستراتيجي المحافظ وبناء الأصول والأمان المالي طويل الأمد للأسرة",
		labelEn: "Conservative strategic saving and long-term asset building for family security"
	}
];
var CURRENT_YEAR = 2026;
var BIRTH_YEARS = Array.from({ length: 55 }, (_, i) => 2008 - i);
var ProfileStep = ({ onStart, initialProfile, savedTestsCount = 0, onOpenSavedHistory, onOpenBlindDate, onOpenWebsiteSection, onOpenPsychologyTests, onOpenIntelligenceTests, onOpenUserDashboard, onOpenArticles, onOpenNovels, onOpenContactFeedback, onBackToHome }) => {
	const { language, direction, isRTL, t } = useLanguage();
	const [theme] = useAppTheme();
	const isAr = language === "ar";
	const isLight = theme === "light";
	const [wizardStep, setWizardStep] = (0, import_react.useState)(1);
	const [userName, setUserName] = (0, import_react.useState)(initialProfile?.userName || "");
	const [userGender, setUserGender] = (0, import_react.useState)(initialProfile?.userGender || "male");
	const [partnerGender, setPartnerGender] = (0, import_react.useState)(initialProfile?.partnerGender || "female");
	const initialBirthYear = initialProfile?.birthYear || (initialProfile?.userBirthDate ? parseInt(initialProfile.userBirthDate.slice(0, 4), 10) : 0) || (initialProfile?.userAge ? CURRENT_YEAR - initialProfile.userAge : 1998);
	const [birthYear, setBirthYear] = (0, import_react.useState)(birthYearInBounds(initialBirthYear) ? initialBirthYear : 1998);
	const [country, setCountry] = (0, import_react.useState)(initialProfile?.country || "المملكة العربية السعودية");
	const [ethnicity, setEthnicity] = (0, import_react.useState)(initialProfile?.ethnicity || "خليجي");
	const [educationLevel, setEducationLevel] = (0, import_react.useState)(initialProfile?.educationLevel || EDUCATION_LEVELS[0]);
	const [lifestyleOutlook, setLifestyleOutlook] = (0, import_react.useState)(initialProfile?.lifestyleOutlook || LIFESTYLE_OUTLOOKS[0]);
	const [coreValuesPriority, setCoreValuesPriority] = (0, import_react.useState)(initialProfile?.coreValuesPriority || CORE_VALUES_OPTIONS[0].labelAr);
	const [communicationAndConflictStyle, setCommunicationAndConflictStyle] = (0, import_react.useState)(initialProfile?.communicationAndConflictStyle || COMMUNICATION_CONFLICT_OPTIONS[0].labelAr);
	const [financialAndFamilyVision, setFinancialAndFamilyVision] = (0, import_react.useState)(initialProfile?.financialAndFamilyVision || FINANCIAL_FAMILY_VISION_OPTIONS[0].labelAr);
	const [privacyConsentAccepted, setPrivacyConsentAccepted] = (0, import_react.useState)(initialProfile?.privacyConsentAccepted || false);
	const [consentError, setConsentError] = (0, import_react.useState)(false);
	const [autoDetectedLocation, setAutoDetectedLocation] = (0, import_react.useState)(null);
	const [activeHubTab, setActiveHubTab] = (0, import_react.useState)("all");
	const [showLogoPreviewModal, setShowLogoPreviewModal] = (0, import_react.useState)(false);
	const [isDownloadingLogo, setIsDownloadingLogo] = (0, import_react.useState)(null);
	function birthYearInBounds(yr) {
		return !isNaN(yr) && yr >= 1945 && yr <= 2008;
	}
	(0, import_react.useEffect)(() => {
		if (initialProfile) {
			if (initialProfile.userGender) setUserGender(initialProfile.userGender);
			if (initialProfile.partnerGender) setPartnerGender(initialProfile.partnerGender);
			if (initialProfile.userName !== void 0) setUserName(initialProfile.userName);
			if (initialProfile.country) setCountry(initialProfile.country);
			if (initialProfile.ethnicity) setEthnicity(initialProfile.ethnicity);
			if (initialProfile.educationLevel) setEducationLevel(initialProfile.educationLevel);
			if (initialProfile.lifestyleOutlook) setLifestyleOutlook(initialProfile.lifestyleOutlook);
			if (initialProfile.coreValuesPriority) setCoreValuesPriority(initialProfile.coreValuesPriority);
			if (initialProfile.communicationAndConflictStyle) setCommunicationAndConflictStyle(initialProfile.communicationAndConflictStyle);
			if (initialProfile.financialAndFamilyVision) setFinancialAndFamilyVision(initialProfile.financialAndFamilyVision);
			if (initialProfile.birthYear && birthYearInBounds(initialProfile.birthYear)) setBirthYear(initialProfile.birthYear);
			else if (initialProfile.userAge) {
				const computedYr = CURRENT_YEAR - initialProfile.userAge;
				if (birthYearInBounds(computedYr)) setBirthYear(computedYr);
			}
		}
	}, [initialProfile]);
	(0, import_react.useEffect)(() => {
		let mounted = true;
		detectUserLocationAndNationality({
			partnerGender,
			fallbackCountry: initialProfile?.country || country
		}).then((detected) => {
			if (!mounted) return;
			setAutoDetectedLocation(detected);
			if (!initialProfile?.country) {
				const matchedInList = COUNTRIES_LIST.find((c) => c.code === detected.countryCode || c.name === detected.countryNameAr || c.name.includes(detected.countryNameAr) || detected.countryNameAr.includes(c.name));
				if (matchedInList) setCountry(matchedInList.name);
				const matchedCultural = CULTURAL_REGIONAL_OPTIONS.find((opt) => detected.ethnicityTag.includes(opt.tag));
				if (matchedCultural) setEthnicity(matchedCultural.tag);
			}
		});
		return () => {
			mounted = false;
		};
	}, [partnerGender]);
	const computedAge = Math.max(18, CURRENT_YEAR - birthYear);
	const syntheticBirthDate = `${birthYear}-01-01`;
	const previewCohort = getGenerationalCohort(syntheticBirthDate, computedAge);
	const handleUserGenderSelect = (gender) => {
		soundManager.playTap();
		setUserGender(gender);
		setPartnerGender(gender === "male" ? "female" : "male");
	};
	const handleCountryChange = (countryName) => {
		soundManager.playTap();
		setCountry(countryName);
		const manualDetected = getNationalityEntryByCountry(countryName, partnerGender);
		setAutoDetectedLocation(manualDetected);
		const found = COUNTRIES_LIST.find((c) => c.name === countryName);
		if (found && found.defaultEthnicity) {
			const matchedCultural = CULTURAL_REGIONAL_OPTIONS.find((opt) => found.defaultEthnicity.includes(opt.tag));
			if (matchedCultural) setEthnicity(matchedCultural.tag);
		}
	};
	const goToNextStep = () => {
		soundManager.playTap();
		if (wizardStep < 4) setWizardStep((prev) => prev + 1);
	};
	const goToPrevStep = () => {
		soundManager.playTap();
		if (wizardStep > 1) setWizardStep((prev) => prev - 1);
	};
	const handleFinalSubmit = (e) => {
		e.preventDefault();
		if (!privacyConsentAccepted) {
			soundManager.playTap();
			setConsentError(true);
			return;
		}
		setConsentError(false);
		soundManager.playNext();
		const combinedCulturalSummary = `${coreValuesPriority} | ${communicationAndConflictStyle} | ${financialAndFamilyVision}`;
		const resolvedNat = autoDetectedLocation || getNationalityEntryByCountry(country, partnerGender);
		onStart({
			userGender,
			partnerGender,
			userAge: computedAge,
			birthYear,
			userName: userName.trim() || void 0,
			userBirthDate: syntheticBirthDate,
			country,
			ethnicity,
			educationLevel,
			lifestyleOutlook,
			partnerFeaturesPreference: combinedCulturalSummary,
			coreValuesPriority,
			communicationAndConflictStyle,
			financialAndFamilyVision,
			privacyConsentAccepted: true,
			detectedCountryCode: resolvedNat.countryCode,
			detectedNationalityAr: resolvedNat.nationalityAr,
			detectedNationalityEn: resolvedNat.nationalityEn,
			detectedEthnicTraitsPrompt: resolvedNat.ethnicFacialTraitsPromptEn,
			detectedEthnicTraitsAr: resolvedNat.ethnicFacialTraitsDescriptionAr,
			isLocationAutoDetected: true
		});
	};
	const wizardStepsMeta = [
		{
			step: 1,
			titleAr: "١. الأساسيات",
			titleEn: "1. Fundamentals",
			subAr: "اللقب، الجنس، سنة الميلاد، والبلد",
			subEn: "Alias, Gender, Birth Year & Country",
			icon: User
		},
		{
			step: 2,
			titleAr: "٢. الثقافة ونمط الحياة",
			titleEn: "2. Culture & Lifestyle",
			subAr: "الانتماء الثقافي الإقليمي والتعليم",
			subEn: "Regional Heritage & Education",
			icon: Globe
		},
		{
			step: 3,
			titleAr: "٣. القيم والتواصل",
			titleEn: "3. Values & Dialogue",
			subAr: "حل الخلافات والرؤية المالية والأسرية",
			subEn: "Conflict Resolution & Family Vision",
			icon: MessageSquareHeart
		},
		{
			step: 4,
			titleAr: "٤. المراجعة والموافقة",
			titleEn: "4. Review & Consent",
			subAr: "ملخص البيانات والموافقة الإلزامية",
			subEn: "Summary & Mandatory Privacy Consent",
			icon: FileCheck2
		}
	];
	const selectedCultureObj = CULTURAL_REGIONAL_OPTIONS.find((c) => c.tag === ethnicity || ethnicity.includes(c.tag)) || CULTURAL_REGIONAL_OPTIONS[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `w-full max-w-4xl mx-auto px-4 py-6 transition-colors duration-300 ${isLight ? "text-slate-900" : "text-white"}`,
		dir: direction,
		children: [
			onBackToHome && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `flex flex-wrap items-center justify-between gap-3 pb-4 mb-5 border-b ${isLight ? "border-slate-200" : "border-white/10"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 text-xs text-slate-400",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onBackToHome,
							className: "hover:text-rose-500 transition cursor-pointer flex items-center gap-1 font-bold",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "الرئيسية" : "Home" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "/" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `font-bold ${isLight ? "text-slate-900" : "text-white"}`,
							children: isAr ? "قسم كاشف شريك الحياة" : "Partner Compatibility Detector"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onBackToHome,
					className: `px-3.5 py-1.5 rounded-xl border text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${isLight ? "bg-rose-50 hover:bg-rose-100 border-rose-200 text-rose-700" : "bg-rose-500/20 hover:bg-rose-500/30 border-rose-500/40 text-rose-300"}`,
					children: [isRTL ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "العودة للرئيسية" : "Back to Home" })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `mb-6 p-3.5 sm:p-4 rounded-3xl border flex flex-col sm:flex-row items-center justify-between gap-3 shadow-sm ${isLight ? "bg-white border-blue-200 text-slate-800" : "bg-slate-900/90 border-blue-500/30 text-white"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `w-10 h-10 rounded-2xl border flex items-center justify-center shrink-0 ${isLight ? "bg-emerald-50 border-emerald-200 text-emerald-700" : "bg-blue-950/70 border-blue-500/50 text-emerald-400"}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "w-5 h-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs sm:text-sm font-extrabold font-['Alexandria']",
							children: isAr ? "الموقع مشرف عليه ومُدار بواسطة مجموعة من المهندسين المتخصصين" : "Engineered & Supervised by Independent Specialist Software Engineers"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `text-[10px] font-mono font-bold ${isLight ? "text-blue-700" : "text-blue-300"}`,
							children: isAr ? "الأردن - عمّان" : "Amman, Jordan"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: `text-[11px] sm:text-xs mt-0.5 ${isLight ? "text-slate-600" : "text-slate-300"}`,
						children: [
							isAr ? "تواصل واستفسارات وملاحظات عبر البريد المعتمد:" : "Official contact & inquiries:",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono font-bold underline select-all",
								children: "one497303@gmail.com"
							})
						]
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `flex items-center gap-2 shrink-0 text-[11px] font-mono ${isLight ? "text-emerald-700 font-bold" : "text-slate-300"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-2 h-2 rounded-full bg-emerald-500 animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "تشفير TLS 1.3 معتمد" : "TLS 1.3 Encrypted" })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `mb-6 p-6 sm:p-8 rounded-3xl border text-start space-y-5 ${isLight ? "bg-white border-rose-200/90 shadow-sm" : "bg-slate-900/80 border-rose-500/25 shadow-lg"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-4 border-b pb-4 border-slate-200 dark:border-white/10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-12 h-12 rounded-2xl p-0.5 bg-gradient-to-tr from-rose-500 via-pink-500 to-violet-600 shadow-md shadow-rose-500/20 shrink-0 overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-full h-full rounded-[14px] bg-[#0b0e17] overflow-hidden flex items-center justify-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: OFFICIAL_LOGO_URL,
										alt: isAr ? "شعار مرآة القلوب" : "Mirror of Hearts Logo",
										width: 48,
										height: 48,
										decoding: "async",
										className: "w-full h-full object-cover rounded-[14px]"
									})
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] font-extrabold text-rose-500 uppercase tracking-wider block",
								children: isAr ? "قسم كاشف شريك الحياة" : "Partner Compatibility Detector Section"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: `text-xl sm:text-2xl md:text-3xl font-black font-['Alexandria',sans-serif] ${isLight ? "text-slate-900" : "text-white"}`,
								children: isAr ? "فهم أعمق للتوافق بين الشركاء" : "Deeper Understanding of Partner Compatibility"
							})] })]
						}), onOpenBlindDate && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								soundManager.playTap();
								onOpenBlindDate();
							},
							className: "px-4 py-2 rounded-xl bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 text-white text-xs font-extrabold transition cursor-pointer shadow-sm flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "w-3.5 h-3.5 fill-current" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "تجربة اللقاء الأعمى (The Blind Date)" : "Launch The Blind Date" })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: `text-xs sm:text-sm leading-relaxed ${isLight ? "text-slate-600" : "text-slate-300"}`,
						children: isAr ? "يساعدك قسم كاشف شريك الحياة على استكشاف جوانب التوافق النفسي والعاطفي والفكري والسلوكي بين شخصين، بهدف فهم نقاط الانسجام ومجالات الاختلاف وبناء علاقة أكثر وعياً وتوازناً." : "The Partner Compatibility Detector section helps you explore psychological, emotional, intellectual, and behavioral compatibility between two partners to understand areas of harmony and build a balanced, mindful relationship."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 md:grid-cols-2 gap-4 pt-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `p-4 rounded-2xl border space-y-2.5 ${isLight ? "bg-rose-50/50 border-rose-200/80" : "bg-slate-950/60 border-white/10"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: `text-xs sm:text-sm font-black font-['Alexandria'] ${isLight ? "text-rose-900" : "text-rose-300"}`,
								children: isAr ? "مميزات القسم:" : "Section Features:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-semibold",
								children: (isAr ? [
									"تحليل شامل لأبعاد التوافق",
									"قياس التوافق العاطفي والفكري",
									"مقارنة القيم وأسلوب الحياة",
									"تقارير واضحة ومبسطة",
									"توصيات لتعزيز التفاهم",
									"خصوصية كاملة للبيانات"
								] : [
									"Comprehensive compatibility analysis",
									"Emotional & intellectual alignment",
									"Values & lifestyle comparison",
									"Clear and structured reports",
									"Actionable harmony advice",
									"Complete data privacy (TLS 1.3)"
								]).map((item, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-emerald-500 font-bold",
										children: "✓"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: isLight ? "text-slate-700" : "text-slate-200",
										children: item
									})]
								}, idx))
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `p-4 rounded-2xl border space-y-2.5 ${isLight ? "bg-indigo-50/50 border-indigo-200/80" : "bg-slate-950/60 border-white/10"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: `text-xs sm:text-sm font-black font-['Alexandria'] ${isLight ? "text-indigo-900" : "text-indigo-300"}`,
								children: isAr ? "ماذا ستجد في هذا القسم؟" : "What You Will Find Here:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-1.5",
								children: (isAr ? [
									"التوافق العاطفي",
									"التوافق الفكري",
									"التوافق السلوكي",
									"التوافق القيمي",
									"نقاط الانسجام",
									"التحديات المحتملة",
									"التقرير النهائي للتوافق"
								] : [
									"Emotional Compatibility",
									"Intellectual Compatibility",
									"Behavioral Compatibility",
									"Values Alignment",
									"Harmony Strengths",
									"Potential Challenges",
									"Final Compatibility Report"
								]).map((tag, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `px-2.5 py-1 rounded-xl text-[11px] font-bold border ${isLight ? "bg-white border-indigo-200 text-indigo-800" : "bg-indigo-500/10 border-indigo-500/30 text-indigo-200"}`,
									children: tag
								}, idx))
							})]
						})]
					})
				]
			}),
			(activeHubTab === "all" || activeHubTab === "compatibility") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-3xl mx-auto space-y-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScientificClinicalDisclaimerBanner, {
						testType: "compatibility",
						testTitleAr: "حاسبة التوافق وكاشف الشريك (4 خطوات)",
						testTitleEn: "4-Step Compatibility & Partner Detector"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TestScoringTrustBanner, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `p-4 rounded-3xl border flex flex-col sm:flex-row items-center justify-between gap-3 ${isLight ? "bg-emerald-50/70 border-emerald-200 text-slate-800" : "bg-gradient-to-l from-emerald-950/60 via-slate-900/90 to-blue-950/60 border-emerald-500/30 text-white"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 text-start",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `w-10 h-10 rounded-2xl border flex items-center justify-center shrink-0 ${isLight ? "bg-white border-emerald-200 text-emerald-600" : "bg-emerald-500/15 border-emerald-400/30 text-emerald-300"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Database, { className: "w-5 h-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center gap-2 flex-wrap",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs sm:text-sm font-extrabold font-['Alexandria']",
									children: isAr ? "معالج كاشف التوافق الذكي (4 خطوات منهجية وفق مبدأ تقليل البيانات)" : "4-Step Smart Compatibility Wizard (Data Minimization Compliant)"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: `text-[11px] mt-0.5 ${isLight ? "text-slate-600" : "text-slate-300"}`,
								children: isAr ? "يقتصر النموذج على اللقب وسنة الميلاد والتفضيلات الثقافية والقيمية دون طلب أي بيانات حساسة." : "Collects only your alias, birth year, and cultural/value preferences without sensitive personal data."
							})] })]
						}), onOpenSavedHistory && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								soundManager.playTap();
								onOpenSavedHistory();
							},
							className: `w-full sm:w-auto px-3.5 py-2 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shrink-0 ${isLight ? "bg-white hover:bg-emerald-100 border-emerald-300 text-emerald-800" : "bg-emerald-600/25 hover:bg-emerald-600/40 text-emerald-200 border-emerald-400/40"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								isAr ? "سجل نتائجي" : "Saved History",
								" ",
								savedTestsCount > 0 ? `(${savedTestsCount})` : ""
							] })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleFinalSubmit,
						className: `rounded-3xl border p-5 sm:p-8 shadow-xl space-y-6 transition-colors duration-300 ${isLight ? "bg-white border-slate-200/90 text-slate-900" : "bg-slate-900/90 border-white/10 text-white"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-4 pb-5 border-b border-blue-500/20",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between text-xs font-bold",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-blue-500 font-extrabold",
											children: isAr ? `الخطوة ${wizardStep} من 4: ${wizardStepsMeta[wizardStep - 1].titleAr}` : `Step ${wizardStep} of 4: ${wizardStepsMeta[wizardStep - 1].titleEn}`
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-mono text-emerald-500 font-bold",
											children: [
												wizardStep * 25,
												"% ",
												isAr ? "مكتمل" : "Complete"
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `w-full h-2.5 rounded-full overflow-hidden border ${isLight ? "bg-slate-100 border-slate-200" : "bg-slate-950 border-slate-800"}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
											className: "h-full bg-gradient-to-r from-blue-600 via-indigo-500 to-emerald-500 rounded-full",
											initial: { width: "25%" },
											animate: { width: `${wizardStep * 25}%` },
											transition: {
												duration: .35,
												ease: "easeOut"
											}
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1",
										children: wizardStepsMeta.map((s) => {
											const IconComponent = s.icon;
											const isCurrent = wizardStep === s.step;
											const isDone = wizardStep > s.step;
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => {
													soundManager.playTap();
													setWizardStep(s.step);
												},
												className: `p-2.5 rounded-2xl border text-start transition flex items-center gap-2.5 cursor-pointer ${isCurrent ? isLight ? "bg-blue-50 border-blue-400 text-blue-950 shadow-sm" : "bg-blue-600/20 border-blue-400 text-white shadow-sm" : isDone ? isLight ? "bg-emerald-50/70 border-emerald-200 text-emerald-900" : "bg-emerald-500/10 border-emerald-500/30 text-emerald-200" : isLight ? "bg-slate-50 border-slate-200 text-slate-500 hover:bg-slate-100" : "bg-slate-950/60 border-white/10 text-slate-400 hover:bg-white/5"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: `w-7 h-7 rounded-xl flex items-center justify-center shrink-0 text-xs font-bold ${isCurrent ? "bg-blue-600 text-white" : isDone ? "bg-emerald-500 text-white" : isLight ? "bg-slate-200 text-slate-700" : "bg-slate-800 text-slate-400"}`,
													children: isDone ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconComponent, { className: "w-3.5 h-3.5" })
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "min-w-0",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "text-xs font-extrabold truncate",
														children: isAr ? s.titleAr : s.titleEn
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: `text-[10px] truncate ${isLight ? "text-slate-500" : "text-slate-400"}`,
														children: isAr ? s.subAr : s.subEn
													})]
												})]
											}, s.step);
										})
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AnimatePresence, {
								mode: "wait",
								children: [
									wizardStep === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
										initial: {
											opacity: 0,
											x: isRTL ? 20 : -20
										},
										animate: {
											opacity: 1,
											x: 0
										},
										exit: {
											opacity: 0,
											x: isRTL ? -20 : 20
										},
										transition: { duration: .25 },
										className: "space-y-6",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-lg sm:text-xl font-black font-['Alexandria']",
												children: isAr ? "الخطوة الأولى: الأساسيات الديموغرافية المبسطة" : "Step 1: Simplified Demographic Fundamentals"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: `text-xs mt-1 ${isLight ? "text-slate-600" : "text-slate-400"}`,
												children: isAr ? "نكتفي بالاسم المستعار (اللقب) وسنة الميلاد فقط التزاماً بمبدأ الحد الأدنى من جمع البيانات (Data Minimization)." : "In adherence to Data Minimization principles, only an alias/nickname and birth year are requested."
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												htmlFor: "user-alias-input",
												className: "block text-xs sm:text-sm font-bold mb-1.5",
												children: isAr ? "الاسم المستعار أو اللقب (لتخصيص التقرير دون الحاجة للاسم الكامل):" : "Nickname or Alias (to personalize your report without full legal name):"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												id: "user-alias-input",
												type: "text",
												value: userName,
												onChange: (e) => setUserName(e.target.value),
												"aria-label": isAr ? "الاسم المستعار أو اللقب" : "Nickname or Alias",
												placeholder: isAr ? "مثال: أبو فيصل، سارة، طارق..." : "e.g., Alex, Sara, Tariq...",
												className: `w-full px-4 py-3 rounded-2xl border text-sm focus:outline-none focus:border-blue-500 ${isLight ? "bg-slate-50 border-slate-300 text-slate-900 placeholder-slate-400" : "bg-slate-950/80 border-white/15 text-white placeholder-slate-500"}`
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: `p-4 rounded-2xl border space-y-3 ${isLight ? "bg-slate-50 border-slate-200" : "bg-slate-950/60 border-white/10"}`,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
														className: "block text-xs sm:text-sm font-bold",
														children: [
															isAr ? "جنسك:" : "Your Gender:",
															" ",
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-rose-500",
																children: "*"
															})
														]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "grid grid-cols-2 gap-2.5",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
															type: "button",
															onClick: () => handleUserGenderSelect("male"),
															className: `p-3 rounded-xl border font-bold text-xs sm:text-sm flex flex-col items-center gap-1.5 transition cursor-pointer ${userGender === "male" ? "bg-blue-600 text-white border-blue-400 shadow-sm" : isLight ? "bg-white border-slate-200 text-slate-700 hover:bg-slate-100" : "bg-slate-900 border-slate-700 text-slate-300 hover:bg-slate-800"}`,
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-2xl",
																children: "👨"
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "ذكر" : "Male" })]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
															type: "button",
															onClick: () => handleUserGenderSelect("female"),
															className: `p-3 rounded-xl border font-bold text-xs sm:text-sm flex flex-col items-center gap-1.5 transition cursor-pointer ${userGender === "female" ? "bg-rose-600 text-white border-rose-400 shadow-sm" : isLight ? "bg-white border-slate-200 text-slate-700 hover:bg-slate-100" : "bg-slate-900 border-slate-700 text-slate-300 hover:bg-slate-800"}`,
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-2xl",
																children: "👩"
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "أنثى" : "Female" })]
														})]
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: `p-4 rounded-2xl border space-y-3 ${isLight ? "bg-slate-50 border-slate-200" : "bg-slate-950/60 border-white/10"}`,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
														className: "block text-xs sm:text-sm font-bold",
														children: [
															isAr ? "الشريك المطلوب دراسة التوافق معه:" : "Target Partner Gender:",
															" ",
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-rose-500",
																children: "*"
															})
														]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "grid grid-cols-2 gap-2.5",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
															type: "button",
															onClick: () => {
																soundManager.playTap();
																setPartnerGender("female");
															},
															className: `p-3 rounded-xl border font-bold text-xs sm:text-sm flex flex-col items-center gap-1.5 transition cursor-pointer ${partnerGender === "female" ? "bg-rose-600 text-white border-rose-400 shadow-sm" : isLight ? "bg-white border-slate-200 text-slate-700 hover:bg-slate-100" : "bg-slate-900 border-slate-700 text-slate-300 hover:bg-slate-800"}`,
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-2xl",
																children: "👰"
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "أنثى / شريكة" : "Female Partner" })]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
															type: "button",
															onClick: () => {
																soundManager.playTap();
																setPartnerGender("male");
															},
															className: `p-3 rounded-xl border font-bold text-xs sm:text-sm flex flex-col items-center gap-1.5 transition cursor-pointer ${partnerGender === "male" ? "bg-blue-600 text-white border-blue-400 shadow-sm" : isLight ? "bg-white border-slate-200 text-slate-700 hover:bg-slate-100" : "bg-slate-900 border-slate-700 text-slate-300 hover:bg-slate-800"}`,
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-2xl",
																children: "🤵"
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "ذكر / شريك" : "Male Partner" })]
														})]
													})]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: `p-4 rounded-2xl border space-y-2.5 ${isLight ? "bg-slate-50 border-slate-200" : "bg-slate-950/60 border-white/10"}`,
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex items-center justify-between",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
																htmlFor: "birth-year-select",
																className: "text-xs sm:text-sm font-bold flex items-center gap-1.5",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "w-4 h-4 text-emerald-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "سنة الميلاد (بدون يوم أو شهر):" : "Birth Year (Year Only):" })]
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "text-xs font-mono font-bold text-emerald-500",
																children: [
																	"~",
																	computedAge,
																	" ",
																	isAr ? "عاماً" : "yrs"
																]
															})]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "relative",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
																id: "birth-year-select",
																"aria-label": isAr ? "سنة الميلاد" : "Select Birth Year",
																title: isAr ? "سنة الميلاد" : "Select Birth Year",
																value: birthYear,
																onChange: (e) => {
																	soundManager.playTap();
																	setBirthYear(Number(e.target.value));
																},
																className: `w-full px-4 py-2.5 rounded-xl border text-sm font-mono font-bold appearance-none cursor-pointer ${isLight ? "bg-white border-slate-300 text-slate-900" : "bg-slate-900 border-white/15 text-white"}`,
																children: BIRTH_YEARS.map((yr) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
																	value: yr,
																	children: [
																		yr,
																		" (",
																		CURRENT_YEAR - yr,
																		" ",
																		isAr ? "سنة" : "yrs",
																		")"
																	]
																}, yr))
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400" })]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "text-[11px] text-emerald-500 font-semibold flex items-center justify-between pt-1",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
																isAr ? "الفئة الجيلية:" : "Generational Cohort:",
																" ",
																previewCohort.cohortName
															] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "font-mono",
																children: [
																	"(",
																	previewCohort.birthYearRange,
																	")"
																]
															})]
														})
													]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: `p-4 rounded-2xl border space-y-2.5 ${isLight ? "bg-slate-50 border-slate-200" : "bg-slate-950/60 border-white/10"}`,
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex items-center justify-between gap-2 flex-wrap",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
																htmlFor: "country-select",
																className: "block text-xs sm:text-sm font-bold",
																children: [
																	isAr ? "البلد والجنسية:" : "Country & Nationality:",
																	" ",
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																		className: "text-rose-500",
																		children: "*"
																	})
																]
															}), autoDetectedLocation && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-500 border border-emerald-500/30",
																children: isAr ? `✓ اكتشاف تلقائي (${autoDetectedLocation.nationalityAr})` : `✓ Auto-detected (${autoDetectedLocation.nationalityEn})`
															})]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "relative",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
																id: "country-select",
																"aria-label": isAr ? "البلد والجنسية" : "Select Country and Nationality",
																title: isAr ? "البلد والجنسية" : "Select Country and Nationality",
																value: country,
																onChange: (e) => handleCountryChange(e.target.value),
																className: `w-full px-4 py-2.5 rounded-xl border text-sm font-bold appearance-none cursor-pointer ${isLight ? "bg-white border-slate-300 text-slate-900" : "bg-slate-900 border-white/15 text-white"}`,
																children: COUNTRIES_LIST.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
																	value: c.name,
																	children: [
																		c.flag,
																		" ",
																		c.name
																	]
																}, c.code))
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400" })]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: `text-[11px] ${isLight ? "text-slate-500" : "text-slate-400"}`,
															children: isAr ? "يُكتشف موقعك وجنسيتك تلقائياً لتوجيه نموذج الذكاء الاصطناعي لتوليد صورة شريك حياة بملامح عرقية واقعية متناسبة مع جنسيتك." : "Automatically detected to guide the AI model to generate a life partner portrait with realistic ethnic features matching your nationality."
														})
													]
												})]
											})
										]
									}, "step1"),
									wizardStep === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
										initial: {
											opacity: 0,
											x: isRTL ? 20 : -20
										},
										animate: {
											opacity: 1,
											x: 0
										},
										exit: {
											opacity: 0,
											x: isRTL ? -20 : 20
										},
										transition: { duration: .25 },
										className: "space-y-6",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-lg sm:text-xl font-black font-['Alexandria']",
												children: isAr ? "الخطوة الثانية: التفضيلات الثقافية ونمط الحياة" : "Step 2: Cultural Preferences & Lifestyle Outlook"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: `text-xs mt-1 ${isLight ? "text-slate-600" : "text-slate-400"}`,
												children: isAr ? "يركز هذا القسم على المدرسة الثقافية والإقليمية العامة (خليجي، شامي، مصري، مغاربي، إلخ) والتطلعات التعليمية والاجتماعية بعيداً عن الأوصاف الجسدية السطحية." : "Focuses on general regional cultural heritage (Gulf, Levantine, Egyptian, Maghreb, etc.), education, and social lifestyle rather than physical traits."
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-2.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
													className: "block text-xs sm:text-sm font-bold",
													children: isAr ? "الخلفية الثقافية والإقليمية المفضلة للتوافق القيمي:" : "Preferred Cultural & Regional Background:"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "grid grid-cols-1 sm:grid-cols-2 gap-2.5",
													children: CULTURAL_REGIONAL_OPTIONS.map((item) => {
														const isSelected = ethnicity === item.tag || ethnicity.includes(item.tag);
														return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
															type: "button",
															onClick: () => {
																soundManager.playTap();
																setEthnicity(item.tag);
															},
															className: `p-3.5 rounded-2xl border text-start transition flex items-center justify-between gap-2 text-xs cursor-pointer ${isSelected ? isLight ? "bg-blue-50 border-blue-500 text-blue-950 font-bold shadow-sm" : "bg-blue-600/20 border-blue-400 text-white font-bold shadow-sm" : isLight ? "bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100" : "bg-slate-950/60 border-white/10 text-slate-300 hover:bg-white/5"}`,
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "leading-relaxed",
																children: isAr ? item.labelAr : item.labelEn
															}), isSelected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4 text-blue-500 shrink-0" })]
														}, item.id);
													})
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-2.5 pt-2 border-t border-white/10",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-2 text-xs sm:text-sm font-bold text-rose-500",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "المستوى التعليمي والفكري:" : "Educational & Intellectual Background:" })]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "grid grid-cols-1 sm:grid-cols-2 gap-2.5",
													children: BILINGUAL_EDUCATION_OPTIONS.map((ed) => {
														const isSelected = educationLevel === ed.value;
														return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
															type: "button",
															onClick: () => {
																soundManager.playTap();
																setEducationLevel(ed.value);
															},
															className: `p-3 rounded-2xl border text-start transition flex items-center justify-between gap-2 text-xs cursor-pointer ${isSelected ? isLight ? "bg-rose-50 border-rose-400 text-rose-950 font-bold shadow-sm" : "bg-rose-500/20 border-rose-400 text-white font-bold shadow-sm" : isLight ? "bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100" : "bg-slate-950/60 border-white/10 text-slate-300 hover:bg-white/5"}`,
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? ed.labelAr : ed.labelEn }), isSelected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4 text-rose-500 shrink-0" })]
														}, ed.value);
													})
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-2.5 pt-2 border-t border-white/10",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-2 text-xs sm:text-sm font-bold text-purple-500",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UsersRound, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "نمط الحياة والتطلعات الاجتماعية المفضلة:" : "Preferred Lifestyle & Social Outlook:" })]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "space-y-2",
													children: BILINGUAL_LIFESTYLE_OPTIONS.map((lf) => {
														const isSelected = lifestyleOutlook === lf.value;
														return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
															type: "button",
															onClick: () => {
																soundManager.playTap();
																setLifestyleOutlook(lf.value);
															},
															className: `w-full p-3 rounded-2xl border text-start transition flex items-center justify-between gap-2 text-xs cursor-pointer ${isSelected ? isLight ? "bg-purple-50 border-purple-400 text-purple-950 font-bold shadow-sm" : "bg-purple-500/20 border-purple-400 text-white font-bold shadow-sm" : isLight ? "bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100" : "bg-slate-950/60 border-white/10 text-slate-300 hover:bg-white/5"}`,
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? lf.labelAr : lf.labelEn }), isSelected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4 text-purple-500 shrink-0" })]
														}, lf.value);
													})
												})]
											})
										]
									}, "step2"),
									wizardStep === 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
										initial: {
											opacity: 0,
											x: isRTL ? 20 : -20
										},
										animate: {
											opacity: 1,
											x: 0
										},
										exit: {
											opacity: 0,
											x: isRTL ? -20 : 20
										},
										transition: { duration: .25 },
										className: "space-y-6",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-lg sm:text-xl font-black font-['Alexandria']",
												children: isAr ? "الخطوة الثالثة: القيم وأسلوب التواصل وحل الخلافات والرؤية المالية والأسرية" : "Step 3: Core Values, Conflict Resolution & Financial/Family Vision"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: `text-xs mt-1 ${isLight ? "text-slate-600" : "text-slate-400"}`,
												children: isAr ? "تُعد هذه الركائز الثلاث (توافق القيم، إدارة الخلاف، والشفافية المالية) المحددات العلمية الأهم لاستقرار العلاقات طويلة الأمد وفق أبحاث جون غوتمان." : "These three pillars (value congruence, conflict repair, and financial alignment) are the strongest predictors of long-term relational stability."
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-2.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
													className: "block text-xs sm:text-sm font-bold text-emerald-500",
													children: isAr ? "١. القيمة العليا التي تمنحها الأولوية القصوى في الشراكة:" : "1. Primary Core Value in a Life Partnership:"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "grid grid-cols-1 sm:grid-cols-2 gap-2.5",
													children: CORE_VALUES_OPTIONS.map((v) => {
														const isSelected = coreValuesPriority === v.labelAr;
														return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
															type: "button",
															onClick: () => {
																soundManager.playTap();
																setCoreValuesPriority(v.labelAr);
															},
															className: `p-3.5 rounded-2xl border text-start transition flex items-center justify-between gap-2 text-xs cursor-pointer ${isSelected ? isLight ? "bg-emerald-50 border-emerald-500 text-emerald-950 font-bold shadow-sm" : "bg-emerald-500/20 border-emerald-400 text-white font-bold shadow-sm" : isLight ? "bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100" : "bg-slate-950/60 border-white/10 text-slate-300 hover:bg-white/5"}`,
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "leading-relaxed",
																children: isAr ? v.labelAr : v.labelEn
															}), isSelected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4 text-emerald-500 shrink-0" })]
														}, v.id);
													})
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-2.5 pt-2 border-t border-white/10",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
													className: "block text-xs sm:text-sm font-bold text-blue-500",
													children: isAr ? "٢. أسلوب التواصل المفضل وإدارة الخلافات الزوجية:" : "2. Preferred Communication & Conflict Resolution Style:"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "space-y-2",
													children: COMMUNICATION_CONFLICT_OPTIONS.map((c) => {
														const isSelected = communicationAndConflictStyle === c.labelAr;
														return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
															type: "button",
															onClick: () => {
																soundManager.playTap();
																setCommunicationAndConflictStyle(c.labelAr);
															},
															className: `w-full p-3.5 rounded-2xl border text-start transition flex items-center justify-between gap-2 text-xs cursor-pointer ${isSelected ? isLight ? "bg-blue-50 border-blue-500 text-blue-950 font-bold shadow-sm" : "bg-blue-500/20 border-blue-400 text-white font-bold shadow-sm" : isLight ? "bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100" : "bg-slate-950/60 border-white/10 text-slate-300 hover:bg-white/5"}`,
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "leading-relaxed",
																children: isAr ? c.labelAr : c.labelEn
															}), isSelected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4 text-blue-500 shrink-0" })]
														}, c.id);
													})
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-2.5 pt-2 border-t border-white/10",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
													className: "block text-xs sm:text-sm font-bold text-amber-500 flex items-center gap-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "٣. الرؤية المالية والأسرية المستقبلية:" : "3. Future Financial & Family Governance Vision:" })]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "space-y-2",
													children: FINANCIAL_FAMILY_VISION_OPTIONS.map((f) => {
														const isSelected = financialAndFamilyVision === f.labelAr;
														return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
															type: "button",
															onClick: () => {
																soundManager.playTap();
																setFinancialAndFamilyVision(f.labelAr);
															},
															className: `w-full p-3.5 rounded-2xl border text-start transition flex items-center justify-between gap-2 text-xs cursor-pointer ${isSelected ? isLight ? "bg-amber-50 border-amber-500 text-amber-950 font-bold shadow-sm" : "bg-amber-500/20 border-amber-400 text-white font-bold shadow-sm" : isLight ? "bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100" : "bg-slate-950/60 border-white/10 text-slate-300 hover:bg-white/5"}`,
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "leading-relaxed",
																children: isAr ? f.labelAr : f.labelEn
															}), isSelected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4 text-amber-500 shrink-0" })]
														}, f.id);
													})
												})]
											})
										]
									}, "step3"),
									wizardStep === 4 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
										initial: {
											opacity: 0,
											x: isRTL ? 20 : -20
										},
										animate: {
											opacity: 1,
											x: 0
										},
										exit: {
											opacity: 0,
											x: isRTL ? -20 : 20
										},
										transition: { duration: .25 },
										className: "space-y-6",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-lg sm:text-xl font-black font-['Alexandria']",
												children: isAr ? "الخطوة الرابعة: المراجعة النهائية وملخص البيانات والموافقة" : "Step 4: Final Data Review, Summary & Mandatory Consent"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: `text-xs mt-1 ${isLight ? "text-slate-600" : "text-slate-400"}`,
												children: isAr ? "راجع ملخص اختياراتك في الخطوات الثلاث السابقة، ثم اقبل مربع الموافقة الإلزامي لبدء حساب التوافق السيكومتري." : "Review your selections across the previous three steps and check the mandatory privacy consent box to begin."
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-3",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: `p-4 rounded-2xl border space-y-2 ${isLight ? "bg-slate-50 border-slate-200" : "bg-slate-950/70 border-white/10"}`,
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex items-center justify-between",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-xs font-extrabold text-blue-500",
																children: isAr ? "١. الأساسيات الديموغرافية" : "1. Fundamentals"
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
																type: "button",
																onClick: () => setWizardStep(1),
																className: "text-[11px] font-bold text-blue-500 hover:underline flex items-center gap-1 cursor-pointer",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "w-3 h-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "تعديل" : "Edit" })]
															})]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "text-slate-400 block text-[10px]",
																	children: isAr ? "اللقب / الاسم المستعار:" : "Nickname:"
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "font-bold",
																	children: userName.trim() || (isAr ? "زائر كريم" : "Guest")
																})] }),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "text-slate-400 block text-[10px]",
																	children: isAr ? "الجنس / الشريك:" : "Gender / Partner:"
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "font-bold",
																	children: userGender === "male" ? isAr ? "ذكر ← أنثى" : "Male → Female" : isAr ? "أنثى ← ذكر" : "Female → Male"
																})] }),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "text-slate-400 block text-[10px]",
																	children: isAr ? "سنة الميلاد والجيل:" : "Birth Year & Cohort:"
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																	className: "font-bold font-mono",
																	children: [
																		birthYear,
																		" (~",
																		computedAge,
																		" ",
																		isAr ? "سنة" : "y",
																		")"
																	]
																})] }),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "text-slate-400 block text-[10px]",
																	children: isAr ? "البلد:" : "Country:"
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "font-bold",
																	children: country
																})] })
															]
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: `p-4 rounded-2xl border space-y-2 ${isLight ? "bg-slate-50 border-slate-200" : "bg-slate-950/70 border-white/10"}`,
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex items-center justify-between",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-xs font-extrabold text-purple-500",
																children: isAr ? "٢. التفضيلات الثقافية ونمط الحياة" : "2. Cultural Preferences & Lifestyle"
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
																type: "button",
																onClick: () => setWizardStep(2),
																className: "text-[11px] font-bold text-purple-500 hover:underline flex items-center gap-1 cursor-pointer",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "w-3 h-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "تعديل" : "Edit" })]
															})]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "space-y-1 text-xs",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "text-slate-400",
																	children: isAr ? "الخلفية الثقافية الإقليمية: " : "Regional Culture: "
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "font-bold",
																	children: isAr ? selectedCultureObj.labelAr : selectedCultureObj.labelEn
																})] }),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "text-slate-400",
																	children: isAr ? "المستوى التعليمي: " : "Education: "
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "font-bold",
																	children: educationLevel
																})] }),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "text-slate-400",
																	children: isAr ? "نمط الحياة: " : "Lifestyle: "
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "font-bold",
																	children: lifestyleOutlook
																})] })
															]
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: `p-4 rounded-2xl border space-y-2 ${isLight ? "bg-slate-50 border-slate-200" : "bg-slate-950/70 border-white/10"}`,
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex items-center justify-between",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-xs font-extrabold text-emerald-500",
																children: isAr ? "٣. القيم وأسلوب التواصل والرؤية المالية" : "3. Values, Communication & Financial Vision"
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
																type: "button",
																onClick: () => setWizardStep(3),
																className: "text-[11px] font-bold text-emerald-500 hover:underline flex items-center gap-1 cursor-pointer",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "w-3 h-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "تعديل" : "Edit" })]
															})]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "space-y-1 text-xs",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "text-slate-400",
																	children: isAr ? "الأولوية القيمية: " : "Core Value: "
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "font-bold",
																	children: coreValuesPriority
																})] }),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "text-slate-400",
																	children: isAr ? "إدارة الخلاف: " : "Conflict Style: "
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "font-bold",
																	children: communicationAndConflictStyle
																})] }),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "text-slate-400",
																	children: isAr ? "الرؤية المالية والأسرية: " : "Financial Vision: "
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "font-bold",
																	children: financialAndFamilyVision
																})] })
															]
														})]
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: `p-4 sm:p-5 rounded-2xl border transition ${privacyConsentAccepted ? isLight ? "bg-emerald-50 border-emerald-400 text-emerald-950" : "bg-emerald-950/35 border-emerald-500/50 text-emerald-100" : consentError ? isLight ? "bg-rose-50 border-rose-500 text-rose-950" : "bg-rose-950/40 border-rose-500 text-rose-100" : isLight ? "bg-amber-50/70 border-amber-300 text-slate-800" : "bg-slate-950/80 border-amber-500/40 text-slate-200"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
													className: "flex items-start gap-3 cursor-pointer select-none",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
														type: "checkbox",
														checked: privacyConsentAccepted,
														onChange: (e) => {
															soundManager.playTap();
															setPrivacyConsentAccepted(e.target.checked);
															if (e.target.checked) setConsentError(false);
														},
														className: "mt-1 w-5 h-5 rounded accent-emerald-600 cursor-pointer shrink-0"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "space-y-1 text-xs sm:text-sm leading-relaxed",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "font-extrabold block",
															children: isAr ? "مربع الموافقة الإلزامي على سياسة الخصوصية وحماية البيانات (مطلوب): *" : "Mandatory Privacy Policy & Data Protection Consent (Required): *"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "text-xs opacity-90",
															children: isAr ? "أقرُّ بموافقتي الصريحة على سياسة الخصوصية وشروط الاستخدام ومبدأ الحد الأدنى من جمع البيانات (Data Minimization) التابع لمنصة «مرآة القلوب»، وأتفهم أن نتائج حاسبة التوافق تُعالَج لأغراض الاستبصار المعرفي والتربوي ولا تُعد تشخيصاً طبياً أو إكلينيكياً، مع احتفاظي بحق حذف بياناتي نهائياً في أي وقت من قائمة «ملفي»." : "I explicitly agree to the Privacy Policy, Terms of Service, and Data Minimization standards of Mirror of Hearts. I understand that this compatibility calculation is strictly for educational self-discovery rather than clinical diagnosis, and that I can permanently delete my data at any time via the \"My Profile\" menu."
														})]
													})]
												}), consentError && !privacyConsentAccepted && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "mt-3 pt-2 border-t border-rose-500/30 flex items-center gap-2 text-xs font-bold text-rose-500",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "w-4 h-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "يُرجى تحديد مربع الموافقة الإلزامي على سياسة الخصوصية وحماية البيانات للمتابعة." : "Please check the mandatory Privacy Policy & Data Protection consent box to proceed." })]
												})]
											})
										]
									}, "step4")
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `pt-4 border-t flex items-center justify-between gap-3 ${isLight ? "border-slate-200" : "border-white/10"}`,
								children: [wizardStep > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: goToPrevStep,
									className: `px-4 py-2.5 rounded-xl border text-xs sm:text-sm font-bold transition flex items-center gap-1.5 cursor-pointer ${isLight ? "bg-slate-100 hover:bg-slate-200 border-slate-300 text-slate-800" : "bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-200"}`,
									children: [isRTL ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "w-4 h-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "الخطوة السابقة" : "Previous Step" })]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {}), wizardStep < 4 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: goToNextStep,
									className: "px-6 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs sm:text-sm font-extrabold transition shadow-md flex items-center gap-2 cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? `متابعة إلى الخطوة ${wizardStep + 1}` : `Continue to Step ${wizardStep + 1}` }), isRTL ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "w-4 h-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "w-4 h-4" })]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "submit",
									className: `px-6 py-3.5 rounded-2xl font-extrabold text-sm sm:text-base flex items-center justify-center gap-2.5 transition shadow-lg cursor-pointer ${privacyConsentAccepted ? "bg-gradient-to-r from-emerald-600 via-teal-600 to-blue-600 hover:opacity-95 text-white shadow-emerald-900/30" : isLight ? "bg-slate-200 text-slate-500 border border-slate-300" : "bg-slate-800 text-slate-400 border border-slate-700"}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-5 h-5 text-amber-300" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "بدء حساب التوافق واستكشاف الشريك" : "Start Compatibility Calculation" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "w-4 h-4 fill-current" })
									]
								})]
							})
						]
					})
				]
			})
		]
	});
};
//#endregion
export { ProfileStep };
