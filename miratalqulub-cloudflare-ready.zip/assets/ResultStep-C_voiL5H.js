const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/pdfReportGenerator-BNu3pVmt.js","assets/index-C5uCeetQ.js","assets/rolldown-runtime-Bk_YeHJf.js","assets/vendor-react-Bm_EF59R.js","assets/vendor-icons-WoMClU7U.js","assets/sound-C_zXqyNA.js","assets/index.es-C20Q95Ms.js","assets/firebase-Cu7XUsbK.js","assets/firebaseAuth-D6LKvzXg.js","assets/index-DMmCvB5f.css"])))=>i.map(i=>d[i]);
import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { n as __vitePreload, o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { $ as Printer, An as BookOpen, At as KeyRound, B as Send, Bt as Gauge, Cn as Calculator, D as Sparkles, En as Brain, Et as Layers, Ft as HeartHandshake, G as RotateCw, Gt as FileDown, Ht as Flame, I as Share2, J as RefreshCw, Jt as Eye, Kt as FileCheck2, Mn as Award, Mt as House, Nt as History, On as Bookmark, P as ShieldCheck, Pn as ArrowLeft, Pt as Heart, Qt as Download, Rt as GraduationCap, S as Sun, Sn as Calendar, U as Scale, Wt as FileText, X as Radar, Yt as EyeOff, Z as Quote, an as Compass, bn as Check, bt as Lock, cn as Clock, f as Twitter, ft as MessageCircle, g as Timer, gn as ChevronUp, hn as CircleAlert, jt as Info, kn as BookmarkCheck, mn as CircleCheck, n as Zap, r as X, rn as Copy, s as Users, st as Moon, t as ZoomIn, ut as MessageSquare, wt as Lightbulb, xn as ChartColumn, xt as LockOpen, yn as ChevronDown } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import { d as useAppTheme, i as setPinLock, l as useLanguage, n as isPinLockEnabled, t as disablePinLock, u as useAuth } from "./index-C5uCeetQ.js";
import { n as AnimatePresence, t as motion } from "./vendor-motion-BS7ODJw7.js";
import { a as confetti_module_default, i as saveChatCadenceExchanges, n as generateDeterministicCadenceAnalysis, r as loadSavedChatCadenceExchanges, t as calculateCadenceMetrics } from "./chatCadenceTracker-DzV50N4M.js";
import { calculateRealCompatibility } from "./realScoringEngine-B-6Eyb1e.js";
import { l as saveTestResultToHistory } from "./userHistoryService-6N9Zh8ed.js";
import { t as calculateSocioculturalScience } from "./socioculturalScience-BtpE3Kxg.js";
import { _ as Tooltip, a as ZAxis, c as Scatter, f as Radar$1, h as PolarGrid, l as Bar, m as PolarRadiusAxis, n as RadarChart, o as YAxis, p as PolarAngleAxis, r as BarChart, s as XAxis, t as ScatterChart, v as Legend, y as ResponsiveContainer } from "./vendor-charts-Z9-zx-pq.js";
//#region src/utils/shareCard.ts
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
async function generateShareCardCanvas(result, profile, imageUrl) {
	const canvas = document.createElement("canvas");
	const width = 1080;
	const height = 1520;
	canvas.width = width;
	canvas.height = height;
	const ctx = canvas.getContext("2d");
	if (!ctx) return imageUrl;
	const bgGrad = ctx.createLinearGradient(0, 0, width, height);
	bgGrad.addColorStop(0, "#150c26");
	bgGrad.addColorStop(.35, "#0b0817");
	bgGrad.addColorStop(1, "#24081c");
	ctx.fillStyle = bgGrad;
	ctx.fillRect(0, 0, width, height);
	ctx.strokeStyle = "rgba(244, 63, 94, 0.45)";
	ctx.lineWidth = 6;
	roundRect(ctx, 30, 30, 1020, 1460, 44);
	ctx.stroke();
	ctx.strokeStyle = "rgba(251, 191, 36, 0.35)";
	ctx.lineWidth = 2;
	roundRect(ctx, 42, 42, 996, 1436, 36);
	ctx.stroke();
	ctx.textAlign = "center";
	ctx.font = "bold 36px Tajawal, sans-serif";
	ctx.fillStyle = "#fb7185";
	ctx.fillText("✨ مِـرآة الـقـلـوب ✨", width / 2, 95);
	ctx.font = "22px Tajawal, sans-serif";
	ctx.fillStyle = "#94a3b8";
	ctx.fillText("دراسة التوافق الفكري والمجتمعي والنفسي المعتمدة", width / 2, 130);
	try {
		const img = await loadImage(imageUrl);
		const imgW = 600;
		const imgH = 600;
		const imgX = 240;
		const imgY = 165;
		const imgRadius = 36;
		ctx.save();
		ctx.shadowColor = "rgba(244, 63, 94, 0.65)";
		ctx.shadowBlur = 45;
		ctx.fillStyle = "#ffffff";
		roundRect(ctx, imgX, imgY, imgW, imgH, imgRadius);
		ctx.fill();
		ctx.restore();
		ctx.save();
		roundRect(ctx, imgX, imgY, imgW, imgH, imgRadius);
		ctx.clip();
		ctx.drawImage(img, imgX, imgY, imgW, imgH);
		ctx.restore();
		ctx.save();
		ctx.strokeStyle = "rgba(255, 255, 255, 0.35)";
		ctx.lineWidth = 4;
		roundRect(ctx, imgX, imgY, imgW, imgH, imgRadius);
		ctx.stroke();
		ctx.restore();
	} catch (e) {
		console.error("Failed to draw portrait image on canvas:", e);
	}
	ctx.save();
	ctx.fillStyle = "rgba(244, 63, 94, 0.95)";
	roundRect(ctx, width / 2 - 240, 780, 480, 80, 40);
	ctx.fill();
	ctx.strokeStyle = "#fde047";
	ctx.lineWidth = 3;
	roundRect(ctx, width / 2 - 240, 780, 480, 80, 40);
	ctx.stroke();
	ctx.font = "bold 42px Alexandria, Tajawal, sans-serif";
	ctx.fillStyle = "#ffffff";
	ctx.fillText(`شريك الحياة: ${result.proposedPartnerName}`, width / 2, 834);
	ctx.restore();
	ctx.font = "bold 30px Tajawal, sans-serif";
	ctx.fillStyle = "#fde047";
	ctx.fillText(`نسبة التوافق الكلي: ${result.compatibilityScore}% ❤️`, width / 2, 905);
	ctx.font = "bold 36px Tajawal, sans-serif";
	ctx.fillStyle = "#ffffff";
	ctx.fillText(result.partnerArchetype, width / 2, 955);
	ctx.font = "24px Tajawal, sans-serif";
	ctx.fillStyle = "#cbd5e1";
	ctx.fillText(`الأصل والمجتمع: ${profile.country} (${profile.ethnicity})`, width / 2, 995);
	const metricsBoxY = 1040;
	ctx.save();
	ctx.fillStyle = "rgba(255, 255, 255, 0.06)";
	roundRect(ctx, 80, metricsBoxY, 920, 160, 24);
	ctx.fill();
	ctx.strokeStyle = "rgba(255, 255, 255, 0.12)";
	ctx.lineWidth = 2;
	roundRect(ctx, 80, metricsBoxY, 920, 160, 24);
	ctx.stroke();
	const colW = 920 / 3;
	[
		{
			title: "التوافق الفكري",
			score: result.intellectualScore || 96,
			color: "#38bdf8"
		},
		{
			title: "التوافق المجتمعي",
			score: result.sociologicalScore || 95,
			color: "#c084fc"
		},
		{
			title: "الذكاء العاطفي",
			score: result.emotionalScore || 98,
			color: "#fb7185"
		}
	].forEach((m, idx) => {
		const cx = 80 + idx * colW + colW / 2;
		ctx.font = "bold 22px Tajawal, sans-serif";
		ctx.fillStyle = "#94a3b8";
		ctx.fillText(m.title, cx, 1090);
		ctx.font = "bold 44px Alexandria, Tajawal, sans-serif";
		ctx.fillStyle = m.color;
		ctx.fillText(`${m.score}%`, cx, 1150);
	});
	ctx.restore();
	ctx.font = "italic 22px Tajawal, sans-serif";
	ctx.fillStyle = "#fef08a";
	ctx.fillText(`دلالة الاسم: «${result.nameMeaning}»`, width / 2, 1260);
	ctx.font = "italic 24px Tajawal, sans-serif";
	ctx.fillStyle = "#e2e8f0";
	ctx.fillText(`${result.partnerVibeQuote}`, width / 2, 1330);
	ctx.font = "bold 22px Tajawal, sans-serif";
	ctx.fillStyle = "#f43f5e";
	ctx.fillText(`لغة الحب: ${result.loveLanguage} • ${result.attachmentStyle || "ارتباط آمن"}`, width / 2, 1380);
	ctx.font = "bold 22px Tajawal, sans-serif";
	ctx.fillStyle = "#94a3b8";
	ctx.fillText("منصة مِـرآة القـلوب • دراسة التوافق الإنساني • الأردن - عمّان", width / 2, 1460);
	return canvas.toDataURL("image/png");
}
function roundRect(ctx, x, y, w, h, r) {
	ctx.beginPath();
	ctx.moveTo(x + r, y);
	ctx.lineTo(x + w - r, y);
	ctx.quadraticCurveTo(x + w, y, x + w, y + r);
	ctx.lineTo(x + w, y + h - r);
	ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
	ctx.lineTo(x + r, y + h);
	ctx.quadraticCurveTo(x, y + h, x, y + h - r);
	ctx.lineTo(x, y + r);
	ctx.quadraticCurveTo(x, y, x + r, y);
	ctx.closePath();
}
function loadImage(src) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		img.crossOrigin = "anonymous";
		img.onload = () => resolve(img);
		img.onerror = () => reject(/* @__PURE__ */ new Error("Image load failed"));
		img.src = src;
	});
}
//#endregion
//#region src/components/ImageViewerModal.tsx
var import_jsx_runtime = require_jsx_runtime();
var ImageViewerModal = ({ imageUrl, title, subtitle, isOpen, onClose, onDownload, onShare }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: isOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		initial: { opacity: 0 },
		animate: { opacity: 1 },
		exit: { opacity: 0 },
		transition: { duration: .25 },
		className: "fixed inset-0 z-50 flex flex-col items-center justify-between p-4 bg-black/95 backdrop-blur-xl",
		dir: "rtl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					y: -20
				},
				animate: {
					opacity: 1,
					y: 0
				},
				exit: {
					opacity: 0,
					y: -20
				},
				transition: { duration: .3 },
				className: "w-full max-w-2xl flex items-center justify-between py-2 text-white",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
					className: "font-bold text-base",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-gray-300",
					children: subtitle
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
					whileHover: { scale: 1.1 },
					whileTap: { scale: .9 },
					onClick: onClose,
					className: "p-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition cursor-pointer",
					"aria-label": "إغلاق",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-5 h-5" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative flex-1 w-full max-w-lg flex items-center justify-center p-2 my-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
					initial: {
						opacity: 0,
						scale: .88
					},
					animate: {
						opacity: 1,
						scale: 1
					},
					exit: {
						opacity: 0,
						scale: .88
					},
					transition: {
						type: "spring",
						damping: 25,
						stiffness: 300
					},
					className: "relative rounded-3xl overflow-hidden border-2 border-rose-500/30 shadow-2xl shadow-rose-500/30 max-h-[70vh]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: imageUrl,
						alt: title,
						className: "w-full h-full object-cover max-h-[70vh] rounded-3xl"
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					y: 20
				},
				animate: {
					opacity: 1,
					y: 0
				},
				exit: {
					opacity: 0,
					y: 20
				},
				transition: { duration: .3 },
				className: "w-full max-w-md flex items-center gap-3 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
					whileHover: { scale: 1.02 },
					whileTap: { scale: .98 },
					onClick: onDownload,
					className: "flex-1 py-3 px-4 rounded-2xl bg-gradient-to-r from-rose-500 to-violet-600 text-white font-bold text-sm flex items-center justify-center gap-2 hover:opacity-95 transition shadow-lg shadow-rose-500/25 cursor-pointer",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تحميل الصورة بدقة عالية" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
					whileHover: { scale: 1.05 },
					whileTap: { scale: .95 },
					onClick: onShare,
					className: "py-3 px-4 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-semibold text-sm flex items-center justify-center gap-2 transition cursor-pointer",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "مشاركة" })]
				})]
			})
		]
	}) });
};
//#endregion
//#region src/components/CompatibilityCharts.tsx
var CompatibilityCharts = ({ result, profile, partnerName: explicitPartnerName }) => {
	const [chartType, setChartType] = (0, import_react.useState)("radar");
	const [showUserSeries, setShowUserSeries] = (0, import_react.useState)(true);
	const [showPartnerSeries, setShowPartnerSeries] = (0, import_react.useState)(true);
	const [selectedDimension, setSelectedDimension] = (0, import_react.useState)(null);
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const [theme] = useAppTheme();
	(0, import_react.useEffect)(() => {
		setMounted(true);
	}, []);
	const userName = profile?.userName || "أنت";
	const partnerName = explicitPartnerName || result.proposedPartnerName || (profile?.partnerGender === "female" ? "نـورة" : "فيـصل");
	const intellectual = result.intellectualScore || 96;
	const sociological = result.sociologicalScore || 95;
	const emotional = result.emotionalScore || 98;
	const lifestyle = result.lifestyleScore || 94;
	const overall = result.compatibilityScore || 97;
	const communication = Math.round((intellectual + emotional) / 2);
	const financial = Math.round((lifestyle + sociological) / 2);
	const userIntellect = Math.max(78, Math.min(96, intellectual - 2));
	const partnerIntellect = Math.max(80, Math.min(98, intellectual + 1));
	const userSociology = Math.max(76, Math.min(95, sociological - 1));
	const partnerSociology = Math.max(78, Math.min(97, sociological + 2));
	const userEmotional = Math.max(82, Math.min(98, emotional - 1));
	const partnerEmotional = Math.max(84, Math.min(99, emotional + 2));
	const userLifestyle = Math.max(75, Math.min(94, lifestyle - 2));
	const partnerLifestyle = Math.max(77, Math.min(96, lifestyle + 1));
	const userCommunication = Math.max(78, Math.min(96, communication - 1));
	const partnerCommunication = Math.max(80, Math.min(97, communication + 2));
	const userFinancial = Math.max(75, Math.min(94, financial - 1));
	const partnerFinancial = Math.max(77, Math.min(95, financial + 1));
	const radarData = [
		{
			dimensionKey: "intellectual",
			subject: "المجال الفكري",
			userScore: userIntellect,
			partnerScore: partnerIntellect,
			compatibility: intellectual,
			fullMark: 100,
			category: "intellectual",
			userDescription: "تفكير عقلاني، حب الاستطلاع، والبحث عن المعنى والوضوح.",
			partnerDescription: "هدوء تحليلي، إصغاء فعال، ونضج في صياغة الرؤى المستقبلية.",
			scientificNote: "تقارب المتجهات المعرفية يعزز تبادل الآراء دون صدام أو استقطاب فكري.",
			color: "#38bdf8",
			iconName: "GraduationCap"
		},
		{
			dimensionKey: "sociological",
			subject: "المجال الاجتماعي",
			userScore: userSociology,
			partnerScore: partnerSociology,
			compatibility: sociological,
			fullMark: 100,
			category: "sociological",
			userDescription: "تقدير صلة الرحم، الارتباط الأسري، والوفاء بالواجبات الاجتماعية.",
			partnerDescription: "أصالة اجتماعية، مراعاة الأعراف العائلية، وحماية استقلال البيت.",
			scientificNote: "التوافق في الهوية الثقافية في المجتمعات العربية يشكل 22% من استقرار العش الزوجي.",
			color: "#a78bfa",
			iconName: "Users"
		},
		{
			dimensionKey: "emotional",
			subject: "المجال العاطفي",
			userScore: userEmotional,
			partnerScore: partnerEmotional,
			compatibility: emotional,
			fullMark: 100,
			category: "emotional",
			userDescription: "تعبير وجداني صادق، بحث عن الأمان النفسي، وتجنب الخصام.",
			partnerDescription: "احتواء حكيم، مساندة دافئة في الأزمات، وارتباط آمن وتشاركي.",
			scientificNote: "الذكاء العاطفي المتبادل ومعدل الإيجابية 5:1 هما أقوى مؤشرات الزواج المستدام (Gottman).",
			color: "#f43f5e",
			iconName: "Heart"
		},
		{
			dimensionKey: "lifestyle",
			subject: "نمط الحياة واليوميات",
			userScore: userLifestyle,
			partnerScore: partnerLifestyle,
			compatibility: lifestyle,
			fullMark: 100,
			category: "practical",
			userDescription: "تنظيم أوقات الراحة والعمل، وحب الاستقرار والتجديد المتزن.",
			partnerDescription: "مرونة في التعامل مع الروتين اليومي، وتقدير المساحة الشخصية.",
			scientificNote: "تطابق الإيقاع البيولوجي واليومي يقلل التوترات الاحتكاكية الصامتة بنسبة 35%.",
			color: "#fbbf24",
			iconName: "Flame"
		},
		{
			dimensionKey: "communication",
			subject: "عمق التواصل والصراحة",
			userScore: userCommunication,
			partnerScore: partnerCommunication,
			compatibility: communication,
			fullMark: 100,
			category: "intellectual",
			userDescription: "تفضيل الحوار الهادئ المباشر، ورفض التلميحات المربكة.",
			partnerDescription: "إنصات عميق، قدرة على التهدئة، وشفافية في مشاركة المشاعر.",
			scientificNote: "التواصل الواعي يحول الخلافات إلى فرص استكشاف متبادل بدلاً من جولات انتصار.",
			color: "#34d399",
			iconName: "MessageCircle"
		},
		{
			dimensionKey: "financial",
			subject: "التخطيط المالي والمستقبلي",
			userScore: userFinancial,
			partnerScore: partnerFinancial,
			compatibility: financial,
			fullMark: 100,
			category: "practical",
			userDescription: "توازن بين التوفير والتمتع بالحياة، ووضوح في أولويات الإنفاق.",
			partnerDescription: "حرص استثماري مسؤول، ومشاركة شفافة في التخطيط للمستقبل.",
			scientificNote: "الشفافية المالية المبكرة تحمي العلاقة من أحد أكبر مسببات الخلافات الزوجية الحديثة.",
			color: "#ec4899",
			iconName: "Compass"
		}
	];
	const barComparisonData = radarData.map((d) => ({
		name: d.subject,
		user: d.userScore,
		partner: d.partnerScore,
		compatibility: d.compatibility,
		color: d.color,
		scientificNote: d.scientificNote
	}));
	const handleToggleChart = (type) => {
		soundManager.playTab();
		setChartType(type);
	};
	const CustomTooltip = ({ active, payload, label }) => {
		if (active && payload && payload.length) {
			const dataItem = radarData.find((item) => item.subject === label || item.subject === payload[0]?.payload?.name || item.subject === payload[0]?.payload?.subject) || payload[0]?.payload;
			const userVal = payload.find((p) => p.dataKey === "userScore" || p.dataKey === "user")?.value;
			const partnerVal = payload.find((p) => p.dataKey === "partnerScore" || p.dataKey === "partner")?.value;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `p-3.5 rounded-2xl shadow-2xl backdrop-blur-xl border text-right text-xs z-50 pointer-events-none max-w-xs ${theme === "light" ? "bg-white/95 border-gray-200 text-gray-800 shadow-purple-500/10" : "bg-[#120d24]/95 border-white/20 text-white shadow-black/60"}`,
				dir: "rtl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between pb-2 mb-2 border-b border-white/10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-extrabold text-sm text-white",
							children: label || dataItem?.subject || "المجال المقاس"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 font-bold text-[11px]",
							children: [
								"التوافق: ",
								dataItem?.compatibility || 95,
								"%"
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5 mb-2 font-mono",
						children: [userVal !== void 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3 text-sky-400",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5 font-sans",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-2.5 h-2.5 rounded-full bg-sky-400 shadow-sm shadow-sky-400/50" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [userName, ":"] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-bold text-sm",
								children: [userVal, "/100"]
							})]
						}), partnerVal !== void 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3 text-rose-400",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5 font-sans",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-2.5 h-2.5 rounded-full bg-rose-500 shadow-sm shadow-rose-500/50" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [partnerName, ":"] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-bold text-sm",
								children: [partnerVal, "/100"]
							})]
						})]
					}),
					dataItem?.scientificNote && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[10.5px] leading-relaxed text-gray-300 font-sans pt-1 border-t border-white/10",
						children: ["💡 ", dataItem.scientificNote]
					})
				]
			});
		}
		return null;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "glass-panel rounded-3xl p-4 sm:p-6 border border-white/10 mb-6 relative overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-0 right-1/4 w-56 h-56 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute bottom-0 left-1/4 w-56 h-56 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col lg:flex-row lg:items-center justify-between gap-3 mb-5 relative z-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 text-rose-400 font-extrabold text-sm sm:text-base",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radar, { className: "w-4 h-4 text-rose-400 animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "رادار مقارنة السمات السيكولوجية والتوافق العلمي:" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-gray-300 mt-0.5",
					children: [
						"مقارنة بصرية متعددة الأبعاد بواسطة Recharts بين سماتك وسمات (",
						partnerName,
						") في المجالات الفكرية، الاجتماعية، والعاطفية"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 self-start lg:self-auto flex-wrap",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1.5 bg-black/40 border border-white/10 p-1 rounded-xl text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundManager.playTap();
								setShowUserSeries(!showUserSeries);
							},
							className: `flex items-center gap-1 px-2 py-1 rounded-lg transition cursor-pointer font-bold ${showUserSeries ? "bg-sky-500/25 text-sky-300 border border-sky-500/40" : "text-gray-500 hover:text-gray-300"}`,
							title: "إظهار/إخفاء سمات المستخدم",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `w-2 h-2 rounded-full ${showUserSeries ? "bg-sky-400" : "bg-gray-600"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: userName })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundManager.playTap();
								setShowPartnerSeries(!showPartnerSeries);
							},
							className: `flex items-center gap-1 px-2 py-1 rounded-lg transition cursor-pointer font-bold ${showPartnerSeries ? "bg-rose-500/25 text-rose-300 border border-rose-500/40" : "text-gray-500 hover:text-gray-300"}`,
							title: "إظهار/إخفاء سمات الشريك",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `w-2 h-2 rounded-full ${showPartnerSeries ? "bg-rose-500" : "bg-gray-600"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: partnerName })]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1 p-1 rounded-xl bg-black/40 border border-white/10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
							whileHover: { scale: 1.04 },
							whileTap: { scale: .96 },
							onClick: () => handleToggleChart("radar"),
							className: `flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold transition cursor-pointer ${chartType === "radar" ? "bg-gradient-to-r from-rose-500 to-purple-600 text-white shadow-md" : "text-gray-400 hover:text-white"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radar, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "مخطط الرادار" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
							whileHover: { scale: 1.04 },
							whileTap: { scale: .96 },
							onClick: () => handleToggleChart("bar"),
							className: `flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold transition cursor-pointer ${chartType === "bar" ? "bg-gradient-to-r from-rose-500 to-purple-600 text-white shadow-md" : "text-gray-400 hover:text-white"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartColumn, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "أعمدة المقارنة" })]
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "w-full h-80 sm:h-96 flex items-center justify-center relative z-10 py-1 ltr-preserve",
				dir: "ltr",
				"data-keep-dir": "true",
				children: mounted && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: "100%",
					children: chartType === "radar" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(RadarChart, {
						data: radarData,
						outerRadius: "75%",
						margin: {
							top: 15,
							right: 30,
							bottom: 15,
							left: 30
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("defs", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("radialGradient", {
								id: "userRadarGrad",
								cx: "50%",
								cy: "50%",
								r: "50%",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
										offset: "0%",
										stopColor: "#38bdf8",
										stopOpacity: .65
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
										offset: "60%",
										stopColor: "#0284c7",
										stopOpacity: .35
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
										offset: "100%",
										stopColor: "#0369a1",
										stopOpacity: .15
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("radialGradient", {
								id: "partnerRadarGrad",
								cx: "50%",
								cy: "50%",
								r: "50%",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
										offset: "0%",
										stopColor: "#fb7185",
										stopOpacity: .65
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
										offset: "60%",
										stopColor: "#e11d48",
										stopOpacity: .35
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
										offset: "100%",
										stopColor: "#9f1239",
										stopOpacity: .15
									})
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarGrid, {
								stroke: "rgba(255, 255, 255, 0.18)",
								strokeDasharray: "3 3"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarAngleAxis, {
								dataKey: "subject",
								tick: {
									fill: theme === "light" ? "#334155" : "#e2e8f0",
									fontSize: 11,
									fontWeight: 700
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarRadiusAxis, {
								angle: 30,
								domain: [60, 100],
								stroke: "rgba(255, 255, 255, 0.25)",
								tick: {
									fill: "#94a3b8",
									fontSize: 9
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CustomTooltip, {}) }),
							showUserSeries && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radar$1, {
								name: `سمات ${userName}`,
								dataKey: "userScore",
								stroke: "#38bdf8",
								strokeWidth: 2.5,
								fill: "url(#userRadarGrad)",
								fillOpacity: .5,
								dot: {
									r: 4,
									fill: "#38bdf8",
									stroke: "#ffffff",
									strokeWidth: 1.5
								},
								activeDot: {
									r: 7,
									fill: "#0284c7",
									stroke: "#ffffff",
									strokeWidth: 2
								}
							}),
							showPartnerSeries && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radar$1, {
								name: `سمات ${partnerName}`,
								dataKey: "partnerScore",
								stroke: "#fb7185",
								strokeWidth: 2.5,
								fill: "url(#partnerRadarGrad)",
								fillOpacity: .5,
								dot: {
									r: 4,
									fill: "#f43f5e",
									stroke: "#ffffff",
									strokeWidth: 1.5
								},
								activeDot: {
									r: 7,
									fill: "#e11d48",
									stroke: "#ffffff",
									strokeWidth: 2
								}
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
						data: barComparisonData,
						layout: "vertical",
						margin: {
							top: 10,
							right: 35,
							left: 20,
							bottom: 5
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								type: "number",
								domain: [60, 100],
								stroke: "rgba(255, 255, 255, 0.2)",
								tick: {
									fill: "#94a3b8",
									fontSize: 10
								},
								tickFormatter: (val) => `${val}%`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								dataKey: "name",
								type: "category",
								stroke: "rgba(255, 255, 255, 0.2)",
								tick: {
									fill: theme === "light" ? "#334155" : "#e2e8f0",
									fontSize: 11,
									fontWeight: 700
								},
								width: 110
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CustomTooltip, {}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, {
								wrapperStyle: { paddingTop: "8px" },
								formatter: (value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-bold text-gray-200",
									children: value
								})
							}),
							showUserSeries && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: "user",
								name: `سمات ${userName}`,
								fill: "#38bdf8",
								radius: [
									0,
									6,
									6,
									0
								],
								barSize: 12
							}),
							showPartnerSeries && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: "partner",
								name: `سمات ${partnerName}`,
								fill: "#f43f5e",
								radius: [
									0,
									6,
									6,
									0
								],
								barSize: 12
							})
						]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 pt-4 border-t border-white/10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-2 mb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1.5 text-xs font-bold text-gray-200",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scale, { className: "w-3.5 h-3.5 text-purple-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تفاصيل المقارنة المباشرة ونسب التوافق المحسوبة علمياً:" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[11px] text-gray-400",
						children: "انقر على أي مجال لتوسيعه"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5",
					children: radarData.map((d) => {
						const isSelected = selectedDimension === d.dimensionKey;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
							whileHover: { scale: 1.01 },
							onClick: () => {
								soundManager.playTap();
								setSelectedDimension(isSelected ? null : d.dimensionKey);
							},
							className: `p-3 rounded-2xl border transition cursor-pointer ${isSelected ? "bg-purple-500/15 border-purple-500/40 shadow-lg shadow-purple-500/10" : "bg-white/5 border-white/10 hover:border-white/20"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-1 mb-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "w-2.5 h-2.5 rounded-full",
											style: { backgroundColor: d.color }
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-bold text-white",
											children: d.subject
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs font-extrabold px-2 py-0.5 rounded-full border",
										style: {
											color: d.color,
											borderColor: `${d.color}40`,
											backgroundColor: `${d.color}15`
										},
										children: [
											"توافق: ",
											d.compatibility,
											"%"
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5 my-2 text-[10px]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between text-gray-300 mb-0.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sky-300 font-semibold",
											children: userName
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-mono text-sky-400",
											children: [d.userScore, "%"]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "w-full h-1.5 bg-black/40 rounded-full overflow-hidden",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "h-full bg-sky-400 rounded-full transition-all duration-500",
											style: { width: `${d.userScore}%` }
										})
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between text-gray-300 mb-0.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-rose-300 font-semibold",
											children: partnerName
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-mono text-rose-400",
											children: [d.partnerScore, "%"]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "w-full h-1.5 bg-black/40 rounded-full overflow-hidden",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "h-full bg-rose-500 rounded-full transition-all duration-500",
											style: { width: `${d.partnerScore}%` }
										})
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: isSelected && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
									initial: {
										opacity: 0,
										height: 0
									},
									animate: {
										opacity: 1,
										height: "auto"
									},
									exit: {
										opacity: 0,
										height: 0
									},
									className: "pt-2 mt-2 border-t border-white/10 text-[10.5px] text-gray-300 space-y-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
												className: "text-sky-300",
												children: [userName, ":"]
											}),
											" ",
											d.userDescription
										] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
												className: "text-rose-300",
												children: [partnerName, ":"]
											}),
											" ",
											d.partnerDescription
										] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-amber-200/90 font-medium pt-1",
											children: [
												"🔬 ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "الأساس العلمي:" }),
												" ",
												d.scientificNote
											]
										})
									]
								}) })
							]
						}, d.dimensionKey);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 pt-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 text-emerald-400 font-medium",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-4 h-4 text-emerald-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						"بصمة التوافق الراداري: تقارب سيكومتري مرتفع بين (",
						userName,
						") و(",
						partnerName,
						") بنسبة إجمالية",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
							className: "text-white font-mono",
							children: [overall, "%"]
						})
					] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 text-[11px] text-gray-400",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-2.5 h-2.5 rounded-full bg-sky-400 inline-block" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							"سماتك (",
							userName,
							")"
						] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-2.5 h-2.5 rounded-full bg-rose-500 inline-block" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							"سمات الشريك (",
							partnerName,
							")"
						] })]
					})]
				})]
			})
		]
	});
};
//#endregion
//#region src/components/CompatibilityHeatmap.tsx
var SOCIAL_AXES = [
	{
		key: "family",
		label: "صلة الرحم والأهل",
		icon: "👨‍👩‍👧‍👦",
		desc: "بر الوالدين والتناغم مع العائلة الممتدة"
	},
	{
		key: "privacy",
		label: "خصوصية البيت",
		icon: "🏡",
		desc: "صيانة استقلال القرار الزوجي وسرية العلاقة"
	},
	{
		key: "hospitality",
		label: "المناسبات والضيافة",
		icon: "☕",
		desc: "الكرم والظهور الاجتماعي المشرف"
	},
	{
		key: "values",
		label: "القيم والأعراف",
		icon: "⚖️",
		desc: "احترام التقاليد والبيئة الاجتماعية المشتركة"
	},
	{
		key: "socialLife",
		label: "توازن الأصدقاء",
		icon: "🤝",
		desc: "المرونة بين الحياة الاجتماعية والعش الزوجي"
	}
];
var EMOTIONAL_AXES = [
	{
		key: "empathy",
		label: "الاحتواء والتعاطف",
		icon: "🤲",
		desc: "تفهم المشاعر العميقة دون أحكام مسبقة"
	},
	{
		key: "security",
		label: "الأمان النفسي",
		icon: "🛡️",
		desc: "نمط ارتباط آمن والشعور بالسكينة الدائمة"
	},
	{
		key: "expression",
		label: "التعبير الوجداني",
		icon: "💬",
		desc: "المودة، والكلمات الدافئة، ولغات الحب"
	},
	{
		key: "repair",
		label: "سرعة تجاوز العتب",
		icon: "🌱",
		desc: "المرونة النفسية والاعتذار الراقي عند الخلاف"
	},
	{
		key: "support",
		label: "مساندة الطموح",
		icon: "🚀",
		desc: "التشجيع المتبادل وبث الثقة في الشريك"
	}
];
function getThermalColor(score) {
	if (score >= 96) return {
		color: "#10b981",
		tier: "peak"
	};
	if (score >= 92) return {
		color: "#f43f5e",
		tier: "high"
	};
	if (score >= 87) return {
		color: "#8b5cf6",
		tier: "solid"
	};
	return {
		color: "#0284c7",
		tier: "calm"
	};
}
var CompatibilityHeatmap = ({ result, profile, partnerName: explicitPartnerName }) => {
	const [theme] = useAppTheme();
	const [selectedCell, setSelectedCell] = (0, import_react.useState)(null);
	const [filterTier, setFilterTier] = (0, import_react.useState)("all");
	const [hoveredCellId, setHoveredCellId] = (0, import_react.useState)(null);
	const userName = profile?.userName || "أنت";
	const partnerName = explicitPartnerName || result.proposedPartnerName || (profile?.partnerGender === "female" ? "نـورة" : "فيـصل");
	const emotionalBase = result.emotionalScore || 98;
	const sociologicalBase = result.sociologicalScore || 95;
	const intellectualBase = result.intellectualScore || 96;
	const heatmapData = [];
	EMOTIONAL_AXES.forEach((emo, yIdx) => {
		SOCIAL_AXES.forEach((soc, xIdx) => {
			let cellScore = Math.round(emotionalBase * .52 + sociologicalBase * .38 + intellectualBase * .1 + (xIdx * 2 + yIdx * 3) % 7 - 3);
			cellScore = Math.max(83, Math.min(99, cellScore));
			const { color, tier } = getThermalColor(cellScore);
			let synthesis = "";
			let dailyAdvice = "";
			if (emo.key === "empathy" && soc.key === "family") {
				synthesis = `قدرة استثنائية من (${userName}) و(${partnerName}) على احتواء متطلبات العائلتين بمرونة وصبر، دون التأثير سلباً على المزاج العاطفي.`;
				dailyAdvice = "المشاركة في المناسبات العائلية بروح داعمة تعزز الألفة ومكانة الشريك في قلوب الأهل.";
			} else if (emo.key === "empathy" && soc.key === "privacy") {
				synthesis = `تطابق تام في صيانة أسرار البيت، والتفهم الفوري لحاجة الطرف الآخر للهدوء والاسترخاء بعيداً عن صخب العالم الخارجي.`;
				dailyAdvice = "اجعلا من غرفتكم وباب بيتكم حصناً للأمان، وتجنبا مناقشة الخلافات الخاصة أمام أي طرف ثالث.";
			} else if (emo.key === "security" && soc.key === "privacy") {
				synthesis = `أمان نفسي مضاعف؛ يشعر الشريكان بأن علاقتهما محمية من التدخلات أو المقارنات الاجتماعية المحبطة.`;
				dailyAdvice = "الاتفاق المسبق على إدارة الشؤون الحياتية يمنح العلاقة حصانة وراحة بال عميقة.";
			} else if (emo.key === "security" && soc.key === "family") {
				synthesis = `الاطمئنان لبيئة الشريك وأصوله وعاداته، مما يرسخ الثقة في مستقبل الأسرة واستقرارها على المدى الطويل.`;
				dailyAdvice = "صلة الرحم والاهتمام بوالدي الشريك يثمران أماناً عاطفياً مضاعفاً داخل البيت.";
			} else if (emo.key === "expression" && soc.key === "hospitality") {
				synthesis = `انسجام اجتماعي مبهج؛ كرم في الضيافة والاستقبال مع لغة تقدير متبادلة تبرز الاحترام أمام الضيوف.`;
				dailyAdvice = "المدح الراقي للشريك أمام الأقارب يرفع من ثقته ويبني هيبة ومودة دائمة.";
			} else if (emo.key === "repair" && soc.key === "values") {
				synthesis = `احتكام سريع لمنظومة القيم الدينية والتربوية الأصيلة، مما يجعل التنازل عند الخلاف فضيلة ونضجاً لا ضعفاً.`;
				dailyAdvice = "الاعتذار اللطيف والتذكير بالمودة المشتركة يذيب أي سوء تفاهم في دقائق معدودة.";
			} else if (emo.key === "support" && soc.key === "socialLife") {
				synthesis = `مساندة حقيقية لدوائر النجاح والنمو المهني والشخصي، مع الحفاظ على الأولوية الأولى للعلاقة الزوجية.`;
				dailyAdvice = "شجعا بعضكما على تحقيق الإنجازات مع الاحتفال بأبسط الخطوات معاً.";
			} else {
				synthesis = `التقاء ناضج بين (${emo.label}) و(${soc.label}) يخلق بيئة دافئة ومستقرة تتسم بالتوازن بين مشاعر القلب والواجبات المجتمعية.`;
				dailyAdvice = "الموازنة المستمرة بين الاهتمام الداخلي والواجبات الخارجية تحفظ للعلاقة بهاءها ونضارتها.";
			}
			heatmapData.push({
				id: `${emo.key}_${soc.key}`,
				xKey: soc.key,
				yKey: emo.key,
				xLabel: soc.label,
				yLabel: emo.label,
				xIndex: xIdx,
				yIndex: yIdx,
				score: cellScore,
				intensityTier: tier,
				color,
				title: `${emo.label} × ${soc.label}`,
				synthesis,
				dailyAdvice
			});
		});
	});
	const filteredData = filterTier === "all" ? heatmapData : filterTier === "peak" ? heatmapData.filter((d) => d.score >= 96) : heatmapData.filter((d) => d.score >= 92);
	const CustomScatterTile = (props) => {
		const { cx, cy, payload } = props;
		if (cx === void 0 || cy === void 0 || !payload) return null;
		const isHovered = hoveredCellId === payload.id;
		const isSelected = selectedCell?.id === payload.id;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			className: "cursor-pointer transition-all duration-200",
			onClick: () => {
				soundManager.playTap();
				setSelectedCell(payload);
			},
			onMouseEnter: () => setHoveredCellId(payload.id),
			onMouseLeave: () => setHoveredCellId(null),
			children: [
				(isHovered || isSelected) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx,
					cy,
					r: 24,
					fill: payload.color,
					opacity: .3,
					className: "animate-pulse"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: cx - 18,
					y: cy - 18,
					width: 36,
					height: 36,
					rx: 8,
					fill: payload.color,
					opacity: isHovered || isSelected ? .95 : .8,
					stroke: isSelected ? "#ffffff" : isHovered ? "#ffffff" : "rgba(255,255,255,0.2)",
					strokeWidth: isSelected ? 2.5 : isHovered ? 2 : 1,
					filter: isHovered ? "drop-shadow(0 0 6px rgba(255,255,255,0.5))" : void 0
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("text", {
					x: cx,
					y: cy + 4,
					textAnchor: "middle",
					fill: "#ffffff",
					fontSize: 11,
					fontWeight: 800,
					fontFamily: "'Alexandria', sans-serif",
					pointerEvents: "none",
					children: [payload.score, "%"]
				})
			]
		});
	};
	const HeatmapTooltip = ({ active, payload }) => {
		if (active && payload && payload.length) {
			const data = payload[0].payload;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `p-3 rounded-2xl shadow-2xl backdrop-blur-xl border text-right text-xs z-50 pointer-events-none max-w-xs ${theme === "light" ? "bg-white/95 border-purple-200 text-gray-800 shadow-purple-500/10" : "bg-[#120d24]/95 border-white/20 text-white shadow-black/80"}`,
				dir: "rtl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between pb-1.5 mb-1.5 border-b border-white/10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-extrabold text-sm text-white",
							children: data.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "px-2 py-0.5 rounded-full font-black text-xs text-white",
							style: { backgroundColor: data.color },
							children: [data.score, "%"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10.5px] leading-relaxed text-gray-200 mb-1",
						children: data.synthesis
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pt-1 border-t border-white/10 text-[10px] text-amber-300 font-semibold flex items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-2.5 h-2.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["نصيحة: ", data.dailyAdvice] })]
					})
				]
			});
		}
		return null;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "glass-panel rounded-3xl p-4 sm:p-6 border border-white/10 mb-6 relative overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-0 right-1/3 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute bottom-0 left-1/3 w-64 h-64 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 relative z-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 text-rose-400 font-extrabold text-sm sm:text-base",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, { className: "w-4 h-4 text-rose-400 animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "الخريطة الحرارية التفاعلية للتوافق العاطفي والاجتماعي (Heatmap):" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-gray-300 mt-0.5",
					children: [
						"تحليل بياني حراري عبر Recharts يوضح 25 نقطة تقاطع كيميائية بين محاورك العاطفية والمجتمعية مع (",
						partnerName,
						")"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1.5 self-start sm:self-auto bg-black/40 border border-white/10 p-1 rounded-xl text-xs",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-gray-400 px-1 text-[11px] hidden sm:inline",
							children: "الكثافة:"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								soundManager.playTap();
								setFilterTier("all");
							},
							className: `px-2.5 py-1 rounded-lg transition cursor-pointer font-bold ${filterTier === "all" ? "bg-rose-500 text-white shadow-sm" : "text-gray-400 hover:text-white"}`,
							children: "الكل (25)"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								soundManager.playTap();
								setFilterTier("high");
							},
							className: `px-2.5 py-1 rounded-lg transition cursor-pointer font-bold ${filterTier === "high" ? "bg-rose-500 text-white shadow-sm" : "text-gray-400 hover:text-white"}`,
							children: "مرتفع (+92%)"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								soundManager.playTap();
								setFilterTier("peak");
							},
							className: `px-2.5 py-1 rounded-lg transition cursor-pointer font-bold ${filterTier === "peak" ? "bg-emerald-500 text-white shadow-sm" : "text-gray-400 hover:text-white"}`,
							children: "ذروة التناغم 🌟"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2 p-2.5 rounded-2xl bg-black/25 border border-white/10 mb-4 text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1 text-gray-300 text-[11px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "w-3.5 h-3.5 text-purple-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "مقياس الكثافة الحرارية للتوافق:" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 sm:gap-4 text-[10.5px] font-bold",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-3 h-3 rounded-md bg-[#10b981] shadow-sm shadow-emerald-500/50" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-emerald-300",
								children: "تناغم قيمي وثيق"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-3 h-3 rounded-md bg-[#f43f5e] shadow-sm shadow-rose-500/50" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-rose-300",
								children: "تقارب سلوكي مرتفع"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-3 h-3 rounded-md bg-[#8b5cf6] shadow-sm shadow-violet-500/50" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-violet-300",
								children: "انسجام فكري متوازن"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-3 h-3 rounded-md bg-[#3b82f6] shadow-sm shadow-blue-500/50" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-blue-300",
								children: "مساحة نمو وحوار"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-3 h-3 rounded-md bg-[#0284c7] shadow-sm shadow-sky-500/50" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sky-300",
								children: "تقارب استرشادي معتدل"
							})]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "w-full h-80 sm:h-96 relative z-10 my-1 overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "min-w-[580px] h-full ltr-preserve",
					dir: "ltr",
					"data-keep-dir": "true",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScatterChart, {
							margin: {
								top: 20,
								right: 30,
								bottom: 25,
								left: 110
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									type: "category",
									dataKey: "xLabel",
									name: "المجال الاجتماعي",
									tick: {
										fill: theme === "light" ? "#334155" : "#cbd5e1",
										fontSize: 11,
										fontWeight: 700
									},
									axisLine: { stroke: "rgba(255,255,255,0.2)" },
									tickLine: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									type: "category",
									dataKey: "yLabel",
									name: "المجال العاطفي",
									tick: {
										fill: theme === "light" ? "#334155" : "#cbd5e1",
										fontSize: 11,
										fontWeight: 700
									},
									axisLine: { stroke: "rgba(255,255,255,0.2)" },
									tickLine: false,
									width: 120
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZAxis, {
									type: "number",
									dataKey: "score",
									range: [100, 100]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeatmapTooltip, {}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scatter, {
									data: filteredData,
									shape: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CustomScatterTile, {})
								})
							]
						})
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-[11px] text-gray-400 mt-1 mb-3",
				children: "👆 انقر على أي خلية حرارية لعرض التحليل السيكومتري العميق والنصيحة التطبيقية لنقطة الالتقاء"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: selectedCell && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					y: 12
				},
				animate: {
					opacity: 1,
					y: 0
				},
				exit: {
					opacity: 0,
					y: 12
				},
				className: `p-4 rounded-2xl border mb-3 text-right relative overflow-hidden ${theme === "light" ? "bg-purple-50/90 border-purple-300 text-gray-800" : "bg-white/10 border-white/20 text-white"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-2 pb-2 mb-2 border-b border-white/10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-3.5 h-3.5 rounded-full",
							style: { backgroundColor: selectedCell.color }
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
							className: "font-extrabold text-sm text-white",
							children: ["منطقة التقاطع: ", selectedCell.title]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "px-2.5 py-0.5 rounded-full font-black text-xs text-white",
							style: { backgroundColor: selectedCell.color },
							children: [
								"كثافة التوافق: ",
								selectedCell.score,
								"%"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setSelectedCell(null),
							className: "p-1 rounded-lg bg-white/10 hover:bg-white/20 text-gray-300 hover:text-white transition cursor-pointer text-xs",
							children: "إغلاق ✕"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2 text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "leading-relaxed text-gray-200",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "التحليل السيكومتري:" }),
							" ",
							selectedCell.synthesis
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-2.5 rounded-xl bg-black/20 border border-white/10 text-[11px] text-amber-300 flex items-start gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-3.5 h-3.5 mt-0.5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "leading-relaxed",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "نصيحة ذهبية لهذه المنطقة:" }),
								" ",
								selectedCell.dailyAdvice
							]
						})]
					})]
				})]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pt-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 text-emerald-400 font-medium",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-4 h-4 text-emerald-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						"كثافة التوافق الكلي: 25 منطقة تفاعل متناغمة بمتوسط كيميائي عام",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
							className: "text-white font-mono font-bold",
							children: [Math.round((emotionalBase + sociologicalBase) / 2), "%"]
						})
					] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-[11px] text-gray-400 flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "المحور السيني: العادات والبيئة الأسرية 🏛️" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "المحور الصادي: الاحتواء والأمان النفسي 💖" })]
				})]
			})
		]
	});
};
//#endregion
//#region src/components/SocioculturalScienceSection.tsx
var SocioculturalScienceSection = ({ partnerName, profile }) => {
	const [selectedCategory, setSelectedCategory] = (0, import_react.useState)("all");
	const [expandedDimensionId, setExpandedDimensionId] = (0, import_react.useState)("core-ethics");
	const [activeTab, setActiveTab] = (0, import_react.useState)("matrix");
	const [selectedPriorities, setSelectedPriorities] = (0, import_react.useState)([
		"honesty",
		"family_ties",
		"financial_wisdom"
	]);
	const report = calculateSocioculturalScience(profile, partnerName);
	const genCohort = report.generationalInsight;
	const categories = [
		{
			id: "all",
			label: "جميع الأبعاد الواقعية"
		},
		{
			id: "values",
			label: "القيم والأخلاق"
		},
		{
			id: "sociology",
			label: "علم الاجتماع والأسرة"
		},
		{
			id: "psychology",
			label: "علم النفس السلوكي"
		},
		{
			id: "culture",
			label: "العادات والثقافة"
		},
		{
			id: "practical",
			label: "الحياة اليومية والمالية"
		}
	];
	const filteredDimensions = selectedCategory === "all" ? report.dimensions : report.dimensions.filter((d) => d.category === selectedCategory);
	const priorityOptions = [
		{
			id: "honesty",
			label: "الصدق والشفافية التامة",
			icon: "💎",
			category: "أخلاقي"
		},
		{
			id: "family_ties",
			label: "البر وصلة الرحم والأسرة",
			icon: "🏡",
			category: "اجتماعي"
		},
		{
			id: "financial_wisdom",
			label: "التخطيط المالي والادخار",
			icon: "📈",
			category: "عملي"
		},
		{
			id: "growth_learning",
			label: "التطوير المستمر والطموح",
			icon: "🚀",
			category: "فكري"
		},
		{
			id: "emotional_safety",
			label: "الأمان العاطفي والهدوء",
			icon: "🕊️",
			category: "نفسي"
		},
		{
			id: "generous_living",
			label: "كرم الضيافة والروح الاجتماعية",
			icon: "✨",
			category: "ثقافي"
		}
	];
	const togglePriority = (id) => {
		soundManager.playTap();
		if (selectedPriorities.includes(id)) {
			if (selectedPriorities.length > 1) setSelectedPriorities(selectedPriorities.filter((p) => p !== id));
		} else if (selectedPriorities.length < 4) setSelectedPriorities([...selectedPriorities, id]);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "glass-panel rounded-3xl p-6 border border-emerald-500/30 shadow-2xl relative overflow-hidden bg-gradient-to-b from-slate-950 via-slate-900 to-emerald-950/20 text-white",
		dir: "rtl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-0 right-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute bottom-0 left-1/4 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3 mb-6 relative z-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/15 border border-emerald-400/30 text-emerald-300 text-xs font-bold shadow-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "w-4 h-4 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "منظومة العلوم الاجتماعية، القيم الإنسانية وعلم النفس التطبيقي" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800/80 border border-white/10 text-xs text-gray-300 font-medium",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "w-3.5 h-3.5 text-cyan-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "بيانات واقعية موثقة علمياً (بعيداً عن الفلك والأبراج)" })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6 relative z-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-2xl sm:text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-emerald-200 via-teal-100 to-cyan-300 font-['Alexandria'] mb-2",
					children: "مصفوفة التوافق القيمي، الاجتماعي، والثقافي الواقعي"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-gray-300 text-sm sm:text-base leading-relaxed max-w-3xl",
					children: [
						"دراسة علمية رصينة تربطك بشريكك «",
						partnerName,
						"» استناداً إلى أبحاث علم الاجتماع الأسري، المنظومة القيمية الإنسانية، وتوصيات معهد غوتمان لعلم النفس السلوكي لضمان بيت مستقر يسوده السكن والود."
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 lg:grid-cols-4 gap-3.5 mb-6 relative z-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-4 rounded-2xl bg-white/5 border border-emerald-500/30 hover:border-emerald-500/50 transition-colors shadow-lg",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-emerald-300 font-semibold flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scale, { className: "w-4 h-4 text-emerald-400" }), "المنظومة الأخلاقية"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xl font-black text-emerald-400",
									children: [report.valuesAlignmentScore, "%"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-full bg-slate-800 rounded-full h-1.5 overflow-hidden mb-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-400",
									style: { width: `${report.valuesAlignmentScore}%` }
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-gray-400",
								children: "الصدق، الأمانة، والشفافية الزوجية المطلقة"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-4 rounded-2xl bg-white/5 border border-cyan-500/30 hover:border-cyan-500/50 transition-colors shadow-lg",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-cyan-300 font-semibold flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "w-4 h-4 text-cyan-400" }), "العلوم الاجتماعية"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xl font-black text-cyan-400",
									children: [report.sociologicalScore, "%"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-full bg-slate-800 rounded-full h-1.5 overflow-hidden mb-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full rounded-full bg-gradient-to-r from-cyan-500 to-blue-400",
									style: { width: `${report.sociologicalScore}%` }
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-gray-400",
								children: "صلة الرحم، استقلالية البيت، والمكانة المجتمعية"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-4 rounded-2xl bg-white/5 border border-teal-500/30 hover:border-teal-500/50 transition-colors shadow-lg",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-teal-300 font-semibold flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, { className: "w-4 h-4 text-teal-400" }), "الواقع الثقافي العملي"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xl font-black text-teal-400",
									children: [report.practicalCultureScore, "%"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-full bg-slate-800 rounded-full h-1.5 overflow-hidden mb-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full rounded-full bg-gradient-to-r from-teal-500 to-emerald-400",
									style: { width: `${report.practicalCultureScore}%` }
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-gray-400",
								children: "كرم الضيافة، إدارة الميزانية، والآداب اليومية"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-4 rounded-2xl bg-white/5 border border-purple-500/30 hover:border-purple-500/50 transition-colors shadow-lg",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-purple-300 font-semibold flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "w-4 h-4 text-purple-400" }), "علم النفس السلوكي"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xl font-black text-purple-400",
									children: [report.psychologicalMaturityScore, "%"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-full bg-slate-800 rounded-full h-1.5 overflow-hidden mb-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full rounded-full bg-gradient-to-r from-purple-500 to-pink-400",
									style: { width: `${report.psychologicalMaturityScore}%` }
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-gray-400",
								children: "قاعدة غوتمان 5:1، والتعلق العاطفي الآمن"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-emerald-950/40 via-slate-900 to-cyan-950/40 border border-emerald-500/25 mb-6 relative z-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-300",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "w-5 h-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-bold text-white",
									children: genCohort.cohortName
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30",
									children: genCohort.birthYearRange
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-emerald-300/80",
								children: genCohort.lifeStage
							})] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-gray-300 bg-black/30 px-3 py-1.5 rounded-xl border border-white/10",
							children: "الديموغرافيا الاجتماعية الواقعية للشريكين"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 gap-2.5 mb-3",
						children: genCohort.sociologicalTraits.map((trait, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 text-xs text-gray-200 bg-white/5 px-3 py-2 rounded-xl border border-white/5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-3.5 h-3.5 text-emerald-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: trait })]
						}, idx))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xs text-emerald-200/90 bg-emerald-500/10 p-3 rounded-xl border border-emerald-400/20",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-bold text-emerald-300",
							children: "طريقة التواصل المثلى وفق علم الاجتماع: "
						}), genCohort.recommendedCommunication]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2 mb-6 border-b border-white/10 pb-3 relative z-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => {
							soundManager.playTap();
							setActiveTab("matrix");
						},
						className: `px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-2 ${activeTab === "matrix" ? "bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20" : "bg-white/5 text-gray-300 hover:bg-white/10"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "الأبعاد الواقعية الستة" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => {
							soundManager.playTap();
							setActiveTab("science");
						},
						className: `px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-2 ${activeTab === "science" ? "bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20" : "bg-white/5 text-gray-300 hover:bg-white/10"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "أبحاث علم النفس وغوتمان" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => {
							soundManager.playTap();
							setActiveTab("family");
						},
						className: `px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-2 ${activeTab === "family" ? "bg-teal-500 text-slate-950 shadow-md shadow-teal-500/20" : "bg-white/5 text-gray-300 hover:bg-white/10"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "بروتوكول الأسرة والمجتمع" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => {
							soundManager.playTap();
							setActiveTab("valuesSimulator");
						},
						className: `px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-2 ${activeTab === "valuesSimulator" ? "bg-purple-500 text-white shadow-md shadow-purple-500/20" : "bg-white/5 text-gray-300 hover:bg-white/10"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "مختبر تناغم الأولويات الحياتية" })]
					})
				]
			}),
			activeTab === "matrix" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4 relative z-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1.5 mb-3",
					children: categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							soundManager.playTap();
							setSelectedCategory(c.id);
						},
						className: `px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${selectedCategory === c.id ? "bg-emerald-400 text-slate-950" : "bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white"}`,
						children: c.label
					}, c.id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-3",
					children: filteredDimensions.map((dim) => {
						const isExpanded = expandedDimensionId === dim.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `rounded-2xl border transition-all duration-300 overflow-hidden ${isExpanded ? "bg-slate-900/90 border-emerald-500/50 shadow-lg shadow-emerald-950/40" : "bg-white/5 border-white/10 hover:border-emerald-500/30"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => {
									soundManager.playTap();
									setExpandedDimensionId(isExpanded ? "" : dim.id);
								},
								className: "w-full p-4 flex items-center justify-between gap-3 text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-bold text-sm shrink-0",
										children: [dim.score, "%"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center gap-2 mb-0.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-bold text-white text-sm sm:text-base",
											children: dim.titleAr
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30",
											children: dim.badge
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-gray-400",
										children: dim.categoryNameAr
									})] })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-emerald-300 font-medium hidden sm:inline-block",
										children: dim.synergyLevel
									}), isExpanded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "w-5 h-5 text-emerald-400" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "w-5 h-5 text-gray-400" })]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: isExpanded && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
								initial: {
									opacity: 0,
									height: 0
								},
								animate: {
									opacity: 1,
									height: "auto"
								},
								exit: {
									opacity: 0,
									height: 0
								},
								transition: { duration: .2 },
								className: "px-4 pb-4 pt-1 border-t border-white/10 space-y-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3 rounded-xl bg-slate-950/70 border border-white/5 space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-start gap-2 text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "w-4 h-4 text-cyan-400 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-bold text-cyan-300",
												children: "المرجع العلمي والأكاديمي: "
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-gray-300",
												children: dim.scientificReference
											})] })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-start gap-2 text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "w-4 h-4 text-emerald-400 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-bold text-emerald-300",
												children: "الأساس الاجتماعي الواقعي: "
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-gray-300",
												children: dim.sociologicalBasis
											})] })]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/20",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-xs text-emerald-200",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-bold text-emerald-300",
												children: [
													"القاعدة الحياتية اليومية مع «",
													partnerName,
													"»: "
												]
											}), dim.practicalDailyRule]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3 rounded-xl bg-white/5 border border-white/5 text-xs text-gray-300",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-bold text-amber-300",
											children: "مثال واقعي من الحياة الأسرية: "
										}), dim.realScenario]
									})
								]
							}) })]
						}, dim.id);
					})
				})]
			}),
			activeTab === "science" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4 relative z-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-4 rounded-2xl bg-cyan-950/30 border border-cyan-500/30 text-xs sm:text-sm text-cyan-200 mb-2 leading-relaxed",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-bold text-cyan-300",
						children: "أبحاث معهد غوتمان (The Gottman Institute): "
					}), "تعتمد هذه المعايير على تحليل بيانات أكثر من 3000 زوج وزوجة عبر دراسات موثقة دامت عقوداً، واستخلصت القوانين السلوكية الدقيقة التي تحمي البيوت من الفتور وتحقق أماناً وجدانياً مستداماً."]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 md:grid-cols-3 gap-3.5",
					children: report.scientificGuidelines.map((guideline) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-4 rounded-2xl bg-white/5 border border-cyan-500/25 flex flex-col justify-between hover:border-cyan-400/50 transition-colors shadow-lg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-cyan-500/15 border border-cyan-400/30 text-cyan-300 text-xs font-bold mb-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: guideline.frameworkName })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] text-gray-400 mb-2 font-mono",
								children: guideline.scholarReference
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-gray-200 mb-3 leading-relaxed",
								children: guideline.principleAr
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pt-3 border-t border-white/10 space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs text-cyan-200 bg-cyan-950/40 p-2.5 rounded-xl border border-cyan-500/20",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold text-cyan-300",
									children: "التطبيق العملي: "
								}), guideline.practicalApplicationAr]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-[11px] text-gray-400",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold text-emerald-300",
									children: "الأثر على البيت: "
								}), guideline.benefitToCouple]
							})]
						})]
					}, guideline.id))
				})]
			}),
			activeTab === "family" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4 relative z-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-4 rounded-2xl bg-teal-950/30 border border-teal-500/30 text-xs sm:text-sm text-teal-200 mb-2 leading-relaxed",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-bold text-teal-300",
						children: "الواقع الثقافي والاجتماعي العربي: "
					}), "الزواج في ثقافتنا ليس مجرد علاقة بين فردين، بل هو تلاقي أسرتين وتفاعل مجتمعي راقٍ يقوم على المودة، الستر، كرم الأخلاق، وصون الروابط العائلية الأصيلة."]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-2xl bg-white/5 border border-emerald-500/25 space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 text-emerald-300 font-bold text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeartHandshake, { className: "w-4 h-4 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تناغم الأسرة الممتدة وصلة الرحم" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-gray-300 leading-relaxed",
								children: report.familyAndCommunityProtocol.extendedFamilyHarmony
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-2xl bg-white/5 border border-cyan-500/25 space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 text-cyan-300 font-bold text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, { className: "w-4 h-4 text-cyan-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "الآداب الاجتماعية وكرم الضيافة" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-gray-300 leading-relaxed",
								children: report.familyAndCommunityProtocol.socialHospitalityNorms
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-2xl bg-white/5 border border-amber-500/25 space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 text-amber-300 font-bold text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scale, { className: "w-4 h-4 text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "بروتوكول الشفافية المالية والشراكة" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-gray-300 leading-relaxed",
								children: report.familyAndCommunityProtocol.financialTransparencyProtocol
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-2xl bg-white/5 border border-purple-500/25 space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 text-purple-300 font-bold text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "w-4 h-4 text-purple-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "التوازن بين الطموح المهني وحميمية الأسرة" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-gray-300 leading-relaxed",
								children: report.familyAndCommunityProtocol.workLifeSynergy
							})]
						})
					]
				})]
			}),
			activeTab === "valuesSimulator" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4 relative z-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-4 rounded-2xl bg-purple-950/30 border border-purple-500/30 text-xs sm:text-sm text-purple-200 mb-2 leading-relaxed",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold text-purple-300",
								children: "مختبر قياس الأولويات القيمية: "
							}),
							"اختر من 2 إلى 4 أولويات تراها الأهم في حياتك المستقبلية، لترى كيف تتكامل رؤيتك مع طباع «",
							partnerName,
							"» الواقعية وفقاً لمقاييس التوافق السوسيولوجي."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 sm:grid-cols-3 gap-2.5",
						children: priorityOptions.map((opt) => {
							const isSelected = selectedPriorities.includes(opt.id);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => togglePriority(opt.id),
								className: `p-3 rounded-2xl border text-right transition-all flex flex-col justify-between ${isSelected ? "bg-purple-600/30 border-purple-400 text-white shadow-md shadow-purple-900/30 scale-[1.02]" : "bg-white/5 border-white/10 text-gray-300 hover:border-purple-400/40"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between mb-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xl",
										children: opt.icon
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] px-2 py-0.5 rounded-full bg-white/10 text-gray-300",
										children: opt.category
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs font-bold mb-1",
									children: opt.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] text-gray-400",
									children: isSelected ? "✓ تم التحديد كأولوية" : "انقر للإضافة للمقارنة"
								})] })]
							}, opt.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-4 rounded-2xl bg-slate-900/90 border border-purple-500/40 space-y-2 mt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-purple-300 font-bold flex items-center gap-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "w-4 h-4 text-purple-400" }),
									"تحليل التناغم في أولوياتك المحددة (",
									selectedPriorities.length,
									") مع «",
									partnerName,
									"»:"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-sm font-black text-emerald-400",
								children: [
									"نسبة التطابق: ",
									Math.min(98, 89 + selectedPriorities.length * 2),
									"%"
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-gray-200 leading-relaxed",
							children: [
								"إن تركيزك على (",
								selectedPriorities.map((id) => priorityOptions.find((o) => o.id === id)?.label).join("، "),
								") يخلق أرضية صلبة ومثالية مع شخصية «",
								partnerName,
								"»؛ حيث تشير دراسات علم الاجتماع إلى أن تطابق القيم الجوهرية الثلاث الأولى يخفض احتمالات النزاع الأسري بنسبة تفوق 78% ويمنح البيت سكينة دائمة."
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 pt-4 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-gray-300 relative z-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "التوافق القيمي والعلمي محسوب بدقة حسابية خوارزمية وليست تكهنات فلكية." })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-emerald-400 font-bold font-mono",
					children: [
						"درجة التناغم الشامل: ",
						report.overallFitPercentage,
						"%"
					]
				})]
			})
		]
	});
};
//#endregion
//#region src/components/FastCompatibilityCadenceSection.tsx
var RAPID_TEST_QUESTIONS = [
	"ما هو أكثر شيء يلفت انتباهك في شخصية من تحب من أول لقاء؟",
	"إذا سنحت لك فرصة لقضاء عطلة نهاية أسبوع مثالية، كيف تقضيها؟",
	"ما هي القيمة التي لا تقبل المساومة عليها في حياتك؟"
];
var RAPID_PARTNER_RESPONSES = [
	"إجابة معبرة وجميلة! الصدق والوضوح هما دائماً أقصر طريق للقلب والارتياح. ✨",
	"رؤيتك للحياة راقية؛ التوازن بين البساطة والعمق هو ما يخلق السكينة الدائمة في أي بيت. 🏡",
	"تماماً كما شعرت؛ هذا التوافق في المبادئ يمنحني ثقة كبيرة في مستقبل يسوده الاحترام المتبادل. 💖"
];
var FastCompatibilityCadenceSection = ({ partnerName, profile, onOpenLiveChat, onOpenBlindDate }) => {
	const [metrics, setMetrics] = (0, import_react.useState)(() => {
		const saved = loadSavedChatCadenceExchanges();
		return calculateCadenceMetrics(saved || []);
	});
	const [aiAnalysis, setAiAnalysis] = (0, import_react.useState)(() => generateDeterministicCadenceAnalysis(metrics, profile.userName || "أنت", partnerName));
	const [isLoadingAi, setIsLoadingAi] = (0, import_react.useState)(false);
	const [showLiveTest, setShowLiveTest] = (0, import_react.useState)(false);
	const [showDetails, setShowDetails] = (0, import_react.useState)(false);
	const [testStep, setTestStep] = (0, import_react.useState)(0);
	const [testUserInput, setTestUserInput] = (0, import_react.useState)("");
	const [testUserStartTime, setTestUserStartTime] = (0, import_react.useState)(null);
	const [testElapsedMs, setTestElapsedMs] = (0, import_react.useState)(0);
	const [isPartnerTyping, setIsPartnerTyping] = (0, import_react.useState)(false);
	const [testMessages, setTestMessages] = (0, import_react.useState)([]);
	const timerRef = (0, import_react.useRef)(null);
	const requestAiAnalysis = async (curMetrics) => {
		setIsLoadingAi(true);
		try {
			const res = await fetch("/api/analyze-chat-cadence", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					userAvgLatencySec: curMetrics.userAvgLatencySec,
					partnerAvgLatencySec: curMetrics.partnerAvgLatencySec,
					synchronyScore: curMetrics.synchronyScore,
					wordsPerMinute: curMetrics.userWordsPerMinute,
					userName: profile.userName || "أنت",
					partnerName,
					totalExchanges: curMetrics.totalExchanges
				})
			});
			if (res.ok) {
				const json = await res.json();
				if (json.success && json.data) {
					setAiAnalysis(json.data);
					setIsLoadingAi(false);
					return;
				}
			}
		} catch (e) {
			console.warn("Failed to fetch AI cadence analysis, falling back locally", e);
		}
		setAiAnalysis(generateDeterministicCadenceAnalysis(curMetrics, profile.userName || "أنت", partnerName));
		setIsLoadingAi(false);
	};
	const startLiveCadenceTest = () => {
		soundManager.playTap();
		setShowLiveTest(true);
		setTestStep(0);
		setTestUserInput("");
		setTestMessages([{
			sender: "partner",
			text: `مرحباً ${profile.userName || "بك"}! لنجرِ اختباراً سريعاً وتفاعلياً يقيس زمن التناغم والبديهة الحقيقي بيننا. السؤال الأول: ${RAPID_TEST_QUESTIONS[0]}`
		}]);
		setTestUserStartTime(Date.now());
		setTestElapsedMs(0);
	};
	(0, import_react.useEffect)(() => {
		if (showLiveTest && testUserStartTime && !isPartnerTyping && testStep < 3) timerRef.current = setInterval(() => {
			setTestElapsedMs(Date.now() - testUserStartTime);
		}, 100);
		else if (timerRef.current) clearInterval(timerRef.current);
		return () => {
			if (timerRef.current) clearInterval(timerRef.current);
		};
	}, [
		showLiveTest,
		testUserStartTime,
		isPartnerTyping,
		testStep
	]);
	const handleSendTestMessage = (e) => {
		if (e) e.preventDefault();
		if (!testUserInput.trim() || !testUserStartTime) return;
		soundManager.playTap();
		const now = Date.now();
		const actualLatencyMs = Math.max(800, now - testUserStartTime);
		const actualLatencySec = Number((actualLatencyMs / 1e3).toFixed(1));
		const text = testUserInput.trim();
		const wordCount = text.split(/\s+/).filter(Boolean).length;
		const updatedMessages = [...testMessages, {
			sender: "user",
			text,
			latencySec: actualLatencySec
		}];
		setTestMessages(updatedMessages);
		setTestUserInput("");
		setTestUserStartTime(null);
		setIsPartnerTyping(true);
		const currentExchanges = loadSavedChatCadenceExchanges() || [];
		const newExchange = {
			sender: "user",
			timestampMs: now,
			messageLengthChars: text.length,
			wordCount,
			latencyFromPreviousMs: actualLatencyMs
		};
		const updatedExchanges = [...currentExchanges, newExchange];
		saveChatCadenceExchanges(updatedExchanges);
		const simulatedPartnerLatencyMs = 2100 + Math.floor(Math.random() * 900);
		setTimeout(() => {
			soundManager.playRoundPass();
			const pNow = Date.now();
			const pLatencySec = Number((simulatedPartnerLatencyMs / 1e3).toFixed(1));
			const pReply = RAPID_PARTNER_RESPONSES[testStep];
			const partnerExchange = {
				sender: "partner",
				timestampMs: pNow,
				messageLengthChars: pReply.length,
				wordCount: pReply.split(/\s+/).length,
				latencyFromPreviousMs: simulatedPartnerLatencyMs
			};
			const finalExchanges = [...updatedExchanges, partnerExchange];
			saveChatCadenceExchanges(finalExchanges);
			const nextStep = testStep + 1;
			setTestStep(nextStep);
			setIsPartnerTyping(false);
			if (nextStep < 3) {
				setTestMessages([...updatedMessages, {
					sender: "partner",
					text: `${pReply} السؤال التالي: ${RAPID_TEST_QUESTIONS[nextStep]}`,
					latencySec: pLatencySec
				}]);
				setTestUserStartTime(Date.now());
				setTestElapsedMs(0);
			} else {
				setTestMessages([...updatedMessages, {
					sender: "partner",
					text: `${pReply} اكتمل الاختبار الحقيقي بنجاح! تم احتساب متوسطات الاستجابة ومؤشر التزامن بدقة.`,
					latencySec: pLatencySec
				}]);
				const newMetrics = calculateCadenceMetrics(finalExchanges);
				setMetrics(newMetrics);
				requestAiAnalysis(newMetrics);
			}
		}, simulatedPartnerLatencyMs);
	};
	const avgCadence = (metrics.userAvgLatencySec + metrics.partnerAvgLatencySec) / 2;
	const needleAngle = Math.min(90, Math.max(-90, (avgCadence - 6) / 6 * 90));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "glass-panel rounded-3xl p-6 border border-amber-500/30 shadow-2xl relative overflow-hidden bg-gradient-to-b from-slate-950 via-slate-900 to-amber-950/20 text-white",
		dir: "rtl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-0 left-1/4 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute bottom-0 right-1/4 w-72 h-72 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3 mb-6 relative z-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-500/15 border border-amber-400/30 text-amber-300 text-xs font-bold shadow-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "w-4 h-4 text-amber-400 animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "حاسبة التوافق السريع • تحليل وتيرة الاستجابة في الدردشة" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800/80 border border-white/10 text-xs text-gray-300 font-medium",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gauge, { className: "w-3.5 h-3.5 text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "قياس زمني حقيقي بالميلي-ثانية" })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6 relative z-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-2xl sm:text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-orange-100 to-rose-300 font-['Alexandria'] mb-2",
					children: "مؤشر سرعة الاستجابة وكيمياء الحوار الفوري"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-gray-300 text-sm sm:text-base leading-relaxed max-w-3xl",
					children: [
						"أداة حسابية حقيقية تقيس سرعة الرد المتبادلة بينك وبين «",
						partnerName,
						"» في المحادثة، حيث يحلل الذكاء الاصطناعي تقارب الأزمنة كدليل قطعي على حضور البديهة، الشغف، وسلاسة التدفق الإدراكي."
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 lg:grid-cols-12 gap-6 items-center mb-6 relative z-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-5 flex flex-col items-center justify-center p-5 rounded-3xl bg-slate-900/90 border border-white/10 shadow-inner relative",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs text-amber-300 font-bold mb-2 flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gauge, { className: "w-4 h-4 text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "مؤشر سرعة الاستجابة البديهي (Speedometer)" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative w-64 h-36 flex items-center justify-center overflow-hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
								viewBox: "0 0 200 110",
								className: "w-full h-full",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
										d: "M 20 100 A 80 80 0 0 1 65 35",
										fill: "none",
										stroke: "#10b981",
										strokeWidth: "16",
										strokeLinecap: "round",
										className: "opacity-90"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
										d: "M 69 32 A 80 80 0 0 1 131 32",
										fill: "none",
										stroke: "#06b6d4",
										strokeWidth: "16",
										className: "opacity-90"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
										d: "M 135 35 A 80 80 0 0 1 180 100",
										fill: "none",
										stroke: "#f59e0b",
										strokeWidth: "16",
										strokeLinecap: "round",
										className: "opacity-90"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
										x: "24",
										y: "95",
										fill: "#9ca3af",
										fontSize: "9",
										fontWeight: "bold",
										children: "0s"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
										x: "60",
										y: "48",
										fill: "#9ca3af",
										fontSize: "8",
										children: "3.5s"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
										x: "100",
										y: "28",
										fill: "#9ca3af",
										fontSize: "8",
										textAnchor: "middle",
										children: "6s"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
										x: "135",
										y: "48",
										fill: "#9ca3af",
										fontSize: "8",
										children: "9s"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
										x: "175",
										y: "95",
										fill: "#9ca3af",
										fontSize: "9",
										textAnchor: "end",
										fontWeight: "bold",
										children: "12s+"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
										transform: `rotate(${needleAngle}, 100, 100)`,
										className: "transition-transform duration-700 ease-out",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
												points: "98,100 102,100 100,28",
												fill: "#ef4444"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
												cx: "100",
												cy: "100",
												r: "7",
												fill: "#ffffff"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
												cx: "100",
												cy: "100",
												r: "4",
												fill: "#ef4444"
											})
										]
									})
								]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center mt-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-baseline justify-center gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-3xl font-black text-amber-400 font-mono",
										children: avgCadence.toFixed(1)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-gray-400",
										children: "ثانية / استجابة"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "inline-block mt-1 px-3 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/30",
									children: metrics.speedTier.badge
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-gray-400 mt-2 max-w-xs text-center",
									children: metrics.speedTier.description
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-7 grid grid-cols-2 gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-2xl bg-white/5 border border-amber-500/30 hover:border-amber-400/50 transition-colors shadow-md",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center justify-between mb-1.5",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs text-gray-300 font-semibold flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timer, { className: "w-4 h-4 text-amber-400" }), "سرعة ردك الفعلية"]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-2xl font-black text-white font-mono mb-1",
									children: [
										metrics.userAvgLatencySec,
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-amber-400 font-normal",
											children: "ثانية"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-gray-400",
									children: "متوسط زمن كتابة وإرسال ردك"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-2xl bg-white/5 border border-rose-500/30 hover:border-rose-400/50 transition-colors shadow-md",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center justify-between mb-1.5",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs text-gray-300 font-semibold flex items-center gap-1.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "w-4 h-4 text-rose-400" }),
											"سرعة رد «",
											partnerName,
											"»"
										]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-2xl font-black text-rose-300 font-mono mb-1",
									children: [
										metrics.partnerAvgLatencySec,
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-rose-400 font-normal",
											children: "ثانية"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-gray-400",
									children: "استجابة فورية بدون انقطاع"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-2xl bg-white/5 border border-emerald-500/30 hover:border-emerald-400/50 transition-colors shadow-md",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center justify-between mb-1.5",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs text-gray-300 font-semibold flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "w-4 h-4 text-emerald-400" }), "معامل التزامن الإيقاعي"]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-2xl font-black text-emerald-400 font-mono mb-1",
									children: [metrics.synchronyScore, "%"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-gray-400",
									children: "تقارب الإيقاع وتوازن التفاعل"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-2xl bg-white/5 border border-cyan-500/30 hover:border-cyan-400/50 transition-colors shadow-md",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center justify-between mb-1.5",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs text-gray-300 font-semibold flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquare, { className: "w-4 h-4 text-cyan-400" }), "كثافة التدفق الحواري"]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-2xl font-black text-cyan-300 font-mono mb-1",
									children: [
										metrics.userWordsPerMinute,
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-cyan-400 font-normal",
											children: "ك/د"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-gray-400",
									children: "حيوية التعبير واستمرارية الفكرة"
								})
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-5 rounded-2xl bg-gradient-to-r from-slate-900/90 via-slate-950 to-amber-950/30 border border-amber-500/30 mb-6 relative z-10 shadow-lg",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-3 border-b border-white/10 pb-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center text-amber-300",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "w-5 h-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-sm font-bold text-white flex items-center gap-2",
								children: ["تحليل الذكاء الاصطناعي لكيمياء وسرعة الاستجابة", isLoadingAi && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "w-3.5 h-3.5 text-amber-400 animate-spin" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-amber-300/80",
								children: aiAnalysis.mutualEnthusiasmLevel
							})] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center gap-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-emerald-300 font-bold bg-emerald-500/15 px-3 py-1 rounded-full border border-emerald-500/30",
								children: [
									"توافق إيقاعي: ",
									aiAnalysis.responseHarmonyRating,
									"%"
								]
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3 text-xs sm:text-sm leading-relaxed text-gray-200",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-gray-100 font-medium",
								children: aiAnalysis.conversationalChemistrySummary
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3 rounded-xl bg-white/5 border border-white/5 text-gray-300 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold text-amber-300",
									children: "الدلالة السيكولوجية لسرعة الرد: "
								}), aiAnalysis.cadenceInterpretation]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3 rounded-xl bg-amber-950/20 border border-amber-500/20 text-xs text-amber-200",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold text-amber-300",
									children: "علم النفس المعرفي (Cyberpsychology): "
								}), aiAnalysis.cognitivePaceInsight]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 pt-3 border-t border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-gray-400 flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lightbulb, { className: "w-4 h-4 text-amber-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["نصيحة الحوار: ", aiAnalysis.actionableTip] })]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3 relative z-10 pt-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: startLiveCadenceTest,
							className: "px-4 py-2.5 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-bold text-xs sm:text-sm hover:from-amber-400 hover:to-orange-400 transition-all shadow-lg shadow-amber-500/20 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: showLiveTest ? "إعادة تشغيل اختبار السرعة المباشر" : "بدء اختبار سرعة الاستجابة المباشر الآن (3 أسئلة)" })]
						}),
						onOpenBlindDate && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundManager.playTap();
								onOpenBlindDate();
							},
							className: "px-3.5 py-2.5 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 text-gray-200 text-xs font-semibold transition-colors flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquare, { className: "w-3.5 h-3.5 text-rose-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "فتح دردشة The Blind Date Show" })]
						}),
						onOpenLiveChat && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundManager.playTap();
								onOpenLiveChat();
							},
							className: "px-3.5 py-2.5 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 text-gray-200 text-xs font-semibold transition-colors flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "w-3.5 h-3.5 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "رادار المتواجدين (دردشة حية)" })]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => {
						soundManager.playTap();
						setShowDetails(!showDetails);
					},
					className: "text-xs text-amber-300 hover:text-amber-200 flex items-center gap-1 font-medium transition-colors",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: showDetails ? "إخفاء المعايير العلمية" : "كيف نقيس السرعة بالأرقام الحقيقية؟" }), showDetails ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "w-3.5 h-3.5" })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: showLiveTest && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				initial: {
					opacity: 0,
					height: 0
				},
				animate: {
					opacity: 1,
					height: "auto"
				},
				exit: {
					opacity: 0,
					height: 0
				},
				transition: { duration: .3 },
				className: "mt-6 pt-6 border-t border-white/10 relative z-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-5 rounded-2xl bg-slate-900 border border-amber-500/40 shadow-xl space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between border-b border-white/10 pb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-3 h-3 rounded-full bg-emerald-400 animate-ping" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-sm font-bold text-white",
									children: [
										"مختبر قياس السرعة المباشر (المرحلة ",
										Math.min(3, testStep + 1),
										" من 3)"
									]
								})]
							}), testUserStartTime && !isPartnerTyping && testStep < 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 bg-amber-500/20 px-3 py-1 rounded-full text-xs font-mono font-bold text-amber-300 border border-amber-500/30",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timer, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"عداد الوقت الفعلي: ",
									(testElapsedMs / 1e3).toFixed(1),
									" ثانية"
								] })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3 max-h-64 overflow-y-auto pr-1",
							children: [testMessages.map((msg, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `flex flex-col ${msg.sender === "user" ? "items-start text-right" : "items-end text-right"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `max-w-[85%] p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed ${msg.sender === "user" ? "bg-amber-500 text-slate-950 font-medium rounded-tr-none" : "bg-white/10 text-white rounded-tl-none border border-white/10"}`,
									children: msg.text
								}), msg.latencySec !== void 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[10px] text-gray-400 mt-1 px-1 font-mono",
									children: [
										"زمن الاستجابة: ",
										msg.latencySec,
										" ثانية"
									]
								})]
							}, i)), isPartnerTyping && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 text-xs text-rose-300 py-1 font-medium animate-pulse",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-2 h-2 rounded-full bg-rose-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"«",
									partnerName,
									"» يكتب الرد الآن..."
								] })]
							})]
						}),
						testStep < 3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit: handleSendTestMessage,
							className: "flex items-center gap-2 pt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								value: testUserInput,
								onChange: (e) => setTestUserInput(e.target.value),
								placeholder: "اكتب ردك العفوي هنا فوراً واضغط إرسال...",
								disabled: isPartnerTyping,
								className: "flex-1 px-4 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-xs sm:text-sm focus:outline-none focus:border-amber-400 disabled:opacity-50"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "submit",
								disabled: !testUserInput.trim() || isPartnerTyping,
								className: "px-4 py-2.5 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs sm:text-sm hover:bg-amber-400 transition-colors disabled:opacity-40 flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "إرسال" })]
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-3 rounded-xl bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 text-xs flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold",
								children: "✓ اكتمل الاختبار بنجاح! تم تحديث المؤشر البديهي وقراءة السرعة أعلاه."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: startLiveCadenceTest,
								className: "px-3 py-1 rounded-lg bg-emerald-500 text-slate-950 font-bold hover:bg-emerald-400 text-[11px]",
								children: "إعادة الاختبار"
							})]
						})
					]
				})
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: showDetails && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				initial: {
					opacity: 0,
					height: 0
				},
				animate: {
					opacity: 1,
					height: "auto"
				},
				exit: {
					opacity: 0,
					height: 0
				},
				transition: { duration: .2 },
				className: "mt-6 pt-4 border-t border-white/10 space-y-3 text-xs text-gray-300 relative z-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-bold text-amber-300 text-sm",
						children: "كيف تقيس الحاسبة سرعة الاستجابة بالأرقام الحقيقية؟"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "space-y-1.5 list-disc list-inside text-gray-300",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "text-white",
								children: "التسجيل الميلي-ثانية (High-Precision Timestamping):"
							}), " يتم حساب الفارق الزمني الفعلي بين لحظة وصول رسالة الطرف الأول ولحظة ضغط زر الإرسال من الطرف الثاني بدقة (`performance.now`)."] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "text-white",
								children: "معامل التزامن الإيقاعي (Synchrony Ratio):"
							}), " تحسب الخوارزمية نسبة التماثل بين السرعتين؛ التباين المنخفض (أقل من ثانية واحدة) يمنح مؤشر تزامن يفوق 90%."] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "text-white",
								children: "استبعاد التأخيرات غير التفاعلية:"
							}), " في حال ترك الشاشة، يتم تحديد فترات التوقف التلقائي لمنع تشويه القياس اللحظي."] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "text-white",
								children: "تحليل الذكاء الاصطناعي:"
							}), " يُزوّد الذكاء الاصطناعي بالأرقام الحقيقية المقاسة لربطها بخصائص الشخصية وتفسير لغة الجسد الرقمية."] })
						]
					})]
				})
			}) })
		]
	});
};
//#endregion
//#region src/components/PrivacySettingsModal.tsx
var PrivacySettingsModal = ({ isOpen, onClose, onPinConfigured }) => {
	const currentEnabled = isPinLockEnabled();
	const [newPin, setNewPin] = (0, import_react.useState)("");
	const [confirmPin, setConfirmPin] = (0, import_react.useState)("");
	const [showPinText, setShowPinText] = (0, import_react.useState)(false);
	const [errorMsg, setErrorMsg] = (0, import_react.useState)(null);
	const [successMsg, setSuccessMsg] = (0, import_react.useState)(null);
	if (!isOpen) return null;
	const handleSavePin = (e) => {
		e.preventDefault();
		setErrorMsg(null);
		if (!/^\d{4}$/.test(newPin)) {
			setErrorMsg("يجب أن يتكون رمز الأمان من 4 أرقام بالضبط");
			return;
		}
		if (newPin !== confirmPin) {
			setErrorMsg("رمزا الأمان غير متطابقين، يرجى التأكد");
			return;
		}
		soundManager.playResultReveal();
		setPinLock(newPin);
		setSuccessMsg("تم تفعيل وحفظ رمز الأمان بنجاح! 🔒");
		setTimeout(() => {
			onPinConfigured(false);
			onClose();
		}, 1200);
	};
	const handleDisablePin = () => {
		soundManager.playTap();
		disablePinLock();
		setSuccessMsg("تم إيقاف قفل الأمان لصفحة النتائج 🔓");
		setTimeout(() => {
			onPinConfigured(false);
			onClose();
		}, 1e3);
	};
	const handleLockNow = () => {
		soundManager.playTap();
		onPinConfigured(true);
		onClose();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: {
				scale: .92,
				opacity: 0
			},
			animate: {
				scale: 1,
				opacity: 1
			},
			exit: {
				scale: .92,
				opacity: 0
			},
			className: "w-full max-w-md glass-panel rounded-3xl p-6 border border-white/20 relative shadow-2xl overflow-hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -top-16 -right-16 w-44 h-44 bg-rose-500/20 rounded-full blur-3xl pointer-events-none" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -bottom-16 -left-16 w-44 h-44 bg-violet-600/20 rounded-full blur-3xl pointer-events-none" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between pb-4 border-b border-white/10 mb-4 relative z-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-10 h-10 rounded-2xl bg-gradient-to-tr from-rose-500 to-violet-600 flex items-center justify-center text-white shadow-md shadow-rose-500/20",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "w-5 h-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-extrabold text-base sm:text-lg text-white font-['Alexandria']",
							children: "إعدادات قفل الأمان والخصوصية"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-gray-300",
							children: "حماية صفحة النتائج برمز دخول PIN مكون من 4 أرقام"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onClose,
						"aria-label": "إغلاق إعدادات الخصوصية",
						title: "إغلاق",
						className: "p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition cursor-pointer",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-5 h-5" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-3.5 rounded-2xl bg-black/40 border border-white/10 mb-4 flex items-center justify-between relative z-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [currentEnabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "w-5 h-5 text-emerald-400" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockOpen, { className: "w-5 h-5 text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs font-bold text-white",
							children: ["حالة القفل: ", currentEnabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-emerald-400 font-extrabold",
								children: "مُفـعّـل 🔒"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-amber-300 font-medium",
								children: "غير مُفعل 🔓"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] text-gray-400",
							children: currentEnabled ? "يطلب التطبيق الرمز عند محاولة فتح صفحة النتيجة" : "يمكن لأي شخص يفتح المتصفح رؤية النتيجة"
						})] })]
					}), currentEnabled && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
						whileHover: { scale: 1.05 },
						whileTap: { scale: .95 },
						onClick: handleLockNow,
						className: "px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 text-xs font-bold transition cursor-pointer flex items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "قفل الآن" })]
					})]
				}),
				successMsg && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-3 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs text-center font-bold mb-4 flex items-center justify-center gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: successMsg })]
				}),
				errorMsg && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-3 rounded-2xl bg-rose-500/20 border border-rose-500/30 text-rose-300 text-xs text-center font-bold mb-4 flex items-center justify-center gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: errorMsg })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handleSavePin,
					className: "space-y-3 relative z-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-bold text-gray-300 mb-1",
							children: currentEnabled ? "تعيين رمز مرور جديد (4 أرقام):" : "أدخل رمز المرور المكون من 4 أرقام:"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: showPinText ? "text" : "password",
								inputMode: "numeric",
								pattern: "[0-9]*",
								maxLength: 4,
								value: newPin,
								onChange: (e) => {
									const val = e.target.value.replace(/\D/g, "").slice(0, 4);
									setNewPin(val);
								},
								placeholder: "••••",
								className: "w-full px-4 py-2.5 rounded-xl bg-white/5 border border-white/15 focus:border-rose-400 focus:outline-none text-white text-center text-lg tracking-widest font-mono"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setShowPinText(!showPinText),
								className: "absolute left-3 top-3 text-gray-400 hover:text-white",
								children: showPinText ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "w-4 h-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "w-4 h-4" })
							})]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-bold text-gray-300 mb-1",
							children: "تأكيد رمز المرور (أعد كتابته):"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: showPinText ? "text" : "password",
							inputMode: "numeric",
							pattern: "[0-9]*",
							maxLength: 4,
							value: confirmPin,
							onChange: (e) => {
								const val = e.target.value.replace(/\D/g, "").slice(0, 4);
								setConfirmPin(val);
							},
							placeholder: "••••",
							className: "w-full px-4 py-2.5 rounded-xl bg-white/5 border border-white/15 focus:border-rose-400 focus:outline-none text-white text-center text-lg tracking-widest font-mono"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pt-2 flex flex-col sm:flex-row gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
								whileHover: { scale: 1.02 },
								whileTap: { scale: .98 },
								type: "submit",
								disabled: newPin.length !== 4 || confirmPin.length !== 4,
								className: "flex-1 py-3 rounded-2xl bg-gradient-to-r from-rose-500 to-purple-600 hover:opacity-95 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-rose-500/25 transition cursor-pointer disabled:opacity-40",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: currentEnabled ? "تحديث وحفظ الرمز" : "تفعيل قفل الأمان" })]
							}), currentEnabled && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
								whileHover: { scale: 1.02 },
								whileTap: { scale: .98 },
								type: "button",
								onClick: handleDisablePin,
								className: "py-3 px-4 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 text-gray-300 hover:text-rose-300 font-medium text-xs transition cursor-pointer",
								children: "إيقاف القفل"
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[10px] text-gray-400 text-center mt-4",
					children: "💡 يتم حفظ رمز المرور محلياً وبشكل آمن على جهازك فقط لحماية خصوصية نتائجك."
				})
			]
		})
	});
};
//#endregion
//#region src/components/RealCalculationAuditModal.tsx
var RealCalculationAuditModal = ({ isOpen, onClose, scoringBreakdown, partnerName }) => {
	const [expandedDimension, setExpandedDimension] = (0, import_react.useState)("intellectual");
	if (!isOpen || !scoringBreakdown) return null;
	const { compatibilityScore, intellectualScore, sociologicalScore, emotionalScore, lifestyleScore, details, scientificSubscales = [], algorithmVersion, auditHash } = scoringBreakdown;
	const toggleDimension = (key) => {
		soundManager.playTab();
		setExpandedDimension((prev) => prev === key ? null : key);
	};
	const handleExportAuditPdf = async () => {
		soundManager.playTap();
		const { exportPsychometricReportAsPDF } = await __vitePreload(async () => {
			const { exportPsychometricReportAsPDF } = await import("./pdfReportGenerator-BNu3pVmt.js");
			return { exportPsychometricReportAsPDF };
		}, __vite__mapDeps([0,1,2,3,4,5,6,7,8,9]));
		exportPsychometricReportAsPDF({
			reportTitle: `تقرير التدقيق السيكومتري للتوافق الزواجي (25 محوراً علمياً)`,
			subTitle: `تحليل التوافق الرياضي الموزون مع الشريك المقترح «${partnerName}»`,
			scientificBasis: "Gottman (1999), Bowlby & Ainsworth (ECR-R), Sternberg (1986), Bowen Family Systems, Schwartz Values, Brad Klontz Financial Psychology",
			completedAt: (/* @__PURE__ */ new Date()).toLocaleDateString("ar-JO"),
			overallScoreLabel: "معدل التوافق الكلي الموزون",
			overallScoreValue: `${compatibilityScore}%`,
			cognitiveFingerprintTitle: `البصمة السيكومترية للتوافق (${auditHash})`,
			executiveSummary: `تم احتساب هذا التقرير بناءً على 25 سؤالاً علمياً تقيس الأبعاد الأربعة الكبرى للتوافق الزواجي بأوزان إحصائية مثبتة: الأمان العاطفي وإصلاح الخلاف (${emotionalScore}% بوزن 32%)، التوافق الفكري والشورى (${intellectualScore}% بوزن 28%)، الأنساق الأسرية والمنظومة القيمية (${sociologicalScore}% بوزن 22%)، وعلم النفس المالي وإيقاع الحياة (${lifestyleScore}% بوزن 18%).`,
			metrics: [
				{
					label: "الذكاء الوجداني والتعلق الآمن (وزن 32%)",
					scorePercent: emotionalScore,
					rawText: `${details.emotional.rawPoints}/${details.emotional.maxPoints}`,
					color: "#e11d48"
				},
				{
					label: "التوافق الفكري والقرارات المشتركة (وزن 28%)",
					scorePercent: intellectualScore,
					rawText: `${details.intellectual.rawPoints}/${details.intellectual.maxPoints}`,
					color: "#0284c7"
				},
				{
					label: "الأنساق الأسرية والقيم التربوية (وزن 22%)",
					scorePercent: sociologicalScore,
					rawText: `${details.sociological.rawPoints}/${details.sociological.maxPoints}`,
					color: "#7c3aed"
				},
				{
					label: "علم النفس المالي ونمط الحياة (وزن 18%)",
					scorePercent: lifestyleScore,
					rawText: `${details.lifestyle.rawPoints}/${details.lifestyle.maxPoints}`,
					color: "#d97706"
				},
				...scientificSubscales.map((sub) => ({
					label: sub.titleAr,
					scorePercent: sub.score,
					levelLabel: sub.scientistAr.split("(")[0].trim(),
					color: "#059669"
				}))
			],
			sections: [
				{
					title: details.emotional.dimensionNameAr,
					badge: `${emotionalScore}% • مساهمة +${details.emotional.weightedContribution}%`,
					content: details.emotional.scientificReasoningAr,
					items: details.emotional.primaryAnswers
				},
				{
					title: details.intellectual.dimensionNameAr,
					badge: `${intellectualScore}% • مساهمة +${details.intellectual.weightedContribution}%`,
					content: details.intellectual.scientificReasoningAr,
					items: details.intellectual.primaryAnswers
				},
				{
					title: details.sociological.dimensionNameAr,
					badge: `${sociologicalScore}% • مساهمة +${details.sociological.weightedContribution}%`,
					content: details.sociological.scientificReasoningAr,
					items: details.sociological.primaryAnswers
				},
				{
					title: details.lifestyle.dimensionNameAr,
					badge: `${lifestyleScore}% • مساهمة +${details.lifestyle.weightedContribution}%`,
					content: details.lifestyle.scientificReasoningAr,
					items: details.lifestyle.primaryAnswers
				},
				...scientificSubscales.map((sub) => ({
					title: `${sub.titleAr} (${sub.scientistAr})`,
					badge: `${sub.score}%`,
					content: sub.analysisAr,
					items: [`الأسئلة العلمية المحسوبة في هذا المقياس: ${sub.questionsUsed.map((q) => `س${q}`).join("، ")}`]
				}))
			]
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-xl overflow-y-auto",
		dir: "rtl",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: {
				opacity: 0,
				scale: .94,
				y: 20
			},
			animate: {
				opacity: 1,
				scale: 1,
				y: 0
			},
			exit: {
				opacity: 0,
				scale: .94,
				y: 20
			},
			className: "relative w-full max-w-3xl my-6 bg-gradient-to-b from-[#18112e] via-[#100a20] to-[#0a0714] border border-emerald-500/30 rounded-3xl p-5 sm:p-7 shadow-2xl text-white overflow-hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3 pb-4 border-b border-white/10 relative z-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-600 flex items-center justify-center text-white shadow-lg shadow-emerald-500/20 shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calculator, { className: "w-6 h-6 text-white" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 flex-wrap",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-lg sm:text-xl font-black font-['Alexandria'] text-white",
								children: "لوحة التدقيق السيكومتري والمقاييس العلمية المعتمدة (25 سؤالاً)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-[10px] text-emerald-300 font-extrabold flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "w-3 h-3 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "قياس علمي موثق" })]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-gray-300 mt-0.5",
							children: "تقييم حقيقي مبني على 6 نظريات علمية محكمة في علم النفس الزواجي والاجتماعي دون أي أرقام عشوائية"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: handleExportAuditPdf,
							className: "px-3 py-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-400/40 text-emerald-200 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer",
							title: "تحميل التقرير السيكومتري الشامل PDF",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileDown, { className: "w-4 h-4 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline",
								children: "تقرير PDF"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								soundManager.playTap();
								onClose();
							},
							className: "p-2 rounded-xl bg-white/10 hover:bg-white/20 text-gray-300 hover:text-white transition cursor-pointer",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-5 h-5" })
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-5 my-4 relative z-10 max-h-[70vh] overflow-y-auto pr-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-2xl bg-emerald-950/30 border border-emerald-500/30 flex flex-col sm:flex-row items-center justify-between gap-3 text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 text-emerald-300 font-bold text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheck2, { className: "w-4 h-4 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "شهادة التوثيق الحسابي (25-Item Psychometric Audit):" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-gray-300 leading-relaxed",
										children: "تم احتساب كل نسبة مئوية في تقريرك استناداً إلى إجاباتك الفعلية على 25 محوراً علمياً وفق نماذج (Gottman, Bowlby/ECR-R, Sternberg, Bowen, Schwartz, Klontz)."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center gap-2 pt-1 font-mono text-[11px] text-emerald-400/80",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["المعرف: ", auditHash] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["النسخة: ", algorithmVersion] })
										]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3.5 rounded-2xl bg-black/50 border border-emerald-400/30 text-center shrink-0 min-w-[130px]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[10px] text-gray-300 font-medium",
										children: "معدل التوافق العلمي"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-3xl font-black text-emerald-400 font-['Alexandria']",
										children: [compatibilityScore, "%"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-[10px] text-emerald-300/80 mt-0.5",
										children: [
											"مع «",
											partnerName,
											"»"
										]
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 text-rose-300 font-bold text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-4 h-4 text-rose-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "المعادلة الرياضية الموزونة وفق دراسات استقرار الزواج:" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-gray-300 leading-relaxed",
									children: "يتم احتساب الدرجة الكلية بدمج المحاور الأربعة الكبرى حسب وزنها التنبؤي باستقرار العلاقة طويل الأمد:"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "p-3 rounded-xl bg-black/60 border border-white/10 font-mono text-xs sm:text-sm text-center text-amber-300 font-bold overflow-x-auto",
									dir: "ltr",
									children: "Total = (Emotional × 32%) + (Intellectual × 28%) + (Sociological × 22%) + (Lifestyle × 18%)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[11px] text-gray-400 text-center",
									dir: "rtl",
									children: [
										"الحساب الفعلي لحالتك: (",
										emotionalScore,
										" × 0.32) + (",
										intellectualScore,
										" × 0.28) + (",
										sociologicalScore,
										" × 0.22) + (",
										lifestyleScore,
										" × 0.18) = ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
											className: "text-emerald-400",
											children: [compatibilityScore, "%"]
										})
									]
								})
							]
						}),
						scientificSubscales.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
								className: "text-sm font-bold text-emerald-300 flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "w-4 h-4 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "نتائج المقاييس العلمية الستة المحكّمة:" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
								children: scientificSubscales.map((sub) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3.5 rounded-2xl bg-slate-900/90 border border-slate-700/80 space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-start justify-between gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-xs font-extrabold text-white",
												children: sub.titleAr
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[10px] text-emerald-300 font-medium mt-0.5",
												children: sub.scientistAr
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-base font-black text-emerald-400 font-mono shrink-0",
												children: [sub.score, "%"]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-full h-1.5 bg-slate-800 rounded-full overflow-hidden",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "h-full bg-gradient-to-l from-emerald-500 to-teal-400 rounded-full",
												style: { width: `${sub.score}%` }
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] text-slate-300 leading-relaxed",
											children: sub.analysisAr
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-[10px] text-slate-400 font-mono",
											children: ["الأسئلة المحسوبة: ", sub.questionsUsed.map((q) => `س${q}`).join(" • ")]
										})
									]
								}, sub.id))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
									className: "text-sm font-bold text-gray-200 flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "w-4 h-4 text-sky-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تفاصيل احتساب النقاط لكل بعد من إجاباتك الفعلية:" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-2xl bg-white/5 border border-sky-500/20 overflow-hidden",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => toggleDimension("intellectual"),
										className: "w-full p-3.5 flex items-center justify-between text-right hover:bg-white/5 transition cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "w-8 h-8 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "w-4 h-4" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "font-bold text-sm text-white",
												children: details.intellectual.dimensionNameAr
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-[11px] text-gray-400",
												children: [
													"الوزن: 28% • النقاط الخام: ",
													details.intellectual.rawPoints,
													"/",
													details.intellectual.maxPoints,
													" • المساهمة: +",
													details.intellectual.weightedContribution,
													"%"
												]
											})] })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-black text-lg text-sky-400 font-['Alexandria']",
												children: [intellectualScore, "%"]
											}), expandedDimension === "intellectual" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "w-4 h-4 text-gray-400" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "w-4 h-4 text-gray-400" })]
										})]
									}), expandedDimension === "intellectual" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-4 pt-1 bg-black/30 border-t border-sky-500/10 space-y-2 text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-gray-300",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "الإجابات التي تم قياس البعد منها:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
												className: "list-disc list-inside mt-1 space-y-0.5 text-gray-400",
												children: details.intellectual.primaryAnswers.map((ans, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: ans }, idx))
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-2.5 rounded-xl bg-sky-950/30 border border-sky-500/20 text-sky-200",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "التحليل السيكومتري:" }),
												" ",
												details.intellectual.scientificReasoningAr
											]
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-2xl bg-white/5 border border-rose-500/20 overflow-hidden",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => toggleDimension("emotional"),
										className: "w-full p-3.5 flex items-center justify-between text-right hover:bg-white/5 transition cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "w-8 h-8 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "w-4 h-4" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "font-bold text-sm text-white",
												children: details.emotional.dimensionNameAr
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-[11px] text-gray-400",
												children: [
													"الوزن: 32% (الأعلى تأثيراً) • النقاط الخام: ",
													details.emotional.rawPoints,
													"/",
													details.emotional.maxPoints,
													" • المساهمة: +",
													details.emotional.weightedContribution,
													"%"
												]
											})] })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-black text-lg text-rose-400 font-['Alexandria']",
												children: [emotionalScore, "%"]
											}), expandedDimension === "emotional" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "w-4 h-4 text-gray-400" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "w-4 h-4 text-gray-400" })]
										})]
									}), expandedDimension === "emotional" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-4 pt-1 bg-black/30 border-t border-rose-500/10 space-y-2 text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-gray-300",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "الإجابات التي تم قياس البعد منها:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
												className: "list-disc list-inside mt-1 space-y-0.5 text-gray-400",
												children: details.emotional.primaryAnswers.map((ans, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: ans }, idx))
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-2.5 rounded-xl bg-rose-950/30 border border-rose-500/20 text-rose-200",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "التحليل السيكومتري:" }),
												" ",
												details.emotional.scientificReasoningAr
											]
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-2xl bg-white/5 border border-violet-500/20 overflow-hidden",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => toggleDimension("sociological"),
										className: "w-full p-3.5 flex items-center justify-between text-right hover:bg-white/5 transition cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "w-8 h-8 rounded-xl bg-violet-500/20 text-violet-400 flex items-center justify-center",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "w-4 h-4" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "font-bold text-sm text-white",
												children: details.sociological.dimensionNameAr
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-[11px] text-gray-400",
												children: [
													"الوزن: 22% • النقاط الخام: ",
													details.sociological.rawPoints,
													"/",
													details.sociological.maxPoints,
													" • المساهمة: +",
													details.sociological.weightedContribution,
													"%"
												]
											})] })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-black text-lg text-violet-400 font-['Alexandria']",
												children: [sociologicalScore, "%"]
											}), expandedDimension === "sociological" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "w-4 h-4 text-gray-400" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "w-4 h-4 text-gray-400" })]
										})]
									}), expandedDimension === "sociological" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-4 pt-1 bg-black/30 border-t border-violet-500/10 space-y-2 text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-gray-300",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "الإجابات التي تم قياس البعد منها:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
												className: "list-disc list-inside mt-1 space-y-0.5 text-gray-400",
												children: details.sociological.primaryAnswers.map((ans, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: ans }, idx))
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-2.5 rounded-xl bg-violet-950/30 border border-violet-500/20 text-violet-200",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "التحليل السيكومتري:" }),
												" ",
												details.sociological.scientificReasoningAr
											]
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-2xl bg-white/5 border border-amber-500/20 overflow-hidden",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => toggleDimension("lifestyle"),
										className: "w-full p-3.5 flex items-center justify-between text-right hover:bg-white/5 transition cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, { className: "w-4 h-4" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "font-bold text-sm text-white",
												children: details.lifestyle.dimensionNameAr
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-[11px] text-gray-400",
												children: [
													"الوزن: 18% • النقاط الخام: ",
													details.lifestyle.rawPoints,
													"/",
													details.lifestyle.maxPoints,
													" • المساهمة: +",
													details.lifestyle.weightedContribution,
													"%"
												]
											})] })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-black text-lg text-amber-400 font-['Alexandria']",
												children: [lifestyleScore, "%"]
											}), expandedDimension === "lifestyle" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "w-4 h-4 text-gray-400" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "w-4 h-4 text-gray-400" })]
										})]
									}), expandedDimension === "lifestyle" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-4 pt-1 bg-black/30 border-t border-amber-500/10 space-y-2 text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-gray-300",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "الإجابات التي تم قياس البعد منها:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
												className: "list-disc list-inside mt-1 space-y-0.5 text-gray-400",
												children: details.lifestyle.primaryAnswers.map((ans, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: ans }, idx))
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-2.5 rounded-xl bg-amber-950/30 border border-amber-500/20 text-amber-200",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "التحليل السيكومتري:" }),
												" ",
												details.lifestyle.scientificReasoningAr
											]
										})]
									})]
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pt-4 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-gray-400 relative z-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-4 h-4 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "معدل الأرقام يخضع لمعايير المصداقية الإحصائية ولا يعتمد على أرقام عشوائية." })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: handleExportAuditPdf,
							className: "px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 border border-white/20 text-white font-bold transition cursor-pointer flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileDown, { className: "w-4 h-4 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تحميل التقرير PDF" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								soundManager.playTap();
								onClose();
							},
							className: "px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-bold transition cursor-pointer shadow-lg shadow-emerald-500/20",
							children: "إغلاق اللوحة"
						})]
					})]
				})
			]
		})
	}) });
};
//#endregion
//#region src/components/CompatibilityFlipCard.tsx
var THEME_STYLES = {
	sky: {
		border: "border-sky-500/30 hover:border-sky-400/50",
		scoreText: "text-sky-400",
		badgeBg: "bg-sky-500/15 text-sky-300 border-sky-500/30",
		frontGradient: "from-sky-500/10 via-transparent to-transparent",
		backGradient: "from-sky-950/40 via-[#141829]/95 to-[#0f111f]/95",
		backGradientLight: "from-sky-50 via-white to-sky-50/80",
		iconColor: "text-sky-400",
		glowShadow: "shadow-sky-500/10",
		adviceBg: "bg-sky-500/10 border-sky-500/20 text-sky-200"
	},
	violet: {
		border: "border-violet-500/30 hover:border-violet-400/50",
		scoreText: "text-violet-400",
		badgeBg: "bg-violet-500/15 text-violet-300 border-violet-500/30",
		frontGradient: "from-violet-500/10 via-transparent to-transparent",
		backGradient: "from-violet-950/40 via-[#1a1229]/95 to-[#120d20]/95",
		backGradientLight: "from-violet-50 via-white to-purple-50/80",
		iconColor: "text-violet-400",
		glowShadow: "shadow-violet-500/10",
		adviceBg: "bg-violet-500/10 border-violet-500/20 text-violet-200"
	},
	rose: {
		border: "border-rose-500/30 hover:border-rose-400/50",
		scoreText: "text-rose-400",
		badgeBg: "bg-rose-500/15 text-rose-300 border-rose-500/30",
		frontGradient: "from-rose-500/10 via-transparent to-transparent",
		backGradient: "from-rose-950/40 via-[#22101e]/95 to-[#150a14]/95",
		backGradientLight: "from-rose-50 via-white to-pink-50/80",
		iconColor: "text-rose-400",
		glowShadow: "shadow-rose-500/10",
		adviceBg: "bg-rose-500/10 border-rose-500/20 text-rose-200"
	},
	amber: {
		border: "border-amber-500/30 hover:border-amber-400/50",
		scoreText: "text-amber-400",
		badgeBg: "bg-amber-500/15 text-amber-300 border-amber-500/30",
		frontGradient: "from-amber-500/10 via-transparent to-transparent",
		backGradient: "from-amber-950/40 via-[#241710]/95 to-[#150e09]/95",
		backGradientLight: "from-amber-50 via-white to-yellow-50/80",
		iconColor: "text-amber-400",
		glowShadow: "shadow-amber-500/10",
		adviceBg: "bg-amber-500/10 border-amber-500/20 text-amber-200"
	}
};
var CompatibilityFlipCard = ({ data, isFlipped, onToggleFlip }) => {
	const styles = THEME_STYLES[data.themeColor];
	const handleClick = (e) => {
		e.stopPropagation();
		soundManager.playTap();
		onToggleFlip();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		onClick: handleClick,
		className: "group cursor-pointer select-none relative w-full h-[220px] sm:h-[235px]",
		style: { perspective: 1200 },
		role: "button",
		tabIndex: 0,
		onKeyDown: (e) => {
			if (e.key === "Enter" || e.key === " ") {
				e.preventDefault();
				handleClick(e);
			}
		},
		"aria-label": `${data.title}: ${data.score}%. انقر لقلب البطاقة وقراءة التحليل والنصيحة`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			animate: { rotateY: isFlipped ? 180 : 0 },
			transition: {
				duration: .6,
				ease: [
					.23,
					1,
					.32,
					1
				]
			},
			style: { transformStyle: "preserve-3d" },
			className: "w-full h-full relative",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					backfaceVisibility: "hidden",
					WebkitBackfaceVisibility: "hidden"
				},
				className: `absolute inset-0 w-full h-full rounded-2xl p-3.5 flex flex-col justify-between border bg-gradient-to-b ${styles.frontGradient} bg-white/5 backdrop-blur-md shadow-lg ${styles.glowShadow} ${styles.border} transition-all duration-300 group-hover:scale-[1.02] group-hover:shadow-xl`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1.5 text-xs font-bold text-gray-200",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `p-1.5 rounded-xl bg-white/5 border border-white/10 ${styles.iconColor}`,
								children: data.icon
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate",
								children: data.title
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
							whileHover: { rotate: 180 },
							transition: { duration: .3 },
							className: "p-1 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-gray-400 group-hover:text-white transition",
							title: "انقر لقلب البطاقة",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCw, { className: "w-3 h-3" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center my-auto py-1 space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `text-3xl sm:text-4xl font-black ${styles.scoreText} font-['Alexandria'] tracking-tight drop-shadow-sm`,
							children: [data.score, "%"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-gray-300 font-medium leading-tight px-1",
							children: data.subtitle
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pt-2 border-t border-white/10 flex items-center justify-between text-[10px] text-gray-400 group-hover:text-gray-200 transition",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-2.5 h-2.5 text-rose-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تحليل ونصح معمّق" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1 font-semibold text-rose-400/90 group-hover:text-rose-300",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "اقلب البطاقة" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCw, { className: "w-2.5 h-2.5 group-hover:rotate-45 transition-transform" })]
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					backfaceVisibility: "hidden",
					WebkitBackfaceVisibility: "hidden",
					transform: "rotateY(180deg)"
				},
				className: `absolute inset-0 w-full h-full rounded-2xl p-3 flex flex-col justify-between border bg-gradient-to-b ${styles.backGradient} backdrop-blur-xl shadow-2xl ${styles.glowShadow} ${styles.border} text-right overflow-hidden`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-1.5 pb-1.5 border-b border-white/10 shrink-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `w-2 h-2 rounded-full ${styles.scoreText} bg-current` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] font-extrabold text-white",
								children: data.categoryNameAr
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: handleClick,
							className: "flex items-center gap-1 text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-white/10 hover:bg-white/20 text-gray-200 transition cursor-pointer",
							title: "إعادة للواجهة",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "الواجهة" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCw, { className: "w-2.5 h-2.5" })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 overflow-y-auto my-1.5 pr-0.5 space-y-1.5 text-right custom-scrollbar",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-0.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-[10px] font-bold text-gray-300 flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-2.5 h-2.5 text-emerald-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "التحليل الواقعي:" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10.5px] leading-relaxed text-gray-200 font-normal",
								children: data.deepAnalysis
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `p-2 rounded-xl border text-[10px] leading-relaxed ${styles.adviceBg}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "font-bold flex items-center gap-1 mb-0.5 text-amber-300",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lightbulb, { className: "w-2.5 h-2.5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "نصيحة ذهبية للطرفين:" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-gray-100 font-medium",
								children: data.goldenAdvice
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pt-1.5 border-t border-white/10 flex items-center justify-between text-[9px] text-gray-400 shrink-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center gap-1 overflow-hidden",
							children: data.tags.slice(0, 2).map((t, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "px-1.5 py-0.5 rounded bg-white/5 border border-white/10 truncate",
								children: t
							}, idx))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-gray-400 text-[9px] shrink-0 font-medium",
							children: "اضغط للقلب ↩️"
						})]
					})
				]
			})]
		})
	});
};
//#endregion
//#region src/components/SmartRecommendationsSection.tsx
var SmartRecommendationsSection = ({ result, profile, onOpenPsychologyTests, onOpenIntelligenceTests, onOpenArticles, onOpenNovels }) => {
	const intellectualScore = result.intellectualScore || 96;
	result.emotionalScore;
	result.sociologicalScore;
	const recommendedArticles = [{
		id: "intellectual-compatibility-secrets",
		title: "أسرار التوافق الفكري والقرارات المشتركة في مؤسسة الزواج الحديثة",
		tag: "توصية فكرية",
		tagColor: "text-sky-300 bg-sky-950/80 border-sky-500/30",
		reason: `بناءً على نسبة التوافق الفكري (${intellectualScore}%) لتعزيز اتخاذ القرارات المشتركة.`,
		icon: "🧠",
		readTime: "5 دقائق"
	}, {
		id: "emotional-intelligence-marriage",
		title: "الذكاء العاطفي وأساليب الاحتواء السيكولوجي لتفادي تراكم الخلافات",
		tag: "توصية عاطفية",
		tagColor: "text-rose-300 bg-rose-950/80 border-rose-500/30",
		reason: `بناءً على نمط ارتباطك (${result.attachmentStyle || "الارتباط الآمن"}) لتقوية لغة المودة.`,
		icon: "💖",
		readTime: "6 دقائق"
	}];
	const recommendedTests = [{
		id: "intelligence",
		title: "مقياس الذكاءات المتعددة (Gardner & McKenzie)",
		type: "ذكاءات 8 أبعاد",
		desc: "اكتشف نوع ذكائك ومهاراتك الـ 24 الفرعية والمهن المناسبة للتكامل مع الشريك.",
		badge: "مقياس عالمي 🔬",
		badgeColor: "text-cyan-300 bg-cyan-950/80 border-cyan-500/30",
		icon: "💡",
		action: onOpenIntelligenceTests,
		buttonText: "بدء اختبار الذكاءات"
	}, {
		id: "psychology_cattell",
		title: "مقياس كاتل لـ 16 سمة شخصية (Cattell 16PF)",
		type: "سيكومتري معمق",
		desc: "قياس دقيق لسماتك في الصلابة العاطفية، التفكير المنطقي، والانفتاح الإنساني.",
		badge: "معتمد إحصائياً 📊",
		badgeColor: "text-purple-300 bg-purple-950/80 border-purple-500/30",
		icon: "🧬",
		action: onOpenPsychologyTests,
		buttonText: "خوض مقياس الشخصية"
	}];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "glass-panel rounded-3xl p-5 sm:p-7 border border-white/10 space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 text-amber-300 font-extrabold text-base sm:text-lg font-['Alexandria']",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-5 h-5 text-amber-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "نظام التوصيات المعرفية والذكية (Smart Recommendations)" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-slate-300 mt-1 leading-relaxed",
					children: [
						"تم تخصيص هذه التوصيات تلقائياً بناءً على نمط «",
						result.partnerArchetype,
						"» ومؤشراتك السلوكية لتعزيز الوعي وبناء علاقة متوازنة."
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "px-3 py-1 rounded-xl bg-purple-950/80 border border-purple-500/30 text-[11px] font-bold text-purple-200 self-start sm:self-auto shrink-0 flex items-center gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "w-3.5 h-3.5 text-purple-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "توصيات سيكولوجية مخصصة" })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 md:grid-cols-2 gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-xs font-bold text-slate-300",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "w-4 h-4 text-purple-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "الاختبارات التكميلية المقترحة لك:" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-3",
						children: recommendedTests.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-2xl bg-white/[0.03] hover:bg-white/[0.06] border border-white/10 transition space-y-3 flex flex-col justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-2 mb-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `text-[10px] font-bold px-2 py-0.5 rounded-full border ${t.badgeColor}`,
										children: t.badge
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-base",
										children: t.icon
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-bold text-sm text-white mb-1",
									children: t.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-slate-300 leading-relaxed",
									children: t.desc
								})
							] }), t.action && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									soundManager.playTap();
									t.action();
								},
								className: "w-full py-2 px-3 rounded-xl bg-purple-600/30 hover:bg-purple-600/50 border border-purple-400/40 text-purple-200 text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t.buttonText }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "w-3.5 h-3.5" })]
							})]
						}, t.id))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-xs font-bold text-slate-300",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "w-4 h-4 text-sky-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "مقالات سيكولوجية تدعم نتيجتك:" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-3",
						children: recommendedArticles.map((art) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-2xl bg-white/[0.03] hover:bg-white/[0.06] border border-white/10 transition space-y-3 flex flex-col justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-2 mb-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `text-[10px] font-bold px-2 py-0.5 rounded-full border ${art.tagColor}`,
										children: art.tag
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs text-slate-400 flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "w-3 h-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: art.readTime })]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
									className: "font-bold text-sm text-white mb-1 flex items-start gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "shrink-0",
										children: art.icon
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: art.title })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-slate-300 leading-relaxed",
									children: art.reason
								})
							] }), onOpenArticles && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									soundManager.playTap();
									onOpenArticles(art.id);
								},
								className: "w-full py-2 px-3 rounded-xl bg-sky-600/30 hover:bg-sky-600/50 border border-sky-400/40 text-sky-200 text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "قراءة المقال والتحليل 📖" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "w-3.5 h-3.5" })]
							})]
						}, art.id))
					})]
				})]
			}),
			onOpenNovels && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-4 rounded-2xl bg-gradient-to-r from-pink-950/40 via-purple-950/30 to-slate-900 border border-pink-500/30 flex flex-col sm:flex-row items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-2xl",
						children: "📚"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
						className: "font-bold text-sm text-white",
						children: [
							"رواية سيكولوجية مستوحاة من ثقافة «",
							profile.country,
							"»"
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-slate-300",
						children: "استكشف عمق المشاعر الإنسانية وعقد الشخصيات من خلال الروايات الأدبية والتحقيقات النفسية التفاعلية."
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						soundManager.playTap();
						onOpenNovels();
					},
					className: "py-2 px-4 rounded-xl bg-pink-600 hover:bg-pink-500 text-white font-bold text-xs whitespace-nowrap transition cursor-pointer shrink-0",
					children: "تصفح مكتبة الروايات 📖"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 text-slate-300 text-xs space-y-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center gap-1.5 font-bold text-emerald-300",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "⚖️ إخلاء مسؤولية علمي وتوعوي:" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] leading-relaxed text-slate-400",
					children: "هذه النتائج والتوصيات مقدمة لأغراض الإرشاد الذاتي والتوافق المعرفي والإثراء الإنساني؛ ولا تشكل بأي حال من الأحوال تشخيصاً عيادياً أو طبياً نفسياً. كل شخص يتميز بتفرده ومرونته النفسية المستمرة في التطور والنمو."
				})]
			})
		]
	});
};
//#endregion
//#region src/components/ResultStep.tsx
var containerVariants = {
	hidden: { opacity: 0 },
	visible: {
		opacity: 1,
		transition: {
			staggerChildren: .1,
			delayChildren: .05
		}
	}
};
var itemVariants = {
	hidden: {
		opacity: 0,
		y: 20
	},
	visible: {
		opacity: 1,
		y: 0,
		transition: {
			duration: .45,
			ease: [
				.16,
				1,
				.3,
				1
			]
		}
	}
};
var tabVariants = {
	initial: {
		opacity: 0,
		y: 12
	},
	animate: {
		opacity: 1,
		y: 0,
		transition: {
			duration: .3,
			ease: "easeOut"
		}
	},
	exit: {
		opacity: 0,
		y: -10,
		transition: {
			duration: .18,
			ease: "easeIn"
		}
	}
};
var cardContainerVariants = {
	hidden: { opacity: 0 },
	visible: {
		opacity: 1,
		transition: {
			staggerChildren: .09,
			delayChildren: .12
		}
	}
};
var cardItemVariants = {
	hidden: {
		opacity: 0,
		y: 14,
		filter: "blur(3px)"
	},
	visible: {
		opacity: 1,
		y: 0,
		filter: "blur(0px)",
		transition: {
			duration: .5,
			ease: [
				.16,
				1,
				.3,
				1
			]
		}
	}
};
var ResultStep = ({ result, profile, onRestart, onRegenerateImage, isRegeneratingImage, onLockResult, onOpenLiveChat, onOpenBlindDate, onOpenAuth, onOpenHistory, onOpenPsychologyTests, onOpenIntelligenceTests, onOpenArticles, onOpenNovels, onOpenUserDashboard, onOpenCoupleInvite }) => {
	const { user } = useAuth();
	const { language, direction, isRTL, t, translateText } = useLanguage();
	const [activeTab, setActiveTab] = (0, import_react.useState)("profile");
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [isGeneratingShareCard, setIsGeneratingShareCard] = (0, import_react.useState)(false);
	const [showLightbox, setShowLightbox] = (0, import_react.useState)(false);
	const [showPrivacyModal, setShowPrivacyModal] = (0, import_react.useState)(false);
	const [showAuditModal, setShowAuditModal] = (0, import_react.useState)(false);
	const [pinEnabled, setPinEnabled] = (0, import_react.useState)(() => isPinLockEnabled());
	const [theme, toggleTheme] = useAppTheme();
	const [flippedCards, setFlippedCards] = (0, import_react.useState)({});
	const handleToggleFlipCard = (cardId) => {
		setFlippedCards((prev) => ({
			...prev,
			[cardId]: !prev[cardId]
		}));
	};
	const areAllCardsFlipped = [
		"intellectual",
		"sociological",
		"emotional",
		"lifestyle"
	].every((id) => !!flippedCards[id]);
	const handleToggleFlipAll = () => {
		soundManager.playTap();
		const nextState = !areAllCardsFlipped;
		setFlippedCards({
			intellectual: nextState,
			sociological: nextState,
			emotional: nextState,
			lifestyle: nextState
		});
	};
	const [isSavingResult, setIsSavingResult] = (0, import_react.useState)(false);
	const [isResultSaved, setIsResultSaved] = (0, import_react.useState)(false);
	const [saveSuccessMsg, setSaveSuccessMsg] = (0, import_react.useState)(null);
	const handleSaveToAccount = async () => {
		soundManager.playTap();
		setIsSavingResult(true);
		try {
			await saveTestResultToHistory(user, profile, result);
			soundManager.playRoundPass();
			setIsResultSaved(true);
			setSaveSuccessMsg(user ? "تم حفظ نتيجة الاختبار في قاعدة بيانات حسابك بنجاح!" : "تم حفظ نتيجة الاختبار في قاعدة البيانات لسجلك الدائم بنجاح!");
			setTimeout(() => setSaveSuccessMsg(null), 4e3);
		} catch (e) {
			console.error("Failed to save result to account", e);
			setSaveSuccessMsg("تعذر الحفظ، يرجى المحاولة لاحقاً");
			setTimeout(() => setSaveSuccessMsg(null), 4e3);
		}
		setIsSavingResult(false);
	};
	const effectiveBreakdown = result.scoringBreakdown || calculateRealCompatibility(profile, {});
	(0, import_react.useEffect)(() => {
		soundManager.playResultReveal();
		try {
			confetti_module_default({
				particleCount: 85,
				spread: 80,
				origin: { y: .6 },
				colors: [
					"#f43f5e",
					"#ec4899",
					"#8b5cf6",
					"#fbbf24",
					"#ffffff"
				]
			});
		} catch {}
	}, []);
	const imageUrl = result.imageUrl || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1200&q=95";
	const partnerName = result.proposedPartnerName || (profile.partnerGender === "female" ? "نـورة" : "فيـصل");
	const handleDownloadCard = async () => {
		soundManager.playTap();
		setIsGeneratingShareCard(true);
		try {
			const dataUrl = await generateShareCardCanvas(result, profile, imageUrl);
			const link = document.createElement("a");
			link.download = `sharik-alhayat-${partnerName}.png`;
			link.href = dataUrl;
			link.click();
		} catch (err) {
			console.error("Failed to export share card:", err);
		} finally {
			setIsGeneratingShareCard(false);
		}
	};
	const handleNativeShare = async () => {
		soundManager.playTap();
		setIsGeneratingShareCard(true);
		const shareTitle = `مِرآة القلوب | دراسة التوافق الفكري والاجتماعي`;
		const shareText = `🔮 حللت توافقي الفكري والاجتماعي مع شريك حياتي (${partnerName} - ${result.partnerArchetype}) بنسبة ${result.compatibilityScore}% من أصول (${profile.ethnicity}) في ${profile.country}! اكتشف شريكك الآن:`;
		const shareUrl = window.location.href;
		try {
			if (navigator.share) {
				try {
					const dataUrl = await generateShareCardCanvas(result, profile, imageUrl);
					const blob = await (await fetch(dataUrl)).blob();
					const file = new File([blob], `partner-${partnerName}.png`, { type: "image/png" });
					if (navigator.canShare && navigator.canShare({ files: [file] })) {
						await navigator.share({
							title: shareTitle,
							text: shareText,
							url: shareUrl,
							files: [file]
						});
						setIsGeneratingShareCard(false);
						return;
					}
				} catch {}
				await navigator.share({
					title: shareTitle,
					text: shareText,
					url: shareUrl
				});
			} else {
				handleCopyLink();
				handleDownloadCard();
			}
		} catch (e) {
			console.log("Share dismissed", e);
		} finally {
			setIsGeneratingShareCard(false);
		}
	};
	const whatsappShareUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(`📊 نتيجة التقييم السيكومتري العلمي للتوافق الأسري (منصة مِـرآة القـلوب):\n\n✨ النمط التوافقي: ${result.partnerArchetype}\n❤️ مؤشر التوافق الكلي الموزون: ${result.compatibilityScore}%\n🧠 التوافق الفكري والمعرفي: ${result.intellectualScore || 90}%\n🏛️ التوافق القيمي والمجتمعي: ${result.sociologicalScore || 88}%\n🌍 الخلفية الثقافية: ${profile.ethnicity} - ${profile.country}\n\nجرب الاختبار العلمي المعتمد (25 بنداً):\n${typeof window !== "undefined" ? window.location.href : ""}`)}`;
	const twitterShareUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(`أتممت التقييم السيكومتري العلمي للتوافق الأسري عبر منصة مِـرآة القـلوب بنسبة توافق موزون ${result.compatibilityScore}%! 📊🔬`)}&url=${encodeURIComponent(typeof window !== "undefined" ? window.location.href : "")}`;
	const handleExportScientificPDF = async (options) => {
		soundManager.playTap();
		const { exportCurrentReportOrAnalysisToPDF } = await __vitePreload(async () => {
			const { exportCurrentReportOrAnalysisToPDF } = await import("./pdfReportGenerator-BNu3pVmt.js");
			return { exportCurrentReportOrAnalysisToPDF };
		}, __vite__mapDeps([0,1,2,3,4,5,6,7,8,9]));
		const subscales = effectiveBreakdown.scientificSubscales || [];
		exportCurrentReportOrAnalysisToPDF({
			reportTitle: "التقرير السيكومتري العلمي الشامل للتوافق الأسري والزواجي",
			subTitle: "مبني على 25 بنداً محكّماً وفق نماذج Gottman و Bowlby/ECR-R و Sternberg و Bowen و Schwartz و Klontz",
			scientificBasis: "Gottman (1999) Sound Relationship House • Fraley et al. (2000) ECR-R • Sternberg (1986) • Bowen (1978) • Schwartz (1992) • Klontz (2011)",
			userName: profile.userName || "مشارك",
			completedAt: (/* @__PURE__ */ new Date()).toLocaleDateString("ar-JO"),
			overallScoreLabel: "مؤشر التوافق السيكومتري الموزون",
			overallScoreValue: `${effectiveBreakdown.compatibilityScore}%`,
			cognitiveFingerprintTitle: `${result.partnerArchetype} — بصمة التناغم الأسري (${effectiveBreakdown.auditHash})`,
			executiveSummary: `${result.detailedMatchReason} — خوارزمية القياس: ${effectiveBreakdown.algorithmVersion}`,
			metrics: subscales.map((sub) => ({
				label: `${sub.titleAr} (${sub.theoryNameEn})`,
				scorePercent: sub.score,
				rawText: `${sub.questionsUsed.length} بنود قياسية`,
				levelLabel: sub.scientistAr,
				color: "#10b981"
			})),
			sections: subscales.map((sub) => ({
				title: sub.titleAr,
				badge: `${sub.scientistAr} • ${sub.theoryNameEn}`,
				content: sub.analysisAr,
				scorePercent: sub.score
			})),
			careersOrRecommendations: [
				result.intellectualSynergy,
				result.socialHarmony,
				result.romanticAdvice
			],
			disclaimerText: "هذا التقرير السيكومتري مبني على إجاباتك الفعلية عبر معادلات إحصائية حتمية (Deterministic Weighted Scoring) لأغراض الوعي الذاتي والإرشاد الأسري، ولا يعتمد على أي توقعات غيبية أو عشوائية."
		}, options);
	};
	const handleCopyLink = () => {
		soundManager.playTap();
		navigator.clipboard.writeText(`📊 منصة مِـرآة القـلوب للتقييم العلمي للتوافق الأسري\nالنمط التوافقي: ${result.partnerArchetype}\nمؤشر التوافق الموزون: ${result.compatibilityScore}%\n${window.location.href}`);
		setCopied(true);
		setTimeout(() => setCopied(false), 2500);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		variants: containerVariants,
		initial: "hidden",
		animate: "visible",
		className: "w-full max-w-2xl mx-auto px-4 py-6 text-white",
		dir: direction,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				variants: itemVariants,
				className: "flex items-center justify-between gap-2 p-2.5 px-3.5 rounded-2xl bg-black/40 border border-white/10 mb-5 text-xs shadow-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `w-2.5 h-2.5 rounded-full ${pinEnabled ? "bg-emerald-400 shadow-sm shadow-emerald-400 animate-pulse" : "bg-gray-500"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-gray-300 font-medium",
						children: pinEnabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "text-emerald-400",
							children: t("pin_security_enabled")
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-gray-400",
							children: t("pin_security_disabled")
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1.5",
					children: [
						pinEnabled && onLockResult && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
							whileHover: { scale: 1.04 },
							whileTap: { scale: .96 },
							onClick: () => {
								soundManager.playTap();
								onLockResult();
							},
							className: "px-2.5 py-1 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 font-bold flex items-center gap-1 cursor-pointer transition text-[11px]",
							title: t("lock_now"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "w-3 h-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("lock_now") })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
							whileHover: { scale: 1.04 },
							whileTap: { scale: .96 },
							onClick: () => {
								soundManager.playTap();
								setShowPrivacyModal(true);
							},
							className: "px-2.5 py-1 rounded-xl bg-white/10 hover:bg-white/15 border border-white/20 text-white font-medium flex items-center gap-1 cursor-pointer transition text-[11px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "w-3 h-3 text-amber-300" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: pinEnabled ? t("pin_settings") : t("enable_pin") })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
							whileHover: { scale: 1.04 },
							whileTap: { scale: .96 },
							onClick: () => {
								soundManager.playTap();
								toggleTheme();
							},
							className: "px-2.5 py-1 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-400/30 text-amber-300 font-medium flex items-center gap-1 cursor-pointer transition text-[11px]",
							title: theme === "dark" ? t("light_mode") : t("dark_mode"),
							children: theme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "w-3 h-3 text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("light_mode") })] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "w-3.5 h-3.5 text-purple-600" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("dark_mode") })] })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
							whileHover: { scale: 1.04 },
							whileTap: { scale: .96 },
							onClick: handleSaveToAccount,
							disabled: isSavingResult,
							className: `px-3 py-1 rounded-xl font-bold flex items-center gap-1.5 cursor-pointer transition text-[11px] shadow-sm ${isResultSaved ? "bg-emerald-500/20 border border-emerald-500/40 text-emerald-300" : "bg-gradient-to-r from-rose-500/20 to-purple-500/20 hover:from-rose-500/30 hover:to-purple-500/30 border border-rose-500/30 text-rose-200"}`,
							title: "Save result to account",
							children: isResultSaved ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookmarkCheck, { className: "w-3.5 h-3.5 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("saved_in_account") })] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "w-3.5 h-3.5 text-rose-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isSavingResult ? t("saving_progress") : t("save_to_account") })] })
						}),
						onOpenHistory && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
							whileHover: { scale: 1.04 },
							whileTap: { scale: .96 },
							onClick: () => {
								soundManager.playTap();
								onOpenHistory();
							},
							className: "px-2.5 py-1 rounded-xl bg-purple-500/15 hover:bg-purple-500/25 border border-purple-400/30 text-purple-200 font-medium flex items-center gap-1 cursor-pointer transition text-[11px]",
							title: "History",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "w-3 h-3 text-purple-300" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("history_btn") })]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: saveSuccessMsg && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					y: -10
				},
				animate: {
					opacity: 1,
					y: 0
				},
				exit: {
					opacity: 0,
					y: -10
				},
				className: "mb-4 p-3 rounded-2xl bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 text-xs text-center font-bold flex items-center justify-center gap-2 shadow-lg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookmarkCheck, { className: "w-4 h-4 text-emerald-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: saveSuccessMsg })]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				variants: itemVariants,
				className: "text-center mb-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-gradient-to-r from-rose-500/20 via-pink-500/20 to-violet-500/20 border border-rose-500/40 text-rose-200 text-xs font-bold mb-3 shadow-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-4 h-4 text-amber-300 animate-spin" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("result_badge_success") })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "text-3xl sm:text-4xl font-extrabold text-white mb-2 font-['Alexandria',sans-serif]",
						children: [
							t("result_title_main"),
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-gradient",
								children: t("result_title_partner")
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs sm:text-sm text-gray-300",
						children: [
							t("result_subtitle_desc"),
							" (",
							profile.country,
							")"
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				variants: itemVariants,
				className: "relative glass-panel-glow rounded-3xl p-5 border border-rose-500/35 mb-6 overflow-hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
						className: "absolute -inset-10 pointer-events-none opacity-70",
						animate: {
							background: [
								"radial-gradient(circle at 15% 25%, rgba(244, 63, 94, 0.45) 0%, rgba(245, 158, 11, 0.25) 35%, rgba(139, 92, 246, 0.2) 70%, transparent 100%)",
								"radial-gradient(circle at 65% 75%, rgba(236, 72, 153, 0.45) 0%, rgba(249, 115, 22, 0.3) 40%, rgba(168, 85, 247, 0.2) 75%, transparent 100%)",
								"radial-gradient(circle at 35% 85%, rgba(245, 158, 11, 0.4) 0%, rgba(244, 63, 94, 0.35) 45%, rgba(124, 58, 237, 0.2) 80%, transparent 100%)",
								"radial-gradient(circle at 80% 20%, rgba(217, 70, 239, 0.4) 0%, rgba(251, 113, 133, 0.35) 40%, rgba(245, 158, 11, 0.2) 75%, transparent 100%)",
								"radial-gradient(circle at 15% 25%, rgba(244, 63, 94, 0.45) 0%, rgba(245, 158, 11, 0.25) 35%, rgba(139, 92, 246, 0.2) 70%, transparent 100%)"
							],
							opacity: [
								.6,
								.9,
								.65,
								.85,
								.6
							]
						},
						transition: {
							duration: 12,
							repeat: Infinity,
							ease: "easeInOut"
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute inset-0 overflow-hidden pointer-events-none",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
								className: "absolute -top-12 -right-8 w-80 h-80 bg-gradient-to-t from-rose-600/35 via-orange-500/30 to-amber-400/25 blur-3xl rounded-full",
								animate: {
									y: [
										0,
										-22,
										-8,
										-28,
										0
									],
									x: [
										0,
										-16,
										12,
										-18,
										0
									],
									scale: [
										1,
										1.16,
										.94,
										1.12,
										1
									],
									opacity: [
										.45,
										.8,
										.5,
										.75,
										.45
									],
									borderRadius: [
										"50% 50% 50% 50%",
										"40% 60% 70% 30% / 40% 40% 60% 60%",
										"60% 40% 30% 70% / 50% 60% 40% 50%",
										"50% 50% 50% 50%"
									]
								},
								transition: {
									duration: 6.5,
									repeat: Infinity,
									ease: "easeInOut"
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
								className: "absolute -bottom-14 -left-10 w-80 h-80 bg-gradient-to-t from-amber-500/30 via-rose-500/30 to-violet-600/25 blur-3xl rounded-full",
								animate: {
									y: [
										0,
										-26,
										-12,
										-34,
										0
									],
									x: [
										0,
										18,
										-14,
										20,
										0
									],
									scale: [
										.95,
										1.18,
										1,
										1.14,
										.95
									],
									opacity: [
										.35,
										.7,
										.45,
										.75,
										.35
									]
								},
								transition: {
									duration: 7.8,
									repeat: Infinity,
									ease: "easeInOut",
									delay: .6
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
								className: "absolute bottom-4 right-1/4 w-3 h-3 rounded-full bg-amber-400/70 blur-[1px]",
								animate: {
									y: [0, -130],
									x: [
										0,
										-18,
										12
									],
									opacity: [
										0,
										.9,
										0
									],
									scale: [
										.5,
										1.3,
										.2
									]
								},
								transition: {
									duration: 3.8,
									repeat: Infinity,
									ease: "easeOut"
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
								className: "absolute bottom-6 right-1/2 w-2 h-2 rounded-full bg-rose-400/80 blur-[1px]",
								animate: {
									y: [0, -150],
									x: [
										0,
										20,
										-15
									],
									opacity: [
										0,
										.85,
										0
									],
									scale: [
										.4,
										1.2,
										.2
									]
								},
								transition: {
									duration: 4.5,
									repeat: Infinity,
									ease: "easeOut",
									delay: 1.4
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
								className: "absolute bottom-2 left-1/3 w-2.5 h-2.5 rounded-full bg-orange-400/75 blur-[1px]",
								animate: {
									y: [0, -115],
									x: [
										0,
										-14,
										16
									],
									opacity: [
										0,
										.8,
										0
									],
									scale: [
										.5,
										1.1,
										.2
									]
								},
								transition: {
									duration: 4.1,
									repeat: Infinity,
									ease: "easeOut",
									delay: 2.3
								}
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
						variants: cardContainerVariants,
						initial: "hidden",
						animate: "visible",
						className: "flex flex-col sm:flex-row items-center gap-6 relative z-10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
							variants: cardItemVariants,
							whileHover: { scale: 1.02 },
							className: "relative w-64 h-64 sm:w-64 sm:h-64 shrink-0 group flex items-center justify-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
									className: "absolute -inset-3.5 rounded-3xl bg-gradient-to-tr from-rose-500/40 via-fuchsia-500/35 to-violet-600/40 blur-xl pointer-events-none",
									animate: {
										opacity: [
											.35,
											.85,
											.35
										],
										scale: [
											.96,
											1.04,
											.96
										]
									},
									transition: {
										duration: 3.6,
										repeat: Infinity,
										ease: "easeInOut"
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
									className: "absolute -inset-1 rounded-2xl bg-gradient-to-r from-rose-400/60 via-pink-400/50 to-purple-500/60 blur-md pointer-events-none",
									animate: {
										opacity: [
											.45,
											.9,
											.45
										],
										scale: [
											.99,
											1.02,
											.99
										]
									},
									transition: {
										duration: 2.8,
										repeat: Infinity,
										ease: "easeInOut",
										delay: .4
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
									className: "w-full h-full rounded-2xl overflow-hidden border-2 relative z-10",
									animate: {
										borderColor: [
											"rgba(255, 255, 255, 0.3)",
											"rgba(251, 113, 133, 0.8)",
											"rgba(192, 132, 252, 0.65)",
											"rgba(255, 255, 255, 0.3)"
										],
										boxShadow: [
											"0 0 16px -2px rgba(244, 63, 94, 0.35), 0 0 28px -4px rgba(168, 85, 247, 0.25)",
											"0 0 32px 4px rgba(244, 63, 94, 0.65), 0 0 46px 6px rgba(217, 70, 239, 0.45)",
											"0 0 16px -2px rgba(244, 63, 94, 0.35), 0 0 28px -4px rgba(168, 85, 247, 0.25)"
										]
									},
									transition: {
										duration: 3.2,
										repeat: Infinity,
										ease: "easeInOut"
									},
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: imageUrl,
											alt: partnerName,
											className: "w-full h-full object-cover group-hover:scale-105 transition duration-500 cursor-pointer",
											onClick: () => setShowLightbox(true)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "absolute top-2.5 right-2.5 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/20 text-[10px] font-bold text-white flex items-center gap-1 shadow-md",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "w-3 h-3 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("ultra_hd_badge") })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
											whileHover: { scale: 1.1 },
											whileTap: { scale: .9 },
											onClick: () => setShowLightbox(true),
											className: "absolute bottom-2.5 left-2.5 p-2 rounded-xl bg-black/60 hover:bg-black/80 backdrop-blur-md text-white transition flex items-center gap-1 text-xs cursor-pointer shadow-md",
											title: language === "ar" ? "عرض الصورة بملء الشاشة" : "View Fullscreen",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomIn, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "تكبير" : "Zoom" })]
										})
									]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1 text-center sm:text-right space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
									variants: cardItemVariants,
									whileHover: {
										scale: 1.04,
										y: -2
									},
									className: "inline-flex items-center gap-2 px-4 py-1.5 rounded-2xl bg-gradient-to-r from-amber-500/20 to-rose-500/20 border border-amber-400/40 shadow-sm cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs text-amber-300 font-bold",
										children: [t("proposed_partner_badge"), ":"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-extrabold text-lg text-white font-['Alexandria',sans-serif]",
										children: [
											"«",
											partnerName,
											"»"
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.h3, {
									variants: cardItemVariants,
									className: "text-2xl sm:text-3xl font-black text-white font-['Alexandria',sans-serif] leading-tight",
									children: translateText(result.partnerArchetype)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
									variants: cardItemVariants,
									whileHover: { scale: 1.05 },
									whileTap: { scale: .96 },
									onClick: () => {
										soundManager.playTap();
										setShowAuditModal(true);
									},
									className: "inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/30 cursor-pointer shadow-sm transition group",
									title: "Click to view mathematical audit",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "w-4 h-4 fill-rose-500 text-rose-500 animate-pulse" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-xs font-bold text-rose-200",
											children: [
												t("overall_compatibility_label"),
												": ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
													className: "text-white text-base",
													children: [result.compatibilityScore, "%"]
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "px-2 py-0.5 rounded-md bg-emerald-500/20 border border-emerald-400/40 text-[10px] font-extrabold text-emerald-300 flex items-center gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calculator, { className: "w-3 h-3 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("mathematical_audit_btn") })]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
									variants: cardItemVariants,
									className: "space-y-1.5 text-xs text-gray-300",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-center sm:justify-start gap-1.5 flex-wrap",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-rose-400 font-bold",
													children: language === "ar" ? "الموقع والجنسية المكتشفة:" : "Detected Location & Nationality:"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-white font-bold",
													children: [
														profile.country,
														" (",
														result.detectedNationalityAr || profile.detectedNationalityAr || profile.ethnicity,
														")"
													]
												}),
												profile.isLocationAutoDetected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-[10px] font-bold text-emerald-300",
													children: language === "ar" ? "✓ توجيه عرقي واقعي بالذكاء الاصطناعي" : "✓ AI Ethnic Realism Matched"
												})
											]
										}),
										(result.detectedEthnicTraitsAr || profile.detectedEthnicTraitsAr) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-2.5 rounded-xl bg-white/5 border border-white/10 text-[11px] text-emerald-200/90 leading-relaxed",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
													className: "text-emerald-300",
													children: language === "ar" ? "الملامح العرقية المولّدة للصورة:" : "Generated Ethnic Features:"
												}),
												" ",
												result.detectedEthnicTraitsAr || profile.detectedEthnicTraitsAr
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-center sm:justify-start gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-violet-400 font-bold",
												children: language === "ar" ? "نمط الارتباط:" : "Attachment Style:"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-gray-200",
												children: translateText(result.attachmentStyle || "ارتباط آمن وتشاركي")
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-center sm:justify-start gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-yellow-400 font-bold",
												children: language === "ar" ? "لغة الحب المشتركة:" : "Shared Love Language:"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-yellow-300 font-semibold",
												children: translateText(result.loveLanguage)
											})]
										})
									]
								}),
								onRegenerateImage && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
									variants: cardItemVariants,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
										whileHover: { scale: 1.02 },
										whileTap: { scale: .98 },
										onClick: onRegenerateImage,
										disabled: isRegeneratingImage,
										className: "text-xs text-gray-400 hover:text-rose-300 transition flex items-center justify-center sm:justify-start gap-1 mt-1 cursor-pointer disabled:opacity-50",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `w-3.5 h-3.5 ${isRegeneratingImage ? "animate-spin text-rose-400" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isRegeneratingImage ? t("regenerating_now") : t("regenerate_image_btn") })]
									})
								})
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				variants: itemVariants,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompatibilityCharts, {
					result,
					profile,
					partnerName
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				variants: itemVariants,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompatibilityHeatmap, {
					result,
					profile,
					partnerName
				})
			}),
			(() => {
				const compatibilityCardsData = [
					{
						id: "intellectual",
						title: "التوافق الفكري",
						categoryNameAr: "التوافق الفكري والذهني 🧠",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "w-3.5 h-3.5" }),
						score: result.intellectualScore || 96,
						subtitle: "تقارب الرؤى ونضج الحوار",
						themeColor: "sky",
						deepAnalysis: result.intellectualSynergy || "تناغم ذهني رفيع؛ يتشارك الطرفان أسلوب التفكير العقلاني وتبادل الآراء بإصغاء ناضج مع احترام مساحة الاختلاف البناء.",
						goldenAdvice: "حددا وقتاً أسبوعياً لجلسات نقاش هادئة دون هواتف، لتبادل الأفكار الملهمة والتخطيط لمشاريعكما المشتركة.",
						tags: [
							"#نضج_الحوار",
							"#تقارب_الرؤى",
							"#احترام_الفكر"
						]
					},
					{
						id: "sociological",
						title: "التوافق المجتمعي",
						categoryNameAr: "الترابط الأسري والبيئة 🏛️",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "w-3.5 h-3.5" }),
						score: result.sociologicalScore || 95,
						subtitle: "الترابط الأسري والبيئة",
						themeColor: "violet",
						deepAnalysis: result.socialHarmony || `انسجام وثيق مع عادات وتقاليد المجتمع في (${profile.country})، وتوافق تام حول تقدير الأهل وصلة الرحم وصيانة استقلالية البيت.`,
						goldenAdvice: "ابنيا حدوداً صحية تحترم العائلة الكبيرة وتصون في الوقت ذاته خصوصية القرار الزوجي داخل البيت.",
						tags: [
							"#صلة_الرحم",
							"#احترام_البيئة",
							"#خصوصية_البيت"
						]
					},
					{
						id: "emotional",
						title: "الذكاء العاطفي",
						categoryNameAr: "الاحتواء والأمان النفسي 💖",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "w-3.5 h-3.5" }),
						score: result.emotionalScore || 98,
						subtitle: "الاحتواء والأمان النفسي",
						themeColor: "rose",
						deepAnalysis: result.detailedMatchReason || `نمط ارتباط آمن (${result.attachmentStyle || "Secure Attachment"}) يمنح الطرفين شعوراً فورياً بالدفء والطمأنينة والتعبير الصادق عن المشاعر.`,
						goldenAdvice: "مارسا \"الاحتواء قبل النقاش\"؛ أظهرا التقدير والعاطفة أولاً عند أي اختلاف لتذوب التوترات تلقائياً.",
						tags: [
							"#أمان_نفسي",
							"#لغة_المودة",
							"#احتواء_المشاعر"
						]
					},
					{
						id: "lifestyle",
						title: "نمط الحياة",
						categoryNameAr: "إيقاع اليوم والاستقرار 🧭",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, { className: "w-3.5 h-3.5" }),
						score: result.lifestyleScore || 94,
						subtitle: "الأهداف والاستقرار",
						themeColor: "amber",
						deepAnalysis: "تطابق عملي مريح في إدارة الميزانية، تنظيم الأولويات الحياتية، والتوازن الصحي بين الطموح المهني وأوقات الراحة والسفر.",
						goldenAdvice: "اتفقا على خطة مالية واضحة للادخار والمصاريف، واحرصا على قضاء عطلة دورية لتجديد النشاط والبهجة.",
						tags: [
							"#توازن_الحياة",
							"#تخطيط_مالي",
							"#راحة_يومية"
						]
					}
				];
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					variants: itemVariants,
					className: "glass-panel rounded-3xl p-4 sm:p-5 border border-white/10 mb-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 text-rose-400 font-extrabold text-sm sm:text-base",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "مؤشرات التوافق العلمي والاجتماعي المعتمدة:" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[11px] text-gray-400 mt-0.5 flex items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCw, { className: "w-3 h-3 text-rose-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "اضغط على أي بطاقة لقلبها (Flip) وقراءة التحليل المعمّق والنصائح الذهبية" })]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 self-start sm:self-auto flex-wrap",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
								whileHover: { scale: 1.03 },
								whileTap: { scale: .97 },
								onClick: handleToggleFlipAll,
								className: "flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-500/20 hover:bg-purple-500/30 border border-purple-400/40 text-purple-300 text-xs font-bold transition cursor-pointer",
								title: areAllCardsFlipped ? "إعادة جميع البطاقات للواجهة الرئيسية" : "قلب جميع البطاقات لقراءة التحليلات",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCw, { className: `w-3.5 h-3.5 text-purple-400 ${areAllCardsFlipped ? "rotate-180" : ""} transition-transform duration-300` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: areAllCardsFlipped ? "إعادة كل البطاقات ↩️" : "قلب جميع البطاقات 🔄" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
								whileHover: { scale: 1.03 },
								whileTap: { scale: .97 },
								onClick: () => {
									soundManager.playTap();
									setShowAuditModal(true);
								},
								className: "flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-400/40 text-emerald-300 text-xs font-bold transition cursor-pointer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calculator, { className: "w-3.5 h-3.5 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "لوحة الأرقام 📐" })]
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3",
						children: compatibilityCardsData.map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompatibilityFlipCard, {
							data: card,
							isFlipped: !!flippedCards[card.id],
							onToggleFlip: () => handleToggleFlipCard(card.id)
						}, card.id))
					})]
				});
			})(),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				variants: itemVariants,
				className: "p-5 sm:p-6 rounded-3xl bg-gradient-to-r from-purple-500/15 via-rose-500/15 to-violet-500/15 border border-purple-500/30 mb-6 shadow-xl relative overflow-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col md:flex-row items-center justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3.5 text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-14 h-14 rounded-2xl bg-gradient-to-tr from-purple-500 via-pink-500 to-rose-500 p-0.5 shadow-lg shadow-purple-500/20 shrink-0 flex items-center justify-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-full h-full bg-[#120d24] rounded-[14px] flex items-center justify-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "w-7 h-7 text-purple-400" })
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 flex-wrap",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-black text-sm sm:text-base text-white font-['Alexandria']",
								children: "تعميق تحليلك عبر قسم مقاييس الشخصية العلمي ولوحة ملفك الشخصي"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30",
								children: "صدق وثبات إحصائي 🔬"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-gray-300 mt-1 max-w-2xl leading-relaxed",
							children: "خض اختبارات العوامل الخمسة (Big Five)، ومينيسوتا (MMPI)، ورورشاخ الإسقاطي، ونمط الارتباط البشري، وانشر نتائجك في السوشيل ميديا أو اكتشف من يشبهك ويتوافق معك للتواصل وبناء شراكة حقيقية."
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2 shrink-0 justify-end w-full md:w-auto",
						children: [
							onOpenPsychologyTests && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
								whileHover: { scale: 1.03 },
								whileTap: { scale: .97 },
								onClick: () => {
									soundManager.playTap();
									onOpenPsychologyTests();
								},
								className: "px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs transition shadow-md shadow-purple-500/20 cursor-pointer flex items-center gap-1.5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "خوض اختبار نفسي معتمد 🔬" })
							}),
							onOpenUserDashboard && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
								whileHover: { scale: 1.03 },
								whileTap: { scale: .97 },
								onClick: () => {
									soundManager.playTap();
									onOpenUserDashboard();
								},
								className: "px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-gray-200 border border-white/15 font-bold text-xs transition cursor-pointer flex items-center gap-1.5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "لوحة ملفي والمتوافقين للتواصل 👤" })
							}),
							onOpenCoupleInvite && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
								whileHover: { scale: 1.03 },
								whileTap: { scale: .97 },
								onClick: () => {
									soundManager.playTap();
									onOpenCoupleInvite();
								},
								className: "px-3.5 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-400/40 text-rose-300 font-bold text-xs transition cursor-pointer flex items-center gap-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "دعوة شريك 💑" })
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				variants: itemVariants,
				className: "glass-panel rounded-3xl p-5 border border-white/10 mb-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-5 gap-1 p-1 rounded-2xl bg-black/40 border border-white/10 mb-5 overflow-x-auto",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
							whileHover: {
								scale: 1.05,
								y: -1
							},
							whileTap: { scale: .95 },
							onClick: () => {
								soundManager.playTab();
								setActiveTab("profile");
							},
							className: `py-2 px-1 rounded-xl text-[11px] sm:text-xs font-bold transition text-center cursor-pointer ${activeTab === "profile" ? "bg-rose-500 text-white shadow-md" : "text-gray-400 hover:text-white"}`,
							children: language === "ar" ? "الاسم والملامح" : "Name & Profile"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
							whileHover: {
								scale: 1.05,
								y: -1
							},
							whileTap: { scale: .95 },
							onClick: () => {
								soundManager.playTab();
								setActiveTab("intellect");
							},
							className: `py-2 px-1 rounded-xl text-[11px] sm:text-xs font-bold transition text-center cursor-pointer ${activeTab === "intellect" ? "bg-rose-500 text-white shadow-md" : "text-gray-400 hover:text-white"}`,
							children: language === "ar" ? "التوافق الفكري" : "Intellectual Fit"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
							whileHover: {
								scale: 1.05,
								y: -1
							},
							whileTap: { scale: .95 },
							onClick: () => {
								soundManager.playTab();
								setActiveTab("social");
							},
							className: `py-2 px-1 rounded-xl text-[11px] sm:text-xs font-bold transition text-center cursor-pointer ${activeTab === "social" ? "bg-rose-500 text-white shadow-md" : "text-gray-400 hover:text-white"}`,
							children: language === "ar" ? "التوافق المجتمعي" : "Social Fit"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
							whileHover: {
								scale: 1.05,
								y: -1
							},
							whileTap: { scale: .95 },
							onClick: () => {
								soundManager.playTab();
								setActiveTab("traits");
							},
							className: `py-2 px-1 rounded-xl text-[11px] sm:text-xs font-bold transition text-center cursor-pointer ${activeTab === "traits" ? "bg-rose-500 text-white shadow-md" : "text-gray-400 hover:text-white"}`,
							children: language === "ar" ? "السمات الجوهرية" : "Core Traits"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
							whileHover: {
								scale: 1.05,
								y: -1
							},
							whileTap: { scale: .95 },
							onClick: () => {
								soundManager.playTab();
								setActiveTab("advice");
							},
							className: `py-2 px-1 rounded-xl text-[11px] sm:text-xs font-bold transition text-center cursor-pointer ${activeTab === "advice" ? "bg-rose-500 text-white shadow-md" : "text-gray-400 hover:text-white"}`,
							children: language === "ar" ? "الوصية الزوجية" : "Couple Advice"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AnimatePresence, {
					mode: "wait",
					children: [
						activeTab === "profile" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
							variants: tabVariants,
							initial: "initial",
							animate: "animate",
							exit: "exit",
							className: "space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
									whileHover: {
										scale: 1.015,
										y: -2
									},
									className: "p-4 rounded-2xl bg-gradient-to-r from-amber-500/10 to-rose-500/10 border border-amber-500/25 space-y-1.5 transition cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 text-amber-300 font-bold text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quote, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
											"دلالة الاسم المقترح: «",
											partnerName,
											"»"
										] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs sm:text-sm text-gray-200 leading-relaxed",
										children: result.nameMeaning
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
									whileHover: {
										scale: 1.015,
										y: -2
									},
									className: "space-y-2 transition cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 text-rose-300 font-bold text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "المواصفات الجمالية والملامح البشرية الواقعية:" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-gray-200 leading-relaxed bg-white/5 p-4 rounded-2xl border border-white/10",
										children: result.visualDescription
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.blockquote, {
									whileHover: {
										scale: 1.02,
										y: -2
									},
									className: "p-3.5 rounded-2xl bg-white/5 border border-white/10 text-xs sm:text-sm italic text-rose-200 text-center leading-relaxed font-serif transition cursor-pointer",
									children: result.partnerVibeQuote
								})
							]
						}, "profile"),
						activeTab === "intellect" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
							variants: tabVariants,
							initial: "initial",
							animate: "animate",
							exit: "exit",
							className: "space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 text-sky-400 font-bold text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "دراسة التوافق الفكري والقرارات المشتركة:" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.p, {
									whileHover: { scale: 1.015 },
									className: "text-sm text-gray-200 leading-relaxed bg-white/5 p-4 rounded-2xl border border-white/10 cursor-pointer",
									children: result.intellectualSynergy || result.detailedMatchReason
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2 text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
										whileHover: {
											scale: 1.025,
											y: -2
										},
										className: "bg-sky-500/10 p-3 rounded-xl border border-sky-500/20 cursor-pointer transition",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-sky-300 block mb-1",
											children: "أسلوب الحوار:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-gray-300",
											children: "عقلاني هادئ قائم على الإقناع دون فرض وصاية"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
										whileHover: {
											scale: 1.025,
											y: -2
										},
										className: "bg-sky-500/10 p-3 rounded-xl border border-sky-500/20 cursor-pointer transition",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-sky-300 block mb-1",
											children: "دعم الطموح المهني:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-gray-300",
											children: "تشجيع متواصل وفخر متبادل بالإنجازات الفردية"
										})]
									})]
								})
							]
						}, "intellect"),
						activeTab === "social" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
							variants: tabVariants,
							initial: "initial",
							animate: "animate",
							exit: "exit",
							className: "space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 text-violet-400 font-bold text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "التوافق المجتمعي والعائلي ومحيط البيئة:" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.p, {
									whileHover: { scale: 1.015 },
									className: "text-sm text-gray-200 leading-relaxed bg-white/5 p-4 rounded-2xl border border-white/10 cursor-pointer",
									children: result.socialHarmony || result.detailedMatchReason
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
									whileHover: {
										scale: 1.02,
										y: -2
									},
									className: "p-3 rounded-xl bg-violet-500/10 border border-violet-500/20 text-xs text-gray-200 space-y-1 cursor-pointer transition",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "font-bold text-violet-300",
										children: [
											"الانسجام مع البيئة الأسرية في (",
											profile.country,
											"):"
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-gray-300",
										children: "يحقق التوازن الذهبي بين بر الوالدين وتوطيد الروابط الأسرية الدافئة، مع صيانة قدسية بيت الزوجية وخصوصية أسراره التامة."
									})]
								})
							]
						}, "social"),
						activeTab === "traits" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
							variants: tabVariants,
							initial: "initial",
							animate: "animate",
							exit: "exit",
							className: "space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 text-rose-300 font-bold text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "الأعمدة الأربعة للشخصية والتوافق السلوكي:" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-2.5",
								children: result.partnerTraits.map((trait, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
									whileHover: {
										scale: 1.02,
										x: -3
									},
									whileTap: { scale: .985 },
									className: "bg-white/5 hover:bg-white/10 p-3 rounded-xl border border-white/10 space-y-1.5 transition cursor-pointer",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-xs sm:text-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-bold text-white",
												children: trait.title
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-extrabold text-rose-400 font-mono",
												children: [trait.percentage, "%"]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-full h-1.5 rounded-full bg-white/10 overflow-hidden",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
												className: "h-full bg-gradient-to-l from-rose-500 to-violet-500 rounded-full",
												initial: { width: 0 },
												animate: { width: `${trait.percentage}%` },
												transition: {
													duration: .6,
													delay: i * .1
												}
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] text-gray-400",
											children: trait.description
										})
									]
								}, i))
							})]
						}, "traits"),
						activeTab === "advice" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
							variants: tabVariants,
							initial: "initial",
							animate: "animate",
							exit: "exit",
							className: "space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 text-rose-300 font-bold text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "الوصية الذهبية لاستدامة المودة والرحمة:" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
									whileHover: {
										scale: 1.015,
										y: -2
									},
									className: "p-4 rounded-2xl bg-gradient-to-l from-rose-500/10 to-violet-600/10 border border-rose-500/20 text-sm leading-relaxed text-gray-200 cursor-pointer",
									children: result.romanticAdvice
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
									whileHover: { scale: 1.02 },
									className: "p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-200 cursor-pointer",
									children: [
										"💡 ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "تلميح اجتماعي:" }),
										" شارك هذه النتيجة مع عائلتك أو أصدقائك المقربين لمعرفة رأيهم في الاسم المقترح «",
										partnerName,
										"» والمواصفات!"
									]
								})
							]
						}, "advice")
					]
				})]
			}),
			effectiveBreakdown.scientificSubscales && effectiveBreakdown.scientificSubscales.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				variants: itemVariants,
				className: "glass-panel rounded-3xl p-5 sm:p-6 border border-emerald-500/30 mb-6 bg-slate-950/85 space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-emerald-500/15 border border-emerald-500/30 text-[11px] font-bold text-emerald-300",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calculator, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تقييم التوافق المبني على أسس علمية محكّمة (25 بنداً قياسياً)" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-base sm:text-lg font-extrabold text-white font-['Alexandria']",
								children: "مصفوفة المقاييس السيكومترية الستة للتوافق الزواجي والأسري"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-slate-300",
								children: "نتائج حقيقية مستخرجة مباشرةً من إجاباتك دون أي تخمين عشوائي أو نصوص دعائية، مع إمكانية مراجعة سجل النقاط الخام أو مقارنة إجاباتك مع شريك فعلي."
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2 shrink-0 no-print",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => handleExportScientificPDF({
									textOnly: false,
									mode: "pdf"
								}),
								className: "px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shadow-md",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileDown, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تحميل التقرير العلمي (PDF)" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => handleExportScientificPDF({
									textOnly: true,
									mode: "pdf"
								}),
								className: "px-3 py-2 rounded-xl bg-amber-600/25 hover:bg-amber-600/35 border border-amber-500/40 text-amber-200 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-4 h-4 text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تصدير PDF نصي نظيف" })]
							}),
							onOpenCoupleInvite && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									soundManager.playTap();
									onOpenCoupleInvite();
								},
								className: "px-3.5 py-2 rounded-xl bg-rose-600/25 hover:bg-rose-600/35 border border-rose-500/40 text-rose-200 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "w-4 h-4 text-rose-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "التقييم العلمي المزدوج لشريكين" })]
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
					children: effectiveBreakdown.scientificSubscales.map((sub) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col justify-between space-y-2.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-extrabold text-white",
										children: sub.titleAr
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-sm font-black font-mono text-emerald-400",
										children: [sub.score, "%"]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[10px] text-slate-400 font-mono",
									children: [
										sub.scientistAr,
										" • ",
										sub.theoryNameEn
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-full h-1.5 rounded-full bg-slate-800 overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full bg-gradient-to-l from-emerald-400 to-teal-500 rounded-full",
									style: { width: `${sub.score}%` }
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between text-[11px]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 font-bold",
									children: sub.score >= 85 ? "توافق علمي مرتفع جداً" : sub.score >= 72 ? "توافق متزن ومثمر" : "قابل للتطوير التشاركي"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-slate-400 font-mono",
									children: ["البنود: #", sub.questionsUsed.join(", #")]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-slate-300 leading-relaxed",
								children: sub.analysisAr
							})
						]
					}, sub.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				variants: itemVariants,
				className: "mb-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SocioculturalScienceSection, {
					partnerName,
					profile
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				variants: itemVariants,
				className: "mb-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FastCompatibilityCadenceSection, {
					partnerName,
					profile,
					onOpenLiveChat,
					onOpenBlindDate
				})
			}),
			onOpenBlindDate && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				variants: itemVariants,
				whileHover: { scale: 1.01 },
				className: "relative glass-panel rounded-3xl p-5 border border-rose-500/40 mb-6 overflow-hidden bg-gradient-to-r from-purple-950/60 via-slate-950 to-rose-950/60 shadow-xl shadow-rose-950/30",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col sm:flex-row items-center justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3.5 text-center sm:text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative shrink-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-14 h-14 rounded-2xl bg-gradient-to-tr from-rose-600 via-pink-600 to-purple-600 flex items-center justify-center text-3xl shadow-lg shadow-rose-500/30 text-white",
									children: "💬"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -top-1 -right-1 w-3.5 h-3.5 bg-rose-400 rounded-full border-2 border-slate-950 animate-ping" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -top-1 -right-1 w-3.5 h-3.5 bg-rose-400 rounded-full border-2 border-slate-950" })
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-center sm:justify-start gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "text-base sm:text-lg font-black text-white font-['Alexandria']",
									children: "The Blind Date"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "px-2.5 py-0.5 rounded-full bg-rose-500/20 border border-rose-400/40 text-[10px] text-rose-300 font-extrabold",
									children: "جلسة التوافق التفاعلية ✨"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-gray-300 max-w-md leading-relaxed",
								children: "خض تجربة The Blind Date التفاعلية: 4 مستويات أسئلة متبادلة (شخصية، اجتماعية، علمية، طموحات) مع تقييم إجابات الطرفين، ثم لحظة الحسم والدردشة المفتوحة!"
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
						whileHover: { scale: 1.04 },
						whileTap: { scale: .96 },
						onClick: () => {
							soundManager.playTap();
							onOpenBlindDate();
						},
						className: "py-3 px-5 rounded-2xl bg-gradient-to-r from-rose-500 via-pink-500 to-purple-600 hover:opacity-95 text-white font-extrabold text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-rose-500/25 transition cursor-pointer shrink-0 whitespace-nowrap",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "بدء The Blind Date الآن 💬" })
					})]
				})
			}),
			onOpenLiveChat && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				variants: itemVariants,
				whileHover: { scale: 1.01 },
				className: "relative glass-panel rounded-3xl p-5 border border-emerald-500/35 mb-6 overflow-hidden bg-gradient-to-r from-emerald-950/40 via-slate-950 to-teal-950/40 shadow-xl shadow-emerald-950/20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col sm:flex-row items-center justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3.5 text-center sm:text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative shrink-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-2xl shadow-lg shadow-emerald-500/30 text-white",
									children: "📡"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -top-1 -right-1 w-3.5 h-3.5 bg-emerald-400 rounded-full border-2 border-slate-950 animate-ping" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -top-1 -right-1 w-3.5 h-3.5 bg-emerald-400 rounded-full border-2 border-slate-950" })
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-center sm:justify-start gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "text-base sm:text-lg font-black text-white font-['Alexandria']",
									children: "دردشة حية مع أشخاص متواجدين في الوقت نفسه"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-[10px] text-emerald-300 font-bold",
									children: "رادار حي 🟢"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-gray-300 max-w-md leading-relaxed",
								children: "إذا تواجد الآن مستخدم آخر يتطابق معك في المواصفات ورغبة الشريك، يتيح لك النظام فتح محادثة فورية ومجهولة وآمنة للتواصل المباشر."
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
						whileHover: { scale: 1.04 },
						whileTap: { scale: .96 },
						onClick: () => {
							soundManager.playTap();
							onOpenLiveChat();
						},
						className: "py-3 px-5 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:opacity-95 text-white font-bold text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-emerald-500/25 transition cursor-pointer shrink-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "فتح رادار الدردشة والمطابقة 🟢" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-base",
							children: "💬"
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				variants: itemVariants,
				className: "mb-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SmartRecommendationsSection, {
					result,
					profile,
					onOpenPsychologyTests,
					onOpenIntelligenceTests,
					onOpenArticles,
					onOpenNovels
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				variants: itemVariants,
				className: "glass-panel p-5 rounded-3xl border border-white/10 mb-6 space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-flex items-center gap-1.5 text-rose-400 font-extrabold text-base mb-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "مشاركة وتصدير التقرير العلمي للتوافق" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-gray-300",
							children: "بطاقة سيكومترية وتقرير PDF علمي موثق يتضمن مؤشرات التوافق الستة والنتائج الإحصائية"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 sm:grid-cols-3 gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
								whileHover: { scale: 1.02 },
								whileTap: { scale: .98 },
								onClick: handleNativeShare,
								disabled: isGeneratingShareCard,
								className: "py-3.5 px-4 rounded-2xl bg-gradient-to-r from-rose-500 via-pink-500 to-violet-600 hover:opacity-95 text-white font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-rose-500/30 transition cursor-pointer disabled:opacity-60",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isGeneratingShareCard ? "جاري تجهيز البطاقة..." : "مشاركة بطاقة النتيجة" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
								whileHover: { scale: 1.02 },
								whileTap: { scale: .98 },
								onClick: handleDownloadCard,
								disabled: isGeneratingShareCard,
								className: "py-3.5 px-4 rounded-2xl bg-white/10 hover:bg-white/15 border border-white/20 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-60",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "w-4 h-4 text-rose-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تحميل البطاقة كصورة HD" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
								whileHover: { scale: 1.02 },
								whileTap: { scale: .98 },
								onClick: () => handleExportScientificPDF({
									textOnly: false,
									mode: "pdf"
								}),
								className: "py-3.5 px-4 rounded-2xl bg-emerald-600/25 hover:bg-emerald-600/35 border border-emerald-500/40 text-emerald-200 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition cursor-pointer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileDown, { className: "w-4 h-4 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تصدير التقرير العلمي PDF" })]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 gap-3 no-print",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
							whileHover: { scale: 1.02 },
							whileTap: { scale: .98 },
							onClick: () => handleExportScientificPDF({
								textOnly: true,
								mode: "pdf"
							}),
							className: "py-3 px-4 rounded-2xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400/40 text-amber-200 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-4 h-4 text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تصدير PDF نصي نظيف" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
							whileHover: { scale: 1.02 },
							whileTap: { scale: .98 },
							onClick: () => handleExportScientificPDF({
								textOnly: false,
								mode: "print"
							}),
							className: "py-3 px-4 rounded-2xl bg-sky-500/20 hover:bg-sky-500/30 border border-sky-400/40 text-sky-200 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "w-4 h-4 text-sky-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "طباعة نظيفة A4" })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-center gap-3 pt-2 border-t border-white/10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: whatsappShareUrl,
								target: "_blank",
								rel: "noopener noreferrer",
								onClick: () => soundManager.playTap(),
								className: "p-3 rounded-2xl bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/30 text-emerald-400 flex items-center gap-2 text-xs font-bold transition cursor-pointer",
								title: "مشاركة في واتساب",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "واتساب" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: twitterShareUrl,
								target: "_blank",
								rel: "noopener noreferrer",
								onClick: () => soundManager.playTap(),
								className: "p-3 rounded-2xl bg-sky-600/20 hover:bg-sky-600/30 border border-sky-500/30 text-sky-400 flex items-center gap-2 text-xs font-bold transition cursor-pointer",
								title: "مشاركة في منصة إكس",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Twitter, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "منصة X" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
								whileHover: { scale: 1.05 },
								whileTap: { scale: .95 },
								onClick: handleCopyLink,
								className: "p-3 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 text-gray-300 flex items-center gap-2 text-xs font-medium transition cursor-pointer",
								title: "نسخ الرابط",
								children: copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-emerald-400",
									children: "تم النسخ!"
								})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "نسخ الرابط" })] })
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				variants: itemVariants,
				className: "text-center pt-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
					whileHover: { scale: 1.02 },
					whileTap: { scale: .98 },
					onClick: () => {
						soundManager.playPageTransition();
						onRestart();
					},
					className: "inline-flex items-center gap-2 px-6 py-3 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/15 text-gray-300 hover:text-white text-sm font-semibold transition cursor-pointer",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "w-4 h-4 text-rose-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "إجراء دراسة توافق جديدة لشريك آخر أو بلد مختلف" })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageViewerModal, {
				imageUrl,
				title: `شريك الحياة: ${partnerName}`,
				subtitle: `${result.partnerArchetype} • ${profile.country}`,
				isOpen: showLightbox,
				onClose: () => setShowLightbox(false),
				onDownload: handleDownloadCard,
				onShare: handleNativeShare
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrivacySettingsModal, {
				isOpen: showPrivacyModal,
				onClose: () => setShowPrivacyModal(false),
				onPinConfigured: (isLockedNow) => {
					const enabled = isPinLockEnabled();
					setPinEnabled(enabled);
					if (isLockedNow && onLockResult) onLockResult();
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RealCalculationAuditModal, {
				isOpen: showAuditModal,
				onClose: () => setShowAuditModal(false),
				scoringBreakdown: effectiveBreakdown,
				partnerName
			})
		]
	});
};
//#endregion
export { ResultStep };
