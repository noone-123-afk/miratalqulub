import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { An as BookOpen, C as Stethoscope, D as Sparkles, I as Share2, K as RotateCcw, Mn as Award, Mt as House, Nn as ArrowRight, Rt as GraduationCap, S as Sun, Sn as Calendar, St as ListChecks, V as Search, Wt as FileText, Z as Quote, _n as ChevronRight, bn as Check, cn as Clock, ht as Maximize2, jn as BookMarked, r as X, st as Moon } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import { d as useAppTheme, l as useLanguage, s as OFFICIAL_LOGO_URL } from "./index-C5uCeetQ.js";
import { n as AnimatePresence, t as motion } from "./vendor-motion-BS7ODJw7.js";
import { a as ARTICLES_CATALOG, c as PLATFORM_INTRODUCTORY_ARTICLES, d as PDF_FOUR_NARRATIVE_ARTICLES, i as getFullContinuousAcademicText, l as EMOTIONAL_IQ_NARRATIVE_ARTICLES, o as getFullContinuousNarrativeText, r as ACADEMIC_PAPERS_CATALOG, s as CLINICAL_CHILDHOOD_ANXIETY_NARRATIVE_ARTICLES, u as RELATIONSHIP_FOUR_NARRATIVE_ARTICLES } from "./data-content-CCe8WBeA.js";
import { n as ReaderToolbar, t as FormattedContinuousManuscript } from "./ReaderToolbar-CBKPy1tK.js";
import { t as ArticleBottomSocialShare } from "./FullScreenResearchStudyModal-CzFzUkbF.js";
import { t as PageSEO } from "./PageSEO-tUCGtj4d.js";
//#region src/components/ResearchArticleModal.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var ResearchArticleModal = ({ isOpen, onClose, content, paper, article, title, abstract, initialViewMode = "continuous_only" }) => {
	const { language, isRTL, toggleLanguage } = useLanguage();
	const { appTheme, toggleAppTheme } = useAppTheme();
	const isLight = appTheme === "light";
	const isAr = language === "ar";
	const [fontSize, setFontSize] = (0, import_react.useState)(18);
	const [viewMode, setViewMode] = (0, import_react.useState)(initialViewMode);
	const [copiedFullText, setCopiedFullText] = (0, import_react.useState)(false);
	const [copiedApa, setCopiedApa] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setViewMode(initialViewMode);
	}, [
		initialViewMode,
		paper?.id,
		article?.id,
		content
	]);
	(0, import_react.useEffect)(() => {
		if (!isOpen) return;
		const handleKeyDown = (e) => {
			if (e.key === "Escape") onClose();
		};
		window.addEventListener("keydown", handleKeyDown);
		return () => window.removeEventListener("keydown", handleKeyDown);
	}, [isOpen, onClose]);
	if (!isOpen || !paper && !article && !content) return null;
	const displayTitle = title || (paper ? isAr ? paper.titleAr : paper.titleEn : article ? isAr ? article.title : article.titleEn : isAr ? "دراسة بحثية / مقال علمي" : "Research Study / Clinical Article");
	const secondaryTitle = paper ? isAr ? paper.titleEn : paper.titleAr : article ? isAr ? article.titleEn : article.title : "";
	const displayAbstract = abstract || (paper ? isAr ? paper.abstractAr : paper.abstractEn : article ? isAr ? article.summary : article.summaryEn : content?.slice(0, 320) || "");
	const fullStudyContent = content || (paper ? getFullContinuousAcademicText(paper, language) : article ? getFullContinuousNarrativeText(article, language) : "");
	const fontScalePercent = Math.round(fontSize / 16 * 100);
	const handleCopyFullManuscript = () => {
		soundManager.playTap();
		if (navigator.clipboard) {
			navigator.clipboard.writeText(fullStudyContent);
			setCopiedFullText(true);
			setTimeout(() => setCopiedFullText(false), 2600);
		}
	};
	const handleCopyApaCitation = () => {
		if (!paper) return;
		soundManager.playTap();
		const year = paper.publishDate.slice(0, 4) || "2025";
		const citation = isAr ? `وحدة الأبحاث والدراسات النفسية - مرآة القلوب. (${year}). ${paper.titleAr}. موسوعة مرآة القلوب للأبحاث النفسية المحكّمة. https://miratalqulub.com/#/articles` : `Mirror of Hearts Psychological Research Unit. (${year}). ${paper.titleEn}. Mirror of Hearts Peer-Reviewed Encyclopedia. https://miratalqulub.com/#/articles`;
		if (navigator.clipboard) {
			navigator.clipboard.writeText(citation);
			setCopiedApa(true);
			setTimeout(() => setCopiedApa(false), 2500);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex flex-col overflow-hidden bg-black/85 backdrop-blur-md",
		dir: isRTL ? "rtl" : "ltr",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": displayTitle,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: {
				opacity: 0,
				y: 16
			},
			animate: {
				opacity: 1,
				y: 0
			},
			exit: {
				opacity: 0,
				y: 16
			},
			transition: { duration: .22 },
			className: `w-full h-full flex flex-col overflow-hidden transition-colors duration-300 ${isLight ? "bg-slate-50 text-slate-900" : "bg-slate-950 text-slate-100"}`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: `shrink-0 px-4 sm:px-8 py-3.5 border-b flex flex-wrap items-center justify-between gap-3 shadow-md z-20 ${isLight ? "bg-white/95 border-slate-200 text-slate-900" : "bg-slate-900/95 border-cyan-500/30 text-white"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-600 to-cyan-500 flex items-center justify-center text-white shadow-md shrink-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "w-5 h-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 flex-wrap",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "px-2.5 py-0.5 rounded-full bg-indigo-500/15 border border-indigo-500/30 text-indigo-700 dark:text-cyan-300 text-[11px] font-extrabold",
								children: isAr ? "القارئ الأكاديمي بملء الشاشة (ResearchArticleModal)" : "Full-Screen Academic Reader"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-[11px] text-emerald-600 dark:text-emerald-400 font-bold hidden sm:inline",
								children: ["• ", isAr ? "قراءة متصلة دون تجزئة" : "Continuous Unsegmented Study"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xs sm:text-sm font-black truncate max-w-xs sm:max-w-xl font-['Alexandria'] mt-0.5",
							children: displayTitle
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						paper && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `inline-flex items-center p-1 rounded-xl border ${isLight ? "bg-slate-100 border-slate-200" : "bg-black/40 border-white/10"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									soundManager.playTap();
									setViewMode("continuous_only");
								},
								className: `px-2.5 py-1 rounded-lg text-xs font-extrabold transition cursor-pointer ${viewMode === "continuous_only" ? "bg-indigo-600 text-white shadow-sm" : isLight ? "text-slate-600 hover:text-slate-900" : "text-gray-300 hover:text-white"}`,
								children: ["📜 ", isAr ? "النص الكامل دون تجزئة" : "Full Continuous"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									soundManager.playTap();
									setViewMode("segmented_and_continuous");
								},
								className: `px-2.5 py-1 rounded-lg text-xs font-extrabold transition cursor-pointer ${viewMode === "segmented_and_continuous" ? "bg-indigo-600 text-white shadow-sm" : isLight ? "text-slate-600 hover:text-slate-900" : "text-gray-300 hover:text-white"}`,
								children: ["📑 ", isAr ? "الأقسام + النص الكامل" : "Sections + Full"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl border ${isLight ? "bg-slate-100 border-slate-300" : "bg-black/40 border-white/15"}`,
							title: isAr ? "التحكم في حجم الخط" : "Font Size Controller",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] font-bold opacity-75 hidden md:inline",
									children: isAr ? "حجم الخط:" : "Font:"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										soundManager.playTap();
										setFontSize((prev) => Math.max(14, prev - 2));
									},
									className: `px-2 py-0.5 rounded-lg text-xs font-black transition cursor-pointer ${isLight ? "hover:bg-white text-slate-800" : "hover:bg-white/15 text-white"}`,
									"aria-label": isAr ? "تصغير حجم الخط" : "Decrease Font Size",
									children: "A-"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "range",
									min: 14,
									max: 28,
									step: 1,
									value: fontSize,
									onChange: (e) => setFontSize(Number(e.target.value)),
									className: "w-16 sm:w-20 accent-indigo-600 cursor-pointer hidden sm:inline-block",
									"aria-label": isAr ? "شريط حجم الخط" : "Font Size Slider"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[11px] font-mono font-extrabold px-1 text-indigo-600 dark:text-cyan-300",
									children: [fontScalePercent, "%"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										soundManager.playTap();
										setFontSize((prev) => Math.min(28, prev + 2));
									},
									className: `px-2 py-0.5 rounded-lg text-xs font-black transition cursor-pointer ${isLight ? "hover:bg-white text-slate-800" : "hover:bg-white/15 text-white"}`,
									"aria-label": isAr ? "تكبير حجم الخط" : "Increase Font Size",
									children: "A+"
								}),
								fontSize !== 18 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										soundManager.playTap();
										setFontSize(18);
									},
									className: "p-1 rounded-lg opacity-70 hover:opacity-100 cursor-pointer",
									title: isAr ? "إعادة ضبط حجم الخط" : "Reset Font Size",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "w-3 h-3" })
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								soundManager.playTap();
								toggleAppTheme();
							},
							className: `px-3 py-1.5 rounded-xl text-xs font-extrabold border flex items-center gap-1.5 transition cursor-pointer ${isLight ? "bg-amber-50 hover:bg-amber-100 text-amber-900 border-amber-300" : "bg-indigo-950/80 hover:bg-indigo-900 text-amber-300 border-indigo-500/40"}`,
							title: isAr ? "تبديل الوضع الليلي / النهاري" : "Toggle Dark / Light Mode",
							children: [isLight ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isLight ? isAr ? "الوضع الليلي" : "Dark Mode" : isAr ? "الوضع النهاري" : "Light Mode" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								soundManager.playTap();
								toggleLanguage();
							},
							className: `px-3 py-1.5 rounded-xl text-xs font-extrabold border transition cursor-pointer ${isLight ? "bg-white hover:bg-slate-100 text-slate-800 border-slate-300" : "bg-white/10 hover:bg-white/20 text-white border-white/15"}`,
							children: isAr ? "EN 🇬🇧" : "عربي 🇸🇦"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								soundManager.playTap();
								onClose();
							},
							className: "px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-extrabold flex items-center gap-1.5 transition cursor-pointer shadow-sm",
							title: isAr ? "إغلاق القارئ (Esc)" : "Close Reader (Esc)",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "إغلاق" : "Close" })]
						})
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-1 overflow-y-auto px-4 sm:px-8 py-6 sm:py-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-5xl mx-auto space-y-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `p-6 sm:p-8 rounded-3xl border space-y-4 shadow-xl ${isLight ? "bg-gradient-to-br from-indigo-50 via-white to-cyan-50 border-indigo-200 text-slate-900" : `bg-gradient-to-br ${paper?.coverGradient || "from-indigo-950/60 via-slate-900 to-cyan-950/60"} border-cyan-500/35 text-white`}`,
							children: [
								paper && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "px-3 py-1 rounded-xl bg-cyan-500/20 border border-cyan-400/40 text-cyan-800 dark:text-cyan-200 text-xs font-extrabold flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? paper.categoryLabelAr : paper.categoryLabelEn })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "px-3 py-1 rounded-xl bg-indigo-500/20 border border-indigo-400/40 text-indigo-800 dark:text-indigo-200 text-xs font-bold",
										children: isAr ? paper.methodologyBadgeAr : paper.methodologyBadgeEn
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "text-2xl sm:text-4xl font-black leading-snug font-['Alexandria']",
									children: displayTitle
								}),
								secondaryTitle && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs sm:text-sm font-semibold italic opacity-80",
									children: secondaryTitle
								}),
								paper && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap gap-1.5 pt-1",
									children: (isAr ? paper.keywordsAr : paper.keywordsEn).map((kw, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: `px-2.5 py-1 rounded-lg text-xs font-bold ${isLight ? "bg-indigo-100/80 text-indigo-900" : "bg-white/10 text-cyan-200"}`,
										children: ["#", kw]
									}, i))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `p-4 rounded-2xl border flex flex-wrap items-center justify-between gap-3 text-xs ${isLight ? "bg-white border-slate-200 text-slate-800" : "bg-black/40 border-white/10 text-cyan-100"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-extrabold flex items-center gap-1.5 text-indigo-700 dark:text-cyan-300",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "w-4 h-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "وحدة الأبحاث والدراسات النفسية المحكّمة — مرآة القلوب" : "Mirror of Hearts Peer-Reviewed Research Unit" })]
										}), paper && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex items-center gap-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "w-3.5 h-3.5 text-amber-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? paper.readTimeAr : paper.readTimeEn })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex items-center gap-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "w-3.5 h-3.5 text-cyan-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: paper.publishDate })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-bold text-emerald-600 dark:text-emerald-400",
												children: [
													"📚 ",
													paper.apaReferences.length,
													" ",
													isAr ? "مرجعاً بصيغة APA 7th" : "APA 7th References"
												]
											})
										] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center gap-2",
										children: [paper && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: handleCopyApaCitation,
											className: "px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer",
											children: [copiedApa ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookMarked, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: copiedApa ? isAr ? "تم نسخ توثيق APA!" : "APA Citation Copied!" : isAr ? "نسخ توثيق APA" : "Copy APA Citation" })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: handleCopyFullManuscript,
											className: "px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer",
											children: [copiedFullText ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: copiedFullText ? isAr ? "تم نسخ النص الكامل!" : "Full Text Copied!" : isAr ? "نسخ البحث كاملاً" : "Copy Full Study" })]
										})]
									})]
								})
							]
						}),
						paper && viewMode === "segmented_and_continuous" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-6 transition-all",
							style: { fontSize: `${fontSize}px` },
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `p-6 rounded-3xl border space-y-2.5 ${isLight ? "bg-amber-50/70 border-amber-200 text-slate-800" : "bg-amber-500/10 border-amber-500/30 text-gray-200"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
										className: "text-lg font-black text-amber-700 dark:text-amber-300 font-['Alexandria'] flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "الملخص (Abstract)" : "Abstract" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "leading-loose",
										children: displayAbstract
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `p-6 rounded-3xl border space-y-3 ${isLight ? "bg-white border-slate-200 text-slate-800 shadow-sm" : "bg-white/[0.02] border-white/10 text-gray-200"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-lg font-black text-indigo-600 dark:text-cyan-300 font-['Alexandria']",
										children: isAr ? "1. المقدمة (Introduction)" : "1. Introduction"
									}), (isAr ? paper.introductionAr : paper.introductionEn).map((p, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "leading-loose",
										children: p
									}, idx))]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `p-6 rounded-3xl border space-y-4 ${isLight ? "bg-white border-slate-200 text-slate-800 shadow-sm" : "bg-white/[0.02] border-white/10 text-gray-200"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-lg font-black text-indigo-600 dark:text-cyan-300 font-['Alexandria']",
										children: isAr ? "2. الإطار النظري والدراسات السابقة (Theoretical Framework)" : "2. Theoretical Framework"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "space-y-4",
										children: paper.theoreticalFramework.map((sec, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: `p-4 rounded-2xl border space-y-2 ${isLight ? "bg-slate-50 border-slate-200" : "bg-black/30 border-white/5"}`,
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
													className: "text-base font-extrabold text-purple-700 dark:text-purple-300",
													children: [
														sec.sectionNumber,
														" ",
														isAr ? sec.titleAr : sec.titleEn
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "leading-relaxed",
													children: isAr ? sec.contentAr : sec.contentEn
												}),
												sec.subPointsAr && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
													className: "space-y-1.5 pt-2",
													children: (isAr ? sec.subPointsAr : sec.subPointsEn || []).map((pt, pIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
														className: "flex items-start gap-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-cyan-500 font-bold",
															children: "•"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: pt })]
													}, pIdx))
												})
											]
										}, idx))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `p-6 rounded-3xl border space-y-3 ${isLight ? "bg-indigo-50/70 border-indigo-200 text-slate-800" : "bg-indigo-950/30 border-indigo-500/30 text-gray-200"}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-lg font-black text-indigo-700 dark:text-indigo-300 font-['Alexandria']",
											children: isAr ? "3. منهجية البحث (Methodology)" : "3. Research Methodology"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-semibold",
											children: isAr ? paper.methodology.approachAr : paper.methodology.approachEn
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
											className: "space-y-2",
											children: (isAr ? paper.methodology.pillarsAr : paper.methodology.pillarsEn).map((pil, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
												className: "flex items-start gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "w-5 h-5 rounded-full bg-indigo-500/20 text-indigo-700 dark:text-indigo-300 text-xs font-bold flex items-center justify-center shrink-0 mt-0.5",
													children: idx + 1
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "leading-relaxed",
													children: pil
												})]
											}, idx))
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `p-6 rounded-3xl border space-y-4 ${isLight ? "bg-white border-slate-200 text-slate-800 shadow-sm" : "bg-white/[0.02] border-white/10 text-gray-200"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-lg font-black text-indigo-600 dark:text-cyan-300 font-['Alexandria']",
										children: isAr ? "4. النتائج والتحليل والمناقشة (Results, Analysis & Discussion)" : "4. Results, Analysis and Discussion"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "space-y-4",
										children: paper.analysisAndDiscussion.map((sec, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: `p-4 rounded-2xl border space-y-2 ${isLight ? "bg-slate-50 border-slate-200" : "bg-black/30 border-white/5"}`,
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
													className: "text-base font-extrabold text-rose-700 dark:text-rose-300",
													children: [
														sec.sectionNumber,
														" ",
														isAr ? sec.titleAr : sec.titleEn
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "leading-relaxed",
													children: isAr ? sec.contentAr : sec.contentEn
												}),
												sec.subPointsAr && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
													className: "space-y-2 pt-2",
													children: (isAr ? sec.subPointsAr : sec.subPointsEn || []).map((pt, pIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
														className: "flex items-start gap-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-rose-500 font-bold",
															children: "▪"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "leading-relaxed",
															children: pt
														})]
													}, pIdx))
												})
											]
										}, idx))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `p-6 rounded-3xl border space-y-2 ${isLight ? "bg-emerald-50 border-emerald-200 text-slate-800" : "bg-emerald-950/30 border-emerald-500/30 text-gray-200"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-lg font-black text-emerald-700 dark:text-emerald-300 font-['Alexandria']",
										children: isAr ? "5. الخاتمة (Conclusion)" : "5. Conclusion"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "leading-loose",
										children: isAr ? paper.conclusionAr : paper.conclusionEn
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `p-6 rounded-3xl border space-y-4 ${isLight ? "bg-white border-slate-200 text-slate-800 shadow-sm" : "bg-white/[0.02] border-white/10 text-gray-200"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
										className: "text-lg font-black text-amber-600 dark:text-amber-300 font-['Alexandria'] flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListChecks, { className: "w-5 h-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "6. التوصيات (Recommendations)" : "6. Recommendations" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-1 gap-3",
										children: paper.recommendations.map((rec, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: `p-4 rounded-2xl border space-y-2 ${isLight ? "bg-slate-50 border-slate-200" : "bg-black/30 border-white/5"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-sm font-extrabold text-indigo-600 dark:text-cyan-300",
												children: isAr ? rec.categoryAr : rec.categoryEn
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
												className: "space-y-1.5",
												children: (isAr ? rec.itemsAr : rec.itemsEn).map((item, iIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
													className: "flex items-start gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-emerald-500 font-bold",
														children: "✓"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "leading-relaxed",
														children: item
													})]
												}, iIdx))
											})]
										}, idx))
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `p-6 sm:p-10 rounded-3xl border-2 space-y-6 shadow-xl ${isLight ? "bg-white border-indigo-200 text-slate-900" : "bg-slate-900/90 border-cyan-500/35 text-gray-100"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-3 border-b pb-4 border-indigo-200 dark:border-white/15",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/15 border border-indigo-500/30 text-indigo-700 dark:text-cyan-300 text-xs font-extrabold",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "النص الأكاديمي الكامل المتواصل (دون تجزئة)" : "Complete Unsegmented Academic Manuscript" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-lg sm:text-2xl font-black font-['Alexandria'] text-indigo-800 dark:text-cyan-300",
										children: isAr ? "📜 المقال البحثي الكامل المتواصل (قراءة أكاديمية متصلة دون تجزئة)" : "📜 Full Continuous Research Study"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: handleCopyFullManuscript,
									className: "px-4 py-2 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs flex items-center gap-1.5 transition cursor-pointer shadow-md",
									children: [copiedFullText ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: copiedFullText ? isAr ? "تم نسخ النص الكامل للبحث!" : "Full Study Copied!" : isAr ? "نسخ النص الكامل المتواصل" : "Copy Full Continuous Text" })]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `p-5 sm:p-8 rounded-2xl border select-text ${isLight ? "bg-slate-50/70 border-slate-200 text-slate-800" : "bg-black/40 border-white/10 text-gray-200"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormattedContinuousManuscript, {
									text: fullStudyContent,
									fontSize,
									isLight
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArticleBottomSocialShare, {
							title: displayTitle,
							summary: displayAbstract,
							url: "https://miratalqulub.com/#/articles",
							isLight,
							language
						})
					]
				})
			})]
		})
	}) });
};
//#endregion
//#region src/pages/ArticlesEncyclopediaPage.tsx
var ArticlesEncyclopediaPage = ({ onBackToHome, onNavigatePage }) => {
	const { language, isRTL, toggleLanguage } = useLanguage();
	const [theme, toggleTheme] = useAppTheme();
	const isLight = theme === "light";
	const [activeTrack, setActiveTrack] = (0, import_react.useState)("narrative");
	const [selectedCategory, setSelectedCategory] = (0, import_react.useState)("all");
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [activeNarrative, setActiveNarrative] = (0, import_react.useState)(null);
	const [activeAcademic, setActiveAcademic] = (0, import_react.useState)(null);
	const [fullScreenPaper, setFullScreenPaper] = (0, import_react.useState)(null);
	const [fullScreenArticle, setFullScreenArticle] = (0, import_react.useState)(null);
	const [copiedShare, setCopiedShare] = (0, import_react.useState)(false);
	const [copiedCitationId, setCopiedCitationId] = (0, import_react.useState)(null);
	const [copiedFullText, setCopiedFullText] = (0, import_react.useState)(false);
	const [copiedStoryFullText, setCopiedStoryFullText] = (0, import_react.useState)(false);
	const [readerFontSize, setReaderFontSize] = (0, import_react.useState)(17);
	const [readerViewMode, setReaderViewMode] = (0, import_react.useState)("segmented_and_continuous");
	(0, import_react.useEffect)(() => {
		const checkDeepLinkedArticle = () => {
			try {
				const hashParts = window.location.hash.replace(/^#\/?/, "").split("/").filter(Boolean);
				const targetId = ((hashParts[0] === "articles" || hashParts[0] === "research") && hashParts[1] ? decodeURIComponent(hashParts[1]) : null) || sessionStorage.getItem("mirat_open_article_id");
				if (targetId) {
					sessionStorage.removeItem("mirat_open_article_id");
					const foundNarrative = ARTICLES_CATALOG.find((a) => a.id === targetId);
					if (foundNarrative) {
						setActiveTrack("narrative");
						setActiveAcademic(null);
						setActiveNarrative(foundNarrative);
						window.scrollTo({
							top: 0,
							behavior: "smooth"
						});
						return;
					}
					const foundAcademic = ACADEMIC_PAPERS_CATALOG.find((p) => p.id === targetId);
					if (foundAcademic) {
						setActiveTrack("academic");
						setActiveNarrative(null);
						setActiveAcademic(foundAcademic);
						window.scrollTo({
							top: 0,
							behavior: "smooth"
						});
					}
				}
			} catch {}
		};
		checkDeepLinkedArticle();
		window.addEventListener("hashchange", checkDeepLinkedArticle);
		return () => window.removeEventListener("hashchange", checkDeepLinkedArticle);
	}, []);
	const featuredGccFamilyStudy = ACADEMIC_PAPERS_CATALOG.find((p) => p.id === "research-gcc-family-based-psychosocial-interventions-chronic-disorders") || null;
	const handleCopyFullText = (paper) => {
		soundManager.playTap();
		const fullText = getFullContinuousAcademicText(paper, language);
		if (navigator.clipboard) {
			navigator.clipboard.writeText(fullText);
			setCopiedFullText(true);
			setTimeout(() => setCopiedFullText(false), 2600);
		}
	};
	const handleCopyStoryFullText = (article) => {
		soundManager.playTap();
		const fullText = getFullContinuousNarrativeText(article, language);
		if (navigator.clipboard) {
			navigator.clipboard.writeText(fullText);
			setCopiedStoryFullText(true);
			setTimeout(() => setCopiedStoryFullText(false), 2600);
		}
	};
	const handleCopyApaCitation = (paper, e) => {
		if (e) e.stopPropagation();
		soundManager.playTap();
		const year = paper.publishDate.slice(0, 4) || "2026";
		const citationText = language === "ar" ? `وحدة الأبحاث والدراسات النفسية - مرآة القلوب. (${year}). ${paper.titleAr}. موسوعة مرآة القلوب للأبحاث النفسية المحكّمة. https://miratalqulub.com/#/articles` : `Mirror of Hearts Psychological Research Unit. (${year}). ${paper.titleEn}. Mirror of Hearts Peer-Reviewed Encyclopedia. https://miratalqulub.com/#/articles`;
		if (navigator.clipboard) {
			navigator.clipboard.writeText(citationText);
			setCopiedCitationId(paper.id);
			setTimeout(() => setCopiedCitationId(null), 2500);
		}
	};
	const categories = [
		{
			key: "all",
			labelAr: "جميع التخصصات",
			labelEn: "All Specialties",
			icon: "✨"
		},
		{
			key: "relationships",
			labelAr: "عيادة العلاقات والزواج",
			labelEn: "Relationships & Marriage",
			icon: "💑"
		},
		{
			key: "applied_psychology",
			labelAr: "علم النفس التطبيقي والعصبي",
			labelEn: "Applied & Neuro-Psychology",
			icon: "🧠"
		},
		{
			key: "self_growth",
			labelAr: "الهوية والاحتراق المبكر",
			labelEn: "Identity & Burnout Recovery",
			icon: "🌱"
		},
		{
			key: "emotional_iq",
			labelAr: "الذكاء العاطفي والتواصل",
			labelEn: "Emotional Intelligence (EQ)",
			icon: "🎯"
		}
	];
	const q = searchQuery.trim().toLowerCase();
	const filteredNarrativeArticles = ARTICLES_CATALOG.filter((art) => {
		const matchesCategory = selectedCategory === "all" || art.category === selectedCategory;
		const matchesQuery = !q || art.title.toLowerCase().includes(q) || art.titleEn.toLowerCase().includes(q) || art.summary.toLowerCase().includes(q) || art.summaryEn.toLowerCase().includes(q) || art.scientificFramework.toLowerCase().includes(q) || art.scientificFrameworkEn.toLowerCase().includes(q);
		return matchesCategory && matchesQuery;
	});
	const filteredAcademicPapers = ACADEMIC_PAPERS_CATALOG.filter((paper) => {
		const matchesCategory = selectedCategory === "all" || paper.category === selectedCategory;
		const matchesQuery = !q || paper.titleAr.toLowerCase().includes(q) || paper.titleEn.toLowerCase().includes(q) || paper.abstractAr.toLowerCase().includes(q) || paper.abstractEn.toLowerCase().includes(q) || paper.keywordsAr.some((k) => k.toLowerCase().includes(q)) || paper.keywordsEn.some((k) => k.toLowerCase().includes(q));
		return matchesCategory && matchesQuery;
	});
	const handleBackToList = () => {
		soundManager.playTap();
		setActiveNarrative(null);
		setActiveAcademic(null);
		window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
	};
	const handleShareContent = (title, summary) => {
		soundManager.playTap();
		const textToShare = `📖 ${title}\n${summary}\nhttps://miratalqulub.com/#/articles`;
		if (navigator.clipboard) {
			navigator.clipboard.writeText(textToShare);
			setCopiedShare(true);
			setTimeout(() => setCopiedShare(false), 2400);
		}
	};
	const isReading = Boolean(activeNarrative || activeAcademic);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full max-w-6xl mx-auto px-4 py-6 sm:py-10 space-y-8",
		dir: isRTL ? "rtl" : "ltr",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageSEO, {
				title: language === "ar" ? "موسوعة مرآة القلوب للمقالات والأبحاث النفسية المحكّمة (APA 7th) | مرآة القلوب" : "Peer-Reviewed Psychological Research Papers & Clinical Articles | Mirror of Hearts",
				description: language === "ar" ? "موسوعة مرآة القلوب للمقالات والأبحاث النفسية: أولاً الأبحاث العلمية الكاملة المحكّمة بتوثيق APA 7th، وثانياً المقالات القصصية العيادية من واقع الجلسات النفسية." : "Mirror of Hearts Encyclopedia: Full peer-reviewed academic research papers (APA 7th) and clinical narrative case studies on relationship compatibility, EQ, and digital psychology.",
				canonicalPath: "/#/articles",
				language
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => {
							soundManager.playTap();
							onBackToHome();
						},
						className: `px-3.5 py-2 rounded-2xl text-xs font-bold flex items-center gap-1.5 border transition cursor-pointer ${isLight ? "bg-white hover:bg-slate-100 text-slate-800 border-slate-300 shadow-sm" : "bg-white/5 hover:bg-white/10 text-gray-200 border-white/10"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, { className: "w-3.5 h-3.5 text-rose-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "الرئيسية" : "Home" })]
					}), isReading && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: handleBackToList,
						className: `px-3.5 py-2 rounded-2xl text-xs font-bold flex items-center gap-1.5 border transition cursor-pointer ${isLight ? "bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border-indigo-200" : "bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-200 border-indigo-400/30"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: `w-3.5 h-3.5 ${!isRTL ? "rotate-180" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "العودة لفهرس الموسوعة" : "Back to Encyclopedia Index" })]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							soundManager.playTap();
							toggleTheme();
						},
						className: `px-3.5 py-2 rounded-2xl text-xs font-extrabold border transition cursor-pointer flex items-center gap-1.5 ${isLight ? "bg-amber-50 hover:bg-amber-100 text-amber-900 border-amber-300 shadow-sm" : "bg-indigo-500/20 hover:bg-indigo-500/30 text-amber-200 border-indigo-400/30"}`,
						children: [isLight ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isLight ? language === "ar" ? "الوضع الليلي" : "Dark Mode" : language === "ar" ? "الوضع النهاري" : "Light Mode" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							soundManager.playTap();
							toggleLanguage();
						},
						className: `px-4 py-2 rounded-2xl text-xs font-extrabold border transition cursor-pointer ${isLight ? "bg-white hover:bg-slate-100 text-slate-900 border-slate-300 shadow-sm" : "bg-white/10 hover:bg-white/20 text-white border-white/15"}`,
						children: language === "ar" ? "Read in English 🇬🇧" : "القراءة باللغة العربية 🇸🇦"
					})]
				})]
			}),
			!isReading && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `p-6 sm:p-8 rounded-3xl border space-y-5 shadow-xl ${isLight ? "bg-gradient-to-br from-indigo-50 via-white to-rose-50 border-slate-200 text-slate-900" : "bg-gradient-to-br from-purple-950/60 via-slate-900/90 to-indigo-950/60 border-white/15 text-white"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-14 h-14 rounded-2xl p-0.5 bg-gradient-to-tr from-rose-500 via-pink-500 to-violet-600 shadow-lg shadow-rose-500/25 shrink-0 overflow-hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-full h-full rounded-[14px] bg-[#0b0e17] overflow-hidden flex items-center justify-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: OFFICIAL_LOGO_URL,
									alt: language === "ar" ? "شعار مرآة القلوب الرسمي" : "Mirror of Hearts Official Logo",
									className: "w-full h-full object-cover rounded-[14px]"
								})
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2 mb-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "px-3 py-1 rounded-full bg-indigo-500/15 border border-indigo-500/30 text-indigo-700 dark:text-cyan-300 text-xs font-extrabold flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "قسم المقالات المعرفية والأبحاث العلمية المحكّمة" : "Knowledge Articles & Peer-Reviewed Research Section" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-700 dark:text-emerald-300 text-xs font-bold",
								children: language === "ar" ? "توثيق مرجعي APA 7th Edition" : "APA 7th Edition Verified"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-2xl sm:text-4xl font-black font-['Alexandria'] leading-tight",
							children: language === "ar" ? "محتوى معرفي يعزز الوعي الذاتي والعلاقات الإنسانية" : "Knowledge Content Elevating Self-Awareness & Human Relationships"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: `text-sm sm:text-base max-w-4xl leading-relaxed ${isLight ? "text-slate-600" : "text-gray-300"}`,
						children: language === "ar" ? "يقدم قسم المقالات المعرفية محتوى متخصصاً ومبسطاً يتناول موضوعات الشخصية والعلاقات الإنسانية والتوافق النفسي والتطوير الذاتي، بالإضافة إلى الأبحاث العلمية المحكّمة، بهدف إثراء معرفة القارئ ومساعدته على فهم نفسه والآخرين بصورة أعمق." : "The Knowledge Articles & Research section offers specialized yet accessible content covering personality, human relationships, psychological compatibility, and self-development alongside peer-reviewed studies."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 md:grid-cols-2 gap-4 pt-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `p-4 rounded-2xl border space-y-2 ${isLight ? "bg-white/90 border-slate-200" : "bg-slate-950/60 border-white/10"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-xs sm:text-sm font-black font-['Alexandria'] text-emerald-600 dark:text-emerald-400",
								children: language === "ar" ? "مميزات القسم:" : "Section Features:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-xs font-semibold",
								children: (language === "ar" ? [
									"مقالات متخصصة باللغة العربية",
									"أسلوب واضح وسهل القراءة",
									"موضوعات متنوعة ومفيدة",
									"محتوى متجدد باستمرار",
									"تركيز على التطبيق العملي",
									"مناسب لمختلف القراء"
								] : [
									"Specialized Arabic & English articles",
									"Clear and readable style",
									"Diverse & practical topics",
									"Continuously updated content",
									"Focus on real-life application",
									"Accessible for all readers"
								]).map((item, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-emerald-500 font-bold",
										children: "✓"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item })]
								}, idx))
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `p-4 rounded-2xl border space-y-2 ${isLight ? "bg-white/90 border-slate-200" : "bg-slate-950/60 border-white/10"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-xs sm:text-sm font-black font-['Alexandria'] text-indigo-600 dark:text-indigo-300",
								children: language === "ar" ? "ماذا ستجد في هذا القسم؟" : "What You Will Find Here:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-1.5",
								children: (language === "ar" ? [
									"مقالات تحليل الشخصية",
									"مقالات العلاقات الإنسانية",
									"مقالات التوافق الزواجي والعاطفي",
									"مقالات التطوير الذاتي",
									"مهارات التواصل",
									"الذكاء العاطفي",
									"نصائح وإرشادات عملية"
								] : [
									"Personality Analysis Articles",
									"Human Relationships",
									"Marital & Emotional Compatibility",
									"Self-Development",
									"Communication Skills",
									"Emotional Intelligence",
									"Practical Guidance"
								]).map((tag, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `px-2.5 py-1 rounded-xl text-[11px] font-bold border ${isLight ? "bg-indigo-50 border-indigo-200 text-indigo-800" : "bg-indigo-500/15 border-indigo-500/30 text-indigo-200"}`,
									children: tag
								}, idx))
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `p-4 sm:p-5 rounded-3xl border space-y-3.5 ${isLight ? "bg-gradient-to-r from-teal-50/90 via-white to-emerald-50/80 border-teal-300 shadow-sm" : "bg-gradient-to-r from-teal-950/55 via-slate-900/85 to-emerald-950/45 border-teal-500/35 shadow-lg"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-0.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-black bg-teal-500/15 text-teal-800 dark:text-teal-300 border border-teal-500/30",
									children: [
										"🩺",
										" ",
										language === "ar" ? `سلسلة علم النفس الإكلينيكي ونمو الطفل والقلق النفسي (${CLINICAL_CHILDHOOD_ANXIETY_NARRATIVE_ARTICLES.length} مقالات ودراسات سريرية)` : `Clinical Psychology, Child Development & Anxiety Series (${CLINICAL_CHILDHOOD_ANXIETY_NARRATIVE_ARTICLES.length} Clinical Studies)`
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: `text-sm sm:text-base font-black font-['Alexandria'] ${isLight ? "text-slate-900" : "text-white"}`,
									children: language === "ar" ? "الأبحاث الإكلينيكية المتعمقة: أثر الطفولة في البلوغ، تشريح القلق النفسي، والتفكير الزائد في ضوء الخصوصية الثقافية العربية" : "In-Depth Clinical Studies: Childhood Impact on Adulthood, Anatomy of Psychological Anxiety & Overthinking in Arab Contexts"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									soundManager.playTap();
									setSelectedCategory("all");
									setActiveTrack("narrative");
								},
								className: `text-[11px] font-bold px-3 py-1 rounded-xl border transition cursor-pointer ${isLight ? "bg-teal-100 hover:bg-teal-200 text-teal-900 border-teal-300" : "bg-teal-500/20 hover:bg-teal-500/30 text-teal-200 border-teal-500/40"}`,
								children: language === "ar" ? "عرض السلسلة الإكلينيكية ←" : "View Clinical Series →"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5",
							children: CLINICAL_CHILDHOOD_ANXIETY_NARRATIVE_ARTICLES.map((art, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									soundManager.playTap();
									setSelectedCategory(art.category);
									setActiveTrack("narrative");
									setActiveAcademic(null);
									setActiveNarrative(art);
								},
								className: `p-3.5 rounded-2xl border text-start transition cursor-pointer flex flex-col justify-between gap-2 group ${isLight ? "bg-white hover:bg-teal-50/70 border-slate-200 hover:border-teal-400 text-slate-900 shadow-xs" : "bg-slate-950/70 hover:bg-teal-950/50 border-white/10 hover:border-teal-400/50 text-white"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-lg",
											children: art.icon
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `px-2 py-0.5 rounded-full text-[10px] font-extrabold ${isLight ? "bg-teal-100 text-teal-800" : "bg-teal-500/20 text-teal-300"}`,
											children: language === "ar" ? `الدراسة الإكلينيكية ${index + 1}` : `Clinical Study ${index + 1}`
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-xs sm:text-[13px] font-black font-['Alexandria'] leading-snug group-hover:text-teal-600 dark:group-hover:text-teal-300 transition-colors",
										children: language === "ar" ? art.title : art.titleEn
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between pt-1.5 border-t border-slate-200/70 dark:border-white/10 text-[10px] font-bold text-teal-600 dark:text-teal-300",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? art.readTime : art.readTimeEn }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "اقرأ الدراسة ←" : "Read Study →" })]
								})]
							}, art.id))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `p-4 sm:p-5 rounded-3xl border space-y-3.5 ${isLight ? "bg-gradient-to-r from-cyan-50/90 via-white to-indigo-50/80 border-cyan-200 shadow-sm" : "bg-gradient-to-r from-cyan-950/50 via-slate-900/80 to-indigo-950/40 border-cyan-500/30 shadow-lg"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-0.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-black bg-cyan-500/15 text-cyan-700 dark:text-cyan-300 border border-cyan-500/30",
									children: [
										"🔬",
										" ",
										language === "ar" ? "المقالات التعريفية عن الموقع — المنهجية العلمية وبناء المقاييس (مقالان)" : "Platform Introductory Articles — Scientific Foundations & Psychometric Design (2 Articles)"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: `text-sm sm:text-base font-black font-['Alexandria'] ${isLight ? "text-slate-900" : "text-white"}`,
									children: language === "ar" ? "الأسس العلمية لاختبارات مرآة القلوب وكيف تُبنى الاختبارات النفسية المعتمدة علمياً؟" : "Scientific Foundations of Mirror of Hearts & How Scientifically Validated Psychological Tests Are Built"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									soundManager.playTap();
									setSelectedCategory("applied_psychology");
									setActiveTrack("narrative");
								},
								className: `text-[11px] font-bold px-3 py-1 rounded-xl border transition cursor-pointer ${isLight ? "bg-cyan-100 hover:bg-cyan-200 text-cyan-900 border-cyan-300" : "bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-200 border-cyan-500/40"}`,
								children: language === "ar" ? "عرض المقالات التعريفية ←" : "View Introductory Articles →"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-1 md:grid-cols-2 gap-3",
							children: PLATFORM_INTRODUCTORY_ARTICLES.map((art, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									soundManager.playTap();
									setSelectedCategory("applied_psychology");
									setActiveTrack("narrative");
									setActiveAcademic(null);
									setActiveNarrative(art);
								},
								className: `p-4 rounded-2xl border text-start transition cursor-pointer flex flex-col justify-between gap-2.5 group ${isLight ? "bg-white hover:bg-cyan-50/70 border-slate-200 hover:border-cyan-400 text-slate-900 shadow-xs" : "bg-slate-950/70 hover:bg-cyan-950/50 border-white/10 hover:border-cyan-400/50 text-white"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xl",
												children: art.icon
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `px-2.5 py-0.5 rounded-full text-[10px] font-extrabold ${isLight ? "bg-cyan-100 text-cyan-800" : "bg-cyan-500/20 text-cyan-300"}`,
												children: language === "ar" ? `المقال التعريفي ${index + 1}` : `Intro Article ${index + 1}`
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-xs sm:text-sm font-black font-['Alexandria'] leading-snug group-hover:text-cyan-600 dark:group-hover:text-cyan-300 transition-colors",
											children: language === "ar" ? art.title : art.titleEn
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: `text-[11px] leading-relaxed line-clamp-2 ${isLight ? "text-slate-600" : "text-slate-300"}`,
											children: language === "ar" ? art.summary : art.summaryEn
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between pt-2 border-t border-slate-200/70 dark:border-white/10 text-[10px] font-bold text-cyan-600 dark:text-cyan-300",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? art.readTime : art.readTimeEn }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "اقرأ المقال التعريفي كاملاً ←" : "Read Full Article →" })]
								})]
							}, art.id))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `p-4 sm:p-5 rounded-3xl border space-y-3.5 ${isLight ? "bg-gradient-to-r from-amber-50/90 via-white to-violet-50/80 border-amber-200 shadow-sm" : "bg-gradient-to-r from-amber-950/50 via-slate-900/80 to-violet-950/40 border-amber-500/30 shadow-lg"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-0.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-black bg-amber-500/15 text-amber-800 dark:text-amber-300 border border-amber-500/30",
									children: [
										"🧠",
										" ",
										language === "ar" ? "سلسلة الذكاء العاطفي وعلم النفس السلوكي — موسوعة متكاملة (6 مقالات شاملة)" : "Emotional Intelligence & Behavioral Psychology — Complete 6-Article Series"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: `text-sm sm:text-base font-black font-['Alexandria'] ${isLight ? "text-slate-900" : "text-white"}`,
									children: language === "ar" ? "سلسلة الذكاء العاطفي: من الجذور العصبية والقياس السيكومتري إلى الزواج، الثقة بالنفس، وإدارة الضغوط" : "Emotional Intelligence Series: From Neural Roots & Measurement to Marriage, Self-Confidence & Stress Mastery"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									soundManager.playTap();
									setSelectedCategory("emotional_iq");
									setActiveTrack("narrative");
								},
								className: `text-[11px] font-bold px-3 py-1 rounded-xl border transition cursor-pointer ${isLight ? "bg-amber-100 hover:bg-amber-200 text-amber-900 border-amber-300" : "bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 border-amber-500/40"}`,
								children: language === "ar" ? "عرض قسم الذكاء العاطفي ←" : "Filter Emotional IQ Category →"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5",
							children: EMOTIONAL_IQ_NARRATIVE_ARTICLES.map((art, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									soundManager.playTap();
									setSelectedCategory("emotional_iq");
									setActiveTrack("narrative");
									setActiveAcademic(null);
									setActiveNarrative(art);
								},
								className: `p-3.5 rounded-2xl border text-start transition cursor-pointer flex flex-col justify-between gap-2 group ${isLight ? "bg-white hover:bg-amber-50/70 border-slate-200 hover:border-amber-400 text-slate-900 shadow-xs" : "bg-slate-950/70 hover:bg-amber-950/50 border-white/10 hover:border-amber-400/50 text-white"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-lg",
											children: art.icon
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `px-2 py-0.5 rounded-full text-[10px] font-extrabold ${isLight ? "bg-amber-100 text-amber-800" : "bg-amber-500/20 text-amber-300"}`,
											children: language === "ar" ? `المقال ${index + 1} من 6` : `EQ Article ${index + 1} of 6`
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-xs sm:text-[13px] font-black font-['Alexandria'] leading-snug group-hover:text-amber-600 dark:group-hover:text-amber-300 transition-colors",
										children: language === "ar" ? art.title : art.titleEn
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between pt-1.5 border-t border-slate-200/70 dark:border-white/10 text-[10px] font-bold text-amber-600 dark:text-amber-300",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? art.readTime : art.readTimeEn }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "اقرأ المقال ←" : "Read →" })]
								})]
							}, art.id))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `p-4 sm:p-5 rounded-3xl border space-y-3.5 ${isLight ? "bg-gradient-to-r from-rose-50/90 via-white to-amber-50/80 border-rose-200 shadow-sm" : "bg-gradient-to-r from-rose-950/50 via-slate-900/80 to-purple-950/40 border-rose-500/30 shadow-lg"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-0.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-black bg-rose-500/15 text-rose-700 dark:text-rose-300 border border-rose-500/30",
									children: [
										"💞",
										" ",
										language === "ar" ? "قسم العلاقات والزواج — سلسلة علمية متكاملة (4 مقالات + خاتمة واعية)" : "Relationships & Marriage — Complete 4-Article Series"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: `text-sm sm:text-base font-black font-['Alexandria'] ${isLight ? "text-slate-900" : "text-white"}`,
									children: language === "ar" ? "موسوعة العلاقات الواعية: التوافق العاطفي، أنماط التعلق، الحب الصحي، والتشريح العلمي لانهيار العلاقات" : "Conscious Relationships: Emotional Compatibility, Attachment Styles, Healthy Love & Anatomy of Failure"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									soundManager.playTap();
									setSelectedCategory("relationships");
									setActiveTrack("narrative");
								},
								className: `text-[11px] font-bold px-3 py-1 rounded-xl border transition cursor-pointer ${isLight ? "bg-rose-100 hover:bg-rose-200 text-rose-900 border-rose-300" : "bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 border-rose-500/40"}`,
								children: language === "ar" ? "عرض قسم مقالات العلاقات ←" : "Filter Relationships Category →"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5",
							children: RELATIONSHIP_FOUR_NARRATIVE_ARTICLES.map((art, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									soundManager.playTap();
									setSelectedCategory("relationships");
									setActiveTrack("narrative");
									setActiveAcademic(null);
									setActiveNarrative(art);
								},
								className: `p-3.5 rounded-2xl border text-start transition cursor-pointer flex flex-col justify-between gap-2 group ${isLight ? "bg-white hover:bg-rose-50/70 border-slate-200 hover:border-rose-400 text-slate-900 shadow-xs" : "bg-slate-950/70 hover:bg-rose-950/50 border-white/10 hover:border-rose-400/50 text-white"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-lg",
											children: art.icon
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `px-2 py-0.5 rounded-full text-[10px] font-extrabold ${isLight ? "bg-rose-100 text-rose-800" : "bg-rose-500/20 text-rose-300"}`,
											children: language === "ar" ? `مقال العلاقات ${index + 1}` : `Rel. Article ${index + 1}`
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-xs sm:text-[13px] font-black font-['Alexandria'] leading-snug group-hover:text-rose-600 dark:group-hover:text-rose-300 transition-colors",
										children: language === "ar" ? art.title : art.titleEn
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between pt-1.5 border-t border-slate-200/70 dark:border-white/10 text-[10px] font-bold text-rose-600 dark:text-rose-300",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? art.readTime : art.readTimeEn }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "اقرأ المقال ←" : "Read →" })]
								})]
							}, art.id))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `p-4 sm:p-5 rounded-3xl border space-y-3.5 ${isLight ? "bg-gradient-to-r from-indigo-50/90 via-white to-emerald-50/80 border-indigo-200 shadow-sm" : "bg-gradient-to-r from-indigo-950/50 via-slate-900/80 to-emerald-950/40 border-indigo-500/30 shadow-lg"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-0.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-black bg-indigo-500/15 text-indigo-700 dark:text-indigo-300 border border-indigo-500/30",
									children: [
										"📚",
										" ",
										language === "ar" ? "سلسلة علمية متكاملة (4 مقالات مقسمة)" : "Complete 4-Article Scientific Series"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: `text-sm sm:text-base font-black font-['Alexandria'] ${isLight ? "text-slate-900" : "text-white"}`,
									children: language === "ar" ? "من النفس الباطنة إلى العقل القيادي: تحليل علمي متكامل لأنواع الشخصية عبر العوامل الخمسة" : "From the Inner Psyche to the Leadership Mind: Integrated Scientific Analysis Across the Big Five"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `text-[11px] font-bold px-2.5 py-1 rounded-xl border ${isLight ? "bg-emerald-50 text-emerald-800 border-emerald-200" : "bg-emerald-500/15 text-emerald-300 border-emerald-500/30"}`,
								children: language === "ar" ? "اختر أياً من المقالات الـ 4 لقراءته فوراً" : "Select any of the 4 articles"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5",
							children: PDF_FOUR_NARRATIVE_ARTICLES.map((art, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									soundManager.playTap();
									setActiveTrack("narrative");
									setActiveAcademic(null);
									setActiveNarrative(art);
								},
								className: `p-3.5 rounded-2xl border text-start transition cursor-pointer flex flex-col justify-between gap-2 group ${isLight ? "bg-white hover:bg-indigo-50/70 border-slate-200 hover:border-indigo-400 text-slate-900 shadow-xs" : "bg-slate-950/70 hover:bg-indigo-950/50 border-white/10 hover:border-indigo-400/50 text-white"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-lg",
											children: art.icon
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `px-2 py-0.5 rounded-full text-[10px] font-extrabold ${isLight ? "bg-indigo-100 text-indigo-800" : "bg-indigo-500/20 text-indigo-300"}`,
											children: language === "ar" ? `مقال ${index + 1} من 4` : `Article ${index + 1} of 4`
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-xs sm:text-[13px] font-black font-['Alexandria'] leading-snug group-hover:text-indigo-600 dark:group-hover:text-indigo-300 transition-colors",
										children: language === "ar" ? art.title : art.titleEn
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between pt-1.5 border-t border-slate-200/70 dark:border-white/10 text-[10px] font-bold text-indigo-600 dark:text-indigo-300",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? art.readTime : art.readTimeEn }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "اقرأ المقال ←" : "Read →" })]
								})]
							}, art.id))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 md:grid-cols-2 gap-4 pt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								soundManager.playTap();
								setActiveTrack("academic");
							},
							className: `p-5 rounded-3xl border text-start transition cursor-pointer flex items-start gap-4 ${activeTrack === "academic" ? isLight ? "bg-gradient-to-r from-indigo-700 to-cyan-700 text-white border-indigo-600 shadow-xl" : "bg-gradient-to-r from-indigo-600/40 to-cyan-600/35 text-white border-cyan-400 shadow-xl" : isLight ? "bg-white hover:bg-slate-50 text-slate-800 border-slate-200 shadow-sm" : "bg-white/[0.03] hover:bg-white/[0.06] text-gray-300 border-white/10"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 ${activeTrack === "academic" ? "bg-white/20 text-white" : "bg-cyan-500/15 text-cyan-500"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "w-6 h-6" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-black text-base sm:text-lg font-['Alexandria']",
										children: language === "ar" ? "أولاً: الأبحاث العلمية الكاملة (APA 7th)" : "First: Full Academic Research Papers"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: `px-2.5 py-0.5 rounded-full text-xs font-extrabold ${activeTrack === "academic" ? "bg-white/25 text-white" : "bg-cyan-500/15 text-cyan-500"}`,
										children: [
											ACADEMIC_PAPERS_CATALOG.length,
											" ",
											language === "ar" ? "أبحاث محكّمة" : "Papers"
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: `text-xs sm:text-sm mt-1.5 leading-relaxed ${activeTrack === "academic" ? "text-white/95" : isLight ? "text-slate-600" : "text-gray-400"}`,
									children: language === "ar" ? "دراسات بحثية أكاديمية متكاملة (ملخص، مقدمة، إطار نظري، منهجية، تحليل ومناقشة، توصيات، ومراجع APA 7th)." : "Complete scholarly research papers (Abstract, Introduction, Theoretical Framework, Methodology, Analysis, & APA 7th References)."
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								soundManager.playTap();
								setActiveTrack("narrative");
							},
							className: `p-5 rounded-3xl border text-start transition cursor-pointer flex items-start gap-4 ${activeTrack === "narrative" ? isLight ? "bg-gradient-to-r from-rose-600 to-purple-600 text-white border-rose-600 shadow-xl" : "bg-gradient-to-r from-rose-600/35 to-purple-600/35 text-white border-rose-400 shadow-xl" : isLight ? "bg-white hover:bg-slate-50 text-slate-800 border-slate-200 shadow-sm" : "bg-white/[0.03] hover:bg-white/[0.06] text-gray-300 border-white/10"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 ${activeTrack === "narrative" ? "bg-white/20 text-white" : "bg-rose-500/15 text-rose-500"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stethoscope, { className: "w-6 h-6" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-black text-base sm:text-lg font-['Alexandria']",
										children: language === "ar" ? "ثانياً: المقالات القصصية العلمية" : "Second: Clinical Narrative Articles"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: `px-2.5 py-0.5 rounded-full text-xs font-extrabold ${activeTrack === "narrative" ? "bg-white/25 text-white" : "bg-rose-500/15 text-rose-500"}`,
										children: [
											ARTICLES_CATALOG.length,
											" ",
											language === "ar" ? "مقالاً" : "Articles"
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: `text-xs sm:text-sm mt-1.5 leading-relaxed ${activeTrack === "narrative" ? "text-white/95" : isLight ? "text-slate-600" : "text-gray-400"}`,
									children: language === "ar" ? "جولات داخل عيادة العلاج النفسي والأسري: قصص واقعية، تفكيك سيكولوجي، واختبارات سلوكية عملية." : "Inside the psychotherapy clinic: real-world case narratives, psychological deconstruction, and practical behavioral tests."
								})]
							})]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, {
				mode: "wait",
				children: !isReading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: { opacity: 0 },
					animate: { opacity: 1 },
					exit: { opacity: 0 },
					className: "space-y-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: `w-4 h-4 text-gray-400 absolute top-3.5 ${isRTL ? "right-4" : "left-4"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "text",
										value: searchQuery,
										onChange: (e) => setSearchQuery(e.target.value),
										placeholder: language === "ar" ? "ابحث في المقالات والأبحاث (غوتمان، التوافق، الانهيار النرجسي، الذكاء الاصطناعي، الاحتراق، تيك توك)..." : "Search articles & research papers (Gottman, compatibility, narcissistic collapse, AI dependency, burnout)...",
										className: `w-full ${isRTL ? "pr-11 pl-4" : "pl-11 pr-4"} py-3.5 rounded-2xl border text-sm focus:outline-none transition ${isLight ? "bg-white border-slate-300 text-slate-900 placeholder-slate-400 focus:border-indigo-600 shadow-sm" : "bg-white/5 border-white/15 text-white placeholder-gray-400 focus:border-purple-400"}`
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center gap-2 overflow-x-auto pb-1",
									children: categories.map((cat) => {
										const isSelected = selectedCategory === cat.key;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => {
												soundManager.playTap();
												setSelectedCategory(cat.key);
											},
											className: `shrink-0 px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer ${isSelected ? "bg-gradient-to-r from-purple-600 to-rose-600 text-white shadow-md" : isLight ? "bg-white hover:bg-slate-100 text-slate-700 border border-slate-200" : "bg-white/5 hover:bg-white/10 text-gray-300 border border-white/10"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: cat.icon }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? cat.labelAr : cat.labelEn })]
										}, cat.key);
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "pt-1 space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReaderToolbar, {
										fontSize: readerFontSize,
										onChangeFontSize: setReaderFontSize,
										viewMode: readerViewMode,
										onChangeViewMode: setReaderViewMode,
										shareTitle: language === "ar" ? "موسوعة مرآة القلوب للمقالات والأبحاث النفسية المحكّمة" : "Mirror of Hearts Encyclopedia of Peer-Reviewed Research & Clinical Articles",
										shareSummary: language === "ar" ? "أبحاث علمية محكّمة بصيغة APA 7th ودراسات حالة عيادية وقصصية كاملة مع قارئ متكامل يدعم التحكم بحجم الخط والوضع الليلي." : "Peer-reviewed APA 7th research papers and clinical case studies with an integrated reader supporting font-size control and Dark/Light mode.",
										shareUrl: "https://miratalqulub.com/#/articles",
										contentTypeLabelAr: "للمقالات والأبحاث",
										contentTypeLabelEn: "Articles & Papers"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `p-3 rounded-2xl border flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 text-xs ${isLight ? "bg-slate-50 border-slate-200 text-slate-700" : "bg-white/[0.03] border-white/10 text-gray-300"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 font-extrabold text-indigo-700 dark:text-cyan-300",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "w-4 h-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "القارئ المتكامل السريع — اختر بحثاً أو مقالاً لفتحه مباشرة:" : "Integrated Quick Reader — Select a study or article to open directly:" })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex flex-wrap items-center gap-2",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
												"aria-label": language === "ar" ? "اختر بحثاً علمياً أو مقالاً لفتحه في القارئ المتكامل" : "Select a research paper or article to open in the integrated reader",
												value: "",
												onChange: (e) => {
													const val = e.target.value;
													if (!val) return;
													soundManager.playTap();
													if (val.startsWith("paper:")) {
														const paperId = val.replace("paper:", "");
														const foundPaper = ACADEMIC_PAPERS_CATALOG.find((p) => p.id === paperId);
														if (foundPaper) {
															setActiveAcademic(foundPaper);
															window.scrollTo({
																top: 0,
																behavior: "smooth"
															});
														}
													} else if (val.startsWith("article:")) {
														const artId = val.replace("article:", "");
														const foundArt = ARTICLES_CATALOG.find((a) => a.id === artId);
														if (foundArt) {
															setActiveNarrative(foundArt);
															window.scrollTo({
																top: 0,
																behavior: "smooth"
															});
														}
													}
												},
												className: `px-3 py-2 rounded-xl border text-xs font-bold focus:outline-none cursor-pointer max-w-xs sm:max-w-md truncate ${isLight ? "bg-white border-slate-300 text-slate-800" : "bg-slate-900 border-white/15 text-white"}`,
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "",
														children: language === "ar" ? "📖 اختر من قائمة الأبحاث المحكّمة والمقالات السريرية..." : "📖 Choose from Peer-Reviewed Papers & Clinical Articles..."
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("optgroup", {
														label: language === "ar" ? "أولاً: الأبحاث العلمية المحكّمة (APA 7th)" : "1. Peer-Reviewed Research Papers (APA 7th)",
														children: ACADEMIC_PAPERS_CATALOG.map((p, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
															value: `paper:${p.id}`,
															children: [
																idx + 1,
																". ",
																language === "ar" ? p.titleAr : p.titleEn
															]
														}, p.id))
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("optgroup", {
														label: language === "ar" ? "ثانياً: المقالات والسجلات القصصية السريرية" : "2. Clinical Narrative Articles & Case Records",
														children: ARTICLES_CATALOG.map((a, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
															value: `article:${a.id}`,
															children: [
																idx + 1,
																". ",
																language === "ar" ? a.title : a.titleEn
															]
														}, a.id))
													})
												]
											})
										})]
									})]
								})
							]
						}),
						activeTrack === "narrative" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-1 md:grid-cols-2 gap-5",
							children: filteredNarrativeArticles.map((art) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.article, {
								whileHover: {
									scale: 1.01,
									y: -3
								},
								onClick: () => {
									soundManager.playTap();
									setActiveNarrative(art);
									window.scrollTo({
										top: 0,
										behavior: "smooth"
									});
								},
								className: `p-6 rounded-3xl border transition cursor-pointer flex flex-col justify-between space-y-4 group shadow-md ${isLight ? "bg-white hover:bg-rose-50/40 border-slate-200 hover:border-rose-400" : "bg-white/[0.03] hover:bg-white/[0.06] border-white/10 hover:border-rose-500/40"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between gap-2 flex-wrap",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "px-3 py-1 rounded-xl bg-rose-500/15 text-rose-600 dark:text-rose-300 text-xs font-bold border border-rose-500/30 flex items-center gap-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: art.icon }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? art.categoryLabelAr : art.categoryLabelEn })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-xs text-amber-600 dark:text-amber-400 font-semibold flex items-center gap-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? art.readTime : art.readTimeEn })]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: `text-base sm:text-lg font-black leading-snug font-['Alexandria'] ${isLight ? "text-slate-900 group-hover:text-rose-600" : "text-white group-hover:text-rose-300"}`,
											children: language === "ar" ? art.title : art.titleEn
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: `text-xs sm:text-sm line-clamp-3 leading-relaxed ${isLight ? "text-slate-600" : "text-gray-300"}`,
											children: language === "ar" ? art.summary : art.summaryEn
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `pt-3 border-t flex flex-wrap items-center justify-between gap-2 text-xs ${isLight ? "border-slate-200" : "border-white/10"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[11px] text-purple-600 dark:text-purple-300 font-semibold truncate max-w-[55%]",
										children: ["🔬 ", language === "ar" ? art.scientificFramework : art.scientificFrameworkEn]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center gap-2 shrink-0",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: (e) => {
													e.stopPropagation();
													soundManager.playTap();
													setFullScreenArticle(art);
												},
												className: "px-2.5 py-1 rounded-xl bg-gradient-to-r from-rose-600 to-purple-600 hover:from-rose-500 hover:to-purple-500 text-white text-[11px] font-extrabold flex items-center gap-1 shadow-sm transition cursor-pointer",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "w-3 h-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "ملء الشاشة" : "Full Screen" })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: (e) => {
													e.stopPropagation();
													soundManager.playTap();
													setReaderViewMode("continuous_only");
													setActiveNarrative(art);
													window.scrollTo({
														top: 0,
														behavior: "smooth"
													});
												},
												className: `px-2.5 py-1 rounded-xl text-[11px] font-bold border transition cursor-pointer ${isLight ? "bg-rose-50 hover:bg-rose-100 text-rose-700 border-rose-200" : "bg-rose-500/15 hover:bg-rose-500/25 text-rose-200 border-rose-400/30"}`,
												children: ["📜 ", language === "ar" ? "قراءة كاملة دون تجزئة" : "Full Unsegmented"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-rose-600 dark:text-rose-400 font-extrabold flex items-center gap-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "قراءة المقال" : "Read" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: `w-4 h-4 ${isRTL ? "rotate-180" : ""}` })]
											})
										]
									})]
								})]
							}, art.id))
						}),
						activeTrack === "academic" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `p-5 sm:p-6 rounded-3xl border space-y-3 ${isLight ? "bg-gradient-to-r from-indigo-50 via-cyan-50/60 to-slate-50 border-indigo-200 text-slate-800 shadow-sm" : "bg-gradient-to-r from-indigo-950/50 via-slate-900/80 to-cyan-950/40 border-cyan-500/30 text-gray-200"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 text-indigo-700 dark:text-cyan-300 font-black text-sm sm:text-base font-['Alexandria']",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "w-5 h-5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "ميثاق الأبحاث العلمية الكاملة ومنهجية التوثيق المرجعي (APA 7th Edition)" : "Full Academic Research Charter & Peer-Review Methodology (APA 7th Edition)" })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-700 dark:text-emerald-300 text-xs font-extrabold",
											children: language === "ar" ? "إشراف: وحدة الأبحاث والدراسات النفسية — مرآة القلوب" : "Supervised by: Mirror of Hearts Psychological Research Unit"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs sm:text-sm leading-relaxed opacity-90",
										children: language === "ar" ? "يضم هذا القسم أوراقاً بحثية ودراسات نفسية وعصبية متكاملة مصاغة وفق المعايير الأكاديمية المحكّمة: (الملخص، الكلمات المفتاحية، المقدمة والإشكالية البحثية، الإطار النظري والدراسات السابقة، منهجية البحث، التحليل والمناقشة، الخاتمة، التوصيات السريرية والتشريعية، وقائمة المراجع بصيغة APA 7th). جميع الأبحاث متاحة للقراءة الكاملة والاستشهاد العلمي المباشر." : "This section houses complete peer-reviewed psychological and neuroscientific papers structured according to rigorous academic standards: Abstract, Keywords, Introduction & Research Problem, Theoretical Framework, Methodology, Analysis & Discussion, Conclusion, Multi-Tier Recommendations, and verified APA 7th References."
									})]
								}),
								featuredGccFamilyStudy && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `p-6 sm:p-7 rounded-3xl border-2 space-y-4 shadow-xl transition-all ${isLight ? "bg-gradient-to-br from-indigo-50 via-white to-emerald-50/70 border-indigo-300 text-slate-900" : "bg-gradient-to-br from-indigo-950/60 via-slate-900/95 to-emerald-950/45 border-cyan-400/45 text-white"}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap items-center justify-between gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex flex-wrap items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "px-3 py-1 rounded-full bg-indigo-600 text-white text-xs font-black flex items-center gap-1.5 shadow-sm",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "دراسة مرجعية مميزة — العرض الكامل بملء الشاشة" : "Featured Reference Study — Full-Screen Scrollable View" })]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-700 dark:text-emerald-300 text-xs font-extrabold",
													children: language === "ar" ? featuredGccFamilyStudy.methodologyBadgeAr : featuredGccFamilyStudy.methodologyBadgeEn
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-xs font-bold text-amber-600 dark:text-amber-300 flex items-center gap-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? featuredGccFamilyStudy.readTimeAr : featuredGccFamilyStudy.readTimeEn })]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-lg sm:text-2xl font-black leading-snug font-['Alexandria']",
											children: language === "ar" ? featuredGccFamilyStudy.titleAr : featuredGccFamilyStudy.titleEn
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: `text-xs sm:text-sm leading-relaxed ${isLight ? "text-slate-700" : "text-gray-200"}`,
											children: language === "ar" ? featuredGccFamilyStudy.abstractAr : featuredGccFamilyStudy.abstractEn
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-indigo-200/70 dark:border-white/10",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex flex-wrap items-center gap-2 text-xs",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "font-bold text-indigo-700 dark:text-cyan-300",
													children: [
														"🎛️",
														" ",
														language === "ar" ? "يدعم التحكم بحجم الخط (A-/A+) • الوضع الليلي/النهاري • المشاركة الاجتماعية" : "Supports Font-Size Control • Dark/Light Mode • Social Sharing"
													]
												})
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex flex-wrap items-center gap-2.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													onClick: () => {
														soundManager.playTap();
														setFullScreenPaper(featuredGccFamilyStudy);
													},
													className: "px-4 py-2.5 rounded-2xl bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white text-xs sm:text-sm font-extrabold flex items-center gap-2 shadow-lg transition cursor-pointer",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "فتح الدراسة في نافذة ملء الشاشة القابلة للتمرير" : "Open in Full-Screen Scrollable View" })]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													onClick: () => {
														soundManager.playTap();
														setReaderViewMode("continuous_only");
														setActiveAcademic(featuredGccFamilyStudy);
														window.scrollTo({
															top: 0,
															behavior: "smooth"
														});
													},
													className: `px-4 py-2.5 rounded-2xl text-xs font-extrabold border transition cursor-pointer flex items-center gap-1.5 ${isLight ? "bg-white hover:bg-indigo-50 text-indigo-800 border-indigo-300" : "bg-white/10 hover:bg-white/20 text-cyan-200 border-white/15"}`,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "قراءة متصلة داخل الصفحة" : "Read Inline Unsegmented" })]
												})]
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-1 gap-5",
									children: filteredAcademicPapers.map((paper, pIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.article, {
										whileHover: {
											scale: 1.005,
											y: -2
										},
										onClick: () => {
											soundManager.playTap();
											setActiveAcademic(paper);
											window.scrollTo({
												top: 0,
												behavior: "smooth"
											});
										},
										className: `p-6 sm:p-7 rounded-3xl border transition cursor-pointer flex flex-col justify-between space-y-4 group shadow-md ${isLight ? "bg-white hover:bg-indigo-50/40 border-slate-200 hover:border-indigo-400" : "bg-white/[0.03] hover:bg-white/[0.06] border-white/10 hover:border-cyan-500/40"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-3",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-between gap-2 flex-wrap",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-2 flex-wrap",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "px-2.5 py-1 rounded-xl bg-amber-500/15 text-amber-700 dark:text-amber-300 text-xs font-black border border-amber-500/30",
																children: language === "ar" ? `الدراسة البحثية #${pIdx + 1}` : `Research Study #${pIdx + 1}`
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "px-3 py-1 rounded-xl bg-cyan-500/15 text-cyan-700 dark:text-cyan-300 text-xs font-extrabold border border-cyan-500/30 flex items-center gap-1.5",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: paper.icon }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? paper.categoryLabelAr : paper.categoryLabelEn })]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "px-3 py-1 rounded-xl bg-indigo-500/15 text-indigo-700 dark:text-indigo-300 text-xs font-bold border border-indigo-500/30",
																children: language === "ar" ? paper.methodologyBadgeAr : paper.methodologyBadgeEn
															})
														]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-3 text-xs",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "text-amber-600 dark:text-amber-400 font-semibold flex items-center gap-1",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? paper.readTimeAr : paper.readTimeEn })]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "text-slate-500 dark:text-gray-400 font-medium flex items-center gap-1",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: paper.publishDate })]
														})]
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
													className: `text-lg sm:text-xl font-black leading-snug font-['Alexandria'] ${isLight ? "text-slate-900 group-hover:text-indigo-700" : "text-white group-hover:text-cyan-300"}`,
													children: language === "ar" ? paper.titleAr : paper.titleEn
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: `text-xs italic font-medium ${isLight ? "text-slate-500" : "text-gray-400"}`,
													children: language === "ar" ? paper.titleEn : paper.titleAr
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: `text-xs sm:text-sm line-clamp-3 leading-relaxed ${isLight ? "text-slate-600" : "text-gray-300"}`,
													children: language === "ar" ? paper.abstractAr : paper.abstractEn
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "flex flex-wrap gap-1.5 pt-1",
													children: (language === "ar" ? paper.keywordsAr : paper.keywordsEn).map((kw, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: `px-2.5 py-0.5 rounded-lg text-[11px] font-semibold ${isLight ? "bg-slate-100 text-slate-700 border border-slate-200" : "bg-white/5 text-gray-300 border border-white/10"}`,
														children: ["#", kw]
													}, idx))
												})
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: `pt-3 border-t flex flex-wrap items-center justify-between gap-2 text-xs ${isLight ? "border-slate-200" : "border-white/10"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex flex-wrap items-center gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-emerald-600 dark:text-emerald-400 font-bold",
													children: [
														"📚 ",
														paper.apaReferences.length,
														" ",
														language === "ar" ? "مرجعاً أكاديمياً موثقاً بصيغة APA 7th" : "Verified APA 7th Citations"
													]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													onClick: (e) => handleCopyApaCitation(paper, e),
													className: `px-2.5 py-1 rounded-xl text-[11px] font-bold border transition cursor-pointer flex items-center gap-1 ${copiedCitationId === paper.id ? "bg-emerald-600 text-white border-emerald-500" : isLight ? "bg-slate-100 hover:bg-indigo-50 text-slate-700 border-slate-300" : "bg-white/5 hover:bg-white/10 text-cyan-200 border-white/15"}`,
													children: [copiedCitationId === paper.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-3 h-3" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookMarked, { className: "w-3 h-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: copiedCitationId === paper.id ? language === "ar" ? "تم نسخ توثيق APA!" : "APA Citation Copied!" : language === "ar" ? "نسخ التوثيق (APA)" : "Copy APA Citation" })]
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex flex-wrap items-center gap-2",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														type: "button",
														onClick: (e) => {
															e.stopPropagation();
															soundManager.playTap();
															setFullScreenPaper(paper);
														},
														className: "px-3 py-1 rounded-xl bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white text-[11px] font-extrabold flex items-center gap-1.5 shadow-sm transition cursor-pointer",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "عرض بملء الشاشة" : "Full-Screen View" })]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														type: "button",
														onClick: (e) => {
															e.stopPropagation();
															soundManager.playTap();
															setReaderViewMode("continuous_only");
															setActiveAcademic(paper);
															window.scrollTo({
																top: 0,
																behavior: "smooth"
															});
														},
														className: `px-3 py-1 rounded-xl text-[11px] font-extrabold border transition cursor-pointer ${isLight ? "bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border-indigo-200" : "bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-200 border-cyan-400/30"}`,
														children: ["📜 ", language === "ar" ? "قراءة كاملة دون تجزئة" : "Full Continuous"]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-indigo-600 dark:text-cyan-400 font-extrabold flex items-center gap-1",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "قراءة البحث العلمي الكامل" : "Read Full Research Paper" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: `w-4 h-4 ${isRTL ? "rotate-180" : ""}` })]
													})
												]
											})]
										})]
									}, paper.id))
								})
							]
						})
					]
				}, "catalog-grid") : activeNarrative ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.article, {
					initial: {
						opacity: 0,
						y: 12
					},
					animate: {
						opacity: 1,
						y: 0
					},
					exit: { opacity: 0 },
					className: "max-w-4xl mx-auto space-y-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `p-6 sm:p-8 rounded-3xl border space-y-4 shadow-xl ${isLight ? "bg-gradient-to-br from-rose-50 via-white to-purple-50 border-rose-200 text-slate-900" : `bg-gradient-to-br ${activeNarrative.coverGradient} border-purple-500/30 text-white`}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "px-3 py-1 rounded-xl bg-rose-500/20 border border-rose-400/40 text-rose-700 dark:text-rose-200 text-xs font-extrabold flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: activeNarrative.icon }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? activeNarrative.categoryLabelAr : activeNarrative.categoryLabelEn })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3 text-xs opacity-80",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "w-3.5 h-3.5 text-amber-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? activeNarrative.readTime : activeNarrative.readTimeEn })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "w-3.5 h-3.5 text-rose-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: activeNarrative.publishDate })]
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "text-2xl sm:text-3xl font-black leading-tight font-['Alexandria']",
									children: language === "ar" ? activeNarrative.title : activeNarrative.titleEn
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm sm:text-base leading-relaxed opacity-90",
									children: language === "ar" ? activeNarrative.summary : activeNarrative.summaryEn
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `p-4 rounded-2xl border flex flex-wrap items-center justify-between gap-3 text-xs ${isLight ? "bg-white border-slate-200 text-slate-800" : "bg-black/40 border-white/10 text-rose-200"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "w-4 h-4 text-rose-500 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: language === "ar" ? "الإطار العلمي المعتمد: " : "Scientific Framework: " }), language === "ar" ? activeNarrative.scientificFramework : activeNarrative.scientificFrameworkEn] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => handleShareContent(language === "ar" ? activeNarrative.title : activeNarrative.titleEn, language === "ar" ? activeNarrative.summary : activeNarrative.summaryEn),
										className: "px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer",
										children: [copiedShare ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: copiedShare ? language === "ar" ? "تم النسخ!" : "Copied!" : language === "ar" ? "مشاركة المقال" : "Share Article" })]
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReaderToolbar, {
							fontSize: readerFontSize,
							onChangeFontSize: setReaderFontSize,
							viewMode: readerViewMode,
							onChangeViewMode: setReaderViewMode,
							onJumpToContinuous: () => {
								const el = document.getElementById("sec-full-continuous-story");
								if (el) el.scrollIntoView({
									behavior: "smooth",
									block: "start"
								});
							},
							onOpenFullScreen: () => setFullScreenArticle(activeNarrative),
							shareTitle: language === "ar" ? activeNarrative.title : activeNarrative.titleEn,
							shareSummary: language === "ar" ? activeNarrative.summary : activeNarrative.summaryEn,
							shareUrl: "https://miratalqulub.com/#/articles",
							contentTypeLabelAr: "للقصة والسجل العيادي",
							contentTypeLabelEn: "Story"
						}),
						readerViewMode === "segmented_and_continuous" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-6 transition-all",
							style: { fontSize: `${readerFontSize}px` },
							children: [
								activeNarrative.clinicalCaseQuoteAr && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `p-5 sm:p-6 rounded-3xl border-s-4 border-rose-500 space-y-2 ${isLight ? "bg-rose-50/70 text-slate-800 border border-rose-200" : "bg-rose-950/25 text-rose-100 border border-rose-500/20"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 text-rose-600 dark:text-rose-400 font-bold text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quote, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "من داخل غرفة الاستشارة النفسية:" : "Inside the Clinical Consultation Room:" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "italic leading-relaxed font-medium",
										style: { fontSize: `${readerFontSize}px` },
										children: language === "ar" ? activeNarrative.clinicalCaseQuoteAr : activeNarrative.clinicalCaseQuoteEn
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `p-5 sm:p-6 rounded-3xl border space-y-3 ${isLight ? "bg-amber-50 border-amber-200 text-slate-800" : "bg-amber-500/10 border-amber-500/30 text-gray-200"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 text-amber-600 dark:text-amber-300 font-extrabold text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "الخلاصة الإكلينيكية وأبرز النقاط المستفادة:" : "Key Clinical Takeaways:" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "space-y-2",
										style: { fontSize: `${Math.max(14, readerFontSize - 1)}px` },
										children: (language === "ar" ? activeNarrative.keyTakeaways : activeNarrative.keyTakeawaysEn).map((takeaway, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "flex items-start gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-amber-500 font-bold shrink-0",
												children: "✓"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "leading-relaxed",
												children: takeaway
											})]
										}, i))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-4",
									children: activeNarrative.contentParagraphs.map((para, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `p-6 rounded-3xl border space-y-2.5 ${isLight ? "bg-white border-slate-200 text-slate-800 shadow-sm" : "bg-white/[0.02] border-white/10 text-gray-200"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
											className: `font-extrabold font-['Alexandria'] flex items-center gap-2 ${isLight ? "text-slate-900" : "text-white"}`,
											style: { fontSize: `${readerFontSize + 2}px` },
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-2.5 h-2.5 rounded-full bg-rose-500 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? para.heading : para.headingEn })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: `leading-loose whitespace-pre-line ${isLight ? "text-slate-700" : "text-gray-300"}`,
											style: { fontSize: `${readerFontSize}px` },
											children: language === "ar" ? para.text : para.textEn
										})]
									}, i))
								}),
								activeNarrative.diagnosticTable && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `p-6 rounded-3xl border space-y-4 overflow-x-auto ${isLight ? "bg-white border-indigo-200 shadow-sm" : "bg-indigo-950/20 border-indigo-500/30"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
										className: `text-base font-black font-['Alexandria'] ${isLight ? "text-indigo-900" : "text-indigo-300"}`,
										children: [
											"⚖️",
											" ",
											language === "ar" ? activeNarrative.diagnosticTable.titleAr : activeNarrative.diagnosticTable.titleEn
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
										className: "w-full text-xs sm:text-sm border-collapse",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
											className: isLight ? "bg-indigo-50 text-indigo-900 border-b border-indigo-200" : "bg-white/5 text-white border-b border-white/10",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "p-3 text-start font-bold",
													children: language === "ar" ? activeNarrative.diagnosticTable.col1Ar : activeNarrative.diagnosticTable.col1En
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "p-3 text-start font-bold text-emerald-600 dark:text-emerald-400",
													children: language === "ar" ? activeNarrative.diagnosticTable.col2Ar : activeNarrative.diagnosticTable.col2En
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "p-3 text-start font-bold text-rose-600 dark:text-rose-400",
													children: language === "ar" ? activeNarrative.diagnosticTable.col3Ar : activeNarrative.diagnosticTable.col3En
												})
											]
										}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: activeNarrative.diagnosticTable.rows.map((row, rIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
											className: `border-b ${isLight ? "border-slate-200" : "border-white/5"}`,
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "p-3 font-bold",
													children: language === "ar" ? row.criterionAr : row.criterionEn
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "p-3",
													children: language === "ar" ? row.naturalAr : row.naturalEn
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "p-3",
													children: language === "ar" ? row.manipulationAr : row.manipulationEn
												})
											]
										}, rIdx)) })]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `p-6 rounded-3xl border space-y-3 shadow-lg ${isLight ? "bg-emerald-50/90 border-emerald-300 text-slate-900" : "bg-gradient-to-r from-emerald-950/60 via-slate-900 to-teal-950/60 border-emerald-500/35 text-gray-200"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 text-emerald-700 dark:text-emerald-300 font-black text-base sm:text-lg",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "⚡" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-['Alexandria']",
											children: language === "ar" ? activeNarrative.practicalExercise.title : activeNarrative.practicalExercise.titleEn
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "space-y-2.5",
										children: (language === "ar" ? activeNarrative.practicalExercise.steps : activeNarrative.practicalExercise.stepsEn).map((st, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-start gap-2.5 text-xs sm:text-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30 text-xs font-bold flex items-center justify-center shrink-0 mt-0.5",
												children: i + 1
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "leading-relaxed",
												children: st
											})]
										}, i))
									})]
								}),
								activeNarrative.conclusionAr && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `p-6 rounded-3xl border space-y-2 ${isLight ? "bg-purple-50 border-purple-200 text-slate-800" : "bg-purple-950/30 border-purple-500/30 text-purple-100"}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "leading-relaxed font-semibold",
										style: { fontSize: `${readerFontSize}px` },
										children: language === "ar" ? activeNarrative.conclusionAr : activeNarrative.conclusionEn
									})
								}),
								activeNarrative.apaReferences && activeNarrative.apaReferences.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `p-6 rounded-3xl border space-y-3 ${isLight ? "bg-slate-100 border-slate-300 text-slate-800" : "bg-slate-900/80 border-white/10 text-gray-300"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
										className: "font-extrabold text-sm flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookMarked, { className: "w-4 h-4 text-indigo-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "أبرز المراجع العلمية الحديثة المعتمدة في المقال (2023 - 2025):" : "Verified Modern Scientific References (2023–2025):" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "space-y-3 text-xs",
										children: activeNarrative.apaReferences.map((ref, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: `p-3.5 rounded-xl border ${isLight ? "bg-white border-slate-200" : "bg-black/30 border-white/5"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-mono text-xs font-bold text-indigo-600 dark:text-indigo-300 dir-ltr text-left",
												children: ref.citation
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-xs opacity-90",
												children: language === "ar" ? ref.noteAr : ref.noteEn
											})]
										}, idx))
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							id: "sec-full-continuous-story",
							className: `p-6 sm:p-8 rounded-3xl border-2 space-y-5 shadow-xl ${isLight ? "bg-gradient-to-b from-rose-50/70 via-white to-slate-50 border-rose-300 text-slate-900" : "bg-gradient-to-b from-rose-950/35 via-slate-900/95 to-slate-950 border-rose-500/40 text-gray-100"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-3 border-b pb-4 border-rose-200 dark:border-white/15",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/15 border border-rose-500/30 text-rose-700 dark:text-rose-300 text-xs font-extrabold",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "خيار القراءة الكاملة المتواصلة للقصص والسجلات العيادية (دون تجزئة)" : "Full Continuous Unsegmented Story & Clinical Case Manuscript" })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-lg sm:text-2xl font-black font-['Alexandria'] text-rose-700 dark:text-rose-300",
											children: language === "ar" ? "📜 النص الكامل المتواصل للقصة / السجلات السريرية (قراءة متصلة دون تجزئة)" : "📜 Full Continuous Unsegmented Story Manuscript"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs opacity-80",
											children: language === "ar" ? "استمتع بقراءة المجموعة القصصية أو السجل العيادي كاملاً ومتواصلاً من السطر الأول حتى الخاتمة دون أي تجزئة." : "Read the complete clinical story collection continuously from start to finish without segmentation."
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => handleCopyStoryFullText(activeNarrative),
									className: "px-4 py-2 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-extrabold text-xs flex items-center gap-1.5 transition cursor-pointer shadow-md shrink-0",
									children: [copiedStoryFullText ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: copiedStoryFullText ? language === "ar" ? "تم نسخ القصة الكاملة!" : "Full Story Copied!" : language === "ar" ? "نسخ النص الكامل للقصة" : "Copy Full Story Text" })]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `p-5 sm:p-8 rounded-2xl border select-text ${isLight ? "bg-white border-slate-200 text-slate-800 shadow-inner" : "bg-black/40 border-white/10 text-gray-200"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormattedContinuousManuscript, {
									text: getFullContinuousNarrativeText(activeNarrative, language),
									fontSize: readerFontSize,
									isLight
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArticleBottomSocialShare, {
							title: language === "ar" ? activeNarrative.title : activeNarrative.titleEn,
							summary: language === "ar" ? activeNarrative.summary : activeNarrative.summaryEn,
							url: "https://miratalqulub.com/#/articles",
							isLight,
							language
						})
					]
				}, "page-narrative-reader") : activeAcademic ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.article, {
					initial: {
						opacity: 0,
						y: 12
					},
					animate: {
						opacity: 1,
						y: 0
					},
					exit: { opacity: 0 },
					className: "max-w-4xl mx-auto space-y-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `p-6 sm:p-8 rounded-3xl border space-y-4 shadow-xl ${isLight ? "bg-gradient-to-br from-indigo-50 via-white to-cyan-50 border-indigo-200 text-slate-900" : `bg-gradient-to-br ${activeAcademic.coverGradient} border-cyan-500/35 text-white`}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "px-3 py-1 rounded-xl bg-cyan-500/20 border border-cyan-400/40 text-cyan-800 dark:text-cyan-200 text-xs font-extrabold flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? activeAcademic.categoryLabelAr : activeAcademic.categoryLabelEn })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "px-3 py-1 rounded-xl bg-indigo-500/20 border border-indigo-400/40 text-indigo-800 dark:text-indigo-200 text-xs font-bold",
										children: language === "ar" ? activeAcademic.methodologyBadgeAr : activeAcademic.methodologyBadgeEn
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "text-xl sm:text-3xl font-black leading-snug font-['Alexandria']",
									children: language === "ar" ? activeAcademic.titleAr : activeAcademic.titleEn
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs sm:text-sm font-semibold italic opacity-75",
									children: language === "ar" ? activeAcademic.titleEn : activeAcademic.titleAr
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap gap-1.5 pt-1",
									children: (language === "ar" ? activeAcademic.keywordsAr : activeAcademic.keywordsEn).map((kw, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: `px-2.5 py-1 rounded-lg text-xs font-bold ${isLight ? "bg-indigo-100/80 text-indigo-900" : "bg-white/10 text-cyan-200"}`,
										children: ["#", kw]
									}, i))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `p-4 rounded-2xl border flex flex-wrap items-center justify-between gap-3 text-xs ${isLight ? "bg-white border-slate-200 text-slate-800" : "bg-black/40 border-white/10 text-cyan-100"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "font-extrabold flex items-center gap-1.5 text-indigo-700 dark:text-cyan-300",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "w-4 h-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "جهة الإصدار والتحكيم: وحدة الأبحاث والدراسات النفسية — مرآة القلوب (عمّان، الأردن)" : "Published & Peer-Reviewed by: Mirror of Hearts Psychological Research Unit (Amman, Jordan)" })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap items-center gap-3 text-[11px] opacity-85",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
													"📅 ",
													language === "ar" ? "تاريخ النشر:" : "Published:",
													" ",
													activeAcademic.publishDate
												] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["⏱️ ", language === "ar" ? activeAcademic.readTimeAr : activeAcademic.readTimeEn] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
													"📚 ",
													activeAcademic.apaReferences.length,
													" ",
													language === "ar" ? "مرجعاً بصيغة APA 7th" : "APA 7th References"
												] })
											]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => {
													soundManager.playTap();
													setFullScreenPaper(activeAcademic);
												},
												className: "px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white font-extrabold text-xs flex items-center gap-1.5 transition cursor-pointer shadow-sm",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "وضع ملء الشاشة القابل للتمرير" : "Full-Screen Scrollable View" })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => handleCopyApaCitation(activeAcademic),
												className: "px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer",
												children: [copiedCitationId === activeAcademic.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookMarked, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: copiedCitationId === activeAcademic.id ? language === "ar" ? "تم نسخ توثيق APA!" : "APA Citation Copied!" : language === "ar" ? "نسخ التوثيق المرجعي (APA)" : "Copy APA Citation" })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => handleShareContent(language === "ar" ? activeAcademic.titleAr : activeAcademic.titleEn, language === "ar" ? activeAcademic.abstractAr : activeAcademic.abstractEn),
												className: "px-3.5 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer",
												children: [copiedShare ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: copiedShare ? language === "ar" ? "تم النسخ!" : "Copied!" : language === "ar" ? "مشاركة البحث" : "Share Paper" })]
											})
										]
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReaderToolbar, {
							fontSize: readerFontSize,
							onChangeFontSize: setReaderFontSize,
							viewMode: readerViewMode,
							onChangeViewMode: setReaderViewMode,
							onJumpToContinuous: () => {
								const el = document.getElementById("sec-full-continuous-text");
								if (el) el.scrollIntoView({
									behavior: "smooth",
									block: "start"
								});
							},
							onOpenFullScreen: () => setFullScreenPaper(activeAcademic),
							shareTitle: language === "ar" ? activeAcademic.titleAr : activeAcademic.titleEn,
							shareSummary: language === "ar" ? activeAcademic.abstractAr : activeAcademic.abstractEn,
							shareUrl: "https://miratalqulub.com/#/articles",
							contentTypeLabelAr: "للبحث العلمي",
							contentTypeLabelEn: "Paper"
						}),
						readerViewMode === "segmented_and_continuous" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-6 transition-all",
							style: { fontSize: `${readerFontSize}px` },
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `p-5 rounded-3xl border space-y-3 ${isLight ? "bg-slate-50 border-slate-200 text-slate-800" : "bg-white/[0.03] border-white/10 text-gray-200"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs sm:text-sm font-black text-indigo-700 dark:text-cyan-300 font-['Alexandria']",
										children: [
											"📑",
											" ",
											language === "ar" ? "الفهرس الهيكلي للدراسة العلمية المحكّمة:" : "Structured Index of the Peer-Reviewed Study:"
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex flex-wrap gap-2 text-xs",
										children: [
											{
												id: "sec-abstract",
												ar: "الملخص (Abstract)",
												en: "Abstract"
											},
											{
												id: "sec-intro",
												ar: "1. المقدمة",
												en: "1. Introduction"
											},
											{
												id: "sec-theory",
												ar: "2. الإطار النظري",
												en: "2. Theoretical Framework"
											},
											{
												id: "sec-method",
												ar: "3. منهجية البحث",
												en: "3. Methodology"
											},
											{
												id: "sec-analysis",
												ar: "4. النتائج والتحليل والمناقشة",
												en: "4. Results & Discussion"
											},
											{
												id: "sec-conclusion",
												ar: "5. الخاتمة",
												en: "5. Conclusion"
											},
											{
												id: "sec-recommendations",
												ar: "6. التوصيات",
												en: "6. Recommendations"
											},
											{
												id: "sec-references",
												ar: "7. المراجع (APA 7th)",
												en: "7. APA 7th References"
											},
											{
												id: "sec-full-continuous-text",
												ar: "📜 النص الكامل المتواصل للبحث (دون تجزئة)",
												en: "📜 Full Continuous Unsegmented Paper"
											}
										].map((secItem) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => {
												const el = document.getElementById(secItem.id);
												if (el) el.scrollIntoView({
													behavior: "smooth",
													block: "start"
												});
											},
											className: `px-3 py-1.5 rounded-xl font-bold border transition cursor-pointer ${isLight ? "bg-white hover:bg-indigo-50 text-slate-700 border-slate-200" : "bg-black/30 hover:bg-white/10 text-gray-300 border-white/10"}`,
											children: language === "ar" ? secItem.ar : secItem.en
										}, secItem.id))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									id: "sec-abstract",
									className: `p-6 rounded-3xl border space-y-2.5 ${isLight ? "bg-amber-50/70 border-amber-200 text-slate-800" : "bg-amber-500/10 border-amber-500/30 text-gray-200"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
										className: "text-base sm:text-lg font-black text-amber-700 dark:text-amber-300 font-['Alexandria'] flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "الملخص (Abstract)" : "Abstract" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "leading-loose",
										style: { fontSize: `${readerFontSize}px` },
										children: language === "ar" ? activeAcademic.abstractAr : activeAcademic.abstractEn
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									id: "sec-intro",
									className: `p-6 rounded-3xl border space-y-3 ${isLight ? "bg-white border-slate-200 text-slate-800 shadow-sm" : "bg-white/[0.02] border-white/10 text-gray-200"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-lg font-black text-indigo-600 dark:text-cyan-300 font-['Alexandria']",
										children: language === "ar" ? "1. المقدمة (Introduction)" : "1. Introduction"
									}), (language === "ar" ? activeAcademic.introductionAr : activeAcademic.introductionEn).map((p, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "leading-loose",
										style: { fontSize: `${readerFontSize}px` },
										children: p
									}, idx))]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									id: "sec-theory",
									className: `p-6 rounded-3xl border space-y-4 ${isLight ? "bg-white border-slate-200 text-slate-800 shadow-sm" : "bg-white/[0.02] border-white/10 text-gray-200"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-lg font-black text-indigo-600 dark:text-cyan-300 font-['Alexandria']",
										children: language === "ar" ? "2. الإطار النظري والدراسات السابقة (Theoretical Framework)" : "2. Theoretical Framework"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "space-y-4",
										children: activeAcademic.theoreticalFramework.map((sec, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: `p-4 rounded-2xl border space-y-2 ${isLight ? "bg-slate-50 border-slate-200" : "bg-black/30 border-white/5"}`,
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
													className: "text-sm sm:text-base font-extrabold text-purple-700 dark:text-purple-300",
													children: [
														sec.sectionNumber,
														" ",
														language === "ar" ? sec.titleAr : sec.titleEn
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "leading-relaxed",
													style: { fontSize: `${readerFontSize}px` },
													children: language === "ar" ? sec.contentAr : sec.contentEn
												}),
												sec.subPointsAr && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
													className: "space-y-1.5 pt-2",
													style: { fontSize: `${Math.max(14, readerFontSize - 1)}px` },
													children: (language === "ar" ? sec.subPointsAr : sec.subPointsEn || []).map((pt, pIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
														className: "flex items-start gap-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-cyan-500 font-bold",
															children: "•"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: pt })]
													}, pIdx))
												})
											]
										}, idx))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									id: "sec-method",
									className: `p-6 rounded-3xl border space-y-3 ${isLight ? "bg-indigo-50/70 border-indigo-200 text-slate-800" : "bg-indigo-950/30 border-indigo-500/30 text-gray-200"}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-lg font-black text-indigo-700 dark:text-indigo-300 font-['Alexandria']",
											children: language === "ar" ? "3. منهجية البحث (Methodology)" : "3. Research Methodology"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-semibold",
											style: { fontSize: `${readerFontSize}px` },
											children: language === "ar" ? activeAcademic.methodology.approachAr : activeAcademic.methodology.approachEn
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
											className: "space-y-2",
											style: { fontSize: `${readerFontSize}px` },
											children: (language === "ar" ? activeAcademic.methodology.pillarsAr : activeAcademic.methodology.pillarsEn).map((pil, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
												className: "flex items-start gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "w-5 h-5 rounded-full bg-indigo-500/20 text-indigo-700 dark:text-indigo-300 text-xs font-bold flex items-center justify-center shrink-0 mt-0.5",
													children: idx + 1
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "leading-relaxed",
													children: pil
												})]
											}, idx))
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									id: "sec-analysis",
									className: `p-6 rounded-3xl border space-y-4 ${isLight ? "bg-white border-slate-200 text-slate-800 shadow-sm" : "bg-white/[0.02] border-white/10 text-gray-200"}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-lg font-black text-indigo-600 dark:text-cyan-300 font-['Alexandria']",
											children: language === "ar" ? "4. التحليل والمناقشة (Analysis and Discussion)" : "4. Analysis and Discussion"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "space-y-4",
											children: activeAcademic.analysisAndDiscussion.map((sec, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: `p-4 rounded-2xl border space-y-2 ${isLight ? "bg-slate-50 border-slate-200" : "bg-black/30 border-white/5"}`,
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
														className: "text-sm sm:text-base font-extrabold text-rose-700 dark:text-rose-300",
														children: [
															sec.sectionNumber,
															" ",
															language === "ar" ? sec.titleAr : sec.titleEn
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "leading-relaxed",
														style: { fontSize: `${readerFontSize}px` },
														children: language === "ar" ? sec.contentAr : sec.contentEn
													}),
													sec.subPointsAr && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
														className: "space-y-2 pt-2",
														style: { fontSize: `${Math.max(14, readerFontSize - 1)}px` },
														children: (language === "ar" ? sec.subPointsAr : sec.subPointsEn || []).map((pt, pIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
															className: "flex items-start gap-2",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-rose-500 font-bold",
																children: "▪"
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "leading-relaxed",
																children: pt
															})]
														}, pIdx))
													})
												]
											}, idx))
										}),
										activeAcademic.summaryTable && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: `mt-4 p-5 rounded-2xl border space-y-3 overflow-x-auto ${isLight ? "bg-indigo-50/60 border-indigo-200" : "bg-indigo-950/25 border-indigo-500/30"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
												className: "text-sm sm:text-base font-black text-indigo-800 dark:text-cyan-300 font-['Alexandria']",
												children: [
													"📊",
													" ",
													language === "ar" ? activeAcademic.summaryTable.titleAr : activeAcademic.summaryTable.titleEn
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
												className: "w-full text-xs sm:text-sm border-collapse",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
													className: isLight ? "bg-indigo-100/80 text-indigo-950 border-b border-indigo-200" : "bg-white/10 text-white border-b border-white/15",
													children: (language === "ar" ? activeAcademic.summaryTable.headersAr : activeAcademic.summaryTable.headersEn).map((hdr, hIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-3 text-start font-extrabold",
														children: hdr
													}, hIdx))
												}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: activeAcademic.summaryTable.rows.map((row, rIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
													className: `border-b ${isLight ? "border-indigo-100 bg-white/80" : "border-white/10 bg-black/20"}`,
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
															className: "p-3 font-bold text-indigo-700 dark:text-cyan-300",
															children: language === "ar" ? row.col1Ar : row.col1En
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
															className: "p-3",
															children: language === "ar" ? row.col2Ar : row.col2En
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
															className: "p-3",
															children: language === "ar" ? row.col3Ar : row.col3En
														})
													]
												}, rIdx)) })]
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									id: "sec-conclusion",
									className: `p-6 rounded-3xl border space-y-2 ${isLight ? "bg-emerald-50 border-emerald-200 text-slate-800" : "bg-emerald-950/30 border-emerald-500/30 text-gray-200"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-lg font-black text-emerald-700 dark:text-emerald-300 font-['Alexandria']",
										children: language === "ar" ? "5. الخاتمة (Conclusion)" : "5. Conclusion"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "leading-loose",
										style: { fontSize: `${readerFontSize}px` },
										children: language === "ar" ? activeAcademic.conclusionAr : activeAcademic.conclusionEn
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									id: "sec-recommendations",
									className: `p-6 rounded-3xl border space-y-4 ${isLight ? "bg-white border-slate-200 text-slate-800 shadow-sm" : "bg-white/[0.02] border-white/10 text-gray-200"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
										className: "text-lg font-black text-amber-600 dark:text-amber-300 font-['Alexandria'] flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListChecks, { className: "w-5 h-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "6. التوصيات (Recommendations)" : "6. Recommendations" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-1 gap-3",
										children: activeAcademic.recommendations.map((rec, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: `p-4 rounded-2xl border space-y-2 ${isLight ? "bg-slate-50 border-slate-200" : "bg-black/30 border-white/5"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-sm font-extrabold text-indigo-600 dark:text-cyan-300",
												children: language === "ar" ? rec.categoryAr : rec.categoryEn
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
												className: "space-y-1.5",
												style: { fontSize: `${Math.max(14, readerFontSize - 1)}px` },
												children: (language === "ar" ? rec.itemsAr : rec.itemsEn).map((item, iIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
													className: "flex items-start gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-emerald-500 font-bold",
														children: "✓"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "leading-relaxed",
														children: item
													})]
												}, iIdx))
											})]
										}, idx))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									id: "sec-references",
									className: `p-6 rounded-3xl border space-y-3 ${isLight ? "bg-slate-100 border-slate-300 text-slate-800" : "bg-slate-900/90 border-white/15 text-gray-300"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
										className: "text-base sm:text-lg font-black flex items-center gap-2 font-['Alexandria']",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookMarked, { className: "w-4 h-4 text-cyan-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "7. المراجع العلمية الموثقة (References - APA 7th Edition)" : "7. References (APA 7th Edition)" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "space-y-2 text-xs font-mono dir-ltr text-left",
										children: activeAcademic.apaReferences.map((cite, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: `p-3 rounded-xl border ${isLight ? "bg-white border-slate-200 text-slate-800" : "bg-black/40 border-white/5 text-cyan-100"}`,
											children: [
												idx + 1,
												". ",
												cite
											]
										}, idx))
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							id: "sec-full-continuous-text",
							className: `p-6 sm:p-8 rounded-3xl border-2 space-y-5 shadow-xl ${isLight ? "bg-gradient-to-b from-indigo-50/70 via-white to-slate-50 border-indigo-300 text-slate-900" : "bg-gradient-to-b from-indigo-950/40 via-slate-900/95 to-slate-950 border-cyan-500/40 text-gray-100"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-3 border-b pb-4 border-indigo-200 dark:border-white/15",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/15 border border-indigo-500/30 text-indigo-700 dark:text-cyan-300 text-xs font-extrabold",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "النسخة المرجعية الكاملة المتواصلة (دون تجزئة)" : "Complete Unsegmented Reference Manuscript" })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-lg sm:text-2xl font-black font-['Alexandria'] text-indigo-800 dark:text-cyan-300",
											children: language === "ar" ? "📜 النص الكامل المتواصل للبحث العلمي (قراءة متصلة دون تجزئة)" : "📜 Full Continuous Unsegmented Research Paper"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs opacity-80",
											children: language === "ar" ? "يُعرض هنا المقال العلمي كاملاً ومتواصلاً من البداية إلى النهاية دون أي تجزئة أو اختصار مع الحفاظ على التنسيق الأكاديمي والجداول والمراجع." : "The complete research manuscript is presented below continuously from start to finish without segmentation, preserving academic formatting, tables, and citations."
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => handleCopyFullText(activeAcademic),
									className: "px-4 py-2 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs flex items-center gap-1.5 transition cursor-pointer shadow-md shrink-0",
									children: [copiedFullText ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: copiedFullText ? language === "ar" ? "تم نسخ النص الكامل للبحث!" : "Full Paper Text Copied!" : language === "ar" ? "نسخ النص الكامل المتواصل للبحث" : "Copy Full Continuous Paper Text" })]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `p-5 sm:p-8 rounded-2xl border select-text ${isLight ? "bg-white border-slate-200 text-slate-800 shadow-inner" : "bg-black/40 border-white/10 text-gray-200"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormattedContinuousManuscript, {
									text: getFullContinuousAcademicText(activeAcademic, language),
									fontSize: readerFontSize,
									isLight
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArticleBottomSocialShare, {
							title: language === "ar" ? activeAcademic.titleAr : activeAcademic.titleEn,
							summary: language === "ar" ? activeAcademic.abstractAr : activeAcademic.abstractEn,
							url: "https://miratalqulub.com/#/articles",
							isLight,
							language
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `p-5 rounded-3xl border text-xs leading-relaxed ${isLight ? "bg-amber-50 border-amber-200 text-amber-900" : "bg-amber-950/30 border-amber-500/30 text-amber-200"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "block mb-1 font-extrabold",
								children: language === "ar" ? "⚖️ إخلاء مسؤولية علمي وعيادي (Scientific & Clinical Disclaimer):" : "⚖️ Scientific & Clinical Disclaimer:"
							}), language === "ar" ? "تم إعداد هذه الدراسة البحثية لأغراض التثقيف النفسي والأكاديمي وتعميق الوعي الذاتي والعلائقي، ولا تُعد بديلاً عن التشخيص الطبي أو العيادي المباشر لدى طبيب نفسي أو معالج إكلينيكي مرخص." : "This academic research paper is published for psychoeducational and scholarly awareness purposes and does not constitute a substitute for formal psychiatric or clinical diagnosis by a licensed mental health professional."]
						})
					]
				}, "page-academic-reader") : null
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResearchArticleModal, {
				isOpen: Boolean(fullScreenPaper || fullScreenArticle),
				onClose: () => {
					setFullScreenPaper(null);
					setFullScreenArticle(null);
				},
				content: fullScreenPaper ? getFullContinuousAcademicText(fullScreenPaper, language) : fullScreenArticle ? getFullContinuousNarrativeText(fullScreenArticle, language) : void 0,
				paper: fullScreenPaper,
				article: fullScreenArticle,
				initialViewMode: "continuous_only"
			})
		]
	});
};
//#endregion
export { ArticlesEncyclopediaPage };
