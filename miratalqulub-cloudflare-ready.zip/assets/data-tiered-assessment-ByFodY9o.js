//#region src/data/tieredPsychologyBank.ts
var ANALYSIS_TIERS_CATALOG = [
	{
		id: "quick",
		titleAr: "التحليل السريع",
		titleEn: "Quick Analysis",
		badgeAr: "مسح سيكومتري مركز",
		questionCount: 32,
		estimatedMinutesMin: 3,
		estimatedMinutesMax: 5,
		durationLabelAr: "3 – 5 دقائق (32 سؤالاً)",
		durationLabelEn: "3 – 5 mins (32 Items)",
		descriptionAr: "تقييم تأسيسي يغطي الركائز الثماني لعلم النفس المعاصر لالتقاط بصمتك الشخصية ونضجك العاطفي بسرعة ودقة.",
		descriptionEn: "Foundational screening spanning all 8 validated psychological constructs for a rapid personality and emotional maturity snapshot.",
		outputsAr: [
			"وصف الشخصية الأساسي",
			"نقاط القوة البارزة",
			"نقاط التحسين والتطوير",
			"أسلوب التواصل السائد",
			"مؤشر النضج العاطفي"
		],
		outputsEn: [
			"Core personality description",
			"Primary strengths",
			"Areas for improvement",
			"Communication style",
			"Emotional maturity index"
		],
		accentColor: "#10b981"
	},
	{
		id: "advanced",
		titleAr: "التحليل المتقدم",
		titleEn: "Advanced Analysis",
		badgeAr: "تشخيص متعدد الأبعاد",
		questionCount: 144,
		estimatedMinutesMin: 18,
		estimatedMinutesMax: 24,
		durationLabelAr: "18 – 24 دقيقة (144 سؤالاً)",
		durationLabelEn: "18 – 24 mins (144 Items)",
		descriptionAr: "قياس سيكومتري موسّع بمزيج من مقاييس ليكرت والاختيار القسري (Forced-Choice) لفحص التفكير والقرار والارتباط وإدارة النزاعات.",
		descriptionEn: "Expanded multi-facet assessment combining Likert-5 and Forced-Choice items examining cognition, attachment, conflict, and family readiness.",
		outputsAr: [
			"تقرير شخصية شامل متعدد المقاييس",
			"تحليل نمط التفكير والمعالجة الذهنية",
			"تحليل أسلوب اتخاذ القرار",
			"تحديد نمط الارتباط (ECR-R)",
			"أسلوب التواصل وحل النزاعات",
			"التوافق العاطفي المتوقع ومؤشرات النجاح الأسري"
		],
		outputsEn: [
			"Comprehensive personality report",
			"Thinking style analysis",
			"Decision-making analysis",
			"Attachment style mapping (ECR-R)",
			"Communication & conflict resolution styles",
			"Expected emotional compatibility & family success indicators"
		],
		accentColor: "#8b5cf6"
	},
	{
		id: "professional",
		titleAr: "التحليل الاحترافي",
		titleEn: "Professional Analysis",
		badgeAr: "البطارية الشاملة المعمقة",
		questionCount: 288,
		estimatedMinutesMin: 35,
		estimatedMinutesMax: 45,
		durationLabelAr: "35 – 45 دقيقة (288 سؤالاً)",
		durationLabelEn: "35 – 45 mins (288 Items)",
		descriptionAr: "البطارية السيكومترية الكاملة متعددة الأوجه مع التحقق من الاتساق الداخلي ومؤشرات القيم والأهداف والمرونة طويلة الأمد مع تقرير PDF متكامل.",
		descriptionEn: "Full facet-level psychometric battery with internal consistency checks, values/goals mapping, marital longevity forecast, and full PDF dossier.",
		outputsAr: [
			"تقرير احترافي متعدد الأقسام",
			"تحليل شخصية شامل (Big Five + HEXACO)",
			"القيم والمعتقدات وأهداف الحياة",
			"القدرة على إدارة الضغوط والتنظيم الذاتي",
			"الذكاء العاطفي والتعاطف المعمق",
			"التوافق الزواجي طويل الأمد + تقرير PDF مفصل بالرسوم البيانية"
		],
		outputsEn: [
			"Multi-section professional dossier",
			"Comprehensive Big Five + HEXACO analysis",
			"Core values, beliefs & life goals architecture",
			"Stress regulation capacity",
			"Emotional intelligence & deep empathy",
			"Long-term marital compatibility + detailed visual PDF report"
		],
		accentColor: "#f43f5e"
	}
];
var CONSTRUCT_SCIENTIFIC_CATALOG = {
	big_five: {
		key: "big_five",
		titleAr: "نموذج العوامل الخمسة الكبرى (Big Five)",
		titleEn: "Big Five Personality Model (OCEAN)",
		referenceAr: "Costa & McCrae (1992) NEO-PI-R & Goldberg IPIP-NEO",
		scientificExplanationAr: "يقيس الاستعدادات الشخصية المستقرة عبر خمسة أبعاد عالمية: الانفتاح على الخبرة، يقظة الضمير، الانبساط، الوفاق، والاتزان الانفعالي.",
		scientificExplanationEn: "Measures broad personality dispositions across Openness, Conscientiousness, Extraversion, Agreeableness, and Emotional Stability.",
		color: "#8b5cf6"
	},
	hexaco: {
		key: "hexaco",
		titleAr: "نموذج هيكساكو سداسي العوامل (HEXACO)",
		titleEn: "HEXACO 6-Factor Personality Model",
		referenceAr: "Ashton & Lee (2004, 2009) HEXACO-PI-R",
		scientificExplanationAr: "يميز الشخصية بستة محاور يضاف إليها عامل الصدق-التواضع (Honesty-Humility) للتنبؤ بالأمانة والنزاهة العلائقية والعدالة.",
		scientificExplanationEn: "Extends personality structure with the critical sixth dimension of Honesty-Humility predicting sincerity, fairness, and relational integrity.",
		color: "#06b6d4"
	},
	attachment: {
		key: "attachment",
		titleAr: "نظرية التعلق والارتباط (Attachment Theory)",
		titleEn: "Adult Attachment Theory (ECR-R)",
		referenceAr: "Bowlby (1969), Ainsworth (1978) & Fraley et al. (2000) ECR-R",
		scientificExplanationAr: "يقيس بُعدَي قلق الارتباط (الخوف من الهجر) وتجنب الارتباط (تجنب القرب العاطفي) لتحديد مستوى الأمان النفسي في العلاقات.",
		scientificExplanationEn: "Evaluates Attachment Anxiety and Attachment Avoidance dimensions shaping emotional safety and closeness in close relationships.",
		color: "#f43f5e"
	},
	emotional_intelligence: {
		key: "emotional_intelligence",
		titleAr: "الذكاء العاطفي (Emotional Intelligence)",
		titleEn: "Emotional Intelligence (MSCEIT & Bar-On)",
		referenceAr: "Salovey & Mayer (1990), Bar-On (1997) & Goleman (1995)",
		scientificExplanationAr: "يرصد كفاءة إدراك المشاعر الذاتية ومشاعر الآخرين، فهم تدرج الانفعالات، توظيفها في اتخاذ القرار، والتفاعل بتعاطف متزن.",
		scientificExplanationEn: "Assesses emotion perception, empathetic decoding, affective understanding, and constructive emotional regulation in relationships.",
		color: "#ec4899"
	},
	self_regulation: {
		key: "self_regulation",
		titleAr: "التنظيم الذاتي وإدارة الضغوط (Self Regulation)",
		titleEn: "Self-Regulation & Executive Control",
		referenceAr: "Gross (1998) Emotion Regulation & Baumeister & Vohs (2004)",
		scientificExplanationAr: "يقيس ضبط الاندفاع الانفعالي، إعادة التقييم المعرفي للأحداث الضاغطة، المثابرة على الأهداف، والقدرة على استعادة التوازن العصبي.",
		scientificExplanationEn: "Evaluates impulse inhibition, cognitive reappraisal under stress, behavioral persistence, and physiological recovery speed.",
		color: "#f59e0b"
	},
	interpersonal: {
		key: "interpersonal",
		titleAr: "العلاقات البينشخصية والأسرة (Interpersonal)",
		titleEn: "Interpersonal & Dyadic Functioning",
		referenceAr: "Gottman (1999) Sound Relationship House & Bowen (1978)",
		scientificExplanationAr: "يفحص بناء الثقة المتبادلة، جودة الحدود مع المحيط، روح الشراكة الأسرية، الاستعداد الأبوي/التربوي، والقدرة على الإصلاح العلائقي.",
		scientificExplanationEn: "Examines trust maintenance, family boundary differentiation, mutual respect, parenting orientation, and relational repair attempts.",
		color: "#10b981"
	},
	communication: {
		key: "communication",
		titleAr: "أنماط التواصل وإدارة النزاعات (Communication)",
		titleEn: "Communication & Conflict Resolution Styles",
		referenceAr: "Thomas & Kilmann (1974) TKI & Rosenberg NVC (2003)",
		scientificExplanationAr: "يحلل أسلوب التعبير الحازم الهادئ، الاستماع الفعال، الوضوح التحليلي، والقدرة على التحول من الدفاعية إلى التعاون التفاوضي.",
		scientificExplanationEn: "Captures assertive dialogue, active listening, analytical clarity, and constructive collaboration vs. avoidance during disagreement.",
		color: "#3b82f6"
	},
	positive_psychology: {
		key: "positive_psychology",
		titleAr: "علم النفس الإيجابي والقيم (Positive Psychology)",
		titleEn: "Positive Psychology, Values & Life Meaning",
		referenceAr: "Seligman (2011) PERMA, Schwartz (1992) Values & VIA Institute",
		scientificExplanationAr: "يستكشف الوضوح القيمي، التفاؤل الواقعي، الامتنان اليومي، وجودة الأهداف الحياتية طويلة الأمد الداعمة للازدهار الأسري.",
		scientificExplanationEn: "Assesses core human values, intrinsic purpose, optimism, gratitude, and long-horizon life goals fostering flourishing partnerships.",
		color: "#14b8a6"
	}
};
var CONSTRUCT_SEEDS_MAP = [
	{
		construct: "big_five",
		seeds: [
			{
				subscale: "bf_openness",
				facetAr: "الفضول الفكري والانفتاح",
				facetEn: "Intellectual Curiosity",
				direction: 1,
				textAr: "أستمتع بتحليل الأفكار الجديدة والبحث عن وجهات نظر غير تقليدية قبل تكوين حكمي.",
				textEn: "I enjoy analyzing new ideas and exploring unconventional viewpoints before forming a judgment.",
				explanationAr: "يعكس ارتفاع الانفتاح المعرفي والقدرة على التفكير التباعدي.",
				explanationEn: "Reflects intellectual curiosity and divergent thinking capacity."
			},
			{
				subscale: "bf_conscientiousness",
				facetAr: "الانضباط وتنظيم المسؤوليات",
				facetEn: "Orderliness & Duty",
				direction: 1,
				textAr: "أحرص على إتمام التزاماتي اليومية بدقة وفي موعدها حتى عند غياب الرقابة الخارجية.",
				textEn: "I complete daily commitments accurately and on time even without external supervision.",
				explanationAr: "يقيس يقظة الضمير والموثوقية التنفيذية طويلة الأمد.",
				explanationEn: "Measures conscientious reliability and autonomous self-discipline."
			},
			{
				subscale: "bf_extraversion",
				facetAr: "الحيوية والتفاعل الاجتماعي",
				facetEn: "Social Energy",
				direction: 1,
				textAr: "أشعر بتجدد نشاطي حين أتواصل مع الناس وأبادر بفتح حوارات بنّاءة في التجمعات.",
				textEn: "I feel energized when connecting with people and initiating constructive conversations.",
				explanationAr: "يرصد درجة الانبساط الاجتماعي وتوليد الطاقة من التفاعل البشري.",
				explanationEn: "Captures social vitality and positive affect gained from interaction."
			},
			{
				subscale: "bf_emotional_stability",
				facetAr: "الصلابة والاتزان الانفعالي",
				facetEn: "Emotional Composure",
				direction: 1,
				textAr: "أحافظ على رباطة جأشي وهدوء تفكيري عندما تتراكم الضغوط أو تتغير الخطط فجأة.",
				textEn: "I maintain composure and calm reasoning when pressures mount or plans shift unexpectedly.",
				explanationAr: "يقيس الاستقرار الانفعالي ومقاومة الاستثارة العصبية (عكس العصابية).",
				explanationEn: "Measures emotional stability and resilience against acute stress."
			},
			{
				subscale: "bf_agreeableness",
				facetAr: "التعاون وحسن الظن",
				facetEn: "Altruism & Cooperation",
				direction: 1,
				textAr: "أسعى لفهم دوافع الآخرين بتعاطف قبل إصدار الأحكام أو الدفاع عن موقفي.",
				textEn: "I seek to understand others empathetically before judging or defending my stance.",
				explanationAr: "يقيس بُعد الوفاق واللين العلائقي في التفاعل الإنساني.",
				explanationEn: "Measures agreeableness and compassionate perspective-taking."
			},
			{
				subscale: "bf_conscientiousness",
				facetAr: "التخطيط مقابل التأجيل",
				facetEn: "Procrastination Control",
				direction: -1,
				textAr: "أؤجل المهام المهمة إلى اللحظات الأخيرة رغم إدراكي لأهميتها.",
				textEn: "I frequently postpone important responsibilities until the last minute.",
				explanationAr: "بند عكسي يكشف فجوات التنظيم الذاتي وإدارة الأولويات.",
				explanationEn: "Reverse-keyed item assessing self-discipline and procrastination risk."
			},
			{
				subscale: "bf_emotional_stability",
				facetAr: "الاجترار الذهني والقلق",
				facetEn: "Anxiety Tendency",
				direction: -1,
				textAr: "تستمر المواقف المحرجة أو المقلقة في استنزاف تفكيري لساعات طويلة بعد انتهائها.",
				textEn: "Distressing events continue to occupy my thoughts for hours after they end.",
				explanationAr: "بند عكسي يقيس القابلية للقلق والاجترار المعرفي.",
				explanationEn: "Reverse-keyed item evaluating vulnerability to rumination."
			},
			{
				subscale: "bf_openness",
				facetAr: "التذوق الفكري والعمق",
				facetEn: "Abstract Reflection",
				direction: 1,
				textAr: "تجذبني الحوارات الفلسفية والعلمية التي تستكشف معنى الحياة والدوافع الإنسانية.",
				textEn: "I am drawn to philosophical and scientific conversations exploring human motivation.",
				explanationAr: "يعكس عمق الانفتاح التأملي والحاجة للاستكشاف المعرفي.",
				explanationEn: "Reflects openness to ideas and reflective intellectual depth."
			},
			{
				subscale: "bf_extraversion",
				facetAr: "تفضيل العزلة الصامتة",
				facetEn: "Solitude Preference",
				direction: -1,
				textAr: "أجد التجمعات الممتدة مرهقة نفسياً وأحتاج بعدها لفترات عزلة طويلة لأستعيد توازني.",
				textEn: "Extended social gatherings drain me and require long solitude afterward to recover.",
				explanationAr: "بند عكسي يميز الميول الانطوائية الهادئة عن الانبساط المرتفع.",
				explanationEn: "Reverse-keyed indicator differentiating introversion from extraversion."
			},
			{
				subscale: "bf_agreeableness",
				facetAr: "التعاطف التفاوضي (اختيار قسري)",
				facetEn: "Task vs Harmony Orientation",
				direction: 1,
				format: "forced_choice",
				textAr: "عند الاختلاف مع مقرب حول خطة مشتركة، أي توجه يعبر عنك أكثر تلقائياً؟",
				textEn: "When disagreeing with someone close on a shared plan, which approach reflects you more naturally?",
				explanationAr: "اختيار إجباري يوازن بين صون المودة والالتزام الصارم بالحجة.",
				explanationEn: "Forced-choice item balancing relational warmth against strict task logic.",
				forcedOptions: [{
					id: "A",
					textAr: "أراعي مشاعره أولاً وأبحث عن صيغة توافق تحفظ الود والانسجام",
					textEn: "Prioritize mutual feelings first and seek a harmonious compromise",
					targetSubscale: "bf_agreeableness",
					scoreValue: 5,
					traitTagAr: "وفاق ورعاية علائقية",
					traitTagEn: "High Agreeableness"
				}, {
					id: "B",
					textAr: "أتمسك بالخيار الأكثر كفاءة منطقياً حتى لو بدا مباشراً وصارماً",
					textEn: "Hold firmly to the most logical option even if it feels blunt",
					targetSubscale: "bf_conscientiousness",
					scoreValue: 2,
					traitTagAr: "حسم مهماتي",
					traitTagEn: "Task Directness"
				}]
			},
			{
				subscale: "bf_openness",
				facetAr: "تقبل التغيير الثقافي",
				facetEn: "Tolerance for Ambiguity",
				direction: 1,
				textAr: "أتعامل مع التغيرات الفكرية والتجارب الجديدة بمرونة دون خوف من المجهول.",
				textEn: "I approach new experiences and ideological shifts with curiosity rather than fear.",
				explanationAr: "يرصد التفتح الذهني وقبول التجديد مقابل الجمود الروتيني.",
				explanationEn: "Evaluates openness to novelty versus rigid adherence to routine."
			},
			{
				subscale: "bf_conscientiousness",
				facetAr: "التحقق من التفاصيل",
				facetEn: "Detail Vigilance",
				direction: 1,
				textAr: "أراجع تفاصيل خطتي المالية والأسرية بدقة لتقليل المفاجآت والعثرات.",
				textEn: "I review details of my financial and family plans carefully to prevent avoidable setbacks.",
				explanationAr: "يعكس بُعد الحذر والتنظيم الممنهج في القرارات الحياتية.",
				explanationEn: "Reflects deliberation and methodical planning under Conscientiousness."
			},
			{
				subscale: "bf_agreeableness",
				facetAr: "النقد الحاد والمنافسة",
				facetEn: "Critical Bluntness",
				direction: -1,
				textAr: "يميل أسلوبي أحياناً إلى انتقاد أخطاء الآخرين بحدة دون تلطيف لغوي.",
				textEn: "I sometimes criticize others mistakes bluntly without softening my tone.",
				explanationAr: "بند عكسي يقيس مستوى اللطف مقابل الصلابة اللفظية.",
				explanationEn: "Reverse-keyed item capturing interpersonal tact vs. harshness."
			},
			{
				subscale: "bf_emotional_stability",
				facetAr: "ثبات المزاج اليومي",
				facetEn: "Affective Consistency",
				direction: 1,
				textAr: "يبقى مزاجي متوازناً نسبياً خلال الأسبوع ولا يتقلب سريعاً لأسباب عابرة.",
				textEn: "My mood stays fairly steady throughout the week without sharp swings over minor events.",
				explanationAr: "يقيس الثبات الانفعالي وتماسك المزاج اليومي.",
				explanationEn: "Assesses day-to-day affective stability."
			},
			{
				subscale: "bf_extraversion",
				facetAr: "المبادرة القيادية",
				facetEn: "Social Assertiveness",
				direction: 1,
				textAr: "أبادر بتنظيم الأنشطة وتوزيع الأدوار حين تتوقف المجموعة عن الحركة.",
				textEn: "I naturally step up to coordinate activities when a group hesitates.",
				explanationAr: "يرصد جانب الحزم الاجتماعي ضمن بُعد الانبساط.",
				explanationEn: "Captures social assertiveness under Extraversion."
			},
			{
				subscale: "bf_openness",
				facetAr: "التفضيل الروتيني",
				facetEn: "Routine Preference",
				direction: -1,
				textAr: "أفضل اتباع الطرق المعتادة التي جربتها سابقاً وتجنب أي أساليب غير مألوفة.",
				textEn: "I prefer sticking strictly to familiar habits and avoiding unfamiliar approaches.",
				explanationAr: "بند عكسي يقيس النزعة المحافظة مقابل الاستكشاف الفكري.",
				explanationEn: "Reverse-keyed openness item contrasting familiarity with novelty."
			},
			{
				subscale: "bf_conscientiousness",
				facetAr: "المثابرة حتى الإتمام",
				facetEn: "Perseverance",
				direction: 1,
				textAr: "أواصل العمل على أهدافي طويلة المدى حتى بعد تلاشي الحماس الأولي.",
				textEn: "I keep working persistently toward long-term goals even after initial excitement fades.",
				explanationAr: "يرتبط بالإنجاز المستدام والاستثمار الواعي في الأهداف.",
				explanationEn: "Associated with long-term achievement striving and grit."
			},
			{
				subscale: "bf_agreeableness",
				facetAr: "التضحية والعفو",
				facetEn: "Forgiveness & Warmth",
				direction: 1,
				textAr: "أستطيع الصفح الصادق حين يعتذر من أخطأ بحقي بنية طيبة.",
				textEn: "I can genuinely forgive when someone sincerely apologizes for a mistake.",
				explanationAr: "يقيس السماحة القلبية والقدرة على تجاوز الأخطاء البسيطة.",
				explanationEn: "Measures interpersonal warmth and capacity for forgiveness."
			},
			{
				subscale: "bf_emotional_stability",
				facetAr: "الضغط الزائد والانفعال",
				facetEn: "Stress Reactivity",
				direction: -1,
				textAr: "أشعر بارتباك سريع وفقدان للتركيز عندما تتداخل عدة مسؤوليات في وقت واحد.",
				textEn: "I easily feel overwhelmed and lose focus when multiple demands hit at once.",
				explanationAr: "بند عكسي لقياس هشاشة التوتر تحت تعدد المهام.",
				explanationEn: "Reverse-keyed stress vulnerability facet."
			},
			{
				subscale: "bf_openness",
				facetAr: "الحس الجمالي والأدبي",
				facetEn: "Aesthetic Sensitivity",
				direction: 1,
				textAr: "يلفت انتباهي الجمال اللغوي والفني وتفاصيل الطبيعة الدقيقة في حياتي اليومية.",
				textEn: "I notice subtle artistic, literary, and natural beauty in everyday life.",
				explanationAr: "يرصد الحس الجمالي والوجداني المرتبط بالانفتاح.",
				explanationEn: "Assesses aesthetic appreciation within Openness."
			},
			{
				subscale: "bf_extraversion",
				facetAr: "البوح العفوي والتعبير",
				facetEn: "Positive Expressiveness",
				direction: 1,
				textAr: "أعبر عن حماسي ومشاعري الإيجابية بوضوح ولا أخفي فرحتي عند النجاح.",
				textEn: "I express positive emotions and enthusiasm openly when good things happen.",
				explanationAr: "يعكس الدفء التعبيري والبهجة المنبسطة.",
				explanationEn: "Reflects positive emotionality facet of Extraversion."
			},
			{
				subscale: "bf_conscientiousness",
				facetAr: "الاندفاع دون تقييم",
				facetEn: "Impulsive Deciding",
				direction: -1,
				textAr: "أندفع أحياناً لقرارات سريعة دون مراجعة العواقب المترتبة عليها.",
				textEn: "I sometimes rush into decisions without reviewing potential consequences.",
				explanationAr: "بند عكسي لقياس التأني الإدراكي والانضباط التنفيذي.",
				explanationEn: "Reverse-keyed deliberation facet."
			},
			{
				subscale: "bf_agreeableness",
				facetAr: "التنافسية المفرطة",
				facetEn: "Zero-Sum Stance",
				direction: -1,
				textAr: "أرى معظم النقاشات الحياتية كساحة يجب أن يخرج فيها طرف منتصراً على الآخر.",
				textEn: "I view most disagreements as contests where one side must win over the other.",
				explanationAr: "بند عكسي يكشف التصلب التنافسي مقابل الشراكة التوافقية.",
				explanationEn: "Reverse-keyed item distinguishing competitiveness from cooperation."
			},
			{
				subscale: "bf_emotional_stability",
				facetAr: "الثقة في القدرة على التكيف",
				facetEn: "Coping Confidence",
				direction: 1,
				textAr: "أثق بقدرتي على إيجاد مخرج عملي مهما تعقدت الظروف المحيطة بي.",
				textEn: "I trust my ability to find workable solutions regardless of situational complexity.",
				explanationAr: "يعكس الاتزان العاطفي المقرون بالكفاءة الذاتية.",
				explanationEn: "Captures emotional resilience paired with self-efficacy."
			},
			{
				subscale: "bf_openness",
				facetAr: "الاختيار القسري: التجديد vs الثبات",
				facetEn: "Exploration vs Convention",
				direction: 1,
				format: "forced_choice",
				textAr: "في تخطيط رحلتكما أو حياتكما السنوية، أيهما يستهويك أكثر؟",
				textEn: "When planning life milestones or trips, which appeals to you more strongly?",
				explanationAr: "اختيار إجباري يقيس التوازن بين حب الاستكشاف والأمان المألوف.",
				explanationEn: "Forced-choice contrasting exploratory openness with conventional security.",
				forcedOptions: [{
					id: "A",
					textAr: "تجربة مسارات وثقافات وأفكار لم نختبرها من قبل لاكتساب آفاق جديدة",
					textEn: "Exploring unfamiliar paths, cultures, and fresh perspectives",
					targetSubscale: "bf_openness",
					scoreValue: 5,
					traitTagAr: "انفتاح استكشافي",
					traitTagEn: "High Openness"
				}, {
					id: "B",
					textAr: "العودة لوجهات وأنماط معروفة ومجربة تضمن الراحة واليقين الكامل",
					textEn: "Returning to proven, predictable routines ensuring certainty",
					targetSubscale: "bf_conscientiousness",
					scoreValue: 3,
					traitTagAr: "استقرار مجرب",
					traitTagEn: "Structured Certainty"
				}]
			},
			{
				subscale: "bf_conscientiousness",
				facetAr: "الوفاء بالوعود الصغيرة",
				facetEn: "Micro-Reliability",
				direction: 1,
				textAr: "إذا قطعت وعداً حتى في أمر بسيط، أعتبر الوفاء به التزاماً أخلاقياً لا يتجزأ.",
				textEn: "Even for minor promises, keeping my word is a non-negotiable ethical duty.",
				explanationAr: "يقيس حس المسؤولية الضميري داخل العلاقات القريبة.",
				explanationEn: "Evaluates conscientious dependability in everyday commitments."
			},
			{
				subscale: "bf_extraversion",
				facetAr: "الحيوية القيادية الحوارية",
				facetEn: "Conversational Vitality",
				direction: 1,
				textAr: "أشعر بالارتياح عندما أبدأ التعارف مع غرباء في بيئات مهنية أو اجتماعية جديدة.",
				textEn: "I feel comfortable initiating conversations with new people in unfamiliar settings.",
				explanationAr: "يقيس السلاسة الاجتماعية والانفتاح التواصلي.",
				explanationEn: "Measures social ease and gregariousness."
			},
			{
				subscale: "bf_agreeableness",
				facetAr: "مراعاة مشاعر المستضعفين",
				facetEn: "Tender-Mindedness",
				direction: 1,
				textAr: "يتحرك قلبي سريعاً لتخفيف معاناة الآخرين وتقديم العون دون انتظار مقابل.",
				textEn: "I feel deeply moved to ease others distress without expecting anything in return.",
				explanationAr: "يقيس الرقة الوجدانية واللطف الإنساني الأصيل.",
				explanationEn: "Assesses tender-mindedness and altruistic concern."
			},
			{
				subscale: "bf_emotional_stability",
				facetAr: "سرعة الاستثارة عند النقد",
				facetEn: "Rejection Sensitivity",
				direction: -1,
				textAr: "يثير النقد الهادئ ردة فعل دفاعية حادة داخلي قبل أن أستمع لمحتواه.",
				textEn: "Even calm constructive feedback triggers intense defensiveness inside me.",
				explanationAr: "بند عكسي يرصد الحساسية المفرطة للنقد والانفعال الدفاعي.",
				explanationEn: "Reverse-keyed item measuring emotional defensiveness."
			},
			{
				subscale: "bf_openness",
				facetAr: "تقييم الوعي الذاتي",
				facetEn: "Emotional Openness",
				direction: 1,
				textAr: "أصغي لنبضات مشاعري الدقيقة وأعتبرها مصدراً مهماً لفهم ذاتي وحكمتي.",
				textEn: "I attune to my nuanced feelings as a vital source of self-understanding.",
				explanationAr: "بُعد الانفتاح على المشاعر في نموذج كوستا ومكري.",
				explanationEn: "Openness to Feelings facet in Costa & McCrae NEO model."
			},
			{
				subscale: "bf_conscientiousness",
				facetAr: "البيئة المرتبة والتركيز",
				facetEn: "Environmental Order",
				direction: 1,
				textAr: "يساعدني ترتيب محيطي وأدواتي الشخصية على صفاء ذهني وإنجازي.",
				textEn: "Keeping my living and working environment organized helps clear my mind.",
				explanationAr: "بُعد النظام الفيزيائي والسلوكي في يقظة الضمير.",
				explanationEn: "Orderliness facet of Conscientiousness."
			},
			{
				subscale: "bf_extraversion",
				facetAr: "تجنب الأضواء والظهور",
				facetEn: "Social Reserve",
				direction: -1,
				textAr: "أفضل العمل في الخلفية بصمت وتجنب أن أكون محور الانتباه في المجالس.",
				textEn: "I prefer working quietly behind the scenes rather than being the center of attention.",
				explanationAr: "بند عكسي يرصد التحفظ الاجتماعي مقابل البروز الانبساطي.",
				explanationEn: "Reverse-keyed modesty/introversion preference."
			},
			{
				subscale: "bf_agreeableness",
				facetAr: "الاستماع المتواضع",
				facetEn: "Humility in Listening",
				direction: 1,
				textAr: "أعترف بوضوح عندما يتضح أن الطرف الآخر يملك رؤية أصوب من رؤيتي.",
				textEn: "I readily acknowledge when someone else presents a more accurate viewpoint than mine.",
				explanationAr: "يعكس الوفاق العقلي والتواضع الموضوعي في الحوار.",
				explanationEn: "Measures cooperative humility and non-defensive listening."
			},
			{
				subscale: "bf_emotional_stability",
				facetAr: "السكينة النفسية بعد الخلاف",
				facetEn: "Post-Conflict Recovery",
				direction: 1,
				textAr: "أتمكن من استعادة هدوئي وتوازني الداخلي سريعاً بعد الخلافات العابرة.",
				textEn: "I recover my inner equilibrium relatively quickly after passing disagreements.",
				explanationAr: "مؤشر مباشر لمرونة الجهاز العصبي الانفعالي.",
				explanationEn: "Direct marker of affective bounce-back resilience."
			},
			{
				subscale: "bf_openness",
				facetAr: "التفكير المرن في القواعد",
				facetEn: "Cognitive Flexibility",
				direction: 1,
				textAr: "أعيد تقييم قناعاتي العملية إذا ظهرت أدلة موثوقة تدعو لتطويرها.",
				textEn: "I willingly revise practical assumptions when credible new evidence emerges.",
				explanationAr: "يعكس المرونة الإدراكية والانفتاح على التعلم المستمر.",
				explanationEn: "Reflects intellectual humility and cognitive flexibility."
			},
			{
				subscale: "bf_conscientiousness",
				facetAr: "الكفاءة الإدارية والتنفيذية",
				facetEn: "Competence & Execution",
				direction: 1,
				textAr: "أضع خطوات تنفيذية واقعية لأحلامي بدلاً من الاكتفاء بالتمني النظري.",
				textEn: "I translate personal aspirations into concrete actionable milestones.",
				explanationAr: "يمثل بُعد الكفاءة والاجتهاد المنظم في نموذج OCEAN.",
				explanationEn: "Competence and goal-directed execution facet."
			}
		],
		ref: CONSTRUCT_SCIENTIFIC_CATALOG.big_five.referenceAr
	},
	{
		construct: "hexaco",
		seeds: [
			{
				subscale: "hx_honesty_humility",
				facetAr: "الصدق وعدم التصنع",
				facetEn: "Sincerity",
				direction: 1,
				textAr: "أتعامل مع الناس بصدق وشفافية دون تملق أو إظهار عكس ما أبطن لتحقيق مصلحة.",
				textEn: "I interact sincerely with people without flattery or pretending to gain favors.",
				explanationAr: "بُعد الصدق والتواضع الجوهري في نموذج HEXACO.",
				explanationEn: "Core Sincerity facet of HEXACO Honesty-Humility."
			},
			{
				subscale: "hx_honesty_humility",
				facetAr: "النزاهة والعدالة المطلقة",
				facetEn: "Fairness",
				direction: 1,
				textAr: "أرفض أخذ أي حق أو امتياز لا أستحقه حتى لو أُتيح لي ذلك دون أن يكتشفه أحد.",
				textEn: "I refuse to take unfair advantages even when guaranteed nobody would find out.",
				explanationAr: "يقيس النزاهة الأخلاقية والعدالة الذاتية تحت غياب الرقيب.",
				explanationEn: "Measures moral Fairness under private accountability."
			},
			{
				subscale: "hx_emotionality",
				facetAr: "الرقة الوجدانية والارتباط",
				facetEn: "Sentimentality",
				direction: 1,
				textAr: "تؤثر بي الروابط العاطفية الصادقة وأشعر بحاجة طبيعية للتآزر الوجداني مع من أحب.",
				textEn: "Deep emotional bonds move me strongly, and I naturally value mutual emotional solidarity.",
				explanationAr: "يرصد الحساسية الوجدانية وبُعد القرابة العاطفية في HEXACO.",
				explanationEn: "Captures Sentimentality within HEXACO Emotionality."
			},
			{
				subscale: "hx_agreeableness",
				facetAr: "الوداعة وضبط الغضب",
				facetEn: "Patience & Gentleness",
				direction: 1,
				textAr: "أحافظ على رفق لساني وأضبط غضبي حتى عندما يتصرف الآخرون باستفزاز أو تقصير.",
				textEn: "I maintain gentle speech and restrain anger even when others act carelessly.",
				explanationAr: "يعكس الصبر والحلم وضبط سرعة الغضب في نموذج HEXACO.",
				explanationEn: "Measures HEXACO Patience and Forgiveness dimensions."
			},
			{
				subscale: "hx_honesty_humility",
				facetAr: "التواضع والابتعاد عن التباهي",
				facetEn: "Modesty",
				direction: 1,
				textAr: "لا أشعر بأنني أستحق معاملة استثنائية أو تفضيلاً أعلى من سائر الناس.",
				textEn: "I do not believe I am entitled to special treatment above ordinary people.",
				explanationAr: "يقيس بُعد التواضع الحقيقي مقابل النرجسية والاستحقاق المبالغ.",
				explanationEn: "Measures Modesty versus entitlement."
			},
			{
				subscale: "hx_honesty_humility",
				facetAr: "الزهد في المظاهر الاستهلاكية",
				facetEn: "Greed Avoidance",
				direction: 1,
				textAr: "لا تتحكم المظاهر المادية الفاخرة أو التفاخر بالممتلكات في قراراتي أو تقييمي للبشر.",
				textEn: "Ostentatious luxury and material status do not drive my choices or view of people.",
				explanationAr: "بُعد تجنب الجشع المادي والتركيز على القيمة الإنسانية.",
				explanationEn: "Assesses Greed Avoidance in Ashton & Lee HEXACO."
			},
			{
				subscale: "hx_emotionality",
				facetAr: "التعاطف الجسدي-الوجداني",
				facetEn: "Emotional Reliance",
				direction: 1,
				textAr: "أجد طمأنينة حقيقية في مشاركة همومي مع شخص موثوق بدلاً من كتمانها وحيداً.",
				textEn: "I find genuine comfort in sharing worries with a trusted confidant rather than isolating.",
				explanationAr: "بُعد الاعتماد العاطفي الصحي وطلب السند النفسي.",
				explanationEn: "Evaluates healthy emotional dependence and support-seeking."
			},
			{
				subscale: "hx_agreeableness",
				facetAr: "الحلم في الخلافات (اختيار قسري)",
				facetEn: "Forbearance vs Retaliation",
				direction: 1,
				format: "forced_choice",
				textAr: "إذا صدرت إساءة غير مقصودة من شخص عزيز، كيف تميل للاستجابة؟",
				textEn: "If someone close unintentionally hurts your feelings, how do you lean toward responding?",
				explanationAr: "اختيار إجباري يقيس العفو الصادق في HEXACO مقابل العتاب القاسي.",
				explanationEn: "Forced-choice contrasting HEXACO Forgiveness vs. grudge holding.",
				forcedOptions: [{
					id: "A",
					textAr: "أصبر وأمنحه عذراً وأفتح حواراً هادئاً لتصفية القلوب سريعاً",
					textEn: "Exercise patience, offer benefit of the doubt, and clear the air calmly",
					targetSubscale: "hx_agreeableness",
					scoreValue: 5,
					traitTagAr: "حلم وتسامح",
					traitTagEn: "Forgiveness"
				}, {
					id: "B",
					textAr: "أنسحب ببرود وأتذكر الموقف طويلاً كدرس يحميني من التكرار",
					textEn: "Withdraw coldly and hold the incident in memory as guard",
					targetSubscale: "hx_agreeableness",
					scoreValue: 1,
					traitTagAr: "تحفظ عتابي",
					traitTagEn: "Guardedness"
				}]
			},
			{
				subscale: "hx_honesty_humility",
				facetAr: "الانتهازية المصلحية",
				facetEn: "Manipulativeness Check",
				direction: -1,
				textAr: "لا مانع لدي من المجاملة الزائفة أو استغلال ضعف الآخرين إذا كانت النتيجة تخدم مصلحتي.",
				textEn: "I do not mind flattery or exploiting loopholes if it clearly advances my goals.",
				explanationAr: "بند عكسي حاسم لقياس النزاهة العلائقية ومنع المراوغة.",
				explanationEn: "Reverse-keyed item screening relational sincerity vs manipulation."
			},
			{
				subscale: "hx_extraversion",
				facetAr: "التقدير الاجتماعي للذات",
				facetEn: "Social Self-Esteem",
				direction: 1,
				textAr: "أشعر بقبول ذاتي متوازن وراحة داخلية عند الحديث عن آرائي أمام الآخرين.",
				textEn: "I feel comfortably self-assured when sharing my thoughts around others.",
				explanationAr: "بُعد تقدير الذات الاجتماعي ضمن المحور السادس في HEXACO.",
				explanationEn: "Social Self-Esteem facet of HEXACO Extraversion."
			},
			{
				subscale: "hx_conscientiousness",
				facetAr: "الدقة والكمال الإيجابي",
				facetEn: "Prudence & Diligence",
				direction: 1,
				textAr: "أفحص تفاصيل الأمور بروية وحكمة قبل اتخاذ أي التزام مؤثر على مستقبلي.",
				textEn: "I weigh consequences prudently before making any commitment affecting my future.",
				explanationAr: "بُعد الحكمة والتروي (Prudence) في نموذج HEXACO.",
				explanationEn: "Prudence and diligence facet under HEXACO Conscientiousness."
			},
			{
				subscale: "hx_openness",
				facetAr: "الابتكار وتطوير الحلول",
				facetEn: "Creativity",
				direction: 1,
				textAr: "أميل لابتكار أفكار وبدائل جديدة لحل التحديات المنزلية أو المهنية المتكررة.",
				textEn: "I naturally invent fresh alternatives to solve recurring domestic or work challenges.",
				explanationAr: "يرصد الإبداع التطبيقي ضمن الانفتاح على الخبرة في HEXACO.",
				explanationEn: "Evaluates Creativity under HEXACO Openness to Experience."
			},
			{
				subscale: "hx_agreeableness",
				facetAr: "تقبل التنوع وتجنب الجدال",
				facetEn: "Flexibility",
				direction: 1,
				textAr: "أتقبل اختلاف طباع المقربين دون فرض أسلوبي كمعيار وحيد للصواب.",
				textEn: "I accept differing habits in loved ones without demanding my way as the sole standard.",
				explanationAr: "بُعد المرونة والتساهل البناء في التعايش الأسري.",
				explanationEn: "HEXACO Flexibility facet reflecting adaptability in partnership."
			},
			{
				subscale: "hx_emotionality",
				facetAr: "الحماية والسلامة الأسرية",
				facetEn: "Harm Avoidance",
				direction: 1,
				textAr: "أولي أهمية واضحة لاتخاذ احتياطات السلامة والاستقرار لحماية من أحب.",
				textEn: "I take thoughtful precautions to protect the safety and stability of loved ones.",
				explanationAr: "يعكس الحذر الوقائي والرعاية المسؤولة في HEXACO Emotionality.",
				explanationEn: "Reflects protective care and cautious prudence."
			},
			{
				subscale: "hx_honesty_humility",
				facetAr: "الشفافية في الأخطاء الشخصية",
				facetEn: "Accountability",
				direction: 1,
				textAr: "أعترف بخطئي إذا أخطأت في حق شريكي أو صديقي دون تبرير ملتف.",
				textEn: "I admit when I have wronged a partner or friend without twisting excuses.",
				explanationAr: "مؤشر عالي الدقة على النضج الأخلاقي والصدق العلائقي.",
				explanationEn: "Strong indicator of relational accountability and sincerity."
			},
			{
				subscale: "hx_extraversion",
				facetAr: "الحيوية والتفاؤل اليومي",
				facetEn: "Liveliness",
				direction: 1,
				textAr: "أستقبل يومي بروح متفائلة ونشاط يجعل التفاعل معي مريحاً ومبهجاً.",
				textEn: "I bring cheerful energy and steady optimism into daily interactions.",
				explanationAr: "بُعد الحيوية (Liveliness) في نموذج HEXACO.",
				explanationEn: "Liveliness facet in HEXACO."
			},
			{
				subscale: "hx_conscientiousness",
				facetAr: "الإهمال تحت غياب المتابعة",
				facetEn: "Slackness Check",
				direction: -1,
				textAr: "أهمل جودة إنجازي إذا شعرت أنه لن تتم مراجعة العمل بدقة.",
				textEn: "I lower my standards whenever I suspect my work will not be checked closely.",
				explanationAr: "بند عكسي يقيس الضمير الداخلي المستقل.",
				explanationEn: "Reverse-keyed diligence integrity check."
			},
			{
				subscale: "hx_openness",
				facetAr: "الفضول المعرفي المتنوع",
				facetEn: "Inquisitiveness",
				direction: 1,
				textAr: "أستمتع بالقراءة أو التعلم حول العلوم والثقافات المختلفة خارج نطاق تخصصي.",
				textEn: "I enjoy reading and learning about science and world cultures beyond my field.",
				explanationAr: "بُعد الاستطلاع الفكري (Inquisitiveness) في HEXACO.",
				explanationEn: "Inquisitiveness facet of HEXACO Openness."
			},
			{
				subscale: "hx_honesty_humility",
				facetAr: "الأمانة المالية المشتركة",
				facetEn: "Financial Honesty",
				direction: 1,
				textAr: "أؤمن بأن الوضوح المالي الكامل وعدم إخفاء التزامات مهمة شرط لثقة الشراكة.",
				textEn: "I believe complete financial honesty about obligations is essential for lasting trust.",
				explanationAr: "تطبيق مباشر لبُعد العدالة والصدق على الشراكة الأسرية.",
				explanationEn: "Applies HEXACO Fairness & Sincerity to shared domestic finances."
			},
			{
				subscale: "hx_agreeableness",
				facetAr: "التحكم في سرعة الانفعال",
				facetEn: "Anger Inhibition",
				direction: -1,
				textAr: "أفقد أعصابي سريعاً عندما تسير الأمور ببطء أو يُخطئ من حولي مراراً.",
				textEn: "I quickly lose my temper when things move slowly or people repeat minor mistakes.",
				explanationAr: "بند عكسي يقيس سرعة الغضب مقابل الحلم.",
				explanationEn: "Reverse-keyed patience marker."
			},
			{
				subscale: "hx_emotionality",
				facetAr: "التأثر الوجداني بمشاعر القريبين",
				facetEn: "Empathic Resonance",
				direction: 1,
				textAr: "أشعر بتعاطف صادق وعميق حين يمر أحد المقربين مني بمحنة أو حزن.",
				textEn: "I feel deeply touched and present when someone close to me goes through grief.",
				explanationAr: "بُعد الرقة العاطفية والتعاضد الأسري.",
				explanationEn: "Reflects sentimentality and affective resonance."
			},
			{
				subscale: "hx_conscientiousness",
				facetAr: "دقة الكمال التنظيمي",
				facetEn: "Perfectionism",
				direction: 1,
				textAr: "أتحرى الدقة والإتقان في كل مهمة أضع اسمي عليها مهما كانت صغيرة.",
				textEn: "I strive for thorough precision in every task carrying my name.",
				explanationAr: "بُعد الإتقان (Perfectionism) الإيجابي في نموذج HEXACO.",
				explanationEn: "Perfectionism & quality striving facet in HEXACO."
			},
			{
				subscale: "hx_extraversion",
				facetAr: "الدفء عند الترحيب",
				facetEn: "Social Boldness",
				direction: 1,
				textAr: "أشعر بالثقة عند التعبير عن رأيي وسط مجموعة دون تردد أو رهبة مفرطة.",
				textEn: "I express my thoughts comfortably within group discussions without excessive hesitation.",
				explanationAr: "بُعد الجرأة الاجتماعية المنفتحة.",
				explanationEn: "Social boldness dimension of HEXACO Extraversion."
			},
			{
				subscale: "hx_openness",
				facetAr: "رفض التنميط الجامد",
				facetEn: "Unconventionality",
				direction: 1,
				textAr: "أتقبل وجود طرق مختلفة للنجاح الحياتي ولا أفرض قالباً واحداً على الجميع.",
				textEn: "I appreciate diverse paths to a fulfilling life rather than insisting on one mold.",
				explanationAr: "بُعد تقبل التنوع الفكري (Unconventionality).",
				explanationEn: "Unconventionality facet of HEXACO Openness."
			},
			{
				subscale: "hx_honesty_humility",
				facetAr: "الاختيار القسري: النزاهة vs المظهر",
				facetEn: "Substance vs Status",
				direction: 1,
				format: "forced_choice",
				textAr: "عند تقييم نجاح شراكة حياة، أيهما أكثر وزناً لديك؟",
				textEn: "When judging the success of a life partnership, what holds more weight for you?",
				explanationAr: "مقياس قسري يفرق بين التواضع والقيم الجوهرية وبين الهوس بالمظهر.",
				explanationEn: "Forced-choice contrasting Honesty-Humility with status-seeking.",
				forcedOptions: [{
					id: "A",
					textAr: "النقاء الأخلاقي والصدق في الخفاء والعلن والسكينة الداخلية",
					textEn: "Moral integrity, sincerity in private and public, and inner peace",
					targetSubscale: "hx_honesty_humility",
					scoreValue: 5,
					traitTagAr: "صدق وتواضع أصيل",
					traitTagEn: "High Honesty-Humility"
				}, {
					id: "B",
					textAr: "الصورة الاجتماعية اللامعة والمكانة المظهرية أمام المحيط الخارجي",
					textEn: "Prestigious outward image and social status in front of others",
					targetSubscale: "hx_honesty_humility",
					scoreValue: 2,
					traitTagAr: "اهتمام بالمظهر",
					traitTagEn: "Status Orientation"
				}]
			},
			{
				subscale: "hx_agreeableness",
				facetAr: "ترك الجدال العقيم",
				facetEn: "Gentleness",
				direction: 1,
				textAr: "أتجنب السخرية أو الانتقاص من قدرات الآخرين حتى أثناء النقاشات الساخنة.",
				textEn: "I avoid sarcasm or belittling others even during heated discussions.",
				explanationAr: "يقيس رقي الحوار وصون الكرامة أثناء الاختلاف.",
				explanationEn: "Measures Gentleness and verbal restraint."
			},
			{
				subscale: "hx_emotionality",
				facetAr: "الاستقرار في الأزمات المادية",
				facetEn: "Fearfulness Check",
				direction: -1,
				textAr: "يسيطر علي الخوف الشديد بسهولة عند سماع أي تغيرات اقتصادية أو صحية محتملة.",
				textEn: "I easily become consumed by fear over potential health or economic uncertainties.",
				explanationAr: "يرصد درجة القلق الحمائي (Fearfulness) في HEXACO Emotionality.",
				explanationEn: "Evaluates Fearfulness facet under Emotionality."
			},
			{
				subscale: "hx_conscientiousness",
				facetAr: "تنظيم الوقت اليومي",
				facetEn: "Organization",
				direction: 1,
				textAr: "أحدد أولوياتي في بداية اليوم ولا أترك المهام تتراكم عشوائياً.",
				textEn: "I clarify priorities early and prevent responsibilities from piling up haphazardly.",
				explanationAr: "بُعد التنظيم والتخطيط التنفيذي.",
				explanationEn: "Organization facet in HEXACO."
			},
			{
				subscale: "hx_extraversion",
				facetAr: "الانعزال الدائم",
				facetEn: "Sociability Check",
				direction: -1,
				textAr: "أتجنب المشاركة في المناسبات العائلية والاجتماعية حتى لو كانت مهمة لأحبائي.",
				textEn: "I avoid family and social gatherings even when they matter greatly to loved ones.",
				explanationAr: "بند عكسي يقيس الانسحاب الاجتماعي المفرط.",
				explanationEn: "Reverse-keyed Sociability check."
			},
			{
				subscale: "hx_openness",
				facetAr: "الإبداع التعبيري",
				facetEn: "Aesthetic Appreciation",
				direction: 1,
				textAr: "أجد متعة في القراءة الفكرية والفنون الهادفة التي تلامس النفس البشرية.",
				textEn: "I find deep fulfillment in thoughtful literature and arts that illuminate human experience.",
				explanationAr: "التذوق الفكري والجمالي في HEXACO.",
				explanationEn: "Aesthetic Appreciation facet."
			},
			{
				subscale: "hx_honesty_humility",
				facetAr: "رفض الغرور الفكري",
				facetEn: "Intellectual Modesty",
				direction: 1,
				textAr: "لا أتظاهر بمعرفة أمر أجهله لمجرد كسب إعجاب الحاضرين.",
				textEn: "I never pretend to know something I do not just to impress those around me.",
				explanationAr: "مؤشر صادق للتواضع المعرفي وعدم التصنع.",
				explanationEn: "Direct indicator of intellectual sincerity and modesty."
			},
			{
				subscale: "hx_agreeableness",
				facetAr: "المرونة في تقاسم القرار",
				facetEn: "Shared Decision Compromise",
				direction: 1,
				textAr: "عندما لا يمس الخلاف الثوابت، أقبل برأي شريكي برحابة صدر وسرور.",
				textEn: "On non-core matters, I happily accommodate my partner’s preference with warmth.",
				explanationAr: "مؤشر المرونة الزوجية في نموذج HEXACO.",
				explanationEn: "Practical Flexibility marker in dyadic life."
			},
			{
				subscale: "hx_conscientiousness",
				facetAr: "المسؤولية عن العواقب",
				facetEn: "Diligence & Ownership",
				direction: 1,
				textAr: "أتحمل مسؤولية نتائج اختياراتي بالكامل دون إلقاء اللوم على الظروف أو الآخرين.",
				textEn: "I take full ownership of my choices without blaming circumstances or others.",
				explanationAr: "يمثل الضمير الناضج والمسؤولية الذاتية.",
				explanationEn: "Represents mature accountability under Conscientiousness."
			},
			{
				subscale: "hx_emotionality",
				facetAr: "الدفء الأسري والانتماء",
				facetEn: "Kinship Sentiment",
				direction: 1,
				textAr: "تحافظ الذكريات الأسرية الدافئة على مكانتها العميقة في وجداني مع مرور السنوات.",
				textEn: "Warm family memories and traditions hold deep, lasting meaning for me.",
				explanationAr: "بُعد العاطفة والانتماء الأسري في HEXACO.",
				explanationEn: "Kinship sentimentality marker."
			},
			{
				subscale: "hx_openness",
				facetAr: "الجمود الفكري",
				facetEn: "Dogmatism Check",
				direction: -1,
				textAr: "أرى النقاش مع أصحاب الآراء المخالفة مضيعة للوقت لأن قناعاتي لا تقبل المراجعة.",
				textEn: "Debating differing perspectives feels pointless since my views are already settled.",
				explanationAr: "بند عكسي يقيس الانفتاح مقابل الانغلاق الفكري.",
				explanationEn: "Reverse-keyed check for intellectual openness."
			},
			{
				subscale: "hx_extraversion",
				facetAr: "الحضور الودود",
				facetEn: "Warmth & Sociability",
				direction: 1,
				textAr: "أبادر بالسلام والابتسامة الدافئة عندما أدخل مكاناً يضم معارفاً أو أصدقاء.",
				textEn: "I greet people warmly with a smile and friendly energy when joining a group.",
				explanationAr: "يعكس الدفء الاجتماعي الإيجابي.",
				explanationEn: "Reflects positive social warmth."
			}
		],
		ref: CONSTRUCT_SCIENTIFIC_CATALOG.hexaco.referenceAr
	},
	{
		construct: "attachment",
		seeds: [
			{
				subscale: "att_anxiety",
				facetAr: "القلق من فقدان المحبة",
				facetEn: "Fear of Abandonment",
				direction: 1,
				textAr: "ينتابني قلق متكرر من أن تتناقص مشاعر الشخص المقرب مني أو يبتعد فجأة دون سبب.",
				textEn: "I often worry that a close partner might lose interest or pull away unexpectedly.",
				explanationAr: "يقيس محور قلق التعلق (Attachment Anxiety) في مقياس ECR-R.",
				explanationEn: "Core Attachment Anxiety indicator in Fraley’s ECR-R."
			},
			{
				subscale: "att_avoidance",
				facetAr: "تجنب الاعتمادية العاطفية",
				facetEn: "Discomfort with Closeness",
				direction: 1,
				textAr: "أشعر بعدم ارتياح عندما يطلب مني الآخرون انفتاحاً عاطفياً عميقاً أو اعتماداً وجدانياً متبادلاً.",
				textEn: "I feel uncomfortable when others seek deep emotional closeness or mutual dependence.",
				explanationAr: "يقيس محور تجنب القرب العاطفي (Attachment Avoidance).",
				explanationEn: "Core Attachment Avoidance indicator in ECR-R."
			},
			{
				subscale: "att_security",
				facetAr: "الأمان العاطفي المكتسب",
				facetEn: "Relational Security",
				direction: 1,
				textAr: "أستطيع التعبير عن احتياجاتي العاطفية بصراحة وهدوء مع الثقة في تقبل الطرف الآخر لي.",
				textEn: "I can express my emotional needs openly and calmly, trusting they will be received well.",
				explanationAr: "مؤشر مباشر لنمط التعلق الآمن (Secure Attachment).",
				explanationEn: "Direct indicator of Secure Adult Attachment."
			},
			{
				subscale: "att_anxiety",
				facetAr: "الحاجة للتطمين المستمر",
				facetEn: "Reassurance Seeking",
				direction: 1,
				textAr: "إذا تأخر شريكي في الرد أو بدا منشغلاً، أفسر ذلك غالباً على أنه فتور أو انزعاج مني.",
				textEn: "When a partner is slow to respond or quiet, I tend to fear they are upset with me.",
				explanationAr: "يقيس فرط يقظة التعلق القلق تجاه إشارات البُعد.",
				explanationEn: "Evaluates anxious hypervigilance toward perceived distance."
			},
			{
				subscale: "att_avoidance",
				facetAr: "الاكتفاء الانفعالي المغلق",
				facetEn: "Compulsive Self-Reliance",
				direction: 1,
				textAr: "أفضل مواجهة أزماتي النفسية وحدي تماماً بدلاً من اللجوء لاحتواء من أحب.",
				textEn: "I prefer handling emotional distress completely alone rather than leaning on loved ones.",
				explanationAr: "يرصد الاستقلالية التجنبية الدفاعية عن الضعف الوجداني.",
				explanationEn: "Measures defensive self-reliance under Attachment Avoidance."
			},
			{
				subscale: "att_security",
				facetAr: "التوازن بين القرب والحرية",
				facetEn: "Autonomy-Closeness Balance",
				direction: 1,
				textAr: "أستمتع بالقرب الدافئ مع شريكي وأحترم في الوقت ذاته حاجة كلينا للمساحة الشخصية.",
				textEn: "I enjoy warm closeness while comfortably respecting each other’s personal space.",
				explanationAr: "العلامة الفارقة للنضج العلائقي والارتباط الآمن.",
				explanationEn: "Hallmark of healthy interdependence in Secure Attachment."
			},
			{
				subscale: "att_anxiety",
				facetAr: "الاختيار القسري: تفسير الصمت",
				facetEn: "Silence Attribution",
				direction: 1,
				format: "forced_choice",
				textAr: "حين يحتاج المقرب منك لبعض الهدوء والصمت ليوم واحد، أي شعور يغلب عليك؟",
				textEn: "When a loved one needs a quiet day to recharge, which internal reaction prevails?",
				explanationAr: "يميز بين القلق العلائقي والأمان النفسي في مواقف الصمت.",
				explanationEn: "Distinguishes anxious attribution from secure emotional trust.",
				forcedOptions: [{
					id: "A",
					textAr: "أتفهم حاجته للهدوء وأثق أن علاقتنا ثابتة وآمنة دون قلق",
					textEn: "Understand their need for quiet and trust our bond remains steady",
					targetSubscale: "att_security",
					scoreValue: 5,
					traitTagAr: "أمان ارتباطي",
					traitTagEn: "Secure Trust"
				}, {
					id: "B",
					textAr: "أشعر بتوتر داخلي وأبحث عن إشارات تؤكد أنني ما زلت محبوباً",
					textEn: "Feel uneasy inside and look for reassurance that everything is fine",
					targetSubscale: "att_anxiety",
					scoreValue: 5,
					traitTagAr: "حساسية قلقية",
					traitTagEn: "Anxious Sensitivity"
				}]
			},
			{
				subscale: "att_avoidance",
				facetAr: "الارتباك من البوح العميق",
				facetEn: "Intimacy Discomfort",
				direction: 1,
				textAr: "أغلق باب الحوار أو أغير الموضوع عندما تصبح المشاعر المتبادلة شديدة العمق والحميمية.",
				textEn: "I tend to deflect or change the subject when emotional intimacy gets very deep.",
				explanationAr: "يكشف التجنب الانفعالي عند ارتفاع درجة القرب الحميمي.",
				explanationEn: "Assesses deactivating strategies under high emotional intimacy."
			},
			{
				subscale: "att_security",
				facetAr: "الثقة في النية الطيبة",
				facetEn: "Benign Attribution",
				direction: 1,
				textAr: "أفترض حسن النية في تصرفات من أحب قبل القفز إلى استنتاجات سلبية عن الرفض.",
				textEn: "I assume benign intent in my partner’s behavior before jumping to negative conclusions.",
				explanationAr: "يعكس الاستقرار الوجداني وثقة القاعدة الآمنة (Bowlby Secure Base).",
				explanationEn: "Reflects Bowlby’s secure internal working model of others."
			},
			{
				subscale: "att_anxiety",
				facetAr: "شدة الانفعال عند الخلاف",
				facetEn: "Protest Behavior",
				direction: 1,
				textAr: "عندما أشعر بالتهميش، أميل لإظهار استياء قوي لإجبار الطرف الآخر على الانتباه لي.",
				textEn: "When feeling neglected, I tend to react strongly to compel my partner’s attention.",
				explanationAr: "يقيس سلوكيات الاحتجاج المميزة للقلق الارتباطي.",
				explanationEn: "Captures attachment protest behaviors under distress."
			},
			{
				subscale: "att_avoidance",
				facetAr: "الاستغناء السريع عند التعقيد",
				facetEn: "Deactivation Reflex",
				direction: 1,
				textAr: "أميل لتقليل تعلقي العاطفي وإقناع نفسي بعدم الحاجة لأحد بمجرد ظهور خلاف جاد.",
				textEn: "I mentally detach and convince myself I need no one as soon as serious tension appears.",
				explanationAr: "يكشف آليات التعطيل (Deactivation) في الارتباط التجنبي.",
				explanationEn: "Identifies avoidant emotional deactivation during conflict."
			},
			{
				subscale: "att_security",
				facetAr: "قبول الضعف الإنساني الآمن",
				facetEn: "Safe Vulnerability",
				direction: 1,
				textAr: "أشعر بالأمان عندما أشارك مخاوفي وضعفي الإنساني مع الشريك الموثوق دون خوف من الاستغلال.",
				textEn: "I feel safe sharing personal vulnerabilities with a trusted partner without fear.",
				explanationAr: "الركيزة الأساسية للحميمية النفسية الآمنة.",
				explanationEn: "Core indicator of safe emotional vulnerability."
			},
			{
				subscale: "att_anxiety",
				facetAr: "طمأنينة الحب المتبادل",
				facetEn: "Felt Security Check",
				direction: -1,
				textAr: "أشعر بيقين مطمئن بأن من يحبني يقدرني ويبقى إلى جواري رغم الاختلافات اليومية.",
				textEn: "I feel calmly certain that loved ones care for me despite ordinary disagreements.",
				explanationAr: "بند عكسي لقلق التعلق يقيس اليقين العاطفي.",
				explanationEn: "Reverse-scored anxiety item checking baseline emotional certainty."
			},
			{
				subscale: "att_avoidance",
				facetAr: "الانسيابية في الاعتماد المتبادل",
				facetEn: "Interdependence Ease",
				direction: -1,
				textAr: "أجد لذة ودفئاً في استشارة شريكي والاتكاء على دعمه عند الحاجة.",
				textEn: "I genuinely enjoy leaning on my partner for counsel and comfort when needed.",
				explanationAr: "بند عكسي لتجنب الارتباط يقيس راحة الاعتماد المتبادل.",
				explanationEn: "Reverse-scored avoidance item assessing comfort with interdependence."
			},
			{
				subscale: "att_security",
				facetAr: "الإصلاح السريع للروابط",
				facetEn: "Repair Confidence",
				direction: 1,
				textAr: "أؤمن أن أي سوء فهم بين الشريكين يمكن إصلاحه بالحوار الهادئ دون تهديد لكيان العلاقة.",
				textEn: "I believe misunderstandings can be repaired constructively without threatening the bond.",
				explanationAr: "يقيس متانة الأمان الارتباطي أثناء النزاعات.",
				explanationEn: "Assesses security of attachment under relational conflict."
			},
			{
				subscale: "att_anxiety",
				facetAr: "تقلب النظرة للذات في الحب",
				facetEn: "Self-Worth Fluctuation",
				direction: 1,
				textAr: "يتأثر شعوري بقيمتي الشخصية بقوة بمستوى الحفاوة والاهتمام الذي أتلقاه في ذلك اليوم.",
				textEn: "My sense of personal worth rises and falls sharply depending on daily affection received.",
				explanationAr: "يرصد ارتباط نموذج الذات القلق بالتحقق الخارجي المستمر.",
				explanationEn: "Reflects anxious model-of-self contingent on external validation."
			},
			{
				subscale: "att_avoidance",
				facetAr: "المسافة النفسية الدائمة",
				facetEn: "Emotional Guardrails",
				direction: 1,
				textAr: "أحتفظ دائماً بمسافة أمان نفسية تمنع أي إنسان من الوصول الكامل لأعماقي.",
				textEn: "I keep an emotional barrier so nobody ever gets completely close to my inner world.",
				explanationAr: "مؤشر أساسي للتجنب الخائف أو الرافض للقرب.",
				explanationEn: "Core Avoidance marker measuring emotional distance barriers."
			},
			{
				subscale: "att_security",
				facetAr: "دعم استقلالية الشريك",
				facetEn: "Secure Base Support",
				direction: 1,
				textAr: "أشجع من أحب على تحقيق طموحاته الخاصة بثقة دون أن أشعر بالتهديد أو الغيرة.",
				textEn: "I encourage my partner’s personal growth with confidence rather than insecurity.",
				explanationAr: "تطبيق دور \"القاعدة الآمنة\" (Secure Base) الداعمة للنمو في نظرية بولبي.",
				explanationEn: "Embodies Bowlby’s supportive Secure Base caregiving role."
			},
			{
				subscale: "att_anxiety",
				facetAr: "تخيل الهجر المفاجئ",
				facetEn: "Abandonment Expectation",
				direction: 1,
				textAr: "يخطر ببالي أحياناً أن العلاقات الصادقة قد لا تدوم وأن البقاء مخلصاً أمر نادر.",
				textEn: "I sometimes expect that even close bonds rarely last reliably over time.",
				explanationAr: "يقيس توقعات عدم الثبات المتجذرة في الارتباط القلق.",
				explanationEn: "Measures chronic abandonment expectations."
			},
			{
				subscale: "att_avoidance",
				facetAr: "الحرية الفردية المطلقة",
				facetEn: "Autonomy Prioritization",
				direction: 1,
				textAr: "أعتبر الحفاظ على حريتي الفردية التامة أهم من الانغماس في شراكة عاطفية وثيقة.",
				textEn: "Preserving complete individual freedom outweighs close emotional entanglement for me.",
				explanationAr: "بُعد التفضيل التجنبي المفرط للاستقلال على الارتباط.",
				explanationEn: "Dismissive-avoidant prioritization of autonomy over attachment."
			},
			{
				subscale: "att_security",
				facetAr: "الحضور الوجداني المستقر",
				facetEn: "Emotional Availability",
				direction: 1,
				textAr: "أبقى حاضراً ومنصتاً لمشاعر شريكي حين يمر بضيق دون تهرب أو تقليل من شعوره.",
				textEn: "I stay emotionally present and attentive when my partner hurts without pulling away.",
				explanationAr: "يقيس الاستجابة الآمنة والاحتواء العاطفي (Safe Haven).",
				explanationEn: "Assesses Safe Haven responsiveness under Secure Attachment."
			},
			{
				subscale: "att_anxiety",
				facetAr: "الغضب الناتج عن عدم الرد",
				facetEn: "Anxious Resentment",
				direction: 1,
				textAr: "أشعر باستياء داخلي إذا لم يبادر شريكي بالتعبير عن اهتمامه بالقدر الذي أتوقعه.",
				textEn: "I feel resentful when my partner does not initiate affection as often as I expect.",
				explanationAr: "يرصد توتر الفجوة بين الحاجة القلقة والاستجابة المتوقعة.",
				explanationEn: "Reflects anxious preoccupation with perceived affection gaps."
			},
			{
				subscale: "att_avoidance",
				facetAr: "نسيان البوح العاطفي",
				facetEn: "Verbal Affection Inhibition",
				direction: 1,
				textAr: "أجد صعوبة في التعبير اللفظي الصريح عن حبي وامتنان قلبي للمقربين.",
				textEn: "I struggle to verbalize warm affection and deep appreciation explicitly.",
				explanationAr: "يعكس التحفظ التجنبي في الإفصاح العاطفي.",
				explanationEn: "Captures avoidant inhibition in affectionate disclosure."
			},
			{
				subscale: "att_security",
				facetAr: "التوافق مع القرب الجسدي والمعنوي",
				facetEn: "Intimacy Comfort",
				direction: 1,
				textAr: "يسهل عليّ الاقتراب العاطفي الصادق دون أن أشعر بالاختناق أو فقدان الهوية.",
				textEn: "True emotional closeness comes naturally without feeling suffocated or losing myself.",
				explanationAr: "يقيس التمايز النفسي الصحي داخل القرب الحميم.",
				explanationEn: "Measures healthy differentiation inside deep intimacy."
			},
			{
				subscale: "att_avoidance",
				facetAr: "الاختيار القسري: الاحتواء vs الانسحاب",
				facetEn: "Distress Coping Strategy",
				direction: 1,
				format: "forced_choice",
				textAr: "عندما تمر بأزمة نفسية شخصية، ما الخيار الأقرب لطبيعتك؟",
				textEn: "During a personal emotional crisis, which response matches your instinct better?",
				explanationAr: "اختيار إجباري بين اللجوء للملاذ الآمن والانكفاء التجنبي.",
				explanationEn: "Forced-choice separating secure support-seeking from avoidant withdrawal.",
				forcedOptions: [{
					id: "A",
					textAr: "الانكفاء في غرفتي ومحاولة تجاوز الألم بصمت دون إشعار أحد",
					textEn: "Retreat quietly alone to process pain without letting anyone in",
					targetSubscale: "att_avoidance",
					scoreValue: 5,
					traitTagAr: "ميل تجنبي للانكفاء",
					traitTagEn: "Avoidant Withdrawal"
				}, {
					id: "B",
					textAr: "البوح لشخص أثق بمحبته لأستمد الطمأنينة والوضوح معاً",
					textEn: "Reach out to a trusted loved one for comforting dialogue",
					targetSubscale: "att_security",
					scoreValue: 5,
					traitTagAr: "ارتباط آمن تشاركي",
					traitTagEn: "Secure Co-Regulation"
				}]
			},
			{
				subscale: "att_anxiety",
				facetAr: "الغيرة المقارنة المفرطة",
				facetEn: "Relational Insecurity",
				direction: 1,
				textAr: "أقارن نفسي أحياناً بالآخرين خوفاً من ألا أكون كافياً لدوام محبة من أحب.",
				textEn: "I sometimes compare myself anxiously to others, fearing I might not be enough.",
				explanationAr: "يعكس قلق الجدارة والاستبدال في العلاقات.",
				explanationEn: "Reflects anxiety over adequacy within attachment."
			},
			{
				subscale: "att_security",
				facetAr: "الحدود الواضحة بدون جفاء",
				facetEn: "Compassionate Boundaries",
				direction: 1,
				textAr: "أستطيع قول \"لا\" بلطف ووضوح دون خوف من خسارة محبة الطرف الآخر.",
				textEn: "I can say no kindly and clearly without fearing abandonment.",
				explanationAr: "علامة قوية للأمان الداخلي وخلو العلاقة من التعلق الاعتمادي.",
				explanationEn: "Key marker of secure boundaries free of anxious appeasement."
			},
			{
				subscale: "att_avoidance",
				facetAr: "التشكيك في التزام الآخرين",
				facetEn: "Trust Hesitation",
				direction: 1,
				textAr: "أجد صعوبة بالغة في تسليم ثقتي الكاملة لأي شخص مهما طال زمن معرفتنا.",
				textEn: "I find it very difficult to trust anyone fully regardless of how long we have known each other.",
				explanationAr: "يقيس عدم الثقة الدفاعي في البُعد التجنبي.",
				explanationEn: "Measures defensive distrust under Avoidance."
			},
			{
				subscale: "att_anxiety",
				facetAr: "التضحية المفرطة لإرضاء الشريك",
				facetEn: "Over-Accommodating Anxiety",
				direction: 1,
				textAr: "أتنازل عن رغباتي الأساسية مراراً خوفاً من إثارة غضب الشريك أو ابتعاده.",
				textEn: "I repeatedly sacrifice core personal needs out of fear of upsetting or losing a partner.",
				explanationAr: "يكشف التنازل بدافع القلق الارتباطي وليس الإيثار الصحي.",
				explanationEn: "Distinguishes fear-driven appeasement from healthy generosity."
			},
			{
				subscale: "att_security",
				facetAr: "التفاؤل العلائقي الصحي",
				facetEn: "Relational Confidence",
				direction: 1,
				textAr: "أدخل العلاقات الجادة بتوازن إيجابي يسمح بظهور المودة وتقبل الاختلاف الطبيعي.",
				textEn: "I enter committed relationships with grounded trust and openness to natural differences.",
				explanationAr: "يعكس نموذج التعلق الإيجابي للذات وللآخرين.",
				explanationEn: "Reflects dual positive working models of self and other."
			},
			{
				subscale: "att_avoidance",
				facetAr: "النفور من الالتزام طويل المدى",
				facetEn: "Commitment Hesitation",
				direction: 1,
				textAr: "تشعرني الوعود والعقود العاطفية طويلة الأمد بالثقل والرغبة في التراجع.",
				textEn: "Long-term emotional commitments make me feel trapped or eager to pull back.",
				explanationAr: "مؤشر مباشر على تجنب الالتزام الحميمي.",
				explanationEn: "Assesses avoidant discomfort with long-horizon commitment."
			},
			{
				subscale: "att_anxiety",
				facetAr: "قراءة النوايا القلقة",
				facetEn: "Hyper-Scanning Cues",
				direction: 1,
				textAr: "أراقب نبرة الصوت وتفاصيل الوجوه بحساسية مفرطة بحثاً عن أي علامة رفض خفية.",
				textEn: "I hyper-scan tone of voice and facial cues for any hidden hint of rejection.",
				explanationAr: "يقيس الحساسية الفائقة لإشارات التهديد العلائقي.",
				explanationEn: "Hypervigilant threat scanning in anxious attachment."
			},
			{
				subscale: "att_security",
				facetAr: "استقرار الانتماء المشترك",
				facetEn: "Felt Mutuality",
				direction: 1,
				textAr: "أشعر بأن الاعتماد المتبادل بين شريكين ناضجين يضاعف قوة كل طرف ولا ينقص حريته.",
				textEn: "Healthy mutual reliance strengthens both partners rather than diminishing freedom.",
				explanationAr: "المبدأ الأساسي للتكامل العلائقي الآمن.",
				explanationEn: "Core principle of mature secure interdependence."
			},
			{
				subscale: "att_avoidance",
				facetAr: "الانفتاح التلقائي (عكسي)",
				facetEn: "Disclosure Comfort",
				direction: -1,
				textAr: "أبادر بمشاركة أفكاري الخاصة وخططي اليومية بعفوية مع من أثق به.",
				textEn: "I share personal reflections and daily plans naturally with trusted companions.",
				explanationAr: "بند عكسي للتجنب يكشف طلاقة الإفصاح الذاتي.",
				explanationEn: "Reverse-scored avoidance item reflecting spontaneous self-disclosure."
			},
			{
				subscale: "att_anxiety",
				facetAr: "التعلق المتعجل",
				facetEn: "Premature Merging",
				direction: 1,
				textAr: "أرغب أحياناً في ذوبان سريع وكامل في العلاقة لدرجة قد تربك وتيرة التدرج الطبيعي.",
				textEn: "I sometimes crave rapid complete merging faster than healthy pacing allows.",
				explanationAr: "يرصد اندفاع الارتباط القلق للتحقق السريع من القبول.",
				explanationEn: "Captures anxious urgency for premature emotional fusion."
			},
			{
				subscale: "att_security",
				facetAr: "التعاطف الآمن دون استنزاف",
				facetEn: "Grounded Empathy",
				direction: 1,
				textAr: "أواسي حزن شريكي بحب حقيقي دون أن أغرق في دوامة ذعر أو عجز معه.",
				textEn: "I comfort a distressed partner steadily without becoming overwhelmed myself.",
				explanationAr: "يدمج الأمان العلائقي بالتمايز العاطفي الصحي.",
				explanationEn: "Combines secure soothing with emotional groundedness."
			}
		],
		ref: CONSTRUCT_SCIENTIFIC_CATALOG.attachment.referenceAr
	},
	{
		construct: "emotional_intelligence",
		seeds: [
			{
				subscale: "ei_self_awareness",
				facetAr: "تسمية المشاعر وفهمها",
				facetEn: "Emotional Self-Awareness",
				direction: 1,
				textAr: "أدرك بدقة ما أشعر به في اللحظة الراهنة (غضب، خيبة، قلق، أو خجل) وأعرف سببه الجذري.",
				textEn: "I accurately identify what I am feeling in the moment and recognize its underlying trigger.",
				explanationAr: "الفرع الأول في نموذج ماير وسالوفي: إدراك وفهم المشاعر الذاتية.",
				explanationEn: "Branch 1 of Mayer-Salovey EI: accurate emotional perception & awareness."
			},
			{
				subscale: "ei_empathy",
				facetAr: "قراءة الإشارات غير اللفظية",
				facetEn: "Empathic Decoding",
				direction: 1,
				textAr: "أنتبه بسهولة لتغير نبرة صوت الآخرين وتعبيراتهم الدقيقة حتى قبل أن يصرحوا بما يزعجهم.",
				textEn: "I pick up subtle shifts in tone and expression even before people state their distress.",
				explanationAr: "يقيس البصيرة الوجدانية والتعاطف المعرفي مع المحيط.",
				explanationEn: "Measures empathetic decoding of nonverbal emotional cues."
			},
			{
				subscale: "ei_regulation",
				facetAr: "إدارة الانفعال داخل التواصل",
				facetEn: "Emotion Management",
				direction: 1,
				textAr: "أتحكم في اختيار توقيت وطريقة تعبيري عن الغضب بحيث يصل المضمون دون جرح للطرف الآخر.",
				textEn: "I choose how and when to express frustration so the message lands respectfully.",
				explanationAr: "يمثل إدارة الانفعالات في نموذج جولمان وبار-أون للذكاء العاطفي.",
				explanationEn: "Represents constructive emotion management in close dialogue."
			},
			{
				subscale: "ei_social_skill",
				facetAr: "احتواء التوتر الاجتماعي",
				facetEn: "Relational Regulation",
				direction: 1,
				textAr: "أجيد تهدئة الأجواء المشحونة بكلمة حكيمة أو لمسة تقدير تعيد الطمأنينة للحوار.",
				textEn: "I help de-escalate tense conversations with calm validation that restores safety.",
				explanationAr: "يقيس مهارة توجيه المناخ العاطفي الإيجابي للعلاقة.",
				explanationEn: "Assesses social-emotional regulation capacity."
			},
			{
				subscale: "ei_self_awareness",
				facetAr: "التمييز بين الشعور والفكرة",
				facetEn: "Affect-Thought Differentiation",
				direction: 1,
				textAr: "أميز بين انزعاجي الداخلي العابر وبين التقييم الموضوعي الحقيقي لتصرفات الطرف الآخر.",
				textEn: "I separate my passing internal stress from an objective reading of another’s actions.",
				explanationAr: "تطبيق الذكاء العاطفي لمنع إسقاط التوتر الشخصي على الشريك.",
				explanationEn: "Prevents emotional spillover and misattribution."
			},
			{
				subscale: "ei_empathy",
				facetAr: "استشعار الاحتياج المستتر",
				facetEn: "Implicit Need Sensing",
				direction: 1,
				textAr: "أستشعر متى يحتاج من أحب إلى الإنصات والاحتواء فقط وليس إلى النصائح المباشرة.",
				textEn: "I recognize when a loved one needs empathetic listening rather than unsolicited fixes.",
				explanationAr: "نضج عاطفي يوازن بين التعاطف والحلول العقلانية.",
				explanationEn: "Distinguishes emotional validation needs from problem-solving."
			},
			{
				subscale: "ei_regulation",
				facetAr: "الاختيار القسري: الاحتواء vs التحليل البارد",
				facetEn: "Emotional Validation Choice",
				direction: 1,
				format: "forced_choice",
				textAr: "عندما يشتكي شريكك بانفعال من ضغط مر به اليوم، كيف تستجيب أولاً؟",
				textEn: "When your partner vents emotionally about a hard day, what is your initial instinct?",
				explanationAr: "اختيار إجباري يقيس الأولوية العاطفية (الاحتواء مقابل التدخل المنطقي المبكر).",
				explanationEn: "Forced-choice gauging emotional attunement vs premature intellectualizing.",
				forcedOptions: [{
					id: "A",
					textAr: "أحتوي مشاعره وأؤكد تفهمي لضيقه قبل الانتقال لأي اقتراح عملي",
					textEn: "Validate feelings and offer warm presence before proposing solutions",
					targetSubscale: "ei_empathy",
					scoreValue: 5,
					traitTagAr: "احتواء وجداني ذكي",
					traitTagEn: "Empathetic Validation"
				}, {
					id: "B",
					textAr: "أقاطعه سريعاً بتحليل منطقي لأخطائه وكيف كان يجب أن يتصرف",
					textEn: "Jump straight into analyzing mistakes and rational fixes",
					targetSubscale: "ei_empathy",
					scoreValue: 2,
					traitTagAr: "تدخل تحليلي مباشر",
					traitTagEn: "Premature Fixing"
				}]
			},
			{
				subscale: "ei_self_awareness",
				facetAr: "العمى العاطفي المؤقت",
				facetEn: "Alexithymia Check",
				direction: -1,
				textAr: "أجد صعوبة في وصف طبيعة مشاعري بالكلمات، وغالباً أقول فقط \"لا أعلم، أشعر بضيق\".",
				textEn: "I struggle to put specific words to my emotions beyond vague tension.",
				explanationAr: "بند عكسي يقيس الوضوح الانفعالي والتعبير اللغوي الدقيق.",
				explanationEn: "Reverse-keyed emotional granularity check."
			},
			{
				subscale: "ei_regulation",
				facetAr: "استثمار المزاج الإيجابي في التفكير",
				facetEn: "Affect Facilitation",
				direction: 1,
				textAr: "أوظف حالتي الوجدانية لتعزيز الإبداع أو اتخاذ قرارات هادئة متزنة.",
				textEn: "I channel emotional states constructively to support creativity and clear thinking.",
				explanationAr: "الفرع الثاني من نموذج ماير-سالوفي: توظيف المشاعر في تيسير التفكير.",
				explanationEn: "Mayer-Salovey Branch 2: using emotions to facilitate thought."
			},
			{
				subscale: "ei_social_skill",
				facetAr: "التقدير الصريح والمحفز",
				facetEn: "Appreciative Affirmation",
				direction: 1,
				textAr: "ألاحظ الجهود الصغيرة التي يبذلها المحيطون وأعبر لهم عن امتناني وتقديري بوضوح.",
				textEn: "I notice quiet everyday kindnesses from others and voice genuine gratitude.",
				explanationAr: "يقيس المهارة الاجتماعية الإيجابية في بناء الرصيد العاطفي.",
				explanationEn: "Positive relational intelligence maintaining emotional bank accounts."
			},
			{
				subscale: "ei_empathy",
				facetAr: "عدم الاكتراث بنبرة الألم",
				facetEn: "Empathy Deficit Check",
				direction: -1,
				textAr: "أحياناً أواصل طرح وجهة نظري بحماس دون أن أنتبه أن الطرف الآخر قد تألم من كلامي.",
				textEn: "I sometimes press my point energetically without noticing that the listener feels hurt.",
				explanationAr: "بند عكسي يقيس اليقظة الانفعالية أثناء النقاش.",
				explanationEn: "Reverse-keyed relational awareness check."
			},
			{
				subscale: "ei_regulation",
				facetAr: "تجنب الانتقام اللفظي",
				facetEn: "Reactive Restraint",
				direction: 1,
				textAr: "أتوقف لثوانٍ واعية قبل الرد حين يستفزني موقف ما كي لا أندم على كلمة قاسية.",
				textEn: "I pause consciously before replying when provoked to avoid saying anything hurtful.",
				explanationAr: "تحكم انفعالي تنفيذي يحفظ الأمان العاطفي.",
				explanationEn: "Executive pause preventing verbal escalation."
			},
			{
				subscale: "ei_social_skill",
				facetAr: "التشجيع الواقعي للآخرين",
				facetEn: "Motivational Coaching",
				direction: 1,
				textAr: "أحسن بث الأمل والثقة في نفس شخص محبط عبر الاستماع لقلقه وتذكيره بنقاط قوته.",
				textEn: "I lift discouraged loved ones by validating concerns and reminding them of their strengths.",
				explanationAr: "مهارة القيادة الوجدانية المساندة للأسرة والمحيط.",
				explanationEn: "Supportive relational influence skill."
			},
			{
				subscale: "ei_self_awareness",
				facetAr: "تتبع محفزات الغضب",
				facetEn: "Trigger Mapping",
				direction: 1,
				textAr: "أعرف مسبقاً الأنماط والمواقف الحساسة التي تستثير ضيقي وأستعد لها بوعي.",
				textEn: "I know my specific emotional triggers ahead of time and prepare calmly for them.",
				explanationAr: "مستوى متقدم من الوعي الذاتي الوقائي.",
				explanationEn: "Proactive self-awareness of emotional sensitivities."
			},
			{
				subscale: "ei_empathy",
				facetAr: "التعاطف المعرفي العابر للخلاف",
				facetEn: "Cognitive Perspective Taking",
				direction: 1,
				textAr: "أستطيع فهم لماذا شعر شريكي بالضيق من موقف معين حتى لو كان تفسيري للأمر مختلفاً.",
				textEn: "I can validate why my partner felt hurt even when I view the event differently.",
				explanationAr: "الذكاء العاطفي العالي يجمع بين ثبات الرأي وتفهم شعور الآخر.",
				explanationEn: "Core emotional intelligence separating perspective from emotional validity."
			},
			{
				subscale: "ei_regulation",
				facetAr: "التفريغ الانفعالي الجارح",
				facetEn: "Unfiltered Venting Check",
				direction: -1,
				textAr: "عندما أتضايق بشدة، أفرغ شحنتي الانفعالية في أقرب شخص أمامي رغم علمي أنه لم يخطئ.",
				textEn: "When strongly upset, I sometimes take it out on whoever is closest even if innocent.",
				explanationAr: "بند عكسي يقيس احتواء الانفعال وعدم ترحيله للمقربين.",
				explanationEn: "Reverse-keyed emotional containment marker."
			},
			{
				subscale: "ei_social_skill",
				facetAr: "قراءة ديناميكية المجلس",
				facetEn: "Group Climate Sensitivity",
				direction: 1,
				textAr: "ألتقط التوتر الخفي في الجلسات العائلية أو المهنية وأعرف كيف أخففه بلطف ولباقة.",
				textEn: "I sense unspoken tension in group settings and soften it gracefully.",
				explanationAr: "الوعي الاجتماعي التنظيمي في نموذج دانيال جولمان.",
				explanationEn: "Social awareness and diplomacy in Goleman EI."
			},
			{
				subscale: "ei_self_awareness",
				facetAr: "فهم تدرج الانفعالات",
				facetEn: "Emotion Progression Insight",
				direction: 1,
				textAr: "أفهم كيف يمكن لشعور صغير بالخذلان أن يتحول تدريجياً إلى فتور إذا لم يُعالج بلطف.",
				textEn: "I understand how minor unaddressed disappointment can gradually turn into distance.",
				explanationAr: "الفرع الثالث من MSCEIT: فهم تطور الانفعالات وتعاقبها.",
				explanationEn: "Mayer-Salovey Branch 3: understanding emotional progressions."
			},
			{
				subscale: "ei_empathy",
				facetAr: "الإنصات بالقلب والعقل معاً",
				facetEn: "Attentive Presence",
				direction: 1,
				textAr: "أترك هاتفي وانشغالاتي جانباً حين يفتح معي شخص قريب موضوعاً وجدانياً مهماً.",
				textEn: "I put aside distractions completely when someone close opens an emotional conversation.",
				explanationAr: "تطبيق الحضور الوجداني الدقيق للإنصات المتعاطف.",
				explanationEn: "Behavioral marker of undivided empathetic presence."
			},
			{
				subscale: "ei_regulation",
				facetAr: "تحويل الإحباط لدافع بناء",
				facetEn: "Affective Resilience",
				direction: 1,
				textAr: "أعيد توجيه طاقة الإحباط بعد أي تعثر نحو خطوات تصحيحية هادئة بدلاً من الاستسلام.",
				textEn: "After setbacks, I redirect frustration into measured corrective action.",
				explanationAr: "الدافعية الذاتية المنضبطة عاطفياً (Goleman Intrinsic Motivation).",
				explanationEn: "Constructive emotional resilience after setbacks."
			},
			{
				subscale: "ei_social_skill",
				facetAr: "لغة التقدير الدقيقة",
				facetEn: "Personalized Care",
				direction: 1,
				textAr: "أنتبه لما يسعد كل شخص مقرب على حدة ولا أعامل الجميع بنفس القالب الآلي.",
				textEn: "I tailor how I show care to what uniquely resonates with each loved one.",
				explanationAr: "يقيس الذكاء العاطفي المخصص للشريك والأسرة.",
				explanationEn: "Individualized relational attunement."
			},
			{
				subscale: "ei_self_awareness",
				facetAr: "تمييز الغضب كقناع للحزن",
				facetEn: "Secondary Emotion Insight",
				direction: 1,
				textAr: "أكتشف بوعي أن انزعاجي الظاهري يخفي أحياناً شعوراً بالخوف أو التعب أو الحاجة للتقدير.",
				textEn: "I recognize when outward irritation masks underlying fatigue, fear, or hurt.",
				explanationAr: "بصيرة وجدانية عميقة تفكك الانفعالات الثانوية.",
				explanationEn: "Deep emotional literacy recognizing primary vs secondary emotions."
			},
			{
				subscale: "ei_empathy",
				facetAr: "الرحمة في العتاب",
				facetEn: "Compassionate Confrontation",
				direction: 1,
				textAr: "أحرص في أصعب لحظات العتاب على ألا أفقد شريكي إحساسه بمكانته وحبي له.",
				textEn: "Even during firm complaints, I keep my partner feeling respected and valued.",
				explanationAr: "دمج الصدق الحازم مع التقدير العاطفي (Gottman Softened Startup).",
				explanationEn: "Combines honesty with loving regard."
			},
			{
				subscale: "ei_regulation",
				facetAr: "ضبط الانفعال أمام الأطفال والمحيط",
				facetEn: "Social Composure",
				direction: 1,
				textAr: "أتحمل مسؤولية نبرتي العاطفية في البيت لأنني أدرك تأثيرها العميق على طمأنينة الأسرة.",
				textEn: "I steward my emotional tone at home knowing how deeply it shapes family peace.",
				explanationAr: "القيادة العاطفية الواعية داخل النظام الأسري.",
				explanationEn: "Conscious emotional stewardship in family systems."
			},
			{
				subscale: "ei_social_skill",
				facetAr: "الاختيار القسري: المصالحة الوجدانية",
				facetEn: "Emotional Repair Priority",
				direction: 1,
				format: "forced_choice",
				textAr: "بعد توتر عابر انتهى على طاولة الحوار، ما الأهم لك لإتمام المصالحة؟",
				textEn: "After a brief tension has cooled down, what feels most essential to close the loop?",
				explanationAr: "اختيار قسري يفرق بين الإغلاق الوجداني العميق والتجاوز السطحي.",
				explanationEn: "Forced-choice gauging emotional repair thoroughness.",
				forcedOptions: [{
					id: "A",
					textAr: "الاطمئنان الصادق أن قلب الشريك صافٍ وسماع مشاعره بعد العاصفة",
					textEn: "Ensuring the partner’s heart feels genuinely heard and comforted afterward",
					targetSubscale: "ei_social_skill",
					scoreValue: 5,
					traitTagAr: "إغلاق وجداني شافٍ",
					traitTagEn: "Heart-Centered Repair"
				}, {
					id: "B",
					textAr: "طي الصفحة عملياً بصمت والمضي للعمل دون الحديث في المشاعر",
					textEn: "Moving back to routine tasks quietly without discussing feelings",
					targetSubscale: "ei_social_skill",
					scoreValue: 2,
					traitTagAr: "تجاوز صامت",
					traitTagEn: "Silent Reset"
				}]
			},
			{
				subscale: "ei_self_awareness",
				facetAr: "الثقة الانفعالية الداخلية",
				facetEn: "Intuitive Congruence",
				direction: 1,
				textAr: "تنسجم قراراتي الكبرى مع بوصلتي الوجدانية ولا أشعر بانفصال دائم بين عقلي وقلبي.",
				textEn: "My major choices align coherently between rational evaluation and inner values.",
				explanationAr: "التكامل بين الإدراك العقلي والوعي الوجداني.",
				explanationEn: "Alignment between analytical judgment and affective intuition."
			},
			{
				subscale: "ei_empathy",
				facetAr: "الفرح الصادق لنجاح الشريك",
				facetEn: "Sympathetic Joy",
				direction: 1,
				textAr: "يفرحني إنجاز شريكي وتفوقه كما لو كان إنجازاً شخصياً لي دون أي غيرة خفية.",
				textEn: "My partner’s success delights me as deeply as my own without hidden rivalry.",
				explanationAr: "التعاطف الإيجابي والفرح التشاركي (Freudenfreude).",
				explanationEn: "Empathic joy and non-competitive celebration."
			},
			{
				subscale: "ei_regulation",
				facetAr: "بطء العودة للهدوء",
				facetEn: "Slow Recovery Check",
				direction: -1,
				textAr: "إذا تعكر صفو صباحي بموقف مزعج، يفسد ذلك مزاج يومي بأكمله.",
				textEn: "One irritating incident in the morning tends to ruin my mood for the whole day.",
				explanationAr: "بند عكسي يقيس كفاءة إعادة التوازن الانفعالي.",
				explanationEn: "Reverse-keyed emotional recovery efficiency item."
			},
			{
				subscale: "ei_social_skill",
				facetAr: "الإصلاح بلمسة دعابة لطيفة",
				facetEn: "Relational Softening",
				direction: 1,
				textAr: "أستخدم اللطف أو الدعابة المتزنة لتخفيف التوتر غير الضروري دون استخفاف بالمشاعر.",
				textEn: "I use gentle warmth or light humor to ease unnecessary tension without trivializing feelings.",
				explanationAr: "أحد أهم أساليب غوتمان في كسر التصعيد السلبي.",
				explanationEn: "Aligns with Gottman positive affective repair."
			},
			{
				subscale: "ei_self_awareness",
				facetAr: "قبول المشاعر المتباينة",
				facetEn: "Emotional Complexity",
				direction: 1,
				textAr: "أستوعب أن أشعر بالمحبة لشخص ما وفي نفس الوقت بالضيق من موقف محدد صدر منه.",
				textEn: "I can hold deep love for someone while candidly addressing a specific frustrating action.",
				explanationAr: "نضج التكامل الوجداني (عدم الوقوع في التفكير الثنائي أبيض/أسود).",
				explanationEn: "Emotional maturity resisting all-or-nothing relational splitting."
			},
			{
				subscale: "ei_empathy",
				facetAr: "تفهم الفروق الثقافية والنفسية",
				facetEn: "Socio-Emotional Empathy",
				direction: 1,
				textAr: "أراعي خلفيات الناس التربوية والظروف التي يمرون بها عند تفسير ردود أفعالهم.",
				textEn: "I factor in people’s upbringing and current pressures before judging their reactions.",
				explanationAr: "التعاطف الاجتماعي السياقي المتقدم.",
				explanationEn: "Contextual socio-emotional empathy."
			},
			{
				subscale: "ei_regulation",
				facetAr: "تفادي القرارات تحت الغضب",
				facetEn: "Affective Delay Rule",
				direction: 1,
				textAr: "أؤجل حسم القرارات المصيرية أو إرسال الرسائل الحادة عندما أكون في ذروة الانفعال.",
				textEn: "I deliberately postpone consequential decisions or messages when intensely upset.",
				explanationAr: "قاعدة الوقاية الذاتية في الذكاء العاطفي التطبيقي.",
				explanationEn: "Applied EI rule preventing impulsive regret."
			},
			{
				subscale: "ei_social_skill",
				facetAr: "صناعة مناخ الأمان للحوار",
				facetEn: "Psychological Safety",
				direction: 1,
				textAr: "يشعر المقربون معي بالراحة للبوح بأسرارهم وأفكارهم دون خشية السخرية أو التشهير.",
				textEn: "People close to me feel safe sharing secrets without fear of judgment or ridicule.",
				explanationAr: "القدرة على تأسيس الأمان النفسي المشترك.",
				explanationEn: "Building interpersonal psychological safety."
			},
			{
				subscale: "ei_self_awareness",
				facetAr: "إشارات الجسد والانفعال",
				facetEn: "Somatic Emotion Reading",
				direction: 1,
				textAr: "ألاحظ إشارات جسمي المبكرة للتوتر (كتيبس الكتفين أو تسارع النفس) وأعالجها مبكراً.",
				textEn: "I notice early bodily signals of stress and step back before reaching exhaustion.",
				explanationAr: "الوعي الجسدي-الوجداني الوقائي لمنع الانفجار الانفعالي.",
				explanationEn: "Somatic emotional self-awareness supporting self-regulation."
			},
			{
				subscale: "ei_empathy",
				facetAr: "الصمت الداعم",
				facetEn: "Compassionate Silence",
				direction: 1,
				textAr: "أعرف أن الحضور الصامت الحنون أحياناً أبلغ مواساة من كثرة النصائح المتكررة.",
				textEn: "I recognize when quiet compassionate presence comforts more than abundant advice.",
				explanationAr: "نضج الدعم العاطفي في الأزمات الوجدانية.",
				explanationEn: "Mature soothing capacity during emotional distress."
			},
			{
				subscale: "ei_social_skill",
				facetAr: "التقاط الفجوة العاطفية",
				facetEn: "Relational Repair Initiative",
				direction: 1,
				textAr: "أبادر بكسر جليد الفتور بعد الخلاف ولا أترك المسافة تطول بدافع العناد.",
				textEn: "I take initiative to warm up distance after a disagreement instead of holding stubborn silence.",
				explanationAr: "مؤشر عالي لاستقرار العلاقات واستدامة المودة.",
				explanationEn: "High indicator of relational repair leadership."
			}
		],
		ref: CONSTRUCT_SCIENTIFIC_CATALOG.emotional_intelligence.referenceAr
	},
	{
		construct: "self_regulation",
		seeds: [
			{
				subscale: "sr_cognitive_reappraisal",
				facetAr: "إعادة التقييم المعرفي للضغوط",
				facetEn: "Cognitive Reappraisal",
				direction: 1,
				textAr: "أستطيع إعادة تأطير المواقف المزعجة بعقلانية لتقليل شحنتها السلبية ورؤية جانبها القابل للحل.",
				textEn: "I intentionally reframe upsetting situations rationally to reduce distress and find solutions.",
				explanationAr: "الاستراتيجية الأكثر صحة في نموذج جيمس غروس لتنظيم الانفعالات.",
				explanationEn: "Adaptive strategy under James Gross Process Model of Emotion Regulation."
			},
			{
				subscale: "sr_impulse_control",
				facetAr: "ضبط الاندفاع السلوكي والمالي",
				facetEn: "Impulse Inhibition",
				direction: 1,
				textAr: "أتحكم في رغباتي الآنية والإنفاقية أو الانفعالية عندما تتعارض مع أهدافي البعيدة.",
				textEn: "I restrain immediate impulses and spending urges when they clash with long-term goals.",
				explanationAr: "بُعد ضبط النفس والتنفيذ المؤجل للمكافأة (Baumeister Self-Regulation).",
				explanationEn: "Measures delay of gratification and impulse inhibition."
			},
			{
				subscale: "sr_stress_resilience",
				facetAr: "الثبات عند الأزمات المتلاحقة",
				facetEn: "Stress Recovery",
				direction: 1,
				textAr: "أتعامل مع فترات الضغط الشديد بخطة عملية وتنفس هادئ بدلاً من الانهيار أو الشلل.",
				textEn: "I respond to high-stress periods with structured priorities rather than shutting down.",
				explanationAr: "يقيس الكفاءة الذاتية والقدرة على إدارة الضغوط الحادة.",
				explanationEn: "Measures coping self-efficacy under sustained pressure."
			},
			{
				subscale: "sr_goal_persistence",
				facetAr: "الالتزام بالعادات الصحية والهدف",
				facetEn: "Behavioral Consistency",
				direction: 1,
				textAr: "ألتزم بالجدول والروتين الذي أضعه لتطوير نفسي حتى في الأيام التي يقل فيها المزاج.",
				textEn: "I keep following personal development routines even on low-motivation days.",
				explanationAr: "التنظيم الذاتي السلوكي المستقل عن تقلب الدافع اللحظي.",
				explanationEn: "Behavioral discipline independent of fluctuating mood."
			},
			{
				subscale: "sr_cognitive_reappraisal",
				facetAr: "تهدئة الأفكار الكارثية",
				facetEn: "De-Catastrophizing",
				direction: 1,
				textAr: "عند تعثر أمر مهم، أمنع ذهني من تضخيم السيناريوهات الكارثية غير الواقعية.",
				textEn: "When a key plan falters, I check catastrophic thoughts against realistic evidence.",
				explanationAr: "مهارة إعادة التنظيم المعرفي ومنع القلق المتصاعد.",
				explanationEn: "Cognitive de-catastrophizing skill."
			},
			{
				subscale: "sr_impulse_control",
				facetAr: "التصرف الاندفاعي تحت التوتر",
				facetEn: "Urgency Check",
				direction: -1,
				textAr: "أتخذ أحياناً قرارات أو أقول كلمات غير محسوبة فقط لأنني أريد التخلص السريع من التوتر.",
				textEn: "I sometimes act or speak impulsively simply to escape acute discomfort quickly.",
				explanationAr: "بند عكسي يقيس الاستعجال السلبي (Negative Urgency).",
				explanationEn: "Reverse-keyed negative urgency impulse indicator."
			},
			{
				subscale: "sr_stress_resilience",
				facetAr: "الاختيار القسري: التهدئة المعرفية vs الكبت",
				facetEn: "Reappraisal vs Suppression",
				direction: 1,
				format: "forced_choice",
				textAr: "عندما تشعر بضغط عصبي في العمل وتعود للمنزل، كيف تنظّم حالتك؟",
				textEn: "When carrying heavy work stress back home, how do you regulate your state?",
				explanationAr: "يميز بين إعادة التقييم الصحي وتراكم الكبت الانفعالي.",
				explanationEn: "Contrasts adaptive reappraisal/communication vs emotional suppression.",
				forcedOptions: [{
					id: "A",
					textAr: "آخذ استراحة قصيرة وأعيد ترتيب أفكاري لأحمي بيتي من عدوى التوتر",
					textEn: "Pause briefly to decompress and reframe so home stays peaceful",
					targetSubscale: "sr_cognitive_reappraisal",
					scoreValue: 5,
					traitTagAr: "تنظيم ذاتي وقائي",
					traitTagEn: "Proactive Reappraisal"
				}, {
					id: "B",
					textAr: "أكبت ضيقي بصمت تام وأدخل في صدام بارد مع أول من يحادثني",
					textEn: "Suppress frustration rigidly and snap coldly if pressed",
					targetSubscale: "sr_impulse_control",
					scoreValue: 1,
					traitTagAr: "كبت وتراكم ضغطي",
					traitTagEn: "Reactive Suppression"
				}]
			},
			{
				subscale: "sr_goal_persistence",
				facetAr: "تصحيح المسار التكيفي",
				facetEn: "Feedback Adaptation",
				direction: 1,
				textAr: "أراجع نتائج خطواتي بانتظام وأعدل ما لا يعمل بمرونة دون التخلي عن الهدف الأصلي.",
				textEn: "I review feedback regularly and adjust ineffective tactics without abandoning the goal.",
				explanationAr: "حلقة التغذية الراجعة في التنظيم الذاتي (Carver & Scheier).",
				explanationEn: "Carver & Scheier cybernetic feedback loop in self-regulation."
			},
			{
				subscale: "sr_stress_resilience",
				facetAr: "الشلل تحت تعدد الأعباء",
				facetEn: "Stress Freeze Check",
				direction: -1,
				textAr: "تتعطل إنتاجيتي تماماً إذا شعرت بضيق الوقت أو تزامن أكثر من التزام مهم.",
				textEn: "My productivity stalls completely whenever deadlines overlap.",
				explanationAr: "بند عكسي يقيس الهشاشة التنفيذية تحت ضغط الوقت.",
				explanationEn: "Reverse-keyed item assessing executive freeze under stress."
			},
			{
				subscale: "sr_cognitive_reappraisal",
				facetAr: "فصل المشكلة عن الهوية",
				facetEn: "Self-Compassion Reframe",
				direction: 1,
				textAr: "عندما أخطئ في قرار، أتعلم الدرس دون جلد قاسٍ للذات يحبط همتي.",
				textEn: "When making an error, I extract the lesson without harsh self-attack.",
				explanationAr: "التعاطف المتزن مع الذات الداعم لاستمرارية التنظيم الذاتي.",
				explanationEn: "Adaptive self-compassion preserving motivational stamina."
			},
			{
				subscale: "sr_impulse_control",
				facetAr: "صبر القرار الشرائي",
				facetEn: "Deliberate Consumption",
				direction: 1,
				textAr: "أمهل نفسي وقتاً للتفكير قبل الشراء أو الالتزامات الكبيرة لتقييم حاجتها الحقيقية.",
				textEn: "I apply a cooling-off pause before major purchases or commitments.",
				explanationAr: "الضبط السلوكي التنفيذي للرغبات المادية.",
				explanationEn: "Impulse regulation applied to financial habits."
			},
			{
				subscale: "sr_goal_persistence",
				facetAr: "ترك المهام نصف المنجزة",
				facetEn: "Completion Gap",
				direction: -1,
				textAr: "أبدأ مشاريع وهوايات بحماس عالٍ ثم أتركها في منتصف الطريق عند ظهور أول صعوبة.",
				textEn: "I start projects enthusiastically but abandon them once routine difficulties emerge.",
				explanationAr: "بند عكسي لقياس استمرارية التنفيذ عبر الزمن.",
				explanationEn: "Reverse-scored perseverance check."
			},
			{
				subscale: "sr_stress_resilience",
				facetAr: "تنظيم الإيقاع البدني والنوم",
				facetEn: "Physiological Regulation",
				direction: 1,
				textAr: "أراعي حاجتي للنوم والراحة والهدوء كجزء أساسي من كفاءتي النفسية والعلائقية.",
				textEn: "I protect sleep and physical rest as a pillar of emotional and relational steadiness.",
				explanationAr: "العناية بالركيزة الفسيولوجية للتنظيم الانفعالي.",
				explanationEn: "Respecting physiological foundations of affective regulation."
			},
			{
				subscale: "sr_cognitive_reappraisal",
				facetAr: "الرؤية طويلة المدى",
				facetEn: "Temporal Distancing",
				direction: 1,
				textAr: "أسأل نفسي أثناء اللحظات المتوترة: هل سيستحق هذا الأمر إفساد علاقتنا بعد عام؟",
				textEn: "During heated moments, I ask whether this issue will matter a year from now.",
				explanationAr: "تقنية التباعد الزمني (Temporal Distancing) لتخفيف التفاعل الانفعالي.",
				explanationEn: "Temporal distancing strategy reducing acute reactivity."
			},
			{
				subscale: "sr_impulse_control",
				facetAr: "تجنب التسرع في الوعود",
				facetEn: "Commitment Pacing",
				direction: 1,
				textAr: "أدرس قدرتي الفعلية قبل أن أعد الآخرين بمهام إضافية قد ترهقني أو أخلّ بها.",
				textEn: "I assess realistic bandwidth before promising others extra commitments.",
				explanationAr: "ضبط الاندفاع العاطفي لإرضاء الآخرين على حساب الموثوقية.",
				explanationEn: "Boundary awareness in promising and time management."
			},
			{
				subscale: "sr_stress_resilience",
				facetAr: "الفصل بين الضغوط المهنية والأسرة",
				facetEn: "Boundary Shielding",
				direction: 1,
				textAr: "لا أحمّل أفراد أسرتي وشريكي تبعات الضغط المهني أو الإحباط الخارجي.",
				textEn: "I shield my partner and household from carrying my external work frustrations.",
				explanationAr: "منع تسرب التوتر (Stress Spillover Control).",
				explanationEn: "Prevents negative stress spillover into family bonds."
			},
			{
				subscale: "sr_goal_persistence",
				facetAr: "تقسيم الأهداف الكبرى",
				facetEn: "Sub-Goal Structuring",
				direction: 1,
				textAr: "أقسم المشاريع المعقدة إلى خطوات صغيرة واضحة تسهل إتمامها دون ارتباك.",
				textEn: "I break overwhelming projects into manageable sequential milestones.",
				explanationAr: "استراتيجية الكفاءة التنظيمية لمكافحة التسويف.",
				explanationEn: "Actionable sub-goal structuring supporting perseverance."
			},
			{
				subscale: "sr_cognitive_reappraisal",
				facetAr: "إسكات النقد الجلدي المتواصل",
				facetEn: "Rumination Release",
				direction: -1,
				textAr: "أظل ألوم نفسي وأعيد استرجاع الأخطاء البسيطة لأيام متتالية.",
				textEn: "I replay minor personal blunders critically in my mind for days.",
				explanationAr: "بند عكسي يقيس الاجترار النقدي.",
				explanationEn: "Reverse-scored self-rumination check."
			},
			{
				subscale: "sr_impulse_control",
				facetAr: "الامتناع عن الرد المتهور رقمياً",
				facetEn: "Digital Pause",
				direction: 1,
				textAr: "أمتنع عن إرسال رسائل نصية حادة في لحظة الغضب وأنتظر حتى تهدأ نبرتي.",
				textEn: "I avoid sending sharp text messages in anger until my tone cools down.",
				explanationAr: "التنظيم الذاتي التطبيقي في التواصل الرقمي المعاصر.",
				explanationEn: "Digital impulse restraint safeguarding relationships."
			},
			{
				subscale: "sr_stress_resilience",
				facetAr: "طلب المساعدة دون حرج",
				facetEn: "Adaptive Help-Seeking",
				direction: 1,
				textAr: "أستشير أهل الخبرة أو المقربين عندما تفوق الأزمة طاقتي الفردية دون مكابرة.",
				textEn: "I seek wise counsel or support when pressures exceed solo bandwidth without pride.",
				explanationAr: "إدارة الضغوط التكيفية الذكية.",
				explanationEn: "Adaptive social coping under acute stress."
			},
			{
				subscale: "sr_goal_persistence",
				facetAr: "التركيز رغم المشتتات",
				facetEn: "Attentional Control",
				direction: 1,
				textAr: "أضبط استخدامي للهاتف والمشتتات عندما تتطلب المهمة أو الجلسة الأسرية حضوراً كاملاً.",
				textEn: "I silence phone distractions when work or family time calls for full focus.",
				explanationAr: "تنظيم الانتباه التنفيذي والحضور الواعي.",
				explanationEn: "Executive attention control protecting presence."
			},
			{
				subscale: "sr_cognitive_reappraisal",
				facetAr: "البحث عن الدروس في التحديات",
				facetEn: "Growth Mindset",
				direction: 1,
				textAr: "أنظر للأزمات التي مررت بها باعتبارها تجارب صقلت حكمتي وأدواتي الشخصية.",
				textEn: "I view past obstacles as experiences that sharpened my wisdom and tools.",
				explanationAr: "التقييم الإدراكي النمائي (Growth-Oriented Reappraisal).",
				explanationEn: "Growth-minded cognitive reappraisal."
			},
			{
				subscale: "sr_impulse_control",
				facetAr: "عدم الانسياق مع المقارنة الاجتماعية",
				facetEn: "Envy Regulation",
				direction: 1,
				textAr: "لا تسمح قراراتي المالية والشخصية لموضات المحيط أو التفاخر أن تدفعني لمقارنات مرهقة.",
				textEn: "Social comparison and fleeting trends do not push me into impulsive lifestyle spending.",
				explanationAr: "استقرار القيم وتنظيم الرغبات في البيئة الاستهلاكية.",
				explanationEn: "Intrinsic self-regulation over social status contagion."
			},
			{
				subscale: "sr_stress_resilience",
				facetAr: "تنظيم الجسد عبر التنفس والحركة",
				facetEn: "Down-Regulation Habits",
				direction: 1,
				textAr: "لدي عادات صحية ثابتة (كالمشي أو التأمل أو التنفس) لتفريغ الضغط قبل تراكمه.",
				textEn: "I maintain consistent physical or contemplative habits to release tension early.",
				explanationAr: "أدوات تنظيم التوتر الفسيولوجي والنفسي.",
				explanationEn: "Proactive physiological down-regulation habits."
			},
			{
				subscale: "sr_goal_persistence",
				facetAr: "الاختيار القسري: الاستمرارية vs الانقطاع",
				facetEn: "Persistence Under Friction",
				direction: 1,
				format: "forced_choice",
				textAr: "عندما تمر علاقة أو مشروع طويل الأمد بمرحلة روتين وملل مؤقت:",
				textEn: "When a meaningful long-term commitment enters a dry or routine stretch:",
				explanationAr: "اختيار إجباري يقيس الصبر التنظيمي في الاستثمار طويل الأمد.",
				explanationEn: "Forced-choice assessing persistence during low-reward maintenance phases.",
				forcedOptions: [{
					id: "A",
					textAr: "أجدد الجهد بوعي وأثبت على العهد لأن البناء الحقيقي يحتاج لصبر وتجديد",
					textEn: "Renew effort purposefully because lasting builds require steady stewardship",
					targetSubscale: "sr_goal_persistence",
					scoreValue: 5,
					traitTagAr: "ثبات واستدامة بناءة",
					traitTagEn: "Steadfast Persistence"
				}, {
					id: "B",
					textAr: "أفقد الشغف سريعاً وأبحث عن بداية جديدة أو تشتيت مثير يغير الأجواء",
					textEn: "Lose interest quickly and chase novel distractions for excitement",
					targetSubscale: "sr_goal_persistence",
					scoreValue: 2,
					traitTagAr: "بحث عن الإثارة الآنية",
					traitTagEn: "Novelty Chasing"
				}]
			},
			{
				subscale: "sr_cognitive_reappraisal",
				facetAr: "عدم الانغماس في لوم الغير",
				facetEn: "Locus of Control",
				direction: 1,
				textAr: "أركز طاقتي على ما أستطيع تغييره والتحكم فيه بدلاً من الشكوى المستمرة من الظروف.",
				textEn: "I invest energy in what lies within my control rather than chronic complaining.",
				explanationAr: "مركز التحكم الداخلي (Internal Locus of Control) في التنظيم الذاتي.",
				explanationEn: "Internal locus of control under pressure."
			},
			{
				subscale: "sr_impulse_control",
				facetAr: "ضبط الإرهاق قبل الكلام",
				facetEn: "Fatigue Awareness",
				direction: 1,
				textAr: "أعترف عندما أكون متعباً جسدياً فأؤجل النقاشات الحساسة ليوم آخر.",
				textEn: "When physically depleted, I recognize my limit and reschedule sensitive talks.",
				explanationAr: "وعي تنظيمي يحفظ جودة التواصل من تدهور الإرهاق.",
				explanationEn: "Self-regulatory scheduling protecting sensitive communication."
			},
			{
				subscale: "sr_stress_resilience",
				facetAr: "المرونة عند تغير المفاجآت",
				facetEn: "Plan B Agility",
				direction: 1,
				textAr: "إذا تعطلت خطتي الأساسية، أنتقل بسلاسة إلى بديل عملي دون إفساد مزاج من معي.",
				textEn: "If Plan A breaks down, I pivot calmly to Plan B without spoiling the mood around me.",
				explanationAr: "المرونة التنفيذية والعاطفية المشتركة.",
				explanationEn: "Executive and emotional agility during disruption."
			},
			{
				subscale: "sr_goal_persistence",
				facetAr: "تقييم العادات الدورية",
				facetEn: "Self-Monitoring",
				direction: 1,
				textAr: "أخصص وقتاً لمراجعة أولوياتي الحياتية ومدى توافق يومي الفعلي مع قيمي.",
				textEn: "I periodically audit whether my daily habits match my highest personal values.",
				explanationAr: "الرقابة الذاتية الواعية (Self-Monitoring) في نموذج بوميستر.",
				explanationEn: "Value-aligned self-monitoring."
			},
			{
				subscale: "sr_cognitive_reappraisal",
				facetAr: "التحكم بتوقعات الكمال القلقة",
				facetEn: "Realistic Standards",
				direction: 1,
				textAr: "أفرق بين السعي للإتقان وبين الكمال المستحيل الذي يولد توتراً مزمناً لي ولأسرتي.",
				textEn: "I distinguish healthy excellence from rigid perfectionism that breeds tension.",
				explanationAr: "التنظيم المعرفي للمعايير الشخصية داخل الأسرة.",
				explanationEn: "Healthy standard-setting vs maladaptive perfectionism."
			},
			{
				subscale: "sr_impulse_control",
				facetAr: "تأخر الاستجابة الدفاعية",
				facetEn: "Ego Regulation",
				direction: -1,
				textAr: "أتسرع أحياناً في الرد بحدّة لإثبات كرامتي ثم أكتشف لاحقاً أنني بالغت في رد الفعل.",
				textEn: "I occasionally snap back sharply to defend pride, only to realize later I overreacted.",
				explanationAr: "بند عكسي يقيس تنظيم الأنا والاندفاع الدفاعي.",
				explanationEn: "Reverse-keyed defensive reactivity check."
			},
			{
				subscale: "sr_stress_resilience",
				facetAr: "الاحتفاظ بالأمل المنضبط",
				facetEn: "Dispositional Hope",
				direction: 1,
				textAr: "حتى في الظروف الصعبة، أظل أرى مسارات واقعية ممكنة للخروج بأمان واستقرار.",
				textEn: "Even in tough chapters, I keep spotting practical pathways toward stability.",
				explanationAr: "الأمل العملي (Snyder Hope Theory) في مواجهة الضغوط.",
				explanationEn: "Pathways and agency thinking under pressure."
			},
			{
				subscale: "sr_goal_persistence",
				facetAr: "التوازن بين العمل والراحة",
				facetEn: "Sustainable Pacing",
				direction: 1,
				textAr: "أنظم جهدي عبر الأسبوع بحيث لا أحرق طاقتي فجأة ثم أتوقف أياماً طويلة.",
				textEn: "I pace my weekly effort sustainably rather than burning out in sudden sprints.",
				explanationAr: "استدامة الطاقة التنفيذية طويلة الأمد.",
				explanationEn: "Sustainable self-regulation pacing."
			},
			{
				subscale: "sr_cognitive_reappraisal",
				facetAr: "النظر من زاوية المحب",
				facetEn: "Relational Reframing",
				direction: 1,
				textAr: "أعيد قراءة التقصير البسيط من قريبي في ضوء ضغوطه وظروفه قبل أن أتخذه إهانة شخصية.",
				textEn: "I interpret minor oversights from loved ones through their workload before taking offense.",
				explanationAr: "إعادة التقييم المعرفي العلائقي لتعزيز المودة.",
				explanationEn: "Relational cognitive reappraisal preventing resentment."
			},
			{
				subscale: "sr_impulse_control",
				facetAr: "ضبط الفضول والمقارنة في التواصل",
				facetEn: "Discretion Control",
				direction: 1,
				textAr: "أحفظ أسرار بيتي وعلاقاتي القريبة ولا أبوح بتفاصيلها لحظة غضب أو تسرع.",
				textEn: "I protect private family matters with complete discretion even when frustrated.",
				explanationAr: "الأمانة العلائقية والضبط الانفعالي في الخصوصية.",
				explanationEn: "Impulse control safeguarding relational confidentiality."
			},
			{
				subscale: "sr_stress_resilience",
				facetAr: "العودة الهادئة بعد التعب",
				facetEn: "Restorative Recovery",
				direction: 1,
				textAr: "أعرف ما يجدد طاقتي الروحية والنفسية الحقيقية وأمارسه بانتظام.",
				textEn: "I know what genuinely restores my emotional balance and practice it regularly.",
				explanationAr: "الاستباقية في استعادة التوازن النفسي.",
				explanationEn: "Intentional emotional restoration."
			}
		],
		ref: CONSTRUCT_SCIENTIFIC_CATALOG.self_regulation.referenceAr
	},
	{
		construct: "interpersonal",
		seeds: [
			{
				subscale: "int_trust_commitment",
				facetAr: "الميثاق والولاء في السراء والضراء",
				facetEn: "Dyadic Commitment",
				direction: 1,
				textAr: "أعتبر الشراكة الزوجية ميثاقاً راسخاً أصون فيه شريكي وحضورنا المعنوي في الرخاء والشدة.",
				textEn: "I view committed partnership as a steadfast covenant honoring support through thick and thin.",
				explanationAr: "ركيزة الالتزام والثقة في بيت العلاقة المتينة لجوتمان وستيرنبرغ.",
				explanationEn: "Core Commitment & Trust pillar in Gottman & Sternberg models."
			},
			{
				subscale: "int_boundaries",
				facetAr: "تمايز الحدود مع العائلة الممتدة",
				facetEn: "Family Boundaries",
				direction: 1,
				textAr: "أوازن بين بر أهلي واحترامهم وبين صيانة استقلال وخصوصية القرار داخل بيتي الزوجي.",
				textEn: "I honor my extended family while fiercely protecting the autonomy and privacy of my home.",
				explanationAr: "يقيس نظرية الأنساق الأسرية لبوين (Bowen Differentiation of Self).",
				explanationEn: "Applies Bowen Family Systems boundary differentiation."
			},
			{
				subscale: "int_parenting_family",
				facetAr: "التوافق والوعي التربوي الأسري",
				facetEn: "Parenting & Family Vision",
				direction: 1,
				textAr: "أحرص على بناء بيت يسوده الاحترام والتفاهم ليكون بيئة تربوية آمنة ودافئة للأبناء.",
				textEn: "I prioritize a home grounded in mutual respect as a warm, secure haven for raising family.",
				explanationAr: "التوجه التربوي والأسرية الإيجابية المستدامة.",
				explanationEn: "Parenting & nurturing domestic climate orientation."
			},
			{
				subscale: "int_repair_synergy",
				facetAr: "صيانة الصداقة الزوجية والألفة",
				facetEn: "Friendship & Fondness",
				direction: 1,
				textAr: "أهتم بالحفاظ على لغة المودة، الصداقة اليومية، والتفاصيل الصغيرة التي تحيي العلاقة.",
				textEn: "I nurture everyday fondness, friendship, and small caring gestures in close partnership.",
				explanationAr: "أهم مؤشرات طول عمر الزواج في أبحاث جون غوتمان.",
				explanationEn: "Gottman’s Fondness & Admiration system predicting relationship longevity."
			},
			{
				subscale: "int_trust_commitment",
				facetAr: "الموثوقية الأخلاقية والخصوصية",
				facetEn: "Relational Trust",
				direction: 1,
				textAr: "يمثل صون غيبة الشريك وحماية سمعته أمام الآخرين خطاً أحمر لا أتجاوزه أبداً.",
				textEn: "Defending my partner’s dignity and privacy in their absence is an absolute principle for me.",
				explanationAr: "ركيزة الثقة والولاء العلائقي.",
				explanationEn: "Core loyalty & trust foundation."
			},
			{
				subscale: "int_boundaries",
				facetAr: "التدخل الخارجي غير المنضبط",
				facetEn: "Porous Boundary Check",
				direction: -1,
				textAr: "أشارك تفاصيل خلافاتي المنزلية الحساسة مع أصدقاء أو أقارب فور حدوثها طلباً للانتصار.",
				textEn: "I immediately share private domestic disputes with outsiders seeking validation.",
				explanationAr: "بند عكسي يرصد ضعف الحدود الأسرية (Triangulation Risk في نظرية بوين).",
				explanationEn: "Reverse-keyed check for family triangulation risk (Bowen)."
			},
			{
				subscale: "int_parenting_family",
				facetAr: "الاختيار القسري: المسؤوليات والتربية",
				facetEn: "Shared Parenting Choice",
				direction: 1,
				format: "forced_choice",
				textAr: "في تربية الأبناء وإدارة البيت، ما المنهج الذي تشعر أنه أصح وأكثر استقراراً؟",
				textEn: "In parenting and household stewardship, which model feels healthiest and most sustainable?",
				explanationAr: "اختيار إجباري يقيس التوجه نحو التربية التشاركية الواعية مقابل الفردية الصارمة.",
				explanationEn: "Forced-choice gauging collaborative authoritative parenting vs rigid unilateralism.",
				forcedOptions: [{
					id: "A",
					textAr: "تربية تشاركية تجمع بين الحنان، الحوار، والقدوة المتفقة بين الأبوين",
					textEn: "Collaborative parenting blending warmth, dialogue, and united guidance",
					targetSubscale: "int_parenting_family",
					scoreValue: 5,
					traitTagAr: "توجه تربوي تشاركي ناضج",
					traitTagEn: "Authoritative Co-Parenting"
				}, {
					id: "B",
					textAr: "الاعتماد على الحزم الصارم وتفويض الشؤون اليومية لطرف واحد غالباً",
					textEn: "Strict unilateral discipline with routine matters left to one partner",
					targetSubscale: "int_parenting_family",
					scoreValue: 2,
					traitTagAr: "حزم منفرد تقليدي",
					traitTagEn: "Unilateral Authority"
				}]
			},
			{
				subscale: "int_repair_synergy",
				facetAr: "الاستجابة الفعالة البناءة",
				facetEn: "Turning Toward Bids",
				direction: 1,
				textAr: "أنتبه لمحاولات القرب الصغيرة (مثل تعليق أو نظرة أو قصة) وأتفاعل معها بدفء.",
				textEn: "I notice everyday bids for connection and turn toward them warmly instead of ignoring them.",
				explanationAr: "مؤشر غوتمان الحاسم (\"التحول نحو مبادرات الاتصال\" Turning Toward).",
				explanationEn: "Gottman’s Turning Toward emotional bids benchmark."
			},
			{
				subscale: "int_trust_commitment",
				facetAr: "تجنب المقارنة القاسية",
				facetEn: "Respectful Loyalty",
				direction: 1,
				textAr: "أمتنع عن مقارنة شريكي أو بيتي بأشخاص آخرين على وسائل التواصل أو في المحيط.",
				textEn: "I avoid comparing my partner or home unfavorably to idealized images of others.",
				explanationAr: "حماية الرضا العلائقي من المقارنات الوهمية.",
				explanationEn: "Protecting dyadic gratitude from upward social comparison."
			},
			{
				subscale: "int_boundaries",
				facetAr: "الدفاع الهادئ عن الشريك",
				facetEn: "Coupled Solidarity",
				direction: 1,
				textAr: "أقف في صف كرامة شريكي بلباقة إذا تعرض لموقف محرج في مجلس عائلي أو اجتماعي.",
				textEn: "I tactfully stand up for my partner’s dignity if they face awkwardness in family gatherings.",
				explanationAr: "التحالف الزوجي الصحي (Spousal Alliance) في نموذج الأنساق الأسرية.",
				explanationEn: "Spousal alliance prioritization in structural family therapy."
			},
			{
				subscale: "int_parenting_family",
				facetAr: "الإجماع على الأساسيات التربوية",
				facetEn: "Co-Parent Alignment",
				direction: 1,
				textAr: "أرى ضرورة عدم إظهار التناقض الحاد في التوجيه التربوي أمام الأبناء وحل الاختلاف على انفراد.",
				textEn: "Parents should resolve discipline disagreements privately rather than undermining each other openly.",
				explanationAr: "معيار رئيسي للانسجام التربوي الأسري.",
				explanationEn: "Key metric of unified co-parenting posture."
			},
			{
				subscale: "int_repair_synergy",
				facetAr: "إعادة صياغة الروتين اليومي",
				facetEn: "Rituals of Connection",
				direction: 1,
				textAr: "أحرص على بناء طقوس يومية ثابتة للتقارب (كالقهوة الصباحية أو الحديث الهادئ مساءً).",
				textEn: "I value preserving daily rituals of connection such as quiet evening catch-ups.",
				explanationAr: "بناء المعنى المشترك وطقوس الترابط في البيت الزوجي.",
				explanationEn: "Rituals of connection in Gottman Sound Relationship House."
			},
			{
				subscale: "int_trust_commitment",
				facetAr: "الشعور بتهديد العلاقة سريعاً",
				facetEn: "Conditional Commitment Check",
				direction: -1,
				textAr: "تخطر بفكرة الانفصال أو الانسحاب سريعاً في ذهني عند مرور العلاقة بأي تعثر حاد.",
				textEn: "Thoughts of walking away surface quickly in my mind during tough arguments.",
				explanationAr: "بند عكسي يقيس متانة الالتزام مقابل هشاشة الميثاق.",
				explanationEn: "Reverse-scored commitment stability indicator."
			},
			{
				subscale: "int_boundaries",
				facetAr: "الشفافية في العادات والضيافة",
				facetEn: "Hospitality Coordination",
				direction: 1,
				textAr: "ننسق الزيارات والمناسبات الاجتماعية باتفاق مسبق يراعي طاقة ووقت الطرفين.",
				textEn: "We coordinate social hosting and family visits by mutual agreement respecting energy.",
				explanationAr: "توازن الحدود والضيافة بين الزوجين.",
				explanationEn: "Practical household boundary coordination."
			},
			{
				subscale: "int_parenting_family",
				facetAr: "الرعاية المتواصلة والقدوة",
				facetEn: "Modeling Respect",
				direction: 1,
				textAr: "أؤمن أن احترام الزوجين لبعضهما هو أعظم مدرسة أخلاقية يتربى عليها الأبناء.",
				textEn: "Mutual respect between partners is the strongest moral classroom for children.",
				explanationAr: "الوعي بدور العلاقة الزوجية كقدوة تربوية عليا.",
				explanationEn: "Understanding dyadic modeling in child development."
			},
			{
				subscale: "int_repair_synergy",
				facetAr: "التقدير المتوازن للمهام المنزلية",
				facetEn: "Fairness Recognition",
				direction: 1,
				textAr: "ألاحظ وأشكر الجهد غير المرئي الذي يبذله الطرف الآخر في رعاية البيت والأسرة.",
				textEn: "I notice and thank invisible everyday efforts my partner invests in home life.",
				explanationAr: "يعزز العدالة الإدراكية ويمنع التذمر الصامت.",
				explanationEn: "Fosters perceived fairness and relational gratitude."
			},
			{
				subscale: "int_trust_commitment",
				facetAr: "تقبل النضج عبر المراحل",
				facetEn: "Long-Horizon Loyalty",
				direction: 1,
				textAr: "أستعد لتغيرات العمر والمسؤوليات بروح تشاركية تزيد الألفة بدلاً من النفور.",
				textEn: "I embrace changing life stages with a partnership mindset that deepens closeness.",
				explanationAr: "النظرة النمائية للاستثمار العلائقي طويل الأمد.",
				explanationEn: "Longitudinal relational resilience perspective."
			},
			{
				subscale: "int_boundaries",
				facetAr: "الاستقلالية المالية المسؤولة",
				facetEn: "Financial Coordination",
				direction: 1,
				textAr: "نناقش القرارات المالية المؤثرة على مستقبل الأسرة بشفافية كاملة واتفاق مشترك.",
				textEn: "Major financial decisions affecting family security are discussed transparently together.",
				explanationAr: "ركيزة الأمان الاقتصادي والتفاهم التنظيمي الأسري.",
				explanationEn: "Shared financial clarity protecting family trust."
			},
			{
				subscale: "int_parenting_family",
				facetAr: "المشاركة الأبوية الفعلية",
				facetEn: "Active Co-Caregiving",
				direction: 1,
				textAr: "أعتبر متابعة تفاصيل تربية الأبناء ورعايتهم مسؤولية أصيلة لكلا الأبوين بلا استثناء.",
				textEn: "Engaged daily parenting and emotional nurturing is a shared core duty of both parents.",
				explanationAr: "مؤشر عالي للتكامل الأبوي/الأمومي المتوازن.",
				explanationEn: "High indicator of balanced co-caregiving readiness."
			},
			{
				subscale: "int_repair_synergy",
				facetAr: "خرائط الحب ومعرفة العالَم الداخلي",
				facetEn: "Love Maps",
				direction: 1,
				textAr: "أهتم بتحديث معرفتي بأحلام شريكي ومخاوفه وما يشغل باله في كل مرحلة جديدة.",
				textEn: "I stay curious about updating my understanding of my partner’s evolving dreams and stresses.",
				explanationAr: "مفهوم \"خرائط الحب\" (Love Maps) الأساسي عند جون غوتمان.",
				explanationEn: "Core Gottman Love Maps principle."
			},
			{
				subscale: "int_trust_commitment",
				facetAr: "قبول تأثير الشريك (Accepting Influence)",
				facetEn: "Shared Power",
				direction: 1,
				textAr: "أقبل تأثير وجهة نظر شريكي في قراراتي ولا أرى مشاركته للرأي انتقاصاً من مكانتي.",
				textEn: "I welcome my partner’s influence in decisions without viewing shared power as weakness.",
				explanationAr: "مؤشر غوتمان الشهير للنجاح الزواجي: تقبل التأثير المتبادل.",
				explanationEn: "Gottman’s empirical marker: Accepting Influence in marriage."
			},
			{
				subscale: "int_boundaries",
				facetAr: "التعامل الدبلوماسي مع الحساسيات",
				facetEn: "Extended Kin Diplomacy",
				direction: 1,
				textAr: "أدير أي سوء فهم طارئ مع المحيط العائلي بحكمة هادئة تمنع تصعيد العداوات.",
				textEn: "I navigate extended family sensitivities diplomatically without escalating friction.",
				explanationAr: "الحكمة الاجتماعية في صون الروابط العائلية الممتدة.",
				explanationEn: "Diplomatic mediation across extended family systems."
			},
			{
				subscale: "int_parenting_family",
				facetAr: "غرس القيم الوجدانية والأخلاقية",
				facetEn: "Character Nurturing",
				direction: 1,
				textAr: "أولي أهمية لتعليم الجيل القادم الصدق، الترحم، وضبط النفس أكثر من التنافس الشكلي.",
				textEn: "I prioritize cultivating integrity, empathy, and self-mastery over superficial status.",
				explanationAr: "توافق الرؤية القيمية في التنشئة الأسرية.",
				explanationEn: "Character-centered parenting orientation."
			},
			{
				subscale: "int_repair_synergy",
				facetAr: "تفادي الغرق الانفعالي (Flooding)",
				facetEn: "Physiological Soothing",
				direction: 1,
				textAr: "أتفق مع شريكي على استراحة قصيرة ومحددة المدة لتهدئة الأعصاب إذا احتدّ نقاش، ثم نعود بإصغاء.",
				textEn: "I agree on brief structured cool-downs when voices rise, always returning with care.",
				explanationAr: "علاج \"الفيضان الانفعالي\" (Emotional Flooding Break) في منهج غوتمان.",
				explanationEn: "Gottman physiological self-soothing timeout protocol."
			},
			{
				subscale: "int_boundaries",
				facetAr: "الاختيار القسري: الأولوية الزوجية",
				facetEn: "Loyalty Priority Dilemma",
				direction: 1,
				format: "forced_choice",
				textAr: "إذا حدث تعارض بين رغبة ضغط اجتماعي خارجي وبين استقرار بيتك وسكينة شريكك:",
				textEn: "If outside social pressure conflicts with your household’s peace and partner’s wellbeing:",
				explanationAr: "اختيار قسري يقيس أولوية النظام الزوجي وفق نظرية بوين ومينوشين.",
				explanationEn: "Forced-choice testing marital subsystem boundary strength.",
				forcedOptions: [{
					id: "A",
					textAr: "أصون استقرار بيتي أولاً بلباقة واحترام للمحيط دون إرهاق شريكي",
					textEn: "Protect household peace first while staying polite to outsiders",
					targetSubscale: "int_boundaries",
					scoreValue: 5,
					traitTagAr: "حماية ذكية للبيت الزوجي",
					traitTagEn: "Healthy Couple Boundary"
				}, {
					id: "B",
					textAr: "أستجيب للضغط الخارجي على حساب راحة بيتي تفادياً للعتاب الاجتماعي",
					textEn: "Yield to external expectations at the expense of home harmony",
					targetSubscale: "int_boundaries",
					scoreValue: 2,
					traitTagAr: "انصياع للضغط الخارجي",
					traitTagEn: "Porous Boundary"
				}]
			},
			{
				subscale: "int_trust_commitment",
				facetAr: "الثقة في النوايا في الرخاء والتعب",
				facetEn: "Unconditional Goodwill",
				direction: 1,
				textAr: "لا أتخلى عن دعم من التزمت به لمجرد مرور مرحلة تعب نفسي أو مالي مؤقت.",
				textEn: "I stand steadily beside my partner during temporary financial or health fatigue.",
				explanationAr: "اختبار أصالة الميثاق والاعتماد المتبادل.",
				explanationEn: "Test of resilient relational loyalty."
			},
			{
				subscale: "int_parenting_family",
				facetAr: "استشعار جاهزية الأبناء للعاطفة",
				facetEn: "Emotional Parenting",
				direction: 1,
				textAr: "أؤمن بضرورة تقبل مشاعر الطفل واحتوائها بدلاً من السخرية منها أو قمعها.",
				textEn: "Children’s emotions deserve calm coaching and validation rather than ridicule.",
				explanationAr: "منهج غوتمان في التربية العاطفية (Emotion-Coaching Parenting).",
				explanationEn: "Gottman Emotion-Coaching Parenting readiness."
			},
			{
				subscale: "int_repair_synergy",
				facetAr: "الذاكرة الإيجابية للعشرة",
				facetEn: "Positive Sentiment Override",
				direction: 1,
				textAr: "تغلب ذكريات الخير والمواقف الجميلة في قلبي على أي منغصات يومية عابرة.",
				textEn: "Fond memories and goodwill consistently outweigh occasional everyday irritations.",
				explanationAr: "ظاهرة \"تغلب المشاعر الإيجابية\" (Positive Sentiment Override).",
				explanationEn: "Gottman Positive Sentiment Override protective factor."
			},
			{
				subscale: "int_boundaries",
				facetAr: "احترام خصوصية الهواتف والمساحة",
				facetEn: "Healthy Autonomy",
				direction: 1,
				textAr: "تنبني الثقة عندي على الصدق والأفعال المستقيمة وليس على المراقبة والتفتيش المستمر.",
				textEn: "My trust grows from consistent integrity rather than anxious surveillance.",
				explanationAr: "نضج الحدود العاطفية والثقة المتزنة.",
				explanationEn: "Trust rooted in integrity rather than control."
			},
			{
				subscale: "int_trust_commitment",
				facetAr: "خطر الازدراء والسخرية",
				facetEn: "Contempt Check",
				direction: -1,
				textAr: "عندما يحتد الغضب، قد ألجأ للسخرية أو التقليل من شأن المقابل لإظهار خطئه.",
				textEn: "When angry, I sometimes use sarcasm or eye-rolling to make my point.",
				explanationAr: "بند عكسي يكشف أهم المنبئات بانهيار العلاقات (غوتمان: الازدراء Contempt).",
				explanationEn: "Reverse-scored screen for Gottman’s #1 predictor: Contempt."
			},
			{
				subscale: "int_parenting_family",
				facetAr: "توفير الوقت النوعي للأسرة",
				facetEn: "Family Presence",
				direction: 1,
				textAr: "أرفض أن يبتلع العمل كل طاقتي دون ترك وقت نوعي صادق للبيت والأحبة.",
				textEn: "I guard against workaholism consuming all my energy from family connection.",
				explanationAr: "التوازن العملي بين الطموح والاستثمار الأسري.",
				explanationEn: "Work-family balance alignment."
			},
			{
				subscale: "int_repair_synergy",
				facetAr: "قبول مبادرة الصلح",
				facetEn: "Repair Receptivity",
				direction: 1,
				textAr: "أستجيب سريعاً ولطفاً إذا حاول شريكي تلطيف الجو والاعتذار بعد التوتر.",
				textEn: "I accept a partner’s gentle olive branch promptly after tension instead of prolonging coldness.",
				explanationAr: "استقبال محاولات الإصلاح العاطفي بنجاح (Repair Uptake).",
				explanationEn: "Receptivity to partner repair attempts."
			},
			{
				subscale: "int_boundaries",
				facetAr: "مساحة الهوايات الشخصية",
				facetEn: "Individual Identity",
				direction: 1,
				textAr: "يسعدني أن يحتفظ شريكي بهواياته وصداقاته الطيبة ضمن توازننا الأسري.",
				textEn: "I happily support my partner keeping healthy personal hobbies and friendships.",
				explanationAr: "يمنع التعلق الخانق ويعزز التجدد داخل الشراكة.",
				explanationEn: "Prevents enmeshment while nourishing mutual freshness."
			},
			{
				subscale: "int_trust_commitment",
				facetAr: "التوافق حول مسار الحياة المستقبلي",
				facetEn: "Shared Life Dreams",
				direction: 1,
				textAr: "أضع خطط السكن والهجرة وتنظيم المستقبل كحوار تشاركي كامل مع شريك الحياة.",
				textEn: "Major relocation, housing, and lifestyle visions are co-authored equally with a partner.",
				explanationAr: "الشراكة الحقيقية في بناء المعنى والخطط المصيرية.",
				explanationEn: "Shared life dreaming and collaborative direction."
			},
			{
				subscale: "int_parenting_family",
				facetAr: "تقدير الأعباء التربوية المستمرة",
				facetEn: "Domestic Appreciation",
				direction: 1,
				textAr: "أقدر أن رعاية الأسرة وتربية الأبناء جهد يومي عظيم يستحق الدعم والشراكة والامتنان.",
				textEn: "Nurturing a home and children is demanding, vital work deserving steady partnership.",
				explanationAr: "وعي تقديري يمنع الاحتراق الأسري.",
				explanationEn: "Recognizes domestic and caregiving effort fairly."
			},
			{
				subscale: "int_repair_synergy",
				facetAr: "إحياء الدفء بالمفاجآت الصادقة",
				facetEn: "Intentional Affection",
				direction: 1,
				textAr: "لا أنتظر المناسبات الرسمية فقط لإظهار التقدير أو تقديم لفتة محبة لمن يشاركني الحياة.",
				textEn: "I do not wait only for formal dates to express warmth or thoughtful surprises.",
				explanationAr: "صيانة الروابط بروح المبادرة الحية.",
				explanationEn: "Proactive affection outside calendar rituals."
			}
		],
		ref: CONSTRUCT_SCIENTIFIC_CATALOG.interpersonal.referenceAr
	},
	{
		construct: "communication",
		seeds: [
			{
				subscale: "com_assertive",
				facetAr: "التواصل الحازم والواضح بمحبة",
				facetEn: "Assertive Clarity",
				direction: 1,
				textAr: "أعبر عن احتياجاتي وحدودي بوضوح ولطف مستخدماً صيغة \"أنا أشعر\" بدلاً من الهجوم والاتهام.",
				textEn: "I express my needs clearly using \"I feel\" statements rather than blaming or attacking.",
				explanationAr: "جوهر التواصل اللاعنفي (NVC لروزنبرغ) والتواصل الحازم الصحي.",
				explanationEn: "Core of Rosenberg’s Nonviolent Communication & healthy assertiveness."
			},
			{
				subscale: "com_reflective",
				facetAr: "الإنصات التأملي العميق",
				facetEn: "Active Reflective Listening",
				direction: 1,
				textAr: "أنصت لحديث الطرف الآخر حتى نهايته وأعيد صياغة مقصده للتأكد من فهمي الصحيح قبل الرد.",
				textEn: "I listen fully and reflect back what I heard before presenting my own rebuttal.",
				explanationAr: "أعلى مهارة في الإنصات الفعال لتقليل سوء الفهم الزوجي.",
				explanationEn: "Active-reflective listening benchmark preventing misinterpretation."
			},
			{
				subscale: "com_collaborating",
				facetAr: "التعاون الإبداعي في حل النزاع",
				facetEn: "TKI Collaborating Mode",
				direction: 1,
				textAr: "عند الخلاف، أسعى لإيجاد حل ثالث إبداعي يحقق احتياجاتي واحتياجات شريكي معاً.",
				textEn: "During conflicts, I seek integrative solutions that genuinely satisfy both partners.",
				explanationAr: "أعلى أنماط نموذج توماس-كيلمان (Thomas-Kilmann Collaborating).",
				explanationEn: "Highest-synergy conflict style in Thomas-Kilmann Instrument (TKI)."
			},
			{
				subscale: "com_analytical",
				facetAr: "الوضوح المنطقي والتفاوضي",
				facetEn: "Analytical Precision",
				direction: 1,
				textAr: "أنظم أفكاري بهدوء وأحدد نقطة الخلاف الحقيقية بدلاً من الخلط بين عدة مواضيع قديمة.",
				textEn: "I focus calmly on the specific issue at hand instead of dragging old grievances back in.",
				explanationAr: "التواصل التحليلي المنظم ومنع تشتيت الخلاف (Kitchen-sinking Control).",
				explanationEn: "Analytical clarity preventing kitchen-sinking during disputes."
			},
			{
				subscale: "com_assertive",
				facetAr: "تجنب الانسحاب الصامت (Stonewalling)",
				facetEn: "Engagement Over Stonewalling",
				direction: -1,
				textAr: "أميل أحياناً للصمت العقابي والانسحاب التام لأيام دون توضيح رغبتي في التهدئة.",
				textEn: "I sometimes resort to cold silent treatment for days without explaining my need to pause.",
				explanationAr: "بند عكسي يرصد \"التحصن الصامت\" (Stonewalling) في أبحاث غوتمان.",
				explanationEn: "Reverse-keyed indicator for Gottman’s Stonewalling."
			},
			{
				subscale: "com_collaborating",
				facetAr: "التنازل المتوازن (Compromising)",
				facetEn: "Mutual Compromise",
				direction: 1,
				textAr: "أشعر بالرضا عندما نلتقي في منتصف الطريق بتنازلات عادلة حين يتعذر التطابق الكامل.",
				textEn: "I gladly meet halfway with fair give-and-take when full consensus is impractical.",
				explanationAr: "يقيس مهارة التسوية المتكافئة في نموذج Thomas-Kilmann.",
				explanationEn: "Evaluates Compromising mode under TKI."
			},
			{
				subscale: "com_reflective",
				facetAr: "الاختيار القسري: بدء الحوار الخادع vs اللطيف",
				facetEn: "Conflict Startup Choice",
				direction: 1,
				format: "forced_choice",
				textAr: "عندما يزعجك تصرف متكرر من شريكك، كيف تبدأ الحديث؟",
				textEn: "When a recurring habit from your partner bothers you, how do you open the talk?",
				explanationAr: "يميز بين \"البداية اللطيفة\" (Softened Startup) والانتقاد التعميمي الحاد.",
				explanationEn: "Distinguishes Gottman’s Softened Startup vs Harsh Startup.",
				forcedOptions: [{
					id: "A",
					textAr: "أصف الموقف المحدد وأثره عليّ بلطف دون عبارات تعميم مثل \"أنت دائماً\"",
					textEn: "Describe the specific event and its impact calmly without \"you always\" labels",
					targetSubscale: "com_assertive",
					scoreValue: 5,
					traitTagAr: "بداية حوار لطيفة وناضجة",
					traitTagEn: "Softened Startup"
				}, {
					id: "B",
					textAr: "أبدأ باللوم المباشر أو الصمت الساخر حتى ينتبه تلقائياً لخطئه",
					textEn: "Start with blunt blame or pointed hints so they realize their fault",
					targetSubscale: "com_assertive",
					scoreValue: 1,
					traitTagAr: "بداية حادة أو دفاعية",
					traitTagEn: "Harsh/Defensive Opening"
				}]
			},
			{
				subscale: "com_expressive",
				facetAr: "البوح الوجداني الصادق",
				facetEn: "Warm Expressiveness",
				direction: 1,
				textAr: "أعبر عن تقديري وشوقي وشكري بالكلمات الواضحة دون حرج أو بخل عاطفي.",
				textEn: "I express appreciation, warmth, and affection openly in clear words.",
				explanationAr: "بُعد التعبيرية الدافئة في التواصل الشخصي.",
				explanationEn: "Expressive communication warmth."
			},
			{
				subscale: "com_analytical",
				facetAr: "التأكد من التفسير قبل الاستنتاج",
				facetEn: "Clarifying Questions",
				direction: 1,
				textAr: "أسأل \"ماذا قصدت بهذه الجملة؟\" بدلاً من بناء افتراضات سلبية من خيالي.",
				textEn: "I ask clarifying questions instead of assuming negative intent behind ambiguous phrasing.",
				explanationAr: "مهارة الفحص التحليلي للمعنى ومنع سوء الفهم الإدراكي.",
				explanationEn: "Analytical verification preventing cognitive distortion."
			},
			{
				subscale: "com_reflective",
				facetAr: "تأكيد فهم النقطة العاطفية",
				facetEn: "Reflective Validation",
				direction: 1,
				textAr: "أركز على فهم ما يعنيه الموضوع بالنسبة للطرف الآخر وليس فقط الكلمات الظاهرة.",
				textEn: "I listen for what an issue deeply means to my partner beneath surface wording.",
				explanationAr: "الإنصات التأملي المزدوج (للمعنى والمشاعر).",
				explanationEn: "Reflective listening tuned to underlying values and feelings."
			},
			{
				subscale: "com_collaborating",
				facetAr: "الابتعاد عن أسلوب الفرض التنافسي",
				facetEn: "Avoiding Domination",
				direction: -1,
				textAr: "أصر على فرض وجهة نظري عبر رفع الصوت أو تكرار الجدل حتى يستسلم الطرف الآخر.",
				textEn: "I raise my voice or push stubbornly until the other person gives in.",
				explanationAr: "بند عكسي يرصد نمط التنافس الصدامي (Competing) في إدارة النزاع.",
				explanationEn: "Reverse-keyed indicator of rigid Competing conflict mode."
			},
			{
				subscale: "com_assertive",
				facetAr: "الدفاعية المفرطة أمام العتاب",
				facetEn: "Defensiveness Check",
				direction: -1,
				textAr: "عندما يعاتبني قريب على أمر أزعجه، أرد فوراً بسرد أخطائه الماضية للدفاع عن نفسي.",
				textEn: "When given feedback, I reflexively counter-attack by listing the other person’s past faults.",
				explanationAr: "بند عكسي يكشف نمط الدفاعية المتقابلة في مقياس غوتمان.",
				explanationEn: "Reverse-keyed marker of defensive counter-complaining."
			},
			{
				subscale: "com_analytical",
				facetAr: "التركيز على المستقبل في الحل",
				facetEn: "Solution Focus",
				direction: 1,
				textAr: "أحوّل الحوار من \"من المخطئ؟\" إلى \"كيف نتفق على نظام يمنع تكرار هذا لاحقاً؟\".",
				textEn: "I pivot talks from assigning blame to designing preventive agreements together.",
				explanationAr: "التفكير البنائي العملي في حل المشكلات الأسرية.",
				explanationEn: "Solution-focused constructive dialogue."
			},
			{
				subscale: "com_expressive",
				facetAr: "مراعاة النبرة والملامح",
				facetEn: "Nonverbal Alignment",
				direction: 1,
				textAr: "أنتبه لتناسق لغة جسدي ونبرة صوتي الهادئة مع كلماتي الطيبة أثناء النقاش.",
				textEn: "I align calm body language and steady tone with respectful words during talks.",
				explanationAr: "انسجام الرسائل اللفظية وغير اللفظية.",
				explanationEn: "Verbal-nonverbal congruence in interpersonal communication."
			},
			{
				subscale: "com_collaborating",
				facetAr: "تقبل التكيف (Accommodating) الواعي",
				facetEn: "Wise Flexibility",
				direction: 1,
				textAr: "أتنازل عن تفصيل غير مصيري عندما أرى أنه يعني لشريكي سعادة كبيرة.",
				textEn: "I gladly defer on low-stakes details when they carry high joy for my partner.",
				explanationAr: "الاستخدام الصحي لنمط الاحتواء (Accommodating) في المواقف المناسبة.",
				explanationEn: "Strategic, healthy use of Accommodating conflict mode."
			},
			{
				subscale: "com_reflective",
				facetAr: "المقاطعة أثناء الحديث",
				facetEn: "Interruption Control",
				direction: -1,
				textAr: "أقاطع المتحدث مراراً لأصحح فكرته أو أفرض ردي قبل أن يكمل جملته.",
				textEn: "I often interrupt mid-sentence to correct points or insert my own counterargument.",
				explanationAr: "بند عكسي يقيس انضباط الاستماع.",
				explanationEn: "Reverse-keyed conversational patience check."
			},
			{
				subscale: "com_assertive",
				facetAr: "طلب التوضيح بحرية",
				facetEn: "Direct Requesting",
				direction: 1,
				textAr: "أطلب ما أحتاجه بشكل واضح ومحدد بدلاً من الاعتماد على التلميح والعتب الصامت.",
				textEn: "I make direct, specific requests rather than expecting partners to read minds.",
				explanationAr: "تجاوز \"قراءة الأفكار المفترضة\" نحو الوضوح الحازم.",
				explanationEn: "Replaces mind-reading expectations with direct requests."
			},
			{
				subscale: "com_expressive",
				facetAr: "استخدام الحوار اليومي الخفيف",
				facetEn: "Everyday Dialogue",
				direction: 1,
				textAr: "أشارك تفاصيل يومي البسيطة بروح دافئة تجعل التواصل بيننا حياً وسلساً.",
				textEn: "I share everyday reflections warmly, keeping natural connection effortless.",
				explanationAr: "الصيانة التواصلية اليومية (Stress-Reducing Conversation).",
				explanationEn: "Low-stakes everyday expressive closeness."
			},
			{
				subscale: "com_collaborating",
				facetAr: "إغلاق القضايا العالقة",
				facetEn: "Unfinished Business Avoidance",
				direction: 1,
				textAr: "لا أؤجل الملفات العالقة حتى تتضخم، بل نحدد موعداً مناسباً لحسمها بود.",
				textEn: "Instead of letting issues fester, we schedule calm time to resolve them thoughtfully.",
				explanationAr: "توازن بين تجنب التهرب وإدارة التوقيت.",
				explanationEn: "Antidote to chronic conflict Avoidance in TKI."
			},
			{
				subscale: "com_analytical",
				facetAr: "تلخيص نقاط الاتفاق أولاً",
				facetEn: "Common Ground Mapping",
				direction: 1,
				textAr: "أبدأ أي تفاوض صعب بذكر المساحات التي نتفق عليها بالفعل لتخفيف حدة الاستقطاب.",
				textEn: "In tense talks, I highlight areas where we already agree first to ease polarization.",
				explanationAr: "أسلوب تفاوضي تحليلي متقدم لتخفيف التوتر.",
				explanationEn: "Constructive common-ground framing."
			},
			{
				subscale: "com_reflective",
				facetAr: "تقدير السياق العاطفي للحديث",
				facetEn: "Timing Wisdom",
				direction: 1,
				textAr: "أختار التوقيت والمكان الملائمين قبل طرح موضوع حساس بدلاً من اقتحام اللحظات المرهقة.",
				textEn: "I pick calm timing before raising sensitive subjects rather than ambushing at exhausted hours.",
				explanationAr: "ذكاء التوقيت التواصلي.",
				explanationEn: "Discernment in conversational timing."
			},
			{
				subscale: "com_assertive",
				facetAr: "الرفض المهذب دون تبرير زائد",
				facetEn: "Respectful Refusal",
				direction: 1,
				textAr: "أعبر عن رفضي لمطلب لا يناسبني بأدب وحزم واضح دون ممارسة العدوان السلبي.",
				textEn: "I decline unsuitable requests politely and firmly without passive-aggressive compliance.",
				explanationAr: "الوقاية من العدوان السلبي (Passive-Aggression) عبر الحزم اللطيف.",
				explanationEn: "Prevents passive-aggressive resentment via polite firmness."
			},
			{
				subscale: "com_expressive",
				facetAr: "الألفة الفكاهية البريئة",
				facetEn: "Playful Affection",
				direction: 1,
				textAr: "أحافظ على روح الفكاهة الودودة والمداعبة الطيبة التي تبهج البيت دون سخرية.",
				textEn: "I share gentle playfulness and warm humor at home without biting sarcasm.",
				explanationAr: "البُعد الودي التعبيري المقوي للصداقة الزوجية.",
				explanationEn: "Playful positive expression."
			},
			{
				subscale: "com_collaborating",
				facetAr: "التعاون في حل العوائق الدائمة",
				facetEn: "Perpetual Gridlock Navigation",
				direction: 1,
				textAr: "في الاختلافات المستمرة بالطبع، أركز على الاحترام المتبادل والبحث عن تسويات مؤقتة مرنة.",
				textEn: "With ongoing temperament differences, I focus on mutual respect and flexible adjustments.",
				explanationAr: "منهج غوتمان في إدارة المشكلات المستمرة (Dialogue on Perpetual Issues).",
				explanationEn: "Gottman’s dialogue framework for perpetual temperament differences."
			},
			{
				subscale: "com_analytical",
				facetAr: "الاختيار القسري: التهرب vs الحوار التفاوضي",
				facetEn: "Avoidance vs Engagement",
				direction: 1,
				format: "forced_choice",
				textAr: "عند ظهور تباين جاد في رؤية مالية أو أسرية، أي مسار تتبع غالباً؟",
				textEn: "When a serious difference emerges on family finances or lifestyle, what path do you take?",
				explanationAr: "اختيار إجباري يقيس التعاون التحليلي مقابل التجنب التام.",
				explanationEn: "Forced-choice contrasting Collaborating analysis vs conflict Avoidance.",
				forcedOptions: [{
					id: "A",
					textAr: "نجلس بالورقة والقلم لنستمع لاحتياجات بعضنا ونبني حلاً تشاركياً وسطاً",
					textEn: "Sit down together, list core needs, and craft a shared integrative solution",
					targetSubscale: "com_collaborating",
					scoreValue: 5,
					traitTagAr: "تعاون تحليلي بنّاء",
					traitTagEn: "Integrative Collaboration"
				}, {
					id: "B",
					textAr: "أتهرب من الحديث وأؤجله باستمرار خشية تطور النقاش لتوتر",
					textEn: "Evade and postpone the talk repeatedly to avoid temporary friction",
					targetSubscale: "com_collaborating",
					scoreValue: 2,
					traitTagAr: "تجنب تفاوضي",
					traitTagEn: "Conflict Avoidance"
				}]
			},
			{
				subscale: "com_reflective",
				facetAr: "فحص الفهم بدون تعالٍ",
				facetEn: "Mutual Check-in",
				direction: 1,
				textAr: "أسأل الطرف الآخر إن كان شعوري أو توضيحي وصل إليه كما أردت أم يحتاج تبسيطاً.",
				textEn: "I verify whether my message felt clear and respectful to the listener.",
				explanationAr: "حرص تواصلي متقدم يغلق فجوة الرسالة.",
				explanationEn: "Communication loop closure check."
			},
			{
				subscale: "com_assertive",
				facetAr: "الصراحة الوقائية المبكرة",
				facetEn: "Early Feedback",
				direction: 1,
				textAr: "أتحدث عن الملاحظات الصغيرة بلطف وهي ما زالت بسيطة قبل أن تتراكم وتنفجر.",
				textEn: "I address minor friction gently early on before small annoyances compound.",
				explanationAr: "الصيانة التواصلية الوقائية.",
				explanationEn: "Preventive early communication."
			},
			{
				subscale: "com_expressive",
				facetAr: "الاعتراف بالمودة باللفظ والفعل",
				facetEn: "Affectionate Fluency",
				direction: 1,
				textAr: "لا أفترض أن الآخرين يعلمون محبتي دون أن أعبر عنها صراحة كلما سنحت الفرصة.",
				textEn: "I never assume loved ones automatically know my care without actively expressing it.",
				explanationAr: "طلاقة التعبير الوجداني الداعم للألفة.",
				explanationEn: "Expressive consistency in close bonds."
			},
			{
				subscale: "com_analytical",
				facetAr: "عدم الخلط بين النقد والفرد",
				facetEn: "Behavior vs Character",
				direction: 1,
				textAr: "أنتقد التصرف المعين نفسه دون إطلاق أوصاف شخصية شاملة تمس جوهر الإنسان.",
				textEn: "I critique a specific action rather than labeling my partner’s whole character.",
				explanationAr: "الفارق الحاسم بين \"الشكوى البناءة\" و\"النقد الهدام\" عند غوتمان.",
				explanationEn: "Distinguishes Complaint from Destructive Criticism (Gottman)."
			},
			{
				subscale: "com_collaborating",
				facetAr: "التحول من الجدال للمرح المشترك",
				facetEn: "De-escalation Skill",
				direction: 1,
				textAr: "أمتلك القدرة على التنازل عن إثبات الغلبة الفردية من أجل بقاء الصفاء المشترك.",
				textEn: "I can let go of winning an argument so our relationship wins peace instead.",
				explanationAr: "أولوية السلام العلائقي على كسب النقاط الجدلية.",
				explanationEn: "Prioritizing relational peace over scoring debate points."
			},
			{
				subscale: "com_reflective",
				facetAr: "ملاحظة الصمت المتألم",
				facetEn: "Reading Quiet Withdrawal",
				direction: 1,
				textAr: "أدرك متى يكون صمت من أحب علامة إرهاق وتعب نفسي وليس تجاهلاً متعمداً.",
				textEn: "I sense when a loved one’s quietness signals exhaustion rather than deliberate coldness.",
				explanationAr: "حساسية الإنصات غير اللفظي.",
				explanationEn: "Accurate decoding of tired withdrawal."
			},
			{
				subscale: "com_assertive",
				facetAr: "ثبات اللغة تحت الاستفزاز",
				facetEn: "Verbal Integrity",
				direction: 1,
				textAr: "أمتنع تماماً عن الألفاظ الجارحة أو التهديد بالقطيعة حتى في لحظات الغضب.",
				textEn: "I never weaponize insults or threats of leaving even during fierce arguments.",
				explanationAr: "أمان التواصل المحترم في الأزمات.",
				explanationEn: "Verbal safety rule protecting relationship trust."
			},
			{
				subscale: "com_expressive",
				facetAr: "تقبل المجاملات والتقدير",
				facetEn: "Warm Receptivity",
				direction: 1,
				textAr: "أستقبل كلمات المدح والتقدير بابتسامة وشكر لطيف دون جفاء أو تقليل من نفسي.",
				textEn: "I receive appreciation warmly with thanks instead of deflecting it awkwardly.",
				explanationAr: "تدوير الطاقة الإيجابية المتبادلة في التواصل.",
				explanationEn: "Reciprocal emotional receptivity."
			},
			{
				subscale: "com_analytical",
				facetAr: "توثيق الاتفاقات المهمة بوضوح",
				facetEn: "Alignment Clarity",
				direction: 1,
				textAr: "في نهاية النقاشات الطويلة نلخص ما اتفقنا عليه بوضوح كي لا نعود لنقطة الصفر.",
				textEn: "At the end of weighty talks, we clearly summarize agreed steps to stay aligned.",
				explanationAr: "تنظيم القرارات الحوارية ومنع الالتباس.",
				explanationEn: "Clear decision closure in analytical communication."
			},
			{
				subscale: "com_collaborating",
				facetAr: "تقدير مساهمة الشريك في الحل",
				facetEn: "Co-Authorship",
				direction: 1,
				textAr: "أحرص أن يشعر الطرف الآخر أن القرار النهائي يمثلنا معاً وليس مفروضاً من طرف واحد.",
				textEn: "I ensure final agreements feel genuinely co-authored by both of us.",
				explanationAr: "التعاون الحقيقي وصناعة الالتزام المشترك.",
				explanationEn: "Co-authored commitment in collaborative resolution."
			},
			{
				subscale: "com_reflective",
				facetAr: "التمهل عن افتراض سوء القصد",
				facetEn: "Charitable Listening",
				direction: 1,
				textAr: "أمنح المتحدث فرصة لتوضيح مراده الحقيقي إذا خانه التعبير في جملة عابرة.",
				textEn: "I let a speaker clarify what they truly meant if a hasty phrase came out poorly.",
				explanationAr: "حسن الظن الحواري الداعم للأمان النفسي.",
				explanationEn: "Charitable listening reducing unnecessary friction."
			}
		],
		ref: CONSTRUCT_SCIENTIFIC_CATALOG.communication.referenceAr
	},
	{
		construct: "positive_psychology",
		seeds: [
			{
				subscale: "pp_values_meaning",
				facetAr: "وضوح القيم والغاية الحياتية",
				facetEn: "Purpose & Values Clarity",
				direction: 1,
				textAr: "أمتلك رؤية واضحة لقيمي الأخلاقية والروحية التي توجه قراراتي الكبرى ومعنى حياتي.",
				textEn: "I hold clear moral and spiritual values that guide my major decisions and life meaning.",
				explanationAr: "يرتبط ببُعد المعنى (Meaning) في نموذج PERMA لسيليغمان وقيم شوارتز.",
				explanationEn: "Reflects Meaning in Seligman’s PERMA and Schwartz Value Clarity."
			},
			{
				subscale: "pp_optimism_gratitude",
				facetAr: "الامتنان والتفاؤل الواقعي",
				facetEn: "Gratitude & Optimism",
				direction: 1,
				textAr: "ألاحظ النعم اليومية والتفاصيل الطيبة في حياتي وأعبر عن امتناني لها باستمرار.",
				textEn: "I actively notice daily blessings and express genuine gratitude regularly.",
				explanationAr: "من أقوى مؤشرات الازدهار النفسي وسعادة العلاقات في علم النفس الإيجابي.",
				explanationEn: "Primary VIA character strength predicting wellbeing and relational satisfaction."
			},
			{
				subscale: "pp_life_goals",
				facetAr: "توازن أهداف الحياة والنمو",
				facetEn: "Balanced Life Goals",
				direction: 1,
				textAr: "لدي خطة واضحة ومتزنة بين طموحي المهني، استقراري الأسري، وتطوري الفكري والشخصي.",
				textEn: "I balance career growth, family stability, financial planning, and lifelong learning.",
				explanationAr: "يقيس الانسجام بين أهداف الحياة المتعددة (PERMA Accomplishment & Relationships).",
				explanationEn: "Measures holistic life-goal alignment."
			},
			{
				subscale: "pp_resilience_flourishing",
				facetAr: "نقاط القوة والإزهار النفسي",
				facetEn: "Character Flourishing",
				direction: 1,
				textAr: "أشعر بقدرتي على توظيف نقاط قوتي الشخصية في خدمة من أحب وترك أثر طيب في محيطي.",
				textEn: "I actively use my signature strengths to enrich my loved ones and community.",
				explanationAr: "مؤشر الازدهار التطبيقي عبر توظيف نقاط القوة (VIA Strengths).",
				explanationEn: "VIA Signature Strengths deployment predicting flourishing."
			},
			{
				subscale: "pp_values_meaning",
				facetAr: "النزاهة الداخلية والعمل بالحق",
				facetEn: "Ethical Congruence",
				direction: 1,
				textAr: "أتخذ موقفي استناداً إلى قناعاتي القيمية الثابتة حتى لو لم يوافقني التيار السائد.",
				textEn: "I stand by core ethical principles even when popular opinion pulls the other way.",
				explanationAr: "الشجاعة الأخلاقية والأصالة القيمية (Authenticity & Integrity).",
				explanationEn: "Moral courage and authentic value alignment."
			},
			{
				subscale: "pp_optimism_gratitude",
				facetAr: "التفاؤل المفسِّر للإخفاق",
				facetEn: "Explanatory Optimism",
				direction: 1,
				textAr: "أتعامل مع الصعوبات على أنها مراحل مؤقتة وقابلة للتجاوز بالعمل والحكمة لا قدرٌ دائم.",
				textEn: "I view setbacks as temporary, specific hurdles workable through effort and wisdom.",
				explanationAr: "نموذج مارتن سيليغمان في الأسلوب التفسيري المتفائل (Learned Optimism).",
				explanationEn: "Martin Seligman’s Learned Optimism explanatory style."
			},
			{
				subscale: "pp_life_goals",
				facetAr: "الاختيار القسري: القيمة والمعنى vs التشتت المادي",
				facetEn: "Intrinsic vs Extrinsic Goals",
				direction: 1,
				format: "forced_choice",
				textAr: "في رسم أولويات حياتك للسنوات العشر القادمة، ما الذي يوجه بوصلتك أولاً؟",
				textEn: "When charting your next decade of life priorities, what guides your compass first?",
				explanationAr: "اختيار قسري يفرق بين الأهداف الجوهرية الداخلية والمظاهر الخارجية (Self-Determination Theory).",
				explanationEn: "Forced-choice separating intrinsic value-driven goals from extrinsic chasing.",
				forcedOptions: [{
					id: "A",
					textAr: "سكينة أسرة متماسكة، نمو معرفي وروحي، وأثر إنساني باقٍ",
					textEn: "Family peace, continuous personal growth, and meaningful human impact",
					targetSubscale: "pp_values_meaning",
					scoreValue: 5,
					traitTagAr: "بوصلة جوهرية سامية",
					traitTagEn: "Intrinsic Meaning Orientation"
				}, {
					id: "B",
					textAr: "التركيز الأساسي على المنافسة المظهرية والتفوق الشكلي على الآخرين",
					textEn: "Outperforming peers visibly in prestige and outward lifestyle markers",
					targetSubscale: "pp_life_goals",
					scoreValue: 2,
					traitTagAr: "تركيز تنافسي خارجي",
					traitTagEn: "Extrinsic Comparison Focus"
				}]
			},
			{
				subscale: "pp_resilience_flourishing",
				facetAr: "الامتنان لشريك الحياة والمحيط",
				facetEn: "Appreciative Presence",
				direction: 1,
				textAr: "أتذكر بوعي محاسن من حولي عند الخلاف كي لا تطغى لحظة غضب على تاريخنا.",
				textEn: "Even during disagreement, I deliberately remember a loved one’s virtues and past kindnesses.",
				explanationAr: "مؤشر عالي للحكمة الوجدانية وتثبيت الرصيد الإيجابي.",
				explanationEn: "Protective gratitude anchoring relationships."
			},
			{
				subscale: "pp_values_meaning",
				facetAr: "موافقة الأقوال للأفعال",
				facetEn: "Behavioral Alignment",
				direction: 1,
				textAr: "تنسجم تصرفاتي اليومية مع القيم التي أتحدث عنها وأطالب بها في الحياة الزوجية.",
				textEn: "My daily conduct consistently reflects the ideals I advocate in relationships.",
				explanationAr: "مؤشر الصدق العملي والانسجام القيمي.",
				explanationEn: "Congruence between espoused and practiced values."
			},
			{
				subscale: "pp_optimism_gratitude",
				facetAr: "النظرة المتشائمة المستسلمة",
				facetEn: "Pessimism Check",
				direction: -1,
				textAr: "أميل غالباً لتوقع أسوأ الاحتمالات وفقدان الحماس سريعاً تجاه المستقبل.",
				textEn: "I often expect the worst-case outcome and easily lose hope about the future.",
				explanationAr: "بند عكسي يقيس الاتجاه التشاؤمي مقابل التفاؤل الواقعي.",
				explanationEn: "Reverse-scored dispositional optimism item."
			},
			{
				subscale: "pp_life_goals",
				facetAr: "الادخار والاستقرار المالي المستقبلي",
				facetEn: "Financial Security Goal",
				direction: 1,
				textAr: "أخطط مالياً لبناء أمان واستقلالية للأسرة على المدى الطويل بعيداً عن الديون المرهقة.",
				textEn: "I plan finances thoughtfully for long-term family stability free of crushing debt.",
				explanationAr: "مؤشر هدف الأمان المالي المتكامل ضمن أهداف الحياة.",
				explanationEn: "Financial stewardship goal indicator."
			},
			{
				subscale: "pp_resilience_flourishing",
				facetAr: "الشغف والانغماس الصحي (Flow)",
				facetEn: "Positive Engagement",
				direction: 1,
				textAr: "أمارس أنشطة معرفية أو عملية أندمج فيها بمتعة وتركيز يجدد طاقتي النفسية.",
				textEn: "I engage regularly in absorbing creative or meaningful activities that renew vitality.",
				explanationAr: "بُعد الانغماس (Engagement / Flow) عند تشيكسينتميهالي وسيليغمان.",
				explanationEn: "PERMA Engagement / Flow indicator."
			},
			{
				subscale: "pp_values_meaning",
				facetAr: "الإحسان والعطاء غير المشروط",
				facetEn: "Benevolence & Generosity",
				direction: 1,
				textAr: "أجد سعادة حقيقية في إدخال السرور على قلب غيري وتخفيف الأعباء عمن حولي.",
				textEn: "Bringing genuine joy or relief to others gives me deep personal fulfillment.",
				explanationAr: "قيمة الإحسان والعطاء في نظرية شوارتز للقيم الإنسانية.",
				explanationEn: "Schwartz Benevolence value dimension."
			},
			{
				subscale: "pp_optimism_gratitude",
				facetAr: "الاحتفاء بالخطوات الإيجابية",
				facetEn: "Savoring Progress",
				direction: 1,
				textAr: "أستمتع بتذوق اللحظات الجميلة البسيطة ولا أؤجل السعادة لحين تحقق أهداف ضخمة فقط.",
				textEn: "I savor simple joyful moments today rather than postponing peace until distant milestones.",
				explanationAr: "مهارة \"التذوق الإيجابي\" (Savoring) في علم النفس الإيجابي.",
				explanationEn: "Positive psychology Savoring skill."
			},
			{
				subscale: "pp_life_goals",
				facetAr: "التوافق بين الطموح والاستقرار",
				facetEn: "Balanced Ambition",
				direction: 1,
				textAr: "طموحاتي المستقبلية قابلة للتنسيق والتناغم مع بناء أسرة سعيدة ومستقرة.",
				textEn: "My career and life ambitions harmonize realistically with nurturing a loving family.",
				explanationAr: "قابلية المواءمة بين الأهداف المهنية والأسرية.",
				explanationEn: "Dual-goal career and family compatibility."
			},
			{
				subscale: "pp_resilience_flourishing",
				facetAr: "النهوض بنضج بعد الخيبات",
				facetEn: "Post-Adversity Growth",
				direction: 1,
				textAr: "أخرج من التجارب الصعبة أكثر وعياً وحكمة دون أن أفقد ثقتي في الخير والناس الطيبين.",
				textEn: "I emerge from tough seasons wiser without growing cynical toward human goodness.",
				explanationAr: "النمو ما بعد الصدمات والضغوط (Post-Traumatic / Stress-Related Growth).",
				explanationEn: "Post-adversity resilience and wisdom."
			},
			{
				subscale: "pp_values_meaning",
				facetAr: "التمسك بالأصالة والتوازن",
				facetEn: "Cultural & Moral Roots",
				direction: 1,
				textAr: "أعتز بجذوري القيمية والأخلاقية وأربطها بفهم معاصر ومنفتح للعالم.",
				textEn: "I honor my ethical and cultural roots while engaging thoughtfully with modern life.",
				explanationAr: "بناء الهوية المتماسكة المنسجمة قيميّاً.",
				explanationEn: "Coherent value identity bridging heritage and modern growth."
			},
			{
				subscale: "pp_life_goals",
				facetAr: "غياب البوصلة والأهداف (عكسي)",
				facetEn: "Goal Clarity Check",
				direction: -1,
				textAr: "أشعر أحياناً أنني أسير في الأيام بلا تصور واضح لما أريده خلال السنوات المقبلة.",
				textEn: "I often drift through weeks with little sense of where I want to be in a few years.",
				explanationAr: "بند عكسي يرصد وضوح الهدف المستقبلي.",
				explanationEn: "Reverse-scored goal clarity check."
			},
			{
				subscale: "pp_optimism_gratitude",
				facetAr: "الامتنان اللفظي المتواصل",
				facetEn: "Grateful Expression",
				direction: 1,
				textAr: "أعتاد قول كلمة الشكر الصادق لأهلي وشريكي على أصغر الخدمات المعتادة يومياً.",
				textEn: "I regularly voice heartfelt thanks to family and partner even for routine kindnesses.",
				explanationAr: "تطبيق الامتنان اليومي كمُحصِّن للعلاقة من الألفة الباردة.",
				explanationEn: "Everyday expressed gratitude protecting against habituation."
			},
			{
				subscale: "pp_values_meaning",
				facetAr: "الضمير الحي في العمل الخاص",
				facetEn: "Private Integrity",
				direction: 1,
				textAr: "البركة والصدق في الرزق والعلاقات مقدم عندي على أي مكاسب سريعة مشبوهة.",
				textEn: "Ethical integrity in livelihood and relationships outweighs any questionable quick gain.",
				explanationAr: "قيمة الكسب النظيف والاستقامة الحياتية.",
				explanationEn: "Ethical primacy in livelihood and partnership."
			},
			{
				subscale: "pp_life_goals",
				facetAr: "الاستثمار المشترك في المعرفة",
				facetEn: "Intellectual Companionship Goal",
				direction: 1,
				textAr: "أتطلع إلى شريك حياة نكبر معاً في الوعي، القراءة، والنقاشات الملهمة عبر العمر.",
				textEn: "I aspire to a partnership where we grow intellectually and thoughtfully together over decades.",
				explanationAr: "هدف النمو المعرفي المشترك طويل الأمد.",
				explanationEn: "Shared lifelong intellectual growth goal."
			},
			{
				subscale: "pp_resilience_flourishing",
				facetAr: "الحكمة في تقديم المشورة",
				facetEn: "Perspective & Wisdom",
				direction: 1,
				textAr: "يلجأ إلي المقربون لسماع رأي متزن يرى الصورة الكبيرة وقت حيرتهم.",
				textEn: "Close friends and relatives trust my balanced perspective when facing tough dilemmas.",
				explanationAr: "قوة الحكمة وبصيرة المنظور (VIA Wisdom/Perspective).",
				explanationEn: "VIA Perspective & Wisdom signature strength."
			},
			{
				subscale: "pp_optimism_gratitude",
				facetAr: "التعامل الإيجابي مع النعم والمحن",
				facetEn: "Contentment",
				direction: 1,
				textAr: "أجمع بين الطموح للارتقاء وبين القناعة والرضا القلبي بما بين يديّ الآن.",
				textEn: "I combine healthy ambition with peaceful contentment for what I already hold.",
				explanationAr: "الجمع المتوازن بين الطموح والرضا النفسي (Authentic Happiness).",
				explanationEn: "Harmonizes aspiration with grounded contentment."
			},
			{
				subscale: "pp_values_meaning",
				facetAr: "التسامح مع التفاوت الطبيعي",
				facetEn: "Universalism Value",
				direction: 1,
				textAr: "أحترم كرامة الإنسان بصرف النظر عن مستواه المادي أو خلفيته الاجتماعية.",
				textEn: "I honor every person’s dignity regardless of social background or wealth.",
				explanationAr: "قيمة العالمية والعدل الإنساني في نموذج شوارتز.",
				explanationEn: "Schwartz Universalism value metric."
			},
			{
				subscale: "pp_life_goals",
				facetAr: "الاختيار القسري: الاستقرار الأسري vs الإنجاز الفردي المجرد",
				facetEn: "Goals Architecture Choice",
				direction: 1,
				format: "forced_choice",
				textAr: "عند تعارض فرصة مغرية تتطلب غياباً طويلاً وتضحية تامة باستقرار الأسرة:",
				textEn: "When a tempting opportunity demands prolonged absence at heavy cost to family stability:",
				explanationAr: "اختيار إجباري يزن بين الطموح الشخصي والحفاظ على تكامل الأسرة.",
				explanationEn: "Forced-choice assessing goal hierarchy balancing ambition and family harmony.",
				forcedOptions: [{
					id: "A",
					textAr: "أتشاور مع شريكي وأبحث عن صيغة تحفظ تماسك بيتنا ولا تضحي بالأسرة",
					textEn: "Consult deeply and craft a path preserving household unity above all",
					targetSubscale: "pp_life_goals",
					scoreValue: 5,
					traitTagAr: "تكامل أسري واعٍ",
					traitTagEn: "Family-Integrated Ambition"
				}, {
					id: "B",
					textAr: "أقدم هدفي المهني الفردي دائماً ولو أدى لتوتر أو بعد عائلي ممتد",
					textEn: "Prioritize individual advancement first despite prolonged family strain",
					targetSubscale: "pp_life_goals",
					scoreValue: 2,
					traitTagAr: "أولوية فردية مطلقة",
					traitTagEn: "Solo Career Priority"
				}]
			},
			{
				subscale: "pp_resilience_flourishing",
				facetAr: "السكينة الروحية والاتزان",
				facetEn: "Inner Serenity",
				direction: 1,
				textAr: "أخصص لحظات تأمل هادئة تربطني بغايتي وتجدد صفائي الداخلي أسبوعياً.",
				textEn: "I preserve quiet contemplative moments weekly to reconnect with purpose and peace.",
				explanationAr: "الركيزة الروحية والتأملية للصحة النفسية الإيجابية.",
				explanationEn: "Contemplative/spiritual anchor supporting flourishing."
			},
			{
				subscale: "pp_optimism_gratitude",
				facetAr: "رؤية الخير في طباع الناس",
				facetEn: "Positive Reframing of Others",
				direction: 1,
				textAr: "ألاحظ الجوانب الطيبة في شخصية من أعاشر قبل أن تقع عيني على عيوبهم العابرة.",
				textEn: "I notice admirable qualities in people around me before dwelling on minor flaws.",
				explanationAr: "عادة التقدير الإيجابي المعززة لجودة الحياة الزوجية.",
				explanationEn: "Appreciative attention strengthening interpersonal warmth."
			},
			{
				subscale: "pp_values_meaning",
				facetAr: "الصدق تحت الضغط الاجتماعي",
				facetEn: "Authentic Courage",
				direction: 1,
				textAr: "لا أنافق أو أؤيد خطأً واضحاً لمجرد مسايرة مجلس أو كسب ود عابر.",
				textEn: "I refrain from validating obvious wrongs merely to win fleeting social approval.",
				explanationAr: "الشجاعة الأخلاقية والأمانة الفكرية.",
				explanationEn: "Ethical authenticity over conformity."
			},
			{
				subscale: "pp_life_goals",
				facetAr: "بناء الإرث والعطاء المجتمعي",
				facetEn: "Generativity",
				direction: 1,
				textAr: "أحلم بأن يكون بيتنا مصدر خير وإلهام إيجابي لمن حولنا وليس منغلقاً على أنفسنا.",
				textEn: "I envision our household radiating kindness and positive hospitality outward.",
				explanationAr: "التوليدية والعطاء المجتمعي (Erikson Generativity).",
				explanationEn: "Generativity and community flourishing goal."
			},
			{
				subscale: "pp_resilience_flourishing",
				facetAr: "المرونة الذهنية أمام المستقبل",
				facetEn: "Future Adaptability",
				direction: 1,
				textAr: "أواجه تغيرات المستقبل بتفاؤل علمي واستعداد للتعلم بدلاً من الخوف المفرط.",
				textEn: "I meet future transitions with readiness to learn rather than rigid anxiety.",
				explanationAr: "المرونة المستقبلية الإيجابية.",
				explanationEn: "Adaptive forward orientation."
			},
			{
				subscale: "pp_optimism_gratitude",
				facetAr: "عدم التعلق بالندم الماضي",
				facetEn: "Past Peace",
				direction: 1,
				textAr: "تصالحت مع تجارب الماضي وأستثمر طاقتي في الحاضر والمستقبل القابل للبناء.",
				textEn: "I have made peace with past chapters and focus energy on building today and tomorrow.",
				explanationAr: "الصحة الزمنية الإيجابية في نموذج زيمباردو وسيليغمان.",
				explanationEn: "Healthy time-perspective balancing gratitude and future focus."
			},
			{
				subscale: "pp_values_meaning",
				facetAr: "أولوية الجودة الإنسانية في الاختيار",
				facetEn: "Intrinsic Partner Values",
				direction: 1,
				textAr: "أضع الخُلق والدين والنضج العقلي قبل أي معايير عابرة عند اختيار شريك الحياة.",
				textEn: "Character, ethics, and emotional maturity outweigh superficial traits in partner choice.",
				explanationAr: "نقاء بوصلة الاختيار القيمية للشريك.",
				explanationEn: "Character-first partner selection criteria."
			},
			{
				subscale: "pp_life_goals",
				facetAr: "التخطيط الصحي والحيوي المشترك",
				facetEn: "Vitality Goals",
				direction: 1,
				textAr: "أضع جودة الصحة الجسدية والراحة النفسية ضمن أهداف أسرتنا الأساسية.",
				textEn: "I treat shared physical health and mental rest as core family priorities.",
				explanationAr: "إدراج الصحة والحيوية ضمن أهداف الحياة المشتركة.",
				explanationEn: "Integrating vitality into long-term life goals."
			},
			{
				subscale: "pp_resilience_flourishing",
				facetAr: "تجاوز الإحباط الاجتماعي بالرسالة",
				facetEn: "Purpose Shielding",
				direction: 1,
				textAr: "تمنحني رسالتي وقيمي حصانة نفسية أمام المقارنات والانتقادات الهامشية.",
				textEn: "Having clear personal purpose protects me from petty criticism or social pressure.",
				explanationAr: "حماية الهوية الذاتية بوضوح المعنى.",
				explanationEn: "Purpose-driven resilience against social noise."
			},
			{
				subscale: "pp_optimism_gratitude",
				facetAr: "الضحك الطيب والبهجة العائلية",
				facetEn: "Playful Flourishing",
				direction: 1,
				textAr: "أؤمن أن البهجة العائلية والضحك المودّ هما من أركان الصحة النفسية في البيت.",
				textEn: "Shared laughter and lightheartedness are vital pillars of domestic wellbeing.",
				explanationAr: "عنصر المشاعر الإيجابية (Positive Emotion) في PERMA.",
				explanationEn: "PERMA Positive Emotion pillar inside family life."
			},
			{
				subscale: "pp_values_meaning",
				facetAr: "الشعور بالمعنى الشامل للرحلة",
				facetEn: "Life Fulfillment",
				direction: 1,
				textAr: "أشعر بانسجام عميق حين أخدم غاية نبيلة تنفع أسرتي ومجتمعي بأمانة وإخلاص.",
				textEn: "I feel deepest fulfillment when contributing honestly to my family and community.",
				explanationAr: "ذروة الازدهار القيمي وفق علم النفس الإيجابي المعاصر.",
				explanationEn: "Eudaimonic fulfillment marker."
			}
		],
		ref: CONSTRUCT_SCIENTIFIC_CATALOG.positive_psychology.referenceAr
	}
];
function buildFullTieredBank() {
	const all = [];
	let runningIdx = 1;
	for (let slot = 0; slot < 36; slot++) {
		const minTier = slot < 4 ? "quick" : slot < 18 ? "advanced" : "professional";
		for (const entry of CONSTRUCT_SEEDS_MAP) {
			const seed = entry.seeds[slot];
			if (!seed) continue;
			all.push({
				id: `tp_${entry.construct}_${slot + 1}`,
				index: runningIdx++,
				construct: entry.construct,
				subscale: seed.subscale,
				facetAr: seed.facetAr,
				facetEn: seed.facetEn,
				format: seed.format || "likert",
				direction: seed.direction,
				textAr: seed.textAr,
				textEn: seed.textEn,
				scientificReference: entry.ref,
				dimensionExplanationAr: seed.explanationAr,
				dimensionExplanationEn: seed.explanationEn,
				forcedOptions: seed.forcedOptions,
				minTier
			});
		}
	}
	return all;
}
var FULL_TIERED_PSYCHOLOGY_BANK = buildFullTieredBank();
function getQuestionsForAnalysisTier(tier) {
	if (tier === "quick") return FULL_TIERED_PSYCHOLOGY_BANK.filter((q) => q.minTier === "quick");
	if (tier === "advanced") return FULL_TIERED_PSYCHOLOGY_BANK.filter((q) => q.minTier === "quick" || q.minTier === "advanced");
	return FULL_TIERED_PSYCHOLOGY_BANK;
}
//#endregion
export { CONSTRUCT_SCIENTIFIC_CATALOG as n, getQuestionsForAnalysisTier as r, ANALYSIS_TIERS_CATALOG as t };
