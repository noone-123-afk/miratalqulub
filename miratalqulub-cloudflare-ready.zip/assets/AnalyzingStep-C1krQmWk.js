import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { D as Sparkles, En as Brain, Pt as Heart, Ut as Fingerprint } from "./vendor-icons-WoMClU7U.js";
import { n as AnimatePresence, t as motion } from "./vendor-motion-BS7ODJw7.js";
//#region src/components/AnalyzingStep.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var STEPS = [
	"تحليل كيمياء الشخصية ونمط الحياة العاطفي...",
	"مطابقة الملامح العرقية والجمالية مع أصول شريكك...",
	"توليد التناغم الروحي وتفاصيل لغة الحب المشتركة...",
	"رسم الصورة الواقعية لشريك الحياة بدقة سينمائية...",
	"إعداد بطاقة توأم الروح والمواصفات الجوهرية..."
];
var AnalyzingStep = ({ profile }) => {
	const [currentStepIndex, setCurrentStepIndex] = (0, import_react.useState)(0);
	const [progress, setProgress] = (0, import_react.useState)(15);
	(0, import_react.useEffect)(() => {
		const stepInterval = setInterval(() => {
			setCurrentStepIndex((prev) => {
				if (prev < STEPS.length - 1) return prev + 1;
				return prev;
			});
		}, 1400);
		const progressInterval = setInterval(() => {
			setProgress((prev) => {
				if (prev >= 95) return 95;
				return prev + Math.floor(Math.random() * 8) + 3;
			});
		}, 250);
		return () => {
			clearInterval(stepInterval);
			clearInterval(progressInterval);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		initial: {
			opacity: 0,
			scale: .95
		},
		animate: {
			opacity: 1,
			scale: 1
		},
		exit: {
			opacity: 0,
			scale: .95
		},
		transition: { duration: .4 },
		className: "w-full max-w-md mx-auto px-4 py-16 text-center text-white",
		dir: "rtl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative w-44 h-44 mx-auto mb-8 flex items-center justify-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
						animate: {
							scale: [
								1,
								1.25,
								1
							],
							opacity: [
								.35,
								.65,
								.35
							]
						},
						transition: {
							duration: 3,
							repeat: Infinity,
							ease: "easeInOut"
						},
						className: "absolute inset-0 rounded-full bg-gradient-to-tr from-rose-500/40 via-pink-500/30 to-violet-600/40 blur-2xl pointer-events-none"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
						animate: { rotate: 360 },
						transition: {
							duration: 14,
							repeat: Infinity,
							ease: "linear"
						},
						className: "absolute inset-1 rounded-full border-2 border-rose-500/40 border-dashed"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
						animate: { rotate: -360 },
						transition: {
							duration: 9,
							repeat: Infinity,
							ease: "linear"
						},
						className: "absolute inset-5 rounded-full border-2 border-violet-500/40 border-dotted"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
						animate: {
							y: [
								-4,
								4,
								-4
							],
							scale: [
								1,
								1.05,
								1
							]
						},
						transition: {
							duration: 2.4,
							repeat: Infinity,
							ease: "easeInOut"
						},
						className: "relative w-24 h-24 rounded-3xl bg-gradient-to-tr from-rose-500 via-pink-500 to-violet-600 p-0.5 shadow-2xl shadow-rose-500/50 flex items-center justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-full h-full bg-[#140e2b] rounded-[22px] flex items-center justify-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-4xl",
								children: "🔮"
							})
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.h3, {
				initial: {
					opacity: 0,
					y: 10
				},
				animate: {
					opacity: 1,
					y: 0
				},
				transition: { delay: .15 },
				className: "text-2xl font-black mb-2 text-white font-['Alexandria']",
				children: ["جاري كشف ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-gradient",
					children: "توأم روحك"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.p, {
				initial: {
					opacity: 0,
					y: 10
				},
				animate: {
					opacity: 1,
					y: 0
				},
				transition: { delay: .25 },
				className: "text-xs sm:text-sm text-gray-300 mb-6",
				children: [
					"المنصة تقوم الآن بمطابقة شخصيتك مع ملامح (",
					profile.ethnicity,
					") في (",
					profile.country,
					")."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					y: 12
				},
				animate: {
					opacity: 1,
					y: 0
				},
				transition: { delay: .3 },
				className: "glass-panel p-4 rounded-2xl border border-white/10 mb-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-7 flex items-center justify-center overflow-hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, {
							mode: "wait",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
								initial: {
									opacity: 0,
									y: 12
								},
								animate: {
									opacity: 1,
									y: 0
								},
								exit: {
									opacity: 0,
									y: -12
								},
								transition: { duration: .28 },
								className: "flex items-center justify-center gap-2 text-rose-300 text-sm font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-4 h-4 animate-spin text-yellow-300 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: STEPS[currentStepIndex] })]
							}, currentStepIndex)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-full h-2 rounded-full bg-white/10 overflow-hidden mt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
							className: "h-full bg-gradient-to-l from-rose-500 via-pink-500 to-violet-500 rounded-full",
							initial: { width: "10%" },
							animate: { width: `${progress}%` },
							transition: { duration: .3 }
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-[11px] text-gray-400 mt-2 font-mono",
						children: [
							"اكتمال التحليل: ",
							progress,
							"%"
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: { opacity: 0 },
				animate: { opacity: 1 },
				transition: { delay: .4 },
				className: "flex flex-wrap items-center justify-center gap-2 text-[11px] text-gray-300",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "px-2.5 py-1 rounded-full bg-white/5 border border-white/10 flex items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "w-3 h-3 text-rose-400" }), " تحليل نفسي عميق"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "px-2.5 py-1 rounded-full bg-white/5 border border-white/10 flex items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fingerprint, { className: "w-3 h-3 text-violet-400" }), " بصمة الملامح العرقية"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "px-2.5 py-1 rounded-full bg-white/5 border border-white/10 flex items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "w-3 h-3 text-pink-400" }), " صورة واقعية 100%"]
					})
				]
			})
		]
	});
};
//#endregion
export { AnalyzingStep };
