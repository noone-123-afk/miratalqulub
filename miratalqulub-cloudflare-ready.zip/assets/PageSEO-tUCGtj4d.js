import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react } from "./vendor-react-Bm_EF59R.js";
//#region src/components/PageSEO.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var PageSEO = ({ title, description, canonicalPath, language, pageType = "website", structuredData }) => {
	(0, import_react.useEffect)(() => {
		document.title = title;
		let descMeta = document.querySelector("meta[name=\"description\"]");
		if (!descMeta) {
			descMeta = document.createElement("meta");
			descMeta.setAttribute("name", "description");
			document.head.appendChild(descMeta);
		}
		descMeta.setAttribute("content", description);
		const fullCanonicalUrl = `https://miratalqulub.com${canonicalPath}`;
		let canonicalLink = document.querySelector("link[rel=\"canonical\"]");
		if (!canonicalLink) {
			canonicalLink = document.createElement("link");
			canonicalLink.setAttribute("rel", "canonical");
			document.head.appendChild(canonicalLink);
		}
		canonicalLink.setAttribute("href", fullCanonicalUrl);
		const setOgMeta = (property, content) => {
			let meta = document.querySelector(`meta[property="${property}"]`);
			if (!meta) {
				meta = document.createElement("meta");
				meta.setAttribute("property", property);
				document.head.appendChild(meta);
			}
			meta.setAttribute("content", content);
		};
		setOgMeta("og:title", title);
		setOgMeta("og:description", description);
		setOgMeta("og:url", fullCanonicalUrl);
		setOgMeta("og:type", pageType === "article" ? "article" : "website");
		setOgMeta("og:locale", language === "ar" ? "ar_AR" : "en_US");
		setOgMeta("og:site_name", language === "ar" ? "مِـرآة القـلوب" : "Mirror of Hearts");
		const setTwitterMeta = (name, content) => {
			let meta = document.querySelector(`meta[name="${name}"]`);
			if (!meta) {
				meta = document.createElement("meta");
				meta.setAttribute("name", name);
				document.head.appendChild(meta);
			}
			meta.setAttribute("content", content);
		};
		setTwitterMeta("twitter:card", "summary_large_image");
		setTwitterMeta("twitter:title", title);
		setTwitterMeta("twitter:description", description);
		const scriptId = "page-dynamic-structured-data";
		let scriptTag = document.getElementById(scriptId);
		if (structuredData) {
			if (!scriptTag) {
				scriptTag = document.createElement("script");
				scriptTag.id = scriptId;
				scriptTag.type = "application/ld+json";
				document.head.appendChild(scriptTag);
			}
			scriptTag.text = JSON.stringify(structuredData);
		} else if (scriptTag) scriptTag.remove();
		return () => {
			const existingScript = document.getElementById(scriptId);
			if (existingScript) existingScript.remove();
		};
	}, [
		title,
		description,
		canonicalPath,
		language,
		pageType,
		structuredData
	]);
	return null;
};
//#endregion
export { PageSEO as t };
