import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { Lt as Globe, P as ShieldCheck, S as Sun, Wt as FileText, Xt as ExternalLink, bt as Lock, h as Trash2, jt as Info, mn as CircleCheck, r as X, st as Moon } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import { d as useAppTheme, l as useLanguage, u as useAuth } from "./index-C5uCeetQ.js";
import { n as AnimatePresence, t as motion } from "./vendor-motion-BS7ODJw7.js";
import { s as purgeAllUserDataPermanently } from "./userHistoryService-6N9Zh8ed.js";
//#region src/components/LegalModal.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var LegalModal = ({ isOpen, onClose, initialTab = "privacy" }) => {
	const { language, toggleLanguage } = useLanguage();
	const { user } = useAuth();
	const [theme, toggleTheme] = useAppTheme();
	const isAr = language === "ar";
	const isLight = theme === "light";
	const [activeTab, setActiveTab] = (0, import_react.useState)(initialTab);
	const [confirmDelete, setConfirmDelete] = (0, import_react.useState)(false);
	const [isDeleting, setIsDeleting] = (0, import_react.useState)(false);
	const [deleteSuccess, setDeleteSuccess] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setActiveTab(initialTab);
	}, [initialTab, isOpen]);
	if (!isOpen) return null;
	const handlePermanentDelete = async () => {
		soundManager.playTap();
		setIsDeleting(true);
		try {
			await purgeAllUserDataPermanently(user);
			setIsDeleting(false);
			setConfirmDelete(false);
			setDeleteSuccess(true);
			setTimeout(() => setDeleteSuccess(false), 4500);
		} catch {
			setIsDeleting(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md",
		dir: isAr ? "rtl" : "ltr",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: {
				opacity: 0,
				scale: .95,
				y: 15
			},
			animate: {
				opacity: 1,
				scale: 1,
				y: 0
			},
			exit: {
				opacity: 0,
				scale: .95,
				y: 15
			},
			transition: { duration: .25 },
			className: `relative w-full max-w-4xl max-h-[92vh] flex flex-col rounded-3xl border shadow-2xl overflow-hidden ${isLight ? "bg-white border-slate-300 text-slate-900" : "bg-[#0f172a] border-slate-700 text-white shadow-black/80"}`,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `p-4 sm:p-6 border-b flex flex-wrap items-center justify-between gap-4 shrink-0 ${isLight ? "bg-slate-50 border-slate-200" : "bg-slate-900/60 border-slate-800"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `w-10 h-10 sm:w-11 sm:h-11 rounded-2xl border flex items-center justify-center ${isLight ? "bg-blue-50 border-blue-200 text-blue-600" : "bg-blue-950/80 border-blue-500/40 text-blue-400"}`,
							children: activeTab === "privacy" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "w-5 h-5 text-emerald-500" }) : activeTab === "terms" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-5 h-5 text-blue-500" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "w-5 h-5 text-purple-500" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: `text-base sm:text-lg font-extrabold font-['Alexandria'] ${isLight ? "text-slate-900" : "text-white"}`,
							children: activeTab === "privacy" ? isAr ? "سياسة الخصوصية وحماية البيانات" : "Privacy Policy & Data Protection" : activeTab === "terms" ? isAr ? "شروط الاستخدام والخدمة" : "Terms of Service" : isAr ? "عن الموقع والإشراف الهندسي" : "About Us & Engineering Supervision"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: `text-xs ${isLight ? "text-slate-600" : "text-slate-300"}`,
							children: isAr ? "الأردن - عمّان • one497303@gmail.com • تشفير قياسي TLS 1.3" : "Jordan - Amman • one497303@gmail.com • TLS 1.3 Encrypted"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `flex p-1 rounded-2xl border ${isLight ? "bg-slate-100 border-slate-200" : "bg-slate-950 border-slate-800"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											soundManager.playTap();
											setActiveTab("privacy");
										},
										className: `px-2.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer ${activeTab === "privacy" ? "bg-blue-600 text-white shadow-sm" : isLight ? "text-slate-600 hover:text-slate-900" : "text-slate-400 hover:text-white"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "الخصوصية" : "Privacy" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											soundManager.playTap();
											setActiveTab("terms");
										},
										className: `px-2.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer ${activeTab === "terms" ? "bg-blue-600 text-white shadow-sm" : isLight ? "text-slate-600 hover:text-slate-900" : "text-slate-400 hover:text-white"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "الشروط" : "Terms" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											soundManager.playTap();
											setActiveTab("about");
										},
										className: `px-2.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer ${activeTab === "about" ? "bg-blue-600 text-white shadow-sm" : isLight ? "text-slate-600 hover:text-slate-900" : "text-slate-400 hover:text-white"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "عن الموقع" : "About" })]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									soundManager.playTap();
									toggleLanguage();
								},
								className: `px-2.5 py-1.5 rounded-xl border text-xs font-bold transition flex items-center gap-1 cursor-pointer ${isLight ? "bg-white border-slate-200 text-sky-700" : "bg-white/5 border-white/10 text-sky-300"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "EN" : "AR" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									soundManager.playTap();
									toggleTheme();
								},
								className: `p-2 rounded-xl border transition cursor-pointer ${isLight ? "bg-white border-slate-200 text-amber-700" : "bg-white/5 border-white/10 text-amber-300"}`,
								children: isLight ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "w-4 h-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "w-4 h-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									soundManager.playTap();
									onClose();
									window.location.hash = activeTab === "privacy" ? "#/privacy" : activeTab === "terms" ? "#/terms" : "#/about";
								},
								className: `px-2.5 py-1.5 rounded-xl border text-[11px] font-bold transition flex items-center gap-1 cursor-pointer ${isLight ? "bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700" : "bg-white/5 hover:bg-white/10 border-white/10 text-slate-300"}`,
								title: isAr ? "عرض الصفحة الكاملة" : "Open Full Page",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "w-3.5 h-3.5 text-blue-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline",
									children: isAr ? "الصفحة الكاملة" : "Full Page"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									soundManager.playTap();
									onClose();
								},
								className: `w-9 h-9 rounded-xl flex items-center justify-center transition cursor-pointer ${isLight ? "bg-slate-200 hover:bg-slate-300 text-slate-700" : "bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-5 h-5" })
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `flex-1 overflow-y-auto p-4 sm:p-7 space-y-6 text-xs sm:text-sm leading-relaxed scrollbar-thin ${isLight ? "text-slate-700" : "text-slate-200"}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `p-4 rounded-2xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${isLight ? "bg-rose-50 border-rose-200 text-slate-900" : "bg-rose-950/30 border-rose-500/40 text-slate-100"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 font-bold text-rose-500",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "w-4 h-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "حق المستخدم في حذف بياناته نهائياً (Right to Erasure)" : "User’s Right to Permanently Delete Data (GDPR)" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: `text-xs ${isLight ? "text-slate-600" : "text-slate-300"}`,
										children: isAr ? "يمكنك مسح كافة بياناتك وسجل اختباراتك من المتصفح والسحابة نهائياً بنقرة زر واحدة." : "You can permanently erase all your profile and test records from browser and cloud storage with one click."
									})]
								}),
								!confirmDelete && !deleteSuccess && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setConfirmDelete(true),
									className: "px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs cursor-pointer shrink-0 flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "حذف بياناتي نهائياً" : "Delete Data Permanently" })]
								}),
								deleteSuccess && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs font-bold text-emerald-500 flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "تم حذف بياناتك نهائياً." : "Data permanently deleted." })]
								}),
								confirmDelete && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										disabled: isDeleting,
										onClick: handlePermanentDelete,
										className: "px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs cursor-pointer",
										children: isDeleting ? isAr ? "جاري الحذف..." : "Deleting..." : isAr ? "تأكيد الحذف النهائي" : "Confirm Delete"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setConfirmDelete(false),
										className: `px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer ${isLight ? "bg-white border border-slate-300 text-slate-700" : "bg-slate-800 text-slate-300"}`,
										children: isAr ? "إلغاء" : "Cancel"
									})]
								})
							]
						}),
						activeTab === "privacy" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `p-4 rounded-2xl border space-y-2 ${isLight ? "bg-emerald-50 border-emerald-300 text-slate-900" : "bg-emerald-950/40 border-emerald-500/50 text-slate-100"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 font-extrabold text-emerald-500 text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "w-5 h-5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "ميثاق حماية البيانات وتشفير TLS 1.3 (الأردن - عمّان)" : "Data Protection & TLS 1.3 Charter (Jordan - Amman)" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs sm:text-sm leading-relaxed",
										children: isAr ? "تُعالج جميع إجابات المقاييس النفسية واختبارات الذكاء وكاشف التوافق بخصوصية تامة عبر بروتوكول التشفير القياسي TLS 1.3 أثناء النقل وAES-256 أثناء التخزين، تحت إشراف فريقنا الهندسي في (الأردن - عمّان). نحن لا نبيع ولا نشارك بيانات المستخدمين مع أي طرف ثالث إطلاقاً." : "All psychometric responses, intelligence batteries, and compatibility inputs are processed with strict privacy under TLS 1.3 in-transit encryption and AES-256 storage encryption, supervised by our engineering team in Amman, Jordan. We never sell or share user data."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: `font-extrabold text-sm sm:text-base ${isLight ? "text-slate-900" : "text-white"}`,
										children: isAr ? "1. مبدأ الحد الأدنى من جمع البيانات (Data Minimization)" : "1. Data Minimization Principle"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: isAr ? "نكتفي بالاسم المستعار، وسنة الميلاد فقط (دون تاريخ الميلاد الدقيق)، والخيارات الثقافية الإقليمية العامة، مع حظر رفع الصور الشخصية، واشتراط مربع الموافقة الإلزامي قبل حساب التوافق." : "We collect only a nickname, birth year (never exact date of birth), and general cultural scope, strictly prohibiting personal photo uploads and requiring explicit consent prior to compatibility scoring." })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: `font-extrabold text-sm sm:text-base ${isLight ? "text-slate-900" : "text-white"}`,
										children: isAr ? "2. التواصل الرسمي ومسؤول حماية البيانات (DPO)" : "2. Official Engineering Supervision & DPO Contact"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: isAr ? "الإشراف الهندسي: الأردن - عمّان (Jordan - Amman) • البريد الرسمي المعتمد: one497303@gmail.com" : "Engineering Supervision: Jordan - Amman (الأردن - عمّان) • Official Email: one497303@gmail.com" })]
								})
							]
						}),
						activeTab === "terms" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: `font-extrabold text-sm sm:text-base ${isLight ? "text-slate-900" : "text-white"}`,
									children: isAr ? "1. طبيعة المنصة وإخلاء المسؤولية العلمي والعيادي" : "1. Platform Nature & Scientific Clinical Disclaimer"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: isAr ? "تُدار منصة «مرآة القلوب» بإشراف هندسي في (الأردن - عمّان). جميع المقاييس والاختبارات هي أدوات استكشافية وتثقيفية بحتة وليست تشخيصاً طبياً أو سريرياً، وتتطلب استشارة مختص مرخص عند الحاجة." : "Mirror of Hearts is supervised by our engineering team in Amman, Jordan. All scales and assessments are exploratory and educational tools, not medical or clinical diagnoses." })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: `font-extrabold text-sm sm:text-base ${isLight ? "text-slate-900" : "text-white"}`,
									children: isAr ? "2. التشفير TLS 1.3 وحق حذف البيانات نهائياً" : "2. TLS 1.3 Security & Right to Permanent Deletion"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: isAr ? "تخضع كافة الجلسات لتشفير TLS 1.3، ويكفل الموقع حق المستخدم المطلق في حذف بياناته نهائياً في أي وقت عبر زر الحذف الفوري أو مراسلة one497303@gmail.com." : "All sessions are protected by TLS 1.3 encryption, and users retain the unconditional right to permanently delete their data anytime via the instant delete button or by emailing one497303@gmail.com." })]
							})]
						}),
						activeTab === "about" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: `font-extrabold text-sm sm:text-base ${isLight ? "text-slate-900" : "text-white"}`,
									children: isAr ? "عن منصة مرآة القلوب والإشراف الهندسي (الأردن - عمّان)" : "About Mirror of Hearts & Engineering Supervision (Jordan - Amman)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: isAr ? "منصة علمية وأدبية مستقلة بإشراف هندسي في (الأردن - عمّان)، تدمج المقاييس السيكومترية الموثقة بمراجع APA (غوتمان، بولبي، بيك، كاتل، غاردنر) مع موسوعة الأبحاث والروايات الأدبية، ضمن بيئة مشفرة ببروتوكول TLS 1.3. للتواصل الرسمي: one497303@gmail.com." : "An independent scientific and literary platform supervised by engineers in Amman, Jordan, integrating APA-referenced psychometric scales with a research encyclopedia and literary novels under TLS 1.3 encryption. Official contact: one497303@gmail.com." })]
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `p-4 sm:p-5 border-t flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0 ${isLight ? "bg-slate-50 border-slate-200" : "bg-slate-900/60 border-slate-800"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "w-4 h-4 text-emerald-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "الأردن - عمّان • one497303@gmail.com • تشفير TLS 1.3" : "Jordan - Amman • one497303@gmail.com • TLS 1.3" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							soundManager.playTap();
							onClose();
						},
						className: "w-full sm:w-auto py-2 px-6 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition shadow-sm cursor-pointer",
						children: isAr ? "فهمت وموافق" : "Understood & Agree"
					})]
				})
			]
		})
	}) });
};
//#endregion
export { LegalModal };
