import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { B as Send, D as Sparkles, Dn as Bot, Ht as Flame, I as Share2, Pt as Heart, Y as Radio, _ as ThumbsUp, bn as Check, bt as Lock, d as UserCheck, ft as MessageCircle, hn as CircleAlert, it as Pause, lt as Mic, r as X, rn as Copy, tt as Play, v as ThumbsDown, vn as ChevronLeft, w as Star } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import { t as motion } from "./vendor-motion-BS7ODJw7.js";
import { a as confetti_module_default, i as saveChatCadenceExchanges, r as loadSavedChatCadenceExchanges } from "./chatCadenceTracker-DzV50N4M.js";
import { n as useLiveChat, t as VoiceToneAnalysisModal } from "./VoiceToneAnalysisModal-CAU2y-QM.js";
//#region src/data/blindDateData.ts
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var BLIND_DATE_STAGES = [
	{
		key: "personal",
		stepNumber: 1,
		titleAr: "المرحلة الأولى: التوافق الشخصي والانطباع الأولي",
		badgeAr: "الانطباع الأول والكيمياء الشخصية",
		subtitleAr: "5 أسئلة متبادلة لاكتشاف الطباع، لغة المشاعر، وكيف يتصرف كل طرف في المواقف الحياتية اليومية",
		icon: "✨",
		color: "from-pink-500 to-rose-600",
		gradient: "from-pink-950/60 via-purple-950/40 to-slate-900",
		borderClass: "border-pink-500/40",
		questions: [
			{
				id: "p_1",
				stage: "personal",
				questionAr: "ما هو أول انطباع يعطيه حضورك للناس، وما هي السمة التي يكتشفونها فيك بعد الاقتراب أكثر؟",
				subtitleAr: "سؤال لاكتشاف العمق الإنساني والفرق بين المظهر الخارجي والجوهر",
				optionsAr: [
					"الهيبة والهدوء أولاً، ثم الدفء والعطاء اللامحدود لمن يحبني.",
					"المرح والابتسامة الساحرة أولاً، ثم العقلانية والوفاء العميق.",
					"الرزانة والاستماع الذكي، ثم الشغف الكبير والتفكير الإيجابي.",
					"البساطة والتواضع الشديد، ثم القيادة والشخصية الواثقة."
				],
				partnerPresetAnswer: "كثير من الناس في البداية يظنون أنني شخص هادئ جداً أو متحفظ بعض الشيء، لكن عندما يتعرفون عليّ أكثر، يكتشفون قلباً مخلصاً، حساً فكاهياً دافئاً، وحباً حقيقياً لرؤية من حولي سعداء ومرتاحين.",
				partnerQuestionToUser: "وأنت.. عندما يمر يومك بضغوطات وتعب، ما الذي تحتاجه بالضبط من شريك حياتك ليشعر قلبك بالأمان؟",
				userSuggestedAnswers: [
					"أن يفهمني من نظرة عيني دون عتاب، ويكون حضناً هادئاً يسمعني دون إصدار أحكام.",
					"أن يشاركني جلسة شاي أو قهوة دافئة بحديث لطيف ينسيني كل تعب النهار.",
					"أن يترك لي مساحة هدوء قصيرة ثم يفاجئني بكلمة حب أو تشجيع صادقة.",
					"أن يقول لي بكل ثقة: «أنا معك وفي ظهرك، وكل شيء سيمر بأفضل ما يكون»."
				]
			},
			{
				id: "p_2",
				stage: "personal",
				questionAr: "كيف تعبر عن غضبك أو عتابك عندما تتضايق من تصرف صدر من شريكك؟",
				subtitleAr: "سؤال لمعرفة إدارة الخلافات والنضج الانفعالي",
				optionsAr: [
					"أفضل النقاش الفوري بهدوء واحترام قبل أن ينتهي اليوم.",
					"أصمت قليلاً حتى تهدأ مشاعري، ثم أفتح الحوار باختيار الكلمات الرقيقة.",
					"أعبر بنظرة أو عتاب لطيف غير جارح؛ لأني لا أتحمل الخصام أو الجفاء.",
					"أكتب ما يضايقني بصراحة ووضوح مع التأكيد على حبي ومكانته في قلبي."
				],
				partnerPresetAnswer: "أنا أؤمن أن العتاب صابون القلوب؛ لذلك لا أحب تراكم الزعل أبداً. عندما أتضايق، آخذ دقائق لتهدأ مشاعري، ثم أتحاور بصوت منخفض وصراحة راقية دون جرح أو تقليل، لأن كرامة الشريك من كرامتي.",
				partnerQuestionToUser: "ما هو الخط الأحمر الوحيد في التعامل الشخصي الذي إن تجاوزه الطرف الآخر تفقد الثقة فيه؟",
				userSuggestedAnswers: [
					"الكذب والخداع وإخفاء الأمور الجوهرية عني مهما كانت الأسباب.",
					"التقليل من الاحترام أمام الآخرين أو جرح الكرامة عند الغضب.",
					"الاستهزاء بمشاعري أو التقليل من طموحاتي وتطلعاتي.",
					"اللامبالاة والجفاء المتعمد وترك المشاكل معلقة دون حل."
				]
			},
			{
				id: "p_3",
				stage: "personal",
				questionAr: "ما هي لغة الحب الأساسية التي تجعلك تشعر بأنك محبوب ومقدّر بصدق؟",
				subtitleAr: "استكشاف لغات الحب الخمس والتناغم الوجداني",
				optionsAr: [
					"الكلمات الطيبة وعبارات التقدير والتشجيع اليومي المستمر.",
					"تخصيص وقت نوعي مميز نكون فيه معاً بعيداً عن المشتتات.",
					"الأفعال ومساندتي ومشاركتي في تفاصيل الحياة والتخفيف عني.",
					"الاهتمام بالتفاصيل الصغيرة والمفاجآت الرمزية التي تعبر عن التفكير بي."
				],
				partnerPresetAnswer: "لغتي الأولى هي «الأفعال والاهتمام الصادق بالتفاصيل». تسعدني الكلمات الجميلة بالطبع، لكن وقفة الشريك معي في اللحظات المهمة وتذكره لما يسعدني ويضايقني هو الدليل الأقوى على مكانتي بقلبه.",
				partnerQuestionToUser: "لو طلب منك وصف روحك وشغفك في جملة واحدة مكثفة، ماذا ستقول لي؟",
				userSuggestedAnswers: [
					"«روح حالمة ومحبة للحياة، تبحث عن شريك يصنع معها كل يوم ذكرى لا تُنسى».",
					"«قلب مخلص، يعشق الاستقرار والهدوء، ويضع بيته وأحبابه فوق كل اعتبار».",
					"«عقل طموح يسعى للتطور الدائم، وشخصية دافئة لا تعرف التصنع أو القسوة».",
					"«شخص يرى الجمال في أبسط الأشياء، ويؤمن أن الصدق هو أعظم استثمار في العلاقات»."
				]
			},
			{
				id: "p_4",
				stage: "personal",
				questionAr: "ما هو الموقف الذي يجعلك تبتسم تلقائياً وتتأكد أن هذا الشخص يملك قلباً نبيلاً؟",
				subtitleAr: "استكشاف معايير النبل والرحمة",
				optionsAr: [
					"طريقة تعامله اللطيفة مع البسطاء وكبار السن في الأماكن العامة.",
					"اعتذاره السريع والنبيل عندما يشعر أنه أخطأ دون كبرياء.",
					"برّه بوالديه وحرصه الصادق على صلة أهله والاهتمام بهم.",
					"دعمه لشريكه في أوقات ضعفه دون أن يُشعره بأي منّة أو فضل."
				],
				partnerPresetAnswer: "أكبر علامة على نبل القلب بالنسبة لي هي الرحمة التلقائية بالضعفاء، والقدرة على الاعتذار النبيل عند الخطأ. الشخص الذي يعتذر برقي هو إنسان كبير القلب وواثق من نفسه.",
				partnerQuestionToUser: "هل تؤمن بالحب من النظرة الأولى أو بالحوار الفكري والتوافق الروحي التدريجي؟",
				userSuggestedAnswers: [
					"الحوار الروحي والفكري التدريجي هو الأبقى والأرسخ بلا شك.",
					"الانجذاب الأولي شرارة مهمة، لكن الحديث العميق هو ما يحول الشرارة إلى نور دائم.",
					"التوافق القلبي يبدأ من أول دقيقة إذا التقت الأرواح وتشابهت القيم.",
					"أؤمن بالكيمياء العفوية التي تكتمل وتتجذر بالاحترام المتبادل والمواقف."
				]
			},
			{
				id: "p_5",
				stage: "personal",
				questionAr: "لو اخترنا قضاء عطلة نهاية الأسبوع سوياً، ما هو النشاط الذي يمنحك أقصى درجات السعادة؟",
				subtitleAr: "استكشاف التناغم الترفيهي والإيقاع الشخصي",
				optionsAr: [
					"جلسة هادئة في مكان جميل في الطبيعة أو البحر مع حديث ممتع.",
					"تجربة مطعم مميز، ثم مشاهدة فيلم ومناقشة أفكاره بشغف.",
					"رحلة استكشافية سريعة لمدينة جديدة والتقاط صور جميلة معاً.",
					"البقاء في البيت وطبخ وجبة شهية سوياً في أجواء دافئة وعائلية."
				],
				partnerPresetAnswer: "أجمل نهاية أسبوع بالنسبة لي هي البساطة: جلسة هادئة وقت الغروب في مكان مفتوح، ومعنا قهوة لذيذة، نتحدث بكل أريحية عن كل شيء ولا شيء، ونشعر أن الوقت يمر كالنسيم من شدة الانسجام.",
				partnerQuestionToUser: "بعد هذه الأسئلة الشخصية الخمسة، ما هو شعورك الأولي تجاه التوافق بيننا حتى الآن؟",
				userSuggestedAnswers: [
					"أشعر بارتياح نفسي غير عادي وتناغم عفوي في طريقة التفكير والطباع.",
					"الإجابات أظهرت نضجاً واحتراماً رفيعاً، وحماسي كبير للانتقال للمرحلة التالية!",
					"كيمياء واعدة جداً، وأشعر أن وراء هذا الستار شخصاً استثنائياً وراقياً.",
					"إجابات مطمئنة تدل على قيم نبيلة نبحث عنها جميعاً في شريك العمر."
				]
			}
		]
	},
	{
		key: "social",
		stepNumber: 2,
		titleAr: "المرحلة الثانية: الأسئلة الاجتماعية ونمط الحياة",
		badgeAr: "التوافق العائلي والاجتماعي",
		subtitleAr: "5 أسئلة متبادلة حول العلاقة مع الأهل، صيانة استقلالية البيت، توزيع الأدوار، والعادات الاجتماعية",
		icon: "🏡",
		color: "from-amber-500 to-orange-600",
		gradient: "from-amber-950/60 via-purple-950/40 to-slate-900",
		borderClass: "border-amber-500/40",
		questions: [
			{
				id: "s_1",
				stage: "social",
				questionAr: "ما هي حدود خصوصية البيت الزوجي في نظرك، وكيف تدير علاقتك مع العائلة والأصدقاء؟",
				subtitleAr: "صيانة خصوصية واستقلالية بيت الزوجية",
				optionsAr: [
					"أسرار البيت خط أحمر مطلق لا يعلمها أحد، مع بر عظيم بالأهل وإكرامهم.",
					"المشاورات الودية مع الأهل مقبولة، لكن القرار النهائي دائماً بيننا وحدنا.",
					"احترام كبير لعادات العائلتين مع حماية مساحتنا الخاصة بالكامل.",
					"علاقة مودة أسرية مفتوحة مع وضع حدود واضحة وصارمة لأي تدخل في خلافاتنا."
				],
				partnerPresetAnswer: "البيت الزوجي بالنسبة لي مملكة مقدسة لها حرمتها وخصوصيتها؛ خلافاتنا وأسرارنا تحل بين جدران بيتنا بالحب والتفاهم، بينما علاقتنا بأهلي وأهلك تكون مبنية على البر، التقدير، الكرم، والفرح المشترك.",
				partnerQuestionToUser: "كيف ترى المناسبات العائلية والواجبات الاجتماعية الأسبوعية؟ هل تفضل الحضور المكثف أم التوازن والاعتدال؟",
				userSuggestedAnswers: [
					"التوازن والاعتدال؛ نؤدي الواجبات الاجتماعية بأناقة ونحافظ على وقتنا الخاص.",
					"أحب الدفء العائلي والتجمعات الأسبوعية؛ العائلة هي السند الأساسي.",
					"نحضر المناسبات المهمة بكل محبة، مع احترام رغبة الشريك إذا كان مرهقاً.",
					"أفضل أن نتفق سوياً كل أسبوع حسب ظروفنا وطاقتنا دون ضغوط أو التزامات مرهقة."
				]
			},
			{
				id: "s_2",
				stage: "social",
				questionAr: "كيف تنظر إلى توزيع المسؤوليات اليومية وإدارة شؤون المنزل بين الزوجين؟",
				subtitleAr: "التشارك والتعاون في إدارة الحياة اليومية",
				optionsAr: [
					"الشراكة الكاملة؛ كل منا يسند الآخر في الطبخ والتنظيم والترتيب بكل حب.",
					"توزيع مرن للأدوار حسب وقت وطاقة كل طرف دون التزام بقوالب جامدة.",
					"المسؤوليات تُدار بالتقدير والمبادرة التلقائية دون الحاجة لطلب أو لوم.",
					"الأهم هو روح التعاون؛ إذا تعب أحدنا وجد الآخر سداً وسنداً له فوراً."
				],
				partnerPresetAnswer: "الحياة الزوجية فريق عمل بروح واحدة؛ لا توجد مهمة «حكر» على طرف. عندما يحتاج البيت تنظيماً أو تحضير وجبة، تسعدني المشاركة بيد واحدة وبضحكة تخفف التعب، فالأنس في المشاركة وليس في التكليف.",
				partnerQuestionToUser: "لو صادفت اختلافاً في العادات أو التقاليد بين بيئتي وبيئتك، كيف سنتعامل معه برأيك؟",
				userSuggestedAnswers: [
					"بالاحترام المتبادل؛ نأخذ أجمل ما في البيئتين ونؤسس ثقافة فريدة خاصة ببيتنا.",
					"التقاليد وسيلة للتقارب وليست قيداً، والأولوية دائماً لما يرضينا ويناسب ديننا وقيمنا.",
					"المرونة والتفهم الذكي، والنظر إلى الاختلاف كمصدر إثراء وتنوع ممتع.",
					"نضع راحتنا وتوافقنا أولاً، مع احترام كبار السن وعاداتهم بأسلوب دبلوماسي راقٍ."
				]
			},
			{
				id: "s_3",
				stage: "social",
				questionAr: "ما هو أسلوبك في التعامل مع وسائل التواصل الاجتماعي ومشاركة تفاصيل الحياة الخاصة؟",
				subtitleAr: "ثقافة الخصوصية الرقمية والمظهر الاجتماعي",
				optionsAr: [
					"أفضل الخصوصية التامة والابتعاد عن نشر لحظاتنا الحميمية للعامة.",
					"مشاركة معتدلة ولطيفة للذكريات الجميلة دون كشف خصوصيات البيت.",
					"حرية شخصية واعية لكل طرف مع الاتفاق المسبق على عدم نشر ما يخص الآخر دون إذنه.",
					"حياتنا الحقيقية هي التي نعيشها معاً، والواقع أجمل بكثير من شاشات الهواتف."
				],
				partnerPresetAnswer: "أميل بقوة لحفظ النعمة والخصوصية؛ اللحظات الدافئة والسعيدة بيننا هي كنزنا الخاص، واستمتع بعيشها في الواقع بكل جوارحي بدلاً من الانشغال بتصويرها لعالم افتراضي.",
				partnerQuestionToUser: "كيف تحب أن نقضي إجازاتنا السنوية؟ هل بالسفر والمغامرات أم بالاسترخاء وزيارة الأهل؟",
				userSuggestedAnswers: [
					"مزيج رائع: سفرة رومانسية خاصة بنا كل عام، مع وقت ممتع لزيارة الأهل.",
					"أعشق استكشاف بلدان وثقافات جديدة وخوض مغامرات تظل في الذاكرة.",
					"أفضل الطبيعة الهادئة والاسترخاء التام وتجديد الطاقة في أجواء راقية.",
					"أي مكان نكون فيه سوياً بقلوب صافية هو الإجازة الأجمل والأكثر بهجة."
				]
			},
			{
				id: "s_4",
				stage: "social",
				questionAr: "عندما تدعو أصدقاءك أو ضيوفك لزيارتنا، كيف تتخيل أجواء الضيافة والاستقبال في بيتنا؟",
				subtitleAr: "الكرم وحسن الاستقبال والتنسيق المتبادل",
				optionsAr: [
					"كرم وترحيب أصيل يعكس كرم أخلاقنا، مع التنسيق المسبق مع الشريك بوقت كافٍ.",
					"أجواء دافئة مريحة خالية من التكلف والمظاهر المرهقة.",
					"بيتنا مفتوح للخير والأحباب، مع الحرص التام على عدم إرهاق الشريك في التحضير.",
					"نظام واضح ومواعيد محددة تحافظ على راحة وطمأنينة أهل البيت."
				],
				partnerPresetAnswer: "الكرم طبع أصيل، وإكرام الضيف من شيم الكرام، لكن سر الضيافة الناجحة هو التنسيق المسبق والتعاون بيننا حتى يكون الاستقبال بهجة للجميع دون أن يشعر أي طرف بالإرهاق أو العبء.",
				partnerQuestionToUser: "ما هو أكثر طقس اجتماعي تتمنى أن نورثه لأبنائنا في المستقبل بإذن الله؟",
				userSuggestedAnswers: [
					"جلسة العشاء اليومية بدون هواتف، حيث نتحدث ونسمع يوميات بعضنا بكل حب.",
					"صلة الرحم والبر بالجد والجدة وتوقير كبار السن وحسن الخلق.",
					"عادة القراءة ومناقشة كتاب كل شهر والاهتمام بالثقافة النافعة.",
					"التطوع والصدقة المشتركة وإحساس العائلة بالضعفاء والمحتاجين."
				]
			},
			{
				id: "s_5",
				stage: "social",
				questionAr: "ما هو تقييمك لمدى توافقنا الاجتماعي ونمط المعيشة بعد هذه الجولة؟",
				subtitleAr: "التثبت من التوافق الحياتي والاجتماعي قبل العبور",
				optionsAr: [
					"تناغم متين وملحوظ؛ أفكارنا متطابقة حول حدود البيت وبر الأهل.",
					"تناغم راقٍ جداً، ولدينا نفس النضج في إدارة الواجبات والخصوصية.",
					"إجابات تدل على خلفية أسرية محترمة وأصيلة، وهذا يبعث على راحة بال بالغة.",
					"أنا متأكد أننا قادرون على بناء أسرة متزنة ومحترمة يفخر بها الجميع."
				],
				partnerPresetAnswer: "أشعر بارتياح عظيم؛ فكرك متزن ويجمع بين الأصالة والعصرية. عندما يكون التقدير هو الأساس، تصبح إدارة أي تفصيل اجتماعي متعة مشتركة تقرب بيننا أكثر.",
				partnerQuestionToUser: "هل أنت مستعد لننتقل معاً للمرحلة الثالثة لاستكشاف التوافق العلمي والفكري؟",
				userSuggestedAnswers: [
					"بكل تأكيد وحماس! التوافق العلمي والفكري هو الركيزة التي أنتظر مناقشتها معك.",
					"مستعد تماماً، وأتوقع أن تكون هذه المرحلة الأكثر إثارة وعمقاً بيننا.",
					"نعم، أنا فخور بما وصلنا إليه ومتحمس لسماع أفكارك في الجولة العلمية.",
					"أنا جاهز ومتحمس؛ الحوار معك ممتع ويثري العقل والروح معاً."
				]
			}
		]
	},
	{
		key: "academic",
		stepNumber: 3,
		titleAr: "المرحلة الثالثة: التوافق العلمي والمستوى الدراسي والفكري",
		badgeAr: "التناغم الفكري والثقافي",
		subtitleAr: "5 أسئلة متبادلة حول الطموح التعليمي، أسلوب النقاش العقلاني، القراءة، والاهتمام بالمعرفة والتطوير",
		icon: "🎓",
		color: "from-blue-500 to-indigo-600",
		gradient: "from-blue-950/60 via-purple-950/40 to-slate-900",
		borderClass: "border-blue-500/40",
		questions: [
			{
				id: "a_1",
				stage: "academic",
				questionAr: "ما هي أهمية المستوى الدراسي والفكري في شريك حياتك، وكيف يؤثر ذلك على حواراتكما اليومية؟",
				subtitleAr: "التقارب الذهني وأهمية الحوار المتبادل",
				optionsAr: [
					"الشهادة وسيلة، لكن الأهم هو الوعي الفكري والقدرة على خوض نقاش عميق وممتع.",
					"أبحث عن شريك طموح أكاديمياً ويحب التعلم المستمر ولا يتوقف عند مرحلة معينة.",
					"التوافق الفكري ضروري جداً لتربية الأبناء وصنع القرارات المصيرية بحكمة.",
					"الأهم هو الذكاء العاطفي والحكمة في إدارة شؤون الحياة والمواقف الصعبة."
				],
				partnerPresetAnswer: "المستوى التعليمي جميل ومهم، لكن الأهم في نظري هو «العقلية المنفتحة والوعي». أحب أن يكون بيننا حديث شيق عن مشاريعنا، قراءاتنا، وتطلعاتنا، وألا تكون محادثاتنا سطحية أو مقتصرة على الروتين فقط.",
				partnerQuestionToUser: "عندما نختلف في وجهات النظر حول قضية فكرية أو قرار مهم، كيف تفضل أن نحسم الموضوع؟",
				userSuggestedAnswers: [
					"بالحجة والمنطق الهادئ والاستماع لرأي الآخر حتى النهاية مع تقبل الرأي المعاكس.",
					"البحث عن حل وسط ذكي يحقق مصلحة الطرفين دون أن يشعر أحدنا بالهزيمة.",
					"استشارة أهل الاختصاص أو كتاب موثوق إذا كان الموضوع تقنياً أو علمياً.",
					"الأخذ بالرأي الأكثر حكمة وسلامة للأسرة، بغض النظر عمن هو صاحب الفكرة."
				]
			},
			{
				id: "a_2",
				stage: "academic",
				questionAr: "هل تسعى لتطوير ذاتك أكاديمياً أو مهنياً عبر دورات أو دراسات عليا، وما هو موقفك من طموح شريكك؟",
				subtitleAr: "الدعم المتبادل للمسيرة الأكاديمية والمهنية",
				optionsAr: [
					"أنا الداعم الأول لطموح شريكي؛ نجاحه فخر لي وسأوفر له كل السبل للإنجاز.",
					"أسعى دائماً للتطوير المستمر وأتمنى أن نتشارك الشغف ذاته ونشجع بعضنا دوماً.",
					"التطوير رائع بشرط الحفاظ على التوازن السليم بين التعليم والبيت والراحة.",
					"أؤمن أن التعلم رحلة مدى الحياة، وفرحتي بحصول شريكي على إنجاز تعادل فرحتي بنفسي."
				],
				partnerPresetAnswer: "أكبر هدية يقدمها الشريك لشريكه هي أن يكون مشجعاً حقيقياً لطموحاته. لو رغبت في إكمال دراسات عليا أو تعلم مهارة متقدمة، ستجدني أشد على يدك وأفتخر بكل خطوة تخطوها نحو القمة.",
				partnerQuestionToUser: "ما هي المجالات أو المواضيع التي يثير شغفك القراءة فيها أو متابعة برامجها الوثائقية؟",
				userSuggestedAnswers: [
					"تطوير الذات، علم النفس، وفهم السلوك الإنساني والعلاقات الناجحة.",
					"التكنولوجيا، الابتكار، والذكاء الاصطناعي ومستقبل العالم الرقمي.",
					"التاريخ، الحضارات الإنسانية، وأسرار الفلسفة والفكر.",
					"ريادة الأعمال، الاستثمار، وبناء المشاريع الناجحة والاستقلال المالي."
				]
			},
			{
				id: "a_3",
				stage: "academic",
				questionAr: "كيف تصف طريقتك في اتخاذ القرارات المصيرية: هل هي عقلانية تحليلية بحتة أم قائمة على الحدس والقلب؟",
				subtitleAr: "آليات اتخاذ القرار والتفكير الاستراتيجي",
				optionsAr: [
					"مزيج متوازن: أدرس المعطيات والبدائل بعقلانية، ثم استخير واستفتي قلبي.",
					"تحليلية ومنطقية؛ أضع الإيجابيات والسلبيات وأستشير الخبراء قبل الإقدام.",
					"حدسية ذكية؛ إحساسي الداخلي بعد التوكل على الله نادراً ما يخطئ.",
					"تشاركية بحتة؛ لا أحسم قراراً مصيرياً إلا بعد أن أسمع رؤية شريكي بعناية."
				],
				partnerPresetAnswer: "أنا شخص يجمع بين «المنطق التحليلي والاستخارة القلبية». أجمع المعلومات وأدرس الخيارات بعقلانية، لكن القرار النهائي دائماً يتوج بجلسة مصارحة معك لنزن الأمر سوياً ونتخذه بيد واحدة.",
				partnerQuestionToUser: "لو عُرضت عليك فرصة دراسية أو مهنية استثنائية في مدينة أو دولة أخرى، كيف سنتخذ القرار سوياً؟",
				userSuggestedAnswers: [
					"ندرس تأثيرها على استقرار بيتنا ومشاعرنا أولاً؛ إذا كانت خيراً لنا سافرنا معاً كفريق.",
					"نضع مستقبلك ومستقبلي في كفة واحدة، ونتخذ القرار الذي يحقق أكبر نمو لنا كزوجين.",
					"الأولوية دائماً لسعادتنا الزوجية، ولن نقبل بفرصة تفرق بيننا أو ترهق أسرنا.",
					"نناقشها بصراحة تامة ونستعد للتضحية المتبادلة بروح حب وشراكة متينة."
				]
			},
			{
				id: "a_4",
				stage: "academic",
				questionAr: "ما هو الكتاب أو الدورة أو التجربة الفكرية التي غيرت طريقة نظرتك للحياة مؤخراً؟",
				subtitleAr: "عمق التأمل والوعي بالمتغيرات",
				optionsAr: [
					"كتاب في الذكاء العاطفي وتفهم مشاعر النفس والآخرين بعمق.",
					"تجربة عملية علمتني أن الصبر والتخطيط الاستراتيجي يصنعان المعجزات.",
					"دورة في إدارة الوقت والأولويات والتركيز على ما يترك أثراً حقيقياً.",
					"قراءات في السيرة النبوية والحكمة الإنسانية التي تمنح سكينة وثباتاً داخلياً."
				],
				partnerPresetAnswer: "أكثر ما أحدث تحولاً في تفكيري هو إدراكي أن «الاستماع الفعّال أهم من الكلام الذكي». عندما نتعلم كيف نسمع الطرف الآخر بعقولنا وقلوبنا معاً، تُحل نصف مشاكل الحياة قبل أن تبدأ.",
				partnerQuestionToUser: "كيف ترى مستوى النقاش الفكري بيننا في هذه الجولة؟ هل تجده محفزاً ومريحاً لعقلك؟",
				userSuggestedAnswers: [
					"محفز جداً؛ أشعر أنني أتحدث مع عقلية ناضجة تحترم الكلمة وتفهم ما وراءها.",
					"إجاباتك تدل على ثقافة عالية ورزانة قلّ أن يجدها المرء هذه الأيام.",
					"هناك تناغم ذهني نادر، وكأن أفكارنا تتقاطع في أهم المبادئ المعرفية.",
					"استمتعت بكل سؤال، وهذا يؤكد لي أن الحوار بيننا في المستقبل لن يمله طرف أبداً."
				]
			},
			{
				id: "a_5",
				stage: "academic",
				questionAr: "هل توافق على تقييم هذه المرحلة كعلامة نجاح فكري كامل والانتقال لمرحلة الطموحات والأحلام؟",
				subtitleAr: "التصويت للعبور إلى المرحلة الرابعة",
				optionsAr: [
					"نعم بكل ثقة وتأكيد؛ التوافق الفكري بيننا استثنائي ومثبت بالأدلة.",
					"موافق تماماً؛ وننتقل للمرحلة الرابعة لنرسم خطط المستقبل سوياً.",
					"بالتأكيد؛ العقل يلتقي بالعقل، وأتطلع لرؤية كيف ستلتقي الأحلام بالأحلام.",
					"أمنح هذه المرحلة علامة كاملة، ومستعد للانطلاق للمرحلة القادمة فوراً."
				],
				partnerPresetAnswer: "بكل سرور وفخر! النقاش الفكري أثبت لي أن وراء هذا الستار عقلية راقية، متوازنة، وتملك بعد نظر حقيقي. أنا متحمس جداً لجولة الطموحات والأحلام الكبرى!",
				partnerQuestionToUser: "هل ننتقل سوياً إلى المرحلة الرابعة: مرحلة الطموحات والأحلام لبناء المستقبل؟",
				userSuggestedAnswers: [
					"نعم، لننطلق سوياً نحو مرحلة الأحلام والطموحات الكبرى! 🚀",
					"مستعد بكل شغف، فلنرسم رؤيتنا المشتركة للمستقبل.",
					"انتقال مؤكد وناجح، أراك في المرحلة الرابعة بحماس!",
					"جاهز لفتح صندوق الأحلام والتطلعات معك."
				]
			}
		]
	},
	{
		key: "ambitions",
		stepNumber: 4,
		titleAr: "المرحلة الرابعة: مرحلة الطموحات والأحلام والمستقبل",
		badgeAr: "رؤية المستقبل والأحلام المشتركة",
		subtitleAr: "5 أسئلة متبادلة حول خطط السنوات الخمس القادمة، الاستقرار المالي، تكوين الأسرة، وأكبر أهداف العمر",
		icon: "🚀",
		color: "from-violet-500 to-purple-700",
		gradient: "from-violet-950/60 via-purple-950/40 to-slate-900",
		borderClass: "border-violet-500/40",
		questions: [
			{
				id: "am_1",
				stage: "ambitions",
				questionAr: "أين ترى نفسك وحياتنا بعد 5 سنوات من الآن؟ ما هو المشهد الذي تتمناه في مخيلتك؟",
				subtitleAr: "رسم الرؤية المستقبلية للحياة الزوجية",
				optionsAr: [
					"في بيت دافئ جميل نملكه، يملؤه الضحك والاستقرار والأمان المالي والأبناء.",
					"حققنا قفزة نوعية في مسيرتنا المهنية، مع رحلات سنوية ملهمة وتوازن أسري تام.",
					"نؤسس مشروعاً عائلياً خاصاً يضمن استقلالنا المالي ويوفر لنا متسعاً من الحرية.",
					"حياة مستقرة وهادئة، ونعيش في قمة التفاهم والرضا ونكون قدوة لكل من حولنا."
				],
				partnerPresetAnswer: "أتخيلنا في بيت هادئ ومريح نصممه بذوقنا المشترك، نجلس في شرفته مساءً نتحدث عن إنجازاتنا بفخر، ولدينا استقرار مالي ونفسي متين، وأهم من ذلك كله: أن يكون الحب والاحترام بيننا قد تضاعف وزاد رسوخاً.",
				partnerQuestionToUser: "ما هي فلسفتك في إدارة المال والميزانية: هل تميل للادخار والاستثمار أم للاستمتاع بالحاضر والسفر؟",
				userSuggestedAnswers: [
					"التوازن الذكي: جزء للادخار والاستثمار للأمان المستقبلي، وجزء نعيش به ونسعد أنفسنا بالسفر.",
					"الاستثمار الذكي وتأسيس أصول تضمن راحة الأسرة، مع عدم حرمان أنفسنا من الطيبات.",
					"ميزانية شهرية واضحة نتفق عليها مع صندوق خاص بالطوارئ وصندوق آخر للرحلات والترفيه.",
					"المال وسيلة لإسعاد بيتنا وشريكنا، وأنا كريم بطبعي مع حكمة وتدبير دون إسراف."
				]
			},
			{
				id: "am_2",
				stage: "ambitions",
				questionAr: "ما هي رؤيتك لتربية الأبناء وما هي القيم الأساسية الثلاث التي تحرص على غرسها فيهم؟",
				subtitleAr: "فلسفة الأبوة والأمومة وغرس القيم",
				optionsAr: [
					"مخافة الله والصدق، الثقة العالية بالنفس، وبر الوالدين وحب مساعدة الناس.",
					"الشجاعة الأدبية، الطموح العلمي والمعرفي، والرحمة والإحساس بالآخرين.",
					"الاستقلالية وتحمل المسؤولية، الحوار الصريح، والاعتزاز بهويتهم وأخلاقهم.",
					"أن يربوا في بيئة آمنة يرون فيها الحب والاحترام بين والديهم كأعظم نموذج حي."
				],
				partnerPresetAnswer: "أهم ما يمكن أن نقدمه لأبنائنا هو أن يشهدوا حباً حقيقياً واحتراماً متبادلاً بيننا في كل يوم. القيم الثلاث الأساسية عندي هي: الصدق التام، الثقة والشجاعة، والرحمة بكل من حولهم.",
				partnerQuestionToUser: "ما هو حلمك الشخصي الأكبر الذي ترغب أن يدعمك شريك حياتك لتحقيقه في هذه الحياة؟",
				userSuggestedAnswers: [
					"تأسيس عمل خاص أو مشروع إنساني يترك بصمة مضيئة وأثراً مستداماً في المجتمع.",
					"أن أصل إلى قمة النجاح في مجالي التخصصي وأكون مرجعاً مرموقاً فيه.",
					"بناء بيت عائلي مثالي ينعم بالسكينة، وأن أؤدي مناسك الحج والعمرة مع شريكي يداً بيد.",
					"أن أعيش حياة متوازنة، حرة، مليئة بالحب والسلام وراحة البال الدائمة."
				]
			},
			{
				id: "am_3",
				stage: "ambitions",
				questionAr: "لو واجهنا ظرفاً مالياً أو تحدياً صعباً في بداية طريقنا، كيف سنتجاوزه معاً برأيك؟",
				subtitleAr: "الصمود في وجه التحديات ووفاء العهد",
				optionsAr: [
					"بالصبر والوفاء والتكاتف؛ الشدة لا تزيدنا إلا تمسكاً وتقارباً ولن نتخلى عن بعضنا أبداً.",
					"بإعادة ترتيب الأولويات والتقشف الذكي مع العمل المشترك لتجاوز الأزمة سريعاً.",
					"باليقين أن الرزق بيد الله، وأن البيوت تُبنى على الصبر والمروءة والتوكل.",
					"بابتسامة ورضا وقول: «المال يأتي ويذهب، لكن بقاءك بجانبي هو الثروة الحقيقية»."
				],
				partnerPresetAnswer: "في الشدائد تُعرف معادن البشر؛ إن جاء الرخاء حمدنا الله وتشاركنا النعمة، وإن جاءت الشدة كنت لك السند الذي لا ينحني، ولن تسمع مني إلا كل دعم ورضا حتى تنجلي الغمة ونعود أقوى من ذي قبل.",
				partnerQuestionToUser: "ما هو المكان أو الوجهة التي تحلم أن نسافر إليها معاً في أول رحلة احتفالية لنا؟",
				userSuggestedAnswers: [
					"رحلة روحانية إلى مكة المكرمة والمدينة المنورة للشكر والبدء ببركة الله.",
					"جزر المالديف أو سويسرا للاستمتاع بالطبيعة الخلابة والأجواء الرومانسية الهادئة.",
					"جولة في عواصم العالم القديم واستكشاف التاريخ والجمال المعماري.",
					"أي مكان هادئ على شاطئ البحر يجمعنا سوياً بصفاء تام وسعادة غامرة."
				]
			},
			{
				id: "am_4",
				stage: "ambitions",
				questionAr: "كيف تود أن يُلهم بيتنا وحياتنا الأسرية كل من يعرفنا من أصدقاء وأقارب؟",
				subtitleAr: "الأثر والقدوة المجتمعية الطيبة",
				optionsAr: [
					"أن نكون نموذجاً للبيت الزوجي السعيد القائم على المودة والرحمة والرقي.",
					"أن يشعر كل من يدخل بيتنا بالسكينة والدفء والكرم وحسن المعشر.",
					"أن يضرب بنا المثل في التفاهم والمساندة المتبادلة والنجاح المشترك.",
					"أن يرى الناس فينا دليلاً حياً على أن الحب الحقيقي الصادق موجود ويمكن أن يستمر للأبد."
				],
				partnerPresetAnswer: "أتمنى أن يكون بيتنا واحة سكينة ونموذجاً حياً للمودة والرحمة التي أمرنا بها الله؛ بيتاً إذا رآه الناس قالوا: «ما شاء الله، هكذا تبنى البيوت المباركة وهكذا تكون السعادة الزوجية».",
				partnerQuestionToUser: "بعد انتهاء مراحل الأسئلة الأربع كاملة، هل شعرت أن هذا التوافق حقيقي وتود إكمال الموعد حتى النهاية؟",
				userSuggestedAnswers: [
					"أشعر بيقين تام وتوافق نادر فاق كل توقعاتي؛ أنا فخور ومبهور بكل كلمة سمعتها.",
					"التوافق بيننا وصل لأعلى مستوياته، وأنتظر اللحظة الحاسمة وإسقاط الستار!",
					"إجاباتك عكست شخصية نادرة أبحث عنها طوال حياتي، وأنا متمسك بهذا اللقاء.",
					"انسجام روحي وفكري كامل؛ هذا الموعد غير نظرتي تماماً نحو التوافق الحقيقي."
				]
			},
			{
				id: "am_5",
				stage: "ambitions",
				questionAr: "هل أنت مستعد الآن لإنهاء أسئلة الستار، والتوجه إلى مرحلة القرار النهائي المصيري لإسقاط الستار؟",
				subtitleAr: "الخطوة الأخيرة قبل لحظة الحسم التلفزيونية في The Blind Date Show",
				optionsAr: [
					"نعم، مستعد بكامل الشوق والجاهزية للحظة الحسم والقرار النهائي!",
					"جاهز تماماً؛ لنختم الجولات الأربع ونتجه لمنصة القرار النهائي.",
					"مستعد لرفع الستار وكشف الوجه وبدء المحادثة الحية المباشرة المفتوحة.",
					"بكل تأكيد وفرح، حان وقت لقاء العيون بعد أن التقت القلوب والعقول."
				],
				partnerPresetAnswer: "أنا جاهز تماماً، بل ويزداد نبض قلبي شوقاً لهذه اللحظة الاستثنائية! لقد أثبتت لي كل إجابة أنك إنسان رائع ونادر الوجود. لننتقل فوراً إلى منصة القرار النهائي وإسقاط الستار!",
				partnerQuestionToUser: "هل نتقدم معاً نحو لحظة إسقاط الستار في The Blind Date Show واتخاذ القرار الحاسم؟",
				userSuggestedAnswers: [
					"نعم! إلى منصة إسقاط الستار واللقاء النهائي الآن! 🎬💖",
					"بكل تأكيد وفرح، أنا جاهز للتصويت بنعم ورفع الستار.",
					"حان وقت الحسم واللقاء بعد أن التقت أرواحنا.",
					"لنرفع الستار ونبدأ أجمل فصل من فصول هذا الموعد الاستثنائي!"
				]
			}
		]
	}
];
//#endregion
//#region src/components/BlindDateShowModal.tsx
var import_jsx_runtime = require_jsx_runtime();
var BlindDateShowModal = ({ isOpen, onClose, profile, result }) => {
	const { isConnected, myUserId, status: liveStatus, partner: livePartner, compatibilityScore: liveCompatScore, messages: liveMessages, onlineCount, searchingCount, isRealPerson: liveIsRealPerson, privateRoomCode, roomErrorMessage, latestBlindDateEvent, startSearch, cancelSearch, sendMessage, leaveChat, sendBlindDateEvent, createPrivateRoom, joinPrivateRoom } = useLiveChat(profile);
	const [participantMode, setParticipantMode] = (0, import_react.useState)("real_person");
	const [roomCodeInput, setRoomCodeInput] = (0, import_react.useState)("");
	const [copiedCode, setCopiedCode] = (0, import_react.useState)(false);
	const [currentStageIdx, setCurrentStageIdx] = (0, import_react.useState)(0);
	const [questionTurnIdx, setQuestionTurnIdx] = (0, import_react.useState)(0);
	const [subStep, setSubStep] = (0, import_react.useState)("setup_mode");
	const [customQuestionInput, setCustomQuestionInput] = (0, import_react.useState)("");
	const [customAnswerInput, setCustomAnswerInput] = (0, import_react.useState)("");
	const [currentAnswerReceived, setCurrentAnswerReceived] = (0, import_react.useState)("");
	const [currentQuestionReceived, setCurrentQuestionReceived] = (0, import_react.useState)("");
	const [selectedUserRating, setSelectedUserRating] = (0, import_react.useState)(5);
	const [selectedReactionTag, setSelectedReactionTag] = (0, import_react.useState)("أعجبني بشدة ❤️");
	const [customFeedbackComment, setCustomFeedbackComment] = (0, import_react.useState)("");
	const [myLevelRating, setMyLevelRating] = (0, import_react.useState)(5);
	const [myLevelApproval, setMyLevelApproval] = (0, import_react.useState)(null);
	const [partnerLevelApproval, setPartnerLevelApproval] = (0, import_react.useState)(null);
	const [myFinalChoice, setMyFinalChoice] = (0, import_react.useState)(null);
	const [partnerFinalChoice, setPartnerFinalChoice] = (0, import_react.useState)(null);
	const [isCurtainDropped, setIsCurtainDropped] = (0, import_react.useState)(false);
	const [answersHistory, setAnswersHistory] = (0, import_react.useState)([]);
	const [openChatInput, setOpenChatInput] = (0, import_react.useState)("");
	const [chatMessages, setChatMessages] = (0, import_react.useState)([]);
	const [isVoiceModalOpen, setIsVoiceModalOpen] = (0, import_react.useState)(false);
	const [currentlyPlayingAudioUrl, setCurrentlyPlayingAudioUrl] = (0, import_react.useState)(null);
	const activeAudioPlayerRef = (0, import_react.useRef)(null);
	const chatEndRef = (0, import_react.useRef)(null);
	const handlePlayVoiceAudio = (url) => {
		if (!url) return;
		if (activeAudioPlayerRef.current) activeAudioPlayerRef.current.pause();
		if (currentlyPlayingAudioUrl === url) {
			setCurrentlyPlayingAudioUrl(null);
			return;
		}
		const audio = new Audio(url);
		activeAudioPlayerRef.current = audio;
		setCurrentlyPlayingAudioUrl(url);
		audio.play();
		audio.onended = () => {
			setCurrentlyPlayingAudioUrl(null);
		};
	};
	const isTargetFemale = profile?.partnerGender !== "male";
	const defaultPartnerName = result?.proposedPartnerName || (isTargetFemale ? "سارة العلي" : "فيصل الراشد");
	const partnerName = livePartner?.userName || defaultPartnerName;
	const partnerAge = livePartner?.userAge || profile?.userAge || 26;
	const partnerCountry = livePartner?.country || profile?.country || "المملكة العربية السعودية";
	const isReal = participantMode === "real_person" && (liveIsRealPerson || !!livePartner);
	const currentStage = BLIND_DATE_STAGES[currentStageIdx] || BLIND_DATE_STAGES[0];
	const currentQuestionItem = currentStage.questions[questionTurnIdx] || currentStage.questions[0];
	(0, import_react.useEffect)(() => {
		chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
	}, [chatMessages, liveMessages]);
	(0, import_react.useEffect)(() => {
		if (livePartner && subStep === "setup_mode") {
			setParticipantMode("real_person");
			setSubStep("user_ask");
			soundManager.playResultReveal();
		}
	}, [livePartner, subStep]);
	(0, import_react.useEffect)(() => {
		if (!latestBlindDateEvent) return;
		const { event, data } = latestBlindDateEvent;
		if (event === "question_asked") {
			soundManager.playTap();
			setCurrentQuestionReceived(data.question);
			setSubStep("user_answer");
		} else if (event === "answer_submitted") {
			soundManager.playTap();
			setCurrentAnswerReceived(data.answer);
			setSubStep("user_rate");
		} else if (event === "rating_submitted") {
			soundManager.playTap();
			setAnswersHistory((prev) => {
				const copy = [...prev];
				const last = copy[copy.length - 1];
				if (last) {
					last.partnerRatingForUser = data.stars;
					last.partnerReactionComment = data.tag;
				}
				return copy;
			});
			if (questionTurnIdx < 4) {
				setQuestionTurnIdx((prev) => prev + 1);
				setSubStep("user_ask");
			} else {
				setSubStep("stage_evaluation");
				soundManager.playRoundPass();
			}
		} else if (event === "stage_evaluated") setPartnerLevelApproval(data.approved);
		else if (event === "final_decision_submitted") setPartnerFinalChoice(data.choice);
		else if (event === "voice_note") {
			soundManager.playRoundPass();
			const record = data.voiceData;
			setChatMessages((prev) => [...prev, {
				id: `partner_voice_${Date.now()}`,
				sender: "partner",
				text: `🎙️ رسالة صوتية من ${partnerName} (${record.duration || 5}ث) • ${record.analysis?.voiceToneArchetype || "نبرة صوتية متوافقة"}`,
				time: (/* @__PURE__ */ new Date()).toLocaleTimeString("ar-SA", {
					hour: "2-digit",
					minute: "2-digit"
				}),
				voiceData: record
			}]);
		}
	}, [latestBlindDateEvent, questionTurnIdx]);
	if (!isOpen) return null;
	const handleUserAskQuestion = (qText) => {
		const question = qText.trim() || currentQuestionItem.questionAr;
		soundManager.playTap();
		setAnswersHistory((prev) => [...prev, {
			stageKey: currentStage.key,
			questionIndex: questionTurnIdx,
			userAskedQuestion: question
		}]);
		setCustomQuestionInput("");
		setSubStep("partner_answer");
		if (isReal) sendBlindDateEvent("question_asked", {
			question,
			stageKey: currentStage.key,
			questionIndex: questionTurnIdx
		});
		else setTimeout(() => {
			setCurrentAnswerReceived(currentQuestionItem.partnerPresetAnswer || "إجابة نابعة من العقل والقلب بتوازن.");
			setSubStep("user_rate");
			soundManager.playTap();
		}, 1600);
	};
	const handleUserRatePartner = (stars, tag, comment) => {
		soundManager.playTap();
		setSelectedUserRating(stars);
		setSelectedReactionTag(tag);
		setAnswersHistory((prev) => {
			const copy = [...prev];
			const last = copy[copy.length - 1];
			if (last) {
				last.userRatingForPartner = stars;
				last.userReactionComment = comment ? `${tag} (${comment})` : tag;
				last.partnerAnswer = currentAnswerReceived || currentQuestionItem.partnerPresetAnswer;
			}
			return copy;
		});
		setCustomFeedbackComment("");
		if (isReal) sendBlindDateEvent("rating_submitted", {
			stars,
			tag,
			comment
		});
		setSubStep("partner_ask");
		if (!isReal) setTimeout(() => {
			setCurrentQuestionReceived(currentQuestionItem.partnerQuestionToUser || "ما رأيك في التوافق بيننا؟");
			setSubStep("user_answer");
			soundManager.playTap();
		}, 1400);
	};
	const handleUserAnswerPartner = (ansText) => {
		const answer = ansText.trim() || customAnswerInput.trim() || currentQuestionItem.userSuggestedAnswers?.[0] || "إجابة تنبع من الاحترام المتبادل والصدق.";
		soundManager.playTap();
		setAnswersHistory((prev) => {
			const copy = [...prev];
			const last = copy[copy.length - 1];
			if (last) {
				last.partnerAskedQuestion = currentQuestionReceived || currentQuestionItem.partnerQuestionToUser;
				last.userAnswer = answer;
			}
			return copy;
		});
		setCustomAnswerInput("");
		setSubStep("partner_rate");
		if (isReal) sendBlindDateEvent("answer_submitted", { answer });
		else setTimeout(() => {
			soundManager.playTap();
			setAnswersHistory((prev) => {
				const copy = [...prev];
				const last = copy[copy.length - 1];
				if (last) {
					last.partnerRatingForUser = 5;
					last.partnerReactionComment = "إجابة ممتازة وراقية جداً! 🌟";
				}
				return copy;
			});
			if (questionTurnIdx < 4) {
				setQuestionTurnIdx((prev) => prev + 1);
				setSubStep("user_ask");
			} else {
				setSubStep("stage_evaluation");
				soundManager.playRoundPass();
			}
		}, 1800);
	};
	const handleLevelVote = (approved) => {
		soundManager.playTap();
		setMyLevelApproval(approved);
		if (isReal) sendBlindDateEvent("stage_evaluated", {
			approved,
			rating: myLevelRating
		});
		else setTimeout(() => {
			setPartnerLevelApproval(true);
		}, 1e3);
	};
	const handleAdvanceToNextLevel = () => {
		soundManager.playRoundPass();
		soundManager.playApplause();
		confetti_module_default({
			particleCount: 90,
			spread: 75,
			origin: { y: .6 },
			colors: [
				"#f43f5e",
				"#a855f7",
				"#fbbf24",
				"#10b981"
			]
		});
		setMyLevelApproval(null);
		setPartnerLevelApproval(null);
		if (currentStageIdx < 3) {
			setCurrentStageIdx((prev) => prev + 1);
			setQuestionTurnIdx(0);
			setSubStep("user_ask");
		} else {
			setSubStep("final_curtain");
			soundManager.playHeartbeat();
		}
	};
	const handleFinalDecision = (choice) => {
		soundManager.playTap();
		setMyFinalChoice(choice);
		soundManager.playHeartbeat();
		if (isReal) sendBlindDateEvent("final_decision_submitted", { choice });
		else setTimeout(() => {
			setPartnerFinalChoice(choice);
			processFinalOutcome(choice, choice);
		}, 1600);
	};
	(0, import_react.useEffect)(() => {
		if (myFinalChoice && partnerFinalChoice && subStep === "final_curtain") processFinalOutcome(myFinalChoice, partnerFinalChoice);
	}, [
		myFinalChoice,
		partnerFinalChoice,
		subStep
	]);
	const processFinalOutcome = (userC, partnerC) => {
		if (userC === "accept" && partnerC === "accept") {
			setIsCurtainDropped(true);
			soundManager.playApplause();
			soundManager.playResultReveal();
			confetti_module_default({
				particleCount: 180,
				spread: 110,
				origin: { y: .5 },
				colors: [
					"#ff1493",
					"#9400d3",
					"#ffd700",
					"#00ffff",
					"#10b981"
				]
			});
			setTimeout(() => {
				setSubStep("open_chat");
				setChatMessages([{
					id: "welcome_1",
					sender: "partner",
					text: `🎉 مبروك لنا إسقاط الستار بعد إتمام مراحل التوافق الأربع والموافقة المتبادلة! يسعدني جداً اللقاء المباشر والحديث معك بكل حرية.`,
					time: (/* @__PURE__ */ new Date()).toLocaleTimeString("ar-SA", {
						hour: "2-digit",
						minute: "2-digit"
					})
				}]);
			}, 2500);
		} else {
			setIsCurtainDropped(false);
			setSubStep("show_rejected");
		}
	};
	const handleSendOpenChat = (e) => {
		if (e) e.preventDefault();
		if (!openChatInput.trim()) return;
		const text = openChatInput.trim();
		soundManager.playTap();
		const timeStr = (/* @__PURE__ */ new Date()).toLocaleTimeString("ar-SA", {
			hour: "2-digit",
			minute: "2-digit"
		});
		const now = Date.now();
		const existing = loadSavedChatCadenceExchanges() || [];
		const userEx = {
			sender: "user",
			timestampMs: now,
			messageLengthChars: text.length,
			wordCount: text.split(/\s+/).filter(Boolean).length
		};
		saveChatCadenceExchanges([...existing, userEx]);
		setChatMessages((prev) => [...prev, {
			id: `me_${now}`,
			sender: "me",
			text,
			time: timeStr
		}]);
		setOpenChatInput("");
		if (isReal) sendMessage(text);
		else {
			const simulatedDelay = 1800 + Math.floor(Math.random() * 800);
			setTimeout(() => {
				const simulatedReplies = [
					`كلماتك راقية وتصل للقلب مباشرة؛ ما تحدثنا عنه خلف الستار أثبت لي صدقك ونقاءك. 💖`,
					`أجمل ما في هذا اللقاء هو التوافق الفكري والروحي الذي اختبرناه في كل مرحلة. ✨`,
					`أنا ممتن جداً لهذه التجربة، وأتطلع لصنع مستقبل جميل مليء بالاحترام والمودة. 🌹`
				];
				const randomReply = simulatedReplies[Math.floor(Math.random() * simulatedReplies.length)];
				const pNow = Date.now();
				const partnerEx = {
					sender: "partner",
					timestampMs: pNow,
					messageLengthChars: randomReply.length,
					wordCount: randomReply.split(/\s+/).filter(Boolean).length,
					latencyFromPreviousMs: simulatedDelay
				};
				saveChatCadenceExchanges([...loadSavedChatCadenceExchanges() || [], partnerEx]);
				soundManager.playTap();
				setChatMessages((prev) => [...prev, {
					id: `partner_${pNow}`,
					sender: "partner",
					text: randomReply,
					time: (/* @__PURE__ */ new Date()).toLocaleTimeString("ar-SA", {
						hour: "2-digit",
						minute: "2-digit"
					})
				}]);
			}, simulatedDelay);
		}
	};
	const handleSendVoiceMessage = (record) => {
		soundManager.playTap();
		const timeStr = (/* @__PURE__ */ new Date()).toLocaleTimeString("ar-SA", {
			hour: "2-digit",
			minute: "2-digit"
		});
		const synergy = record.analysis?.vocalSynergyScore || 96;
		const archetype = record.analysis?.voiceToneArchetype || "النبرة الدافئة والمطمئنة";
		const voiceMsg = {
			id: `me_voice_${Date.now()}`,
			sender: "me",
			text: `🎙️ رسالة صوتية (${record.duration}ث) • ${archetype}`,
			time: timeStr,
			voiceData: record
		};
		setChatMessages((prev) => [...prev, voiceMsg]);
		if (isReal) sendBlindDateEvent("voice_note", { voiceData: record });
		else setTimeout(() => {
			soundManager.playRoundPass();
			const partnerReplyText = record.analysis?.partnerAcousticReaction || `شعرتُ بارتياح وسكينة كبيرة عند سماع نبرة صوتك؛ فيها صدق وهدوء يجعل الحديث معك ممتعاً ومطمئناً للقلب.`;
			const partnerMsg = {
				id: `partner_voice_${Date.now()}`,
				sender: "partner",
				text: `🎙️ رد صوتي من ${partnerName}: "${partnerReplyText}"`,
				time: (/* @__PURE__ */ new Date()).toLocaleTimeString("ar-SA", {
					hour: "2-digit",
					minute: "2-digit"
				}),
				voiceData: {
					duration: 5,
					analysis: {
						voiceToneArchetype: isTargetFemale ? "النبرة العذبة الرقيقة والإشراق المطمئن" : "النبرة الرزينة الدافئة والحضور الوقور",
						vocalSynergyScore: synergy,
						emotionalTones: [
							{
								name: "الدفء والسكينة",
								score: 96,
								description: "نبرة هادئة تبعث على الأمان النفسي والارتياح الفوري للطرف الآخر"
							},
							{
								name: "الصدق والعفوية",
								score: 95,
								description: "خلو النبرة من التصنع مما يعزز الثقة العاطفية المتبادلة"
							},
							{
								name: "الرزانة والاتزان",
								score: 98,
								description: "إيقاع حوار متزن وناضج يعكس النضج الفكري والوقار"
							},
							{
								name: "الود والشغف",
								score: 93,
								description: "طاقة إيجابية لطيفة تضفي دفئاً ورونقاً على حواركما"
							}
						],
						acousticProfile: {
							pitchDescription: isTargetFemale ? "طبقة أنثوية عذبة، هادئة ومفعمة بالرقة" : "طبقة رجولية دافئة ومتزنة ومريحة للأذن",
							cadence: "إيقاع هادئ وموزون يمنح كل كلمة حقها من التعبير",
							resonance: "رنين عاطفي إيجابي يخلق انطباعاً مهدئاً وجذاباً"
						},
						vocalCompatibilityReport: `تتميز نبرة صوتك بانسجام استثنائي مع شخصية (${partnerName})؛ حيث يجمع الصوت بين الهدوء المريح والوضوح الصادق، مما يمنح الشريك شعوراً فورياً بالأمان النفسي والرغبة في الاستماع دون تردد. هذا التردد الصوتي المتزن يكمل طبقة وطبيعة (${partnerName})، ويبشر بمحادثات مستقبلية يسودها التفاهم والتناغم التام.`,
						communicationTip: "استمرا في هذا الأسلوب الحواري الهادئ، فالتوافق الصوتي يعزز التفاهم السريع وبناء الثقة.",
						partnerAcousticReaction: partnerReplyText
					}
				}
			};
			setChatMessages((prev) => [...prev, partnerMsg]);
		}, 2200);
	};
	const handleCopyCode = () => {
		if (privateRoomCode) {
			soundManager.playTap();
			navigator.clipboard.writeText(privateRoomCode);
			setCopiedCode(true);
			setTimeout(() => setCopiedCode(false), 2500);
		}
	};
	const allRatings = [];
	answersHistory.forEach((rec) => {
		if (rec.userRatingForPartner) allRatings.push(rec.userRatingForPartner);
		if (rec.partnerRatingForUser) allRatings.push(rec.partnerRatingForUser);
	});
	const averageStars = allRatings.length > 0 ? (allRatings.reduce((acc, curr) => acc + curr, 0) / allRatings.length).toFixed(1) : "5.0";
	const compatibilityPercent = allRatings.length > 0 ? Math.min(100, Math.round(Number(averageStars) / 5 * 100)) : 100;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/90 backdrop-blur-xl overflow-hidden",
		dir: "rtl",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: {
				opacity: 0,
				scale: .94,
				y: 20
			},
			animate: {
				opacity: 1,
				scale: 1,
				y: 0
			},
			exit: {
				opacity: 0,
				scale: .94,
				y: 20
			},
			className: "w-full max-w-4xl h-[92vh] max-h-[880px] bg-slate-950 border border-rose-500/30 rounded-3xl overflow-hidden shadow-2xl flex flex-col relative",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-3 sm:p-4 bg-gradient-to-r from-purple-950 via-slate-900 to-rose-950 border-b border-white/10 flex items-center justify-between shrink-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-11 h-11 rounded-2xl bg-gradient-to-tr from-rose-500 via-pink-600 to-purple-600 flex items-center justify-center text-white text-xl shadow-lg shadow-rose-500/25",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "w-6 h-6 text-white" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -top-1 -right-1 w-3 h-3 bg-rose-500 rounded-full animate-ping" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -top-1 -right-1 w-3 h-3 bg-rose-500 rounded-full border-2 border-slate-950" })
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-base sm:text-lg font-black text-white font-['Alexandria'] tracking-wide",
								children: "The Blind Date"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "px-2 py-0.5 rounded-full bg-rose-500/20 border border-rose-400/40 text-[10px] text-rose-300 font-extrabold flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "اللقاء التوافقي التفاعلي" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "✨" })]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-gray-300",
							children: "طرح الأسئلة • مكان مخصص للإجابة • تقييم متبادل لكل سؤال • تقييم نهاية كل مستوى • قرار الدردشة أو عدم الرضى"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: `px-2.5 py-1 rounded-xl text-xs font-bold border flex items-center gap-1.5 ${isReal ? "bg-emerald-500/20 border-emerald-400/40 text-emerald-300" : "bg-purple-500/20 border-purple-400/30 text-purple-200"}`,
							children: [isReal ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "w-3.5 h-3.5 text-emerald-400" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bot, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isReal ? "شخصان حقيقيان 🟢" : "شريك ذكي 🤖" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								soundManager.playTap();
								onClose();
							},
							className: "p-2 rounded-xl bg-white/10 hover:bg-white/20 text-gray-300 hover:text-white transition cursor-pointer",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-4 h-4" })
						})]
					})]
				}),
				subStep !== "setup_mode" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "bg-slate-900/90 border-b border-white/5 px-3 py-2 shrink-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-4 gap-1.5 sm:gap-2",
						children: BLIND_DATE_STAGES.map((st, idx) => {
							const isPast = idx < currentStageIdx;
							const isCurrent = idx === currentStageIdx;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `p-1.5 sm:p-2 rounded-xl border text-center transition-all ${isCurrent ? `bg-gradient-to-r ${st.color}/20 border-rose-400/60 shadow-md shadow-rose-500/10` : isPast ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-300" : "bg-white/5 border-white/5 text-gray-500 opacity-60"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-center gap-1 text-[11px] font-bold",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isPast ? "✅" : st.icon }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "hidden sm:inline",
											children: [
												"المستوى ",
												st.stepNumber,
												":"
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "truncate",
											children: st.badgeAr
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[9px] text-gray-400 mt-0.5",
									children: isPast ? "تم الاجتياز والتقييم" : isCurrent ? `السؤال ${questionTurnIdx + 1} من 5` : "مقفلة 🔒"
								})]
							}, st.key);
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 overflow-y-auto p-3 sm:p-5 flex flex-col justify-between",
					children: [
						subStep === "setup_mode" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "my-auto max-w-xl mx-auto w-full space-y-5 text-center py-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
									initial: { scale: .9 },
									animate: { scale: 1 },
									className: "w-20 h-20 mx-auto rounded-3xl bg-gradient-to-tr from-rose-600 via-pink-600 to-purple-600 flex items-center justify-center text-4xl shadow-xl shadow-rose-500/30",
									children: "💬"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-xl font-black text-white font-['Alexandria']",
										children: "اختر نمط المشاركة في The Blind Date"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-gray-300 leading-relaxed",
										children: "يمكن لشخصين حقيقيين الدخول والتعارف وطرح الأسئلة وتقييم بعضهما البعض لكل سؤال وفي نهاية كل مستوى، أو بدء جلسة فورية مع شريك افتراضي ذكي."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-3 text-right",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										onClick: () => setParticipantMode("real_person"),
										className: `p-4 rounded-2xl border transition cursor-pointer ${participantMode === "real_person" ? "bg-rose-500/15 border-rose-500 shadow-md shadow-rose-500/20" : "bg-white/5 border-white/10 hover:border-white/20"}`,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between mb-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-2xl",
													children: "👥"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold",
													children: "مباشر وحقيقي 🟢"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
												className: "text-sm font-bold text-white mb-1",
												children: "شخصان حقيقيان (Real People)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] text-gray-400 leading-relaxed",
												children: "ادخل مع شخص حقيقي متواجد الآن، أو أنشئ رمز غرفة وشاركه مع الطرف الآخر للدخول معاً فوراً."
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										onClick: () => setParticipantMode("ai_simulation"),
										className: `p-4 rounded-2xl border transition cursor-pointer ${participantMode === "ai_simulation" ? "bg-purple-500/15 border-purple-500 shadow-md shadow-purple-500/20" : "bg-white/5 border-white/10 hover:border-white/20"}`,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between mb-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-2xl",
													children: "🤖"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 text-[10px] font-bold",
													children: "فوري وممتع ✨"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
												className: "text-sm font-bold text-white mb-1",
												children: "شريك تفاعلي ذكي (AI Match)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] text-gray-400 leading-relaxed",
												children: "ابدأ الجلسة فوراً مع شريك ذكي يطابق تفضيلاتك الثقافية والعمرية دون انتظار أحد."
											})
										]
									})]
								}),
								participantMode === "real_person" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3 text-right",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-xs text-rose-300 font-bold",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "خيارات الربط المباشر لشخصين حقيقيين:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-[10px] text-gray-400",
												children: ["متصلون الآن: ", onlineCount]
											})]
										}),
										privateRoomCode ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-3 rounded-xl bg-purple-950/60 border border-purple-500/40 text-center space-y-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs text-gray-300 block",
													children: "شارك هذا الرمز مع الطرف الآخر للدخول معك فوراً:"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-center gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-xl font-mono font-black text-amber-300 tracking-widest bg-black/50 px-4 py-1.5 rounded-xl border border-amber-400/40",
														children: privateRoomCode
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														onClick: handleCopyCode,
														className: "p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition cursor-pointer",
														title: "نسخ الرمز",
														children: copiedCode ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4 text-emerald-400" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "w-4 h-4" })
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-[10px] text-gray-400 animate-pulse",
													children: "في انتظار دخول الطرف الآخر إلى الغرفة..."
												})
											]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-1 sm:grid-cols-2 gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												onClick: () => createPrivateRoom(),
												className: "p-3 rounded-xl bg-gradient-to-r from-rose-600 to-purple-600 hover:opacity-90 text-white text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "إنشاء غرفة خاصة برمز مشاركة" })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												onClick: startSearch,
												className: "p-3 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-white text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "w-4 h-4 text-emerald-400 animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "البحث التلقائي عن شخص متصل الآن" })]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "pt-2 border-t border-white/10 flex gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "text",
												value: roomCodeInput,
												onChange: (e) => setRoomCodeInput(e.target.value.toUpperCase()),
												placeholder: "أدخل رمز الغرفة (مثال: DATE-1234)...",
												className: "flex-1 px-3.5 py-2 rounded-xl bg-black/40 border border-white/15 text-white text-xs font-mono uppercase focus:outline-none focus:border-rose-400"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => {
													if (roomCodeInput.trim()) joinPrivateRoom(roomCodeInput.trim());
												},
												disabled: !roomCodeInput.trim(),
												className: "px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition cursor-pointer disabled:opacity-40",
												children: "انضمام"
											})]
										}),
										roomErrorMessage && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-2.5 rounded-xl bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "w-4 h-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: roomErrorMessage })]
										})
									]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "pt-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => {
											soundManager.playTap();
											setSubStep("user_ask");
										},
										className: "w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-purple-600 via-pink-600 to-rose-600 hover:opacity-95 text-white font-extrabold text-sm transition cursor-pointer shadow-lg shadow-purple-500/30 flex items-center justify-center gap-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "بدء جلسة اللقاء مع الشريك الذكي الآن 🚀" })
									})
								})
							]
						}),
						subStep !== "setup_mode" && subStep !== "open_chat" && subStep !== "show_rejected" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative mb-3 p-3 rounded-2xl bg-gradient-to-r from-purple-950/40 via-slate-900 to-rose-950/40 border border-white/10 shrink-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2 relative",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col items-center justify-center p-2.5 sm:p-3 rounded-xl bg-black/40 border border-white/5 text-center",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-br from-rose-600 to-pink-600 flex items-center justify-center text-2xl text-white shadow-lg shadow-rose-500/20 mb-1.5",
												children: profile?.userGender === "female" ? "👩" : "👨"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-bold text-white truncate max-w-[130px]",
												children: profile?.userName || "أنت (المتسابق الأول)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-[10px] text-gray-400",
												children: [
													profile?.country,
													" • ",
													profile?.userAge,
													" سنة"
												]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col items-center justify-center p-2.5 sm:p-3 rounded-xl bg-black/40 border border-white/5 text-center relative overflow-hidden",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-br from-purple-700 to-indigo-900 flex items-center justify-center text-2xl text-white/40 shadow-inner shadow-purple-500/20 mb-1.5 relative",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "filter blur-sm",
													children: isTargetFemale ? "👩" : "👨"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "absolute inset-0 flex items-center justify-center text-[10px] font-black text-rose-300",
													children: "🔒 خلف الستار"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-bold text-white truncate max-w-[130px]",
												children: partnerName
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] text-purple-300",
												children: isReal ? "متصل حقيقي 🟢" : `${partnerCountry} • ${partnerAge} سنة`
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "absolute inset-y-0 left-1/2 -translate-x-1/2 w-8 sm:w-10 bg-gradient-to-b from-rose-800 via-red-900 to-rose-950 border-x-2 border-amber-400/50 shadow-2xl flex flex-col items-center justify-center z-10 rounded-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[8px] font-black text-amber-300 uppercase tracking-widest [writing-mode:vertical-rl] py-1",
											children: "الستار الفاصل"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "w-3 h-3 text-amber-300 animate-pulse my-0.5" })]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2.5 flex items-center justify-between px-3 py-1 rounded-xl bg-white/5 text-[11px] text-gray-300",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-1.5 text-amber-300 font-bold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, { className: "w-3.5 h-3.5 text-rose-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										"توافق المرحلة: ",
										compatibilityPercent,
										"%"
									] })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-rose-300 font-medium truncate max-w-[200px]",
									children: currentStage.titleAr
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1 flex flex-col justify-center",
							children: [
								subStep === "user_ask" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
									initial: {
										opacity: 0,
										y: 10
									},
									animate: {
										opacity: 1,
										y: 0
									},
									className: "space-y-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-4 rounded-2xl bg-gradient-to-r from-rose-950/50 via-purple-950/40 to-slate-900 border border-rose-500/30",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between mb-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 text-xs font-bold",
													children: [
														"سؤالك رقم (",
														questionTurnIdx + 1,
														" من 5) للشريك"
													]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs text-gray-400",
													children: "دورك في طرح السؤال 🎤"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-base sm:text-lg font-bold text-white mb-1 leading-relaxed",
												children: currentQuestionItem.questionAr
											}),
											currentQuestionItem.subtitleAr && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-xs text-gray-400",
												children: ["💡 ", currentQuestionItem.subtitleAr]
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs text-gray-300 font-bold block",
												children: "اختر صيغة السؤال أو اكتب سؤالك الخاص:"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "grid grid-cols-1 sm:grid-cols-2 gap-2",
												children: currentQuestionItem.optionsAr.map((opt, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													onClick: () => handleUserAskQuestion(opt),
													className: "p-3 rounded-xl bg-white/5 hover:bg-rose-500/15 border border-white/10 hover:border-rose-500/40 text-right text-xs text-gray-200 transition cursor-pointer flex items-start gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-rose-400 font-bold shrink-0",
														children: [i + 1, "."]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: opt })]
												}, i))
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex gap-2 pt-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													type: "text",
													value: customQuestionInput,
													onChange: (e) => setCustomQuestionInput(e.target.value),
													placeholder: "أو اكتب سؤالك المخصص للشريك هنا...",
													className: "flex-1 px-4 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white placeholder-gray-500 text-xs focus:outline-none focus:border-rose-400"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													onClick: () => handleUserAskQuestion(customQuestionInput),
													className: "px-4 py-2.5 rounded-xl bg-gradient-to-r from-rose-500 to-pink-600 hover:opacity-90 text-white font-bold text-xs transition cursor-pointer flex items-center gap-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "طرح السؤال" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "w-3.5 h-3.5 -rotate-90" })]
												})]
											})
										]
									})]
								}, "sub_user_ask"),
								subStep === "partner_answer" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
									initial: {
										opacity: 0,
										scale: .95
									},
									animate: {
										opacity: 1,
										scale: 1
									},
									className: "text-center py-10 space-y-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-16 h-16 mx-auto rounded-2xl bg-purple-600/20 border border-purple-500/40 flex items-center justify-center text-3xl animate-pulse",
											children: "✍️"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
											className: "text-base font-bold text-white",
											children: [partnerName, " يكتب إجابته الآن في المكان المخصص خلف الستار..."]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-center items-center gap-1.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-2 h-2 rounded-full bg-rose-400 animate-bounce" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "w-2 h-2 rounded-full bg-purple-400 animate-bounce",
													style: { animationDelay: "0.15s" }
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "w-2 h-2 rounded-full bg-pink-400 animate-bounce",
													style: { animationDelay: "0.3s" }
												})
											]
										})
									]
								}, "sub_partner_answer"),
								subStep === "user_rate" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
									initial: {
										opacity: 0,
										y: 10
									},
									animate: {
										opacity: 1,
										y: 0
									},
									className: "space-y-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-4 rounded-2xl bg-gradient-to-r from-purple-950/60 via-slate-900 to-purple-900/40 border border-purple-500/40",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex items-center gap-2 mb-2",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 text-[11px] font-bold",
												children: [
													"إجابة ",
													partnerName,
													" من خلف الستار 🎙️"
												]
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
											className: "text-sm sm:text-base text-gray-100 italic leading-relaxed",
											children: [
												"«",
												currentAnswerReceived || currentQuestionItem.partnerPresetAnswer,
												"»"
											]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs font-bold text-amber-300",
													children: "قيم إجابة الشريك (1 إلى 5 نجوم):"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "flex items-center gap-1",
													children: [
														1,
														2,
														3,
														4,
														5
													].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														onClick: () => {
															soundManager.playTap();
															setSelectedUserRating(s);
														},
														className: "p-1 cursor-pointer transition hover:scale-125",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: `w-6 h-6 ${s <= selectedUserRating ? "fill-amber-400 text-amber-400 drop-shadow" : "text-gray-600"}` })
													}, s))
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[11px] text-gray-400",
													children: "انطباعك عن الإجابة:"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "flex flex-wrap gap-1.5",
													children: [
														"أعجبني بشدة ❤️",
														"ذكي ومقنع 💡",
														"عميق ومتزن 👑",
														"متطابق مع قيمي 🎯",
														"يحتاج توضيح 🤔"
													].map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														onClick: () => setSelectedReactionTag(tag),
														className: `px-3 py-1.5 rounded-xl text-xs font-semibold transition cursor-pointer ${selectedReactionTag === tag ? "bg-rose-500 text-white shadow-md shadow-rose-500/25" : "bg-white/5 hover:bg-white/10 text-gray-300 border border-white/10"}`,
														children: tag
													}, tag))
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "text",
												value: customFeedbackComment,
												onChange: (e) => setCustomFeedbackComment(e.target.value),
												placeholder: "ملاحظة إضافية أو تعليق للشريك على إجابته (اختياري)...",
												className: "w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/15 text-white placeholder-gray-500 text-xs focus:outline-none focus:border-rose-400"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => handleUserRatePartner(selectedUserRating, selectedReactionTag, customFeedbackComment),
												className: "w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-rose-600 hover:opacity-90 text-white font-bold text-xs transition cursor-pointer flex items-center justify-center gap-2 shadow-lg shadow-rose-500/20",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "اعتماد تقييم الإجابة والانتقال لسؤال الشريك ⭐" })
											})
										]
									})]
								}, "sub_user_rate"),
								subStep === "partner_ask" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
									initial: {
										opacity: 0,
										scale: .95
									},
									animate: {
										opacity: 1,
										scale: 1
									},
									className: "text-center py-8 space-y-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-16 h-16 mx-auto rounded-2xl bg-rose-600/20 border border-rose-500/40 flex items-center justify-center text-3xl animate-bounce",
											children: "🎤"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
											className: "text-base font-bold text-white",
											children: [
												"الدور الآن على ",
												partnerName,
												" لطرح سؤاله لك من خلف الستار!"
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-gray-400",
											children: "استعد لكتابة إجابتك في المكان المخصص..."
										})
									]
								}, "sub_partner_ask"),
								subStep === "user_answer" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
									initial: {
										opacity: 0,
										y: 10
									},
									animate: {
										opacity: 1,
										y: 0
									},
									className: "space-y-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-4 rounded-2xl bg-gradient-to-r from-purple-950/60 via-slate-900 to-rose-950/40 border border-purple-500/30",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between mb-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "px-2.5 py-0.5 rounded-full bg-purple-500/20 text-purple-300 text-xs font-bold",
												children: [
													"سؤال ",
													partnerName,
													" لك ❓"
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs text-gray-400",
												children: "اكتب إجابتك ليقوم الشريك بتقييمها"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
											className: "text-base sm:text-lg font-bold text-white leading-relaxed",
											children: [
												"«",
												currentQuestionReceived || currentQuestionItem.partnerQuestionToUser,
												"»"
											]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between text-xs text-gray-300 font-bold",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "مكان الإجابة المخصص (اكتب ردك بحرية كاملة):" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] text-rose-300",
													children: "الطرف الآخر سيقوم بتقييم هذا الرد"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
												rows: 3,
												value: customAnswerInput,
												onChange: (e) => setCustomAnswerInput(e.target.value),
												placeholder: "اكتب إجابتك الصادقة والمفصلة هنا بكلماتك وأسلوبك الخاص...",
												className: "w-full px-4 py-3 rounded-xl bg-black/50 border border-white/15 text-white placeholder-gray-500 text-xs focus:outline-none focus:border-rose-400 leading-relaxed resize-none"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[11px] text-gray-400 block",
													children: "أو اختر إجابة سريعة للإلهام:"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "grid grid-cols-1 sm:grid-cols-2 gap-1.5",
													children: currentQuestionItem.userSuggestedAnswers?.map((ans, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														onClick: () => setCustomAnswerInput(ans),
														className: "p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-right text-[11px] text-gray-300 transition cursor-pointer",
														children: ans
													}, i))
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												onClick: () => handleUserAnswerPartner(customAnswerInput),
												disabled: !customAnswerInput.trim(),
												className: "w-full py-3 rounded-xl bg-gradient-to-r from-purple-600 via-pink-600 to-rose-600 hover:opacity-95 text-white font-bold text-xs transition cursor-pointer disabled:opacity-40 flex items-center justify-center gap-2 shadow-lg shadow-purple-500/25",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "إرسال إجابتي ليقوم الشريك بتقييمها 🚀" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "w-3.5 h-3.5 -rotate-90" })]
											})
										]
									})]
								}, "sub_user_answer"),
								subStep === "partner_rate" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
									initial: {
										opacity: 0,
										scale: .95
									},
									animate: {
										opacity: 1,
										scale: 1
									},
									className: "text-center py-10 space-y-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-16 h-16 mx-auto rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-3xl animate-spin",
											children: "⭐"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
											className: "text-base font-bold text-white",
											children: [partnerName, " يقرأ إجابتك الآن ويقوم بتقييمها خلف الستار..."]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-gray-300",
											children: "سيتم تسجيل درجات التقييم في سجل التوافق فوراً."
										})
									]
								}, "sub_partner_rate"),
								subStep === "stage_evaluation" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
									initial: {
										opacity: 0,
										scale: .94
									},
									animate: {
										opacity: 1,
										scale: 1
									},
									className: "p-5 sm:p-6 rounded-3xl bg-gradient-to-b from-purple-950/80 to-slate-900 border-2 border-amber-500/50 text-center space-y-4 shadow-2xl",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-16 h-16 mx-auto rounded-3xl bg-gradient-to-tr from-amber-500 to-rose-500 flex items-center justify-center text-3xl text-white shadow-lg shadow-amber-500/30",
											children: "🏆"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
												className: "text-lg sm:text-xl font-black text-white font-['Alexandria']",
												children: [
													"تقييم نهاية المستوى ",
													currentStage.stepNumber,
													": ",
													currentStage.badgeAr
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-gray-300 max-w-md mx-auto leading-relaxed",
												children: "أكملتما تبادل الأسئلة الخمسة وإجاباتها وتقييماتها بنجاح! والآن يقوم كل طرف بتقييم التوافق الإجمالي لهذا المستوى والتصويت على التأهل للمستوى القادم."
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-3.5 rounded-2xl bg-white/5 border border-white/10 max-w-md mx-auto space-y-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-bold text-amber-300 block",
												children: "تقييمك الإجمالي للشريك في هذا المستوى:"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex items-center justify-center gap-2",
												children: [
													1,
													2,
													3,
													4,
													5
												].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => setMyLevelRating(s),
													className: "cursor-pointer hover:scale-125 transition",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: `w-7 h-7 ${s <= myLevelRating ? "fill-amber-400 text-amber-400" : "text-gray-600"}` })
												}, s))
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "max-w-md mx-auto space-y-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs text-gray-200 font-bold block",
												children: "هل توافق على استمرار الشريك والتأهل للمستوى التالي؟"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "grid grid-cols-2 gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													onClick: () => handleLevelVote(true),
													className: `p-3 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${myLevelApproval === true ? "bg-emerald-500 text-white border-emerald-400" : "bg-emerald-500/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/30"}`,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThumbsUp, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "نعم، راضٍ وموافق 🚀" })]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													onClick: () => handleLevelVote(false),
													className: `p-3 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${myLevelApproval === false ? "bg-rose-600 text-white border-rose-500" : "bg-rose-500/20 text-rose-300 border-rose-500/40 hover:bg-rose-500/30"}`,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThumbsDown, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "غير راضٍ عن التوافق" })]
												})]
											})]
										}),
										myLevelApproval === true && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "pt-2",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												onClick: handleAdvanceToNextLevel,
												className: "w-full max-w-md py-3.5 px-6 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-rose-600 hover:opacity-95 text-white font-extrabold text-sm transition cursor-pointer shadow-xl shadow-emerald-500/20 mx-auto flex items-center justify-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: currentStageIdx < 3 ? `الانتقال للمستوى ${currentStageIdx + 2}: ${BLIND_DATE_STAGES[currentStageIdx + 1]?.badgeAr} 🚀` : "الانتقال للحظة الحسم والقرار النهائي لإسقاط الستار! ✨" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "w-4 h-4" })]
											})
										})
									]
								}, "sub_stage_eval"),
								subStep === "final_curtain" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
									initial: {
										opacity: 0,
										scale: .95
									},
									animate: {
										opacity: 1,
										scale: 1
									},
									className: "p-5 sm:p-6 rounded-3xl bg-gradient-to-b from-rose-950/80 via-slate-900 to-purple-950/80 border-2 border-rose-500/50 text-center space-y-5 shadow-2xl relative overflow-hidden",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-20 h-20 mx-auto rounded-3xl bg-gradient-to-tr from-rose-500 to-amber-500 flex items-center justify-center text-4xl shadow-xl shadow-rose-500/30 animate-pulse",
											children: "✨"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-xl sm:text-2xl font-black text-white font-['Alexandria']",
												children: "لحظة الحسم والقرار النهائي في The Blind Date"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-xs sm:text-sm text-gray-300 max-w-lg mx-auto leading-relaxed",
												children: ["لقد أكملتما المستويات الأربعة كاملة (الشخصية، الاجتماعية، العلمية، والطموحات). والآن يُخيّر كل طرف بين:", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
													className: "text-amber-300 block mt-1 text-sm",
													children: "«الموافقة والرضى لرفع الستار والدردشة المفتوحة، أو عدم الرضى وإبقاء الستار مغلقاً»"
												})]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-2 gap-3 max-w-md mx-auto text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: `p-3 rounded-2xl border transition ${myFinalChoice === "accept" ? "bg-emerald-500/20 border-emerald-400 text-emerald-300" : myFinalChoice === "reject" ? "bg-rose-500/20 border-rose-400 text-rose-300" : "bg-white/5 border-white/10 text-gray-400"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "block font-bold mb-1",
													children: "قرارك أنت:"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: myFinalChoice === "accept" ? "💖 راضٍ وموافق على اللقاء" : myFinalChoice === "reject" ? "🛑 غير راضٍ عن التوافق" : "في انتظار اختيارك" })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: `p-3 rounded-2xl border transition ${partnerFinalChoice === "accept" ? "bg-emerald-500/20 border-emerald-400 text-emerald-300" : partnerFinalChoice === "reject" ? "bg-rose-500/20 border-rose-400 text-rose-300" : "bg-white/5 border-white/10 text-gray-400"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "block font-bold mb-1",
													children: [
														"قرار ",
														partnerName,
														":"
													]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: partnerFinalChoice === "accept" ? "💖 راضٍ وموافق على اللقاء" : partnerFinalChoice === "reject" ? "🛑 غير راضٍ عن التوافق" : "يترقب قرارك" })]
											})]
										}),
										!myFinalChoice ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-md mx-auto pt-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												onClick: () => handleFinalDecision("accept"),
												className: "py-4 px-5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:opacity-95 text-white font-extrabold text-xs sm:text-sm transition cursor-pointer shadow-xl shadow-emerald-500/25 flex items-center justify-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "w-4 h-4 fill-white animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "راضٍ وأوافق على رفع الستار والدردشة 💖" })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												onClick: () => handleFinalDecision("reject"),
												className: "py-4 px-5 rounded-2xl bg-gradient-to-r from-rose-700 to-red-800 hover:opacity-95 text-white font-extrabold text-xs sm:text-sm transition cursor-pointer shadow-xl shadow-rose-900/30 flex items-center justify-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThumbsDown, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "عدم الرضى (إبقاء الستار مغلقاً) 🛑" })]
											})]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "py-2 text-rose-300 text-xs font-bold animate-pulse flex items-center justify-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-4 h-4 text-amber-300" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "جاري معالجة قرار الطرفين لحسم نتيجة الستار..." })]
										})
									]
								}, "sub_final_curtain"),
								subStep === "show_rejected" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
									initial: {
										opacity: 0,
										scale: .95
									},
									animate: {
										opacity: 1,
										scale: 1
									},
									className: "p-6 rounded-3xl bg-slate-900/90 border-2 border-rose-500/30 text-center space-y-4 max-w-md mx-auto",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-16 h-16 mx-auto rounded-2xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-3xl",
											children: "🔒"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-lg font-bold text-white font-['Alexandria']",
											children: "ظل الستار مغلقاً لعدم اكتمال الرضى المتبادل"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-gray-300 leading-relaxed",
											children: "شكراً لمشاركتكما الراقية والصريحة في The Blind Date. الاحترام المتبادل والصراحة هما الأهم في تقييم التوافق، ونتمنى لكل منكما التوفيق في إيجاد الشريك المتوافق تماماً!"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "pt-2",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => {
													soundManager.playTap();
													setCurrentStageIdx(0);
													setQuestionTurnIdx(0);
													setMyFinalChoice(null);
													setPartnerFinalChoice(null);
													setSubStep("setup_mode");
												},
												className: "w-full py-3 px-5 rounded-2xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition cursor-pointer",
												children: "بدء جولة جديدة في The Blind Date 💬"
											})
										})
									]
								}, "sub_rejected"),
								subStep === "open_chat" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
									initial: {
										opacity: 0,
										y: 15
									},
									animate: {
										opacity: 1,
										y: 0
									},
									className: "flex flex-col h-full space-y-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-3.5 rounded-2xl bg-gradient-to-r from-rose-950/70 via-purple-950/70 to-slate-900 border border-rose-500/40 flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "w-12 h-12 rounded-2xl overflow-hidden bg-gradient-to-br from-rose-500 to-purple-600 flex items-center justify-center text-2xl shadow-md border-2 border-rose-400",
													children: result?.imageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
														src: result.imageUrl,
														alt: partnerName,
														className: "w-full h-full object-cover"
													}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isTargetFemale ? "👩" : "👨" })
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "font-extrabold text-white text-sm",
														children: partnerName
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-[10px] text-emerald-300 font-bold",
														children: "سقط الستار بالرضى المتبادل 🟢"
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "text-[11px] text-gray-300",
													children: [
														partnerCountry,
														" • ",
														partnerAge,
														" عاماً • توافق ",
														compatibilityPercent,
														"%"
													]
												})] })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "px-2.5 py-1 rounded-xl bg-white/10 text-[10px] text-amber-300 font-bold",
												children: "الدردشة المفتوحة غير المحدودة 💬"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex-1 min-h-[220px] max-h-[340px] overflow-y-auto space-y-2.5 p-3 rounded-2xl bg-black/50 border border-white/10 scrollbar-thin",
											children: [chatMessages.map((m) => {
												const isMe = m.sender === "me";
												return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
													initial: {
														opacity: 0,
														y: 6
													},
													animate: {
														opacity: 1,
														y: 0
													},
													className: `flex flex-col ${isMe ? "items-end" : "items-start"}`,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-1.5 mb-0.5 px-1 text-[10px] text-gray-400",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isMe ? "أنت" : partnerName }),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: m.time })
														]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: `max-w-[88%] sm:max-w-[80%] px-4 py-2.5 rounded-2xl text-xs leading-relaxed ${isMe ? "bg-gradient-to-r from-rose-600 to-pink-600 text-white rounded-tr-none shadow-md shadow-rose-500/10" : "bg-white/10 text-gray-100 rounded-tl-none border border-white/10 shadow-sm"}`,
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "font-medium",
															children: m.text
														}), m.voiceData && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "mt-2.5 pt-2.5 border-t border-white/20 space-y-2",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "flex items-center gap-2 p-2 rounded-xl bg-black/30 border border-white/10",
																children: [
																	m.voiceData.audioUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																		type: "button",
																		onClick: () => handlePlayVoiceAudio(m.voiceData.audioUrl),
																		className: "w-7 h-7 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center transition active:scale-95 cursor-pointer shrink-0",
																		title: "تشغيل الملاحظة الصوتية",
																		children: currentlyPlayingAudioUrl === m.voiceData.audioUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "w-3.5 h-3.5 text-rose-300" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "w-3.5 h-3.5 fill-white text-white" })
																	}),
																	/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																		className: "flex-1 flex items-center gap-1.5",
																		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																			className: "font-mono text-[11px] text-amber-200",
																			children: ["0:0", m.voiceData.duration || 6]
																		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																			className: "flex items-center gap-0.5 h-4 flex-1",
																			children: [
																				10,
																				16,
																				22,
																				14,
																				26,
																				18,
																				14,
																				20,
																				12,
																				18,
																				10
																			].map((h, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																				style: { height: `${h * .65}px` },
																				className: `w-1 rounded-full inline-block ${currentlyPlayingAudioUrl === m.voiceData?.audioUrl ? "bg-emerald-400 animate-pulse" : "bg-white/60"}`
																			}, i))
																		})]
																	}),
																	/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																		className: "text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30",
																		children: [
																			"توافق ",
																			m.voiceData.analysis?.vocalSynergyScore || 96,
																			"%"
																		]
																	})
																]
															}), m.voiceData.analysis && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "p-2.5 rounded-xl bg-black/40 border border-white/10 space-y-1.5 text-[11px]",
																children: [
																	/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																		className: "flex items-center justify-between text-amber-300 font-bold",
																		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																			className: "flex items-center gap-1",
																			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-3.5 h-3.5 text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: m.voiceData.analysis.voiceToneArchetype })]
																		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																			className: "text-[10px] text-gray-300",
																			children: "التحليل الصوتي المتقدم"
																		})]
																	}),
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "text-gray-200 leading-relaxed text-[11px]",
																		children: m.voiceData.analysis.vocalCompatibilityReport
																	}),
																	m.voiceData.analysis.partnerAcousticReaction && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																		className: "text-[10px] text-rose-300 italic pt-1 border-t border-white/10",
																		children: [
																			"انطباع الطرف الآخر: \"",
																			m.voiceData.analysis.partnerAcousticReaction,
																			"\""
																		]
																	})
																]
															})]
														})]
													})]
												}, m.id);
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { ref: chatEndRef })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-thin",
											children: [
												"ما هو أكثر شيء أسعدك في إجاباتي؟ ✨",
												"أنا ممتن جداً لهذا التوافق واللقاء! 💖",
												"ما رأيك أن نتفق على كتاب نقرؤه معاً؟ 📚",
												"يسعدني أن نتحدث دائماً بكل هذا الاحترام والود 🌹"
											].map((ice, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setOpenChatInput(ice),
												className: "shrink-0 px-2.5 py-1 rounded-xl bg-white/5 hover:bg-white/15 border border-white/10 text-[11px] text-gray-300 hover:text-white transition cursor-pointer",
												children: ice
											}, i))
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
											onSubmit: handleSendOpenChat,
											className: "flex items-center gap-2 pt-1",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													onClick: () => {
														soundManager.playTap();
														setIsVoiceModalOpen(true);
													},
													className: "px-3 py-2.5 rounded-2xl bg-gradient-to-r from-rose-500/20 via-pink-500/20 to-purple-500/20 hover:from-rose-500/30 hover:to-purple-500/30 border border-rose-500/40 text-rose-300 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shrink-0 active:scale-95 shadow-sm",
													title: "تسجيل رسالة صوتية قصيرة وتحليل نبرة الصوت والمشاعر والتناغم",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "w-4 h-4 text-rose-400 animate-pulse" }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "hidden sm:inline font-['Alexandria']",
															children: "تسجيل صوتي وتحليل النبرة 🎙️"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "sm:hidden",
															children: "🎙️ صوتي"
														})
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													type: "text",
													value: openChatInput,
													onChange: (e) => setOpenChatInput(e.target.value),
													placeholder: "اكتب رسالتك المفتوحة للشريك بكل مودة واحترام...",
													className: "flex-1 px-4 py-2.5 rounded-2xl bg-white/5 border border-white/15 text-white placeholder-gray-500 text-xs focus:outline-none focus:border-rose-400"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "submit",
													disabled: !openChatInput.trim(),
													className: "p-2.5 px-4 rounded-2xl bg-gradient-to-r from-rose-500 to-purple-600 hover:opacity-95 text-white transition flex items-center justify-center gap-1.5 text-xs font-bold cursor-pointer disabled:opacity-40",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "إرسال" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "w-3.5 h-3.5 -rotate-90" })]
												})
											]
										})
									]
								}, "sub_open_chat")
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VoiceToneAnalysisModal, {
					isOpen: isVoiceModalOpen,
					onClose: () => setIsVoiceModalOpen(false),
					partnerName,
					partnerGender: profile?.partnerGender || "female",
					userGender: profile?.userGender || "male",
					onSendVoiceMessageToChat: handleSendVoiceMessage
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-4 py-2.5 bg-slate-900/90 border-t border-white/5 flex items-center justify-between text-[11px] text-gray-400 shrink-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "💬 جلسة The Blind Date التفاعلية" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "نظام إجابة مخصص وتقييم متبادل" })
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center gap-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-amber-300 font-bold",
							children: [
								"متوسط تقييم الإجابات: ",
								averageStars,
								" ⭐"
							]
						})
					})]
				})
			]
		})
	});
};
//#endregion
export { BlindDateShowModal };
