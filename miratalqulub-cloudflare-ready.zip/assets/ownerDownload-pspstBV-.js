async function downloadOwnerProtectedZip(endpoint, filename, user) {
	if (!user || !user.email || user.email.toLowerCase() !== "one497303@gmail.com".toLowerCase() || !user.emailVerified) throw new Error("غير مصرح: هذا التحميل مخصص لحساب المالك الموثق فقط (one497303@gmail.com).");
	const idToken = await user.getIdToken(true);
	const response = await fetch(endpoint, {
		method: "GET",
		headers: { Authorization: `Bearer ${idToken}` }
	});
	if (!response.ok) {
		let errorMessage = "فشل التحقق من صلاحيات المالك لتحميل الحزمة.";
		try {
			const errJson = await response.json();
			if (errJson?.error) errorMessage = errJson.error;
		} catch {}
		throw new Error(errorMessage);
	}
	const blob = await response.blob();
	const objectUrl = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = objectUrl;
	link.download = filename;
	document.body.appendChild(link);
	link.click();
	link.remove();
	setTimeout(() => URL.revokeObjectURL(objectUrl), 4e3);
}
//#endregion
export { downloadOwnerProtectedZip };
