import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { I as Share2, bn as Check, rn as Copy } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import "./index-C5uCeetQ.js";
import "./data-content-CCe8WBeA.js";
import "./ReaderToolbar-CBKPy1tK.js";
//#region src/components/FullScreenResearchStudyModal.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var ArticleBottomSocialShare = ({ title, summary, url, isLight, language }) => {
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [showPlatforms, setShowPlatforms] = (0, import_react.useState)(true);
	const isAr = language === "ar";
	const shareUrl = url || (typeof window !== "undefined" ? window.location.href : "https://miratalqulub.com/#/articles");
	const fullShareMessage = `📖 ${title}\n\n${summary.slice(0, 240)}...\n\n🔗 ${shareUrl}`;
	const encodedText = encodeURIComponent(fullShareMessage);
	const encodedUrl = encodeURIComponent(shareUrl);
	const encodedTitle = encodeURIComponent(`📖 ${title}`);
	const handleCopyShare = () => {
		soundManager.playTap();
		if (navigator.clipboard) {
			navigator.clipboard.writeText(fullShareMessage);
			setCopied(true);
			setTimeout(() => setCopied(false), 2500);
		}
	};
	const handleNativeOrToggleShare = async () => {
		soundManager.playTap();
		if (typeof navigator !== "undefined" && typeof navigator.share === "function") try {
			await navigator.share({
				title,
				text: summary.slice(0, 220),
				url: shareUrl
			});
			return;
		} catch {}
		setShowPlatforms((prev) => !prev);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `p-5 sm:p-6 rounded-3xl border-2 space-y-4 transition-all ${isLight ? "bg-gradient-to-r from-indigo-50 via-white to-rose-50 border-indigo-200 text-slate-900 shadow-md" : "bg-gradient-to-r from-indigo-950/60 via-slate-900/95 to-rose-950/50 border-cyan-500/35 text-white shadow-xl"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "inline-flex items-center gap-1.5 text-xs font-extrabold text-rose-600 dark:text-rose-300",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "نشر المعرفة العلمية ومشاركة الدراسة" : "Share This Scientific Study" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-base sm:text-lg font-black font-['Alexandria']",
						children: isAr ? "شارك هذا البحث العلمي عبر منصات التواصل الاجتماعي" : "Share This Research Study on Social Media"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: `text-xs ${isLight ? "text-slate-600" : "text-gray-300"}`,
						children: isAr ? "ساهم في نشر الوعي النفسي والأكاديمي المبني على الدليل العلمي في دول مجلس التعاون الخليجي والعالم العربي." : "Help disseminate evidence-based psychological and family mental health research."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: handleNativeOrToggleShare,
					className: "px-4 py-2.5 rounded-2xl bg-gradient-to-r from-rose-600 to-purple-600 hover:from-rose-500 hover:to-purple-500 text-white text-xs font-extrabold flex items-center gap-2 shadow-md transition cursor-pointer",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "مشاركة عبر التواصل الاجتماعي" : "Share on Social Media" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: handleCopyShare,
					className: `px-4 py-2.5 rounded-2xl text-xs font-extrabold border flex items-center gap-1.5 transition cursor-pointer ${copied ? "bg-emerald-600 text-white border-emerald-500" : isLight ? "bg-white hover:bg-slate-100 text-slate-800 border-slate-300" : "bg-white/10 hover:bg-white/20 text-white border-white/15"}`,
					children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: copied ? isAr ? "تم نسخ رابط وملخص البحث!" : "Link & Summary Copied!" : isAr ? "نسخ رابط البحث للمشاركة" : "Copy Share Link" })]
				})]
			})]
		}), showPlatforms && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pt-3 border-t border-indigo-200/70 dark:border-white/10 flex flex-wrap items-center gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: `https://wa.me/?text=${encodedText}`,
					target: "_blank",
					rel: "noopener noreferrer",
					onClick: () => soundManager.playTap(),
					className: "px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-extrabold flex items-center gap-1.5 transition shadow-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "💬" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "واتساب (WhatsApp)" : "WhatsApp" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: `https://twitter.com/intent/tweet?text=${encodedTitle}&url=${encodedUrl}`,
					target: "_blank",
					rel: "noopener noreferrer",
					onClick: () => soundManager.playTap(),
					className: "px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white border border-white/15 text-xs font-extrabold flex items-center gap-1.5 transition shadow-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "𝕏" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "منصة إكس (Twitter / X)" : "Post on X" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: `https://t.me/share/url?url=${encodedUrl}&text=${encodedTitle}`,
					target: "_blank",
					rel: "noopener noreferrer",
					onClick: () => soundManager.playTap(),
					className: "px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-extrabold flex items-center gap-1.5 transition shadow-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "✈️" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "تيليجرام (Telegram)" : "Telegram" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}&quote=${encodedTitle}`,
					target: "_blank",
					rel: "noopener noreferrer",
					onClick: () => soundManager.playTap(),
					className: "px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-extrabold flex items-center gap-1.5 transition shadow-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "📘" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "فيسبوك (Facebook)" : "Facebook" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`,
					target: "_blank",
					rel: "noopener noreferrer",
					onClick: () => soundManager.playTap(),
					className: "px-3.5 py-2 rounded-xl bg-indigo-700 hover:bg-indigo-600 text-white text-xs font-extrabold flex items-center gap-1.5 transition shadow-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "💼" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "لينكدإن (LinkedIn)" : "LinkedIn" })]
				})
			]
		})]
	});
};
//#endregion
export { ArticleBottomSocialShare as t };
