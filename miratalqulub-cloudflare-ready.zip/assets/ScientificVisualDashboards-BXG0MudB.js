import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { d as useAppTheme, l as useLanguage } from "./index-C5uCeetQ.js";
import { _ as Tooltip, d as CartesianGrid, f as Radar, g as Cell, h as PolarGrid, l as Bar, m as PolarRadiusAxis, n as RadarChart, o as YAxis, p as PolarAngleAxis, r as BarChart, s as XAxis, v as Legend, y as ResponsiveContainer } from "./vendor-charts-Z9-zx-pq.js";
//#region src/components/ScientificVisualDashboards.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
function safeVal(n) {
	if (!Number.isFinite(n)) return 0;
	return Math.max(0, Math.min(100, Math.round(n)));
}
var ScientificVisualDashboards = ({ charts, userName, comparisonOverlay }) => {
	const { theme } = useAppTheme();
	const { direction, isRTL, translateText } = useLanguage();
	const isLight = theme === "light";
	const [selectedCell, setSelectedCell] = (0, import_react.useState)(null);
	const axisTextColor = isLight ? "#334155" : "#cbd5e1";
	const gridStroke = isLight ? "rgba(15,23,42,0.12)" : "rgba(255,255,255,0.12)";
	const cardBg = isLight ? "bg-white border-slate-200 text-slate-900 shadow-sm" : "bg-slate-900/75 border-white/10 text-slate-100";
	const tooltipStyle = {
		backgroundColor: isLight ? "#ffffff" : "#0f172a",
		border: isLight ? "1px solid #cbd5e1" : "1px solid rgba(139,92,246,0.45)",
		borderRadius: "12px",
		color: isLight ? "#0f172a" : "#f8fafc",
		fontSize: "12px",
		fontFamily: isRTL ? "Alexandria, sans-serif" : "Inter, system-ui, sans-serif"
	};
	const overallData = (charts.overallRadar || []).map((d) => ({
		...d,
		subject: isRTL ? d.subject : translateText(d.subject),
		score: safeVal(d.score),
		fullMark: 100
	}));
	const bfData = (charts.bigFiveRadar || []).map((d) => ({
		...d,
		trait: isRTL ? d.trait : translateText(d.trait),
		score: safeVal(d.score),
		benchmark: safeVal(d.benchmark),
		fullMark: 100
	}));
	const hxData = (charts.hexacoRadar || []).map((d) => ({
		...d,
		trait: isRTL ? d.trait : translateText(d.trait),
		score: safeVal(d.score),
		fullMark: 100
	}));
	const eiData = (charts.emotionalIntelligence || []).map((d) => ({
		...d,
		branch: isRTL ? d.branch : translateText(d.branch),
		score: safeVal(d.score)
	}));
	const overallEI = eiData.length > 0 ? Math.round(eiData.reduce((acc, item) => acc + item.score, 0) / eiData.length) : 50;
	const commData = (charts.communicationStyles || []).map((d) => ({
		...d,
		style: isRTL ? d.style : translateText(d.style),
		score: safeVal(d.score)
	}));
	const conflictData = (charts.conflictModes || []).map((d) => ({
		...d,
		mode: isRTL ? d.mode : translateText(d.mode),
		score: safeVal(d.score),
		fullMark: 100
	}));
	const goalsData = (charts.lifeGoalsAlignment || []).map((d) => ({
		...d,
		domain: isRTL ? d.domain : translateText(d.domain),
		userScore: safeVal(d.userScore),
		targetBenchmark: safeVal(d.targetBenchmark)
	}));
	const attAnxiety = safeVal(charts.attachment?.anxiety ?? 30);
	const attAvoidance = safeVal(charts.attachment?.avoidance ?? 30);
	const gaugeRadius = 46;
	const gaugeCircumference = 2 * Math.PI * gaugeRadius;
	const gaugeDashOffset = gaugeCircumference * (1 - overallEI / 100);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		dir: direction,
		children: [
			comparisonOverlay && comparisonOverlay.axes.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `rounded-2xl border p-4 sm:p-5 ${cardBg}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap items-center justify-between gap-2 mb-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "font-extrabold text-sm sm:text-base",
						children: isRTL ? `مقارنة المحاور التسعة: ${comparisonOverlay.personAName} ✕ ${comparisonOverlay.personBName}` : `9-Axis Dyadic Comparison: ${comparisonOverlay.personAName} ✕ ${comparisonOverlay.personBName}`
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs opacity-75",
						children: isRTL ? "تراكب سيكومتري مباشر عبر Big Five وHEXACO والتعلق والذكاء العاطفي والتواصل والقيم" : "Direct psychometric overlay across Big Five, HEXACO, Attachment (ECR-R), EI, Communication & Core Values"
					})] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "w-full h-72 sm:h-80 ltr-preserve",
					dir: "ltr",
					"data-keep-dir": "true",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(RadarChart, {
							data: comparisonOverlay.axes.map((a) => ({
								axis: isRTL ? a.axisNameAr.split("(")[0].trim() : translateText(a.axisNameAr).split("(")[0].trim(),
								A: safeVal(a.personAScore),
								B: safeVal(a.personBScore),
								fullMark: 100
							})),
							outerRadius: "68%",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarGrid, { stroke: gridStroke }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarAngleAxis, {
									dataKey: "axis",
									tick: {
										fill: axisTextColor,
										fontSize: 10
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarRadiusAxis, {
									angle: 30,
									domain: [0, 100],
									tick: {
										fill: axisTextColor,
										fontSize: 9
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radar, {
									name: comparisonOverlay.personAName,
									dataKey: "A",
									stroke: "#8b5cf6",
									fill: "#8b5cf6",
									fillOpacity: .35,
									strokeWidth: 2.5
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radar, {
									name: comparisonOverlay.personBName,
									dataKey: "B",
									stroke: "#10b981",
									fill: "#10b981",
									fillOpacity: .3,
									strokeWidth: 2.5
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, { wrapperStyle: { fontSize: "12px" } }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: tooltipStyle })
							]
						})
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 lg:grid-cols-2 gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `rounded-2xl border p-4 ${cardBg}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "font-extrabold text-sm mb-1",
							children: isRTL ? "1. رادار التركيبة النفسية الشاملة (8 نماذج علمية)" : "1. Comprehensive 8-Construct Psychometric Radar"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] opacity-75 mb-2",
							children: isRTL ? `التوزيع المتكامل لبصمة ${userName || "المختبَر"} عبر المحاور الثمانية` : `Integrated psychometric profile of ${userName || "Examinee"} across 8 scientific constructs`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-full h-64 ltr-preserve",
							dir: "ltr",
							"data-keep-dir": "true",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
								width: "100%",
								height: "100%",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(RadarChart, {
									data: overallData,
									outerRadius: "66%",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarGrid, { stroke: gridStroke }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarAngleAxis, {
											dataKey: "subject",
											tick: {
												fill: axisTextColor,
												fontSize: 10
											}
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarRadiusAxis, {
											angle: 90,
											domain: [0, 100],
											tick: {
												fill: axisTextColor,
												fontSize: 9
											}
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radar, {
											name: isRTL ? "نتيجتك %" : "Your Score %",
											dataKey: "score",
											stroke: "#8b5cf6",
											fill: "#8b5cf6",
											fillOpacity: .42,
											strokeWidth: 2.5
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: tooltipStyle })
									]
								})
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `rounded-2xl border p-4 ${cardBg}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "font-extrabold text-sm mb-1",
							children: isRTL ? "2. رادار العوامل الخمسة الكبرى (Big Five vs Normative)" : "2. Big Five (OCEAN) vs. Normative Benchmark"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] opacity-75 mb-2",
							children: isRTL ? "مقارنة سماتك الخمس مع المتوسط المعياري (Benchmark)" : "Comparing your 5 personality dimensions against the normative population benchmark"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-full h-64 ltr-preserve",
							dir: "ltr",
							"data-keep-dir": "true",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
								width: "100%",
								height: "100%",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(RadarChart, {
									data: bfData,
									outerRadius: "68%",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarGrid, { stroke: gridStroke }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarAngleAxis, {
											dataKey: "trait",
											tick: {
												fill: axisTextColor,
												fontSize: 10.5
											}
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarRadiusAxis, {
											angle: 90,
											domain: [0, 100],
											tick: {
												fill: axisTextColor,
												fontSize: 9
											}
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radar, {
											name: isRTL ? "درجتك %" : "Your Score %",
											dataKey: "score",
											stroke: "#ec4899",
											fill: "#ec4899",
											fillOpacity: .4,
											strokeWidth: 2.5
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radar, {
											name: isRTL ? "المتوسط المعياري" : "Normative Benchmark",
											dataKey: "benchmark",
											stroke: "#06b6d4",
											fill: "#06b6d4",
											fillOpacity: .14,
											strokeWidth: 1.8,
											strokeDasharray: "4 4"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, { wrapperStyle: { fontSize: "11px" } }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: tooltipStyle })
									]
								})
							})
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 lg:grid-cols-2 gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `rounded-2xl border p-4 ${cardBg}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "font-extrabold text-sm mb-1",
							children: isRTL ? "3. رادار نموذج هيكساكو سداسي العوامل (HEXACO)" : "3. HEXACO 6-Factor Personality Radar"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] opacity-75 mb-2",
							children: isRTL ? "يُظهر عامل الصدق والتواضع (H) إلى جانب الأبعاد الخمسة المفسرة للسلوك" : "Highlights Honesty-Humility (H) alongside the 5 structural personality factors"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-full h-64 ltr-preserve",
							dir: "ltr",
							"data-keep-dir": "true",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
								width: "100%",
								height: "100%",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(RadarChart, {
									data: hxData,
									outerRadius: "68%",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarGrid, { stroke: gridStroke }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarAngleAxis, {
											dataKey: "trait",
											tick: {
												fill: axisTextColor,
												fontSize: 10.5
											}
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarRadiusAxis, {
											angle: 90,
											domain: [0, 100],
											tick: {
												fill: axisTextColor,
												fontSize: 9
											}
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radar, {
											name: "HEXACO %",
											dataKey: "score",
											stroke: "#06b6d4",
											fill: "#06b6d4",
											fillOpacity: .38,
											strokeWidth: 2.5
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: tooltipStyle })
									]
								})
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `rounded-2xl border p-4 flex flex-col justify-between ${cardBg}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "font-extrabold text-sm mb-1",
						children: isRTL ? "4. مقياس الذكاء العاطفي (Emotional Intelligence Meter)" : "4. Mayer-Salovey Emotional Intelligence (EQ) Meter"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] opacity-75 mb-3",
						children: isRTL ? "الفروع الأربعة لنموذج ماير وسالوفي (الوعي، التعاطف، التنظيم، المهارة الاجتماعية)" : "Four Mayer-Salovey branches: Self-Awareness, Empathy, Regulation & Social Competence"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col sm:flex-row items-center gap-4 my-auto",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative w-32 h-32 shrink-0 flex items-center justify-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
								viewBox: "0 0 110 110",
								className: "w-full h-full -rotate-90",
								"aria-label": isRTL ? `مؤشر الذكاء العاطفي ${overallEI}%` : `Emotional Intelligence Index ${overallEI}%`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
									cx: "55",
									cy: "55",
									r: gaugeRadius,
									fill: "none",
									stroke: isLight ? "#e2e8f0" : "rgba(255,255,255,0.1)",
									strokeWidth: "10"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
									cx: "55",
									cy: "55",
									r: gaugeRadius,
									fill: "none",
									stroke: "#ec4899",
									strokeWidth: "10",
									strokeLinecap: "round",
									strokeDasharray: gaugeCircumference,
									strokeDashoffset: gaugeDashOffset
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute inset-0 flex flex-col items-center justify-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-2xl font-black tabular-nums",
									children: [overallEI, "%"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] opacity-75 font-bold",
									children: isRTL ? "مؤشر EQ الكلي" : "Composite EQ"
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex-1 w-full space-y-2.5",
							children: eiData.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-xs font-bold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: b.branch }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "tabular-nums",
										style: { color: b.color },
										children: [b.score, "%"]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `w-full h-2.5 rounded-full overflow-hidden ${isLight ? "bg-slate-200" : "bg-white/10"}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-full rounded-full transition-all duration-500",
										style: {
											width: `${b.score}%`,
											backgroundColor: b.color
										}
									})
								})]
							}, b.branch))
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 lg:grid-cols-2 gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `rounded-2xl border p-4 ${cardBg}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "font-extrabold text-sm mb-1",
							children: isRTL ? "5. خريطة التعلق العاطفي ثنائية الأبعاد (ECR-R Quadrant)" : "5. Two-Dimensional Adult Attachment Space (ECR-R Quadrant)"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[11px] opacity-75 mb-3",
							children: [
								isRTL ? "التصنيف:" : "Classification:",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: isRTL ? charts.attachment?.styleAr : charts.attachment?.styleEn || translateText(charts.attachment?.styleAr || "") }),
								" ",
								"• ",
								isRTL ? "القلق:" : "Anxiety:",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "tabular-nums font-bold",
									children: [attAnxiety, "%"]
								}),
								" •",
								" ",
								isRTL ? "التجنب:" : "Avoidance:",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "tabular-nums font-bold",
									children: [attAvoidance, "%"]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative w-full aspect-[4/3] max-h-64 ltr-preserve",
							dir: "ltr",
							"data-keep-dir": "true",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
								viewBox: "0 0 320 220",
								className: "w-full h-full",
								role: "img",
								"aria-label": isRTL ? "خريطة التعلق العاطفي" : "Adult Attachment Quadrant Map",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
										x: "40",
										y: "15",
										width: "125",
										height: "85",
										rx: "6",
										fill: "rgba(245,158,11,0.12)",
										stroke: gridStroke
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
										x: "165",
										y: "15",
										width: "125",
										height: "85",
										rx: "6",
										fill: "rgba(244,63,94,0.14)",
										stroke: gridStroke
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
										x: "40",
										y: "100",
										width: "125",
										height: "85",
										rx: "6",
										fill: "rgba(16,185,129,0.16)",
										stroke: gridStroke
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
										x: "165",
										y: "100",
										width: "125",
										height: "85",
										rx: "6",
										fill: "rgba(249,115,22,0.12)",
										stroke: gridStroke
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
										x: "102",
										y: "34",
										textAnchor: "middle",
										fill: axisTextColor,
										fontSize: "10",
										fontWeight: "bold",
										children: isRTL ? "قلق متعطش (Anxious)" : "Anxious-Preoccupied"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
										x: "227",
										y: "34",
										textAnchor: "middle",
										fill: axisTextColor,
										fontSize: "10",
										fontWeight: "bold",
										children: isRTL ? "حذر متذبذب (Fearful)" : "Fearful-Avoidant"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
										x: "102",
										y: "175",
										textAnchor: "middle",
										fill: "#10b981",
										fontSize: "10.5",
										fontWeight: "bold",
										children: isRTL ? "آمن مستقر (Secure)" : "Secure Attachment"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
										x: "227",
										y: "175",
										textAnchor: "middle",
										fill: axisTextColor,
										fontSize: "10",
										fontWeight: "bold",
										children: isRTL ? "تجنبي مكتفٍ (Avoidant)" : "Dismissive-Avoidant"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
										x1: "165",
										y1: "15",
										x2: "165",
										y2: "185",
										stroke: axisTextColor,
										strokeOpacity: "0.35",
										strokeDasharray: "3 3"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
										x1: "40",
										y1: "100",
										x2: "290",
										y2: "100",
										stroke: axisTextColor,
										strokeOpacity: "0.35",
										strokeDasharray: "3 3"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
										x: "165",
										y: "206",
										textAnchor: "middle",
										fill: axisTextColor,
										fontSize: "10",
										children: isRTL ? "محور التجنب (Avoidance: 0% ⟶ 100%)" : "Attachment Avoidance (0% ⟶ 100%)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
										x: "16",
										y: "100",
										textAnchor: "middle",
										fill: axisTextColor,
										fontSize: "10",
										transform: "rotate(-90 16 100)",
										children: isRTL ? "قلق الهجر (Anxiety %)" : "Attachment Anxiety (%)"
									}),
									(() => {
										const cx = 40 + attAvoidance / 100 * 250;
										const cy = 185 - attAnxiety / 100 * 170;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
											cx,
											cy,
											r: "13",
											fill: "rgba(139,92,246,0.28)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
											cx,
											cy,
											r: "6.5",
											fill: "#8b5cf6",
											stroke: "#ffffff",
											strokeWidth: "2"
										})] });
									})()
								]
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `rounded-2xl border p-4 ${cardBg}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "font-extrabold text-sm mb-1",
							children: isRTL ? "6. مصفوفة التوافق العلائقي التفاعلية (4×4 Matrix)" : "6. Interactive Dyadic Synergy Matrix (4×4)"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] opacity-75 mb-3",
							children: isRTL ? "انقر على أي خلية لقراءة تفسير التآزر بين ركائز الاستقرار والذكاء العاطفي" : "Click any cell to inspect dyadic synergy across emotional stability and relational pillars"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-4 gap-1.5",
							children: (charts.compatibilityMatrix || []).slice(0, 16).map((cell, idx) => {
								const s = safeVal(cell.synergyScore);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setSelectedCell(selectedCell === idx ? null : idx),
									className: `p-2 rounded-xl border text-center transition hover:scale-[1.03] cursor-pointer ${s >= 75 ? "bg-emerald-500/20 border-emerald-500/40 text-emerald-500" : s >= 50 ? "bg-indigo-500/20 border-indigo-500/40 text-indigo-400" : "bg-amber-500/20 border-amber-500/40 text-amber-500"} ${selectedCell === idx ? "ring-2 ring-purple-500" : ""}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-sm font-black tabular-nums",
										children: [s, "%"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[9.5px] font-bold truncate opacity-90",
										children: isRTL ? cell.labelAr : translateText(cell.labelAr)
									})]
								}, `${cell.axisA}_${cell.axisB}_${idx}`);
							})
						}),
						selectedCell !== null && charts.compatibilityMatrix?.[selectedCell] && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `mt-2.5 p-2.5 rounded-xl text-xs border ${isLight ? "bg-slate-50 border-slate-200" : "bg-black/30 border-white/10"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-extrabold",
									children: [
										isRTL ? charts.compatibilityMatrix[selectedCell].axisA : translateText(charts.compatibilityMatrix[selectedCell].axisA),
										" ",
										"×",
										" ",
										isRTL ? charts.compatibilityMatrix[selectedCell].axisB : translateText(charts.compatibilityMatrix[selectedCell].axisB),
										":"
									]
								}),
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-bold text-purple-400 tabular-nums",
									children: [safeVal(charts.compatibilityMatrix[selectedCell].synergyScore), "%"]
								}),
								" ",
								"—",
								" ",
								isRTL ? charts.compatibilityMatrix[selectedCell].labelAr : translateText(charts.compatibilityMatrix[selectedCell].labelAr)
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 lg:grid-cols-3 gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `rounded-2xl border p-4 ${cardBg}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
								className: "font-extrabold text-sm mb-1",
								children: isRTL ? "7. أنماط التواصل الحواري" : "7. Communication Styles Profile"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] opacity-75 mb-2",
								children: isRTL ? "توزيع الحزم والإنصات والتحليل والدفء" : "Distribution of Assertive, Reflective, Analytical & Expressive styles"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-full h-56 ltr-preserve",
								dir: "ltr",
								"data-keep-dir": "true",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
									width: "100%",
									height: "100%",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
										data: commData,
										layout: "vertical",
										margin: {
											left: 10,
											right: 16,
											top: 6,
											bottom: 6
										},
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
												stroke: gridStroke,
												horizontal: false
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
												type: "number",
												domain: [0, 100],
												tick: {
													fill: axisTextColor,
													fontSize: 10
												}
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
												type: "category",
												dataKey: "style",
												width: 105,
												tick: {
													fill: axisTextColor,
													fontSize: 10
												}
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: tooltipStyle }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
												dataKey: "score",
												name: isRTL ? "النسبة %" : "Score %",
												radius: [
													0,
													6,
													6,
													0
												],
												children: commData.map((entry, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: entry.color || "#3b82f6" }, `comm_${idx}`))
											})
										]
									})
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `rounded-2xl border p-4 ${cardBg}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
								className: "font-extrabold text-sm mb-1",
								children: isRTL ? "8. خريطة إدارة النزاعات (TKI)" : "8. Conflict Resolution Modes (TKI)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] opacity-75 mb-2",
								children: isRTL ? "أوضاع توماس-كيلمان الخمسة عند الخلاف" : "Thomas-Kilmann 5 conflict-handling orientations"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-full h-56 ltr-preserve",
								dir: "ltr",
								"data-keep-dir": "true",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
									width: "100%",
									height: "100%",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(RadarChart, {
										data: conflictData,
										outerRadius: "65%",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarGrid, { stroke: gridStroke }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarAngleAxis, {
												dataKey: "mode",
												tick: {
													fill: axisTextColor,
													fontSize: 10
												}
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarRadiusAxis, {
												angle: 90,
												domain: [0, 100],
												tick: {
													fill: axisTextColor,
													fontSize: 9
												}
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radar, {
												name: isRTL ? "استجابة النزاع %" : "Conflict Mode %",
												dataKey: "score",
												stroke: "#f59e0b",
												fill: "#f59e0b",
												fillOpacity: .38,
												strokeWidth: 2
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: tooltipStyle })
										]
									})
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `rounded-2xl border p-4 ${cardBg}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
								className: "font-extrabold text-sm mb-1",
								children: isRTL ? "9. اتساق أهداف الحياة (PERMA)" : "9. Life Goals Alignment (PERMA)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] opacity-75 mb-2",
								children: isRTL ? "مؤشر أهدافك مقابل هدف الازدهار الأسري" : "Your goal alignment vs. normative family flourishing"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-full h-56 ltr-preserve",
								dir: "ltr",
								"data-keep-dir": "true",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
									width: "100%",
									height: "100%",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
										data: goalsData,
										margin: {
											top: 8,
											right: 10,
											left: -12,
											bottom: 8
										},
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
												stroke: gridStroke,
												vertical: false
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
												dataKey: "domain",
												tick: {
													fill: axisTextColor,
													fontSize: 9.5
												},
												interval: 0
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
												domain: [0, 100],
												tick: {
													fill: axisTextColor,
													fontSize: 10
												}
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: tooltipStyle }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, { wrapperStyle: { fontSize: "10.5px" } }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
												dataKey: "userScore",
												name: isRTL ? "هدفك %" : "Your Score %",
												fill: "#14b8a6",
												radius: [
													4,
													4,
													0,
													0
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
												dataKey: "targetBenchmark",
												name: isRTL ? "المعيار" : "Benchmark",
												fill: "#94a3b8",
												radius: [
													4,
													4,
													0,
													0
												]
											})
										]
									})
								})
							})
						]
					})
				]
			})
		]
	});
};
//#endregion
export { ScientificVisualDashboards };
