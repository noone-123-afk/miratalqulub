import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { D as Sparkles, Dt as Laugh, En as Brain, Ft as HeartHandshake, It as Handshake, Lt as Globe, N as Shield, Nn as ArrowRight, O as Sparkle, P as ShieldCheck, Pt as Heart, S as Sun, Tn as Briefcase, Tt as Leaf, Zt as DoorOpen, an as Compass, at as PanelsTopLeft, b as Target, cn as Clock, gt as MapPin, k as Smile, m as TrendingUp, n as Zap, on as Coffee, ot as Palette, pt as MessageCircleHeart, q as Rocket, qt as Feather, s as Users, tn as Crown, zt as Gift } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import { d as useAppTheme, l as useLanguage, o as TestScoringTrustBanner } from "./index-C5uCeetQ.js";
import { n as AnimatePresence, t as motion } from "./vendor-motion-BS7ODJw7.js";
import { r as ScientificClinicalDisclaimerBanner } from "./PsychometricAcademicFraming-DuCcNyEP.js";
import { NATIONALITY_DATABASE, detectUserLocationAndNationality, getNationalityEntryByCountry, refineEthnicPromptWithQuizAnswers } from "./locationNationalityDetector-u5K3h3nb.js";
//#region src/components/QuizStep.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var ICON_MAP = {
	Coffee: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coffee, { className: "w-5 h-5" }),
	Compass: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "w-5 h-5" }),
	Users: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "w-5 h-5" }),
	Target: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, { className: "w-5 h-5" }),
	Shield: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "w-5 h-5" }),
	Smile: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smile, { className: "w-5 h-5" }),
	Gift: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gift, { className: "w-5 h-5" }),
	Laugh: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Laugh, { className: "w-5 h-5" }),
	MessageCircleHeart: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircleHeart, { className: "w-5 h-5" }),
	Clock: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "w-5 h-5" }),
	Handshake: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Handshake, { className: "w-5 h-5" }),
	Sparkle: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkle, { className: "w-5 h-5" }),
	Brain: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "w-5 h-5" }),
	HeartHandshake: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeartHandshake, { className: "w-5 h-5" }),
	Feather: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feather, { className: "w-5 h-5" }),
	Crown: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crown, { className: "w-5 h-5" }),
	Zap: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "w-5 h-5" }),
	ShieldCheck: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "w-5 h-5" }),
	TrendingUp: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "w-5 h-5" }),
	Sun: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "w-5 h-5" }),
	DoorOpen: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DoorOpen, { className: "w-5 h-5" }),
	Layout: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelsTopLeft, { className: "w-5 h-5" }),
	Palette: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Palette, { className: "w-5 h-5" }),
	Globe: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "w-5 h-5" }),
	Briefcase: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "w-5 h-5" }),
	Heart: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "w-5 h-5" }),
	Leaf: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Leaf, { className: "w-5 h-5" }),
	Rocket: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rocket, { className: "w-5 h-5" })
};
var questionVariants = {
	initial: {
		opacity: 0,
		x: 28
	},
	animate: {
		opacity: 1,
		x: 0,
		transition: {
			duration: .35,
			ease: [
				.16,
				1,
				.3,
				1
			]
		}
	},
	exit: {
		opacity: 0,
		x: -28,
		transition: {
			duration: .22,
			ease: [
				.4,
				0,
				1,
				1
			]
		}
	}
};
var optionsContainerVariants = {
	hidden: { opacity: 0 },
	visible: {
		opacity: 1,
		transition: { staggerChildren: .06 }
	}
};
var optionItemVariants = {
	hidden: {
		opacity: 0,
		y: 12
	},
	visible: {
		opacity: 1,
		y: 0,
		transition: {
			duration: .35,
			ease: [
				.16,
				1,
				.3,
				1
			]
		}
	}
};
var PARTNER_QUIZ_AUTOSAVE_KEY = "mirat_partner_quiz_autosave_v2";
var QuizStep = ({ questions, profile, onComplete, onBackToProfile }) => {
	const { direction, language } = useLanguage();
	const [theme] = useAppTheme();
	const isAr = language === "ar";
	const isLight = theme === "light";
	const partnerGender = profile?.partnerGender || "female";
	const [currentIndex, setCurrentIndex] = (0, import_react.useState)(() => {
		try {
			const saved = localStorage.getItem(PARTNER_QUIZ_AUTOSAVE_KEY);
			if (saved) {
				const parsed = JSON.parse(saved);
				if (typeof parsed.currentIndex === "number" && parsed.currentIndex < questions.length) return parsed.currentIndex;
			}
		} catch {}
		return 0;
	});
	const [answers, setAnswers] = (0, import_react.useState)(() => {
		try {
			const saved = localStorage.getItem(PARTNER_QUIZ_AUTOSAVE_KEY);
			if (saved) {
				const parsed = JSON.parse(saved);
				if (parsed.answers && typeof parsed.answers === "object") return parsed.answers;
			}
		} catch {}
		return {};
	});
	const [detectedLocation, setDetectedLocation] = (0, import_react.useState)(() => getNationalityEntryByCountry(profile?.detectedCountryCode || profile?.country || "SA", partnerGender));
	const [isDetectingLocation, setIsDetectingLocation] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		let mounted = true;
		setIsDetectingLocation(true);
		detectUserLocationAndNationality({
			partnerGender,
			fallbackCountry: profile?.country,
			answers
		}).then((detected) => {
			if (!mounted) return;
			setDetectedLocation(detected);
			setIsDetectingLocation(false);
		});
		return () => {
			mounted = false;
		};
	}, [partnerGender, profile?.country]);
	const [selectedOptionId, setSelectedOptionId] = (0, import_react.useState)(null);
	const currentQ = questions[currentIndex] || questions[0];
	const progressPercent = Math.round((currentIndex + 1) / questions.length * 100);
	const handleManualNationalityOverride = (countryCode) => {
		soundManager.playTap();
		const manualEntry = getNationalityEntryByCountry(countryCode, partnerGender);
		const refined = refineEthnicPromptWithQuizAnswers(manualEntry, answers, partnerGender);
		setDetectedLocation({
			...refined,
			detectionSource: "manual"
		});
	};
	const handleResetQuiz = () => {
		soundManager.playTap();
		try {
			localStorage.removeItem(PARTNER_QUIZ_AUTOSAVE_KEY);
		} catch {}
		setAnswers({});
		setCurrentIndex(0);
		setSelectedOptionId(null);
	};
	const handleSelectOption = (optionId) => {
		soundManager.playTap();
		setSelectedOptionId(optionId);
		const updatedAnswers = {
			...answers,
			[currentQ.id]: optionId
		};
		setAnswers(updatedAnswers);
		const refinedLocation = refineEthnicPromptWithQuizAnswers(detectedLocation, updatedAnswers, partnerGender);
		setDetectedLocation(refinedLocation);
		setTimeout(() => {
			if (currentIndex < questions.length - 1) {
				soundManager.playPageTransition();
				const nextIndex = currentIndex + 1;
				setCurrentIndex(nextIndex);
				setSelectedOptionId(null);
				try {
					localStorage.setItem(PARTNER_QUIZ_AUTOSAVE_KEY, JSON.stringify({
						answers: updatedAnswers,
						currentIndex: nextIndex,
						updatedAt: (/* @__PURE__ */ new Date()).toISOString()
					}));
				} catch {}
			} else {
				soundManager.playPageTransition();
				try {
					localStorage.removeItem(PARTNER_QUIZ_AUTOSAVE_KEY);
				} catch {}
				onComplete(updatedAnswers, refinedLocation);
			}
		}, 280);
	};
	const handlePrevious = () => {
		soundManager.playPageTransition();
		if (currentIndex > 0) {
			const prevIdx = currentIndex - 1;
			setCurrentIndex(prevIdx);
			setSelectedOptionId(null);
		} else onBackToProfile();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `w-full max-w-xl mx-auto px-4 py-4 ${isLight ? "text-slate-900" : "text-white"}`,
		dir: direction,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScientificClinicalDisclaimerBanner, {
				testType: "compatibility",
				testTitleAr: "اختبار التوافق النفسي والقيمي للشريك",
				testTitleEn: "Partner Psychological & Values Compatibility Quiz",
				compact: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TestScoringTrustBanner, { compact: true })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `mb-4 p-3.5 rounded-2xl border transition-colors ${isLight ? "bg-emerald-50/80 border-emerald-200 text-slate-800 shadow-sm" : "bg-emerald-950/35 border-emerald-500/30 text-white"}`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-7 h-7 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-500 shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "w-4 h-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1.5 flex-wrap",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] font-extrabold text-emerald-600 dark:text-emerald-300",
								children: isAr ? "اكتشاف تلقائي للموقع والجنسية لتوجيه ملامح صورة الشريك بالذكاء الاصطناعي:" : "Auto-Detected Location & Nationality for AI Partner Ethnic Realism:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-600 dark:text-emerald-300 border border-emerald-500/30",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: detectedLocation.flag }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: detectedLocation.countryNameAr }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: detectedLocation.nationalityAr })
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: `text-[11px] mt-1 leading-relaxed ${isLight ? "text-slate-600" : "text-slate-300"}`,
							children: isDetectingLocation ? isAr ? "جاري معايرة الموقع الجغرافي والملامح العرقية الواقعية أثناء إجابتك..." : "Calibrating location and realistic ethnic facial features..." : detectedLocation.ethnicFacialTraitsDescriptionAr
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1.5 ms-auto",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "quiz-nationality-select",
							className: "text-[10px] font-bold opacity-75",
							children: isAr ? "تعديل الجنسية:" : "Change:"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							id: "quiz-nationality-select",
							"aria-label": isAr ? "تعديل الجنسية المكتشفة" : "Change Detected Nationality",
							title: isAr ? "تعديل الجنسية المكتشفة" : "Change Detected Nationality",
							value: detectedLocation.countryCode,
							onChange: (e) => handleManualNationalityOverride(e.target.value),
							className: `px-2 py-1 rounded-lg border text-[11px] font-bold cursor-pointer ${isLight ? "bg-white border-emerald-300 text-slate-800" : "bg-slate-900 border-emerald-500/40 text-white"}`,
							children: Object.values(NATIONALITY_DATABASE).map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: entry.code,
								children: [
									entry.flag,
									" ",
									entry.nameAr,
									" (",
									entry.nationalityAr,
									")"
								]
							}, entry.code))
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6 space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `flex items-center justify-between text-xs ${isLight ? "text-slate-600" : "text-gray-300"}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
								whileHover: { scale: 1.05 },
								whileTap: { scale: .95 },
								onClick: handlePrevious,
								className: `flex items-center gap-1 hover:text-rose-500 transition cursor-pointer py-1 px-2.5 rounded-lg border ${isLight ? "bg-white border-slate-200 text-slate-700" : "bg-white/5 border-white/10 text-gray-200"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: `w-3.5 h-3.5 ${direction === "ltr" ? "rotate-180" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "السابق" : "Previous" })]
							}), Object.keys(answers).length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: handleResetQuiz,
								"aria-label": isAr ? "إعادة الاختبار من الأول" : "Reset quiz from start",
								title: isAr ? "إعادة الاختبار من الأول" : "Reset quiz from start",
								className: `py-1 px-2 rounded-lg border text-[10px] transition cursor-pointer ${isLight ? "bg-slate-100 hover:bg-rose-50 text-slate-600 hover:text-rose-600 border-slate-200" : "bg-white/5 hover:bg-rose-500/20 text-gray-400 hover:text-rose-300 border-white/10"}`,
								children: isAr ? "إعادة من الأول" : "Reset"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `font-bold font-['Alexandria',sans-serif] ${isLight ? "text-rose-600" : "text-rose-300"}`,
							children: isAr ? `السؤال ${currentIndex + 1} من ${questions.length}` : `Question ${currentIndex + 1} of ${questions.length}`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `text-[10px] hidden sm:inline ${isLight ? "text-emerald-600 font-bold" : "text-emerald-400"}`,
								children: isAr ? "● حفظ تلقائي" : "● Auto-saved"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: `font-semibold ${isLight ? "text-slate-600" : "text-gray-400"}`,
								children: [progressPercent, "%"]
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `w-full h-2 rounded-full overflow-hidden ${isLight ? "bg-slate-200" : "bg-white/10"}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
						className: "h-full bg-gradient-to-l from-rose-500 via-pink-500 to-violet-500 rounded-full",
						initial: { width: 0 },
						animate: { width: `${progressPercent}%` },
						transition: {
							duration: .35,
							ease: "easeInOut"
						}
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, {
				mode: "wait",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					variants: questionVariants,
					initial: "initial",
					animate: "animate",
					exit: "exit",
					className: "space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `p-6 rounded-3xl border ${isLight ? "bg-white border-slate-200 shadow-lg" : "glass-panel-glow border-white/15"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2 mb-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border ${isLight ? "bg-rose-50 text-rose-700 border-rose-200" : "bg-rose-500/20 text-rose-300 border-rose-500/30"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-3.5 h-3.5 text-rose-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: currentQ.category })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `text-[10px] px-2 py-0.5 rounded-full border ${isLight ? "bg-slate-100 text-slate-600 border-slate-200" : "text-gray-400 bg-white/5 border-white/10"}`,
									children: currentQ.scientificDimension
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: `text-xl sm:text-2xl font-extrabold leading-snug mb-2 font-['Alexandria'] ${isLight ? "text-slate-900" : "text-white"}`,
								children: currentQ.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: `text-xs sm:text-sm ${isLight ? "text-slate-600" : "text-gray-300"}`,
								children: currentQ.subtitle
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
						variants: optionsContainerVariants,
						initial: "hidden",
						animate: "visible",
						className: "space-y-3",
						children: currentQ.options.map((option) => {
							const isChosen = selectedOptionId === option.id || answers[currentQ.id] === option.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
								variants: optionItemVariants,
								whileHover: {
									scale: 1.015,
									x: -3
								},
								whileTap: { scale: .985 },
								type: "button",
								onClick: () => handleSelectOption(option.id),
								className: `w-full p-4 rounded-2xl border text-start transition-colors duration-200 flex items-start gap-3.5 cursor-pointer ${isChosen ? isLight ? "bg-rose-50 border-rose-400 shadow-md text-slate-900" : "bg-gradient-to-l from-rose-500/30 to-violet-600/30 border-rose-400 shadow-lg shadow-rose-500/25 text-white" : isLight ? "bg-white hover:bg-slate-50 border-slate-200 text-slate-800 hover:border-rose-300 shadow-sm" : "bg-[#15102a]/80 hover:bg-[#1a1435] border-white/10 text-gray-200 hover:border-white/20"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `w-10 h-10 rounded-xl shrink-0 flex items-center justify-center transition-transform ${isChosen ? "bg-rose-500 text-white shadow-md shadow-rose-500/30 scale-105" : isLight ? "bg-slate-100 text-slate-600" : "bg-white/10 text-gray-300"}`,
									children: ICON_MAP[option.icon] || /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-5 h-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1 min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `font-bold text-sm sm:text-base leading-snug mb-1 ${isLight ? "text-slate-900" : "text-white"}`,
										children: option.text
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `text-xs leading-relaxed ${isLight ? "text-slate-600" : "text-gray-400"}`,
										children: option.description
									})]
								})]
							}, option.id);
						})
					})]
				}, currentQ.id)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: `text-center text-xs mt-6 ${isLight ? "text-slate-500" : "text-gray-400"}`,
				children: isAr ? "اختر الإجابة الأقرب لعفويتك وطبيعتك لتكون النتيجة الاستكشافية أكثر دقة وواقعية ✨" : "Choose the answer closest to your natural behavior for a more accurate exploratory result ✨"
			})
		]
	});
};
//#endregion
export { QuizStep };
