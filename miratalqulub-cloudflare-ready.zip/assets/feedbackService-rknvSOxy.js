import { t as db } from "./firebase-Cu7XUsbK.js";
import { a as orderBy, l as collection, o as query, r as getDocs, s as setDoc, u as doc } from "./vendor-firebase-firestore-nFD0fmjQ.js";
//#region src/services/feedbackService.ts
var OFFICIAL_EMAIL = "one497303@gmail.com";
/**
* Submit visitor feedback/contact message
*/
async function submitFeedbackMessage(data) {
	const messageId = `msg_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
	const now = (/* @__PURE__ */ new Date()).toISOString();
	const feedbackDoc = {
		id: messageId,
		name: data.name.trim(),
		email: data.email.trim(),
		subject: data.subject.trim(),
		message: data.message.trim(),
		category: data.category,
		categoryLabelAr: data.categoryLabelAr,
		rating: data.rating || 5,
		userId: data.user?.uid,
		createdAt: now,
		status: "new"
	};
	try {
		const existing = JSON.parse(localStorage.getItem("mirat_real_feedback_messages") || "[]");
		localStorage.setItem("mirat_real_feedback_messages", JSON.stringify([feedbackDoc, ...existing].slice(0, 50)));
	} catch {}
	try {
		const feedbackRef = doc(db, "feedback_messages", messageId);
		await setDoc(feedbackRef, feedbackDoc);
	} catch (err) {
		console.warn("Could not write directly to Firestore feedback_messages, using server endpoint", err);
	}
	try {
		await fetch("/api/feedback", {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(feedbackDoc)
		});
	} catch (err) {
		console.warn("Server feedback API call failed", err);
	}
	return {
		success: true,
		messageId,
		mailtoUrl: `mailto:${OFFICIAL_EMAIL}?subject=${encodeURIComponent(`[مرآة القلوب - ${data.categoryLabelAr}] ${data.subject}`)}&body=${encodeURIComponent(`السلام عليكم ورحمة الله،\n\nالاسم: ${data.name}\nالبريد الإلكتروني: ${data.email}\nالقسم/التصنيف: ${data.categoryLabelAr}\nالتقييم: ${data.rating || 5} نجوم\n\nنص الرسالة والملاحظة:\n${data.message}\n\n---\nأُرسلت عبر نموذج الملاحظات والتواصل في منصة مِـرآة القـلوب\nالتاريخ: ${(/* @__PURE__ */ new Date()).toLocaleString("ar")}`)}`
	};
}
/**
* Fetch all real feedback messages (Strictly genuine user submissions only, no fake demo items)
*/
async function fetchFeedbackMessages() {
	try {
		const colRef = collection(db, "feedback_messages");
		const q = query(colRef, orderBy("createdAt", "desc"));
		const snapshot = await getDocs(q);
		const list = [];
		snapshot.forEach((d) => {
			list.push(d.data());
		});
		if (list.length > 0) {
			try {
				localStorage.setItem("mirat_real_feedback_messages", JSON.stringify(list));
			} catch {}
			return list;
		}
	} catch (err) {
		console.warn("Could not read feedback_messages from Firestore, trying server endpoint", err);
	}
	try {
		const res = await fetch("/api/feedback/list");
		if (res.ok) {
			const data = await res.json();
			if (data.success && Array.isArray(data.messages) && data.messages.length > 0) return data.messages;
		}
	} catch {}
	try {
		const raw = localStorage.getItem("mirat_real_feedback_messages");
		if (raw) {
			const parsed = JSON.parse(raw);
			if (Array.isArray(parsed)) return parsed;
		}
	} catch {}
	return [];
}
//#endregion
export { fetchFeedbackMessages as n, submitFeedbackMessage as r, OFFICIAL_EMAIL as t };
