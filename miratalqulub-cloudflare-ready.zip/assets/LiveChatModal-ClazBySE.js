import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { B as Send, D as Sparkles, J as RefreshCw, X as Radar, Y as Radio, lt as Mic, r as X, s as Users, vt as LogOut } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import { t as motion } from "./vendor-motion-BS7ODJw7.js";
import { n as useLiveChat, t as VoiceToneAnalysisModal } from "./VoiceToneAnalysisModal-CAU2y-QM.js";
//#region src/components/LiveChatModal.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var ICEBREAKERS = [
	"ما هي أهم قيمة تبحث عنها في شريك الحياة؟ 🌟",
	"ما هو نمط يومك المثالي في نهاية الأسبوع؟ ☕",
	"كيف تحب أن يعبّر لك الطرف الآخر عن التقدير والاهتمام؟ 💖",
	"ما هو حلمك الأكبر الذي تسعى لتحقيقه قريباً؟ 🚀",
	"أي المدن أو الأماكن الطبيعية هي الأقرب لقلبك؟ ✈️"
];
var LiveChatModal = ({ isOpen, onClose, profile, onOpenBlindDate }) => {
	const { isConnected, myUserId, status, partner, compatibilityScore, compatibilityReason, messages, partnerIsTyping, partnerLeftMessage, onlineCount, searchingCount, startSearch, cancelSearch, sendMessage, sendTyping, leaveChat } = useLiveChat(profile);
	const [inputText, setInputText] = (0, import_react.useState)("");
	const [isVoiceModalOpen, setIsVoiceModalOpen] = (0, import_react.useState)(false);
	const messagesEndRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
	}, [messages, partnerIsTyping]);
	if (!isOpen) return null;
	const handleSend = (e) => {
		if (e) e.preventDefault();
		if (!inputText.trim()) return;
		soundManager.playTap();
		sendMessage(inputText);
		setInputText("");
		sendTyping(false);
	};
	const handleInputChange = (e) => {
		setInputText(e.target.value);
		sendTyping(e.target.value.length > 0);
	};
	const handleIcebreakerClick = (prompt) => {
		soundManager.playTap();
		sendMessage(prompt);
	};
	const userGenderText = profile?.userGender === "male" ? "شاب" : "فتاة";
	const partnerGenderText = profile?.partnerGender === "female" ? "فتاة" : "شاب";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md",
		dir: "rtl",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: {
				opacity: 0,
				scale: .95,
				y: 15
			},
			animate: {
				opacity: 1,
				scale: 1,
				y: 0
			},
			exit: {
				opacity: 0,
				scale: .95,
				y: 15
			},
			className: "w-full max-w-xl bg-slate-950 border border-rose-500/30 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-4 bg-gradient-to-r from-purple-950/80 via-slate-900 to-rose-950/80 border-b border-white/10 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-10 h-10 rounded-2xl bg-gradient-to-br from-rose-500 to-purple-600 flex items-center justify-center text-white shadow-md shadow-rose-500/20",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "w-5 h-5 animate-pulse" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -top-1 -right-1 w-3 h-3 bg-emerald-400 rounded-full border-2 border-slate-950 animate-ping" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -top-1 -right-1 w-3 h-3 bg-emerald-400 rounded-full border-2 border-slate-950" })
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-base font-extrabold text-white font-['Alexandria']",
								children: "رادار التوافق والدردشة الحية"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-[10px] text-emerald-300 font-bold",
								children: "مباشر 🟢"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-gray-300",
							children: "مطابقة فورية للمتواجدين في الوقت نفسه إذا تشابهت المواصفات"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-white/5 border border-white/10 text-[11px] text-gray-300",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "w-3.5 h-3.5 text-rose-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["متواجدون الآن: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: onlineCount })] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								soundManager.playTap();
								onClose();
							},
							className: "p-2 rounded-xl bg-white/10 hover:bg-white/20 text-gray-300 hover:text-white transition cursor-pointer",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-4 h-4" })
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 overflow-y-auto p-4 space-y-4",
					children: [
						status === "idle" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "py-4 space-y-4 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
									initial: { scale: .9 },
									animate: { scale: 1 },
									className: "w-20 h-20 mx-auto rounded-3xl bg-gradient-to-tr from-rose-600/30 via-purple-600/30 to-amber-500/20 border border-rose-500/40 flex items-center justify-center text-4xl shadow-inner shadow-rose-500/20",
									children: "📡"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: "text-lg font-bold text-white font-['Alexandria']",
										children: "ابحث عن شخص متواجد الآن يطابق مواصفاتك"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-gray-300 max-w-md mx-auto leading-relaxed",
										children: "يقوم الرادار بفحص المتصلين حالياً على المنصة في نفس اللحظة، وإذا وجد تطابقاً متبادلاً في الرغبات والمواصفات للطرفين يفتح غرفة محادثة حية ومباشرة."
									})]
								}),
								profile && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3.5 rounded-2xl bg-white/5 border border-white/10 max-w-md mx-auto text-xs text-right space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between text-rose-300 font-bold border-b border-white/10 pb-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "مواصفاتك المسجلة للبحث:" })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] text-gray-400",
											children: "هويتك محمية ومجهولة 🔒"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-2 gap-2 text-gray-300 text-[11px]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-gray-400",
												children: "أنت: "
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [
												profile.userName || userGenderText,
												" (",
												profile.userAge,
												" عاماً)"
											] })] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-gray-400",
												children: "تبحث عن: "
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-rose-300",
												children: partnerGenderText
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-gray-400",
												children: "البلد: "
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: profile.country })] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-gray-400",
												children: "الثقافة: "
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: profile.ethnicity })] })
										]
									})]
								}),
								partnerLeftMessage && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3 rounded-2xl bg-amber-500/20 border border-amber-500/30 text-amber-200 text-xs",
									children: ["ℹ️ ", partnerLeftMessage]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "pt-2 space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
										whileHover: { scale: 1.03 },
										whileTap: { scale: .97 },
										onClick: startSearch,
										className: "w-full max-w-md py-3.5 px-6 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:opacity-95 text-white font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/30 transition cursor-pointer mx-auto",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radar, {
											className: "w-4 h-4 animate-spin",
											style: { animationDuration: "6s" }
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "بدء البحث بالرادار المباشر عن متصل متوافق 🟢" })]
									}), onOpenBlindDate && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
										whileHover: { scale: 1.03 },
										whileTap: { scale: .97 },
										onClick: () => {
											soundManager.playTap();
											onClose();
											onOpenBlindDate();
										},
										className: "w-full max-w-md py-3.5 px-6 rounded-2xl bg-gradient-to-r from-rose-500 via-pink-500 to-purple-600 hover:opacity-95 text-white font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg shadow-rose-500/30 transition cursor-pointer mx-auto",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "🎬 الانتقال إلى عرض The Blind Date Show التلفزيوني" })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3 rounded-2xl bg-purple-500/10 border border-purple-500/20 text-[11px] text-purple-200 max-w-md mx-auto text-right space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex items-center gap-1.5 font-bold text-amber-300",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "💡 نصيحة للتجربة الفورية:" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-gray-300 leading-relaxed",
										children: [
											"يمكنك فتح هذا الرابط في ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "نافذة خاصة ثانية (Incognito)" }),
											" أو على جهاز آخر؛ وبمجرد النقر على البحث في النافذتين سيتم ربطهما في دردشة حية فورية ومتبادلة!"
										]
									})]
								})
							]
						}),
						status === "searching" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "py-8 space-y-6 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative w-36 h-36 mx-auto flex items-center justify-center",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
											animate: {
												scale: [
													1,
													1.8,
													2.2
												],
												opacity: [
													.6,
													.2,
													0
												]
											},
											transition: {
												repeat: Infinity,
												duration: 2.2,
												ease: "easeOut"
											},
											className: "absolute inset-0 rounded-full border-2 border-rose-500"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
											animate: {
												scale: [
													1,
													1.4,
													1.8
												],
												opacity: [
													.7,
													.3,
													0
												]
											},
											transition: {
												repeat: Infinity,
												duration: 2.2,
												delay: .6,
												ease: "easeOut"
											},
											className: "absolute inset-0 rounded-full border-2 border-purple-500"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-20 h-20 rounded-full bg-gradient-to-br from-rose-500 to-purple-600 flex items-center justify-center text-white text-3xl shadow-xl shadow-rose-500/30 relative z-10 animate-pulse",
											children: "📡"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
										className: "text-lg font-bold text-white font-['Alexandria'] flex items-center justify-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "جاري البحث عن متصلين متوافقين..." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "w-4 h-4 text-rose-400 animate-spin" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-gray-300 max-w-sm mx-auto leading-relaxed",
										children: "نقوم حالياً بفحص رغبات الشريك والمواصفات مع الأشخاص المتواجدين على المنصة في هذه اللحظة..."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-center gap-3 text-xs text-gray-400",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["المتواجدون: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-white",
											children: onlineCount
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["الباحثون عن تطابق: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-rose-400",
											children: searchingCount || 1
										})] })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
									whileHover: { scale: 1.02 },
									whileTap: { scale: .98 },
									onClick: cancelSearch,
									className: "py-2.5 px-6 rounded-2xl bg-white/10 hover:bg-white/15 border border-white/20 text-gray-300 text-xs font-semibold cursor-pointer transition",
									children: "إلغاء البحث والعودة"
								}) })
							]
						}),
						status === "in_chat" && partner && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col h-full space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
									initial: {
										opacity: 0,
										y: -10
									},
									animate: {
										opacity: 1,
										y: 0
									},
									className: "p-3.5 rounded-2xl bg-gradient-to-r from-rose-950/60 via-purple-950/60 to-slate-900 border border-rose-500/30 flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-12 h-12 rounded-2xl bg-gradient-to-tr from-rose-500 to-purple-600 flex items-center justify-center text-2xl shadow-md shadow-rose-500/20",
											children: partner.userGender === "male" ? "👨" : "👩"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-bold text-white text-sm font-['Alexandria']",
													children: partner.userName
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "px-2 py-0.5 rounded-full bg-rose-500/20 border border-rose-400/30 text-[10px] text-rose-300 font-bold",
													children: [
														"توافق ",
														compatibilityScore,
														"% ❤️"
													]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[11px] text-gray-300",
												children: [
													partner.country,
													" • ",
													partner.ethnicity,
													" • ",
													partner.userAge,
													" عاماً"
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] text-amber-300/90 mt-0.5",
												children: compatibilityReason
											})
										] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
										whileHover: { scale: 1.05 },
										whileTap: { scale: .95 },
										onClick: leaveChat,
										className: "p-2 rounded-xl bg-white/5 hover:bg-rose-500/20 text-gray-400 hover:text-rose-300 border border-white/10 transition cursor-pointer text-xs flex items-center gap-1",
										title: "إنهاء المحادثة",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "hidden sm:inline",
											children: "إنهاء"
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-h-[220px] max-h-[320px] overflow-y-auto space-y-2.5 p-2 rounded-2xl bg-black/40 border border-white/5 scrollbar-thin",
									children: [
										messages.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-center py-6 text-gray-400 text-xs space-y-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-bold text-rose-300",
												children: "🎉 بدأت المحادثة الحية بينكما بنجاح!"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "ألقِ التحية أو اختر أحد أسئلة التوافق المقترحة بالأسفل لبدء حوار ثري." })]
										}),
										messages.map((m) => {
											const isMe = m.senderId === myUserId;
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
												initial: {
													opacity: 0,
													y: 5
												},
												animate: {
													opacity: 1,
													y: 0
												},
												className: `flex flex-col ${isMe ? "items-end" : "items-start"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-1.5 mb-0.5 px-1 text-[10px] text-gray-400",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isMe ? "أنت" : partner.userName }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: new Date(m.timestamp).toLocaleTimeString("ar-SA", {
															hour: "2-digit",
															minute: "2-digit"
														}) })
													]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: `max-w-[85%] px-3.5 py-2.5 rounded-2xl text-xs leading-relaxed ${isMe ? "bg-gradient-to-r from-rose-600 to-pink-600 text-white rounded-tr-none shadow-md shadow-rose-500/10" : "bg-white/10 text-gray-100 rounded-tl-none border border-white/10 shadow-sm"}`,
													children: m.text
												})]
											}, m.id);
										}),
										partnerIsTyping && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 text-xs text-rose-300 py-1 px-2 italic",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex gap-1",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-1.5 h-1.5 rounded-full bg-rose-400 animate-bounce" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "w-1.5 h-1.5 rounded-full bg-rose-400 animate-bounce",
														style: { animationDelay: "0.15s" }
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "w-1.5 h-1.5 rounded-full bg-rose-400 animate-bounce",
														style: { animationDelay: "0.3s" }
													})
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [partner.userName, " يكتب الآن..."] })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { ref: messagesEndRef })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[11px] text-gray-400 block px-1",
										children: "💬 أسئلة مقترحة لكسر الجليد واستكشاف التوافق:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-thin",
										children: ICEBREAKERS.map((prompt, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => handleIcebreakerClick(prompt),
											className: "shrink-0 px-2.5 py-1 rounded-xl bg-white/5 hover:bg-white/15 border border-white/10 text-[11px] text-gray-300 hover:text-white transition cursor-pointer",
											children: prompt
										}, i))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									onSubmit: handleSend,
									className: "flex items-center gap-2 pt-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => {
												soundManager.playTap();
												setIsVoiceModalOpen(true);
											},
											className: "px-3 py-2.5 rounded-2xl bg-gradient-to-r from-rose-500/20 via-pink-500/20 to-purple-500/20 hover:from-rose-500/30 hover:to-purple-500/30 border border-rose-500/40 text-rose-300 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shrink-0 active:scale-95 shadow-sm",
											title: "تسجيل رسالة صوتية قصيرة وتحليل نبرة الصوت والمشاعر بواسطة الذكاء الاصطناعي",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "w-4 h-4 text-rose-400 animate-pulse" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "hidden sm:inline font-['Alexandria']",
													children: "تسجيل صوتي 🎙️"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "sm:hidden",
													children: "🎙️"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											value: inputText,
											onChange: handleInputChange,
											placeholder: "اكتب رسالتك باحترام ومودة...",
											className: "flex-1 px-4 py-2.5 rounded-2xl bg-white/5 border border-white/15 text-white placeholder-gray-500 text-xs focus:outline-none focus:border-rose-400"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
											whileHover: { scale: 1.05 },
											whileTap: { scale: .95 },
											type: "submit",
											disabled: !inputText.trim(),
											className: "p-2.5 px-4 rounded-2xl bg-gradient-to-r from-rose-500 to-purple-600 hover:opacity-95 text-white transition flex items-center justify-center gap-1.5 text-xs font-bold cursor-pointer disabled:opacity-40",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "إرسال" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "w-3.5 h-3.5 -rotate-90" })]
										})
									]
								})
							]
						})
					]
				}),
				partner && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VoiceToneAnalysisModal, {
					isOpen: isVoiceModalOpen,
					onClose: () => setIsVoiceModalOpen(false),
					partnerName: partner.userName,
					partnerGender: partner.userGender,
					userGender: profile?.userGender || "male",
					onSendVoiceMessageToChat: (record) => {
						const synergy = record.analysis?.vocalSynergyScore || 96;
						const archetype = record.analysis?.voiceToneArchetype || "نبرة صوتية دافئة";
						sendMessage(`🎙️ [رسالة صوتية ${record.duration}ث] • ${archetype} • نسبة التوافق الصوتي: ${synergy}%`);
					}
				})
			]
		})
	});
};
//#endregion
export { LiveChatModal };
