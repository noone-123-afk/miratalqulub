import { t as db } from "./firebase-Cu7XUsbK.js";
import { c as where, l as collection, n as getDoc, o as query, r as getDocs, s as setDoc, t as deleteDoc, u as doc } from "./vendor-firebase-firestore-nFD0fmjQ.js";
import { t as NOVELS_CATALOG } from "./data-content-CCe8WBeA.js";
//#region src/services/novelsService.ts
var LOCAL_CUSTOM_NOVELS_KEY = "mirat_owner_custom_novels";
var LOCAL_MODIFIED_NOVELS_KEY = "mirat_owner_modified_novels";
var LOCAL_HIDDEN_NOVELS_KEY = "mirat_owner_hidden_novels";
var LOCAL_COMMENTS_STORAGE_KEY = "mirat_novels_user_comments";
async function getNovelComments(novelId) {
	let localComments = [];
	try {
		const raw = localStorage.getItem(`${LOCAL_COMMENTS_STORAGE_KEY}_${novelId}`);
		if (raw) localComments = JSON.parse(raw);
	} catch {}
	try {
		const commentsRef = collection(db, "novel_comments");
		const q = query(commentsRef, where("novelId", "==", novelId));
		const snapshot = await getDocs(q);
		const firestoreComments = [];
		snapshot.forEach((d) => {
			const data = d.data();
			firestoreComments.push({
				id: d.id,
				novelId: data.novelId,
				userName: data.userName,
				userRoleTitle: data.userRoleTitle,
				rating: data.rating,
				commentText: data.commentText,
				createdAt: data.createdAt,
				likesCount: data.likesCount || 0
			});
		});
		if (firestoreComments.length > 0) {
			const existingIds = new Set(firestoreComments.map((c) => c.id));
			const combined = [...firestoreComments];
			localComments.forEach((c) => {
				if (!existingIds.has(c.id)) {
					combined.push(c);
					existingIds.add(c.id);
				}
			});
			return combined;
		}
	} catch {}
	return localComments;
}
async function addNovelComment(novelId, userName, rating, commentText, userRoleTitle) {
	const newComment = {
		id: `com_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
		novelId,
		userName: userName.trim() || "قارئ زائر",
		userRoleTitle: userRoleTitle?.trim() || "متابع للتحقيقات",
		rating: Math.max(1, Math.min(5, rating)),
		commentText: commentText.trim(),
		createdAt: "الآن",
		likesCount: 1
	};
	try {
		const raw = localStorage.getItem(`${LOCAL_COMMENTS_STORAGE_KEY}_${novelId}`);
		const updated = [newComment, ...raw ? JSON.parse(raw) : []];
		localStorage.setItem(`${LOCAL_COMMENTS_STORAGE_KEY}_${novelId}`, JSON.stringify(updated));
	} catch {}
	try {
		const commentDoc = doc(db, "novel_comments", newComment.id);
		await setDoc(commentDoc, {
			...newComment,
			timestamp: Date.now()
		});
	} catch (err) {
		console.warn("Could not sync comment to Firestore immediately, saved locally.", err);
	}
	return newComment;
}
async function likeNovelComment(commentId, novelId) {
	try {
		const raw = localStorage.getItem(`${LOCAL_COMMENTS_STORAGE_KEY}_${novelId}`);
		if (raw) {
			const updated = JSON.parse(raw).map((c) => c.id === commentId ? {
				...c,
				likesCount: c.likesCount + 1
			} : c);
			localStorage.setItem(`${LOCAL_COMMENTS_STORAGE_KEY}_${novelId}`, JSON.stringify(updated));
		}
	} catch {}
	try {
		const commentDoc = doc(db, "novel_comments", commentId);
		const snap = await getDoc(commentDoc);
		if (snap.exists()) {
			const currentLikes = snap.data().likesCount || 0;
			await setDoc(commentDoc, { likesCount: currentLikes + 1 }, { merge: true });
		}
	} catch {}
}
async function getHiddenNovelIds() {
	const hidden = /* @__PURE__ */ new Set();
	try {
		const raw = localStorage.getItem(LOCAL_HIDDEN_NOVELS_KEY);
		if (raw) JSON.parse(raw).forEach((id) => hidden.add(id));
	} catch {}
	try {
		(await getDocs(collection(db, "hidden_novels"))).forEach((d) => {
			hidden.add(d.id);
		});
	} catch {}
	return hidden;
}
async function getModifiedNovelsMap() {
	const map = {};
	try {
		const raw = localStorage.getItem(LOCAL_MODIFIED_NOVELS_KEY);
		if (raw) {
			const parsed = JSON.parse(raw);
			Object.assign(map, parsed);
		}
	} catch {}
	try {
		(await getDocs(collection(db, "modified_novels"))).forEach((d) => {
			const data = d.data();
			map[data.id] = data;
		});
	} catch {}
	return map;
}
async function getOwnerCustomNovels() {
	let list = [];
	try {
		const raw = localStorage.getItem(LOCAL_CUSTOM_NOVELS_KEY);
		if (raw) list = JSON.parse(raw);
	} catch {}
	try {
		const novelsRef = collection(db, "custom_novels");
		const snapshot = await getDocs(novelsRef);
		const firestoreNovels = [];
		snapshot.forEach((d) => {
			firestoreNovels.push(d.data());
		});
		if (firestoreNovels.length > 0) {
			const ids = new Set(firestoreNovels.map((n) => n.id));
			const merged = [...firestoreNovels];
			list.forEach((n) => {
				if (!ids.has(n.id)) {
					merged.push(n);
					ids.add(n.id);
				}
			});
			return merged;
		}
	} catch {}
	return list;
}
async function getAllNovels() {
	const [hiddenIds, modifiedMap, customNovels] = await Promise.all([
		getHiddenNovelIds(),
		getModifiedNovelsMap(),
		getOwnerCustomNovels()
	]);
	const mergedMap = /* @__PURE__ */ new Map();
	NOVELS_CATALOG.forEach((novel) => {
		if (!hiddenIds.has(novel.id)) {
			const effectiveNovel = modifiedMap[novel.id] ? {
				...novel,
				...modifiedMap[novel.id]
			} : novel;
			mergedMap.set(novel.id, effectiveNovel);
		}
	});
	customNovels.forEach((novel) => {
		if (!hiddenIds.has(novel.id)) {
			const effectiveNovel = modifiedMap[novel.id] ? {
				...novel,
				...modifiedMap[novel.id]
			} : novel;
			mergedMap.set(novel.id, effectiveNovel);
		}
	});
	return Array.from(mergedMap.values());
}
async function saveOrUpdateNovel(novel) {
	if (!NOVELS_CATALOG.some((n) => n.id === novel.id)) {
		try {
			const updated = [novel, ...(await getOwnerCustomNovels()).filter((n) => n.id !== novel.id)];
			localStorage.setItem(LOCAL_CUSTOM_NOVELS_KEY, JSON.stringify(updated));
		} catch {}
		try {
			const novelDoc = doc(db, "custom_novels", novel.id);
			await setDoc(novelDoc, {
				...novel,
				updatedAt: (/* @__PURE__ */ new Date()).toISOString()
			});
		} catch (err) {
			console.warn("Could not sync custom novel to Firestore:", err);
		}
	}
	try {
		const raw = localStorage.getItem(LOCAL_MODIFIED_NOVELS_KEY);
		const map = raw ? JSON.parse(raw) : {};
		map[novel.id] = novel;
		localStorage.setItem(LOCAL_MODIFIED_NOVELS_KEY, JSON.stringify(map));
	} catch {}
	try {
		const modDoc = doc(db, "modified_novels", novel.id);
		await setDoc(modDoc, {
			...novel,
			modifiedAt: (/* @__PURE__ */ new Date()).toISOString()
		});
	} catch (err) {
		console.warn("Could not sync modified novel to Firestore:", err);
	}
	try {
		const rawHidden = localStorage.getItem(LOCAL_HIDDEN_NOVELS_KEY);
		if (rawHidden) {
			const newHidden = JSON.parse(rawHidden).filter((id) => id !== novel.id);
			localStorage.setItem(LOCAL_HIDDEN_NOVELS_KEY, JSON.stringify(newHidden));
		}
	} catch {}
}
async function deleteOwnerNovel(novelId) {
	try {
		const raw = localStorage.getItem(LOCAL_HIDDEN_NOVELS_KEY);
		const list = raw ? JSON.parse(raw) : [];
		if (!list.includes(novelId)) {
			list.push(novelId);
			localStorage.setItem(LOCAL_HIDDEN_NOVELS_KEY, JSON.stringify(list));
		}
	} catch {}
	try {
		const raw = localStorage.getItem(LOCAL_CUSTOM_NOVELS_KEY);
		if (raw) {
			const updated = JSON.parse(raw).filter((n) => n.id !== novelId);
			localStorage.setItem(LOCAL_CUSTOM_NOVELS_KEY, JSON.stringify(updated));
		}
	} catch {}
	try {
		const raw = localStorage.getItem(LOCAL_MODIFIED_NOVELS_KEY);
		if (raw) {
			const map = JSON.parse(raw);
			delete map[novelId];
			localStorage.setItem(LOCAL_MODIFIED_NOVELS_KEY, JSON.stringify(map));
		}
	} catch {}
	try {
		await setDoc(doc(db, "hidden_novels", novelId), {
			id: novelId,
			hidden: true,
			deletedAt: (/* @__PURE__ */ new Date()).toISOString()
		});
	} catch {}
	try {
		await deleteDoc(doc(db, "custom_novels", novelId));
	} catch {}
	try {
		await deleteDoc(doc(db, "modified_novels", novelId));
	} catch {}
}
async function hideNovel(novelId) {
	try {
		const raw = localStorage.getItem(LOCAL_HIDDEN_NOVELS_KEY);
		const list = raw ? JSON.parse(raw) : [];
		if (!list.includes(novelId)) {
			list.push(novelId);
			localStorage.setItem(LOCAL_HIDDEN_NOVELS_KEY, JSON.stringify(list));
		}
	} catch {}
	try {
		await setDoc(doc(db, "hidden_novels", novelId), {
			id: novelId,
			hidden: true,
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		});
	} catch {}
}
async function unhideNovel(novelId) {
	try {
		const raw = localStorage.getItem(LOCAL_HIDDEN_NOVELS_KEY);
		if (raw) {
			const filtered = JSON.parse(raw).filter((id) => id !== novelId);
			localStorage.setItem(LOCAL_HIDDEN_NOVELS_KEY, JSON.stringify(filtered));
		}
	} catch {}
	try {
		await deleteDoc(doc(db, "hidden_novels", novelId));
	} catch {}
}
//#endregion
export { getNovelComments as a, saveOrUpdateNovel as c, getHiddenNovelIds as i, unhideNovel as l, deleteOwnerNovel as n, hideNovel as o, getAllNovels as r, likeNovelComment as s, addNovelComment as t };
