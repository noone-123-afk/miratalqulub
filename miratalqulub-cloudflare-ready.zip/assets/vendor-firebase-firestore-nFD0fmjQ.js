import { A as FirebaseError, C as getApp, D as LogLevel, E as registerVersion, F as getUA, I as isCloudWorkstation, L as isSafari, M as deepEqual, N as getDefaultEmulatorHostnameAndPort, O as Logger, P as getModularInstance, R as pingServer, S as _registerComponent, _ as Integer, b as _getProvider, d as EventType, f as Stat, g as getStatEventTarget, h as createWebChannelTransport, j as createMockUserToken, k as Component, l as ErrorCode, m as XhrIo, p as WebChannel, u as Event, v as Md5, x as _isFirebaseServerApp, y as SDK_VERSION } from "./vendor-firebase-auth-BGpsStFY.js";
import { a as __classPrivateFieldGet, r as RE2JS } from "./firebase-Cu7XUsbK.js";
//#region node_modules/@firebase/firestore/dist/common-D9UYuXJO.esm.js
/**
* @license
* Copyright 2023 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/** The semver (www.semver.org) version of the SDK. */
var xe = "13.0.0";
function __PRIVATE_setSDKVersion(e) {
	xe = e;
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/** Formats an object as a JSON string, suitable for logging. */
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var ve = new Logger("@firebase/firestore");
function __PRIVATE_getLogLevel() {
	return ve.logLevel;
}
/**
* Sets the verbosity of Cloud Firestore logs (debug, error, or silent).
*
* @param logLevel - The verbosity you set for activity and error logging. Can
*   be any of the following values:
*
*   <ul>
*     <li>`debug` for the most verbose logging level, primarily for
*     debugging.</li>
*     <li>`error` to log errors only.</li>
*     <li><code>`silent` to turn off logging.</li>
*   </ul>
*/ function setLogLevel(e) {
	ve.setLogLevel(e);
}
function __PRIVATE_logDebug(e, ...t) {
	if (ve.logLevel <= LogLevel.DEBUG) {
		const n = t.map(__PRIVATE_argToString);
		ve.debug(`Firestore (${xe}): ${e}`, ...n);
	}
}
function __PRIVATE_logError(e, ...t) {
	if (ve.logLevel <= LogLevel.ERROR) {
		const n = t.map(__PRIVATE_argToString);
		ve.error(`Firestore (${xe}): ${e}`, ...n);
	}
}
/**
* @internal
*/ function __PRIVATE_logWarn(e, ...t) {
	if (ve.logLevel <= LogLevel.WARN) {
		const n = t.map(__PRIVATE_argToString);
		ve.warn(`Firestore (${xe}): ${e}`, ...n);
	}
}
/**
* Converts an additional log parameter to a string representation.
*/ function __PRIVATE_argToString(e) {
	if ("string" == typeof e) return e;
	try {
		return function __PRIVATE_formatJSON(e) {
			return JSON.stringify(e);
		}(e);
	} catch (t) {
		return e;
	}
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ function l(e, t, n) {
	let r = "Unexpected state";
	"string" == typeof t ? r = t : n = t, __PRIVATE__fail(e, r, n);
}
function __PRIVATE__fail(e, t, n) {
	let r = `FIRESTORE (${xe}) INTERNAL ASSERTION FAILED: ${t} (ID: ${e.toString(16)})`;
	if (void 0 !== n) try {
		r += " CONTEXT: " + JSON.stringify(n);
	} catch (e) {
		r += " CONTEXT: " + n;
	}
	throw __PRIVATE_logError(r), new Error(r);
}
function __PRIVATE_hardAssert(e, t, n, r) {
	let i = "Unexpected state";
	"string" == typeof n ? i = n : r = n, e || __PRIVATE__fail(t, i, r);
}
/**
* Casts `obj` to `T`. In non-production builds, verifies that `obj` is an
* instance of `T` before casting.
*/ function __PRIVATE_debugCast(e, t) {
	return e;
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Generates `nBytes` of random bytes.
*
* If `nBytes < 0` , an error will be thrown.
*/ function __PRIVATE_randomBytes(e) {
	const t = "undefined" != typeof self && (self.crypto || self.msCrypto), n = new Uint8Array(e);
	if (t && "function" == typeof t.getRandomValues) t.getRandomValues(n);
	else for (let t = 0; t < e; t++) n[t] = Math.floor(256 * Math.random());
	return n;
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* A utility class for generating unique alphanumeric IDs of a specified length.
*
* @internal
* Exported internally for testing purposes.
*/ var __PRIVATE_AutoId = class {
	static newId() {
		const e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789", t = 62 * Math.floor(256 / 62);
		let n = "";
		for (; n.length < 20;) {
			const r = __PRIVATE_randomBytes(40);
			for (let i = 0; i < r.length; ++i) n.length < 20 && r[i] < t && (n += e.charAt(r[i] % 62));
		}
		return n;
	}
};
function __PRIVATE_primitiveComparator(e, t) {
	return e < t ? -1 : e > t ? 1 : 0;
}
/** Compare strings in UTF-8 encoded byte order */ function __PRIVATE_compareUtf8Strings(e, t) {
	const n = Math.min(e.length, t.length);
	for (let r = 0; r < n; r++) {
		const n = e.charAt(r), i = t.charAt(r);
		if (n !== i) return __PRIVATE_isSurrogate(n) === __PRIVATE_isSurrogate(i) ? __PRIVATE_primitiveComparator(n, i) : __PRIVATE_isSurrogate(n) ? 1 : -1;
	}
	return __PRIVATE_primitiveComparator(e.length, t.length);
}
var De = 55296;
var Ce = 57343;
function __PRIVATE_isSurrogate(e) {
	const t = e.charCodeAt(0);
	return t >= De && t <= Ce;
}
/** Helper to compare arrays using isEqual(). */ function __PRIVATE_arrayEquals(e, t, n) {
	return e.length === t.length && e.every(((e, r) => n(e, t[r])));
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var SortedMap = class SortedMap {
	constructor(e, t) {
		this.comparator = e, this.root = t || LLRBNode.EMPTY;
	}
	insert(e, t) {
		return new SortedMap(this.comparator, this.root.insert(e, t, this.comparator).copy(null, null, LLRBNode.BLACK, null, null));
	}
	remove(e) {
		return new SortedMap(this.comparator, this.root.remove(e, this.comparator).copy(null, null, LLRBNode.BLACK, null, null));
	}
	get(e) {
		let t = this.root;
		for (; !t.isEmpty();) {
			const n = this.comparator(e, t.key);
			if (0 === n) return t.value;
			n < 0 ? t = t.left : n > 0 && (t = t.right);
		}
		return null;
	}
	indexOf(e) {
		let t = 0, n = this.root;
		for (; !n.isEmpty();) {
			const r = this.comparator(e, n.key);
			if (0 === r) return t + n.left.size;
			r < 0 ? n = n.left : (t += n.left.size + 1, n = n.right);
		}
		return -1;
	}
	isEmpty() {
		return this.root.isEmpty();
	}
	get size() {
		return this.root.size;
	}
	minKey() {
		return this.root.minKey();
	}
	maxKey() {
		return this.root.maxKey();
	}
	inorderTraversal(e) {
		return this.root.inorderTraversal(e);
	}
	forEach(e) {
		this.inorderTraversal(((t, n) => (e(t, n), false)));
	}
	toString() {
		const e = [];
		return this.inorderTraversal(((t, n) => (e.push(`${t}:${n}`), false))), `{${e.join(", ")}}`;
	}
	reverseTraversal(e) {
		return this.root.reverseTraversal(e);
	}
	getIterator() {
		return new SortedMapIterator(this.root, null, this.comparator, false);
	}
	getIteratorFrom(e) {
		return new SortedMapIterator(this.root, e, this.comparator, false);
	}
	getReverseIterator() {
		return new SortedMapIterator(this.root, null, this.comparator, true);
	}
	getReverseIteratorFrom(e) {
		return new SortedMapIterator(this.root, e, this.comparator, true);
	}
};
var SortedMapIterator = class {
	constructor(e, t, n, r) {
		this.isReverse = r, this.nodeStack = [];
		let i = 1;
		for (; !e.isEmpty();) if (i = t ? n(e.key, t) : 1, t && r && (i *= -1), i < 0) e = this.isReverse ? e.left : e.right;
		else {
			if (0 === i) {
				this.nodeStack.push(e);
				break;
			}
			this.nodeStack.push(e), e = this.isReverse ? e.right : e.left;
		}
	}
	getNext() {
		let e = this.nodeStack.pop();
		const t = {
			key: e.key,
			value: e.value
		};
		if (this.isReverse) for (e = e.left; !e.isEmpty();) this.nodeStack.push(e), e = e.right;
		else for (e = e.right; !e.isEmpty();) this.nodeStack.push(e), e = e.left;
		return t;
	}
	hasNext() {
		return this.nodeStack.length > 0;
	}
	peek() {
		if (0 === this.nodeStack.length) return null;
		const e = this.nodeStack[this.nodeStack.length - 1];
		return {
			key: e.key,
			value: e.value
		};
	}
};
var LLRBNode = class LLRBNode {
	constructor(e, t, n, r, i) {
		this.key = e, this.value = t, this.color = null != n ? n : LLRBNode.RED, this.left = null != r ? r : LLRBNode.EMPTY, this.right = null != i ? i : LLRBNode.EMPTY, this.size = this.left.size + 1 + this.right.size;
	}
	copy(e, t, n, r, i) {
		return new LLRBNode(null != e ? e : this.key, null != t ? t : this.value, null != n ? n : this.color, null != r ? r : this.left, null != i ? i : this.right);
	}
	isEmpty() {
		return false;
	}
	inorderTraversal(e) {
		return this.left.inorderTraversal(e) || e(this.key, this.value) || this.right.inorderTraversal(e);
	}
	reverseTraversal(e) {
		return this.right.reverseTraversal(e) || e(this.key, this.value) || this.left.reverseTraversal(e);
	}
	min() {
		return this.left.isEmpty() ? this : this.left.min();
	}
	minKey() {
		return this.min().key;
	}
	maxKey() {
		return this.right.isEmpty() ? this.key : this.right.maxKey();
	}
	insert(e, t, n) {
		let r = this;
		const i = n(e, r.key);
		return r = i < 0 ? r.copy(null, null, null, r.left.insert(e, t, n), null) : 0 === i ? r.copy(null, t, null, null, null) : r.copy(null, null, null, null, r.right.insert(e, t, n)), r.fixUp();
	}
	removeMin() {
		if (this.left.isEmpty()) return LLRBNode.EMPTY;
		let e = this;
		return e.left.isRed() || e.left.left.isRed() || (e = e.moveRedLeft()), e = e.copy(null, null, null, e.left.removeMin(), null), e.fixUp();
	}
	remove(e, t) {
		let n, r = this;
		if (t(e, r.key) < 0) r.left.isEmpty() || r.left.isRed() || r.left.left.isRed() || (r = r.moveRedLeft()), r = r.copy(null, null, null, r.left.remove(e, t), null);
		else {
			if (r.left.isRed() && (r = r.rotateRight()), r.right.isEmpty() || r.right.isRed() || r.right.left.isRed() || (r = r.moveRedRight()), 0 === t(e, r.key)) {
				if (r.right.isEmpty()) return LLRBNode.EMPTY;
				n = r.right.min(), r = r.copy(n.key, n.value, null, null, r.right.removeMin());
			}
			r = r.copy(null, null, null, null, r.right.remove(e, t));
		}
		return r.fixUp();
	}
	isRed() {
		return this.color;
	}
	fixUp() {
		let e = this;
		return e.right.isRed() && !e.left.isRed() && (e = e.rotateLeft()), e.left.isRed() && e.left.left.isRed() && (e = e.rotateRight()), e.left.isRed() && e.right.isRed() && (e = e.colorFlip()), e;
	}
	moveRedLeft() {
		let e = this.colorFlip();
		return e.right.left.isRed() && (e = e.copy(null, null, null, null, e.right.rotateRight()), e = e.rotateLeft(), e = e.colorFlip()), e;
	}
	moveRedRight() {
		let e = this.colorFlip();
		return e.left.left.isRed() && (e = e.rotateRight(), e = e.colorFlip()), e;
	}
	rotateLeft() {
		const e = this.copy(null, null, LLRBNode.RED, null, this.right.left);
		return this.right.copy(null, null, this.color, e, null);
	}
	rotateRight() {
		const e = this.copy(null, null, LLRBNode.RED, this.left.right, null);
		return this.left.copy(null, null, this.color, null, e);
	}
	colorFlip() {
		const e = this.left.copy(null, null, !this.left.color, null, null), t = this.right.copy(null, null, !this.right.color, null, null);
		return this.copy(null, null, !this.color, e, t);
	}
	checkMaxDepth() {
		const e = this.check();
		return Math.pow(2, e) <= this.size + 1;
	}
	check() {
		if (this.isRed() && this.left.isRed()) throw l(43730, {
			key: this.key,
			value: this.value
		});
		if (this.right.isRed()) throw l(14113, {
			key: this.key,
			value: this.value
		});
		const e = this.left.check();
		if (e !== this.right.check()) throw l(27949);
		return e + (this.isRed() ? 0 : 1);
	}
};
LLRBNode.EMPTY = null, LLRBNode.RED = true, LLRBNode.BLACK = false;
LLRBNode.EMPTY = new class LLRBEmptyNode {
	constructor() {
		this.size = 0;
	}
	get key() {
		throw l(57766);
	}
	get value() {
		throw l(16141);
	}
	get color() {
		throw l(16727);
	}
	get left() {
		throw l(29726);
	}
	get right() {
		throw l(36894);
	}
	copy(e, t, n, r, i) {
		return this;
	}
	insert(e, t, n) {
		return new LLRBNode(e, t);
	}
	remove(e, t) {
		return this;
	}
	isEmpty() {
		return true;
	}
	inorderTraversal(e) {
		return false;
	}
	reverseTraversal(e) {
		return false;
	}
	minKey() {
		return null;
	}
	maxKey() {
		return null;
	}
	isRed() {
		return false;
	}
	checkMaxDepth() {
		return true;
	}
	check() {
		return 0;
	}
}();
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* SortedSet is an immutable (copy-on-write) collection that holds elements
* in order specified by the provided comparator.
*
* NOTE: if provided comparator returns 0 for two elements, we consider them to
* be equal!
*/
var SortedSet = class SortedSet {
	constructor(e) {
		this.comparator = e, this.data = new SortedMap(this.comparator);
	}
	has(e) {
		return null !== this.data.get(e);
	}
	first() {
		return this.data.minKey();
	}
	last() {
		return this.data.maxKey();
	}
	get size() {
		return this.data.size;
	}
	indexOf(e) {
		return this.data.indexOf(e);
	}
	/** Iterates elements in order defined by "comparator" */ forEach(e) {
		this.data.inorderTraversal(((t, n) => (e(t), false)));
	}
	/** Iterates over `elem`s such that: range[0] &lt;= elem &lt; range[1]. */ forEachInRange(e, t) {
		const n = this.data.getIteratorFrom(e[0]);
		for (; n.hasNext();) {
			const r = n.getNext();
			if (this.comparator(r.key, e[1]) >= 0) return;
			t(r.key);
		}
	}
	/**
	* Iterates over `elem`s such that: start &lt;= elem until false is returned.
	*/ forEachWhile(e, t) {
		let n;
		for (n = void 0 !== t ? this.data.getIteratorFrom(t) : this.data.getIterator(); n.hasNext();) if (!e(n.getNext().key)) return;
	}
	/** Finds the least element greater than or equal to `elem`. */ firstAfterOrEqual(e) {
		const t = this.data.getIteratorFrom(e);
		return t.hasNext() ? t.getNext().key : null;
	}
	getIterator() {
		return new SortedSetIterator(this.data.getIterator());
	}
	getIteratorFrom(e) {
		return new SortedSetIterator(this.data.getIteratorFrom(e));
	}
	/** Inserts or updates an element */ add(e) {
		return this.copy(this.data.remove(e).insert(e, true));
	}
	/** Deletes an element */ delete(e) {
		return this.has(e) ? this.copy(this.data.remove(e)) : this;
	}
	isEmpty() {
		return this.data.isEmpty();
	}
	unionWith(e) {
		let t = this;
		return t.size < e.size && (t = e, e = this), e.forEach(((e) => {
			t = t.add(e);
		})), t;
	}
	isEqual(e) {
		if (!(e instanceof SortedSet)) return false;
		if (this.size !== e.size) return false;
		const t = this.data.getIterator(), n = e.data.getIterator();
		for (; t.hasNext();) {
			const e = t.getNext().key, r = n.getNext().key;
			if (0 !== this.comparator(e, r)) return false;
		}
		return true;
	}
	toArray() {
		const e = [];
		return this.forEach(((t) => {
			e.push(t);
		})), e;
	}
	toString() {
		const e = [];
		return this.forEach(((t) => e.push(t))), "SortedSet(" + e.toString() + ")";
	}
	copy(e) {
		const t = new SortedSet(this.comparator);
		return t.data = e, t;
	}
};
var SortedSetIterator = class {
	constructor(e) {
		this.iter = e;
	}
	getNext() {
		return this.iter.getNext().key;
	}
	hasNext() {
		return this.iter.hasNext();
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var ta = {
	/** Not an error; returned on success. */
	OK: "ok",
	/** The operation was cancelled (typically by the caller). */
	CANCELLED: "cancelled",
	/** Unknown error or an error from a different error domain. */
	UNKNOWN: "unknown",
	/**
	* Client specified an invalid argument. Note that this differs from
	* FAILED_PRECONDITION. INVALID_ARGUMENT indicates arguments that are
	* problematic regardless of the state of the system (e.g., a malformed file
	* name).
	*/
	INVALID_ARGUMENT: "invalid-argument",
	/**
	* Deadline expired before operation could complete. For operations that
	* change the state of the system, this error may be returned even if the
	* operation has completed successfully. For example, a successful response
	* from a server could have been delayed long enough for the deadline to
	* expire.
	*/
	DEADLINE_EXCEEDED: "deadline-exceeded",
	/** Some requested entity (e.g., file or directory) was not found. */
	NOT_FOUND: "not-found",
	/**
	* Some entity that we attempted to create (e.g., file or directory) already
	* exists.
	*/
	ALREADY_EXISTS: "already-exists",
	/**
	* The caller does not have permission to execute the specified operation.
	* PERMISSION_DENIED must not be used for rejections caused by exhausting
	* some resource (use RESOURCE_EXHAUSTED instead for those errors).
	* PERMISSION_DENIED must not be used if the caller cannot be identified
	* (use UNAUTHENTICATED instead for those errors).
	*/
	PERMISSION_DENIED: "permission-denied",
	/**
	* The request does not have valid authentication credentials for the
	* operation.
	*/
	UNAUTHENTICATED: "unauthenticated",
	/**
	* Some resource has been exhausted, perhaps a per-user quota, or perhaps the
	* entire file system is out of space.
	*/
	RESOURCE_EXHAUSTED: "resource-exhausted",
	/**
	* Operation was rejected because the system is not in a state required for
	* the operation's execution. For example, directory to be deleted may be
	* non-empty, an rmdir operation is applied to a non-directory, etc.
	*
	* A litmus test that may help a service implementor in deciding
	* between FAILED_PRECONDITION, ABORTED, and UNAVAILABLE:
	*  (a) Use UNAVAILABLE if the client can retry just the failing call.
	*  (b) Use ABORTED if the client should retry at a higher-level
	*      (e.g., restarting a read-modify-write sequence).
	*  (c) Use FAILED_PRECONDITION if the client should not retry until
	*      the system state has been explicitly fixed. E.g., if an "rmdir"
	*      fails because the directory is non-empty, FAILED_PRECONDITION
	*      should be returned since the client should not retry unless
	*      they have first fixed up the directory by deleting files from it.
	*  (d) Use FAILED_PRECONDITION if the client performs conditional
	*      REST Get/Update/Delete on a resource and the resource on the
	*      server does not match the condition. E.g., conflicting
	*      read-modify-write on the same resource.
	*/
	FAILED_PRECONDITION: "failed-precondition",
	/**
	* The operation was aborted, typically due to a concurrency issue like
	* sequencer check failures, transaction aborts, etc.
	*
	* See litmus test above for deciding between FAILED_PRECONDITION, ABORTED,
	* and UNAVAILABLE.
	*/
	ABORTED: "aborted",
	/**
	* Operation was attempted past the valid range. E.g., seeking or reading
	* past end of file.
	*
	* Unlike INVALID_ARGUMENT, this error indicates a problem that may be fixed
	* if the system state changes. For example, a 32-bit file system will
	* generate INVALID_ARGUMENT if asked to read at an offset that is not in the
	* range [0,2^32-1], but it will generate OUT_OF_RANGE if asked to read from
	* an offset past the current file size.
	*
	* There is a fair bit of overlap between FAILED_PRECONDITION and
	* OUT_OF_RANGE. We recommend using OUT_OF_RANGE (the more specific error)
	* when it applies so that callers who are iterating through a space can
	* easily look for an OUT_OF_RANGE error to detect when they are done.
	*/
	OUT_OF_RANGE: "out-of-range",
	/** Operation is not implemented or not supported/enabled in this service. */
	UNIMPLEMENTED: "unimplemented",
	/**
	* Internal errors. Means some invariants expected by underlying System has
	* been broken. If you see one of these errors, Something is very broken.
	*/
	INTERNAL: "internal",
	/**
	* The service is currently unavailable. This is a most likely a transient
	* condition and may be corrected by retrying with a backoff.
	*
	* See litmus test above for deciding between FAILED_PRECONDITION, ABORTED,
	* and UNAVAILABLE.
	*/
	UNAVAILABLE: "unavailable",
	/** Unrecoverable data loss or corruption. */
	DATA_LOSS: "data-loss"
};
/** An error returned by a Firestore operation. */ var e = class extends FirebaseError {
	/** @hideconstructor */
	constructor(e, t) {
		super(e, t), this.code = e, this.message = t, this.toString = () => `${this.name}: [code=${this.code}]: ${this.message}`;
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var Fe = "__name__";
/**
* Path represents an ordered sequence of string segments.
*/
var BasePath = class BasePath {
	constructor(e, t, n) {
		void 0 === t ? t = 0 : t > e.length && l(637, {
			offset: t,
			range: e.length
		}), void 0 === n ? n = e.length - t : n > e.length - t && l(1746, {
			length: n,
			range: e.length - t
		}), this.segments = e, this.offset = t, this.len = n;
	}
	get length() {
		return this.len;
	}
	isEqual(e) {
		return 0 === BasePath.comparator(this, e);
	}
	child(e) {
		const t = this.segments.slice(this.offset, this.limit());
		return e instanceof BasePath ? e.forEach(((e) => {
			t.push(e);
		})) : t.push(e), this.construct(t);
	}
	/** The index of one past the last segment of the path. */ limit() {
		return this.offset + this.length;
	}
	popFirst(e) {
		return e = void 0 === e ? 1 : e, this.construct(this.segments, this.offset + e, this.length - e);
	}
	popLast() {
		return this.construct(this.segments, this.offset, this.length - 1);
	}
	firstSegment() {
		return this.segments[this.offset];
	}
	lastSegment() {
		return this.get(this.length - 1);
	}
	get(e) {
		return this.segments[this.offset + e];
	}
	isEmpty() {
		return 0 === this.length;
	}
	isPrefixOf(e) {
		if (e.length < this.length) return false;
		for (let t = 0; t < this.length; t++) if (this.get(t) !== e.get(t)) return false;
		return true;
	}
	isImmediateParentOf(e) {
		if (this.length + 1 !== e.length) return false;
		for (let t = 0; t < this.length; t++) if (this.get(t) !== e.get(t)) return false;
		return true;
	}
	forEach(e) {
		for (let t = this.offset, n = this.limit(); t < n; t++) e(this.segments[t]);
	}
	toArray() {
		return this.segments.slice(this.offset, this.limit());
	}
	/**
	* Compare 2 paths segment by segment, prioritizing numeric IDs
	* (e.g., "__id123__") in numeric ascending order, followed by string
	* segments in lexicographical order.
	*/ static comparator(e, t) {
		const n = Math.min(e.length, t.length);
		for (let r = 0; r < n; r++) {
			const n = BasePath.compareSegments(e.get(r), t.get(r));
			if (0 !== n) return n;
		}
		return __PRIVATE_primitiveComparator(e.length, t.length);
	}
	static compareSegments(e, t) {
		const n = BasePath.isNumericId(e), r = BasePath.isNumericId(t);
		return n && !r ? -1 : !n && r ? 1 : n && r ? BasePath.extractNumericId(e).compare(BasePath.extractNumericId(t)) : __PRIVATE_compareUtf8Strings(e, t);
	}
	static isNumericId(e) {
		return e.startsWith("__id") && e.endsWith("__");
	}
	static extractNumericId(e) {
		return Integer.fromString(e.substring(4, e.length - 2));
	}
};
/**
* A slash-separated path for navigating resources (documents and collections)
* within Firestore.
*
* @internal
*/ var ResourcePath = class ResourcePath extends BasePath {
	construct(e, t, n) {
		return new ResourcePath(e, t, n);
	}
	canonicalString() {
		return this.toArray().join("/");
	}
	toString() {
		return this.canonicalString();
	}
	toStringWithLeadingSlash() {
		return `/${this.canonicalString()}`;
	}
	/**
	* Returns a string representation of this path
	* where each path segment has been encoded with
	* `encodeURIComponent`.
	*/ toUriEncodedString() {
		return this.toArray().map(encodeURIComponent).join("/");
	}
	/**
	* Creates a resource path from the given slash-delimited string. If multiple
	* arguments are provided, all components are combined. Leading and trailing
	* slashes from all components are ignored.
	*/ static fromString(...t) {
		const n = [];
		for (const r of t) {
			if (r.indexOf("//") >= 0) throw new e(ta.INVALID_ARGUMENT, `Invalid segment (${r}). Paths must not contain // in them.`);
			n.push(...r.split("/").filter(((e) => e.length > 0)));
		}
		return new ResourcePath(n);
	}
	static emptyPath() {
		return new ResourcePath([]);
	}
};
var Oe = /^[_a-zA-Z][_a-zA-Z0-9]*$/;
/**
* A dot-separated path for navigating sub-objects within a document.
* @internal
*/ var Me$1 = class FieldPath extends BasePath {
	construct(e, t, n) {
		return new FieldPath(e, t, n);
	}
	/**
	* Returns true if the string could be used as a segment in a field path
	* without escaping.
	*/ static isValidIdentifier(e) {
		return Oe.test(e);
	}
	canonicalString() {
		return this.toArray().map(((e) => (e = e.replace(/\\/g, "\\\\").replace(/`/g, "\\`"), FieldPath.isValidIdentifier(e) || (e = "`" + e + "`"), e))).join(".");
	}
	toString() {
		return this.canonicalString();
	}
	/**
	* Returns true if this field references the key of a document.
	*/ isKeyField() {
		return 1 === this.length && this.get(0) === Fe;
	}
	/**
	* The field designating the key of a document.
	*/ static keyField() {
		return new FieldPath([Fe]);
	}
	/**
	* Parses a field string from the given server-formatted string.
	*
	* - Splitting the empty string is not allowed (for now at least).
	* - Empty segments within the string (e.g. if there are two consecutive
	*   separators) are not allowed.
	*
	* TODO(b/37244157): we should make this more strict. Right now, it allows
	* non-identifier path components, even if they aren't escaped.
	*/ static fromServerFormat(t) {
		const n = [];
		let r = "", i = 0;
		const __PRIVATE_addCurrentSegment = () => {
			if (0 === r.length) throw new e(ta.INVALID_ARGUMENT, `Invalid field path (${t}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);
			n.push(r), r = "";
		};
		let s = false;
		for (; i < t.length;) {
			const n = t[i];
			if ("\\" === n) {
				if (i + 1 === t.length) throw new e(ta.INVALID_ARGUMENT, "Path has trailing escape character: " + t);
				const n = t[i + 1];
				if ("\\" !== n && "." !== n && "`" !== n) throw new e(ta.INVALID_ARGUMENT, "Path has invalid escape sequence: " + t);
				r += n, i += 2;
			} else "`" === n ? (s = !s, i++) : "." !== n || s ? (r += n, i++) : (__PRIVATE_addCurrentSegment(), i++);
		}
		if (__PRIVATE_addCurrentSegment(), s) throw new e(ta.INVALID_ARGUMENT, "Unterminated ` in path: " + t);
		return new FieldPath(n);
	}
	static emptyPath() {
		return new FieldPath([]);
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Provides a set of fields that can be used to partially patch a document.
* FieldMask is used in conjunction with ObjectValue.
* Examples:
*   foo - Overwrites foo entirely with the provided value. If foo is not
*         present in the companion ObjectValue, the field is deleted.
*   foo.bar - Overwrites only the field bar of the object foo.
*             If foo is not an object, foo is replaced with an object
*             containing foo
*/ var FieldMask = class FieldMask {
	constructor(e) {
		this.fields = e, e.sort(Me$1.comparator);
	}
	static empty() {
		return new FieldMask([]);
	}
	/**
	* Returns a new FieldMask object that is the result of adding all the given
	* fields paths to this field mask.
	*/ unionWith(e) {
		let t = new SortedSet(Me$1.comparator);
		for (const e of this.fields) t = t.add(e);
		for (const n of e) t = t.add(n);
		return new FieldMask(t.toArray());
	}
	/**
	* Verifies that `fieldPath` is included by at least one field in this field
	* mask.
	*
	* This is an O(n) operation, where `n` is the size of the field mask.
	*/ covers(e) {
		for (const t of this.fields) if (t.isPrefixOf(e)) return true;
		return false;
	}
	isEqual(e) {
		return __PRIVATE_arrayEquals(this.fields, e.fields, ((e, t) => e.isEqual(t)));
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ function __PRIVATE_objectSize(e) {
	let t = 0;
	for (const n in e) Object.prototype.hasOwnProperty.call(e, n) && t++;
	return t;
}
function forEach(e, t) {
	for (const n in e) Object.prototype.hasOwnProperty.call(e, n) && t(n, e[n]);
}
function __PRIVATE_mapToArray(e, t) {
	const n = [];
	for (const r in e) Object.prototype.hasOwnProperty.call(e, r) && n.push(t(e[r], r, e));
	return n;
}
function isEmpty(e) {
	for (const t in e) if (Object.prototype.hasOwnProperty.call(e, t)) return false;
	return true;
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @internal
*/ var DocumentKey = class DocumentKey {
	constructor(e) {
		this.path = e;
	}
	static fromPath(e) {
		return new DocumentKey(ResourcePath.fromString(e));
	}
	static fromName(e) {
		return new DocumentKey(ResourcePath.fromString(e).popFirst(5));
	}
	static empty() {
		return new DocumentKey(ResourcePath.emptyPath());
	}
	get collectionGroup() {
		return this.path.popLast().lastSegment();
	}
	/** Returns true if the document is in the specified collectionId. */ hasCollectionId(e) {
		return this.path.length >= 2 && this.path.get(this.path.length - 2) === e;
	}
	/** Returns the collection group (i.e. the name of the parent collection) for this key. */ getCollectionGroup() {
		return this.path.get(this.path.length - 2);
	}
	/** Returns the fully qualified path to the parent collection. */ getCollectionPath() {
		return this.path.popLast();
	}
	isEqual(e) {
		return null !== e && 0 === ResourcePath.comparator(this.path, e.path);
	}
	toString() {
		return this.path.toString();
	}
	static comparator(e, t) {
		return ResourcePath.comparator(e.path, t.path);
	}
	static isDocumentKey(e) {
		return e.length % 2 == 0;
	}
	/**
	* Creates and returns a new document key with the given segments.
	*
	* @param segments - The segments of the path to the document
	* @returns A new instance of DocumentKey
	*/ static fromSegments(e) {
		return new DocumentKey(new ResourcePath(e.slice()));
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ function __PRIVATE_validateNonEmptyArgument(t, n, r) {
	if (!r) throw new e(ta.INVALID_ARGUMENT, `Function ${t}() cannot be called with an empty ${n}.`);
}
/**
* Validates that two boolean options are not set at the same time.
* @internal
*/ function __PRIVATE_validateIsNotUsedTogether(t, n, r, i) {
	if (true === n && true === i) throw new e(ta.INVALID_ARGUMENT, `${t} and ${r} cannot be used together.`);
}
/**
* Validates that `path` refers to a document (indicated by the fact it contains
* an even numbers of segments).
*/ function __PRIVATE_validateDocumentPath(t) {
	if (!DocumentKey.isDocumentKey(t)) throw new e(ta.INVALID_ARGUMENT, `Invalid document reference. Document references must have an even number of segments, but ${t} has ${t.length}.`);
}
/**
* Validates that `path` refers to a collection (indicated by the fact it
* contains an odd numbers of segments).
*/ function __PRIVATE_validateCollectionPath(t) {
	if (DocumentKey.isDocumentKey(t)) throw new e(ta.INVALID_ARGUMENT, `Invalid collection reference. Collection references must have an odd number of segments, but ${t} has ${t.length}.`);
}
/**
* Returns true if it's a non-null object without a custom prototype
* (i.e. excludes Array, Date, etc.).
*/ function p(e) {
	return "object" == typeof e && null !== e && (Object.getPrototypeOf(e) === Object.prototype || null === Object.getPrototypeOf(e));
}
/** Returns a string describing the type / value of the provided input. */ function __PRIVATE_valueDescription(e) {
	if (void 0 === e) return "undefined";
	if (null === e) return "null";
	if ("string" == typeof e) return e.length > 20 && (e = `${e.substring(0, 20)}...`), JSON.stringify(e);
	if ("number" == typeof e || "boolean" == typeof e) return "" + e;
	if ("object" == typeof e) {
		if (e instanceof Array) return "an array";
		{
			const t = function __PRIVATE_tryGetCustomObjectType(e) {
				if (e.constructor) return e.constructor.name;
				return null;
			}(e);
			return t ? `a custom ${t} object` : "an object";
		}
	}
	return "function" == typeof e ? "a function" : l(12329, { type: typeof e });
}
function ra(t, n) {
	if ("_delegate" in t && (t = t._delegate), !(t instanceof n)) {
		if (n.name === t.constructor.name) throw new e(ta.INVALID_ARGUMENT, "Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");
		{
			const r = __PRIVATE_valueDescription(t);
			throw new e(ta.INVALID_ARGUMENT, `Expected type '${n.name}', but it was: ${r}`);
		}
	}
	return t;
}
function __PRIVATE_validatePositiveNumber(t, n) {
	if (n <= 0) throw new e(ta.INVALID_ARGUMENT, `Function ${t}() requires a positive number, but it was: ${n}.`);
}
/**
* @license
* Copyright 2025 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Helper function to define a JSON schema {@link Property}.
* @private
* @internal
*/ function property(e, t) {
	const n = { typeString: e };
	return t && (n.value = t), n;
}
/**
* Validates the JSON object based on the provided schema, and narrows the type to the provided
* JSON schema.
* @private
* @internal
*
* @param json - A JSON object to validate.
* @param scheme - a {@link JsonSchema} that defines the properties to validate.
* @returns true if the JSON schema exists within the object. Throws a FirestoreError otherwise.
*/ function __PRIVATE_validateJSON(t, n) {
	if (!p(t)) throw new e(ta.INVALID_ARGUMENT, "JSON must be an object");
	let r;
	for (const e in n) if (n[e]) {
		const i = n[e].typeString, s = "value" in n[e] ? { value: n[e].value } : void 0, _ = n[e].optional;
		if (!(e in t)) {
			if (_) continue;
			r = `JSON missing required field: '${e}'`;
			break;
		}
		const o = t[e];
		if (i && typeof o !== i) {
			r = `JSON field '${e}' must be a ${i}.`;
			break;
		}
		if (void 0 !== s && o !== s.value) {
			r = `Expected '${e}' field to equal '${s.value}'`;
			break;
		}
	}
	if (r) throw new e(ta.INVALID_ARGUMENT, r);
	return true;
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var Ne = -62135596800;
var Be = 1e6;
/**
* A `Timestamp` represents a point in time independent of any time zone or
* calendar, represented as seconds and fractions of seconds at nanosecond
* resolution in UTC Epoch time.
*
* It is encoded using the Proleptic Gregorian Calendar which extends the
* Gregorian calendar backwards to year one. It is encoded assuming all minutes
* are 60 seconds long, i.e. leap seconds are "smeared" so that no leap second
* table is needed for interpretation. Range is from 0001-01-01T00:00:00Z to
* 9999-12-31T23:59:59.999999999Z.
*
* For examples and further specifications, refer to the
* {@link https://github.com/google/protobuf/blob/master/src/google/protobuf/timestamp.proto | Timestamp definition}.
*/
var Timestamp = class Timestamp {
	/**
	* Creates a new timestamp with the current date, with millisecond precision.
	*
	* @returns a new timestamp representing the current date.
	*/
	static now() {
		return Timestamp.fromMillis(Date.now());
	}
	/**
	* Creates a new timestamp from the given date.
	*
	* @param date - The date to initialize the `Timestamp` from.
	* @returns A new `Timestamp` representing the same point in time as the given
	*     date.
	*/ static fromDate(e) {
		return Timestamp.fromMillis(e.getTime());
	}
	/**
	* Creates a new timestamp from the given number of milliseconds.
	*
	* @param milliseconds - Number of milliseconds since Unix epoch
	*     1970-01-01T00:00:00Z.
	* @returns A new `Timestamp` representing the same point in time as the given
	*     number of milliseconds.
	*/ static fromMillis(e) {
		const t = Math.floor(e / 1e3), n = Math.floor((e - 1e3 * t) * Be);
		return new Timestamp(t, n);
	}
	/**
	* Creates a new timestamp from the given `Temporal.Instant`.
	*
	* @param instant - The `Temporal.Instant` to initialize the `Timestamp` from.
	* @returns A new `Timestamp` representing the same point in time as the given
	*     instant.
	*/ static fromInstant(t) {
		if (!t || "bigint" != typeof t.t) throw new e(ta.INVALID_ARGUMENT, "Invalid Temporal.Instant object provided.");
		return Timestamp._fromEpochNanoseconds(t.t);
	}
	static _fromEpochNanoseconds(e) {
		let t, n;
		if (e >= 0n) t = Number(e / 1000000000n), n = Number(e % 1000000000n);
		else {
			const r = e % 1000000000n;
			0n === r ? (t = Number(e / 1000000000n), n = 0) : (t = Number(e / 1000000000n - 1n), n = Number(r + 1000000000n));
		}
		return new Timestamp(t, n);
	}
	/**
	* Creates a new timestamp.
	*
	* @param seconds - The number of seconds of UTC time since Unix epoch
	*     1970-01-01T00:00:00Z. Must be from 0001-01-01T00:00:00Z to
	*     9999-12-31T23:59:59Z inclusive.
	* @param nanoseconds - The non-negative fractions of a second at nanosecond
	*     resolution. Negative second values with fractions must still have
	*     non-negative nanoseconds values that count forward in time. Must be
	*     from 0 to 999,999,999 inclusive.
	*/ constructor(t, n) {
		if (this.seconds = t, this.nanoseconds = n, n < 0) throw new e(ta.INVALID_ARGUMENT, "Timestamp nanoseconds out of range: " + n);
		if (n >= 1e9) throw new e(ta.INVALID_ARGUMENT, "Timestamp nanoseconds out of range: " + n);
		if (t < Ne) throw new e(ta.INVALID_ARGUMENT, "Timestamp seconds out of range: " + t);
		if (t >= 253402300800) throw new e(ta.INVALID_ARGUMENT, "Timestamp seconds out of range: " + t);
	}
	/**
	* Converts a `Timestamp` to a JavaScript `Date` object. This conversion
	* causes a loss of precision since `Date` objects only support millisecond
	* precision.
	*
	* @returns JavaScript `Date` object representing the same point in time as
	*     this `Timestamp`, with millisecond precision.
	*/ toDate() {
		return new Date(this.toMillis());
	}
	/**
	* Converts a `Timestamp` to a numeric timestamp (in milliseconds since
	* epoch). This operation causes a loss of precision.
	*
	* @returns The point in time corresponding to this timestamp, represented as
	*     the number of milliseconds since Unix epoch 1970-01-01T00:00:00Z.
	*/ toMillis() {
		return 1e3 * this.seconds + this.nanoseconds / Be;
	}
	/**
	* Converts a `Timestamp` to a `Temporal.Instant` object.
	*
	* @returns `Temporal.Instant` object representing the same point in time as
	*     this `Timestamp`.
	*/ toInstant() {
		if ("undefined" == typeof Temporal || !Temporal.Instant) throw new e(ta.FAILED_PRECONDITION, "The Temporal object is not available in the current environment.");
		const t = 1000000000n * BigInt(this.seconds) + BigInt(this.nanoseconds);
		return Temporal.Instant.__PRIVATE_fromEpochNanoseconds(t);
	}
	_compareTo(e) {
		return this.seconds === e.seconds ? __PRIVATE_primitiveComparator(this.nanoseconds, e.nanoseconds) : __PRIVATE_primitiveComparator(this.seconds, e.seconds);
	}
	/**
	* Returns true if this `Timestamp` is equal to the provided one.
	*
	* @param other - The `Timestamp` to compare against.
	* @returns true if this `Timestamp` is equal to the provided one.
	*/ isEqual(e) {
		return e.seconds === this.seconds && e.nanoseconds === this.nanoseconds;
	}
	/** Returns a textual representation of this `Timestamp`. */ toString() {
		return "Timestamp(seconds=" + this.seconds + ", nanoseconds=" + this.nanoseconds + ")";
	}
	/**
	* Returns a JSON-serializable representation of this `Timestamp`.
	*/ toJSON() {
		return {
			type: Timestamp._jsonSchemaVersion,
			seconds: this.seconds,
			nanoseconds: this.nanoseconds
		};
	}
	/**
	* Builds a `Timestamp` instance from a JSON object created by {@link Timestamp.toJSON}.
	*/ static fromJSON(e) {
		if (__PRIVATE_validateJSON(e, Timestamp._jsonSchema)) return new Timestamp(e.seconds, e.nanoseconds);
	}
	/**
	* Converts this object to a primitive string, which allows `Timestamp` objects
	* to be compared using the `>`, `<=`, `>=` and `>` operators.
	*/ valueOf() {
		const e = this.seconds - Ne;
		return String(e).padStart(12, "0") + "." + String(this.nanoseconds).padStart(9, "0");
	}
};
Timestamp._jsonSchemaVersion = "firestore/timestamp/1.0", Timestamp._jsonSchema = {
	type: property("string", Timestamp._jsonSchemaVersion),
	seconds: property("number"),
	nanoseconds: property("number")
};
/**
* @license
* Copyright 2023 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* An error encountered while decoding base64 string.
*/
var __PRIVATE_Base64DecodeError = class extends Error {
	constructor() {
		super(...arguments), this.name = "Base64DecodeError";
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Immutable class that represents a "proto" byte string.
*
* Proto byte strings can either be Base64-encoded strings or Uint8Arrays when
* sent on the wire. This class abstracts away this differentiation by holding
* the proto byte string in a common class that must be converted into a string
* before being sent as a proto.
* @internal
*/ var ByteString = class ByteString {
	constructor(e) {
		this.binaryString = e;
	}
	static fromBase64String(e) {
		const t = function __PRIVATE_decodeBase64(e) {
			try {
				return atob(e);
			} catch (e) {
				throw "undefined" != typeof DOMException && e instanceof DOMException ? new __PRIVATE_Base64DecodeError("Invalid base64 string: " + e) : e;
			}
		}(e);
		return new ByteString(t);
	}
	static fromUint8Array(e) {
		const t = function __PRIVATE_binaryStringFromUint8Array(e) {
			let t = "";
			for (let n = 0; n < e.length; ++n) t += String.fromCharCode(e[n]);
			return t;
		}(e);
		return new ByteString(t);
	}
	[Symbol.iterator]() {
		let e = 0;
		return { next: () => e < this.binaryString.length ? {
			value: this.binaryString.charCodeAt(e++),
			done: false
		} : {
			value: void 0,
			done: true
		} };
	}
	toBase64() {
		return function __PRIVATE_encodeBase64(e) {
			return btoa(e);
		}(this.binaryString);
	}
	toUint8Array() {
		return function __PRIVATE_uint8ArrayFromBinaryString(e) {
			const t = new Uint8Array(e.length);
			for (let n = 0; n < e.length; n++) t[n] = e.charCodeAt(n);
			return t;
		}(this.binaryString);
		/**
		* @license
		* Copyright 2020 Google LLC
		*
		* Licensed under the Apache License, Version 2.0 (the "License");
		* you may not use this file except in compliance with the License.
		* You may obtain a copy of the License at
		*
		*   http://www.apache.org/licenses/LICENSE-2.0
		*
		* Unless required by applicable law or agreed to in writing, software
		* distributed under the License is distributed on an "AS IS" BASIS,
		* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
		* See the License for the specific language governing permissions and
		* limitations under the License.
		*/
	}
	approximateByteSize() {
		return 2 * this.binaryString.length;
	}
	compareTo(e) {
		return __PRIVATE_primitiveComparator(this.binaryString, e.binaryString);
	}
	isEqual(e) {
		return this.binaryString === e.binaryString;
	}
};
ByteString.EMPTY_BYTE_STRING = new ByteString("");
var Le$1 = /* @__PURE__ */ new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);
/**
* Converts the possible Proto values for a timestamp value into a "seconds and
* nanos" representation.
*/ function __PRIVATE_normalizeTimestamp(e) {
	if (__PRIVATE_hardAssert(!!e, 39018), "string" == typeof e) {
		let t = 0;
		const n = Le$1.exec(e);
		if (__PRIVATE_hardAssert(!!n, 46558, { timestamp: e }), n[1]) {
			let e = n[1];
			e = (e + "000000000").substr(0, 9), t = Number(e);
		}
		const r = new Date(e);
		return {
			seconds: Math.floor(r.getTime() / 1e3),
			nanos: t
		};
	}
	return {
		seconds: __PRIVATE_normalizeNumber(e.seconds),
		nanos: __PRIVATE_normalizeNumber(e.nanos)
	};
}
/**
* Converts the possible Proto types for numbers into a JavaScript number.
* Returns 0 if the value is not numeric.
*/ function __PRIVATE_normalizeNumber(e) {
	return "number" == typeof e ? e : "string" == typeof e ? Number(e) : 0;
}
/** Converts the possible Proto types for Blobs into a ByteString. */ function __PRIVATE_normalizeByteString(e) {
	return "string" == typeof e ? ByteString.fromBase64String(e) : ByteString.fromUint8Array(e);
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Represents a locally-applied ServerTimestamp.
*
* Server Timestamps are backed by MapValues that contain an internal field
* `__type__` with a value of `server_timestamp`. The previous value and local
* write time are stored in its `__previous_value__` and `__local_write_time__`
* fields respectively.
*
* Notes:
* - ServerTimestampValue instances are created as the result of applying a
*   transform. They can only exist in the local view of a document. Therefore
*   they do not need to be parsed or serialized.
* - When evaluated locally (e.g. for snapshot.data()), they by default
*   evaluate to `null`. This behavior can be configured by passing custom
*   FieldValueOptions to value().
* - With respect to other ServerTimestampValues, they sort by their
*   localWriteTime.
*/ var Ue = "server_timestamp";
var ke = "__type__";
var Qe = "__previous_value__";
var qe = "__local_write_time__";
function __PRIVATE_isServerTimestamp(e) {
	return (e?.mapValue?.fields || {})[ke]?.stringValue === Ue;
}
/**
* Creates a new ServerTimestamp proto value (using the internal format).
*/
/**
* Returns the value of the field before this ServerTimestamp was set.
*
* Preserving the previous values allows the user to display the last resoled
* value until the backend responds with the timestamp.
*/
function __PRIVATE_getPreviousValue(e) {
	const t = e.mapValue.fields[Qe];
	return __PRIVATE_isServerTimestamp(t) ? __PRIVATE_getPreviousValue(t) : t;
}
/**
* Returns the local time at which this timestamp was first set.
*/ function __PRIVATE_getLocalWriteTime(e) {
	const t = __PRIVATE_normalizeTimestamp(e.mapValue.fields[qe].timestampValue);
	return new Timestamp(t.seconds, t.nanos);
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var DatabaseInfo = class {
	/**
	* Constructs a DatabaseInfo using the provided host, databaseId and
	* persistenceKey.
	*
	* @param databaseId - The database to use.
	* @param appId - The Firebase App Id.
	* @param persistenceKey - A unique identifier for this Firestore's local
	* storage (used in conjunction with the databaseId).
	* @param host - The Firestore backend host to connect to.
	* @param ssl - Whether to use SSL when connecting.
	* @param forceLongPolling - Whether to use the forceLongPolling option
	* when using WebChannel as the network transport.
	* @param autoDetectLongPolling - Whether to use the detectBufferingProxy
	* option when using WebChannel as the network transport.
	* @param longPollingOptions - Options that configure long-polling.
	* @param useFetchStreams - Whether to use the Fetch API instead of
	* XMLHTTPRequest
	*/
	constructor(e, t, n, r, i, s, _, o, a, u, c, l, E) {
		this.databaseId = e, this.appId = t, this.persistenceKey = n, this.host = r, this.ssl = i, this.forceLongPolling = s, this.autoDetectLongPolling = _, this.longPollingOptions = o, this.useFetchStreams = a, this.isUsingEmulator = u, this.apiKey = c, this._customHeaders = l, this.grpcFlowControlWindow = E;
	}
};
/** The default database name for a project. */ var Ke = "(default)";
/**
* Represents the database ID a Firestore client is associated with.
* @internal
*/ var DatabaseId = class DatabaseId {
	constructor(e, t) {
		this.projectId = e, this.database = t || Ke;
	}
	static empty() {
		return new DatabaseId("", "");
	}
	get isDefaultDatabase() {
		return this.database === Ke;
	}
	isEqual(e) {
		return e instanceof DatabaseId && e.projectId === this.projectId && e.database === this.database;
	}
};
function __PRIVATE_databaseIdFromApp(t, n) {
	if (!Object.prototype.hasOwnProperty.apply(t.options, ["projectId"])) throw new e(ta.INVALID_ARGUMENT, "\"projectId\" not provided in firebase.initializeApp.");
	return new DatabaseId(t.options.projectId, n);
}
/**
* Copyright 2021 M.Vokhmentsev
*
* @license
* Copyright 2025 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @private
* @internal
*/ var __PRIVATE_QuadrupleBuilder = class __PRIVATE_QuadrupleBuilder {
	constructor() {
		this.exponent = 0, this.i = 0n, this.o = 0n, this.u = new Array(4).fill(0n), this.l = new Array(6).fill(0n), this.h = new Array(6).fill(0n), this.T = new Array(6).fill(0n), this.P = new Array(12).fill(0n);
	}
	static I(e, t) {
		let n = new __PRIVATE_QuadrupleBuilder();
		return n.parse(e, t), n;
	}
	parse(e, t) {
		t += e.length - 1, this.exponent = 0, this.i = 0n, this.o = 0n;
		let n = this.T, r = this.R(e, n);
		if (0 == r && this.isEmpty(n)) return;
		if ((t += r) < __PRIVATE_QuadrupleBuilder.A) return;
		if (t > __PRIVATE_QuadrupleBuilder.V) return void (this.exponent = Number(__PRIVATE_QuadrupleBuilder.m));
		let i = this.p(t, n);
		this.S(t, i, n);
	}
	R(e, t) {
		for (let e = 0; e < 6; e++) t[e] = 0n;
		let n = 0;
		for (; n < e.length && 0 == e[n];) n += 1;
		if (n == e.length) return 0;
		let r = -n;
		if (e.length - n > __PRIVATE_QuadrupleBuilder.v) {
			let t = e[__PRIVATE_QuadrupleBuilder.v] >= 5, i = new Array(__PRIVATE_QuadrupleBuilder.v).fill(0);
			for (let t = 0; t < __PRIVATE_QuadrupleBuilder.v; t++) i[t] = e[t + n];
			t && (r += this.D(i)), e = i, n = 0;
		}
		for (let r = e.length - 1; r >= n; r--) t[0] |= BigInt(e[r]) << 32n, this.C(t);
		return r;
	}
	C(e) {
		let t = e.length;
		for (let n = 0; n < t; n++) {
			let r = e[n] % 10n;
			e[n] = e[n] / 10n, n + 1 < t && (e[n + 1] += r << 32n);
		}
	}
	isEmpty(e) {
		for (let t = 0; t < e.length; t++) if (0n != e[t]) return false;
		return true;
	}
	D(e) {
		for (let t = e.length - 1; t >= 0; t--) {
			if (9 != e[t]) return e[t] = e[t] + 1, 0;
			e[t] = 0;
		}
		return e[0] = 1, 1;
	}
	p(e, t) {
		let n = t[0] << 31n | t[1] >> 1n, r = Number(n) / __PRIVATE_QuadrupleBuilder.F;
		return Math.floor(Number(e) * __PRIVATE_QuadrupleBuilder.O + this.log2(r));
	}
	log2(e) {
		return __PRIVATE_QuadrupleBuilder.M * Math.log(e);
	}
	S(e, t, n) {
		let r = this.u;
		this.N(-t, r);
		let i = this.P;
		this.B(n, r, i), this.L(i), BigInt(r[0]) != BigInt(-e) && this.L(i), t += this.U(i), (t += __PRIVATE_QuadrupleBuilder.k) <= 0 || (t += this.q(i), BigInt(t) >= __PRIVATE_QuadrupleBuilder.m ? this.exponent = Number(__PRIVATE_QuadrupleBuilder.m) : (this.exponent = Number(t), this.i = (i[0] << 32n) + i[1] & 18446744073709551615n, this.o = (i[2] << 32n) + i[3] & 18446744073709551615n));
	}
	N(e, t) {
		if (0 == e) return void this.K(__PRIVATE_QuadrupleBuilder.$[0], t);
		let n = __PRIVATE_QuadrupleBuilder.$;
		e < 0 && (e = -e, n = __PRIVATE_QuadrupleBuilder.W);
		let r = __PRIVATE_QuadrupleBuilder.G, i = 32, s = true;
		for (; e > 0;) e >= r && (s ? (this.K(n[i], t), s = false) : this.j(t, n[i], t), e -= r), i -= 1, r *= .5;
	}
	K(e, t) {
		for (let n = 0; n < t.length; n++) t[n] = e[n];
	}
	j(e, t, n) {
		this.H(e, t, this.P);
		let r = this.J(this.P);
		this.Y(this.P, n), n[0] = e[0] + t[0] + BigInt(r);
	}
	H(e, t, n) {
		for (let e = 0; e < n.length; e++) n[e] = 0n;
		this.Z(e, this.l), this.Z(t, this.h);
		for (let e = 5; e >= 0; e--) for (let t = 5; t >= 0; t--) {
			let r = this.l[e] * this.h[t];
			n[t + e + 1] = n[t + e + 1] + (r & __PRIVATE_QuadrupleBuilder.X) & 18446744073709551615n, n[t + e] = n[t + e] + (r >> 32n) & 18446744073709551615n;
		}
		for (let e = 11; e >= 1; e--) n[e - 1] = n[e - 1] + (n[e] >> 32n) & 18446744073709551615n, n[e] &= __PRIVATE_QuadrupleBuilder.X;
	}
	J(e) {
		let t = 0;
		for (; this.ee(e);) this.L(e), t -= 1;
		return t;
	}
	ee(e) {
		if (e[0] < 429496729n) return true;
		if (e[0] > 429496729n) return false;
		for (let t = 1; t < e.length; t++) {
			if (e[t] < 2576980377n) return true;
			if (e[t] > 2576980377n) return false;
		}
		return false;
	}
	B(e, t, n) {
		for (let e = 0; e < n.length; e++) n[e] = 0n;
		let r = this.h;
		this.Z(t, r);
		let i = e.length;
		for (let t = i - 1; t >= 0; t--) for (let s = i - 1; s >= 0; s--) {
			let i = e[t] * r[s];
			n[s + t + 1] = n[s + t + 1] + (i & __PRIVATE_QuadrupleBuilder.X) & 18446744073709551615n, n[s + t] = n[s + t] + (i >> 32n) & 18446744073709551615n;
		}
		for (let e = 11; e >= 1; e--) n[e - 1] = n[e - 1] + (n[e] >> 32n) & 18446744073709551615n, n[e] &= __PRIVATE_QuadrupleBuilder.X;
	}
	L(e) {
		let t = e.length - 1;
		e[0] &= __PRIVATE_QuadrupleBuilder.X, e[t] *= 10n;
		for (let n = t - 1; n >= 0; n--) e[n] = 10n * e[n] + (e[n + 1] >> 32n) & 18446744073709551615n, e[n + 1] &= __PRIVATE_QuadrupleBuilder.X;
	}
	U(e) {
		let t = 31 - __PRIVATE_QuadrupleBuilder.te(e[0]);
		return 0 != t && this.ne(e, t), t;
	}
	q(e) {
		return this.re(e, 5, 100n), this.re(e, 4, 2147483648n), 0n != (e[0] & __PRIVATE_QuadrupleBuilder.ie << 1n) ? (this.ne(e, 1), 1) : 0;
	}
	Y(e, t) {
		t[1] = (e[0] << 32n) + e[1], t[2] = (e[2] << 32n) + e[3], t[3] = (e[4] << 32n) + e[5];
	}
	Z(e, t) {
		t[0] = e[1] >> 32n, t[1] = e[1] & __PRIVATE_QuadrupleBuilder.X, t[2] = e[2] >> 32n, t[3] = e[2] & __PRIVATE_QuadrupleBuilder.X, t[4] = e[3] >> 32n, t[5] = e[3] & __PRIVATE_QuadrupleBuilder.X;
	}
	ne(e, t) {
		let n = e.length - 1, r = BigInt(32 - Math.abs(t));
		if (t > 0) {
			let i = BigInt(t);
			for (let t = n + 1 - 1; t >= 1; t--) e[t] = e[t] >> i | e[t - 1] << r & __PRIVATE_QuadrupleBuilder.X;
			e[0] = e[0] >> i;
		} else if (t < 0) {
			let i = BigInt(-t);
			e[0] = 18446744073709551615n & (e[0] << i | e[1] >> r);
			for (let t = 1; t < n; t++) e[t] = 18446744073709551615n & (e[t] << i & __PRIVATE_QuadrupleBuilder.X | e[t + 1] >> r);
			e[n] = e[n] << i & __PRIVATE_QuadrupleBuilder.X;
		}
	}
	re(e, t, n) {
		let r = t;
		e[r] = e[r] + n & 18446744073709551615n;
		for (let t = r + 1 - 1; t >= 1 && 0n != (e[t] & __PRIVATE_QuadrupleBuilder.ie); t--) e[t] &= __PRIVATE_QuadrupleBuilder.X, e[t - 1] += 1n;
	}
	static te(e) {
		let t = Number(e >> 32n);
		return 0 == t ? 32 + Math.clz32(Number(BigInt.asUintN(32, e))) : Math.clz32(t);
	}
};
/**
* @license
* Copyright 2025 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var $e;
var We;
var Ge;
var je;
var ze;
var He;
/**
* @private
* @internal
*/ __PRIVATE_QuadrupleBuilder.v = 59, __PRIVATE_QuadrupleBuilder.V = 646456993, __PRIVATE_QuadrupleBuilder.A = -646457032, __PRIVATE_QuadrupleBuilder.F = 0xccccccccccccd00, __PRIVATE_QuadrupleBuilder.se = 9223372036854775808n, __PRIVATE_QuadrupleBuilder.G = 2147483648, __PRIVATE_QuadrupleBuilder.X = 4294967295n, __PRIVATE_QuadrupleBuilder.ie = 18446744069414584320n, __PRIVATE_QuadrupleBuilder.O = Math.log(10) / Math.log(2), __PRIVATE_QuadrupleBuilder.M = 1 / Math.log(2), __PRIVATE_QuadrupleBuilder.k = 2147483647, __PRIVATE_QuadrupleBuilder.m = 4294967295n, __PRIVATE_QuadrupleBuilder.$ = [
	[
		1n,
		1844674407370955161n,
		11068046444225730969n,
		11068046444225730970n
	],
	[
		1n,
		3689348814741910323n,
		3689348814741910323n,
		3689348814741910324n
	],
	[
		1n,
		7378697629483820646n,
		7378697629483820646n,
		7378697629483820647n
	],
	[
		2n,
		2951479051793528258n,
		10330176681277348904n,
		17708874310761169552n
	],
	[
		3n,
		4722366482869645213n,
		12838933875301847924n,
		13576803638250229990n
	],
	[
		5n,
		12089258196146291747n,
		1139270913992301907n,
		14834133714314273028n
	],
	[
		10n,
		7922816251426433759n,
		6537434485812897421n,
		10943610198455522670n
	],
	[
		20n,
		3402823669209384634n,
		11690551640656395617n,
		434502812078806219n
	],
	[
		39n,
		6277101735386680763n,
		15417593589425144845n,
		4980338030897529499n
	],
	[
		78n,
		2135987035920910082n,
		7286864317269821293n,
		1470929914900401402n
	],
	[
		155n,
		2473304014731045340n,
		11160745210636643808n,
		17197624135881608752n
	],
	[
		309n,
		3316158518186977171n,
		1610101194367568473n,
		2505321366944869367n
	],
	[
		617n,
		5961435402259919231n,
		8541288306462491492n,
		12917583404895345239n
	],
	[
		1234n,
		1926557440885621868n,
		10330761220174613655n,
		4973663491106771606n
	],
	[
		2467n,
		2012075170664720308n,
		5203521067837755057n,
		4252902708988064798n
	],
	[
		4933n,
		2194667241128661798n,
		9997912988788550371n,
		2882452207710407228n
	],
	[
		9865n,
		2611064738599533141n,
		4667649273809606933n,
		5480838552042273826n
	],
	[
		19729n,
		3695860387023220540n,
		11618221355217427600n,
		15743111447059609512n
	],
	[
		39457n,
		7404766904006053691n,
		12160444268087321627n,
		5501995613499181412n
	],
	[
		78914n,
		2972371312984624324n,
		9931534487804675078n,
		3934513978629065883n
	],
	[
		157827n,
		4789458338529041696n,
		8874761816389274466n,
		17334709082760258060n
	],
	[
		315653n,
		12435208666009569532n,
		53738705337609241n,
		5451751215914427447n
	],
	[
		631306n,
		8382748410739091470n,
		5595760811601129281n,
		5808897528453025485n
	],
	[
		1262612n,
		3809369861530133413n,
		7258727891356815428n,
		12698775008535499593n
	],
	[
		2525223n,
		7866590810795563528n,
		11575482952928815984n,
		1738499114246505760n
	],
	[
		5050446n,
		3354697757892663011n,
		3122677384963859433n,
		1903788099230575219n
	],
	[
		10100891n,
		6100804023648459231n,
		15587055094752631951n,
		12467802392503039034n
	],
	[
		20201782n,
		2017689928707321463n,
		11400993815251097644n,
		15657595017903947855n
	],
	[
		40403563n,
		2206932904874568912n,
		10086775996354462822n,
		7871099721466003992n
	],
	[
		80807125n,
		2640331988754402584n,
		17494500724586232665n,
		12073153853204213065n
	],
	[
		161614249n,
		3779178039757925203n,
		4593549380955514492n,
		2162745452984644395n
	],
	[
		323228497n,
		7742388900241556266n,
		8212051283157458959n,
		10362106829961871628n
	],
	[
		646456994n,
		3249602512132054904n,
		4645955491659115631n,
		2401850457105738694n
	]
], __PRIVATE_QuadrupleBuilder.W = [
	[
		1n,
		1844674407370955161n,
		11068046444225730969n,
		11068046444225730970n
	],
	[
		0n,
		9223372036854775808n,
		0n,
		0n
	],
	[
		0n,
		4611686018427387904n,
		0n,
		1n
	],
	[
		-1n,
		11529215046068469760n,
		0n,
		0n
	],
	[
		-2n,
		7205759403792793600n,
		0n,
		0n
	],
	[
		-4n,
		2814749767106560000n,
		0n,
		1n
	],
	[
		-9n,
		4294967296000000000n,
		0n,
		1n
	],
	[
		-19n,
		10000000000000000000n,
		0n,
		0n
	],
	[
		-38n,
		5421010862427522170n,
		687399551400673280n,
		1n
	],
	[
		-77n,
		15930919111324522770n,
		5327493063679123134n,
		12292710897160462338n
	],
	[
		-154n,
		13758210268297397763n,
		12320534732722919674n,
		6675599427733050225n
	],
	[
		-308n,
		10261342003245940623n,
		6273243709394548296n,
		6440670082096085128n
	],
	[
		-616n,
		5708060961156115120n,
		9326959349272872362n,
		14394422795431165174n
	],
	[
		-1233n,
		17662715873372225491n,
		16018126490311694428n,
		5356816969625239316n
	],
	[
		-2466n,
		16912010638674145271n,
		1614368466976504750n,
		8601533998869527035n
	],
	[
		-4932n,
		15504964057600816844n,
		16725227620538152213n,
		14050867044384726477n
	],
	[
		-9864n,
		13032322097974936284n,
		15317032172363146549n,
		6308761762498734157n
	],
	[
		-19728n,
		9207121787276552771n,
		2686637268731583271n,
		6864278666688451401n
	],
	[
		-39456n,
		4595450084145690875n,
		7667683976197477395n,
		449294573396472465n
	],
	[
		-78913n,
		11448178275521484223n,
		3110751028328854690n,
		1120171678522345134n
	],
	[
		-157826n,
		7104819436125367673n,
		14991248556251613302n,
		16820949487516534012n
	],
	[
		-315652n,
		2736442757499254003n,
		4679685605244421446n,
		11731094814065673062n
	],
	[
		-631305n,
		4059317424879466168n,
		1990423776449209129n,
		14056183348504135159n
	],
	[
		-1262611n,
		8932773117080711014n,
		7396631747502695834n,
		11647671188648399829n
	],
	[
		-2525222n,
		4325665019387541401n,
		14660155504483916480n,
		5763493405214599753n
	],
	[
		-5050445n,
		10143458262979115930n,
		7822744214343089676n,
		1615945487545495999n
	],
	[
		-10100890n,
		5577664281657086504n,
		2124849129118726579n,
		8904011362647467789n
	],
	[
		-20201781n,
		16864948477933278509n,
		13298207519877393505n,
		10179411950183364575n
	],
	[
		-40403562n,
		15418790764745900618n,
		12109694407689697456n,
		12044714451038874750n
	],
	[
		-80807124n,
		12887862903992969105n,
		14515304112506087704n,
		320416584029509902n
	],
	[
		-161614248n,
		9004136966850474441n,
		7308686012685280919n,
		1358577080284203015n
	],
	[
		-323228496n,
		4395056503947017296n,
		13747437776819292273n,
		16250244679374086836n
	],
	[
		-646456993n,
		10471507381303696026n,
		4273141307571403437n,
		18050914191569890740n
	]
];
var __PRIVATE_Quadruple = class __PRIVATE_Quadruple {
	constructor(e, t, n, r) {
		this.negative = e, this._e = t, this.i = n, this.o = r;
	}
	/** Return the (unbiased) exponent of this {@link Quadruple}. */ exponent() {
		return this._e - __PRIVATE_QuadrupleBuilder.k;
	}
	/** Return true if this {@link Quadruple} is -0 or +0 */ oe() {
		return 0 === this._e && 0n === this.i && 0n === this.o;
	}
	/** Return true if this {@link Quadruple} is -infinity or +infinity */ ae() {
		return this._e === __classPrivateFieldGet(__PRIVATE_Quadruple, $e, "f", We) && 0n === this.i && 0n === this.o;
	}
	/** Return true if this {@link Quadruple} is a NaN. */ isNaN() {
		return this._e === __classPrivateFieldGet(__PRIVATE_Quadruple, $e, "f", We) && !(0n === this.i && 0n === this.o);
	}
	/** Compare two quadruples, with -0 < 0, and all NaNs equal and larger than all numbers. */ compareTo(e) {
		if (this.isNaN()) return e.isNaN() ? 0 : 1;
		if (e.isNaN()) return -1;
		let t, n;
		if (this.negative) {
			if (!e.negative) return -1;
			t = 1, n = -1;
		} else {
			if (e.negative) return 1;
			t = -1, n = 1;
		}
		return this._e < e._e ? t : this._e > e._e ? n : this.i < e.i ? t : this.i > e.i ? n : this.o < e.o ? t : this.o > e.o ? n : 0;
	}
	debug() {
		return (this.negative ? "+" : "-") + __classPrivateFieldGet(__PRIVATE_Quadruple, $e, "m", Ge).call(__PRIVATE_Quadruple, this.i) + __classPrivateFieldGet(__PRIVATE_Quadruple, $e, "m", Ge).call(__PRIVATE_Quadruple, this.o) + "*2^" + this.exponent();
	}
	static fromNumber(e) {
		if (isNaN(e)) return __PRIVATE_Quadruple.NaN;
		if (!isFinite(e)) return e < 0 ? __PRIVATE_Quadruple.ue : __PRIVATE_Quadruple.ce;
		if (0 === e) return Math.sign(1 / e) > 0 ? __PRIVATE_Quadruple.le : __PRIVATE_Quadruple.Ee;
		const t = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(8));
		t.setFloat64(0, e);
		const n = t.getBigUint64(0);
		let r = BigInt.asUintN(64, n << 12n), i = 2047 & Number(n >> 52n);
		if (0 === i) {
			const e = __PRIVATE_QuadrupleBuilder.te(r);
			r = e < 63 ? r << BigInt(e + 1) : 0n, i = -e;
		}
		return new __PRIVATE_Quadruple(e < 0, __classPrivateFieldGet(__PRIVATE_Quadruple, $e, "m", He).call(__PRIVATE_Quadruple, i - 1023), r, 0n);
	}
	/**
	* Converts a decimal number to a {@link Quadruple}. The supported format (no whitespace allowed)
	* is:
	*
	* <ul>
	*   <li><code>NaN</code> for Quadruple.NaN
	*   <li><code>Infinity</code> or <code>+Infinity</code> for Quadruple.POSITIVE_INFINITY
	*   <li><code>-Infinity</code> for Quadruple.NEGATIVE_INFINITY
	*   <li>String matching the regular expression: <code>[+-]?[0-9]*(\.[0-9]*)?([eE][+-]?[0-9]+)?</code> - the exponent cannot be more
	*       than 9 digits, and the whole string cannot be empty
	* </ul>
	*/ static fromString(e) {
		if ("NaN" === e) return __PRIVATE_Quadruple.NaN;
		if ("-Infinity" === e) return __PRIVATE_Quadruple.ue;
		if ("Infinity" === e || "+Infinity" === e) return __PRIVATE_Quadruple.ce;
		const t = new Array(e.length).fill(0);
		let n = 0, r = 0, i = 0, s = false;
		for ("-" === e[n] ? (s = true, n++) : "+" === e[n] && n++; __classPrivateFieldGet(__PRIVATE_Quadruple, $e, "m", je).call(__PRIVATE_Quadruple, e, n);) t[r++] = __classPrivateFieldGet(__PRIVATE_Quadruple, $e, "m", ze).call(__PRIVATE_Quadruple, e, n++);
		if ("." === e[n]) {
			const s = ++n;
			for (; __classPrivateFieldGet(__PRIVATE_Quadruple, $e, "m", je).call(__PRIVATE_Quadruple, e, n);) t[r++] = __classPrivateFieldGet(__PRIVATE_Quadruple, $e, "m", ze).call(__PRIVATE_Quadruple, e, n++);
			i = s - n;
		}
		if ("e" === e[n] || "E" === e[n]) {
			let t = 0;
			n++;
			let r = 1;
			"-" === e[n] ? (r = -1, n++) : "+" === e[n] && n++;
			const s = n;
			for (; __classPrivateFieldGet(__PRIVATE_Quadruple, $e, "m", je).call(__PRIVATE_Quadruple, e, n);) if (t = 10 * t + __classPrivateFieldGet(__PRIVATE_Quadruple, $e, "m", ze).call(__PRIVATE_Quadruple, e, n++), n - s > 9) throw new Error("Exponent too large " + e);
			if (n === s) throw new Error("Invalid number " + e);
			i += t * r;
		}
		if (0 === r || n !== e.length) throw new Error("Invalid number " + e);
		const _ = __PRIVATE_QuadrupleBuilder.I(t.slice(0, r), i);
		return new __PRIVATE_Quadruple(s, _.exponent, _.i, _.o);
	}
};
$e = __PRIVATE_Quadruple, Ge = function ___PRIVATE_Quadruple_hex(e) {
	return e.toString(16).padStart(16, "0");
}, je = function ___PRIVATE_Quadruple_isDigit(e, t) {
	const n = e.codePointAt(t);
	return void 0 !== n && n >= 48 && n <= 57;
}, ze = function ___PRIVATE_Quadruple_digit(e, t) {
	return e.codePointAt(t) - 48;
}, He = function ___PRIVATE_Quadruple_bias(e) {
	return e + __PRIVATE_QuadrupleBuilder.k;
}, We = { value: Number(__PRIVATE_QuadrupleBuilder.m) }, __PRIVATE_Quadruple.le = new __PRIVATE_Quadruple(false, 0, 0n, 0n), __PRIVATE_Quadruple.Ee = new __PRIVATE_Quadruple(true, 0, 0n, 0n), __PRIVATE_Quadruple.NaN = new __PRIVATE_Quadruple(false, __classPrivateFieldGet(__PRIVATE_Quadruple, $e, "f", We), 1n << 63n, 0n), __PRIVATE_Quadruple.ue = new __PRIVATE_Quadruple(true, __classPrivateFieldGet(__PRIVATE_Quadruple, $e, "f", We), 0n, 0n), __PRIVATE_Quadruple.ce = new __PRIVATE_Quadruple(false, __classPrivateFieldGet(__PRIVATE_Quadruple, $e, "f", We), 0n, 0n), new __PRIVATE_Quadruple(true, __classPrivateFieldGet(__PRIVATE_Quadruple, $e, "m", He).call(__PRIVATE_Quadruple, 63), 0n, 0n), new __PRIVATE_Quadruple(false, __classPrivateFieldGet(__PRIVATE_Quadruple, $e, "m", He).call(__PRIVATE_Quadruple, 0), 0n, 0n), new __PRIVATE_Quadruple(true, __classPrivateFieldGet(__PRIVATE_Quadruple, $e, "m", He).call(__PRIVATE_Quadruple, 0), 0n, 0n);
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/** Sentinel value that sorts before any Mutation Batch ID. */
var Je = -1;
/**
* Returns whether a variable is either undefined or null.
*/ function __PRIVATE_isNullOrUndefined(e) {
	return null == e;
}
/** Returns whether the value represents -0. */ function __PRIVATE_isNegativeZero(e) {
	return 0 === e && 1 / e == -1 / 0;
}
/**
* Returns whether a value is an integer and in the safe integer range
* @param value - The value to test for being an integer and in the safe range
*/ function isSafeInteger(e) {
	return "number" == typeof e && Number.isInteger(e) && !__PRIVATE_isNegativeZero(e) && e <= Number.MAX_SAFE_INTEGER && e >= Number.MIN_SAFE_INTEGER;
}
function __PRIVATE_isString$1(e) {
	return "string" == typeof e;
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var Ye = "__type__";
var Ze = "__vector__";
var Xe = "value";
var et = "server_timestamp";
var tt = "__min__";
var nt = "__max__";
var rt = "__regex__";
var it = "pattern";
var st = "options";
var _t = "__oid__";
var ot = "__int__";
var at = "__decimal128__";
var ut = "__request_timestamp__";
var ct = "seconds";
var lt = "increment";
var Et = "__binary__";
var ht = { nullValue: "NULL_VALUE" };
var Tt = { mapValue: { fields: { __type__: { stringValue: nt } } } };
var dt;
var mt;
(mt = dt || (dt = {})).he = "regexValue", mt.Te = "bsonObjectIdValue", mt.Pe = "int32Value", mt.Ie = "decimal128Value", mt.Re = "bsonTimestampValue", mt.Ae = "bsonBinaryValue", mt.Ve = "minKeyValue", mt.fe = "maxKeyValue", mt.de = "maxValue", mt.me = "vectorValue", mt.pe = "serverTimestampValue", mt.ge = "regularMapValue";
var pt = {
	[Ze]: dt.me,
	[nt]: dt.de,
	[et]: dt.pe
};
var gt = {
	[rt]: dt.he,
	[_t]: dt.Te,
	[ot]: dt.Pe,
	[at]: dt.Ie,
	[ut]: dt.Re,
	[Et]: dt.Ae,
	[tt]: dt.Ve,
	[nt]: dt.fe
};
var yt = new Set(Object.values(gt));
var wt = { booleanValue: true };
var bt = { booleanValue: false };
/** Extracts the backend's type order for the provided value. */
function __PRIVATE_typeOrder(e) {
	if ("nullValue" in e) return 0;
	if ("booleanValue" in e) return 2;
	if ("integerValue" in e || "doubleValue" in e) return 3;
	if ("timestampValue" in e) return 4;
	if ("stringValue" in e) return 7;
	if ("bytesValue" in e) return 8;
	if ("referenceValue" in e) return 9;
	if ("geoPointValue" in e) return 11;
	if ("arrayValue" in e) return 13;
	if (!("mapValue" in e)) return l(28295, { value: e });
	switch (__PRIVATE_detectMapRepresentation(e)) {
		case dt.pe: return 6;
		case dt.de: return 9007199254740991;
		case dt.me: return 14;
		case dt.he: return 12;
		case dt.Te: return 10;
		case dt.Pe:
		case dt.Ie: return 3;
		case dt.Re: return 5;
		case dt.Ae: return 8;
		case dt.Ve: return 1;
		case dt.fe: return 16;
		default: return 15;
	}
}
/** Tests `left` and `right` for equality based on the backend semantics. */ function __PRIVATE_valueEquals$1(e, t, n) {
	if (e === t) return true;
	const r = __PRIVATE_typeOrder(e);
	if (r !== __PRIVATE_typeOrder(t)) return false;
	switch (r) {
		case 0:
		case 9007199254740991:
		case 16:
		case 1: return true;
		case 2: return e.booleanValue === t.booleanValue;
		case 6: return __PRIVATE_getLocalWriteTime(e).isEqual(__PRIVATE_getLocalWriteTime(t));
		case 4: return function __PRIVATE_timestampEquals(e, t) {
			if ("string" == typeof e.timestampValue && "string" == typeof t.timestampValue && e.timestampValue.length === t.timestampValue.length) return e.timestampValue === t.timestampValue;
			const n = __PRIVATE_normalizeTimestamp(e.timestampValue), r = __PRIVATE_normalizeTimestamp(t.timestampValue);
			return n.seconds === r.seconds && n.nanos === r.nanos;
		}(e, t);
		case 7: return e.stringValue === t.stringValue;
		case 8: return function __PRIVATE_blobEquals(e, t) {
			return 0 === __PRIVATE_compareBlobsAndSubtype(e, t);
		}(e, t);
		case 9: return e.referenceValue === t.referenceValue;
		case 11: return function __PRIVATE_geoPointEquals(e, t) {
			return __PRIVATE_normalizeNumber(e.geoPointValue.latitude) === __PRIVATE_normalizeNumber(t.geoPointValue.latitude) && __PRIVATE_normalizeNumber(e.geoPointValue.longitude) === __PRIVATE_normalizeNumber(t.geoPointValue.longitude);
		}(e, t);
		case 3: return function __PRIVATE_numberEquals(e, t, n) {
			if (__PRIVATE_isDecimal128Value(e) && __PRIVATE_isDecimal128Value(t)) return 0 === __PRIVATE_compareQuadruples(e, t);
			if ("integerValue" in e && "integerValue" in t || __PRIVATE_isInt32Value(e) && __PRIVATE_isInt32Value(t)) return __PRIVATE_extractNumber(e) === __PRIVATE_extractNumber(t);
			let r, i;
			if ("doubleValue" in e && "doubleValue" in t) r = __PRIVATE_normalizeNumber(e.doubleValue), i = __PRIVATE_normalizeNumber(t.doubleValue);
			else {
				if (!n?.ye) return false;
				r = __PRIVATE_normalizeNumber(e.integerValue ?? e.doubleValue), i = __PRIVATE_normalizeNumber(t.integerValue ?? t.doubleValue);
			}
			if (r === i) return !!n?.we || __PRIVATE_isNegativeZero(r) === __PRIVATE_isNegativeZero(i);
			return !!(void 0 === n || n.be) && isNaN(r) && isNaN(i);
		}(e, t, n);
		case 13: return __PRIVATE_arrayEquals(e.arrayValue.values || [], t.arrayValue.values || [], ((e, t) => __PRIVATE_valueEquals$1(e, t, n)));
		case 14:
		case 15: return function __PRIVATE_objectEquals(e, t, n) {
			const r = e.mapValue.fields || {}, i = t.mapValue.fields || {};
			if (__PRIVATE_objectSize(r) !== __PRIVATE_objectSize(i)) return false;
			for (const e in r) if (r.hasOwnProperty(e) && (void 0 === i[e] || !__PRIVATE_valueEquals$1(r[e], i[e], n))) return false;
			return true;
		}(e, t, n);
		case 5: return 0 === __PRIVATE_compareBsonTimestamps(e, t);
		case 12: return 0 === __PRIVATE_compareRegex(e, t);
		case 10: return 0 === __PRIVATE_compareBsonObjectIds(e, t);
		default: return l(52216, { left: e });
	}
}
function __PRIVATE_arrayValueContains(e, t) {
	return void 0 !== (e.values || []).find(((e) => __PRIVATE_valueEquals$1(e, t)));
}
function __PRIVATE_valueCompare(e, t) {
	if (e === t) return 0;
	const n = __PRIVATE_typeOrder(e), r = __PRIVATE_typeOrder(t);
	if (n !== r) return __PRIVATE_primitiveComparator(n, r);
	switch (n) {
		case 0:
		case 1:
		case 16:
		case 9007199254740991: return 0;
		case 2: return __PRIVATE_primitiveComparator(e.booleanValue, t.booleanValue);
		case 3: return __PRIVATE_compareNumbers(e, t);
		case 4: return __PRIVATE_compareTimestamps(e.timestampValue, t.timestampValue);
		case 6: return __PRIVATE_compareTimestamps(__PRIVATE_getLocalWriteTime(e), __PRIVATE_getLocalWriteTime(t));
		case 7: return __PRIVATE_compareUtf8Strings(e.stringValue, t.stringValue);
		case 8: return __PRIVATE_compareBlobsAndSubtype(e, t);
		case 9: return function __PRIVATE_compareReferences(e, t) {
			const n = e.split("/"), r = t.split("/");
			for (let e = 0; e < n.length && e < r.length; e++) {
				const t = __PRIVATE_primitiveComparator(n[e], r[e]);
				if (0 !== t) return t;
			}
			return __PRIVATE_primitiveComparator(n.length, r.length);
		}(e.referenceValue, t.referenceValue);
		case 11: return function __PRIVATE_compareGeoPoints(e, t) {
			const n = __PRIVATE_primitiveComparator(__PRIVATE_normalizeNumber(e.latitude), __PRIVATE_normalizeNumber(t.latitude));
			if (0 !== n) return n;
			return __PRIVATE_primitiveComparator(__PRIVATE_normalizeNumber(e.longitude), __PRIVATE_normalizeNumber(t.longitude));
		}(e.geoPointValue, t.geoPointValue);
		case 13: return __PRIVATE_compareArrays(e.arrayValue, t.arrayValue);
		case 14: return function __PRIVATE_compareVectors(e, t) {
			const n = e.fields || {}, r = t.fields || {}, i = n[Xe]?.arrayValue, s = r[Xe]?.arrayValue, _ = __PRIVATE_primitiveComparator(i?.values?.length || 0, s?.values?.length || 0);
			if (0 !== _) return _;
			return __PRIVATE_compareArrays(i, s);
		}(e.mapValue, t.mapValue);
		case 15: return function __PRIVATE_compareMaps(e, t) {
			if (e === Tt.mapValue && t === Tt.mapValue) return 0;
			if (e === Tt.mapValue) return 1;
			if (t === Tt.mapValue) return -1;
			const n = e.fields || {}, r = Object.keys(n), i = t.fields || {}, s = Object.keys(i);
			r.sort(), s.sort();
			for (let e = 0; e < r.length && e < s.length; ++e) {
				const t = __PRIVATE_compareUtf8Strings(r[e], s[e]);
				if (0 !== t) return t;
				const _ = __PRIVATE_valueCompare(n[r[e]], i[s[e]]);
				if (0 !== _) return _;
			}
			return __PRIVATE_primitiveComparator(r.length, s.length);
		}(e.mapValue, t.mapValue);
		case 5: return __PRIVATE_compareBsonTimestamps(e, t);
		case 12: return __PRIVATE_compareRegex(e, t);
		case 10: return __PRIVATE_compareBsonObjectIds(e, t);
		default: throw l(23264, { Se: n });
	}
}
function __PRIVATE_extractNumber(e) {
	let t;
	return t = __PRIVATE_isInt32Value(e) ? e.mapValue.fields[ot].integerValue : e.integerValue || e.doubleValue, __PRIVATE_normalizeNumber(t);
}
function __PRIVATE_getDecimal128StringValue(e) {
	return e.mapValue.fields[at].stringValue;
}
function __PRIVATE_compareNumbers(e, t) {
	if (__PRIVATE_isDecimal128Value(e) || __PRIVATE_isDecimal128Value(t)) return __PRIVATE_compareQuadruples(e, t);
	const n = __PRIVATE_extractNumber(e), r = __PRIVATE_extractNumber(t);
	return isNaN(n) ? isNaN(r) ? 0 : -1 : isNaN(r) ? 1 : __PRIVATE_primitiveComparator(n, r);
}
function __PRIVATE_compareQuadruples(e, t) {
	const n = __PRIVATE_convertNumberToQuadruple(e), r = __PRIVATE_convertNumberToQuadruple(t);
	return n.oe() && r.oe() ? 0 : n.isNaN() ? r.isNaN() ? 0 : -1 : r.isNaN() ? 1 : n.compareTo(r);
}
function __PRIVATE_convertNumberToQuadruple(e) {
	return __PRIVATE_isDecimal128Value(e) ? __PRIVATE_Quadruple.fromString(__PRIVATE_getDecimal128StringValue(e)) : __PRIVATE_Quadruple.fromNumber(__PRIVATE_extractNumber(e));
}
function __PRIVATE_compareTimestamps(e, t) {
	if ("string" == typeof e && "string" == typeof t && e.length === t.length) return __PRIVATE_primitiveComparator(e, t);
	const n = __PRIVATE_normalizeTimestamp(e), r = __PRIVATE_normalizeTimestamp(t), i = __PRIVATE_primitiveComparator(n.seconds, r.seconds);
	return 0 !== i ? i : __PRIVATE_primitiveComparator(n.nanos, r.nanos);
}
function __PRIVATE_compareArrays(e, t) {
	const n = e.values || [], r = t.values || [];
	for (let e = 0; e < n.length && e < r.length; ++e) {
		const t = __PRIVATE_valueCompare(n[e], r[e]);
		if (void 0 !== t && 0 !== t) return t;
	}
	return __PRIVATE_primitiveComparator(n.length, r.length);
}
function __PRIVATE_compareBsonTimestamps(e, t) {
	const n = e.mapValue.fields?.[ut].mapValue?.fields?.[ct], r = t.mapValue.fields?.[ut].mapValue?.fields?.[ct], i = e.mapValue.fields?.[ut].mapValue?.fields?.[lt], s = t.mapValue.fields?.[ut].mapValue?.fields?.[lt], _ = __PRIVATE_compareNumbers(n, r);
	return 0 !== _ ? _ : __PRIVATE_compareNumbers(i, s);
}
function __PRIVATE_getBytesAndSubtype(e) {
	if ("bytesValue" in e) return {
		subtype: 0,
		bytes: __PRIVATE_normalizeByteString(e.bytesValue)
	};
	const r = ((e.mapValue?.fields)?.[Et])?.bytesValue;
	if (!r) throw new Error("Received incorrect value for BsonBinaryData");
	const i = __PRIVATE_normalizeByteString(r).toUint8Array();
	if (0 === i.length) throw new Error("Received empty bytesValue for BsonBinaryData");
	const s = i[0], _ = i.slice(1);
	return {
		subtype: s,
		bytes: ByteString.fromUint8Array(_)
	};
}
function __PRIVATE_compareBlobsAndSubtype(e, t) {
	const n = __PRIVATE_getBytesAndSubtype(e), r = __PRIVATE_getBytesAndSubtype(t);
	return n.subtype !== r.subtype ? n.subtype < r.subtype ? -1 : 1 : n.bytes.compareTo(r.bytes);
}
function __PRIVATE_compareRegex(e, t) {
	const n = e.mapValue.fields, r = n?.[rt]?.mapValue?.fields?.[it]?.stringValue ?? "", i = n?.[rt]?.mapValue?.fields?.[st]?.stringValue ?? "", s = t.mapValue.fields, _ = s?.[rt]?.mapValue?.fields?.[it]?.stringValue ?? "", o = s?.[rt]?.mapValue?.fields?.[st]?.stringValue ?? "", a = __PRIVATE_compareUtf8Strings(r, _);
	return 0 !== a ? a : __PRIVATE_primitiveComparator(i, o);
}
function __PRIVATE_compareBsonObjectIds(e, t) {
	return __PRIVATE_compareUtf8Strings(e.mapValue.fields?.[_t]?.stringValue ?? "", t.mapValue.fields?.[_t]?.stringValue ?? "");
}
/**
* Generates the canonical ID for the provided field value (as used in Target
* serialization).
*/ function canonicalId(e) {
	return __PRIVATE_canonifyValue(e);
}
function __PRIVATE_canonifyValue(e) {
	return "nullValue" in e ? "null" : "booleanValue" in e ? "" + e.booleanValue : "integerValue" in e ? "" + e.integerValue : "doubleValue" in e ? "" + e.doubleValue : "timestampValue" in e ? function __PRIVATE_canonifyTimestamp(e) {
		const t = __PRIVATE_normalizeTimestamp(e);
		return `time(${t.seconds},${t.nanos})`;
	}(e.timestampValue) : "stringValue" in e ? e.stringValue : "bytesValue" in e ? function __PRIVATE_canonifyByteString(e) {
		return __PRIVATE_normalizeByteString(e).toBase64();
	}(e.bytesValue) : "referenceValue" in e ? function __PRIVATE_canonifyReference(e) {
		return DocumentKey.fromName(e).toString();
	}(e.referenceValue) : "geoPointValue" in e ? function __PRIVATE_canonifyGeoPoint(e) {
		return `geo(${e.latitude},${e.longitude})`;
	}(e.geoPointValue) : "arrayValue" in e ? function __PRIVATE_canonifyArray(e) {
		let t = "[", n = true;
		for (const r of e.values || []) n ? n = false : t += ",", t += __PRIVATE_canonifyValue(r);
		return t + "]";
	}(e.arrayValue) : "mapValue" in e ? function __PRIVATE_canonifyMap(e) {
		const t = Object.keys(e.fields || {}).sort();
		let n = "{", r = true;
		for (const i of t) r ? r = false : n += ",", n += `${i}:${__PRIVATE_canonifyValue(e.fields[i])}`;
		return n + "}";
	}(e.mapValue) : l(61005, { value: e });
}
function __PRIVATE_estimateByteSize(e) {
	switch (__PRIVATE_typeOrder(e)) {
		case 0:
		case 2: return 4;
		case 3: return __PRIVATE_isDecimal128Value(e) ? 16 : 8;
		case 4:
		case 11: return 16;
		case 6:
			const t = __PRIVATE_getPreviousValue(e);
			return t ? 16 + __PRIVATE_estimateByteSize(t) : 16;
		case 7: return 2 * e.stringValue.length;
		case 8: return "bytesValue" in e ? __PRIVATE_normalizeByteString(e.bytesValue).approximateByteSize() : __PRIVATE_estimateMapByteSize(e.mapValue);
		case 9: return e.referenceValue.length;
		case 13: return function __PRIVATE_estimateArrayByteSize(e) {
			return (e.values || []).reduce(((e, t) => e + __PRIVATE_estimateByteSize(t)), 0);
		}(e.arrayValue);
		case 14:
		case 15:
		case 12:
		case 10:
		case 5:
		case 1:
		case 16: return __PRIVATE_estimateMapByteSize(e.mapValue);
		default: throw l(13486, { value: e });
	}
}
function __PRIVATE_estimateMapByteSize(e) {
	let t = 0;
	return forEach(e.fields, ((e, n) => {
		t += e.length + __PRIVATE_estimateByteSize(n);
	})), t;
}
function __PRIVATE_refValue(e, t) {
	return { referenceValue: `projects/${e.projectId}/databases/${e.database}/documents/${t.path.canonicalString()}` };
}
/** Returns true if `value` is an BooleanValue . */
/** Returns true if `value` is an IntegerValue . */
function __PRIVATE_isIntegerValue(e) {
	return !!e && "integerValue" in e;
}
/** Returns true if `value` is a DoubleValue. */ function __PRIVATE_isDoubleValue(e) {
	return !!e && "doubleValue" in e;
}
function __PRIVATE_isDecimal128Value(e) {
	if (!e.mapValue?.fields) return false;
	const t = e.mapValue.fields;
	return 1 === __PRIVATE_objectSize(t) && t[at] && !!t[at].stringValue;
}
function __PRIVATE_isInt32Value(e) {
	if (!e.mapValue?.fields) return false;
	const t = e.mapValue.fields;
	return 1 === __PRIVATE_objectSize(t) && void 0 !== t[ot]?.integerValue;
}
/** Returns true if `value` is either an IntegerValue or a DoubleValue. */ function R(e) {
	return __PRIVATE_isIntegerValue(e) || __PRIVATE_isDoubleValue(e) || !!e && __PRIVATE_isInt32Value(e) || !!e && __PRIVATE_isDecimal128Value(e);
}
/** Returns true if `value` is an ArrayValue. */ function isArray(e) {
	return !!e && "arrayValue" in e;
}
/** Returns true if `value` is an ArrayValue. */
/** Returns true if `value` is a NullValue. */
function __PRIVATE_isNullValue(e) {
	return !!e && "nullValue" in e;
}
/** Returns true if `value` is NaN. */ function __PRIVATE_isNanValue(e) {
	return !(!__PRIVATE_isDoubleValue(e) || !isNaN(Number(e.doubleValue))) || !(!__PRIVATE_isDecimal128Value(e) || "NaN" !== __PRIVATE_getDecimal128StringValue(e));
}
/** Returns true if `value` is Timestamp. */
/** Returns true if `value` is a MapValue. */
function __PRIVATE_isMapValue(e) {
	return !!e && "mapValue" in e;
}
function __PRIVATE_detectMapRepresentation(e) {
	if (!e.mapValue?.fields) return dt.ge;
	const t = e.mapValue.fields, n = t[Ye]?.stringValue;
	if (n && pt[n]) return pt[n];
	if (1 === __PRIVATE_objectSize(t)) return gt[Object.keys(t)[0]] ?? dt.ge;
	return dt.ge;
}
/** Returns true if `value` is a VetorValue. */ function __PRIVATE_isVectorValue(e) {
	return (e?.mapValue?.fields || {})[Ye]?.stringValue === Ze;
}
/** Returns true if `value` is a VetorValue. */ function __PRIVATE_getVectorValue(e) {
	return (e?.mapValue?.fields || {})[Xe]?.arrayValue;
}
/** Creates a deep copy of `source`. */ function __PRIVATE_deepClone(e) {
	if (e.geoPointValue) return { geoPointValue: { ...e.geoPointValue } };
	if (e.timestampValue && "object" == typeof e.timestampValue) return { timestampValue: { ...e.timestampValue } };
	if (e.mapValue) {
		const t = { mapValue: { fields: {} } };
		return forEach(e.mapValue.fields, ((e, n) => t.mapValue.fields[e] = __PRIVATE_deepClone(n))), t;
	}
	if (e.arrayValue) {
		const t = { arrayValue: { values: [] } };
		for (let n = 0; n < (e.arrayValue.values || []).length; ++n) t.arrayValue.values[n] = __PRIVATE_deepClone(e.arrayValue.values[n]);
		return t;
	}
	return { ...e };
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* An ObjectValue represents a MapValue in the Firestore Proto and offers the
* ability to add and remove fields (via the ObjectValueBuilder).
*/ var ObjectValue = class ObjectValue {
	constructor(e) {
		this.value = e;
	}
	static empty() {
		return new ObjectValue({ mapValue: {} });
	}
	/**
	* Returns the value at the given path or null.
	*
	* @param path - the path to search
	* @returns The value at the path or null if the path is not set.
	*/ field(e) {
		if (e.isEmpty()) return this.value;
		{
			let t = this.value;
			for (let n = 0; n < e.length - 1; ++n) if (t = (t.mapValue.fields || {})[e.get(n)], !__PRIVATE_isMapValue(t)) return null;
			return t = (t.mapValue.fields || {})[e.lastSegment()], t || null;
		}
	}
	/**
	* Sets the field to the provided value.
	*
	* @param path - The field path to set.
	* @param value - The value to set.
	*/ set(e, t) {
		this.getFieldsMap(e.popLast())[e.lastSegment()] = __PRIVATE_deepClone(t);
	}
	/**
	* Sets the provided fields to the provided values.
	*
	* @param data - A map of fields to values (or null for deletes).
	*/ setAll(e) {
		let t = Me$1.emptyPath(), n = {}, r = [];
		e.forEach(((e, i) => {
			if (!t.isImmediateParentOf(i)) {
				const e = this.getFieldsMap(t);
				this.applyChanges(e, n, r), n = {}, r = [], t = i.popLast();
			}
			e ? n[i.lastSegment()] = __PRIVATE_deepClone(e) : r.push(i.lastSegment());
		}));
		const i = this.getFieldsMap(t);
		this.applyChanges(i, n, r);
	}
	/**
	* Removes the field at the specified path. If there is no field at the
	* specified path, nothing is changed.
	*
	* @param path - The field path to remove.
	*/ delete(e) {
		const t = this.field(e.popLast());
		__PRIVATE_isMapValue(t) && t.mapValue.fields && delete t.mapValue.fields[e.lastSegment()];
	}
	isEqual(e) {
		return __PRIVATE_valueEquals$1(this.value, e.value);
	}
	/**
	* Returns the map that contains the leaf element of `path`. If the parent
	* entry does not yet exist, or if it is not a map, a new map will be created.
	*/ getFieldsMap(e) {
		let t = this.value;
		t.mapValue.fields || (t.mapValue = { fields: {} });
		for (let n = 0; n < e.length; ++n) {
			let r = t.mapValue.fields[e.get(n)];
			__PRIVATE_isMapValue(r) && r.mapValue.fields || (r = { mapValue: { fields: {} } }, t.mapValue.fields[e.get(n)] = r), t = r;
		}
		return t.mapValue.fields;
	}
	/**
	* Modifies `fieldsMap` by adding, replacing or deleting the specified
	* entries.
	*/ applyChanges(e, t, n) {
		forEach(t, ((t, n) => e[t] = n));
		for (const t of n) delete e[t];
	}
	clone() {
		return new ObjectValue(__PRIVATE_deepClone(this.value));
	}
};
/**
* Returns a FieldMask built from all fields in a MapValue.
*/ function __PRIVATE_extractFieldMask(e) {
	const t = [];
	return forEach(e.fields, ((e, n) => {
		const r = new Me$1([e]);
		if (__PRIVATE_isMapValue(n) && !function __PRIVATE_isBsonType(e) {
			return yt.has(__PRIVATE_detectMapRepresentation(e));
		}(n)) {
			const e = __PRIVATE_extractFieldMask(n.mapValue).fields;
			if (0 === e.length) t.push(r);
			else for (const n of e) t.push(r.child(n));
		} else t.push(r);
	})), new FieldMask(t);
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Returns an DoubleValue for `value` that is encoded based the serializer's
* `useProto3Json` setting.
*/ function __PRIVATE_toDouble(e, t) {
	if (e.useProto3Json) {
		if (isNaN(t)) return { doubleValue: "NaN" };
		if (t === 1 / 0) return { doubleValue: "Infinity" };
		if (t === -1 / 0) return { doubleValue: "-Infinity" };
	}
	return { doubleValue: __PRIVATE_isNegativeZero(t) ? "-0" : t };
}
/**
* Returns an IntegerValue for `value`.
*/ function __PRIVATE_toInteger(e) {
	return { integerValue: "" + e };
}
/**
* Returns a value for a number that's appropriate to put into a proto.
* The return value is an IntegerValue if it can safely represent the value,
* otherwise a DoubleValue is returned.
*/ function toNumber(e, t, n) {
	return isSafeInteger(t) ? __PRIVATE_toInteger(t) : __PRIVATE_toDouble(e, t);
}
/**
* @license
* Copyright 2018 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/** Used to represent a field transform on a mutation. */ var TransformOperation = class {
	constructor() {
		this._ = void 0;
	}
};
/**
* Computes the local transform result against the provided `previousValue`,
* optionally using the provided localWriteTime.
*/ function __PRIVATE_applyTransformOperationToLocalView(e, t, n) {
	return e instanceof __PRIVATE_ServerTimestampTransform ? function serverTimestamp$1(e, t) {
		const n = { fields: {
			[ke]: { stringValue: Ue },
			[qe]: { timestampValue: {
				seconds: e.seconds,
				nanos: e.nanoseconds
			} }
		} };
		return t && __PRIVATE_isServerTimestamp(t) && (t = __PRIVATE_getPreviousValue(t)), t && (n.fields[Qe] = t), { mapValue: n };
	}(n, t) : e instanceof __PRIVATE_ArrayUnionTransformOperation ? __PRIVATE_applyArrayUnionTransformOperation(e, t) : e instanceof __PRIVATE_ArrayRemoveTransformOperation ? __PRIVATE_applyArrayRemoveTransformOperation(e, t) : e instanceof __PRIVATE_NumericIncrementTransformOperation ? function __PRIVATE_applyNumericIncrementTransformOperationToLocalView(e, t) {
		const n = __PRIVATE_computeTransformOperationBaseValue(e, t), r = asNumber(n) + asNumber(e.xe);
		if (__PRIVATE_isDecimal128Value(n) || __PRIVATE_isDecimal128Value(e.xe)) return { mapValue: { fields: { [at]: { stringValue: r.toString() } } } };
		if (__PRIVATE_isInt32Value(n)) return __PRIVATE_isDoubleValue(e.xe) ? { doubleValue: r } : __PRIVATE_isIntegerValue(e.xe) ? { integerValue: r.toString() } : { mapValue: { fields: { [ot]: __PRIVATE_toInteger(r) } } };
		return __PRIVATE_isIntegerValue(n) && (__PRIVATE_isIntegerValue(e.xe) || __PRIVATE_isInt32Value(e.xe)) ? __PRIVATE_toInteger(r) : __PRIVATE_toDouble(e.serializer, r);
	}(e, t) : e instanceof __PRIVATE_NumericMinimumTransformOperation ? function __PRIVATE_applyNumericMinimumTransformOperationToLocalView(e, t) {
		if (!R(t)) return e.xe;
		if (__PRIVATE_isNanValue(e.xe)) return e.xe;
		if (__PRIVATE_isNanValue(t)) return t;
		return __PRIVATE_compareNumbers(e.xe, t) < 0 ? e.xe : t;
	}(e, t) : e instanceof __PRIVATE_NumericMaximumTransformOperation ? function __PRIVATE_applyNumericMaximumTransformOperationToLocalView(e, t) {
		if (!R(t)) return e.xe;
		if (__PRIVATE_isNanValue(e.xe)) return e.xe;
		if (__PRIVATE_isNanValue(t)) return t;
		return __PRIVATE_compareNumbers(e.xe, t) > 0 ? e.xe : t;
	}(e, t) : void 0;
}
/**
* Computes a final transform result after the transform has been acknowledged
* by the server, potentially using the server-provided transformResult.
*/ function __PRIVATE_applyTransformOperationToRemoteDocument(e, t, n) {
	return e instanceof __PRIVATE_ArrayUnionTransformOperation ? __PRIVATE_applyArrayUnionTransformOperation(e, t) : e instanceof __PRIVATE_ArrayRemoveTransformOperation ? __PRIVATE_applyArrayRemoveTransformOperation(e, t) : n;
}
/**
* If this transform operation is not idempotent, returns the base value to
* persist for this transform. If a base value is returned, the transform
* operation is always applied to this base value, even if document has
* already been updated.
*
* Base values provide consistent behavior for non-idempotent transforms and
* allow us to return the same latency-compensated value even if the backend
* has already applied the transform operation. The base value is null for
* idempotent transforms, as they can be re-played even if the backend has
* already applied them.
*
* @returns a base value to store along with the mutation, or null for
* idempotent transforms.
*/ function __PRIVATE_computeTransformOperationBaseValue(e, t) {
	return e instanceof __PRIVATE_NumericIncrementTransformOperation ? R(t) ? t : { integerValue: 0 } : null;
}
/** Transforms a value into a server-generated timestamp. */
var __PRIVATE_ServerTimestampTransform = class extends TransformOperation {};
/** Transforms an array value via a union operation. */ var __PRIVATE_ArrayUnionTransformOperation = class extends TransformOperation {
	constructor(e) {
		super(), this.elements = e;
	}
};
function __PRIVATE_applyArrayUnionTransformOperation(e, t) {
	const n = __PRIVATE_coercedFieldValuesArray(t);
	for (const t of e.elements) n.some(((e) => __PRIVATE_valueEquals$1(e, t))) || n.push(t);
	return { arrayValue: { values: n } };
}
/** Transforms an array value via a remove operation. */ var __PRIVATE_ArrayRemoveTransformOperation = class extends TransformOperation {
	constructor(e) {
		super(), this.elements = e;
	}
};
function __PRIVATE_applyArrayRemoveTransformOperation(e, t) {
	let n = __PRIVATE_coercedFieldValuesArray(t);
	for (const t of e.elements) n = n.filter(((e) => !__PRIVATE_valueEquals$1(e, t)));
	return { arrayValue: { values: n } };
}
/**
* Implements the backend semantics for locally computed NUMERIC_ADD (increment)
* transforms. Converts all field values to integers or doubles, but unlike the
* backend does not cap integer values at 2^63. Instead, JavaScript number
* arithmetic is used and precision loss can occur for values greater than 2^53.
*/ var __PRIVATE_NumericTransformOperation = class extends TransformOperation {
	constructor(e, t) {
		super(), this.serializer = e, this.xe = t;
	}
};
var __PRIVATE_NumericIncrementTransformOperation = class extends __PRIVATE_NumericTransformOperation {};
var __PRIVATE_NumericMinimumTransformOperation = class extends __PRIVATE_NumericTransformOperation {};
var __PRIVATE_NumericMaximumTransformOperation = class extends __PRIVATE_NumericTransformOperation {};
function asNumber(e) {
	return __PRIVATE_isIntegerValue(e) ? __PRIVATE_normalizeNumber(e.integerValue) : __PRIVATE_isDoubleValue(e) ? __PRIVATE_normalizeNumber(e.doubleValue) : __PRIVATE_isInt32Value(e) ? __PRIVATE_normalizeNumber(e.mapValue.fields[ot].integerValue) : __PRIVATE_isDecimal128Value(e) ? parseFloat(e.mapValue.fields[at].stringValue) : 0;
}
function __PRIVATE_coercedFieldValuesArray(e) {
	return isArray(e) && e.arrayValue.values ? e.arrayValue.values.slice() : [];
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function __PRIVATE_fieldTransformEquals(e, t) {
	return e.field.isEqual(t.field) && function __PRIVATE_transformOperationEquals(e, t) {
		return e instanceof __PRIVATE_ArrayUnionTransformOperation && t instanceof __PRIVATE_ArrayUnionTransformOperation || e instanceof __PRIVATE_ArrayRemoveTransformOperation && t instanceof __PRIVATE_ArrayRemoveTransformOperation ? __PRIVATE_arrayEquals(e.elements, t.elements, __PRIVATE_valueEquals$1) : e instanceof __PRIVATE_NumericIncrementTransformOperation && t instanceof __PRIVATE_NumericIncrementTransformOperation || e instanceof __PRIVATE_NumericMinimumTransformOperation && t instanceof __PRIVATE_NumericMinimumTransformOperation || e instanceof __PRIVATE_NumericMaximumTransformOperation && t instanceof __PRIVATE_NumericMaximumTransformOperation ? __PRIVATE_valueEquals$1(e.xe, t.xe) : e instanceof __PRIVATE_ServerTimestampTransform && t instanceof __PRIVATE_ServerTimestampTransform;
	}(e.transform, t.transform);
}
/** The result of successfully applying a mutation to the backend. */
var MutationResult = class {
	constructor(e, t) {
		this.version = e, this.transformResults = t;
	}
};
/**
* Encodes a precondition for a mutation. This follows the model that the
* backend accepts with the special case of an explicit "empty" precondition
* (meaning no precondition).
*/ var Precondition = class Precondition {
	constructor(e, t) {
		this.updateTime = e, this.exists = t;
	}
	/** Creates a new empty Precondition. */ static none() {
		return new Precondition();
	}
	/** Creates a new Precondition with an exists flag. */ static exists(e) {
		return new Precondition(void 0, e);
	}
	/** Creates a new Precondition based on a version a document exists at. */ static updateTime(e) {
		return new Precondition(e);
	}
	/** Returns whether this Precondition is empty. */ get isNone() {
		return void 0 === this.updateTime && void 0 === this.exists;
	}
	isEqual(e) {
		return this.exists === e.exists && (this.updateTime ? !!e.updateTime && this.updateTime.isEqual(e.updateTime) : !e.updateTime);
	}
};
/** Returns true if the preconditions is valid for the given document. */ function __PRIVATE_preconditionIsValidForDocument(e, t) {
	return void 0 !== e.updateTime ? t.isFoundDocument() && t.version.isEqual(e.updateTime) : void 0 === e.exists || e.exists === t.isFoundDocument();
}
/**
* A mutation describes a self-contained change to a document. Mutations can
* create, replace, delete, and update subsets of documents.
*
* Mutations not only act on the value of the document but also its version.
*
* For local mutations (mutations that haven't been committed yet), we preserve
* the existing version for Set and Patch mutations. For Delete mutations, we
* reset the version to 0.
*
* Here's the expected transition table.
*
* MUTATION           APPLIED TO            RESULTS IN
*
* SetMutation        Document(v3)          Document(v3)
* SetMutation        NoDocument(v3)        Document(v0)
* SetMutation        InvalidDocument(v0)   Document(v0)
* PatchMutation      Document(v3)          Document(v3)
* PatchMutation      NoDocument(v3)        NoDocument(v3)
* PatchMutation      InvalidDocument(v0)   UnknownDocument(v3)
* DeleteMutation     Document(v3)          NoDocument(v0)
* DeleteMutation     NoDocument(v3)        NoDocument(v0)
* DeleteMutation     InvalidDocument(v0)   NoDocument(v0)
*
* For acknowledged mutations, we use the updateTime of the WriteResponse as
* the resulting version for Set and Patch mutations. As deletes have no
* explicit update time, we use the commitTime of the WriteResponse for
* Delete mutations.
*
* If a mutation is acknowledged by the backend but fails the precondition check
* locally, we transition to an `UnknownDocument` and rely on Watch to send us
* the updated version.
*
* Field transforms are used only with Patch and Set Mutations. We use the
* `updateTransforms` message to store transforms, rather than the `transforms`s
* messages.
*
* ## Subclassing Notes
*
* Every type of mutation needs to implement its own applyToRemoteDocument() and
* applyToLocalView() to implement the actual behavior of applying the mutation
* to some source document (see `setMutationApplyToRemoteDocument()` for an
* example).
*/ var Mutation = class {};
/**
* A utility method to calculate a `Mutation` representing the overlay from the
* final state of the document, and a `FieldMask` representing the fields that
* are mutated by the local mutations.
*/ function __PRIVATE_calculateOverlayMutation(e, t) {
	if (!e.hasLocalMutations || t && 0 === t.fields.length) return null;
	if (null === t) return e.isNoDocument() ? new __PRIVATE_DeleteMutation(e.key, Precondition.none()) : new __PRIVATE_SetMutation(e.key, e.data, Precondition.none());
	{
		const n = e.data, r = ObjectValue.empty();
		let i = new SortedSet(Me$1.comparator);
		for (let e of t.fields) if (!i.has(e)) {
			let t = n.field(e);
			null === t && e.length > 1 && (e = e.popLast(), t = n.field(e)), null === t ? r.delete(e) : r.set(e, t), i = i.add(e);
		}
		return new __PRIVATE_PatchMutation(e.key, r, new FieldMask(i.toArray()), Precondition.none());
	}
}
/**
* Applies this mutation to the given document for the purposes of computing a
* new remote document. If the input document doesn't match the expected state
* (e.g. it is invalid or outdated), the document type may transition to
* unknown.
*
* @param mutation - The mutation to apply.
* @param document - The document to mutate. The input document can be an
*     invalid document if the client has no knowledge of the pre-mutation state
*     of the document.
* @param mutationResult - The result of applying the mutation from the backend.
*/ function __PRIVATE_mutationApplyToRemoteDocument(e, t, n) {
	e instanceof __PRIVATE_SetMutation ? function __PRIVATE_setMutationApplyToRemoteDocument(e, t, n) {
		const r = e.value.clone(), i = __PRIVATE_serverTransformResults(e.fieldTransforms, t, n.transformResults);
		r.setAll(i), t.convertToFoundDocument(n.version, r).setHasCommittedMutations();
	}(e, t, n) : e instanceof __PRIVATE_PatchMutation ? function __PRIVATE_patchMutationApplyToRemoteDocument(e, t, n) {
		if (!__PRIVATE_preconditionIsValidForDocument(e.precondition, t)) return void t.convertToUnknownDocument(n.version);
		const r = __PRIVATE_serverTransformResults(e.fieldTransforms, t, n.transformResults), i = t.data;
		i.setAll(__PRIVATE_getPatch(e)), i.setAll(r), t.convertToFoundDocument(n.version, i).setHasCommittedMutations();
	}(e, t, n) : function __PRIVATE_deleteMutationApplyToRemoteDocument(e, t, n) {
		t.convertToNoDocument(n.version).setHasCommittedMutations();
	}(0, t, n);
}
/**
* Applies this mutation to the given document for the purposes of computing
* the new local view of a document. If the input document doesn't match the
* expected state, the document is not modified.
*
* @param mutation - The mutation to apply.
* @param document - The document to mutate. The input document can be an
*     invalid document if the client has no knowledge of the pre-mutation state
*     of the document.
* @param previousMask - The fields that have been updated before applying this mutation.
* @param localWriteTime - A timestamp indicating the local write time of the
*     batch this mutation is a part of.
* @returns A `FieldMask` representing the fields that are changed by applying this mutation.
*/ function __PRIVATE_mutationApplyToLocalView(e, t, n, r) {
	return e instanceof __PRIVATE_SetMutation ? function __PRIVATE_setMutationApplyToLocalView(e, t, n, r) {
		if (!__PRIVATE_preconditionIsValidForDocument(e.precondition, t)) return n;
		const i = e.value.clone(), s = __PRIVATE_localTransformResults(e.fieldTransforms, r, t);
		return i.setAll(s), t.convertToFoundDocument(t.version, i).setHasLocalMutations(), null;
	}(e, t, n, r) : e instanceof __PRIVATE_PatchMutation ? function __PRIVATE_patchMutationApplyToLocalView(e, t, n, r) {
		if (!__PRIVATE_preconditionIsValidForDocument(e.precondition, t)) return n;
		const i = __PRIVATE_localTransformResults(e.fieldTransforms, r, t), s = t.data;
		if (s.setAll(__PRIVATE_getPatch(e)), s.setAll(i), t.convertToFoundDocument(t.version, s).setHasLocalMutations(), null === n) return null;
		return n.unionWith(e.fieldMask.fields).unionWith(e.fieldTransforms.map(((e) => e.field)));
	}(e, t, n, r) : function __PRIVATE_deleteMutationApplyToLocalView(e, t, n) {
		if (__PRIVATE_preconditionIsValidForDocument(e.precondition, t)) return t.convertToNoDocument(t.version).setHasLocalMutations(), null;
		return n;
	}(e, t, n);
}
/**
* If this mutation is not idempotent, returns the base value to persist with
* this mutation. If a base value is returned, the mutation is always applied
* to this base value, even if document has already been updated.
*
* The base value is a sparse object that consists of only the document
* fields for which this mutation contains a non-idempotent transformation
* (e.g. a numeric increment). The provided value guarantees consistent
* behavior for non-idempotent transforms and allow us to return the same
* latency-compensated value even if the backend has already applied the
* mutation. The base value is null for idempotent mutations, as they can be
* re-played even if the backend has already applied them.
*
* @returns a base value to store along with the mutation, or null for
* idempotent mutations.
*/ function __PRIVATE_mutationExtractBaseValue(e, t) {
	let n = null;
	for (const r of e.fieldTransforms) {
		const e = t.data.field(r.field), i = __PRIVATE_computeTransformOperationBaseValue(r.transform, e || null);
		null != i && (null === n && (n = ObjectValue.empty()), n.set(r.field, i));
	}
	return n || null;
}
function __PRIVATE_mutationEquals(e, t) {
	return e.type === t.type && !!e.key.isEqual(t.key) && !!e.precondition.isEqual(t.precondition) && !!function __PRIVATE_fieldTransformsAreEqual(e, t) {
		return void 0 === e && void 0 === t || !(!e || !t) && __PRIVATE_arrayEquals(e, t, ((e, t) => __PRIVATE_fieldTransformEquals(e, t)));
	}(e.fieldTransforms, t.fieldTransforms) && (0 === e.type ? e.value.isEqual(t.value) : 1 !== e.type || e.data.isEqual(t.data) && e.fieldMask.isEqual(t.fieldMask));
}
/**
* A mutation that creates or replaces the document at the given key with the
* object value contents.
*/ var __PRIVATE_SetMutation = class extends Mutation {
	constructor(e, t, n, r = []) {
		super(), this.key = e, this.value = t, this.precondition = n, this.fieldTransforms = r, this.type = 0;
	}
	getFieldMask() {
		return null;
	}
};
var __PRIVATE_PatchMutation = class extends Mutation {
	constructor(e, t, n, r, i = []) {
		super(), this.key = e, this.data = t, this.fieldMask = n, this.precondition = r, this.fieldTransforms = i, this.type = 1;
	}
	getFieldMask() {
		return this.fieldMask;
	}
};
function __PRIVATE_getPatch(e) {
	const t = /* @__PURE__ */ new Map();
	return e.fieldMask.fields.forEach(((n) => {
		if (!n.isEmpty()) {
			const r = e.data.field(n);
			t.set(n, r);
		}
	})), t;
}
/**
* Creates a list of "transform results" (a transform result is a field value
* representing the result of applying a transform) for use after a mutation
* containing transforms has been acknowledged by the server.
*
* @param fieldTransforms - The field transforms to apply the result to.
* @param mutableDocument - The current state of the document after applying all
* previous mutations.
* @param serverTransformResults - The transform results received by the server.
* @returns The transform results list.
*/ function __PRIVATE_serverTransformResults(e, t, n) {
	const r = /* @__PURE__ */ new Map();
	__PRIVATE_hardAssert(e.length === n.length, 32656, {
		ve: n.length,
		De: e.length
	});
	for (let i = 0; i < n.length; i++) {
		const s = e[i], _ = s.transform, o = t.data.field(s.field);
		r.set(s.field, __PRIVATE_applyTransformOperationToRemoteDocument(_, o, n[i]));
	}
	return r;
}
/**
* Creates a list of "transform results" (a transform result is a field value
* representing the result of applying a transform) for use when applying a
* transform locally.
*
* @param fieldTransforms - The field transforms to apply the result to.
* @param localWriteTime - The local time of the mutation (used to
*     generate ServerTimestampValues).
* @param mutableDocument - The document to apply transforms on.
* @returns The transform results list.
*/ function __PRIVATE_localTransformResults(e, t, n) {
	const r = /* @__PURE__ */ new Map();
	for (const i of e) {
		const e = i.transform, s = n.data.field(i.field);
		r.set(i.field, __PRIVATE_applyTransformOperationToLocalView(e, s, t));
	}
	return r;
}
/** A mutation that deletes the document at the given key. */ var __PRIVATE_DeleteMutation = class extends Mutation {
	constructor(e, t) {
		super(), this.key = e, this.precondition = t, this.type = 2, this.fieldTransforms = [];
	}
	getFieldMask() {
		return null;
	}
};
var __PRIVATE_VerifyMutation = class extends Mutation {
	constructor(e, t) {
		super(), this.key = e, this.precondition = t, this.type = 3, this.fieldTransforms = [];
	}
	getFieldMask() {
		return null;
	}
};
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Represents a bound of a query.
*
* The bound is specified with the given components representing a position and
* whether it's just before or just after the position (relative to whatever the
* query order is).
*
* The position represents a logical index position for a query. It's a prefix
* of values for the (potentially implicit) order by clauses of a query.
*
* Bound provides a function to determine whether a document comes before or
* after a bound. This is influenced by whether the position is just before or
* just after the provided values.
*/ var Bound = class {
	constructor(e, t) {
		this.position = e, this.inclusive = t;
	}
};
function __PRIVATE_boundCompareToDocument(e, t, n) {
	let r = 0;
	for (let i = 0; i < e.position.length; i++) {
		const s = t[i], _ = e.position[i];
		if (s.field.isKeyField()) r = DocumentKey.comparator(DocumentKey.fromName(_.referenceValue), n.key);
		else r = __PRIVATE_valueCompare(_, n.data.field(s.field));
		if ("desc" === s.dir && (r *= -1), 0 !== r) break;
	}
	return r;
}
/**
* Returns true if a document sorts after a bound using the provided sort
* order.
*/ function __PRIVATE_boundEquals(e, t) {
	if (null === e) return null === t;
	if (null === t) return false;
	if (e.inclusive !== t.inclusive || e.position.length !== t.position.length) return false;
	for (let n = 0; n < e.position.length; n++) if (!__PRIVATE_valueEquals$1(e.position[n], t.position[n])) return false;
	return true;
}
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var Filter = class {};
var FieldFilter = class FieldFilter extends Filter {
	constructor(e, t, n) {
		super(), this.field = e, this.op = t, this.value = n;
	}
	/**
	* Creates a filter based on the provided arguments.
	*/ static create(e, t, n) {
		return e.isKeyField() ? "in" === t || "not-in" === t ? this.createKeyFieldInFilter(e, t, n) : new __PRIVATE_KeyFieldFilter(e, t, n) : "array-contains" === t ? new __PRIVATE_ArrayContainsFilter(e, n) : "in" === t ? new __PRIVATE_InFilter(e, n) : "not-in" === t ? new __PRIVATE_NotInFilter(e, n) : "array-contains-any" === t ? new __PRIVATE_ArrayContainsAnyFilter(e, n) : new FieldFilter(e, t, n);
	}
	static createKeyFieldInFilter(e, t, n) {
		return "in" === t ? new __PRIVATE_KeyFieldInFilter(e, n) : new __PRIVATE_KeyFieldNotInFilter(e, n);
	}
	matches(e) {
		const t = e.data.field(this.field);
		return "!=" === this.op ? null !== t && void 0 === t.nullValue && this.matchesComparison(__PRIVATE_valueCompare(t, this.value)) : null !== t && __PRIVATE_typeOrder(this.value) === __PRIVATE_typeOrder(t) && this.matchesComparison(__PRIVATE_valueCompare(t, this.value));
	}
	matchesComparison(e) {
		switch (this.op) {
			case "<": return e < 0;
			case "<=": return e <= 0;
			case "==": return 0 === e;
			case "!=": return 0 !== e;
			case ">": return e > 0;
			case ">=": return e >= 0;
			default: return l(47266, { operator: this.op });
		}
	}
	isInequality() {
		return [
			"<",
			"<=",
			">",
			">=",
			"!=",
			"not-in"
		].indexOf(this.op) >= 0;
	}
	getFlattenedFilters() {
		return [this];
	}
	getFilters() {
		return [this];
	}
};
var CompositeFilter = class CompositeFilter extends Filter {
	constructor(e, t) {
		super(), this.filters = e, this.op = t, this.Ce = null;
	}
	/**
	* Creates a filter based on the provided arguments.
	*/ static create(e, t) {
		return new CompositeFilter(e, t);
	}
	matches(e) {
		return __PRIVATE_compositeFilterIsConjunction(this) ? void 0 === this.filters.find(((t) => !t.matches(e))) : void 0 !== this.filters.find(((t) => t.matches(e)));
	}
	getFlattenedFilters() {
		return null !== this.Ce || (this.Ce = this.filters.reduce(((e, t) => e.concat(t.getFlattenedFilters())), [])), this.Ce;
	}
	getFilters() {
		return Object.assign([], this.filters);
	}
};
function __PRIVATE_compositeFilterIsConjunction(e) {
	return "and" === e.op;
}
/**
* Returns true if this filter is a conjunction of field filters only. Returns false otherwise.
*/ function __PRIVATE_compositeFilterIsFlatConjunction(e) {
	return __PRIVATE_compositeFilterIsFlat(e) && __PRIVATE_compositeFilterIsConjunction(e);
}
/**
* Returns true if this filter does not contain any composite filters. Returns false otherwise.
*/ function __PRIVATE_compositeFilterIsFlat(e) {
	for (const t of e.filters) if (t instanceof CompositeFilter) return false;
	return true;
}
function __PRIVATE_canonifyFilter(e) {
	if (e instanceof FieldFilter) return e.field.canonicalString() + e.op.toString() + canonicalId(e.value);
	if (__PRIVATE_compositeFilterIsFlatConjunction(e)) return e.filters.map(((e) => __PRIVATE_canonifyFilter(e))).join(",");
	{
		const t = e.filters.map(((e) => __PRIVATE_canonifyFilter(e))).join(",");
		return `${e.op}(${t})`;
	}
}
function __PRIVATE_filterEquals(e, t) {
	return e instanceof FieldFilter ? function __PRIVATE_fieldFilterEquals(e, t) {
		return t instanceof FieldFilter && e.op === t.op && e.field.isEqual(t.field) && __PRIVATE_valueEquals$1(e.value, t.value);
	}(e, t) : e instanceof CompositeFilter ? function __PRIVATE_compositeFilterEquals(e, t) {
		if (t instanceof CompositeFilter && e.op === t.op && e.filters.length === t.filters.length) return e.filters.reduce(((e, n, r) => e && __PRIVATE_filterEquals(n, t.filters[r])), true);
		return false;
	}(e, t) : void l(19439);
}
/** Returns a debug description for `filter`. */ function __PRIVATE_stringifyFilter(e) {
	return e instanceof FieldFilter ? function __PRIVATE_stringifyFieldFilter(e) {
		return `${e.field.canonicalString()} ${e.op} ${canonicalId(e.value)}`;
	}(e) : e instanceof CompositeFilter ? function __PRIVATE_stringifyCompositeFilter(e) {
		return e.op.toString() + " {" + e.getFilters().map(__PRIVATE_stringifyFilter).join(" ,") + "}";
	}(e) : "Filter";
}
var __PRIVATE_KeyFieldFilter = class extends FieldFilter {
	constructor(e, t, n) {
		super(e, t, n), this.key = DocumentKey.fromName(n.referenceValue);
	}
	matches(e) {
		const t = DocumentKey.comparator(e.key, this.key);
		return this.matchesComparison(t);
	}
};
/** Filter that matches on key fields within an array. */ var __PRIVATE_KeyFieldInFilter = class extends FieldFilter {
	constructor(e, t) {
		super(e, "in", t), this.keys = __PRIVATE_extractDocumentKeysFromArrayValue("in", t);
	}
	matches(e) {
		return this.keys.some(((t) => t.isEqual(e.key)));
	}
};
/** Filter that matches on key fields not present within an array. */ var __PRIVATE_KeyFieldNotInFilter = class extends FieldFilter {
	constructor(e, t) {
		super(e, "not-in", t), this.keys = __PRIVATE_extractDocumentKeysFromArrayValue("not-in", t);
	}
	matches(e) {
		return !this.keys.some(((t) => t.isEqual(e.key)));
	}
};
function __PRIVATE_extractDocumentKeysFromArrayValue(e, t) {
	return (t.arrayValue?.values || []).map(((e) => DocumentKey.fromName(e.referenceValue)));
}
/** A Filter that implements the array-contains operator. */ var __PRIVATE_ArrayContainsFilter = class extends FieldFilter {
	constructor(e, t) {
		super(e, "array-contains", t);
	}
	matches(e) {
		const t = e.data.field(this.field);
		return isArray(t) && __PRIVATE_arrayValueContains(t.arrayValue, this.value);
	}
};
/** A Filter that implements the IN operator. */ var __PRIVATE_InFilter = class extends FieldFilter {
	constructor(e, t) {
		super(e, "in", t);
	}
	matches(e) {
		const t = e.data.field(this.field);
		return null !== t && __PRIVATE_arrayValueContains(this.value.arrayValue, t);
	}
};
/** A Filter that implements the not-in operator. */ var __PRIVATE_NotInFilter = class extends FieldFilter {
	constructor(e, t) {
		super(e, "not-in", t);
	}
	matches(e) {
		if (__PRIVATE_arrayValueContains(this.value.arrayValue, { nullValue: "NULL_VALUE" })) return false;
		const t = e.data.field(this.field);
		return null !== t && void 0 === t.nullValue && !__PRIVATE_arrayValueContains(this.value.arrayValue, t);
	}
};
/** A Filter that implements the array-contains-any operator. */ var __PRIVATE_ArrayContainsAnyFilter = class extends FieldFilter {
	constructor(e, t) {
		super(e, "array-contains-any", t);
	}
	matches(e) {
		const t = e.data.field(this.field);
		return !(!isArray(t) || !t.arrayValue.values) && t.arrayValue.values.some(((e) => __PRIVATE_arrayValueContains(this.value.arrayValue, e)));
	}
};
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* An ordering on a field, in some Direction. Direction defaults to ASCENDING.
*/ var OrderBy = class {
	constructor(e, t = "asc") {
		this.field = e, this.dir = t;
	}
};
function __PRIVATE_orderByEquals(e, t) {
	return e.dir === t.dir && e.field.isEqual(t.field);
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* A version of a document in Firestore. This corresponds to the version
* timestamp, such as update_time or read_time.
*/ var SnapshotVersion = class SnapshotVersion {
	static fromTimestamp(e) {
		return new SnapshotVersion(e);
	}
	static min() {
		return new SnapshotVersion(new Timestamp(0, 0));
	}
	static max() {
		return new SnapshotVersion(new Timestamp(253402300799, 999999999));
	}
	constructor(e) {
		this.timestamp = e;
	}
	compareTo(e) {
		return this.timestamp._compareTo(e.timestamp);
	}
	isEqual(e) {
		return this.timestamp.isEqual(e.timestamp);
	}
	/** Returns a number representation of the version for use in spec tests. */ toMicroseconds() {
		return 1e6 * this.timestamp.seconds + this.timestamp.nanoseconds / 1e3;
	}
	toString() {
		return "SnapshotVersion(" + this.timestamp.toString() + ")";
	}
	toTimestamp() {
		return this.timestamp;
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Represents a document in Firestore with a key, version, data and whether it
* has local mutations applied to it.
*
* Documents can transition between states via `convertToFoundDocument()`,
* `convertToNoDocument()` and `convertToUnknownDocument()`. If a document does
* not transition to one of these states even after all mutations have been
* applied, `isValidDocument()` returns false and the document should be removed
* from all views.
*/ var MutableDocument = class MutableDocument {
	constructor(e, t, n, r, i, s, _) {
		this.key = e, this.documentType = t, this.version = n, this.readTime = r, this.createTime = i, this.data = s, this.documentState = _;
	}
	/**
	* Creates a document with no known version or data, but which can serve as
	* base document for mutations.
	*/ static newInvalidDocument(e) {
		return new MutableDocument(e, 0, SnapshotVersion.min(), SnapshotVersion.min(), SnapshotVersion.min(), ObjectValue.empty(), 0);
	}
	/**
	* Creates a new document that is known to exist with the given data at the
	* given version.
	*/ static newFoundDocument(e, t, n, r) {
		return new MutableDocument(e, 1, t, SnapshotVersion.min(), n, r, 0);
	}
	/** Creates a new document that is known to not exist at the given version. */ static newNoDocument(e, t) {
		return new MutableDocument(e, 2, t, SnapshotVersion.min(), SnapshotVersion.min(), ObjectValue.empty(), 0);
	}
	/**
	* Creates a new document that is known to exist at the given version but
	* whose data is not known (e.g. a document that was updated without a known
	* base document).
	*/ static newUnknownDocument(e, t) {
		return new MutableDocument(e, 3, t, SnapshotVersion.min(), SnapshotVersion.min(), ObjectValue.empty(), 2);
	}
	/**
	* Changes the document type to indicate that it exists and that its version
	* and data are known.
	*/ convertToFoundDocument(e, t) {
		return !this.createTime.isEqual(SnapshotVersion.min()) || 2 !== this.documentType && 0 !== this.documentType || (this.createTime = e), this.version = e, this.documentType = 1, this.data = t, this.documentState = 0, this;
	}
	/**
	* Changes the document type to indicate that it doesn't exist at the given
	* version.
	*/ convertToNoDocument(e) {
		return this.version = e, this.documentType = 2, this.data = ObjectValue.empty(), this.documentState = 0, this;
	}
	/**
	* Changes the document type to indicate that it exists at a given version but
	* that its data is not known (e.g. a document that was updated without a known
	* base document).
	*/ convertToUnknownDocument(e) {
		return this.version = e, this.documentType = 3, this.data = ObjectValue.empty(), this.documentState = 2, this;
	}
	setHasCommittedMutations() {
		return this.documentState = 2, this;
	}
	setHasLocalMutations() {
		return this.documentState = 1, this.version = SnapshotVersion.min(), this;
	}
	setReadTime(e) {
		return this.readTime = e, this;
	}
	get hasLocalMutations() {
		return 1 === this.documentState;
	}
	get hasCommittedMutations() {
		return 2 === this.documentState;
	}
	get hasPendingWrites() {
		return this.hasLocalMutations || this.hasCommittedMutations;
	}
	isValidDocument() {
		return 0 !== this.documentType;
	}
	isFoundDocument() {
		return 1 === this.documentType;
	}
	isNoDocument() {
		return 2 === this.documentType;
	}
	isUnknownDocument() {
		return 3 === this.documentType;
	}
	isEqual(e) {
		return e instanceof MutableDocument && this.key.isEqual(e.key) && this.version.isEqual(e.version) && this.documentType === e.documentType && this.documentState === e.documentState && this.data.isEqual(e.data);
	}
	mutableCopy() {
		return new MutableDocument(this.key, this.documentType, this.version, this.readTime, this.createTime, this.data.clone(), this.documentState);
	}
	toString() {
		return `Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {createTime: ${this.createTime}}), {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`;
	}
};
/**
* Compares the value for field `field` in the provided documents. Throws if
* the field does not exist in both documents.
*/
/**
* @license
* Copyright 2021 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* The initial mutation batch id for each index. Gets updated during index
* backfill.
*/
var St = -1;
/**
* The initial sequence number for each index. Gets updated during index
* backfill.
*/
/**
* An index definition for field indexes in Firestore.
*
* Every index is associated with a collection. The definition contains a list
* of fields and their index kind (which can be `ASCENDING`, `DESCENDING` or
* `CONTAINS` for ArrayContains/ArrayContainsAny queries).
*
* Unlike the backend, the SDK does not differentiate between collection or
* collection group-scoped indices. Every index can be used for both single
* collection and collection group queries.
*/
var FieldIndex = class {
	constructor(e, t, n, r) {
		this.indexId = e, this.collectionGroup = t, this.fields = n, this.indexState = r;
	}
};
/** Returns a debug representation of the field index */ FieldIndex.UNKNOWN_ID = -1;
/**
* Creates an offset that matches all documents with a read time higher than
* `readTime`.
*/ function __PRIVATE_newIndexOffsetSuccessorFromReadTime(e, t) {
	const n = e.toTimestamp().seconds, r = e.toTimestamp().nanoseconds + 1;
	return new IndexOffset(SnapshotVersion.fromTimestamp(1e9 === r ? new Timestamp(n + 1, 0) : new Timestamp(n, r)), DocumentKey.empty(), t);
}
/** Creates a new offset based on the provided document. */ function __PRIVATE_newIndexOffsetFromDocument(e) {
	return new IndexOffset(e.readTime, e.key, St);
}
/**
* Stores the latest read time, document and batch ID that were processed for an
* index.
*/ var IndexOffset = class IndexOffset {
	constructor(e, t, n) {
		this.readTime = e, this.documentKey = t, this.largestBatchId = n;
	}
	/** Returns an offset that sorts before all regular offsets. */ static min() {
		return new IndexOffset(SnapshotVersion.min(), DocumentKey.empty(), St);
	}
	/** Returns an offset that sorts after all regular offsets. */ static max() {
		return new IndexOffset(SnapshotVersion.max(), DocumentKey.empty(), St);
	}
};
function __PRIVATE_indexOffsetComparator(e, t) {
	let n = e.readTime.compareTo(t.readTime);
	return 0 !== n ? n : (n = DocumentKey.comparator(e.documentKey, t.documentKey), 0 !== n ? n : __PRIVATE_primitiveComparator(e.largestBatchId, t.largestBatchId));
}
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var __PRIVATE_TargetImpl = class {
	constructor(e, t = null, n = [], r = [], i = null, s = null, _ = null) {
		this.path = e, this.collectionGroup = t, this.orderBy = n, this.filters = r, this.limit = i, this.startAt = s, this.endAt = _, this.Fe = null;
	}
};
/**
* Initializes a Target with a path and optional additional query constraints.
* Path must currently be empty if this is a collection group query.
*
* NOTE: you should always construct `Target` from `Query.toTarget` instead of
* using this factory method, because `Query` provides an implicit `orderBy`
* property.
*/ function __PRIVATE_newTarget(e, t = null, n = [], r = [], i = null, s = null, _ = null) {
	return new __PRIVATE_TargetImpl(e, t, n, r, i, s, _);
}
function __PRIVATE_canonifyTarget(e) {
	const t = __PRIVATE_debugCast(e);
	if (null === t.Fe) {
		let e = t.path.canonicalString();
		null !== t.collectionGroup && (e += "|cg:" + t.collectionGroup), e += "|f:", e += t.filters.map(((e) => __PRIVATE_canonifyFilter(e))).join(","), e += "|ob:", e += t.orderBy.map(((e) => function __PRIVATE_canonifyOrderBy(e) {
			return e.field.canonicalString() + e.dir;
		}(e))).join(","), __PRIVATE_isNullOrUndefined(t.limit) || (e += "|l:", e += t.limit), t.startAt && (e += "|lb:", e += t.startAt.inclusive ? "b:" : "a:", e += t.startAt.position.map(((e) => canonicalId(e))).join(",")), t.endAt && (e += "|ub:", e += t.endAt.inclusive ? "a:" : "b:", e += t.endAt.position.map(((e) => canonicalId(e))).join(",")), t.Fe = e;
	}
	return t.Fe;
}
function __PRIVATE_targetEquals(e, t) {
	if (e.limit !== t.limit) return false;
	if (e.orderBy.length !== t.orderBy.length) return false;
	for (let n = 0; n < e.orderBy.length; n++) if (!__PRIVATE_orderByEquals(e.orderBy[n], t.orderBy[n])) return false;
	if (e.filters.length !== t.filters.length) return false;
	for (let n = 0; n < e.filters.length; n++) if (!__PRIVATE_filterEquals(e.filters[n], t.filters[n])) return false;
	return e.collectionGroup === t.collectionGroup && !!e.path.isEqual(t.path) && !!__PRIVATE_boundEquals(e.startAt, t.startAt) && __PRIVATE_boundEquals(e.endAt, t.endAt);
}
function __PRIVATE_targetIsPipelineTarget(e) {
	return !!e.isCorePipeline;
}
function __PRIVATE_targetIsDocumentTarget(e) {
	return !!e.path && DocumentKey.isDocumentKey(e.path) && null === e.collectionGroup && 0 === e.filters.length;
}
/** Returns the number of segments of a perfect index for this target. */
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Query encapsulates all the query attributes we support in the SDK. It can
* be run against the LocalStore, as well as be converted to a `Target` to
* query the RemoteStore results.
*
* Visible for testing.
*/
var __PRIVATE_QueryImpl = class {
	/**
	* Initializes a Query with a path and optional additional query constraints.
	* Path must currently be empty if this is a collection group query.
	*/
	constructor(e, t = null, n = [], r = [], i = null, s = "F", _ = null, o = null) {
		this.path = e, this.collectionGroup = t, this.explicitOrderBy = n, this.filters = r, this.limit = i, this.limitType = s, this.startAt = _, this.endAt = o, this.Oe = null, this.Me = null, this.Ne = null, this.startAt, this.endAt;
	}
};
/** Creates a new Query instance with the options provided. */ function __PRIVATE_newQuery(e, t, n, r, i, s, _, o) {
	return new __PRIVATE_QueryImpl(e, t, n, r, i, s, _, o);
}
/** Creates a new Query for a query that matches all documents at `path` */ function __PRIVATE_newQueryForPath(e) {
	return new __PRIVATE_QueryImpl(e);
}
/**
* Helper to convert a collection group query into a collection query at a
* specific path. This is used when executing collection group queries, since
* we have to split the query into a set of collection queries at multiple
* paths.
*/
/**
* Returns true if this query does not specify any query constraints that
* could remove results.
*/
function __PRIVATE_queryMatchesAllDocuments(e) {
	return 0 === e.filters.length && null === e.limit && null == e.startAt && null == e.endAt && (0 === e.explicitOrderBy.length || 1 === e.explicitOrderBy.length && e.explicitOrderBy[0].field.isKeyField());
}
/**
* Returns whether the query matches a single document by path (rather than a
* collection).
*/
function __PRIVATE_isDocumentQuery$1(e) {
	return DocumentKey.isDocumentKey(e.path) && null === e.collectionGroup && 0 === e.filters.length;
}
/**
* Returns whether the query matches a collection group rather than a specific
* collection.
*/ function __PRIVATE_isCollectionGroupQuery(e) {
	return null !== e.collectionGroup;
}
/**
* Returns the normalized order-by constraint that is used to execute the Query,
* which can be different from the order-by constraints the user provided (e.g.
* the SDK and backend always orders by `__name__`). The normalized order-by
* includes implicit order-bys in addition to the explicit user provided
* order-bys.
*/ function __PRIVATE_queryNormalizedOrderBy(e) {
	const t = __PRIVATE_debugCast(e);
	if (null === t.Oe) {
		t.Oe = [];
		const e = /* @__PURE__ */ new Set();
		for (const n of t.explicitOrderBy) t.Oe.push(n), e.add(n.field.canonicalString());
		const n = t.explicitOrderBy.length > 0 ? t.explicitOrderBy[t.explicitOrderBy.length - 1].dir : "asc";
		(function __PRIVATE_getInequalityFilterFields(e) {
			let t = new SortedSet(Me$1.comparator);
			return e.filters.forEach(((e) => {
				e.getFlattenedFilters().forEach(((e) => {
					e.isInequality() && (t = t.add(e.field));
				}));
			})), t;
		})(t).forEach(((r) => {
			e.has(r.canonicalString()) || r.isKeyField() || t.Oe.push(new OrderBy(r, n));
		})), e.has(Me$1.keyField().canonicalString()) || t.Oe.push(new OrderBy(Me$1.keyField(), n));
	}
	return t.Oe;
}
/**
* Converts this `Query` instance to its corresponding `Target` representation.
*/ function __PRIVATE_queryToTarget(e) {
	const t = __PRIVATE_debugCast(e);
	return t.Me || (t.Me = __PRIVATE__queryToTarget(t, __PRIVATE_queryNormalizedOrderBy(e))), t.Me;
}
function __PRIVATE__queryToTarget(e, t) {
	if ("F" === e.limitType) return __PRIVATE_newTarget(e.path, e.collectionGroup, t, e.filters, e.limit, e.startAt, e.endAt);
	{
		t = t.map(((e) => {
			const t = "desc" === e.dir ? "asc" : "desc";
			return new OrderBy(e.field, t);
		}));
		const n = e.endAt ? new Bound(e.endAt.position, e.endAt.inclusive) : null, r = e.startAt ? new Bound(e.startAt.position, e.startAt.inclusive) : null;
		return __PRIVATE_newTarget(e.path, e.collectionGroup, t, e.filters, e.limit, n, r);
	}
}
function __PRIVATE_queryWithAddedFilter(e, t) {
	const n = e.filters.concat([t]);
	return new __PRIVATE_QueryImpl(e.path, e.collectionGroup, e.explicitOrderBy.slice(), n, e.limit, e.limitType, e.startAt, e.endAt);
}
function __PRIVATE_queryWithAddedOrderBy(e, t) {
	const n = e.explicitOrderBy.concat([t]);
	return new __PRIVATE_QueryImpl(e.path, e.collectionGroup, n, e.filters.slice(), e.limit, e.limitType, e.startAt, e.endAt);
}
function __PRIVATE_queryWithLimit(e, t, n) {
	return new __PRIVATE_QueryImpl(e.path, e.collectionGroup, e.explicitOrderBy.slice(), e.filters.slice(), t, n, e.startAt, e.endAt);
}
function __PRIVATE_queryEquals(e, t) {
	return __PRIVATE_targetEquals(__PRIVATE_queryToTarget(e), __PRIVATE_queryToTarget(t)) && e.limitType === t.limitType;
}
function __PRIVATE_stringifyQuery(e) {
	return `Query(target=${function __PRIVATE_stringifyTarget(e) {
		let t = e.path.canonicalString();
		return null !== e.collectionGroup && (t += " collectionGroup=" + e.collectionGroup), e.filters.length > 0 && (t += `, filters: [${e.filters.map(((e) => __PRIVATE_stringifyFilter(e))).join(", ")}]`), __PRIVATE_isNullOrUndefined(e.limit) || (t += ", limit: " + e.limit), e.orderBy.length > 0 && (t += `, orderBy: [${e.orderBy.map(((e) => function __PRIVATE_stringifyOrderBy(e) {
			return `${e.field.canonicalString()} (${e.dir})`;
		}(e))).join(", ")}]`), e.startAt && (t += ", startAt: ", t += e.startAt.inclusive ? "b:" : "a:", t += e.startAt.position.map(((e) => canonicalId(e))).join(",")), e.endAt && (t += ", endAt: ", t += e.endAt.inclusive ? "a:" : "b:", t += e.endAt.position.map(((e) => canonicalId(e))).join(",")), `Target(${t})`;
	}(__PRIVATE_queryToTarget(e))}; limitType=${e.limitType})`;
}
/** Returns whether `doc` matches the constraints of `query`. */ function __PRIVATE_queryMatches(e, t) {
	return t.isFoundDocument() && function __PRIVATE_queryMatchesPathAndCollectionGroup(e, t) {
		const n = t.key.path;
		return null !== e.collectionGroup ? t.key.hasCollectionId(e.collectionGroup) && e.path.isPrefixOf(n) : DocumentKey.isDocumentKey(e.path) ? e.path.isEqual(n) : e.path.isImmediateParentOf(n);
	}(e, t) && function __PRIVATE_queryMatchesOrderBy(e, t) {
		for (const n of __PRIVATE_queryNormalizedOrderBy(e)) if (!n.field.isKeyField() && null === t.data.field(n.field)) return false;
		return true;
	}(e, t) && function __PRIVATE_queryMatchesFilters(e, t) {
		for (const n of e.filters) if (!n.matches(t)) return false;
		return true;
	}(e, t) && function __PRIVATE_queryMatchesBounds(e, t) {
		if (e.startAt && !function __PRIVATE_boundSortsBeforeDocument(e, t, n) {
			const r = __PRIVATE_boundCompareToDocument(e, t, n);
			return e.inclusive ? r <= 0 : r < 0;
		}(e.startAt, __PRIVATE_queryNormalizedOrderBy(e), t)) return false;
		if (e.endAt && !function __PRIVATE_boundSortsAfterDocument(e, t, n) {
			const r = __PRIVATE_boundCompareToDocument(e, t, n);
			return e.inclusive ? r >= 0 : r > 0;
		}(e.endAt, __PRIVATE_queryNormalizedOrderBy(e), t)) return false;
		return true;
	}(e, t);
}
/**
* Returns a new comparator function that can be used to compare two documents
* based on the Query's ordering constraint.
*/
function __PRIVATE_newQueryComparator(e) {
	return (t, n) => {
		let r = false;
		for (const i of __PRIVATE_queryNormalizedOrderBy(e)) {
			const e = __PRIVATE_compareDocs(i, t, n);
			if (0 !== e) return e;
			r = r || i.field.isKeyField();
		}
		return 0;
	};
}
function __PRIVATE_compareDocs(e, t, n) {
	const r = e.field.isKeyField() ? DocumentKey.comparator(t.key, n.key) : function __PRIVATE_compareDocumentsByField(e, t, n) {
		const r = t.data.field(e), i = n.data.field(e);
		return null !== r && null !== i ? __PRIVATE_valueCompare(r, i) : l(42886);
	}(e.field, t, n);
	switch (e.dir) {
		case "asc": return r;
		case "desc": return -1 * r;
		default: return l(19790, { direction: e.dir });
	}
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var ExistenceFilter = class {
	constructor(e, t) {
		this.count = e, this.unchangedNames = t;
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Error Codes describing the different ways GRPC can fail. These are copied
* directly from GRPC's sources here:
*
* https://github.com/grpc/grpc/blob/bceec94ea4fc5f0085d81235d8e1c06798dc341a/include/grpc%2B%2B/impl/codegen/status_code_enum.h
*
* Important! The names of these identifiers matter because the string forms
* are used for reverse lookups from the webchannel stream. Do NOT change the
* names of these identifiers or change this into a const enum.
*/ var xt;
var vt;
/**
* Determines whether an error code represents a permanent error when received
* in response to a non-write operation.
*
* See isPermanentWriteError for classifying write errors.
*/
function __PRIVATE_isPermanentError(e) {
	switch (e) {
		case ta.OK: return l(64938);
		case ta.CANCELLED:
		case ta.UNKNOWN:
		case ta.DEADLINE_EXCEEDED:
		case ta.RESOURCE_EXHAUSTED:
		case ta.INTERNAL:
		case ta.UNAVAILABLE:
		case ta.UNAUTHENTICATED: return false;
		case ta.INVALID_ARGUMENT:
		case ta.NOT_FOUND:
		case ta.ALREADY_EXISTS:
		case ta.PERMISSION_DENIED:
		case ta.FAILED_PRECONDITION:
		case ta.ABORTED:
		case ta.OUT_OF_RANGE:
		case ta.UNIMPLEMENTED:
		case ta.DATA_LOSS: return true;
		default: return l(15467, { code: e });
	}
}
/**
* Determines whether an error code represents a permanent error when received
* in response to a write operation.
*
* Write operations must be handled specially because as of b/119437764, ABORTED
* errors on the write stream should be retried too (even though ABORTED errors
* are not generally retryable).
*
* Note that during the initial handshake on the write stream an ABORTED error
* signals that we should discard our stream token (i.e. it is permanent). This
* means a handshake error should be classified with isPermanentError, above.
*/
/**
* Maps an error Code from GRPC status code number, like 0, 1, or 14. These
* are not the same as HTTP status codes.
*
* @returns The Code equivalent to the given GRPC status code. Fails if there
*     is no match.
*/
function __PRIVATE_mapCodeFromRpcCode(e) {
	if (void 0 === e) return __PRIVATE_logError("GRPC error has no .code"), ta.UNKNOWN;
	switch (e) {
		case xt.OK: return ta.OK;
		case xt.CANCELLED: return ta.CANCELLED;
		case xt.UNKNOWN: return ta.UNKNOWN;
		case xt.DEADLINE_EXCEEDED: return ta.DEADLINE_EXCEEDED;
		case xt.RESOURCE_EXHAUSTED: return ta.RESOURCE_EXHAUSTED;
		case xt.INTERNAL: return ta.INTERNAL;
		case xt.UNAVAILABLE: return ta.UNAVAILABLE;
		case xt.UNAUTHENTICATED: return ta.UNAUTHENTICATED;
		case xt.INVALID_ARGUMENT: return ta.INVALID_ARGUMENT;
		case xt.NOT_FOUND: return ta.NOT_FOUND;
		case xt.ALREADY_EXISTS: return ta.ALREADY_EXISTS;
		case xt.PERMISSION_DENIED: return ta.PERMISSION_DENIED;
		case xt.FAILED_PRECONDITION: return ta.FAILED_PRECONDITION;
		case xt.ABORTED: return ta.ABORTED;
		case xt.OUT_OF_RANGE: return ta.OUT_OF_RANGE;
		case xt.UNIMPLEMENTED: return ta.UNIMPLEMENTED;
		case xt.DATA_LOSS: return ta.DATA_LOSS;
		default: return l(39323, { code: e });
	}
}
/**
* Converts an HTTP response's error status to the equivalent error code.
*
* @param status - An HTTP error response status ("FAILED_PRECONDITION",
* "UNKNOWN", etc.)
* @returns The equivalent Code. Non-matching responses are mapped to
*     Code.UNKNOWN.
*/ (vt = xt || (xt = {}))[vt.OK = 0] = "OK", vt[vt.CANCELLED = 1] = "CANCELLED", vt[vt.UNKNOWN = 2] = "UNKNOWN", vt[vt.INVALID_ARGUMENT = 3] = "INVALID_ARGUMENT", vt[vt.DEADLINE_EXCEEDED = 4] = "DEADLINE_EXCEEDED", vt[vt.NOT_FOUND = 5] = "NOT_FOUND", vt[vt.ALREADY_EXISTS = 6] = "ALREADY_EXISTS", vt[vt.PERMISSION_DENIED = 7] = "PERMISSION_DENIED", vt[vt.UNAUTHENTICATED = 16] = "UNAUTHENTICATED", vt[vt.RESOURCE_EXHAUSTED = 8] = "RESOURCE_EXHAUSTED", vt[vt.FAILED_PRECONDITION = 9] = "FAILED_PRECONDITION", vt[vt.ABORTED = 10] = "ABORTED", vt[vt.OUT_OF_RANGE = 11] = "OUT_OF_RANGE", vt[vt.UNIMPLEMENTED = 12] = "UNIMPLEMENTED", vt[vt.INTERNAL = 13] = "INTERNAL", vt[vt.UNAVAILABLE = 14] = "UNAVAILABLE", vt[vt.DATA_LOSS = 15] = "DATA_LOSS";
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* A map implementation that uses objects as keys. Objects must have an
* associated equals function and must be immutable. Entries in the map are
* stored together with the key being produced from the mapKeyFn. This map
* automatically handles collisions of keys.
*/
var ObjectMap = class {
	constructor(e, t) {
		this.mapKeyFn = e, this.equalsFn = t, this.inner = {}, this.innerSize = 0;
	}
	/** Get a value for this key, or undefined if it does not exist. */ get(e) {
		const t = this.mapKeyFn(e), n = this.inner[t];
		if (void 0 !== n) {
			for (const [t, r] of n) if (this.equalsFn(t, e)) return r;
		}
	}
	has(e) {
		return void 0 !== this.get(e);
	}
	/** Put this key and value in the map. */ set(e, t) {
		const n = this.mapKeyFn(e), r = this.inner[n];
		if (void 0 === r) return this.inner[n] = [[e, t]], void this.innerSize++;
		for (let n = 0; n < r.length; n++) if (this.equalsFn(r[n][0], e)) return void (r[n] = [e, t]);
		r.push([e, t]), this.innerSize++;
	}
	/**
	* Remove this key from the map. Returns a boolean if anything was deleted.
	*/ delete(e) {
		const t = this.mapKeyFn(e), n = this.inner[t];
		if (void 0 === n) return false;
		for (let r = 0; r < n.length; r++) if (this.equalsFn(n[r][0], e)) return 1 === n.length ? delete this.inner[t] : n.splice(r, 1), this.innerSize--, true;
		return false;
	}
	forEach(e) {
		forEach(this.inner, ((t, n) => {
			for (const [t, r] of n) e(t, r);
		}));
	}
	isEmpty() {
		return isEmpty(this.inner);
	}
	size() {
		return this.innerSize;
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var Dt = new SortedMap(DocumentKey.comparator);
function __PRIVATE_mutableDocumentMap() {
	return Dt;
}
var Ct = new SortedMap(DocumentKey.comparator);
function documentMap(...e) {
	let t = Ct;
	for (const n of e) t = t.insert(n.key, n);
	return t;
}
function __PRIVATE_convertOverlayedDocumentMapToDocumentMap(e) {
	let t = Ct;
	return e.forEach(((e, n) => t = t.insert(e, n.overlayedDocument))), t;
}
function __PRIVATE_newOverlayMap() {
	return __PRIVATE_newDocumentKeyMap();
}
function __PRIVATE_newMutationMap() {
	return __PRIVATE_newDocumentKeyMap();
}
function __PRIVATE_newDocumentKeyMap() {
	return new ObjectMap(((e) => e.toString()), ((e, t) => e.isEqual(t)));
}
var Ft = new SortedMap(DocumentKey.comparator);
var Ot = new SortedSet(DocumentKey.comparator);
function __PRIVATE_documentKeySet(...e) {
	let t = Ot;
	for (const n of e) t = t.add(n);
	return t;
}
var Mt = new SortedSet(__PRIVATE_primitiveComparator);
function __PRIVATE_targetIdSet() {
	return Mt;
}
/**
* @license
* Copyright 2023 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* The global, singleton instance of TestingHooksSpi.
*
* This variable will be `null` in all cases _except_ when running from
* integration tests that have registered callbacks to be notified of events
* that happen during the test execution.
*/ var Nt = null;
/**
* @license
* Copyright 2023 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* An instance of the Platform's 'TextEncoder' implementation.
*/ function __PRIVATE_newTextEncoder() {
	return new TextEncoder();
}
/**
* An instance of the Platform's 'TextDecoder' implementation.
*/
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var Bt = new Integer([4294967295, 4294967295], 0);
function __PRIVATE_getMd5HashValue(e) {
	const t = __PRIVATE_newTextEncoder().encode(e), n = new Md5();
	return n.update(t), new Uint8Array(n.digest());
}
function __PRIVATE_get64BitUints(e) {
	const t = new DataView(e.buffer), n = t.getUint32(0, true), r = t.getUint32(4, true), i = t.getUint32(8, true), s = t.getUint32(12, true);
	return [new Integer([n, r], 0), new Integer([i, s], 0)];
}
var BloomFilter = class BloomFilter {
	constructor(e, t, n) {
		if (this.bitmap = e, this.padding = t, this.hashCount = n, t < 0 || t >= 8) throw new __PRIVATE_BloomFilterError(`Invalid padding: ${t}`);
		if (n < 0) throw new __PRIVATE_BloomFilterError(`Invalid hash count: ${n}`);
		if (e.length > 0 && 0 === this.hashCount) throw new __PRIVATE_BloomFilterError(`Invalid hash count: ${n}`);
		if (0 === e.length && 0 !== t) throw new __PRIVATE_BloomFilterError(`Invalid padding when bitmap length is 0: ${t}`);
		this.Be = 8 * e.length - t, this.Le = Integer.fromNumber(this.Be);
	}
	Ue(e, t, n) {
		let r = e.add(t.multiply(Integer.fromNumber(n)));
		return 1 === r.compare(Bt) && (r = new Integer([r.getBits(0), r.getBits(1)], 0)), r.modulo(this.Le).toNumber();
	}
	ke(e) {
		return !!(this.bitmap[Math.floor(e / 8)] & 1 << e % 8);
	}
	mightContain(e) {
		if (0 === this.Be) return false;
		const [n, r] = __PRIVATE_get64BitUints(__PRIVATE_getMd5HashValue(e));
		for (let e = 0; e < this.hashCount; e++) {
			const t = this.Ue(n, r, e);
			if (!this.ke(t)) return false;
		}
		return true;
	}
	/** Create bloom filter for testing purposes only. */ static create(e, t, n) {
		const r = e % 8 == 0 ? 0 : 8 - e % 8, i = new Uint8Array(Math.ceil(e / 8)), s = new BloomFilter(i, r, t);
		return n.forEach(((e) => s.insert(e))), s;
	}
	insert(e) {
		if (0 === this.Be) return;
		const [n, r] = __PRIVATE_get64BitUints(__PRIVATE_getMd5HashValue(e));
		for (let e = 0; e < this.hashCount; e++) {
			const t = this.Ue(n, r, e);
			this.Qe(t);
		}
	}
	Qe(e) {
		const t = Math.floor(e / 8), n = e % 8;
		this.bitmap[t] |= 1 << n;
	}
};
var __PRIVATE_BloomFilterError = class extends Error {
	constructor() {
		super(...arguments), this.name = "BloomFilterError";
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* An event from the RemoteStore. It is split into targetChanges (changes to the
* state or the set of documents in our watched targets) and documentUpdates
* (changes to the actual documents).
*/ var RemoteEvent = class RemoteEvent {
	constructor(e, t, n, r, i, s) {
		this.snapshotVersion = e, this.targetChanges = t, this.targetMismatches = n, this.documentUpdates = r, this.augmentedDocumentUpdates = i, this.resolvedLimboDocuments = s;
	}
	/**
	* HACK: Views require RemoteEvents in order to determine whether the view is
	* CURRENT, but secondary tabs don't receive remote events. So this method is
	* used to create a synthesized RemoteEvent that can be used to apply a
	* CURRENT status change to a View, for queries executed in a different tab.
	*/
	static createSynthesizedRemoteEventForCurrentChange(e, t, n) {
		const r = /* @__PURE__ */ new Map();
		return r.set(e, TargetChange.createSynthesizedTargetChangeForCurrentChange(e, t, n)), new RemoteEvent(SnapshotVersion.min(), r, new SortedMap(__PRIVATE_primitiveComparator), __PRIVATE_mutableDocumentMap(), __PRIVATE_mutableDocumentMap(), __PRIVATE_documentKeySet());
	}
};
/**
* A TargetChange specifies the set of changes for a specific target as part of
* a RemoteEvent. These changes track which documents are added, modified or
* removed, as well as the target's resume token and whether the target is
* marked CURRENT.
* The actual changes *to* documents are not part of the TargetChange since
* documents may be part of multiple targets.
*/ var TargetChange = class TargetChange {
	constructor(e, t, n, r, i) {
		this.resumeToken = e, this.current = t, this.addedDocuments = n, this.modifiedDocuments = r, this.removedDocuments = i;
	}
	/**
	* This method is used to create a synthesized TargetChanges that can be used to
	* apply a CURRENT status change to a View (for queries executed in a different
	* tab) or for new queries (to raise snapshots with correct CURRENT status).
	*/ static createSynthesizedTargetChangeForCurrentChange(e, t, n) {
		return new TargetChange(n, t, __PRIVATE_documentKeySet(), __PRIVATE_documentKeySet(), __PRIVATE_documentKeySet());
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Represents a changed document and a list of target ids to which this change
* applies.
*
* If document has been deleted NoDocument will be provided.
*/ var __PRIVATE_DocumentWatchChange = class {
	constructor(e, t, n, r) {
		this.qe = e, this.removedTargetIds = t, this.key = n, this.Ke = r;
	}
};
var __PRIVATE_ExistenceFilterChange = class {
	constructor(e, t) {
		this.targetId = e, this.$e = t;
	}
};
var __PRIVATE_WatchTargetChange = class {
	constructor(e, t, n = ByteString.EMPTY_BYTE_STRING, r = null) {
		this.state = e, this.targetIds = t, this.resumeToken = n, this.cause = r;
	}
};
/** Tracks the internal state of a Watch target. */ var __PRIVATE_TargetState = class {
	/**
	* Track the targetId for logging.
	*/
	constructor(e) {
		this.targetId = e, this.We = 0, this.Ge = __PRIVATE_snapshotChangesMap(), this.je = ByteString.EMPTY_BYTE_STRING, this.ze = false, this.He = true;
	}
	/**
	* Whether this target has been marked 'current'.
	*
	* 'Current' has special meaning in the RPC protocol: It implies that the
	* Watch backend has sent us all changes up to the point at which the target
	* was added and that the target is consistent with the rest of the watch
	* stream.
	*/ get current() {
		return this.ze;
	}
	/** The last resume token sent to us for this target. */ get resumeToken() {
		return this.je;
	}
	/** Whether this target has pending target adds or target removes. */ get Je() {
		return 0 !== this.We;
	}
	/** Whether we have modified any state that should trigger a snapshot. */ get Ye() {
		return this.He;
	}
	/**
	* Applies the resume token to the TargetChange, but only when it has a new
	* value. Empty resumeTokens are discarded.
	*/ Ze(e) {
		e.approximateByteSize() > 0 && (this.He = true, this.je = e);
	}
	/**
	* Creates a target change from the current set of changes.
	*
	* To reset the document changes after raising this snapshot, call
	* `clearPendingChanges()`.
	*/ Xe() {
		let e = __PRIVATE_documentKeySet(), t = __PRIVATE_documentKeySet(), n = __PRIVATE_documentKeySet();
		return this.Ge.forEach(((r, i) => {
			switch (i) {
				case 0:
					e = e.add(r);
					break;
				case 2:
					t = t.add(r);
					break;
				case 1:
					n = n.add(r);
					break;
				default: l(38017, { changeType: i });
			}
		})), new TargetChange(this.je, this.ze, e, t, n);
	}
	/**
	* Resets the document changes and sets `hasPendingChanges` to false.
	*/ et() {
		this.He = false, this.Ge = __PRIVATE_snapshotChangesMap();
	}
	tt(e, t) {
		this.He = true, this.Ge = this.Ge.insert(e, t);
	}
	nt(e) {
		this.He = true, this.Ge = this.Ge.remove(e);
	}
	rt() {
		this.We += 1;
	}
	it() {
		this.We -= 1, __PRIVATE_hardAssert(this.We >= 0, 3241, {
			We: this.We,
			targetId: this.targetId
		});
	}
	st() {
		this.He = true, this.ze = true;
	}
};
var Lt = "WatchChangeAggregator";
/**
* A helper class to accumulate watch changes into a RemoteEvent.
*/ var __PRIVATE_WatchChangeAggregator = class {
	constructor(e) {
		this._t = e, this.ot = /* @__PURE__ */ new Map(), this.ut = __PRIVATE_mutableDocumentMap(), this.ct = __PRIVATE_documentTargetMap(), this.lt = __PRIVATE_mutableDocumentMap(), this.Et = __PRIVATE_documentTargetMap(), this.ht = new SortedMap(__PRIVATE_primitiveComparator);
	}
	/**
	* Processes and adds the DocumentWatchChange to the current set of changes.
	*/ Tt(e) {
		for (const t of e.qe) e.Ke && e.Ke.isFoundDocument() ? this.Pt(t, e.Ke) : this.It(t, e.key, e.Ke);
		for (const t of e.removedTargetIds) this.It(t, e.key, e.Ke);
	}
	/** Processes and adds the WatchTargetChange to the current set of changes. */ Rt(e) {
		this.forEachTarget(e, ((t) => {
			const n = this.ot.get(t);
			if (n) switch (e.state) {
				case 0:
					this.At(t) && n.Ze(e.resumeToken);
					break;
				case 1:
					n.it(), n.Je || n.et(), n.Ze(e.resumeToken);
					break;
				case 2:
					n.it(), n.Je || this.removeTarget(t);
					break;
				case 3:
					this.At(t) && (n.st(), n.Ze(e.resumeToken));
					break;
				case 4:
					this.At(t) && (this.Vt(t), n.Ze(e.resumeToken));
					break;
				default: l(56790, { state: e.state });
			}
			else __PRIVATE_logDebug(Lt, `handleTargetChange received targetChange for untracked target ID (${t}) with state (${e.state})`);
		}));
	}
	/**
	* Iterates over all targetIds that the watch change applies to: either the
	* targetIds explicitly listed in the change or the targetIds of all currently
	* active targets.
	*/ forEachTarget(e, t) {
		e.targetIds.length > 0 ? e.targetIds.forEach(t) : this.ot.forEach(((e, n) => {
			this.At(n) && t(n);
		}));
	}
	ft(e) {
		return __PRIVATE_targetIsPipelineTarget(e) ? "documents" === e.getPipelineSourceType() && 1 === e.getPipelineDocuments()?.length : __PRIVATE_targetIsDocumentTarget(e);
	}
	/**
	* Handles existence filters and synthesizes deletes for filter mismatches.
	* Targets that are invalidated by filter mismatches are added to
	* `pendingTargetResets`.
	*/ dt(e) {
		const t = e.targetId, n = e.$e.count, r = this.gt(t);
		if (r) {
			const i = r.target;
			if (this.ft(i)) if (0 === n) {
				const e = new DocumentKey(__PRIVATE_targetIsPipelineTarget(i) ? ResourcePath.fromString(i.getPipelineDocuments()[0]) : i.path);
				this.It(t, e, MutableDocument.newNoDocument(e, SnapshotVersion.min()));
			} else __PRIVATE_hardAssert(1 === n, 20013, "Single document existence filter with count: " + n);
			else {
				const r = this.yt(t);
				if (r !== n) {
					const n = this.wt(e), i = n ? this.bt(n, e, r) : 1;
					if (0 !== i) {
						this.Vt(t);
						const e = 2 === i ? "TargetPurposeExistenceFilterMismatchBloom" : "TargetPurposeExistenceFilterMismatch";
						this.ht = this.ht.insert(t, e);
					}
					Nt?.St(function __PRIVATE_createExistenceFilterMismatchInfoForTestingHooks(e, t, n, r, i) {
						const s = {
							localCacheCount: e,
							existenceFilterCount: t.count,
							databaseId: n.database,
							projectId: n.projectId
						}, _ = t.unchangedNames;
						_ && (s.bloomFilter = {
							applied: 0 === i,
							hashCount: _?.hashCount ?? 0,
							bitmapLength: _?.bits?.bitmap?.length ?? 0,
							padding: _?.bits?.padding ?? 0,
							mightContain: (e) => r?.mightContain(e) ?? false
						});
						return s;
					}(r, e.$e, this._t.xt(), n, i));
					/**
					* @license
					* Copyright 2017 Google LLC
					*
					* Licensed under the Apache License, Version 2.0 (the "License");
					* you may not use this file except in compliance with the License.
					* You may obtain a copy of the License at
					*
					*   http://www.apache.org/licenses/LICENSE-2.0
					*
					* Unless required by applicable law or agreed to in writing, software
					* distributed under the License is distributed on an "AS IS" BASIS,
					* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
					* See the License for the specific language governing permissions and
					* limitations under the License.
					*/
				}
			}
		}
	}
	/**
	* Parse the bloom filter from the "unchanged_names" field of an existence
	* filter.
	*/ wt(e) {
		const t = e.$e.unchangedNames;
		if (!t || !t.bits) return null;
		const { bits: { bitmap: n = "", padding: r = 0 }, hashCount: i = 0 } = t;
		let s, _;
		try {
			s = __PRIVATE_normalizeByteString(n).toUint8Array();
		} catch (e) {
			if (e instanceof __PRIVATE_Base64DecodeError) return __PRIVATE_logWarn("Decoding the base64 bloom filter in existence filter failed (" + e.message + "); ignoring the bloom filter and falling back to full re-query."), null;
			throw e;
		}
		try {
			_ = new BloomFilter(s, r, i);
		} catch (e) {
			return __PRIVATE_logWarn(e instanceof __PRIVATE_BloomFilterError ? "BloomFilter error: " : "Applying bloom filter failed: ", e), null;
		}
		return 0 === _.Be ? null : _;
	}
	/**
	* Apply bloom filter to remove the deleted documents, and return the
	* application status.
	*/ bt(e, t, n) {
		return t.$e.count === n - this.vt(e, t.targetId) ? 0 : 2;
	}
	/**
	* Filter out removed documents based on bloom filter membership result and
	* return number of documents removed.
	*/ vt(e, t) {
		const n = this._t.getRemoteKeysForTarget(t);
		let r = 0;
		return n.forEach(((n) => {
			const i = this._t.xt(), s = `projects/${i.projectId}/databases/${i.database}/documents/${n.path.canonicalString()}`;
			e.mightContain(s) || (this.It(t, n, null), r++);
		})), r;
	}
	/**
	* Converts the currently accumulated state into a remote event at the
	* provided snapshot version. Resets the accumulated changes before returning.
	*/ Dt(e) {
		const t = /* @__PURE__ */ new Map();
		this.ot.forEach(((n, r) => {
			const i = this.gt(r);
			if (i) {
				if (n.current && this.ft(i.target)) {
					const n = new DocumentKey(__PRIVATE_targetIsPipelineTarget(i.target) ? ResourcePath.fromString(i.target.getPipelineDocuments()[0]) : i.target.path);
					this.Ct(n).has(r) || this.Ft(r, n) || this.It(r, n, MutableDocument.newNoDocument(n, e));
				}
				n.Ye && (t.set(r, n.Xe()), n.et());
			}
		}));
		let n = __PRIVATE_documentKeySet();
		this.Et.forEach(((e, t) => {
			let r = true;
			t.forEachWhile(((e) => {
				const t = this.gt(e);
				return !t || "TargetPurposeLimboResolution" === t.purpose || (r = false, false);
			})), r && (n = n.add(e));
		})), this.ut.forEach(((t, n) => n.setReadTime(e))), this.lt.forEach(((t, n) => n.setReadTime(e)));
		const r = new RemoteEvent(e, t, this.ht, this.ut, this.lt, n);
		return this.ut = __PRIVATE_mutableDocumentMap(), this.ct = __PRIVATE_documentTargetMap(), this.lt = __PRIVATE_mutableDocumentMap(), this.Et = __PRIVATE_documentTargetMap(), this.ht = new SortedMap(__PRIVATE_primitiveComparator), r;
	}
	/**
	* Adds the provided document to the internal list of document updates and
	* its document key to the given target's mapping.
	*/
	Pt(e, t) {
		const n = this.ot.get(e);
		if (!n || !this.At(e)) return void __PRIVATE_logDebug(Lt, `addDocumentToTarget received document for unknown inactive target (${e})`);
		const r = this.Ft(e, t.key) ? 2 : 0;
		n.tt(t.key, r), __PRIVATE_targetIsPipelineTarget(this.gt(e).target) && "exact" !== this.gt(e).target.getPipelineFlavor() ? this.lt = this.lt.insert(t.key, t) : this.ut = this.ut.insert(t.key, t), this.ct = this.ct.insert(t.key, this.Ct(t.key).add(e)), this.Et = this.Et.insert(t.key, this.Ot(t.key).add(e));
	}
	/**
	* Removes the provided document from the target mapping. If the
	* document no longer matches the target, but the document's state is still
	* known (e.g. we know that the document was deleted or we received the change
	* that caused the filter mismatch), the new document can be provided
	* to update the remote document cache.
	*/
	It(e, t, n) {
		const r = this.ot.get(e);
		r && this.At(e) ? (this.Ft(e, t) ? r.tt(t, 1) : r.nt(t), this.Et = this.Et.insert(t, this.Ot(t).delete(e)), this.Et = this.Et.insert(t, this.Ot(t).add(e)), n && (__PRIVATE_targetIsPipelineTarget(this.gt(e).target) && "exact" !== this.gt(e).target.getPipelineFlavor() ? this.lt = this.lt.insert(t, n) : this.ut = this.ut.insert(t, n))) : __PRIVATE_logDebug(Lt, `removeDocumentFromTarget received document for unknown or inactive target (${e})`);
	}
	removeTarget(e) {
		this.ot.delete(e);
	}
	/**
	* Returns the current count of documents in the target. This includes both
	* the number of documents that the LocalStore considers to be part of the
	* target as well as any accumulated changes.
	*/ yt(e) {
		const t = this.ot.get(e);
		if (!t) return 0;
		const n = t.Xe();
		return this._t.getRemoteKeysForTarget(e).size + n.addedDocuments.size - n.removedDocuments.size;
	}
	/**
	* Increment the number of acks needed from watch before we can consider the
	* server to be 'in-sync' with the client's active targets.
	*/ rt(e) {
		let t = this.ot.get(e);
		t || (__PRIVATE_logDebug(Lt, `recordPendingTargetRequest set up tracking for target ID ${e}`), t = new __PRIVATE_TargetState(e), this.ot.set(e, t)), t.rt();
	}
	Ot(e) {
		let t = this.Et.get(e);
		return t || (t = new SortedSet(__PRIVATE_primitiveComparator), this.Et = this.Et.insert(e, t)), t;
	}
	Ct(e) {
		let t = this.ct.get(e);
		return t || (t = new SortedSet(__PRIVATE_primitiveComparator), this.ct = this.ct.insert(e, t)), t;
	}
	/**
	* Verifies that the user is still interested in this target (by calling
	* `getTargetDataForTarget()`) and that we are not waiting for pending ADDs
	* from watch.
	*/ At(e) {
		const t = null !== this.gt(e);
		return t || __PRIVATE_logDebug(Lt, "Detected inactive target", e), t;
	}
	/**
	* Returns the TargetData for an active target (i.e. a target that the user
	* is still interested in that has no outstanding target change requests).
	*/ gt(e) {
		const t = this.ot.get(e);
		return void 0 === t || t.Je ? null : this._t.Mt(e);
	}
	/**
	* Resets the state of a Watch target to its initial state (e.g. sets
	* 'current' to false, clears the resume token and removes its target mapping
	* from all documents).
	*/ Vt(e) {
		this.ot.set(e, new __PRIVATE_TargetState(e));
		this._t.getRemoteKeysForTarget(e).forEach(((t) => {
			this.It(e, t, null);
		}));
	}
	/**
	* Returns whether the LocalStore considers the document to be part of the
	* specified target.
	*/ Ft(e, t) {
		return this._t.getRemoteKeysForTarget(e).has(t);
	}
};
function __PRIVATE_documentTargetMap() {
	return new SortedMap(DocumentKey.comparator);
}
function __PRIVATE_snapshotChangesMap() {
	return new SortedMap(DocumentKey.comparator);
}
var Ut = (() => {
	return {
		asc: "ASCENDING",
		desc: "DESCENDING"
	};
})();
var kt = (() => {
	return {
		"<": "LESS_THAN",
		"<=": "LESS_THAN_OR_EQUAL",
		">": "GREATER_THAN",
		">=": "GREATER_THAN_OR_EQUAL",
		"==": "EQUAL",
		"!=": "NOT_EQUAL",
		"array-contains": "ARRAY_CONTAINS",
		in: "IN",
		"not-in": "NOT_IN",
		"array-contains-any": "ARRAY_CONTAINS_ANY"
	};
})();
var Qt = (() => {
	return {
		and: "AND",
		or: "OR"
	};
})();
/**
* This class generates JsonObject values for the Datastore API suitable for
* sending to either GRPC stub methods or via the JSON/HTTP REST API.
*
* The serializer supports both Protobuf.js and Proto3 JSON formats. By
* setting `useProto3Json` to true, the serializer will use the Proto3 JSON
* format.
*
* For a description of the Proto3 JSON format check
* https://developers.google.com/protocol-buffers/docs/proto3#json
*
* TODO(klimt): We can remove the databaseId argument if we keep the full
* resource name in documents.
*/
var JsonProtoSerializer = class {
	constructor(e, t) {
		this.databaseId = e, this.useProto3Json = t;
	}
};
/**
* Returns a value for a number (or null) that's appropriate to put into
* a google.protobuf.Int32Value proto.
* DO NOT USE THIS FOR ANYTHING ELSE.
* This method cheats. It's typed as returning "number" because that's what
* our generated proto interfaces say Int32Value must be. But GRPC actually
* expects a { value: <number> } struct.
*/
function __PRIVATE_toInt32Proto(e, t) {
	return e.useProto3Json || __PRIVATE_isNullOrUndefined(t) ? t : { value: t };
}
/**
* Returns a number (or null) from a google.protobuf.Int32Value proto.
*/
/**
* Returns a value for a Date that's appropriate to put into a proto.
*/
function toTimestamp(e, t) {
	if (e.useProto3Json) return `${(/* @__PURE__ */ new Date(1e3 * t.seconds)).toISOString().replace(/\.\d*/, "").replace("Z", "")}.${("000000000" + t.nanoseconds).slice(-9)}Z`;
	return {
		seconds: "" + t.seconds,
		nanos: t.nanoseconds
	};
}
/**
* Returns a Timestamp typed object given protobuf timestamp value.
*/ function fromTimestamp(e) {
	const t = __PRIVATE_normalizeTimestamp(e);
	return new Timestamp(t.seconds, t.nanos);
}
/**
* Returns a value for bytes that's appropriate to put in a proto.
*
* Visible for testing.
*/ function __PRIVATE_toBytes(e, t) {
	return e.useProto3Json ? t.toBase64() : t.toUint8Array();
}
/**
* Returns a ByteString based on the proto string value.
*/ function __PRIVATE_toVersion(e, t) {
	return toTimestamp(e, t.toTimestamp());
}
function __PRIVATE_fromVersion(e) {
	return __PRIVATE_hardAssert(!!e, 49232), SnapshotVersion.fromTimestamp(fromTimestamp(e));
}
function __PRIVATE_toResourceName(e, t) {
	return __PRIVATE_toResourcePath(e, t).canonicalString();
}
function __PRIVATE_toResourcePath(e, t) {
	const n = function __PRIVATE_fullyQualifiedPrefixPath(e) {
		return new ResourcePath([
			"projects",
			e.projectId,
			"databases",
			e.database
		]);
	}(e).child("documents");
	return void 0 === t ? n : n.child(t);
}
function __PRIVATE_fromResourceName(e) {
	const t = ResourcePath.fromString(e);
	return __PRIVATE_hardAssert(__PRIVATE_isValidResourceName(t), 10190, { key: t.toString() }), t;
}
function __PRIVATE_toName(e, t) {
	return __PRIVATE_toResourceName(e.databaseId, t.path);
}
function fromName(t, n) {
	const r = __PRIVATE_fromResourceName(n);
	if (r.get(1) !== t.databaseId.projectId) throw new e(ta.INVALID_ARGUMENT, "Tried to deserialize key from different project: " + r.get(1) + " vs " + t.databaseId.projectId);
	if (r.get(3) !== t.databaseId.database) throw new e(ta.INVALID_ARGUMENT, "Tried to deserialize key from different database: " + r.get(3) + " vs " + t.databaseId.database);
	return new DocumentKey(__PRIVATE_extractLocalPathFromResourceName(r));
}
function __PRIVATE_toQueryPath(e, t) {
	return __PRIVATE_toResourceName(e.databaseId, t);
}
function __PRIVATE_fromQueryPath(e) {
	const t = __PRIVATE_fromResourceName(e);
	return 4 === t.length ? ResourcePath.emptyPath() : __PRIVATE_extractLocalPathFromResourceName(t);
}
function __PRIVATE_getEncodedDatabaseId(e) {
	return new ResourcePath([
		"projects",
		e.databaseId.projectId,
		"databases",
		e.databaseId.database
	]).canonicalString();
}
function __PRIVATE_extractLocalPathFromResourceName(e) {
	return __PRIVATE_hardAssert(e.length > 4 && "documents" === e.get(4), 29091, { key: e.toString() }), e.popFirst(5);
}
/** Creates a Document proto from key and fields (but no create/update time) */ function __PRIVATE_toMutationDocument(e, t, n) {
	return {
		name: __PRIVATE_toName(e, t),
		fields: n.value.mapValue.fields
	};
}
function __PRIVATE_fromWatchChange(t, n) {
	let r;
	if ("targetChange" in n) {
		n.targetChange;
		const i = function __PRIVATE_fromWatchTargetChangeState(e) {
			return "NO_CHANGE" === e ? 0 : "ADD" === e ? 1 : "REMOVE" === e ? 2 : "CURRENT" === e ? 3 : "RESET" === e ? 4 : l(39313, { state: e });
		}(n.targetChange.targetChangeType || "NO_CHANGE"), s = n.targetChange.targetIds || [], _ = function __PRIVATE_fromBytes(e, t) {
			return e.useProto3Json ? (__PRIVATE_hardAssert(void 0 === t || "string" == typeof t, 58123), ByteString.fromBase64String(t || "")) : (__PRIVATE_hardAssert(void 0 === t || t instanceof Buffer || t instanceof Uint8Array, 16193), ByteString.fromUint8Array(t || /* @__PURE__ */ new Uint8Array()));
		}(t, n.targetChange.resumeToken), o = n.targetChange.cause;
		r = new __PRIVATE_WatchTargetChange(i, s, _, o && function __PRIVATE_fromRpcStatus(t) {
			return new e(void 0 === t.code ? ta.UNKNOWN : __PRIVATE_mapCodeFromRpcCode(t.code), t.message || "");
		}(o) || null);
	} else if ("documentChange" in n) {
		n.documentChange;
		const e = n.documentChange;
		e.document, e.document.name, e.document.updateTime;
		const i = fromName(t, e.document.name), s = __PRIVATE_fromVersion(e.document.updateTime), _ = e.document.createTime ? __PRIVATE_fromVersion(e.document.createTime) : SnapshotVersion.min(), o = new ObjectValue({ mapValue: { fields: e.document.fields } }), a = MutableDocument.newFoundDocument(i, s, _, o);
		r = new __PRIVATE_DocumentWatchChange(e.targetIds || [], e.removedTargetIds || [], a.key, a);
	} else if ("documentDelete" in n) {
		n.documentDelete;
		const e = n.documentDelete;
		e.document;
		const i = fromName(t, e.document), s = e.readTime ? __PRIVATE_fromVersion(e.readTime) : SnapshotVersion.min(), _ = MutableDocument.newNoDocument(i, s);
		r = new __PRIVATE_DocumentWatchChange([], e.removedTargetIds || [], _.key, _);
	} else if ("documentRemove" in n) {
		n.documentRemove;
		const e = n.documentRemove;
		e.document;
		const i = fromName(t, e.document);
		r = new __PRIVATE_DocumentWatchChange([], e.removedTargetIds || [], i, null);
	} else {
		if (!("filter" in n)) return l(11601, { Nt: n });
		{
			n.filter;
			const e = n.filter;
			e.targetId;
			const { count: t = 0, unchangedNames: i } = e, s = new ExistenceFilter(t, i), _ = e.targetId;
			r = new __PRIVATE_ExistenceFilterChange(_, s);
		}
	}
	return r;
}
function toMutation(e, t) {
	let n;
	if (t instanceof __PRIVATE_SetMutation) n = { update: __PRIVATE_toMutationDocument(e, t.key, t.value) };
	else if (t instanceof __PRIVATE_DeleteMutation) n = { delete: __PRIVATE_toName(e, t.key) };
	else if (t instanceof __PRIVATE_PatchMutation) n = {
		update: __PRIVATE_toMutationDocument(e, t.key, t.data),
		updateMask: __PRIVATE_toDocumentMask(t.fieldMask)
	};
	else {
		if (!(t instanceof __PRIVATE_VerifyMutation)) return l(16599, { Bt: t.type });
		n = { verify: __PRIVATE_toName(e, t.key) };
	}
	return t.fieldTransforms.length > 0 && (n.updateTransforms = t.fieldTransforms.map(((e) => function __PRIVATE_toFieldTransform(e, t) {
		const n = t.transform;
		if (n instanceof __PRIVATE_ServerTimestampTransform) return {
			fieldPath: t.field.canonicalString(),
			setToServerValue: "REQUEST_TIME"
		};
		if (n instanceof __PRIVATE_ArrayUnionTransformOperation) return {
			fieldPath: t.field.canonicalString(),
			appendMissingElements: { values: n.elements }
		};
		if (n instanceof __PRIVATE_ArrayRemoveTransformOperation) return {
			fieldPath: t.field.canonicalString(),
			removeAllFromArray: { values: n.elements }
		};
		if (n instanceof __PRIVATE_NumericIncrementTransformOperation) return {
			fieldPath: t.field.canonicalString(),
			increment: n.xe
		};
		if (n instanceof __PRIVATE_NumericMinimumTransformOperation) return {
			fieldPath: t.field.canonicalString(),
			minimum: n.xe
		};
		if (n instanceof __PRIVATE_NumericMaximumTransformOperation) return {
			fieldPath: t.field.canonicalString(),
			maximum: n.xe
		};
		throw l(20930, { transform: t.transform });
	}(0, e)))), t.precondition.isNone || (n.currentDocument = function __PRIVATE_toPrecondition(e, t) {
		return void 0 !== t.updateTime ? { updateTime: __PRIVATE_toVersion(e, t.updateTime) } : void 0 !== t.exists ? { exists: t.exists } : l(27497);
	}(e, t.precondition)), n;
}
function __PRIVATE_fromWriteResults(e, t) {
	return e && e.length > 0 ? (__PRIVATE_hardAssert(void 0 !== t, 14353), e.map(((e) => function __PRIVATE_fromWriteResult(e, t) {
		let n = e.updateTime ? __PRIVATE_fromVersion(e.updateTime) : __PRIVATE_fromVersion(t);
		return n.isEqual(SnapshotVersion.min()) && (n = __PRIVATE_fromVersion(t)), new MutationResult(n, e.transformResults || []);
	}(e, t)))) : [];
}
function __PRIVATE_toDocumentsTarget(e, t) {
	return { documents: [__PRIVATE_toQueryPath(e, t.path)] };
}
function __PRIVATE_toQueryTarget(e, t) {
	const n = { structuredQuery: {} }, r = t.path;
	let i;
	null !== t.collectionGroup ? (i = r, n.structuredQuery.from = [{
		collectionId: t.collectionGroup,
		allDescendants: true
	}]) : (i = r.popLast(), n.structuredQuery.from = [{ collectionId: r.lastSegment() }]), n.parent = __PRIVATE_toQueryPath(e, i);
	const s = function __PRIVATE_toFilters(e) {
		if (0 === e.length) return;
		return __PRIVATE_toFilter(CompositeFilter.create(e, "and"));
	}(t.filters);
	s && (n.structuredQuery.where = s);
	const _ = function __PRIVATE_toOrder(e) {
		if (0 === e.length) return;
		return e.map(((e) => function __PRIVATE_toPropertyOrder(e) {
			return {
				field: __PRIVATE_toFieldPathReference(e.field),
				direction: __PRIVATE_toDirection(e.dir)
			};
		}(e)));
	}(t.orderBy);
	_ && (n.structuredQuery.orderBy = _);
	const o = __PRIVATE_toInt32Proto(e, t.limit);
	return null !== o && (n.structuredQuery.limit = o), t.startAt && (n.structuredQuery.startAt = function __PRIVATE_toStartAtCursor(e) {
		return {
			before: e.inclusive,
			values: e.position
		};
	}(t.startAt)), t.endAt && (n.structuredQuery.endAt = function __PRIVATE_toEndAtCursor(e) {
		return {
			before: !e.inclusive,
			values: e.position
		};
	}(t.endAt)), {
		Lt: n,
		parent: i
	};
}
function __PRIVATE_convertQueryTargetToQuery(e) {
	let t = __PRIVATE_fromQueryPath(e.parent);
	const n = e.structuredQuery, r = n.from ? n.from.length : 0;
	let i = null;
	if (r > 0) {
		__PRIVATE_hardAssert(1 === r, 65062);
		const e = n.from[0];
		e.allDescendants ? i = e.collectionId : t = t.child(e.collectionId);
	}
	let s = [];
	n.where && (s = function __PRIVATE_fromFilters(e) {
		const t = __PRIVATE_fromFilter(e);
		if (t instanceof CompositeFilter && __PRIVATE_compositeFilterIsFlatConjunction(t)) return t.getFilters();
		return [t];
	}(n.where));
	let _ = [];
	n.orderBy && (_ = function __PRIVATE_fromOrder(e) {
		return e.map(((e) => function __PRIVATE_fromPropertyOrder(e) {
			return new OrderBy(__PRIVATE_fromFieldPathReference(e.field), function __PRIVATE_fromDirection(e) {
				switch (e) {
					case "ASCENDING": return "asc";
					case "DESCENDING": return "desc";
					default: return;
				}
			}(e.direction));
		}(e)));
	}(n.orderBy));
	let o = null;
	n.limit && (o = function __PRIVATE_fromInt32Proto(e) {
		let t;
		return t = "object" == typeof e ? e.value : e, __PRIVATE_isNullOrUndefined(t) ? null : t;
	}(n.limit));
	let a = null;
	n.startAt && (a = function __PRIVATE_fromStartAtCursor(e) {
		const t = !!e.before;
		return new Bound(e.values || [], t);
	}(n.startAt));
	let u = null;
	return n.endAt && (u = function __PRIVATE_fromEndAtCursor(e) {
		const t = !e.before;
		return new Bound(e.values || [], t);
	}(n.endAt)), __PRIVATE_newQuery(t, i, _, s, o, "F", a, u);
}
function __PRIVATE_toListenRequestLabels(e, t) {
	const n = function __PRIVATE_toLabel(e) {
		switch (e) {
			case "TargetPurposeListen": return null;
			case "TargetPurposeExistenceFilterMismatch": return "existence-filter-mismatch";
			case "TargetPurposeExistenceFilterMismatchBloom": return "existence-filter-mismatch-bloom";
			case "TargetPurposeLimboResolution": return "limbo-document";
			default: return l(28987, { purpose: e });
		}
	}(t.purpose);
	return null == n ? null : { "goog-listen-tags": n };
}
function __PRIVATE_toPipelineTarget(e, t) {
	return { structuredPipeline: { pipeline: { stages: t.stages.map(((t) => t._toProto(e))) } } };
}
function __PRIVATE_fromFilter(e) {
	return void 0 !== e.unaryFilter ? function __PRIVATE_fromUnaryFilter(e) {
		switch (e.unaryFilter.op) {
			case "IS_NAN":
				const t = __PRIVATE_fromFieldPathReference(e.unaryFilter.field);
				return FieldFilter.create(t, "==", { doubleValue: NaN });
			case "IS_NULL":
				const n = __PRIVATE_fromFieldPathReference(e.unaryFilter.field);
				return FieldFilter.create(n, "==", { nullValue: "NULL_VALUE" });
			case "IS_NOT_NAN":
				const r = __PRIVATE_fromFieldPathReference(e.unaryFilter.field);
				return FieldFilter.create(r, "!=", { doubleValue: NaN });
			case "IS_NOT_NULL":
				const i = __PRIVATE_fromFieldPathReference(e.unaryFilter.field);
				return FieldFilter.create(i, "!=", { nullValue: "NULL_VALUE" });
			case "OPERATOR_UNSPECIFIED": return l(61313);
			default: return l(60726);
		}
	}(e) : void 0 !== e.fieldFilter ? function __PRIVATE_fromFieldFilter(e) {
		return FieldFilter.create(__PRIVATE_fromFieldPathReference(e.fieldFilter.field), function __PRIVATE_fromOperatorName(e) {
			switch (e) {
				case "EQUAL": return "==";
				case "NOT_EQUAL": return "!=";
				case "GREATER_THAN": return ">";
				case "GREATER_THAN_OR_EQUAL": return ">=";
				case "LESS_THAN": return "<";
				case "LESS_THAN_OR_EQUAL": return "<=";
				case "ARRAY_CONTAINS": return "array-contains";
				case "IN": return "in";
				case "NOT_IN": return "not-in";
				case "ARRAY_CONTAINS_ANY": return "array-contains-any";
				case "OPERATOR_UNSPECIFIED": return l(58110);
				default: return l(50506);
			}
		}(e.fieldFilter.op), e.fieldFilter.value);
	}(e) : void 0 !== e.compositeFilter ? function __PRIVATE_fromCompositeFilter(e) {
		return CompositeFilter.create(e.compositeFilter.filters.map(((e) => __PRIVATE_fromFilter(e))), function __PRIVATE_fromCompositeOperatorName(e) {
			switch (e) {
				case "AND": return "and";
				case "OR": return "or";
				default: return l(1026);
			}
		}(e.compositeFilter.op));
	}(e) : l(30097, { filter: e });
}
function __PRIVATE_toDirection(e) {
	return Ut[e];
}
function __PRIVATE_toOperatorName(e) {
	return kt[e];
}
function __PRIVATE_toCompositeOperatorName(e) {
	return Qt[e];
}
function __PRIVATE_toFieldPathReference(e) {
	return { fieldPath: e.canonicalString() };
}
function __PRIVATE_fromFieldPathReference(e) {
	return Me$1.fromServerFormat(e.fieldPath);
}
function __PRIVATE_toFilter(e) {
	return e instanceof FieldFilter ? function __PRIVATE_toUnaryOrFieldFilter(e) {
		if ("==" === e.op) {
			if (__PRIVATE_isNanValue(e.value)) return { unaryFilter: {
				field: __PRIVATE_toFieldPathReference(e.field),
				op: "IS_NAN"
			} };
			if (__PRIVATE_isNullValue(e.value)) return { unaryFilter: {
				field: __PRIVATE_toFieldPathReference(e.field),
				op: "IS_NULL"
			} };
		} else if ("!=" === e.op) {
			if (__PRIVATE_isNanValue(e.value)) return { unaryFilter: {
				field: __PRIVATE_toFieldPathReference(e.field),
				op: "IS_NOT_NAN"
			} };
			if (__PRIVATE_isNullValue(e.value)) return { unaryFilter: {
				field: __PRIVATE_toFieldPathReference(e.field),
				op: "IS_NOT_NULL"
			} };
		}
		return { fieldFilter: {
			field: __PRIVATE_toFieldPathReference(e.field),
			op: __PRIVATE_toOperatorName(e.op),
			value: e.value
		} };
	}(e) : e instanceof CompositeFilter ? function __PRIVATE_toCompositeFilter(e) {
		const t = e.getFilters().map(((e) => __PRIVATE_toFilter(e)));
		if (1 === t.length) return t[0];
		return { compositeFilter: {
			op: __PRIVATE_toCompositeOperatorName(e.op),
			filters: t
		} };
	}(e) : l(54877, { filter: e });
}
function __PRIVATE_toDocumentMask(e) {
	const t = [];
	return e.fields.forEach(((e) => t.push(e.canonicalString()))), { fieldPaths: t };
}
function __PRIVATE_isValidResourceName(e) {
	return e.length >= 4 && "projects" === e.get(0) && "databases" === e.get(2);
}
function __PRIVATE_isProtoValueSerializable(e) {
	return !!e && "function" == typeof e._toProto && "ProtoValue" === e._protoValueType;
}
function toMapValue(e, t) {
	const n = { fields: {} };
	return t.forEach(((t, r) => {
		if ("string" != typeof r) throw new Error(`Cannot encode map with non-string key: ${r}`);
		n.fields[r] = t._toProto(e);
	})), { mapValue: n };
}
function __PRIVATE_toStringValue(e) {
	return { stringValue: e };
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ function __PRIVATE_newSerializer(e) {
	return new JsonProtoSerializer(e, true);
}
/**
* @license
* Copyright 2025 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Represents a BSON ObjectId type in Firestore documents.
*
* @class BsonObjectId
*/ var BsonObjectId = class {
	constructor(e) {
		this.value = e;
	}
	/**
	* Returns true if this `BsonObjectId` is equal to the provided one.
	*
	* @param other - The `BsonObjectId` to compare against.
	* @return 'true' if this `BsonObjectId` is equal to the provided one.
	*/ isEqual(e) {
		return this.value === e.value;
	}
};
/**
* @license
* Copyright 2025 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Represents a BSON Timestamp type in Firestore documents.
*
* @class BsonTimestamp
*/ var BsonTimestamp = class {
	constructor(e, t) {
		if (this.seconds = e, this.increment = t, !Number.isInteger(e) || e < 0 || e > 4294967295) throw new Error("BsonTimestamp 'seconds' must be in the range of a 32-bit unsigned integer (0-4294967295).");
		if (!Number.isInteger(t) || t < 0 || t > 4294967295) throw new Error("BsonTimestamp 'increment' must be in the range of a 32-bit unsigned integer (0-4294967295).");
	}
	/**
	* Returns true if this `BsonTimestamp` is equal to the provided one.
	*
	* @param other -  The `BsonTimestamp` to compare against.
	* @return 'true' if this `BsonTimestamp` is equal to the provided one.
	*/ isEqual(e) {
		return this.seconds === e.seconds && this.increment === e.increment;
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* An immutable object representing an array of bytes.
*/ var Bytes = class Bytes {
	/** @hideconstructor */
	constructor(t, n = 0) {
		if (this.subtype = n, !Number.isInteger(n) || n < 0 || n > 255) throw new e(ta.INVALID_ARGUMENT, "The subtype for Bytes must be a value in the inclusive [0, 255] range.");
		this._byteString = t;
	}
	/**
	* Creates a new `Bytes` object from the given Base64 string, converting it to
	* bytes.
	*
	* @param base64 - The Base64 string used to create the `Bytes` object.
	* @param subtype - Optional subtype value.
	*/ static fromBase64String(t, n = 0) {
		try {
			return new Bytes(ByteString.fromBase64String(t), n);
		} catch (t) {
			throw new e(ta.INVALID_ARGUMENT, "Failed to construct data from Base64 string: " + t);
		}
	}
	/**
	* Creates a new `Bytes` object from the given Uint8Array.
	*
	* @param array - The Uint8Array used to create the `Bytes` object.
	* @param subtype - Optional subtype value.
	*/ static fromUint8Array(e, t = 0) {
		return new Bytes(ByteString.fromUint8Array(e), t);
	}
	/**
	* Returns the underlying bytes as a Base64-encoded string.
	*
	* @returns The Base64-encoded string created from the `Bytes` object.
	*/ toBase64() {
		return this._byteString.toBase64();
	}
	/**
	* Returns the underlying bytes in a new `Uint8Array`.
	*
	* @returns The Uint8Array created from the `Bytes` object.
	*/ toUint8Array() {
		return this._byteString.toUint8Array();
	}
	/**
	* Returns the underlying bytes as a `Uint8Array`.
	*
	* @returns The Uint8Array created from the `Bytes` object.
	*/ get data() {
		return this.toUint8Array();
	}
	/**
	* Returns a string representation of the `Bytes` object.
	*
	* @returns A string representation of the `Bytes` object.
	*/ toString() {
		return "Bytes(base64: " + this.toBase64() + ", subtype: " + this.subtype + ")";
	}
	/**
	* Returns true if this `Bytes` object is equal to the provided one.
	*
	* @param other - The `Bytes` object to compare against.
	* @returns true if this `Bytes` object is equal to the provided one.
	*/ isEqual(e) {
		return this.subtype === e.subtype && this._byteString.isEqual(e._byteString);
	}
	/**
	* Returns a JSON-serializable representation of this `Bytes` instance.
	*
	* @returns a JSON representation of this object.
	*/ toJSON() {
		const e = {
			type: Bytes._jsonSchemaVersion,
			bytes: this.toBase64()
		};
		return 0 !== this.subtype && (e.subtype = this.subtype), e;
	}
	/**
	* Builds a `Bytes` instance from a JSON object created by {@link Bytes.toJSON}.
	*
	* @param json - a JSON object represention of a `Bytes` instance
	* @returns an instance of {@link Bytes} if the JSON object could be parsed. Throws a
	* {@link FirestoreError} if an error occurs.
	*/ static fromJSON(e) {
		if (__PRIVATE_validateJSON(e, Bytes._jsonSchema)) {
			const t = e.subtype ?? 0;
			return Bytes.fromBase64String(e.bytes, t);
		}
	}
};
Bytes._jsonSchemaVersion = "firestore/bytes/1.0", Bytes._jsonSchema = {
	type: property("string", Bytes._jsonSchemaVersion),
	bytes: property("string"),
	subtype: {
		...property("number"),
		optional: true
	}
};
/**
* @license
* Copyright 2025 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Represents a 128-bit decimal type in Firestore documents.
*
* @class Decimal128Value
*/
var Decimal128Value = class {
	constructor(e) {
		this.stringValue = e, this.value = __PRIVATE_Quadruple.fromString(e);
	}
	/**
	* Returns true if this `Decimal128Value` is equal to the provided one.
	*
	* @param other - The `Decimal128Value` to compare against.
	* @return 'true' if this `Decimal128Value` is equal to the provided one.
	*/ isEqual(e) {
		return !(!this.value.oe() || !e.value.oe()) || 0 === this.value.compareTo(e.value);
	}
	/**
	* Returns a JSON-serializable representation of this `Decimal128Value` instance.
	*
	* @returns a JSON representation of this object.
	*/ toJSON() {
		return { kt: { stringValue: this.stringValue } };
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* A `FieldPath` refers to a field in a document. The path may consist of a
* single field name (referring to a top-level field in the document), or a
* list of field names (referring to a nested field in the document).
*
* Create a `FieldPath` by providing field names. If more than one field
* name is provided, the path will point to a nested field in a document.
*/ var FieldPath = class {
	/**
	* Creates a `FieldPath` from the provided field names. If more than one field
	* name is provided, the path will point to a nested field in a document.
	*
	* @param fieldNames - A list of field names.
	*/
	constructor(...t) {
		for (let n = 0; n < t.length; ++n) if (0 === t[n].length) throw new e(ta.INVALID_ARGUMENT, "Invalid field name at argument $(i + 1). Field names must not be empty.");
		this._internalPath = new Me$1(t);
	}
	/**
	* Returns true if this `FieldPath` is equal to the provided one.
	*
	* @param other - The `FieldPath` to compare against.
	* @returns true if this `FieldPath` is equal to the provided one.
	*/ isEqual(e) {
		return this._internalPath.isEqual(e._internalPath);
	}
};
/**
* Returns a special sentinel `FieldPath` to refer to the ID of a document.
* It can be used in queries to sort or filter by the document ID.
*/ function documentId$1() {
	return new FieldPath(Fe);
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Sentinel values that can be used when writing document fields with `set()`
* or `update()`.
*/ var FieldValue = class {
	/**
	* @param _methodName - The public API endpoint that returns this class.
	* @hideconstructor
	*/
	constructor(e) {
		this._methodName = e;
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* An immutable object representing a geographic location in Firestore. The
* location is represented as latitude/longitude pair.
*
* Latitude values are in the range of [-90, 90].
* Longitude values are in the range of [-180, 180].
*/ var GeoPoint = class GeoPoint {
	/**
	* Creates a new immutable `GeoPoint` object with the provided latitude and
	* longitude values.
	* @param latitude - The latitude as number between -90 and 90.
	* @param longitude - The longitude as number between -180 and 180.
	*/
	constructor(t, n) {
		if (!isFinite(t) || t < -90 || t > 90) throw new e(ta.INVALID_ARGUMENT, "Latitude must be a number between -90 and 90, but was: " + t);
		if (!isFinite(n) || n < -180 || n > 180) throw new e(ta.INVALID_ARGUMENT, "Longitude must be a number between -180 and 180, but was: " + n);
		this._lat = t, this._long = n;
	}
	/**
	* The latitude of this `GeoPoint` instance.
	*/ get latitude() {
		return this._lat;
	}
	/**
	* The longitude of this `GeoPoint` instance.
	*/ get longitude() {
		return this._long;
	}
	/**
	* Returns true if this `GeoPoint` is equal to the provided one.
	*
	* @param other - The `GeoPoint` to compare against.
	* @returns true if this `GeoPoint` is equal to the provided one.
	*/ isEqual(e) {
		return this._lat === e._lat && this._long === e._long;
	}
	/**
	* Actually private to JS consumers of our API, so this function is prefixed
	* with an underscore.
	*/ _compareTo(e) {
		return __PRIVATE_primitiveComparator(this._lat, e._lat) || __PRIVATE_primitiveComparator(this._long, e._long);
	}
	/**
	* Returns a JSON-serializable representation of this `GeoPoint` instance.
	*
	* @returns a JSON representation of this object.
	*/ toJSON() {
		return {
			latitude: this._lat,
			longitude: this._long,
			type: GeoPoint._jsonSchemaVersion
		};
	}
	/**
	* Builds a `GeoPoint` instance from a JSON object created by {@link GeoPoint.toJSON}.
	*
	* @param json - a JSON object represention of a `GeoPoint` instance
	* @returns an instance of {@link GeoPoint} if the JSON object could be parsed. Throws a
	* {@link FirestoreError} if an error occurs.
	*/ static fromJSON(e) {
		if (__PRIVATE_validateJSON(e, GeoPoint._jsonSchema)) return new GeoPoint(e.latitude, e.longitude);
	}
};
GeoPoint._jsonSchemaVersion = "firestore/geoPoint/1.0", GeoPoint._jsonSchema = {
	type: property("string", GeoPoint._jsonSchemaVersion),
	latitude: property("number"),
	longitude: property("number")
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Represents a 32-bit integer type in Firestore documents.
*
* @class Int32Value
*/
var Int32Value = class {
	constructor(e) {
		this.value = e;
	}
	/**
	* Returns true if this `Int32Value` is equal to the provided one.
	*
	* @param other - The `Int32Value` to compare against.
	* @return 'true' if this `Int32Value` is equal to the provided one.
	*/ isEqual(e) {
		return this.value === e.value;
	}
};
/**
* @license
* Copyright 2025 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Represent a "Max Key" type in Firestore documents.
*
* @class MaxKey
*/ var MaxKey = class MaxKey {
	constructor() {
		/** A type string to uniquely identify instances of this class. */
		this.type = "MaxKey";
	}
	static instance() {
		return MaxKey.MAX_KEY_VALUE_INSTANCE || (MaxKey.MAX_KEY_VALUE_INSTANCE = new MaxKey()), MaxKey.MAX_KEY_VALUE_INSTANCE;
	}
};
MaxKey.MAX_KEY_VALUE_INSTANCE = null;
/**
* @license
* Copyright 2025 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Represent a "Min Key" type in Firestore documents.
*
* @class MinKey
*/
var MinKey = class MinKey {
	constructor() {
		/** A type string to uniquely identify instances of this class. */
		this.type = "MinKey";
	}
	static instance() {
		return MinKey.MIN_KEY_VALUE_INSTANCE || (MinKey.MIN_KEY_VALUE_INSTANCE = new MinKey()), MinKey.MIN_KEY_VALUE_INSTANCE;
	}
};
MinKey.MIN_KEY_VALUE_INSTANCE = null;
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Simple wrapper around a nullable UID. Mostly exists to make code more
* readable.
*/
var User = class {
	constructor(e) {
		this.uid = e;
	}
	isAuthenticated() {
		return null != this.uid;
	}
	/**
	* Returns a key representing this user, suitable for inclusion in a
	* dictionary.
	*/ toKey() {
		return this.isAuthenticated() ? "uid:" + this.uid : "anonymous-user";
	}
	isEqual(e) {
		return e.uid === this.uid;
	}
};
/** A user with a null UID. */ User.UNAUTHENTICATED = new User(null), User.GOOGLE_CREDENTIALS = new User("google-credentials-uid"), User.FIRST_PARTY = new User("first-party-uid"), User.MOCK_USER = new User("mock-user");
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var __PRIVATE_Deferred = class {
	constructor() {
		this.promise = new Promise(((e, t) => {
			this.resolve = e, this.reject = t;
		}));
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var __PRIVATE_OAuthToken = class {
	constructor(e, t) {
		this.user = t, this.type = "OAuth", this.headers = /* @__PURE__ */ new Map(), this.headers.set("Authorization", `Bearer ${e}`);
	}
};
/**
* A CredentialsProvider that always yields an empty token.
* @internal
*/ var __PRIVATE_EmptyAuthCredentialsProvider = class {
	getToken() {
		return Promise.resolve(null);
	}
	invalidateToken() {}
	start(e, t) {
		e.enqueueRetryable((() => t(User.UNAUTHENTICATED)));
	}
	shutdown() {}
};
/**
* A CredentialsProvider that always returns a constant token. Used for
* emulator token mocking.
*/ var __PRIVATE_EmulatorAuthCredentialsProvider = class {
	constructor(e) {
		this.token = e, this.changeListener = null;
	}
	getToken() {
		return Promise.resolve(this.token);
	}
	invalidateToken() {}
	start(e, t) {
		this.changeListener = t, e.enqueueRetryable((() => t(this.token.user)));
	}
	shutdown() {
		this.changeListener = null;
	}
};
var __PRIVATE_FirebaseAuthCredentialsProvider = class {
	constructor(e) {
		this.Qt = e, this.currentUser = User.UNAUTHENTICATED, this.qt = 0, this.forceRefresh = false, this.auth = null;
	}
	start(e, t) {
		__PRIVATE_hardAssert(void 0 === this.Kt, 42304);
		let n = this.qt;
		const __PRIVATE_guardedChangeListener = (e) => this.qt !== n ? (n = this.qt, t(e)) : Promise.resolve();
		let r = new __PRIVATE_Deferred();
		this.Kt = () => {
			this.qt++, this.currentUser = this.$t(), r.resolve(), r = new __PRIVATE_Deferred(), e.enqueueRetryable((() => __PRIVATE_guardedChangeListener(this.currentUser)));
		};
		const __PRIVATE_awaitNextToken = () => {
			const t = r;
			e.enqueueRetryable((async () => {
				await t.promise, await __PRIVATE_guardedChangeListener(this.currentUser);
			}));
		}, __PRIVATE_registerAuth = (e) => {
			__PRIVATE_logDebug("FirebaseAuthCredentialsProvider", "Auth detected"), this.auth = e, this.Kt && (this.auth.addAuthTokenListener(this.Kt), __PRIVATE_awaitNextToken());
		};
		this.Qt.onInit(((e) => __PRIVATE_registerAuth(e))), setTimeout((() => {
			if (!this.auth) {
				const e = this.Qt.getImmediate({ optional: true });
				e ? __PRIVATE_registerAuth(e) : (__PRIVATE_logDebug("FirebaseAuthCredentialsProvider", "Auth not yet detected"), r.resolve(), r = new __PRIVATE_Deferred());
			}
		}), 0), __PRIVATE_awaitNextToken();
	}
	getToken() {
		const e = this.qt, t = this.forceRefresh;
		return this.forceRefresh = false, this.auth ? this.auth.getToken(t).then(((t) => this.qt !== e ? (__PRIVATE_logDebug("FirebaseAuthCredentialsProvider", "getToken aborted due to token change."), this.getToken()) : t ? (__PRIVATE_hardAssert("string" == typeof t.accessToken, 31837, { Wt: t }), new __PRIVATE_OAuthToken(t.accessToken, this.currentUser)) : null)) : Promise.resolve(null);
	}
	invalidateToken() {
		this.forceRefresh = true;
	}
	shutdown() {
		this.auth && this.Kt && this.auth.removeAuthTokenListener(this.Kt), this.Kt = void 0;
	}
	$t() {
		const e = this.auth && this.auth.getUid();
		return __PRIVATE_hardAssert(null === e || "string" == typeof e, 2055, { Gt: e }), new User(e);
	}
};
var __PRIVATE_FirstPartyToken = class {
	constructor(e, t, n) {
		this.jt = e, this.zt = t, this.Ht = n, this.type = "FirstParty", this.user = User.FIRST_PARTY, this.Jt = /* @__PURE__ */ new Map();
	}
	/**
	* Gets an authorization token, using a provided factory function, or return
	* null.
	*/ Yt() {
		return this.Ht ? this.Ht() : null;
	}
	get headers() {
		this.Jt.set("X-Goog-AuthUser", this.jt);
		const e = this.Yt();
		return e && this.Jt.set("Authorization", e), this.zt && this.Jt.set("X-Goog-Iam-Authorization-Token", this.zt), this.Jt;
	}
};
var __PRIVATE_FirstPartyAuthCredentialsProvider = class {
	constructor(e, t, n) {
		this.jt = e, this.zt = t, this.Ht = n;
	}
	getToken() {
		return Promise.resolve(new __PRIVATE_FirstPartyToken(this.jt, this.zt, this.Ht));
	}
	start(e, t) {
		e.enqueueRetryable((() => t(User.FIRST_PARTY)));
	}
	shutdown() {}
	invalidateToken() {}
};
var AppCheckToken = class {
	constructor(e) {
		this.value = e, this.type = "AppCheck", this.headers = /* @__PURE__ */ new Map(), e && e.length > 0 && this.headers.set("x-firebase-appcheck", this.value);
	}
};
var __PRIVATE_FirebaseAppCheckTokenProvider = class {
	constructor(e, t) {
		this.Zt = t, this.forceRefresh = false, this.appCheck = null, this.Xt = null, this.en = null, _isFirebaseServerApp(e) && e.settings.appCheckToken && (this.en = e.settings.appCheckToken);
	}
	start(e, t) {
		__PRIVATE_hardAssert(void 0 === this.Kt, 3512);
		const onTokenChanged = (e) => {
			null != e.error && __PRIVATE_logDebug("FirebaseAppCheckTokenProvider", `Error getting App Check token; using placeholder token instead. Error: ${e.error.message}`);
			const n = e.token !== this.Xt;
			return this.Xt = e.token, __PRIVATE_logDebug("FirebaseAppCheckTokenProvider", `Received ${n ? "new" : "existing"} token.`), n ? t(e.token) : Promise.resolve();
		};
		this.Kt = (t) => {
			e.enqueueRetryable((() => onTokenChanged(t)));
		};
		const __PRIVATE_registerAppCheck = (e) => {
			__PRIVATE_logDebug("FirebaseAppCheckTokenProvider", "AppCheck detected"), this.appCheck = e, this.Kt && this.appCheck.addTokenListener(this.Kt);
		};
		this.Zt.onInit(((e) => __PRIVATE_registerAppCheck(e))), setTimeout((() => {
			if (!this.appCheck) {
				const e = this.Zt.getImmediate({ optional: true });
				e ? __PRIVATE_registerAppCheck(e) : __PRIVATE_logDebug("FirebaseAppCheckTokenProvider", "AppCheck not yet detected");
			}
		}), 0);
	}
	getToken() {
		if (this.en) return Promise.resolve(new AppCheckToken(this.en));
		const e = this.forceRefresh;
		return this.forceRefresh = false, this.appCheck ? this.appCheck.getToken(e).then(((e) => e ? (__PRIVATE_hardAssert("string" == typeof e.token, 44558, { tokenResult: e }), this.Xt = e.token, new AppCheckToken(e.token)) : null)) : Promise.resolve(null);
	}
	invalidateToken() {
		this.forceRefresh = true;
	}
	shutdown() {
		this.appCheck && this.Kt && this.appCheck.removeTokenListener(this.Kt), this.Kt = void 0;
	}
};
/**
* Builds a CredentialsProvider depending on the type of
* the credentials passed in.
*/
/**
* Creates and returns a new `ExperimentalLongPollingOptions` with the same
* option values as the given instance.
*/
function __PRIVATE_cloneLongPollingOptions(e) {
	const t = {};
	return void 0 !== e.timeoutSeconds && (t.timeoutSeconds = e.timeoutSeconds), t;
}
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var __PRIVATE_NoopConnectivityMonitor = class {
	tn(e) {}
	shutdown() {}
};
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var qt = "ConnectivityMonitor";
/**
* Browser implementation of ConnectivityMonitor.
*/ var __PRIVATE_BrowserConnectivityMonitor = class {
	constructor() {
		this.nn = () => this.rn(), this.sn = () => this._n(), this.an = [], this.un();
	}
	tn(e) {
		this.an.push(e);
	}
	shutdown() {
		window.removeEventListener("online", this.nn), window.removeEventListener("offline", this.sn);
	}
	un() {
		window.addEventListener("online", this.nn), window.addEventListener("offline", this.sn);
	}
	rn() {
		__PRIVATE_logDebug(qt, "Network connectivity changed: AVAILABLE");
		for (const e of this.an) e(0);
	}
	_n() {
		__PRIVATE_logDebug(qt, "Network connectivity changed: UNAVAILABLE");
		for (const e of this.an) e(1);
	}
	/** Checks that all used attributes of window are available. */
	static cn() {
		return "undefined" != typeof window && void 0 !== window.addEventListener && void 0 !== window.removeEventListener;
	}
};
/**
* @license
* Copyright 2023 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* The value returned from the most recent invocation of
* `generateUniqueDebugId()`, or null if it has never been invoked.
*/ var Kt = null;
/**
* Generates and returns an initial value for `lastUniqueDebugId`.
*
* The returned value is randomly selected from a range of integers that are
* represented as 8 hexadecimal digits. This means that (within reason) any
* numbers generated by incrementing the returned number by 1 will also be
* represented by 8 hexadecimal digits. This leads to all "IDs" having the same
* length when converted to a hexadecimal string, making reading logs containing
* these IDs easier to follow. And since the return value is randomly selected
* it will help to differentiate between logs from different executions.
*/
/**
* Generates and returns a unique ID as a hexadecimal string.
*
* The returned ID is intended to be used in debug logging messages to help
* correlate log messages that may be spatially separated in the logs, but
* logically related. For example, a network connection could include the same
* "debug ID" string in all of its log messages to help trace a specific
* connection over time.
*
* @returns the 10-character generated ID (e.g. "0xa1b2c3d4").
*/
function __PRIVATE_generateUniqueDebugId() {
	return null === Kt ? Kt = function __PRIVATE_generateInitialUniqueDebugId() {
		return 268435456 + Math.round(2147483648 * Math.random());
	}() : Kt++, "0x" + Kt.toString(16);
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var $t = "RestConnection";
var Wt = {
	BatchGetDocuments: "batchGet",
	Commit: "commit",
	RunQuery: "runQuery",
	RunAggregationQuery: "runAggregationQuery",
	ExecutePipeline: "executePipeline"
};
/**
* Maps RPC names to the corresponding REST endpoint name.
*
* We use array notation to avoid mangling.
*/
/**
* Base class for all Rest-based connections to the backend (WebChannel and
* HTTP).
*/
var __PRIVATE_RestConnection = class {
	get En() {
		return false;
	}
	constructor(e) {
		this.databaseInfo = e, this.databaseId = e.databaseId;
		const t = e.ssl ? "https" : "http", n = encodeURIComponent(this.databaseId.projectId), r = encodeURIComponent(this.databaseId.database);
		this.hn = t + "://" + e.host, this.Tn = `projects/${n}/databases/${r}`, this.Pn = this.databaseId.database === Ke ? `project_id=${n}` : `project_id=${n}&database_id=${r}`;
	}
	In(e, t, n, r, i) {
		const s = __PRIVATE_generateUniqueDebugId(), _ = this.Rn(e, t.toUriEncodedString());
		__PRIVATE_logDebug($t, `Sending RPC '${e}' ${s}:`, _, n);
		const o = {
			"google-cloud-resource-prefix": this.Tn,
			"x-goog-request-params": this.Pn
		};
		this.An(o, r, i);
		const { host: a } = new URL(_), u = isCloudWorkstation(a);
		return this.Vn(e, _, o, n, u).then(((t) => (__PRIVATE_logDebug($t, `Received RPC '${e}' ${s}: `, t), t)), ((t) => {
			throw __PRIVATE_logWarn($t, `RPC '${e}' ${s} failed with error: `, t, "url: ", _, "request:", n), t;
		}));
	}
	fn(e, t, n, r, i, s) {
		return this.In(e, t, n, r, i);
	}
	/**
	* Modifies the headers for a request, adding any authorization token if
	* present and any additional headers for the request.
	*/ An(e, t, n) {
		if (e["X-Goog-Api-Client"] = function __PRIVATE_getGoogApiClientValue() {
			return "gl-js/ fire/" + xe;
		}(), e["Content-Type"] = "text/plain", this.databaseInfo.appId && (e["X-Firebase-GMPID"] = this.databaseInfo.appId), t && t.headers.forEach(((t, n) => e[n] = t)), n && n.headers.forEach(((t, n) => e[n] = t)), this.databaseInfo._customHeaders) for (const t of Object.keys(this.databaseInfo._customHeaders)) e[t] = this.databaseInfo._customHeaders[t];
	}
	Rn(e, t) {
		const n = Wt[e];
		let r = `${this.hn}/v1/${t}:${n}`;
		return this.databaseInfo.apiKey && (r = `${r}?key=${encodeURIComponent(this.databaseInfo.apiKey)}`), r;
	}
	/**
	* Closes and cleans up any resources associated with the connection. This
	* implementation is a no-op because there are no resources associated
	* with the RestConnection that need to be cleaned up.
	*/ terminate() {}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Provides a simple helper class that implements the Stream interface to
* bridge to other implementations that are streams but do not implement the
* interface. The stream callbacks are invoked with the callOn... methods.
*/ var __PRIVATE_StreamBridge = class {
	constructor(e) {
		this.dn = e.dn, this.mn = e.mn;
	}
	pn(e) {
		this.gn = e;
	}
	yn(e) {
		this.wn = e;
	}
	bn(e) {
		this.Sn = e;
	}
	onMessage(e) {
		this.xn = e;
	}
	close() {
		this.mn();
	}
	send(e) {
		this.dn(e);
	}
	vn() {
		this.gn();
	}
	Dn() {
		this.wn();
	}
	Cn(e) {
		this.Sn(e);
	}
	Fn(e) {
		this.xn(e);
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var Gt = "WebChannelConnection";
var __PRIVATE_unguardedEventListen = (e, t, n) => {
	e.listen(t, ((e) => {
		try {
			n(e);
		} catch (e) {
			setTimeout((() => {
				throw e;
			}), 0);
		}
	}));
};
var __PRIVATE_WebChannelConnection = class __PRIVATE_WebChannelConnection extends __PRIVATE_RestConnection {
	constructor(e) {
		super(e), this.On = [], this.forceLongPolling = e.forceLongPolling, this.autoDetectLongPolling = e.autoDetectLongPolling, this.useFetchStreams = e.useFetchStreams, this.longPollingOptions = e.longPollingOptions;
	}
	/**
	* Initialize STAT_EVENT listener once. Subsequent calls are a no-op.
	* getStatEventTarget() returns the same target every time.
	*/ static Mn() {
		if (!__PRIVATE_WebChannelConnection.Nn) __PRIVATE_unguardedEventListen(getStatEventTarget(), Event.STAT_EVENT, ((e) => {
			e.stat === Stat.PROXY ? __PRIVATE_logDebug(Gt, "STAT_EVENT: detected buffering proxy") : e.stat === Stat.NOPROXY && __PRIVATE_logDebug(Gt, "STAT_EVENT: detected no buffering proxy");
		})), __PRIVATE_WebChannelConnection.Nn = true;
	}
	Vn(t, n, r, i, s) {
		const _ = __PRIVATE_generateUniqueDebugId();
		return new Promise(((s, o) => {
			const a = new XhrIo();
			a.setWithCredentials(true), a.listenOnce(EventType.COMPLETE, (() => {
				try {
					switch (a.getLastErrorCode()) {
						case ErrorCode.NO_ERROR:
							const n = a.getResponseJson();
							__PRIVATE_logDebug(Gt, `XHR for RPC '${t}' ${_} received:`, JSON.stringify(n)), s(n);
							break;
						case ErrorCode.TIMEOUT:
							__PRIVATE_logDebug(Gt, `RPC '${t}' ${_} timed out`), o(new e(ta.DEADLINE_EXCEEDED, "Request time out"));
							break;
						case ErrorCode.HTTP_ERROR:
							const r = a.getStatus();
							if (__PRIVATE_logDebug(Gt, `RPC '${t}' ${_} failed with status:`, r, "response text:", a.getResponseText()), r > 0) {
								let t = a.getResponseJson();
								Array.isArray(t) && (t = t[0]);
								const n = t?.error;
								if (n && n.status && n.message) o(new e(function __PRIVATE_mapCodeFromHttpResponseErrorStatus(e) {
									const t = e.toLowerCase().replace(/_/g, "-");
									return Object.values(ta).indexOf(t) >= 0 ? t : ta.UNKNOWN;
								}(n.status), n.message));
								else o(new e(ta.UNKNOWN, "Server responded with status " + a.getStatus()));
							} else o(new e(ta.UNAVAILABLE, "Connection failed."));
							break;
						default: l(9055, {
							Bn: t,
							streamId: _,
							Ln: a.getLastErrorCode(),
							Un: a.getLastError()
						});
					}
				} finally {
					__PRIVATE_logDebug(Gt, `RPC '${t}' ${_} completed.`);
				}
			}));
			const u = JSON.stringify(i);
			__PRIVATE_logDebug(Gt, `RPC '${t}' ${_} sending request:`, i), a.send(n, "POST", u, r, 15);
		}));
	}
	kn(t, n, r) {
		const i = __PRIVATE_generateUniqueDebugId(), s = [
			this.hn,
			"/",
			"google.firestore.v1.Firestore",
			"/",
			t,
			"/channel"
		], _ = this.createWebChannelTransport(), o = {
			httpSessionIdParam: "gsessionid",
			initMessageHeaders: {},
			messageUrlParams: { database: `projects/${this.databaseId.projectId}/databases/${this.databaseId.database}` },
			sendRawJson: true,
			supportsCrossDomainXhr: true,
			internalChannelParams: { forwardChannelRequestTimeoutMs: 6e5 },
			forceLongPolling: this.forceLongPolling,
			detectBufferingProxy: this.autoDetectLongPolling
		}, a = this.longPollingOptions.timeoutSeconds;
		void 0 !== a && (o.longPollingTimeout = Math.round(1e3 * a)), this.useFetchStreams && (o.useFetchStreams = true), this.An(o.initMessageHeaders, n, r), o.encodeInitMessageHeaders = true;
		const u = s.join("");
		__PRIVATE_logDebug(Gt, `Creating RPC '${t}' stream ${i}: ${u}`, o);
		const c = _.createWebChannel(u, o);
		this.Qn(c);
		let l = false, E = false;
		const h = new __PRIVATE_StreamBridge({
			dn: (e) => {
				E ? __PRIVATE_logDebug(Gt, `Not sending because RPC '${t}' stream ${i} is closed:`, e) : (l || (__PRIVATE_logDebug(Gt, `Opening RPC '${t}' stream ${i} transport.`), c.open(), l = true), __PRIVATE_logDebug(Gt, `RPC '${t}' stream ${i} sending:`, e), c.send(e));
			},
			mn: () => c.close()
		});
		return __PRIVATE_unguardedEventListen(c, WebChannel.EventType.OPEN, (() => {
			E || (__PRIVATE_logDebug(Gt, `RPC '${t}' stream ${i} transport opened.`), h.vn());
		})), __PRIVATE_unguardedEventListen(c, WebChannel.EventType.CLOSE, (() => {
			E || (E = !0, __PRIVATE_logDebug(Gt, `RPC '${t}' stream ${i} transport closed`), h.Cn(), this.qn(c));
		})), __PRIVATE_unguardedEventListen(c, WebChannel.EventType.ERROR, ((n) => {
			E || (E = !0, __PRIVATE_logWarn(Gt, `RPC '${t}' stream ${i} transport errored. Name:`, n.name, "Message:", n.message), h.Cn(new e(ta.UNAVAILABLE, "The operation could not be completed")));
		})), __PRIVATE_unguardedEventListen(c, WebChannel.EventType.MESSAGE, ((n) => {
			if (!E) {
				const r = n.data[0];
				__PRIVATE_hardAssert(!!r, 16349);
				const s = r, _ = s?.error || s[0]?.error;
				if (_) {
					__PRIVATE_logDebug(Gt, `RPC '${t}' stream ${i} received error:`, _);
					const n = _.status;
					let r = function __PRIVATE_mapCodeFromRpcStatus(e) {
						const t = xt[e];
						if (void 0 !== t) return __PRIVATE_mapCodeFromRpcCode(t);
					}(n), s = _.message;
					"NOT_FOUND" === n && s.includes("database") && s.includes("does not exist") && s.includes(this.databaseId.database) && __PRIVATE_logWarn(`Database '${this.databaseId.database}' not found. Please check your project configuration.`), void 0 === r && (r = ta.INTERNAL, s = "Unknown error status: " + n + " with message " + _.message), E = !0, h.Cn(new e(r, s)), c.close();
				} else __PRIVATE_logDebug(Gt, `RPC '${t}' stream ${i} received:`, r), h.Fn(r);
			}
		})), __PRIVATE_WebChannelConnection.Mn(), setTimeout((() => {
			h.Dn();
		}), 0), h;
	}
	/**
	* Closes and cleans up any resources associated with the connection.
	*/ terminate() {
		this.On.forEach(((e) => e.close())), this.On = [];
	}
	/**
	* Add a WebChannel instance to the collection of open instances.
	* @param webChannel
	*/ Qn(e) {
		this.On.push(e);
	}
	/**
	* Remove a WebChannel instance from the collection of open instances.
	* @param webChannel
	*/ qn(e) {
		this.On = this.On.filter(((t) => t === e));
	}
	/**
	* Modifies the headers for a request, adding the api key if present,
	* and then calling super.modifyHeadersForRequest
	*/ An(e, t, n) {
		super.An(e, t, n), this.databaseInfo.apiKey && (e["x-goog-api-key"] = this.databaseInfo.apiKey);
	}
	/**
	* Wrapped for mocking.
	* @protected
	*/ createWebChannelTransport() {
		return createWebChannelTransport();
	}
};
/**
* Track if the STAT_EVENT listener has been initialized.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/** Initializes the WebChannelConnection for the browser. */
function __PRIVATE_newConnection(e) {
	return new __PRIVATE_WebChannelConnection(e);
}
/** Return the Platform-specific connectivity monitor. */ __PRIVATE_WebChannelConnection.Nn = false;
/**
* A helper for running delayed tasks following an exponential backoff curve
* between attempts.
*
* Each delay is made up of a "base" delay which follows the exponential
* backoff curve, and a +/- 50% "jitter" that is calculated and added to the
* base delay. This prevents clients from accidentally synchronizing their
* delays causing spikes of load to the backend.
*/
var __PRIVATE_ExponentialBackoff = class {
	constructor(e, t, n = 1e3, r = 1.5, i = 6e4) {
		this.Kn = e, this.timerId = t, this.$n = n, this.Wn = r, this.Gn = i, this.jn = 0, this.zn = null, this.Hn = Date.now(), this.reset();
	}
	/**
	* Resets the backoff delay.
	*
	* The very next backoffAndWait() will have no delay. If it is called again
	* (i.e. due to an error), initialDelayMs (plus jitter) will be used, and
	* subsequent ones will increase according to the backoffFactor.
	*/ reset() {
		this.jn = 0;
	}
	/**
	* Resets the backoff delay to the maximum delay (e.g. for use after a
	* RESOURCE_EXHAUSTED error).
	*/ Jn() {
		this.jn = this.Gn;
	}
	/**
	* Returns a promise that resolves after currentDelayMs, and increases the
	* delay for any subsequent attempts. If there was a pending backoff operation
	* already, it will be canceled.
	*/ Yn(e) {
		this.cancel();
		const t = Math.floor(this.jn + this.Zn()), n = Math.max(0, Date.now() - this.Hn), r = Math.max(0, t - n);
		r > 0 && __PRIVATE_logDebug("ExponentialBackoff", `Backing off for ${r} ms (base delay: ${this.jn} ms, delay with jitter: ${t} ms, last attempt: ${n} ms ago)`), this.zn = this.Kn.enqueueAfterDelay(this.timerId, r, (() => (this.Hn = Date.now(), e()))), this.jn *= this.Wn, this.jn < this.$n && (this.jn = this.$n), this.jn > this.Gn && (this.jn = this.Gn);
	}
	Xn() {
		null !== this.zn && (this.zn.skipDelay(), this.zn = null);
	}
	cancel() {
		null !== this.zn && (this.zn.cancel(), this.zn = null);
	}
	/** Returns a random value in the range [-currentBaseMs/2, currentBaseMs/2] */ Zn() {
		return (Math.random() - .5) * this.jn;
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var jt = "PersistentStream";
/** The time a stream stays open after it is marked idle. */
/**
* A PersistentStream is an abstract base class that represents a streaming RPC
* to the Firestore backend. It's built on top of the connections own support
* for streaming RPCs, and adds several critical features for our clients:
*
*   - Exponential backoff on failure
*   - Authentication via CredentialsProvider
*   - Dispatching all callbacks into the shared worker queue
*   - Closing idle streams after 60 seconds of inactivity
*
* Subclasses of PersistentStream implement serialization of models to and
* from the JSON representation of the protocol buffers for a specific
* streaming RPC.
*
* ## Starting and Stopping
*
* Streaming RPCs are stateful and need to be start()ed before messages can
* be sent and received. The PersistentStream will call the onOpen() function
* of the listener once the stream is ready to accept requests.
*
* Should a start() fail, PersistentStream will call the registered onClose()
* listener with a FirestoreError indicating what went wrong.
*
* A PersistentStream can be started and stopped repeatedly.
*
* Generic types:
*  SendType: The type of the outgoing message of the underlying
*    connection stream
*  ReceiveType: The type of the incoming message of the underlying
*    connection stream
*  ListenerType: The type of the listener that will be used for callbacks
*/
var __PRIVATE_PersistentStream = class {
	constructor(e, t, n, r, i, s, _, o) {
		this.Kn = e, this.er = n, this.tr = r, this.connection = i, this.authCredentialsProvider = s, this.appCheckCredentialsProvider = _, this.listener = o, this.state = 0, this.nr = 0, this.rr = null, this.ir = null, this.stream = null, this.sr = 0, this._r = new __PRIVATE_ExponentialBackoff(e, t);
	}
	/**
	* Returns true if start() has been called and no error has occurred. True
	* indicates the stream is open or in the process of opening (which
	* encompasses respecting backoff, getting auth tokens, and starting the
	* actual RPC). Use isOpen() to determine if the stream is open and ready for
	* outbound requests.
	*/ ar() {
		return 1 === this.state || 5 === this.state || this.ur();
	}
	/**
	* Returns true if the underlying RPC is open (the onOpen() listener has been
	* called) and the stream is ready for outbound requests.
	*/ ur() {
		return 2 === this.state || 3 === this.state;
	}
	/**
	* Starts the RPC. Only allowed if isStarted() returns false. The stream is
	* not immediately ready for use: onOpen() will be invoked when the RPC is
	* ready for outbound requests, at which point isOpen() will return true.
	*
	* When start returns, isStarted() will return true.
	*/ start() {
		this.sr = 0, 4 !== this.state ? this.auth() : this.cr();
	}
	/**
	* Stops the RPC. This call is idempotent and allowed regardless of the
	* current isStarted() state.
	*
	* When stop returns, isStarted() and isOpen() will both return false.
	*/ async stop() {
		this.ar() && await this.close(0);
	}
	/**
	* After an error the stream will usually back off on the next attempt to
	* start it. If the error warrants an immediate restart of the stream, the
	* sender can use this to indicate that the receiver should not back off.
	*
	* Each error will call the onClose() listener. That function can decide to
	* inhibit backoff if required.
	*/ lr() {
		this.state = 0, this._r.reset();
	}
	/**
	* Marks this stream as idle. If no further actions are performed on the
	* stream for one minute, the stream will automatically close itself and
	* notify the stream's onClose() handler with Status.OK. The stream will then
	* be in a !isStarted() state, requiring the caller to start the stream again
	* before further use.
	*
	* Only streams that are in state 'Open' can be marked idle, as all other
	* states imply pending network operations.
	*/ Er() {
		this.ur() && null === this.rr && (this.rr = this.Kn.enqueueAfterDelay(this.er, 6e4, (() => this.hr())));
	}
	/** Sends a message to the underlying stream. */ Tr(e) {
		this.Pr(), this.stream.send(e);
	}
	/** Called by the idle timer when the stream should close due to inactivity. */ async hr() {
		if (this.ur()) return this.close(0);
	}
	/** Marks the stream as active again. */ Pr() {
		this.rr && (this.rr.cancel(), this.rr = null);
	}
	/** Cancels the health check delayed operation. */ Ir() {
		this.ir && (this.ir.cancel(), this.ir = null);
	}
	/**
	* Closes the stream and cleans up as necessary:
	*
	* * closes the underlying GRPC stream;
	* * calls the onClose handler with the given 'error';
	* * sets internal stream state to 'finalState';
	* * adjusts the backoff timer based on the error
	*
	* A new stream can be opened by calling start().
	*
	* @param finalState - the intended state of the stream after closing.
	* @param error - the error the connection was closed with.
	*/ async close(e, t) {
		this.Pr(), this.Ir(), this._r.cancel(), this.nr++, 4 !== e ? this._r.reset() : t && t.code === ta.RESOURCE_EXHAUSTED ? (__PRIVATE_logError(t.toString()), __PRIVATE_logError("Using maximum backoff delay to prevent overloading the backend."), this._r.Jn()) : t && t.code === ta.UNAUTHENTICATED && 3 !== this.state && (this.authCredentialsProvider.invalidateToken(), this.appCheckCredentialsProvider.invalidateToken()), null !== this.stream && (this.Rr(), this.stream.close(), this.stream = null), this.state = e, await this.listener.bn(t);
	}
	/**
	* Can be overridden to perform additional cleanup before the stream is closed.
	* Calling super.tearDown() is not required.
	*/ Rr() {}
	auth() {
		this.state = 1;
		const t = this.Ar(this.nr), n = this.nr;
		Promise.all([this.authCredentialsProvider.getToken(), this.appCheckCredentialsProvider.getToken()]).then((([e, t]) => {
			this.nr === n && this.Vr(e, t);
		}), ((n) => {
			t((() => {
				const t = new e(ta.UNKNOWN, "Fetching auth token failed: " + n.message);
				return this.dr(t);
			}));
		}));
	}
	Vr(e, t) {
		const n = this.Ar(this.nr);
		this.stream = this.mr(e, t), this.stream.pn((() => {
			n((() => this.listener.pn()));
		})), this.stream.yn((() => {
			n((() => (this.state = 2, this.ir = this.Kn.enqueueAfterDelay(this.tr, 1e4, (() => (this.ur() && (this.state = 3), Promise.resolve()))), this.listener.yn())));
		})), this.stream.bn(((e) => {
			n((() => this.dr(e)));
		})), this.stream.onMessage(((e) => {
			n((() => 1 == ++this.sr ? this.pr(e) : this.onNext(e)));
		}));
	}
	cr() {
		this.state = 5, this._r.Yn((async () => {
			this.state = 0, this.start();
		}));
	}
	dr(e) {
		return __PRIVATE_logDebug(jt, `close with error: ${e}`), this.stream = null, this.close(4, e);
	}
	/**
	* Returns a "dispatcher" function that dispatches operations onto the
	* AsyncQueue but only runs them if closeCount remains unchanged. This allows
	* us to turn auth / stream callbacks into no-ops if the stream is closed /
	* re-opened, etc.
	*/ Ar(e) {
		return (t) => {
			this.Kn.enqueueAndForget((() => this.nr === e ? t() : (__PRIVATE_logDebug(jt, "stream callback skipped by getCloseGuardedDispatcher."), Promise.resolve())));
		};
	}
};
/**
* A PersistentStream that implements the Listen RPC.
*
* Once the Listen stream has called the onOpen() listener, any number of
* listen() and unlisten() calls can be made to control what changes will be
* sent from the server for ListenResponses.
*/ var __PRIVATE_PersistentListenStream = class extends __PRIVATE_PersistentStream {
	constructor(e, t, n, r, i, s) {
		super(e, "listen_stream_connection_backoff", "listen_stream_idle", "health_check_timeout", t, n, r, s), this.serializer = i;
	}
	mr(e, t) {
		return this.connection.kn("Listen", e, t);
	}
	pr(e) {
		return this.onNext(e);
	}
	onNext(e) {
		this._r.reset();
		const t = __PRIVATE_fromWatchChange(this.serializer, e), n = function __PRIVATE_versionFromListenResponse(e) {
			if (!("targetChange" in e)) return SnapshotVersion.min();
			const t = e.targetChange;
			return t.targetIds && t.targetIds.length ? SnapshotVersion.min() : t.readTime ? __PRIVATE_fromVersion(t.readTime) : SnapshotVersion.min();
		}(e);
		return this.listener.gr(t, n);
	}
	/**
	* Registers interest in the results of the given target. If the target
	* includes a resumeToken it will be included in the request. Results that
	* affect the target will be streamed back as WatchChange messages that
	* reference the targetId.
	*/ yr(e) {
		const t = {};
		t.database = __PRIVATE_getEncodedDatabaseId(this.serializer), t.addTarget = function __PRIVATE_toTarget(e, t) {
			let n;
			const r = t.target;
			if (n = __PRIVATE_targetIsPipelineTarget(r) ? { pipelineQuery: __PRIVATE_toPipelineTarget(e, r) } : __PRIVATE_targetIsDocumentTarget(r) ? { documents: __PRIVATE_toDocumentsTarget(e, r) } : { query: __PRIVATE_toQueryTarget(e, r).Lt }, n.targetId = t.targetId, t.resumeToken.approximateByteSize() > 0) {
				n.resumeToken = __PRIVATE_toBytes(e, t.resumeToken);
				const r = __PRIVATE_toInt32Proto(e, t.expectedCount);
				null !== r && (n.expectedCount = r);
			} else if (t.snapshotVersion.compareTo(SnapshotVersion.min()) > 0) {
				n.readTime = toTimestamp(e, t.snapshotVersion.toTimestamp());
				const r = __PRIVATE_toInt32Proto(e, t.expectedCount);
				null !== r && (n.expectedCount = r);
			}
			return n;
		}(this.serializer, e);
		const n = __PRIVATE_toListenRequestLabels(this.serializer, e);
		n && (t.labels = n), this.Tr(t);
	}
	/**
	* Unregisters interest in the results of the target associated with the
	* given targetId.
	*/ wr(e) {
		const t = {};
		t.database = __PRIVATE_getEncodedDatabaseId(this.serializer), t.removeTarget = e, this.Tr(t);
	}
};
/**
* A Stream that implements the Write RPC.
*
* The Write RPC requires the caller to maintain special streamToken
* state in between calls, to help the server understand which responses the
* client has processed by the time the next request is made. Every response
* will contain a streamToken; this value must be passed to the next
* request.
*
* After calling start() on this stream, the next request must be a handshake,
* containing whatever streamToken is on hand. Once a response to this
* request is received, all pending mutations may be submitted. When
* submitting multiple batches of mutations at the same time, it's
* okay to use the same streamToken for the calls to writeMutations.
*
* TODO(b/33271235): Use proto types
*/ var __PRIVATE_PersistentWriteStream = class extends __PRIVATE_PersistentStream {
	constructor(e, t, n, r, i, s) {
		super(e, "write_stream_connection_backoff", "write_stream_idle", "health_check_timeout", t, n, r, s), this.serializer = i;
	}
	/**
	* Tracks whether or not a handshake has been successfully exchanged and
	* the stream is ready to accept mutations.
	*/ get br() {
		return this.sr > 0;
	}
	start() {
		this.lastStreamToken = void 0, super.start();
	}
	Rr() {
		this.br && this.Sr([]);
	}
	mr(e, t) {
		return this.connection.kn("Write", e, t);
	}
	pr(e) {
		return __PRIVATE_hardAssert(!!e.streamToken, 31322), this.lastStreamToken = e.streamToken, __PRIVATE_hardAssert(!e.writeResults || 0 === e.writeResults.length, 55816), this.listener.vr();
	}
	onNext(e) {
		__PRIVATE_hardAssert(!!e.streamToken, 12678), this.lastStreamToken = e.streamToken, this._r.reset();
		const t = __PRIVATE_fromWriteResults(e.writeResults, e.commitTime), n = __PRIVATE_fromVersion(e.commitTime);
		return this.listener.Dr(n, t);
	}
	/**
	* Sends an initial streamToken to the server, performing the handshake
	* required to make the StreamingWrite RPC work. Subsequent
	* calls should wait until onHandshakeComplete was called.
	*/ Cr() {
		const e = {};
		e.database = __PRIVATE_getEncodedDatabaseId(this.serializer), this.Tr(e);
	}
	/** Sends a group of mutations to the Firestore backend to apply. */ Sr(e) {
		const t = {
			streamToken: this.lastStreamToken,
			writes: e.map(((e) => toMutation(this.serializer, e)))
		};
		this.Tr(t);
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Datastore and its related methods are a wrapper around the external Google
* Cloud Datastore grpc API, which provides an interface that is more convenient
* for the rest of the client SDK architecture to consume.
*/ var Datastore = class {};
/**
* An implementation of Datastore that exposes additional state for internal
* consumption.
*/ var __PRIVATE_DatastoreImpl = class extends Datastore {
	constructor(e, t, n, r) {
		super(), this.authCredentials = e, this.appCheckCredentials = t, this.connection = n, this.serializer = r, this.Fr = false;
	}
	Or() {
		if (this.Fr) throw new e(ta.FAILED_PRECONDITION, "The client has already been terminated.");
	}
	/** Invokes the provided RPC with auth and AppCheck tokens. */ In(t, n, r, i) {
		return this.Or(), Promise.all([this.authCredentials.getToken(), this.appCheckCredentials.getToken()]).then((([e, s]) => this.connection.In(t, __PRIVATE_toResourcePath(n, r), i, e, s))).catch(((t) => {
			throw "FirebaseError" === t.name ? (t.code === ta.UNAUTHENTICATED && (this.authCredentials.invalidateToken(), this.appCheckCredentials.invalidateToken()), t) : new e(ta.UNKNOWN, t.toString());
		}));
	}
	/** Invokes the provided RPC with streamed results with auth and AppCheck tokens. */ fn(t, n, r, i, s) {
		return this.Or(), Promise.all([this.authCredentials.getToken(), this.appCheckCredentials.getToken()]).then((([e, _]) => this.connection.fn(t, __PRIVATE_toResourcePath(n, r), i, e, _, s))).catch(((t) => {
			throw "FirebaseError" === t.name ? (t.code === ta.UNAUTHENTICATED && (this.authCredentials.invalidateToken(), this.appCheckCredentials.invalidateToken()), t) : new e(ta.UNKNOWN, t.toString());
		}));
	}
	terminate() {
		this.Fr = true, this.connection.terminate();
	}
};
function __PRIVATE_newDatastore(e, t, n, r) {
	return new __PRIVATE_DatastoreImpl(e, t, n, r);
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var zt = "ComponentProvider";
var Ht = /* @__PURE__ */ new Map();
/**
* An instance map that ensures only one Datastore exists per Firestore
* instance.
*/ function __PRIVATE_makeDatabaseInfo(e, t, n, r, i) {
	return new DatabaseInfo(e, t, n, i.host, i.ssl, i.experimentalForceLongPolling, i.experimentalAutoDetectLongPolling, __PRIVATE_cloneLongPollingOptions(i.experimentalLongPollingOptions), i.useFetchStreams, i.isUsingEmulator, r, i._customHeaders, i.grpcFlowControlWindow);
}
/**
* @license
* Copyright 2018 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var Jt = {
	didRun: false,
	sequenceNumbersCollected: 0,
	targetsRemoved: 0,
	documentsRemoved: 0
};
var Yt = 41943040;
var LruParams = class LruParams {
	static withCacheSize(e) {
		return new LruParams(e, LruParams.DEFAULT_COLLECTION_PERCENTILE, LruParams.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT);
	}
	constructor(e, t, n) {
		this.cacheSizeCollectionThreshold = e, this.percentileToCollect = t, this.maximumSequenceNumbersToCollect = n;
	}
};
LruParams.DEFAULT_COLLECTION_PERCENTILE = 10, LruParams.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT = 1e3, LruParams.DEFAULT = new LruParams(Yt, LruParams.DEFAULT_COLLECTION_PERCENTILE, LruParams.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT), LruParams.DISABLED = new LruParams(-1, 0, 0);
/**
* @license
* Copyright 2018 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* `ListenSequence` is a monotonic sequence. It is initialized with a minimum value to
* exceed. All subsequent calls to next will return increasing values. If provided with a
* `SequenceNumberSyncer`, it will additionally bump its next value when told of a new value, as
* well as write out sequence numbers that it produces via `next()`.
*/
var __PRIVATE_ListenSequence = class {
	constructor(e, t) {
		this.previousValue = e, t && (t.sequenceNumberHandler = (e) => this.Mr(e), this.Nr = (e) => t.writeSequenceNumber(e));
	}
	Mr(e) {
		return this.previousValue = Math.max(e, this.previousValue), this.previousValue;
	}
	next() {
		const e = ++this.previousValue;
		return this.Nr && this.Nr(e), e;
	}
};
__PRIVATE_ListenSequence.Br = -1;
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var Zt = "The current tab is not in the required state to perform this operation. It might be necessary to refresh the browser tab.";
/**
* A base class representing a persistence transaction, encapsulating both the
* transaction's sequence numbers as well as a list of onCommitted listeners.
*
* When you call Persistence.runTransaction(), it will create a transaction and
* pass it to your callback. You then pass it to any method that operates
* on persistence.
*/ var PersistenceTransaction = class {
	constructor() {
		this.onCommittedListeners = [];
	}
	addOnCommittedListener(e) {
		this.onCommittedListeners.push(e);
	}
	raiseOnCommittedEvent() {
		this.onCommittedListeners.forEach(((e) => e()));
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Verifies the error thrown by a LocalStore operation. If a LocalStore
* operation fails because the primary lease has been taken by another client,
* we ignore the error (the persistence layer will immediately call
* `applyPrimaryLease` to propagate the primary state change). All other errors
* are re-thrown.
*
* @param err - An error returned by a LocalStore operation.
* @returns A Promise that resolves after we recovered, or the original error.
*/ async function __PRIVATE_ignoreIfPrimaryLeaseLoss(e) {
	if (e.code !== ta.FAILED_PRECONDITION || e.message !== Zt) throw e;
	__PRIVATE_logDebug("LocalStore", "Unexpectedly lost primary lease");
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* PersistencePromise is essentially a re-implementation of Promise except
* it has a .next() method instead of .then() and .next() and .catch() callbacks
* are executed synchronously when a PersistencePromise resolves rather than
* asynchronously (Promise implementations use setImmediate() or similar).
*
* This is necessary to interoperate with IndexedDB which will automatically
* commit transactions if control is returned to the event loop without
* synchronously initiating another operation on the transaction.
*
* NOTE: .then() and .catch() only allow a single consumer, unlike normal
* Promises.
*/ var PersistencePromise = class PersistencePromise {
	constructor(e) {
		this.nextCallback = null, this.catchCallback = null, this.result = void 0, this.error = void 0, this.isDone = false, this.callbackAttached = false, e(((e) => {
			this.isDone = true, this.result = e, this.nextCallback && this.nextCallback(e);
		}), ((e) => {
			this.isDone = true, this.error = e, this.catchCallback && this.catchCallback(e);
		}));
	}
	catch(e) {
		return this.next(void 0, e);
	}
	next(e, t) {
		return this.callbackAttached && l(59440), this.callbackAttached = true, this.isDone ? this.error ? this.wrapFailure(t, this.error) : this.wrapSuccess(e, this.result) : new PersistencePromise(((n, r) => {
			this.nextCallback = (t) => {
				this.wrapSuccess(e, t).next(n, r);
			}, this.catchCallback = (e) => {
				this.wrapFailure(t, e).next(n, r);
			};
		}));
	}
	toPromise() {
		return new Promise(((e, t) => {
			this.next(e, t);
		}));
	}
	wrapUserFunction(e) {
		try {
			const t = e();
			return t instanceof PersistencePromise ? t : PersistencePromise.resolve(t);
		} catch (e) {
			return PersistencePromise.reject(e);
		}
	}
	wrapSuccess(e, t) {
		return e ? this.wrapUserFunction((() => e(t))) : PersistencePromise.resolve(t);
	}
	wrapFailure(e, t) {
		return e ? this.wrapUserFunction((() => e(t))) : PersistencePromise.reject(t);
	}
	static resolve(e) {
		return new PersistencePromise(((t, n) => {
			t(e);
		}));
	}
	static reject(e) {
		return new PersistencePromise(((t, n) => {
			n(e);
		}));
	}
	static waitFor(e) {
		return new PersistencePromise(((t, n) => {
			let r = 0, i = 0, s = false;
			e.forEach(((e) => {
				++r, e.next((() => {
					++i, s && i === r && t();
				}), ((e) => n(e)));
			})), s = true, i === r && t();
		}));
	}
	/**
	* Given an array of predicate functions that asynchronously evaluate to a
	* boolean, implements a short-circuiting `or` between the results. Predicates
	* will be evaluated until one of them returns `true`, then stop. The final
	* result will be whether any of them returned `true`.
	*/ static or(e) {
		let t = PersistencePromise.resolve(false);
		for (const n of e) t = t.next(((e) => e ? PersistencePromise.resolve(e) : n()));
		return t;
	}
	static forEach(e, t) {
		const n = [];
		return e.forEach(((e, r) => {
			n.push(t.call(this, e, r));
		})), this.waitFor(n);
	}
	/**
	* Concurrently map all array elements through asynchronous function.
	*/ static mapArray(e, t) {
		return new PersistencePromise(((n, r) => {
			const i = e.length, s = new Array(i);
			let _ = 0;
			for (let o = 0; o < i; o++) {
				const a = o;
				t(e[a]).next(((e) => {
					s[a] = e, ++_, _ === i && n(s);
				}), ((e) => r(e)));
			}
		}));
	}
	/**
	* An alternative to recursive PersistencePromise calls, that avoids
	* potential memory problems from unbounded chains of promises.
	*
	* The `action` will be called repeatedly while `condition` is true.
	*/ static doWhile(e, t) {
		return new PersistencePromise(((n, r) => {
			const process = () => {
				true === e() ? t().next((() => {
					process();
				}), r) : n();
			};
			process();
		}));
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/** Parse User Agent to determine Android version. Returns -1 if not found. */ function __PRIVATE_getAndroidVersion(e) {
	const t = e.match(/Android ([\d.]+)/i), n = t ? t[1].split(".").slice(0, 2).join(".") : "-1";
	return Number(n);
}
/** Verifies whether `e` is an IndexedDbTransactionError. */ function __PRIVATE_isIndexedDbTransactionError(e) {
	return "IndexedDbTransactionError" === e.name;
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var tn = "LruGarbageCollector";
var nn = 1048576;
function __PRIVATE_bufferEntryComparator([e, t], [n, r]) {
	const i = __PRIVATE_primitiveComparator(e, n);
	return 0 === i ? __PRIVATE_primitiveComparator(t, r) : i;
}
/**
* Used to calculate the nth sequence number. Keeps a rolling buffer of the
* lowest n values passed to `addElement`, and finally reports the largest of
* them in `maxValue`.
*/ var __PRIVATE_RollingSequenceNumberBuffer = class {
	constructor(e) {
		this.ai = e, this.buffer = new SortedSet(__PRIVATE_bufferEntryComparator), this.ui = 0;
	}
	ci() {
		return ++this.ui;
	}
	li(e) {
		const t = [e, this.ci()];
		if (this.buffer.size < this.ai) this.buffer = this.buffer.add(t);
		else {
			const e = this.buffer.last();
			__PRIVATE_bufferEntryComparator(t, e) < 0 && (this.buffer = this.buffer.delete(e).add(t));
		}
	}
	get maxValue() {
		return this.buffer.last()[0];
	}
};
/**
* This class is responsible for the scheduling of LRU garbage collection. It handles checking
* whether or not GC is enabled, as well as which delay to use before the next run.
*/ var __PRIVATE_LruScheduler = class {
	constructor(e, t, n) {
		this.garbageCollector = e, this.asyncQueue = t, this.localStore = n, this.Ei = null;
	}
	start() {
		-1 !== this.garbageCollector.params.cacheSizeCollectionThreshold && this.hi(6e4);
	}
	stop() {
		this.Ei && (this.Ei.cancel(), this.Ei = null);
	}
	get started() {
		return null !== this.Ei;
	}
	hi(e) {
		__PRIVATE_logDebug(tn, `Garbage collection scheduled in ${e}ms`), this.Ei = this.asyncQueue.enqueueAfterDelay("lru_garbage_collection", e, (async () => {
			this.Ei = null;
			try {
				await this.localStore.collectGarbage(this.garbageCollector);
			} catch (e) {
				__PRIVATE_isIndexedDbTransactionError(e) ? __PRIVATE_logDebug(tn, "Ignoring IndexedDB error during garbage collection: ", e) : await __PRIVATE_ignoreIfPrimaryLeaseLoss(e);
			}
			await this.hi(3e5);
		}));
	}
};
/**
* Implements the steps for LRU garbage collection.
*/ var __PRIVATE_LruGarbageCollectorImpl = class {
	constructor(e, t) {
		this.Ti = e, this.params = t;
	}
	calculateTargetCount(e, t) {
		return this.Ti.Pi(e).next(((e) => Math.floor(t / 100 * e)));
	}
	nthSequenceNumber(e, t) {
		if (0 === t) return PersistencePromise.resolve(__PRIVATE_ListenSequence.Br);
		const n = new __PRIVATE_RollingSequenceNumberBuffer(t);
		return this.Ti.forEachTarget(e, ((e) => n.li(e.sequenceNumber))).next((() => this.Ti.Ii(e, ((e) => n.li(e))))).next((() => n.maxValue));
	}
	removeTargets(e, t, n) {
		return this.Ti.removeTargets(e, t, n);
	}
	removeOrphanedDocuments(e, t) {
		return this.Ti.removeOrphanedDocuments(e, t);
	}
	collect(e, t) {
		return -1 === this.params.cacheSizeCollectionThreshold ? (__PRIVATE_logDebug("LruGarbageCollector", "Garbage collection skipped; disabled"), PersistencePromise.resolve(Jt)) : this.getCacheSize(e).next(((n) => n < this.params.cacheSizeCollectionThreshold ? (__PRIVATE_logDebug("LruGarbageCollector", `Garbage collection skipped; Cache size ${n} is lower than threshold ${this.params.cacheSizeCollectionThreshold}`), Jt) : this.Ri(e, t)));
	}
	getCacheSize(e) {
		return this.Ti.getCacheSize(e);
	}
	Ri(e, t) {
		let n, r, i, s, _, o, a;
		const u = Date.now();
		return this.calculateTargetCount(e, this.params.percentileToCollect).next(((t) => (t > this.params.maximumSequenceNumbersToCollect ? (__PRIVATE_logDebug("LruGarbageCollector", `Capping sequence numbers to collect down to the maximum of ${this.params.maximumSequenceNumbersToCollect} from ${t}`), r = this.params.maximumSequenceNumbersToCollect) : r = t, s = Date.now(), this.nthSequenceNumber(e, r)))).next(((r) => (n = r, _ = Date.now(), this.removeTargets(e, n, t)))).next(((t) => (i = t, o = Date.now(), this.removeOrphanedDocuments(e, n)))).next(((e) => {
			if (a = Date.now(), __PRIVATE_getLogLevel() <= LogLevel.DEBUG) __PRIVATE_logDebug("LruGarbageCollector", `LRU Garbage Collection\n\tCounted targets in ${s - u}ms\n\tDetermined least recently used ${r} in ` + (_ - s) + `ms
\tRemoved ${i} targets in ` + (o - _) + `ms
\tRemoved ${e} documents in ` + (a - o) + `ms
Total Duration: ${a - u}ms`);
			return PersistencePromise.resolve({
				didRun: true,
				sequenceNumbersCollected: r,
				targetsRemoved: i,
				documentsRemoved: e
			});
		}));
	}
};
function __PRIVATE_newLruGarbageCollector(e, t) {
	return new __PRIVATE_LruGarbageCollectorImpl(e, t);
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var rn = "firestore.googleapis.com";
var sn = true;
/**
* A concrete type describing all the values that can be applied via a
* user-supplied `FirestoreSettings` object. This is a separate type so that
* defaults can be supplied and the value can be checked for equality.
*/
var FirestoreSettingsImpl = class {
	constructor(t) {
		if (void 0 === t.host) {
			if (void 0 !== t.ssl) throw new e(ta.INVALID_ARGUMENT, "Can't provide ssl option if host option is not set");
			this.host = rn, this.ssl = sn;
		} else this.host = t.host, this.ssl = t.ssl ?? sn;
		if (this.isUsingEmulator = void 0 !== t.emulatorOptions, this.credentials = t.credentials, this.ignoreUndefinedProperties = !!t.ignoreUndefinedProperties, this.localCache = t.localCache, t._customHeaders && (this._customHeaders = { ...t._customHeaders }), void 0 === t.cacheSizeBytes) this.cacheSizeBytes = Yt;
		else {
			if (-1 !== t.cacheSizeBytes && t.cacheSizeBytes < nn) throw new e(ta.INVALID_ARGUMENT, "cacheSizeBytes must be at least 1048576");
			this.cacheSizeBytes = t.cacheSizeBytes;
		}
		if (__PRIVATE_validateIsNotUsedTogether("experimentalForceLongPolling", t.experimentalForceLongPolling, "experimentalAutoDetectLongPolling", t.experimentalAutoDetectLongPolling), this.experimentalForceLongPolling = !!t.experimentalForceLongPolling, this.experimentalForceLongPolling ? this.experimentalAutoDetectLongPolling = false : void 0 === t.experimentalAutoDetectLongPolling ? this.experimentalAutoDetectLongPolling = true : this.experimentalAutoDetectLongPolling = !!t.experimentalAutoDetectLongPolling, this.experimentalLongPollingOptions = __PRIVATE_cloneLongPollingOptions(t.experimentalLongPollingOptions ?? {}), function __PRIVATE_validateLongPollingOptions(t) {
			if (void 0 !== t.timeoutSeconds) {
				if (isNaN(t.timeoutSeconds)) throw new e(ta.INVALID_ARGUMENT, `invalid long polling timeout: ${t.timeoutSeconds} (must not be NaN)`);
				if (t.timeoutSeconds < 5) throw new e(ta.INVALID_ARGUMENT, `invalid long polling timeout: ${t.timeoutSeconds} (minimum allowed value is 5)`);
				if (t.timeoutSeconds > 30) throw new e(ta.INVALID_ARGUMENT, `invalid long polling timeout: ${t.timeoutSeconds} (maximum allowed value is 30)`);
			}
		}(this.experimentalLongPollingOptions), this.useFetchStreams = !!t.useFetchStreams, void 0 !== t.grpcFlowControlWindow) {
			/**
			* @license
			* Copyright 2020 Google LLC
			*
			* Licensed under the Apache License, Version 2.0 (the "License");
			* you may not use this file except in compliance with the License.
			* You may obtain a copy of the License at
			*
			*   http://www.apache.org/licenses/LICENSE-2.0
			*
			* Unless required by applicable law or agreed to in writing, software
			* distributed under the License is distributed on an "AS IS" BASIS,
			* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
			* See the License for the specific language governing permissions and
			* limitations under the License.
			*/
			if ("number" != typeof t.grpcFlowControlWindow || t.grpcFlowControlWindow <= 0 || t.grpcFlowControlWindow > 2147483647 || !Number.isInteger(t.grpcFlowControlWindow)) throw new e(ta.INVALID_ARGUMENT, "grpcFlowControlWindow must be a positive integer and cannot exceed 2147483647");
			this.grpcFlowControlWindow = t.grpcFlowControlWindow;
		}
	}
	isEqual(e) {
		return this.host === e.host && this.ssl === e.ssl && this.credentials === e.credentials && this.cacheSizeBytes === e.cacheSizeBytes && this.experimentalForceLongPolling === e.experimentalForceLongPolling && this.experimentalAutoDetectLongPolling === e.experimentalAutoDetectLongPolling && function __PRIVATE_longPollingOptionsEqual(e, t) {
			/**
			* @license
			* Copyright 2023 Google LLC
			*
			* Licensed under the Apache License, Version 2.0 (the "License");
			* you may not use this file except in compliance with the License.
			* You may obtain a copy of the License at
			*
			*   http://www.apache.org/licenses/LICENSE-2.0
			*
			* Unless required by applicable law or agreed to in writing, software
			* distributed under the License is distributed on an "AS IS" BASIS,
			* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
			* See the License for the specific language governing permissions and
			* limitations under the License.
			*/
			return e.timeoutSeconds === t.timeoutSeconds;
		}(this.experimentalLongPollingOptions, e.experimentalLongPollingOptions) && this.ignoreUndefinedProperties === e.ignoreUndefinedProperties && this.useFetchStreams === e.useFetchStreams && this.grpcFlowControlWindow === e.grpcFlowControlWindow && function __PRIVATE_customHeadersEqual(e, t) {
			if (e === t) return true;
			if (!e || !t) return false;
			const n = Object.keys(e), r = Object.keys(t);
			if (n.length !== r.length) return false;
			for (const r of n) if (e[r] !== t[r]) return false;
			return true;
		}(this._customHeaders, e._customHeaders);
	}
};
var _n = class Firestore {
	/** @hideconstructor */
	constructor(e, t, n, r) {
		this._authCredentials = e, this._appCheckCredentials = t, this._databaseId = n, this._app = r, this.type = "firestore-lite", this._persistenceKey = "(lite)", this._settings = new FirestoreSettingsImpl({}), this._settingsFrozen = false, this._emulatorOptions = {}, this._terminateTask = "notTerminated";
	}
	/**
	* The {@link @firebase/app#FirebaseApp} associated with this `Firestore` service
	* instance.
	*/ get app() {
		if (!this._app) throw new e(ta.FAILED_PRECONDITION, "Firestore was not initialized using the Firebase SDK. 'app' is not available");
		return this._app;
	}
	get _initialized() {
		return this._settingsFrozen;
	}
	get _terminated() {
		return "notTerminated" !== this._terminateTask;
	}
	_setSettings(t) {
		if (this._settingsFrozen) throw new e(ta.FAILED_PRECONDITION, "Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");
		this._settings = new FirestoreSettingsImpl(t), this._emulatorOptions = t.emulatorOptions || {}, void 0 !== t.credentials && (this._authCredentials = function __PRIVATE_makeAuthCredentialsProvider(t) {
			if (!t) return new __PRIVATE_EmptyAuthCredentialsProvider();
			switch (t.type) {
				case "firstParty": return new __PRIVATE_FirstPartyAuthCredentialsProvider(t.sessionIndex || "0", t.iamToken || null, t.authTokenFactory || null);
				case "provider": return t.client;
				default: throw new e(ta.INVALID_ARGUMENT, "makeAuthCredentialsProvider failed due to invalid credential type");
			}
		}(t.credentials));
	}
	_getSettings() {
		return this._settings;
	}
	_getEmulatorOptions() {
		return this._emulatorOptions;
	}
	_freezeSettings() {
		return this._settingsFrozen = true, this._settings;
	}
	_delete() {
		return "notTerminated" === this._terminateTask && (this._terminateTask = this._terminate()), this._terminateTask;
	}
	async _restart() {
		"notTerminated" === this._terminateTask ? await this._terminate() : this._terminateTask = "notTerminated";
	}
	/** Returns a JSON-serializable representation of this `Firestore` instance. */ toJSON() {
		return {
			app: this._app,
			databaseId: this._databaseId,
			settings: this._settings
		};
	}
	/**
	* Terminates all components used by this client. Subclasses can override
	* this method to clean up their own dependencies, but must also call this
	* method.
	*
	* Only ever called once.
	*/ _terminate() {
		/**
		* Removes all components associated with the provided instance. Must be called
		* when the `Firestore` instance is terminated.
		*/
		return function __PRIVATE_removeComponents(e) {
			const t = Ht.get(e);
			t && (__PRIVATE_logDebug(zt, "Removing Datastore"), Ht.delete(e), t.terminate());
		}(this), Promise.resolve();
	}
};
/**
* Modify this instance to communicate with the Cloud Firestore emulator.
*
* Note: This must be called before this instance has been used to do any
* operations.
*
* @param firestore - The `Firestore` instance to configure to connect to the
* emulator.
* @param host - the emulator host (ex: localhost).
* @param port - the emulator port (ex: 9000).
* @param options.mockUserToken - the mock auth token to use for unit testing
* Security Rules.
*/ function connectFirestoreEmulator(t, n, r, i = {}) {
	t = ra(t, _n);
	const s = isCloudWorkstation(n), _ = t._getSettings(), o = {
		..._,
		emulatorOptions: t._getEmulatorOptions()
	}, a = `${n}:${r}`;
	s && pingServer(`https://${a}`), _.host !== rn && _.host !== a && __PRIVATE_logWarn("Host has been set in both settings() and connectFirestoreEmulator(), emulator host will be used.");
	const u = {
		..._,
		host: a,
		ssl: s,
		emulatorOptions: i
	};
	if (!deepEqual(u, o) && (t._setSettings(u), i.mockUserToken)) {
		let n, r;
		if ("string" == typeof i.mockUserToken) n = i.mockUserToken, r = User.MOCK_USER;
		else {
			n = createMockUserToken(i.mockUserToken, t._app?.options.projectId);
			const s = i.mockUserToken.sub || i.mockUserToken.user_id;
			if (!s) throw new e(ta.INVALID_ARGUMENT, "mockUserToken must contain 'sub' or 'user_id' field!");
			r = new User(s);
		}
		t._authCredentials = new __PRIVATE_EmulatorAuthCredentialsProvider(new __PRIVATE_OAuthToken(n, r));
	}
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* A `Query` refers to a query which you can read or listen to. You can also
* construct refined `Query` objects by adding filters and ordering.
*/ var Query = class Query {
	/** @hideconstructor protected */
	constructor(e, t, n) {
		this.converter = t, this._query = n, this.type = "query", this.firestore = e;
	}
	withConverter(e) {
		return new Query(this.firestore, e, this._query);
	}
};
/**
* A `DocumentReference` refers to a document location in a Firestore database
* and can be used to write, read, or listen to the location. The document at
* the referenced location may or may not exist.
*/ var aa = class aa {
	/** @hideconstructor */
	constructor(e, t, n) {
		this.converter = t, this._key = n, this.type = "document", this.firestore = e;
	}
	get _path() {
		return this._key.path;
	}
	/**
	* The document's identifier within its collection.
	*/ get id() {
		return this._key.path.lastSegment();
	}
	/**
	* A string representing the path of the referenced document (relative
	* to the root of the database).
	*/ get path() {
		return this._key.path.canonicalString();
	}
	/**
	* The collection this `DocumentReference` belongs to.
	*/ get parent() {
		return new na(this.firestore, this.converter, this._key.path.popLast());
	}
	withConverter(e) {
		return new aa(this.firestore, e, this._key);
	}
	/**
	* Returns a JSON-serializable representation of this `DocumentReference` instance.
	*
	* @returns a JSON representation of this object.
	*/ toJSON() {
		return {
			type: aa._jsonSchemaVersion,
			referencePath: this._key.toString()
		};
	}
	static fromJSON(e, t, n) {
		if (__PRIVATE_validateJSON(t, aa._jsonSchema)) return new aa(e, n || null, new DocumentKey(ResourcePath.fromString(t.referencePath)));
	}
};
aa._jsonSchemaVersion = "firestore/documentReference/1.0", aa._jsonSchema = {
	type: property("string", aa._jsonSchemaVersion),
	referencePath: property("string")
};
/**
* A `CollectionReference` object can be used for adding documents, getting
* document references, and querying for documents (using {@link (query:1)}).
*/
var na = class na extends Query {
	/** @hideconstructor */
	constructor(e, t, n) {
		super(e, t, __PRIVATE_newQueryForPath(n)), this._path = n, this.type = "collection";
	}
	/** The collection's identifier. */ get id() {
		return this._query.path.lastSegment();
	}
	/**
	* A string representing the path of the referenced collection (relative
	* to the root of the database).
	*/ get path() {
		return this._query.path.canonicalString();
	}
	/**
	* A reference to the containing `DocumentReference` if this is a
	* subcollection. If this isn't a subcollection, the reference is null.
	*/ get parent() {
		const e = this._path.popLast();
		return e.isEmpty() ? null : new aa(this.firestore, null, new DocumentKey(e));
	}
	withConverter(e) {
		return new na(this.firestore, e, this._path);
	}
};
function collection(t, n, ...r) {
	if (t = getModularInstance(t), __PRIVATE_validateNonEmptyArgument("collection", "path", n), t instanceof _n) {
		const e = ResourcePath.fromString(n, ...r);
		return __PRIVATE_validateCollectionPath(e), new na(t, null, e);
	}
	{
		if (!(t instanceof aa || t instanceof na)) throw new e(ta.INVALID_ARGUMENT, "Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");
		const i = t._path.child(ResourcePath.fromString(n, ...r));
		return __PRIVATE_validateCollectionPath(i), new na(t.firestore, null, i);
	}
}
function doc(t, n, ...r) {
	if (t = getModularInstance(t), 1 === arguments.length && (n = __PRIVATE_AutoId.newId()), __PRIVATE_validateNonEmptyArgument("doc", "path", n), t instanceof _n) {
		const e = ResourcePath.fromString(n, ...r);
		return __PRIVATE_validateDocumentPath(e), new aa(t, null, new DocumentKey(e));
	}
	{
		if (!(t instanceof aa || t instanceof na)) throw new e(ta.INVALID_ARGUMENT, "Expected first argument to doc() to be a CollectionReference, a DocumentReference or FirebaseFirestore");
		const i = t._path.child(ResourcePath.fromString(n, ...r));
		return __PRIVATE_validateDocumentPath(i), new aa(t.firestore, t instanceof na ? t.converter : null, new DocumentKey(i));
	}
}
/**
* @license
* Copyright 2025 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Represents a regular expression type in Firestore documents.
*
* @class RegexValue
*/ var RegexValue = class {
	constructor(e, t) {
		this.pattern = e, this.options = t;
	}
	/**
	* Returns true if this `RegexValue` is equal to the provided one.
	*
	* @param other - The `RegexValue` to compare against.
	* @return 'true' if this `RegexValue` is equal to the provided one.
	*/ isEqual(e) {
		return this.pattern === e.pattern && this.options === e.options;
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Returns true iff the array contains the value using strong equality.
*/
/**
* Compares two array for equality using comparator. The method computes the
* intersection and invokes `onAdd` for every element that is in `after` but not
* `before`. `onRemove` is invoked for every element in `before` but missing
* from `after`.
*
* The method creates a copy of both `before` and `after` and runs in O(n log
* n), where n is the size of the two lists.
*
* @param before - The elements that exist in the original array.
* @param after - The elements to diff against the original array.
* @param comparator - The comparator for the elements in before and after.
* @param onAdd - A function to invoke for every element that is part of `
* after` but not `before`.
* @param onRemove - A function to invoke for every element that is part of
* `before` but not `after`.
*/
/**
* @license
* Copyright 2024 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Represents a vector type in Firestore documents.
* Create an instance with <code>{@link vector}</code>.
*/
var n = class n {
	/**
	* @private
	* @internal
	*/
	constructor(e) {
		this._values = (e || []).map(((e) => e));
	}
	/**
	* Returns a copy of the raw number array form of the vector.
	*/ toArray() {
		return this._values.map(((e) => e));
	}
	/**
	* Returns `true` if the two `VectorValue` values have the same raw number arrays, returns `false` otherwise.
	*/ isEqual(e) {
		/**
		* Verifies equality for an array of primitives.
		*
		* @private
		* @internal
		* @param left - Array of primitives.
		* @param right - Array of primitives.
		* @returns True if arrays are equal.
		*/
		return function __PRIVATE_isPrimitiveArrayEqual(e, t) {
			if (e.length !== t.length) return false;
			for (let n = 0; n < e.length; ++n) if (e[n] !== t[n]) return false;
			return true;
		}(this._values, e._values);
	}
	/**
	* Returns a JSON-serializable representation of this `VectorValue` instance.
	*
	* @returns a JSON representation of this object.
	*/ toJSON() {
		return {
			type: n._jsonSchemaVersion,
			vectorValues: this._values
		};
	}
	/**
	* Builds a `VectorValue` instance from a JSON object created by {@link VectorValue.toJSON}.
	*
	* @param json - a JSON object represention of a `VectorValue` instance.
	* @returns an instance of {@link VectorValue} if the JSON object could be parsed. Throws a
	* {@link FirestoreError} if an error occurs.
	*/ static fromJSON(t) {
		if (__PRIVATE_validateJSON(t, n._jsonSchema)) {
			if (Array.isArray(t.vectorValues) && t.vectorValues.every(((e) => "number" == typeof e))) return new n(t.vectorValues);
			throw new e(ta.INVALID_ARGUMENT, "Expected 'vectorValues' field to be a number array");
		}
	}
};
n._jsonSchemaVersion = "firestore/vectorValue/1.0", n._jsonSchema = {
	type: property("string", n._jsonSchemaVersion),
	vectorValues: property("object")
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var on = /^__.*__$/;
/** The result of parsing document data (e.g. for a setData call). */ var ParsedSetData = class {
	constructor(e, t, n) {
		this.data = e, this.fieldMask = t, this.fieldTransforms = n;
	}
	toMutation(e, t) {
		return null !== this.fieldMask ? new __PRIVATE_PatchMutation(e, this.data, this.fieldMask, t, this.fieldTransforms) : new __PRIVATE_SetMutation(e, this.data, t, this.fieldTransforms);
	}
};
function __PRIVATE_isWrite(e) {
	switch (e) {
		case 0:
		case 2:
		case 1: return true;
		case 3:
		case 4: return false;
		default: throw l(40011, { dataSource: e });
	}
}
/** A "context" object passed around while parsing user data. */ var ParseContextImpl = class ParseContextImpl {
	/**
	* Initializes a ParseContext with the given source and path.
	*
	* @param settings - The settings for the parser.
	* @param databaseId - The database ID of the Firestore instance.
	* @param serializer - The serializer to use to generate the Value proto.
	* @param ignoreUndefinedProperties - Whether to ignore undefined properties
	* rather than throw.
	* @param fieldTransforms - A mutable list of field transforms encountered
	* while parsing the data.
	* @param fieldMask - A mutable list of field paths encountered while parsing
	* the data.
	*
	* TODO(b/34871131): We don't support array paths right now, so path can be
	* null to indicate the context represents any location within an array (in
	* which case certain features will not work and errors will be somewhat
	* compromised).
	*/
	constructor(e, t, n, r, i, s) {
		this.settings = e, this.databaseId = t, this.serializer = n, this.ignoreUndefinedProperties = r, void 0 === i && this.validatePath(), this.fieldTransforms = i || [], this.fieldMask = s || [];
	}
	get path() {
		return this.settings.path;
	}
	get dataSource() {
		return this.settings.dataSource;
	}
	/** Returns a new context with the specified settings overwritten. */ contextWith(e) {
		return new ParseContextImpl({
			...this.settings,
			...e
		}, this.databaseId, this.serializer, this.ignoreUndefinedProperties, this.fieldTransforms, this.fieldMask);
	}
	childContextForField(e) {
		const t = this.path?.child(e), n = this.contextWith({
			path: t,
			arrayElement: false
		});
		return n.validatePathSegment(e), n;
	}
	childContextForFieldPath(e) {
		const t = this.path?.child(e), n = this.contextWith({
			path: t,
			arrayElement: false
		});
		return n.validatePath(), n;
	}
	childContextForArray(e) {
		return this.contextWith({
			path: void 0,
			arrayElement: true
		});
	}
	createError(e) {
		return createError(e, this.settings.methodName, this.settings.hasConverter || false, this.path, this.settings.targetDoc);
	}
	/** Returns 'true' if 'fieldPath' was traversed when creating this context. */ contains(e) {
		return void 0 !== this.fieldMask.find(((t) => e.isPrefixOf(t))) || void 0 !== this.fieldTransforms.find(((t) => e.isPrefixOf(t.field)));
	}
	validatePath() {
		if (this.path) for (let e = 0; e < this.path.length; e++) this.validatePathSegment(this.path.get(e));
	}
	validatePathSegment(e) {
		if (0 === e.length) throw this.createError("Document fields must not be empty");
		if (__PRIVATE_isWrite(this.dataSource) && on.test(e)) throw this.createError("Document fields cannot begin and end with \"__\"");
	}
};
/**
* Helper for parsing raw user input (provided via the API) into internal model
* classes.
*/ var UserDataReader = class {
	constructor(e, t, n) {
		this.databaseId = e, this.ignoreUndefinedProperties = t, this.serializer = n || __PRIVATE_newSerializer(e);
	}
	/** Creates a new top-level parse context. */ createContext(e, t, n, r = false) {
		return new ParseContextImpl({
			dataSource: e,
			methodName: t,
			targetDoc: n,
			path: Me$1.emptyPath(),
			arrayElement: false,
			hasConverter: r
		}, this.databaseId, this.serializer, this.ignoreUndefinedProperties);
	}
};
function la(e) {
	const t = e._freezeSettings(), n = __PRIVATE_newSerializer(e._databaseId);
	return new UserDataReader(e._databaseId, !!t.ignoreUndefinedProperties, n);
}
/** Parse document data from a set() call. */ function __PRIVATE_parseSetData(t, n, r, i, s, _ = {}) {
	const o = t.createContext(_.merge || _.mergeFields ? 2 : 0, n, r, s);
	__PRIVATE_validatePlainObject("Data must be an object, but it was:", o, i);
	const a = __PRIVATE_parseObject(i, o);
	let u, c;
	if (_.merge) u = new FieldMask(o.fieldMask), c = o.fieldTransforms;
	else if (_.mergeFields) {
		const t = [];
		for (const i of _.mergeFields) {
			const s = K(n, i, r);
			if (!o.contains(s)) throw new e(ta.INVALID_ARGUMENT, `Field '${s}' is specified in your field mask but missing from your input data.`);
			__PRIVATE_fieldMaskContains(t, s) || t.push(s);
		}
		u = new FieldMask(t), c = o.fieldTransforms.filter(((e) => u.covers(e.field)));
	} else u = null, c = o.fieldTransforms;
	return new ParsedSetData(new ObjectValue(a), u, c);
}
/**
* Parse a "query value" (e.g. value in a where filter or a value in a cursor
* bound).
*
* @param allowArrays - Whether the query value is an array that may directly
* contain additional arrays (e.g. the operand of an `in` query).
*/ function __PRIVATE_parseQueryValue(e, t, n, r = false) {
	return __PRIVATE_parseData(n, e.createContext(r ? 4 : 3, t));
}
/**
* Parses user data to Protobuf Values.
*
* @param input - Data to be parsed.
* @param context - A context object representing the current path being parsed,
* the source of the data being parsed, etc.
* @returns The parsed value, or null if the value was a FieldValue sentinel
* that should not be included in the resulting parsed data.
*/ function __PRIVATE_parseData(e, t, r) {
	if (__PRIVATE_looksLikeJsonObject(e = getModularInstance(e))) return __PRIVATE_validatePlainObject("Unsupported field value:", t, e), __PRIVATE_parseObject(e, t);
	if (e instanceof FieldValue)
 /**
	* "Parses" the provided FieldValueImpl, adding any necessary transforms to
	* context.fieldTransforms.
	*/
	return function __PRIVATE_parseSentinelFieldValue(e, t) {
		if (!__PRIVATE_isWrite(t.dataSource)) throw t.createError(`${e._methodName}() can only be used with update() and set()`);
		if (!t.path) throw t.createError(`${e._methodName}() is not currently supported inside arrays`);
		const n = e._toFieldTransform(t);
		n && t.fieldTransforms.push(n);
	}(e, t), null;
	if (void 0 === e && t.ignoreUndefinedProperties) return null;
	if (t.path && t.fieldMask.push(t.path), e instanceof Array) {
		if (t.settings.arrayElement && 4 !== t.dataSource) throw t.createError("Nested arrays are not supported");
		return function __PRIVATE_parseArray(e, t) {
			const n = [];
			let r = 0;
			for (const i of e) {
				let e = __PRIVATE_parseData(i, t.childContextForArray(r));
				e ?? (e = { nullValue: "NULL_VALUE" }), n.push(e), r++;
			}
			return { arrayValue: { values: n } };
		}(e, t);
	}
	return function __PRIVATE_parseScalarValue(e, t, r) {
		if (null === (e = getModularInstance(e))) return { nullValue: "NULL_VALUE" };
		if ("number" == typeof e) return toNumber(t.serializer, e);
		if ("boolean" == typeof e) return { booleanValue: e };
		if ("string" == typeof e) return { stringValue: e };
		if (e instanceof Date) {
			const n = Timestamp.fromDate(e);
			return { timestampValue: toTimestamp(t.serializer, n) };
		}
		if (e instanceof Timestamp) {
			const n = new Timestamp(e.seconds, 1e3 * Math.floor(e.nanoseconds / 1e3));
			return { timestampValue: toTimestamp(t.serializer, n) };
		}
		if (__PRIVATE_isTemporalInstant(e)) {
			const n = Timestamp.fromInstant(e), r = new Timestamp(n.seconds, 1e3 * Math.floor(n.nanoseconds / 1e3));
			return { timestampValue: toTimestamp(t.serializer, r) };
		}
		if (e instanceof GeoPoint) return { geoPointValue: {
			latitude: e.latitude,
			longitude: e.longitude
		} };
		if (e instanceof Bytes) return 0 === e.subtype ? { bytesValue: __PRIVATE_toBytes(t.serializer, e._byteString) } : 
		/**
		* Parses Bytes with a non-zero subtype.
		*/
		function __PRIVATE_parseBytesWithSubtype(e, t) {
			const n = t.toUint8Array(), r = new Uint8Array(n.length + 1);
			r[0] = t.subtype, r.set(n, 1);
			return { mapValue: { fields: { [Et]: { bytesValue: __PRIVATE_toBytes(e, ByteString.fromUint8Array(r)) } } } };
		}(t.serializer, e);
		if (e instanceof aa) {
			const n = t.databaseId, r = e.firestore._databaseId;
			if (!r.isEqual(n)) throw t.createError(`Document reference is for database ${r.projectId}/${r.database} but should be for database ${n.projectId}/${n.database}`);
			return { referenceValue: __PRIVATE_toResourceName(e.firestore._databaseId || t.databaseId, e._key.path) };
		}
		if (e instanceof n)
 /**
		* Creates a new VectorValue proto value (using the internal format).
		*/
		return function __PRIVATE_parseVectorValue(e, t) {
			const r = e instanceof n ? e.toArray() : e;
			return { mapValue: { fields: {
				[Ye]: { stringValue: Ze },
				[Xe]: { arrayValue: { values: r.map(((e) => {
					if ("number" != typeof e) throw t.createError("VectorValues must only contain numeric values.");
					return __PRIVATE_toDouble(t.serializer, e);
				})) } }
			} } };
		}(e, t);
		if (e instanceof RegexValue) return function __PRIVATE_parseRegexValue(e) {
			return { mapValue: { fields: { [rt]: { mapValue: { fields: {
				[it]: { stringValue: e.pattern },
				[st]: { stringValue: e.options }
			} } } } } };
		}(e);
		if (e instanceof BsonObjectId) return function __PRIVATE_parseBsonObjectId(e) {
			return { mapValue: { fields: { [_t]: { stringValue: e.value } } } };
		}(e);
		if (e instanceof Int32Value) return function __PRIVATE_parseInt32Value(e) {
			return { mapValue: { fields: { [ot]: __PRIVATE_toInteger(e.value) } } };
		}(e);
		if (e instanceof Decimal128Value) return function __PRIVATE_parseDecimal128Value(e) {
			return { mapValue: { fields: { [at]: { stringValue: e.stringValue } } } };
		}(e);
		if (e instanceof BsonTimestamp) return function __PRIVATE_parseBsonTimestamp(e) {
			return { mapValue: { fields: { [ut]: { mapValue: { fields: {
				[ct]: __PRIVATE_toInteger(e.seconds),
				[lt]: __PRIVATE_toInteger(e.increment)
			} } } } } };
		}(e);
		if (e instanceof MinKey) return function __PRIVATE_parseMinKey() {
			return { mapValue: { fields: { [tt]: { nullValue: "NULL_VALUE" } } } };
		}();
		if (e instanceof MaxKey) return function __PRIVATE_parseMaxKey() {
			return { mapValue: { fields: { [nt]: { nullValue: "NULL_VALUE" } } } };
		}();
		if (__PRIVATE_isProtoValueSerializable(e)) return e._toProto(t.serializer);
		throw t.createError(`Unsupported field value: ${__PRIVATE_valueDescription(e)}`);
	}(e, t);
}
function __PRIVATE_parseObject(e, t) {
	const n = {};
	return isEmpty(e) ? t.path && t.path.length > 0 && t.fieldMask.push(t.path) : forEach(e, ((e, r) => {
		const i = __PRIVATE_parseData(r, t.childContextForField(e));
		null != i && (n[e] = i);
	})), { mapValue: { fields: n } };
}
function __PRIVATE_isTemporalInstant(e) {
	if ("object" != typeof e || null === e) return false;
	if ("undefined" != typeof Temporal && "function" == typeof Temporal.Instant) {
		if (e instanceof Temporal.Instant) return true;
	}
	const t = e;
	return "Temporal.Instant" === t[Symbol.toStringTag] && "bigint" == typeof t.t;
}
function __PRIVATE_looksLikeJsonObject(e) {
	return !("object" != typeof e || null === e || e instanceof Array || e instanceof Date || e instanceof Timestamp || e instanceof GeoPoint || e instanceof Bytes || e instanceof aa || e instanceof FieldValue || e instanceof n || e instanceof MinKey || e instanceof MaxKey || e instanceof Int32Value || e instanceof Decimal128Value || e instanceof RegexValue || e instanceof BsonObjectId || e instanceof BsonTimestamp || __PRIVATE_isTemporalInstant(e) || __PRIVATE_isProtoValueSerializable(e));
}
function __PRIVATE_validatePlainObject(e, t, n) {
	if (!__PRIVATE_looksLikeJsonObject(n) || !p(n)) {
		const r = __PRIVATE_valueDescription(n);
		throw "an object" === r ? t.createError(e + " a custom object") : t.createError(e + " " + r);
	}
}
/**
* Helper that calls fromDotSeparatedString() but wraps any error thrown.
*/ function K(e, t, n) {
	if ((t = getModularInstance(t)) instanceof FieldPath) return t._internalPath;
	if ("string" == typeof t) return __PRIVATE_fieldPathFromDotSeparatedString(e, t);
	throw createError("Field path arguments must be of type string or ", e, false, void 0, n);
}
/**
* Matches any characters in a field path string that are reserved.
*/ var an = /* @__PURE__ */ new RegExp("[~\\*/\\[\\]]");
/**
* Wraps fromDotSeparatedString with an error message about the method that
* was thrown.
* @param methodName - The publicly visible method name
* @param path - The dot-separated string form of a field path which will be
* split on dots.
* @param targetDoc - The document against which the field path will be
* evaluated.
*/ function __PRIVATE_fieldPathFromDotSeparatedString(e, t, n) {
	if (t.search(an) >= 0) throw createError(`Invalid field path (${t}). Paths must not contain '~', '*', '/', '[', or ']'`, e, false, void 0, n);
	try {
		return new FieldPath(...t.split("."))._internalPath;
	} catch (r) {
		throw createError(`Invalid field path (${t}). Paths must not be empty, begin with '.', end with '.', or contain '..'`, e, false, void 0, n);
	}
}
function createError(t, n, r, i, s) {
	const _ = i && !i.isEmpty(), o = void 0 !== s;
	let a = `Function ${n}() called with invalid data`;
	r && (a += " (via `toFirestore()`)"), a += ". ";
	let u = "";
	return (_ || o) && (u += " (found", _ && (u += ` in field ${i}`), o && (u += ` in document ${s}`), u += ")"), new e(ta.INVALID_ARGUMENT, a + t + u);
}
/** Checks `haystack` if FieldPath `needle` is present. Runs in O(n). */ function __PRIVATE_fieldMaskContains(e, t) {
	return e.some(((e) => e.isEqual(t)));
}
function __PRIVATE_isUserData(e) {
	return "function" == typeof e._readUserData;
}
/**
* @license
* Copyright 2025 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var OptionsUtil = class OptionsUtil {
	constructor(e) {
		this.optionDefinitions = e;
	}
	_getKnownOptions(e, t) {
		const n = ObjectValue.empty();
		for (const r in this.optionDefinitions) if (this.optionDefinitions.hasOwnProperty(r)) {
			const i = this.optionDefinitions[r];
			if (r in e) {
				const s = e[r];
				let _;
				if (i.nestedOptions && p(s)) _ = { mapValue: { fields: new OptionsUtil(i.nestedOptions).getOptionsProto(t, s) } };
				else s && (_ = __PRIVATE_parseData(s, t) ?? void 0);
				_ && n.set(Me$1.fromServerFormat(i.serverName), _);
			}
		}
		return n;
	}
	getOptionsProto(e, t, n) {
		const r = this._getKnownOptions(t, e);
		if (n) {
			const t = new Map(__PRIVATE_mapToArray(n, ((t, n) => [Me$1.fromServerFormat(n), void 0 !== t ? __PRIVATE_parseData(t, e) : null])));
			r.setAll(t);
		}
		return r.value.mapValue.fields ?? {};
	}
};
/**
* @license
* Copyright 2024 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function u(e) {
	return "object" == typeof e && null !== e && !!("nullValue" in e && (null === e.nullValue || "NULL_VALUE" === e.nullValue) || "booleanValue" in e && (null === e.booleanValue || "boolean" == typeof e.booleanValue) || "integerValue" in e && (null === e.integerValue || "number" == typeof e.integerValue || "string" == typeof e.integerValue) || "doubleValue" in e && (null === e.doubleValue || "number" == typeof e.doubleValue) || "timestampValue" in e && (null === e.timestampValue || function __PRIVATE_isITimestamp(e) {
		return "object" == typeof e && null !== e && "seconds" in e && (null === e.seconds || "number" == typeof e.seconds || "string" == typeof e.seconds) && "nanos" in e && (null === e.nanos || "number" == typeof e.nanos);
	}(e.timestampValue)) || "stringValue" in e && (null === e.stringValue || "string" == typeof e.stringValue) || "bytesValue" in e && (null === e.bytesValue || e.bytesValue instanceof Uint8Array) || "referenceValue" in e && (null === e.referenceValue || "string" == typeof e.referenceValue) || "geoPointValue" in e && (null === e.geoPointValue || function __PRIVATE_isILatLng(e) {
		return "object" == typeof e && null !== e && "latitude" in e && (null === e.latitude || "number" == typeof e.latitude) && "longitude" in e && (null === e.longitude || "number" == typeof e.longitude);
	}(e.geoPointValue)) || "arrayValue" in e && (null === e.arrayValue || function __PRIVATE_isIArrayValue(e) {
		return "object" == typeof e && null !== e && !(!("values" in e) || null !== e.values && !Array.isArray(e.values));
	}(e.arrayValue)) || "mapValue" in e && (null === e.mapValue || function __PRIVATE_isIMapValue(e) {
		return "object" == typeof e && null !== e && !(!("fields" in e) || null !== e.fields && !p(e.fields));
	}(e.mapValue)) || "fieldReferenceValue" in e && (null === e.fieldReferenceValue || "string" == typeof e.fieldReferenceValue) || "functionValue" in e && (null === e.functionValue || function __PRIVATE_isIFunction(e) {
		return "object" == typeof e && null !== e && !(!("name" in e) || null !== e.name && "string" != typeof e.name || !("args" in e) || null !== e.args && !Array.isArray(e.args));
	}(e.functionValue)) || "pipelineValue" in e && (null === e.pipelineValue || function __PRIVATE_isIPipeline(e) {
		return "object" == typeof e && null !== e && !(!("stages" in e) || null !== e.stages && !Array.isArray(e.stages));
	}(e.pipelineValue)));
}
/**
* Creates a new `VectorValue` constructed with a copy of the given array of numbers.
*
* @param values - Create a `VectorValue` instance with a copy of this array of numbers.
*
* @returns A new `VectorValue` constructed with a copy of the given array of numbers.
*/ function r(e) {
	return new n(e);
}
/**
* @license
* Copyright 2024 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Converts a value to an Expression, Returning either a Constant, MapFunction,
* ArrayFunction, or the input itself (if it's already an expression).
*
* @private
* @internal
* @param value
*/ function __PRIVATE_valueToDefaultExpr(e) {
	let n;
	return e instanceof t ? e : (n = p(e) ? __PRIVATE__map(e) : e instanceof Array ? b(e) : m(e, void 0), n);
}
/**
* Converts a value to an Expression, Returning either a Constant, MapFunction,
* ArrayFunction, or the input itself (if it's already an expression).
*
* @private
* @internal
* @param value
*/ function __PRIVATE_vectorToExpr(e) {
	if (e instanceof t) return e;
	if (e instanceof n) return i(e);
	if (Array.isArray(e)) return i(r(e));
	throw new Error("Unsupported value: " + typeof e);
}
/**
* Converts a value to an Expression, Returning either a Constant, MapFunction,
* ArrayFunction, or the input itself (if it's already an expression).
* If the input is a string, it is assumed to be a field name, and a
* field(value) is returned.
*
* @private
* @internal
* @param value
*/ function __PRIVATE_fieldOrExpression(e) {
	if (__PRIVATE_isString$1(e)) return s(e);
	return __PRIVATE_valueToDefaultExpr(e);
}
/**
*
* Represents an expression that can be evaluated to a value within the execution of a {@link
* @firebase/firestore/pipelines#Pipeline}.
*
* Expressions are the building blocks for creating complex queries and transformations in
* Firestore pipelines. They can represent:
*
* - **Field references:** Access values from document fields.
* - **Literals:** Represent constant values (strings, numbers, booleans).
* - **Function calls:** Apply functions to one or more expressions.
*
* The `Expression` class provides a fluent API for building expressions. You can chain together
* method calls to create complex expressions.
*/ var t = class {
	constructor() {
		this._protoValueType = "ProtoValue";
	}
	/**
	* Creates an expression that adds this expression to another expression.
	*
	* @example
	* ```typescript
	* // Add the value of the 'quantity' field and the 'reserve' field.
	* field("quantity").add(field("reserve"));
	* ```
	*
	* @param second - The expression or literal to add to this expression.
	* @param others - Optional additional expressions or literals to add to this expression.
	* @returns A new `Expression` representing the addition operation.
	*/ add(e) {
		return new y("add", [this, __PRIVATE_valueToDefaultExpr(e)], "add");
	}
	/**
	* Wraps the expression in a [BooleanExpression].
	*
	* @returns A [BooleanExpression] representing the same expression.
	*/ asBoolean() {
		if (this instanceof BooleanExpression) return this;
		if (this instanceof Constant) return new __PRIVATE_BooleanConstant(this);
		if (this instanceof o) return new __PRIVATE_BooleanField(this);
		if (this instanceof y) return new __PRIVATE_BooleanFunctionExpression(this);
		throw new e("invalid-argument", `Conversion of type ${typeof this} to BooleanExpression not supported.`);
	}
	subtract(e) {
		return new y("subtract", [this, __PRIVATE_valueToDefaultExpr(e)], "subtract");
	}
	/**
	* Creates an expression that multiplies this expression by another expression.
	*
	* @example
	* ```typescript
	* // Multiply the 'quantity' field by the 'price' field
	* field("quantity").multiply(field("price"));
	* ```
	*
	* @param second - The second expression or literal to multiply by.
	* @param others - Optional additional expressions or literals to multiply by.
	* @returns A new `Expression` representing the multiplication operation.
	*/ multiply(e) {
		return new y("multiply", [this, __PRIVATE_valueToDefaultExpr(e)], "multiply");
	}
	divide(e) {
		return new y("divide", [this, __PRIVATE_valueToDefaultExpr(e)], "divide");
	}
	mod(e) {
		return new y("mod", [this, __PRIVATE_valueToDefaultExpr(e)], "mod");
	}
	equal(e) {
		return new y("equal", [this, __PRIVATE_valueToDefaultExpr(e)], "equal").asBoolean();
	}
	notEqual(e) {
		return new y("not_equal", [this, __PRIVATE_valueToDefaultExpr(e)], "notEqual").asBoolean();
	}
	lessThan(e) {
		return new y("less_than", [this, __PRIVATE_valueToDefaultExpr(e)], "lessThan").asBoolean();
	}
	lessThanOrEqual(e) {
		return new y("less_than_or_equal", [this, __PRIVATE_valueToDefaultExpr(e)], "lessThanOrEqual").asBoolean();
	}
	greaterThan(e) {
		return new y("greater_than", [this, __PRIVATE_valueToDefaultExpr(e)], "greaterThan").asBoolean();
	}
	greaterThanOrEqual(e) {
		return new y("greater_than_or_equal", [this, __PRIVATE_valueToDefaultExpr(e)], "greaterThanOrEqual").asBoolean();
	}
	/**
	* Creates an expression that concatenates an array expression with one or more other arrays.
	*
	* @example
	* ```typescript
	* // Combine the 'items' array with another array field.
	* field("items").arrayConcat(field("otherItems"));
	* ```
	* @param secondArray - Second array expression or array literal to concatenate.
	* @param otherArrays - Optional additional array expressions or array literals to concatenate.
	* @returns A new `Expression` representing the concatenated array.
	*/ arrayConcat(e, ...t) {
		const n = [e, ...t].map(((e) => __PRIVATE_valueToDefaultExpr(e)));
		return new y("array_concat", [this, ...n], "arrayConcat");
	}
	arrayContains(e) {
		return new y("array_contains", [this, __PRIVATE_valueToDefaultExpr(e)], "arrayContains").asBoolean();
	}
	arrayContainsAll(e) {
		const t = Array.isArray(e) ? new __PRIVATE_ListOfExprs(e.map(__PRIVATE_valueToDefaultExpr), "arrayContainsAll") : e;
		return new y("array_contains_all", [this, t], "arrayContainsAll").asBoolean();
	}
	arrayContainsAny(e) {
		const t = Array.isArray(e) ? new __PRIVATE_ListOfExprs(e.map(__PRIVATE_valueToDefaultExpr), "arrayContainsAny") : e;
		return new y("array_contains_any", [this, t], "arrayContainsAny").asBoolean();
	}
	/**
	* Creates an expression that reverses an array.
	*
	* @example
	* ```typescript
	* // Reverse the value of the 'myArray' field.
	* field("myArray").arrayReverse();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the reversed array.
	*/ arrayReverse() {
		return new y("array_reverse", [this]);
	}
	/**
	* Creates an expression that calculates the length of an array.
	*
	* @example
	* ```typescript
	* // Get the number of items in the 'cart' array
	* field("cart").arrayLength();
	* ```
	*
	* @returns A new `Expression` representing the length of the array.
	*/ arrayLength() {
		return new y("array_length", [this], "arrayLength");
	}
	equalAny(e) {
		const t = Array.isArray(e) ? new __PRIVATE_ListOfExprs(e.map(__PRIVATE_valueToDefaultExpr), "equalAny") : e;
		return new y("equal_any", [this, t], "equalAny").asBoolean();
	}
	notEqualAny(e) {
		const t = Array.isArray(e) ? new __PRIVATE_ListOfExprs(e.map(__PRIVATE_valueToDefaultExpr), "notEqualAny") : e;
		return new y("not_equal_any", [this, t], "notEqualAny").asBoolean();
	}
	/**
	* Creates an expression that checks if a field exists in the document.
	*
	* @example
	* ```typescript
	* // Check if the document has a field named "phoneNumber"
	* field("phoneNumber").exists();
	* ```
	*
	* @returns A new `Expression` representing the 'exists' check.
	*/ exists() {
		return new y("exists", [this], "exists").asBoolean();
	}
	/**
	* Creates an expression that calculates the character length of a string in UTF-8.
	*
	* @example
	* ```typescript
	* // Get the character length of the 'name' field in its UTF-8 form.
	* field("name").charLength();
	* ```
	*
	* @returns A new `Expression` representing the length of the string.
	*/ charLength() {
		return new y("char_length", [this], "charLength");
	}
	like(e) {
		return new y("like", [this, __PRIVATE_valueToDefaultExpr(e)], "like").asBoolean();
	}
	regexContains(e) {
		return new y("regex_contains", [this, __PRIVATE_valueToDefaultExpr(e)], "regexContains").asBoolean();
	}
	regexFind(e) {
		return new y("regex_find", [this, __PRIVATE_valueToDefaultExpr(e)], "regexFind");
	}
	regexFindAll(e) {
		return new y("regex_find_all", [this, __PRIVATE_valueToDefaultExpr(e)], "regexFindAll");
	}
	regexMatch(e) {
		return new y("regex_match", [this, __PRIVATE_valueToDefaultExpr(e)], "regexMatch").asBoolean();
	}
	stringContains(e) {
		return new y("string_contains", [this, __PRIVATE_valueToDefaultExpr(e)], "stringContains").asBoolean();
	}
	startsWith(e) {
		return new y("starts_with", [this, __PRIVATE_valueToDefaultExpr(e)], "startsWith").asBoolean();
	}
	endsWith(e) {
		return new y("ends_with", [this, __PRIVATE_valueToDefaultExpr(e)], "endsWith").asBoolean();
	}
	/**
	* Creates an expression that converts a string to lowercase.
	*
	* @example
	* ```typescript
	* // Convert the 'name' field to lowercase
	* field("name").toLower();
	* ```
	*
	* @returns A new `Expression` representing the lowercase string.
	*/ toLower() {
		return new y("to_lower", [this], "toLower");
	}
	/**
	* Creates an expression that converts a string to uppercase.
	*
	* @example
	* ```typescript
	* // Convert the 'title' field to uppercase
	* field("title").toUpper();
	* ```
	*
	* @returns A new `Expression` representing the uppercase string.
	*/ toUpper() {
		return new y("to_upper", [this], "toUpper");
	}
	/**
	* Creates an expression that removes leading and trailing characters from a string or byte array.
	*
	* @example
	* ```typescript
	* // Trim whitespace from the 'userInput' field
	* field("userInput").trim();
	*
	* // Trim quotes from the 'userInput' field
	* field("userInput").trim('"');
	* ```
	* @param valueToTrim - Optional This parameter is treated as a set of characters or bytes that will be
	* trimmed from the input. If not specified, then whitespace will be trimmed.
	* @returns A new `Expression` representing the trimmed string or byte array.
	*/ trim(e) {
		const t = [this];
		return e && t.push(__PRIVATE_valueToDefaultExpr(e)), new y("trim", t, "trim");
	}
	/**
	* Trims whitespace or a specified set of characters/bytes from the beginning of a string or byte array.
	*
	* @example
	* ```typescript
	* // Trim whitespace from the beginning of the 'userInput' field
	* field("userInput").ltrim();
	*
	* // Trim quotes from the beginning of the 'userInput' field
	* field("userInput").ltrim('"');
	* ```
	*
	* @param valueToTrim - Optional. A string or byte array containing the characters/bytes to trim.
	* If not specified, whitespace will be trimmed.
	* @returns A new `Expression` representing the trimmed string.
	*/ ltrim(e) {
		const t = [this];
		return e && t.push(__PRIVATE_valueToDefaultExpr(e)), new y("ltrim", t, "ltrim");
	}
	/**
	* Trims whitespace or a specified set of characters/bytes from the end of a string or byte array.
	*
	* @example
	* ```typescript
	* // Trim whitespace from the end of the 'userInput' field
	* field("userInput").rtrim();
	*
	* // Trim quotes from the end of the 'userInput' field
	* field("userInput").rtrim('"');
	* ```
	*
	* @param valueToTrim - Optional. A string or byte array containing the characters/bytes to trim.
	* If not specified, whitespace will be trimmed.
	* @returns A new `Expression` representing the trimmed string or byte array.
	*/ rtrim(e) {
		const t = [this];
		return e && t.push(__PRIVATE_valueToDefaultExpr(e)), new y("rtrim", t, "rtrim");
	}
	/**
	* Creates an expression that returns the data type of this expression's result, as a string.
	*
	* @remarks
	* This is evaluated on the backend. This means:
	* 1. Generic typed elements (like `array<string>`) evaluate strictly to the primitive `'array'`.
	* 2. Any custom `FirestoreDataConverter` mappings are ignored.
	* 3. For numeric values, the backend does not yield the JavaScript `"number"` type; it evaluates
	*    precisely as `"int64"` or `"float64"`.
	* 4. For date or timestamp objects, the backend evaluates to `"timestamp"`.
	*
	* @example
	* ```typescript
	* // Get the data type of the value in field 'title'
	* field('title').type()
	* ```
	*
	* @returns A new `Expression` representing the data type.
	*/ type() {
		return new y("type", [this]);
	}
	/**
	* Creates an expression that checks if the result of this expression is of the given type.
	*
	* @remarks Null or undefined fields evaluate to skip/error. Use `ifAbsent()` / `isAbsent()` to evaluate missing data.
	* Supported values for `type` are:
	* `'null'`, `'array'`, `'boolean'`, `'bytes'`, `'timestamp'`, `'geo_point'`, `'number'`,
	* `'int32'`, `'int64'`, `'float64'`, `'decimal128'`, `'map'`, `'reference'`, `'string'`,
	* `'vector'`, `'max_key'`, `'min_key'`, `'object_id'`, `'regex'`, `'request_timestamp'`.
	*
	* @example
	* ```typescript
	* // Check if the 'price' field is specifically an integer (not just 'number')
	* field('price').isType('int64');
	* ```
	*
	* @param type - The type to check for.
	* @returns A new `BooleanExpression` that evaluates to true if the expression's result is of the given type, false otherwise.
	*/ isType(e) {
		return new y("is_type", [this, i(e)], "isType").asBoolean();
	}
	/**
	* Creates an expression that concatenates string expressions together.
	*
	* @example
	* ```typescript
	* // Combine the 'firstName', " ", and 'lastName' fields into a single string
	* field("firstName").stringConcat(constant(" "), field("lastName"));
	* ```
	*
	* @param secondString - The additional expression or string literal to concatenate.
	* @param otherStrings - Optional additional expressions or string literals to concatenate.
	* @returns A new `Expression` representing the concatenated string.
	*/ stringConcat(e, ...t) {
		const n = [e, ...t].map(__PRIVATE_valueToDefaultExpr);
		return new y("string_concat", [this, ...n], "stringConcat");
	}
	/**
	* Creates an expression that finds the index of the first occurrence of a substring or byte sequence.
	*
	* @example
	* ```typescript
	* // Find the index of "foo" in the 'text' field
	* field("text").stringIndexOf("foo");
	* ```
	*
	* @param search - The substring or byte sequence to search for.
	* @returns A new `Expression` representing the index of the first occurrence.
	*/ stringIndexOf(e) {
		return new y("string_index_of", [this, __PRIVATE_valueToDefaultExpr(e)], "stringIndexOf");
	}
	/**
	* Creates an expression that repeats a string or byte array a specified number of times.
	*
	* @example
	* ```typescript
	* // Repeat the 'label' field 3 times
	* field("label").stringRepeat(3);
	* ```
	*
	* @param repetitions - The number of times to repeat the string or byte array.
	* @returns A new `Expression` representing the repeated string or byte array.
	*/ stringRepeat(e) {
		return new y("string_repeat", [this, __PRIVATE_valueToDefaultExpr(e)], "stringRepeat");
	}
	/**
	* Creates an expression that replaces all occurrences of a substring or byte sequence with a replacement.
	*
	* @example
	* ```typescript
	* // Replace all occurrences of "foo" with "bar" in the 'text' field
	* field("text").stringReplaceAll("foo", "bar");
	* ```
	*
	* @param find - The substring or byte sequence to search for.
	* @param replacement - The replacement string or byte sequence.
	* @returns A new `Expression` representing the string or byte array with replacements.
	*/ stringReplaceAll(e, t) {
		return new y("string_replace_all", [
			this,
			__PRIVATE_valueToDefaultExpr(e),
			__PRIVATE_valueToDefaultExpr(t)
		], "stringReplaceAll");
	}
	/**
	* Creates an expression that replaces the first occurrence of a substring or byte sequence with a replacement.
	*
	* @example
	* ```typescript
	* // Replace the first occurrence of "foo" with "bar" in the 'text' field
	* field("text").stringReplaceOne("foo", "bar");
	* ```
	*
	* @param find - The substring or byte sequence to search for.
	* @param replacement - The replacement string or byte sequence.
	* @returns A new `Expression` representing the string or byte array with the replacement.
	*/ stringReplaceOne(e, t) {
		return new y("string_replace_one", [
			this,
			__PRIVATE_valueToDefaultExpr(e),
			__PRIVATE_valueToDefaultExpr(t)
		], "stringReplaceOne");
	}
	/**
	* Creates an expression that concatenates expression results together.
	*
	* @example
	* ```typescript
	* // Combine the 'firstName', ' ', and 'lastName' fields into a single value.
	* field("firstName").concat(constant(" "), field("lastName"));
	* ```
	*
	* @param second - The additional expression or literal to concatenate.
	* @param others - Optional additional expressions or literals to concatenate.
	* @returns A new `Expression` representing the concatenated value.
	*/ concat(e, ...t) {
		const n = [e, ...t].map(__PRIVATE_valueToDefaultExpr);
		return new y("concat", [this, ...n], "concat");
	}
	/**
	* Creates an expression that reverses this string expression.
	*
	* @example
	* ```typescript
	* // Reverse the value of the 'myString' field.
	* field("myString").reverse();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the reversed string.
	*/ reverse() {
		return new y("reverse", [this], "reverse");
	}
	/**
	* Filters the array using a provided alias and predicate expression.
	*
	* @example
	* ```typescript
	* // Filter the 'items' array to only include those where the 'price' is greater than 10
	* field("items").arrayFilter('item', greaterThan(variable('item.price'), 10));
	* ```
	*
	* @param alias - The variable name to use for each element.
	* @param filter - The predicate boolean expression to filter by.
	* @returns A new `Expression` representing the filtered array.
	*/ arrayFilter(e, t) {
		return new y("array_filter", [
			this,
			__PRIVATE_valueToDefaultExpr(e),
			t
		], "arrayFilter");
	}
	/**
	* Creates an expression that applies a provided transformation to each element in an array.
	*
	* @example
	* ```typescript
	* // Transform the 'scores' array by multiplying each score by 10
	* field("scores").arrayTransform("score", multiply(variable("score"), 10));
	* ```
	*
	* @param elementAlias - The variable name to use for each element.
	* @param transform - The lambda expression used to transform the elements.
	* @returns A new `Expression` representing the arrayTransform operation.
	*/ arrayTransform(e, t) {
		return new y("array_transform", [
			this,
			__PRIVATE_valueToDefaultExpr(e),
			t
		], "arrayTransform");
	}
	/**
	* Creates an expression that applies a provided transformation to each element in an array, providing the element's index to the transformation expression.
	*
	* @example
	* ```typescript
	* // Transform the 'scores' array by adding the index to each score
	* field("scores").arrayTransformWithIndex("score", "i", add(variable("score"), variable("i")));
	* ```
	*
	* @param elementAlias - The variable name to use for each element.
	* @param indexAlias - The variable name to use for the current index.
	* @param transform - The lambda expression used to transform the elements.
	* @returns A new `Expression` representing the arrayTransformWithIndex operation.
	*/ arrayTransformWithIndex(e, t, n) {
		return new y("array_transform", [
			this,
			__PRIVATE_valueToDefaultExpr(e),
			__PRIVATE_valueToDefaultExpr(t),
			n
		], "arrayTransformWithIndex");
	}
	/**
	* Returns a subset of the array.
	*
	* @example
	* ```typescript
	* // Get 5 elements from the 'items' array starting from index 2
	* field("items").arraySlice(2, 5);
	*
	* // Get n number of elements from the 'items' array starting from index 2
	* field("items").arraySlice(2, field("count"));
	* ```
	*
	* @param offset - The starting offset.
	* @param length - The optional length of the slice.
	* @returns A new `Expression` representing the sliced array.
	*/ arraySlice(e, t) {
		const n = [this, __PRIVATE_valueToDefaultExpr(e)];
		return void 0 !== t && n.push(__PRIVATE_valueToDefaultExpr(t)), new y("array_slice", n, "arraySlice");
	}
	/**
	* Returns the first element of the array.
	*
	* @example
	* ```typescript
	* // Get the first element of the 'myArray' field.
	* field("myArray").arrayFirst();
	* ```
	*
	* @returns A new `Expression` representing the first element.
	*/ arrayFirst() {
		return new y("array_first", [this], "arrayFirst");
	}
	arrayFirstN(e) {
		return new y("array_first_n", [this, __PRIVATE_valueToDefaultExpr(e)], "arrayFirstN");
	}
	/**
	* Returns the last element of the array.
	*
	* @example
	* ```typescript
	* // Get the last element of the 'myArray' field.
	* field("myArray").arrayLast();
	* ```
	*
	* @returns A new `Expression` representing the last element.
	*/ arrayLast() {
		return new y("array_last", [this], "arrayLast");
	}
	arrayLastN(e) {
		return new y("array_last_n", [this, __PRIVATE_valueToDefaultExpr(e)], "arrayLastN");
	}
	/**
	* Returns the maximum value in the array.
	*
	* @example
	* ```typescript
	* // Get the maximum value of the 'myArray' field.
	* field("myArray").arrayMaximum();
	* ```
	*
	* @returns A new `Expression` representing the maximum value.
	*/ arrayMaximum() {
		return new y("maximum", [this], "arrayMaximum");
	}
	arrayMaximumN(e) {
		return new y("maximum_n", [this, __PRIVATE_valueToDefaultExpr(e)], "arrayMaximumN");
	}
	/**
	* Returns the minimum value in the array.
	*
	* @example
	* ```typescript
	* // Get the minimum value of the 'myArray' field.
	* field("myArray").arrayMinimum();
	* ```
	*
	* @returns A new `Expression` representing the minimum value.
	*/ arrayMinimum() {
		return new y("minimum", [this], "arrayMinimum");
	}
	arrayMinimumN(e) {
		return new y("minimum_n", [this, __PRIVATE_valueToDefaultExpr(e)], "arrayMinimumN");
	}
	arrayIndexOf(e) {
		return new y("array_index_of", [
			this,
			__PRIVATE_valueToDefaultExpr(e),
			__PRIVATE_valueToDefaultExpr("first")
		], "arrayIndexOf");
	}
	arrayLastIndexOf(e) {
		return new y("array_index_of", [
			this,
			__PRIVATE_valueToDefaultExpr(e),
			__PRIVATE_valueToDefaultExpr("last")
		], "arrayLastIndexOf");
	}
	arrayIndexOfAll(e) {
		return new y("array_index_of_all", [this, __PRIVATE_valueToDefaultExpr(e)], "arrayIndexOfAll");
	}
	/**
	* Creates an expression that calculates the length of this string expression in bytes.
	*
	* @example
	* ```typescript
	* // Calculate the length of the 'myString' field in bytes.
	* field("myString").byteLength();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the length of the string in bytes.
	*/ byteLength() {
		return new y("byte_length", [this], "byteLength");
	}
	/**
	* Creates an expression that computes the ceiling of a numeric value.
	*
	* @example
	* ```typescript
	* // Compute the ceiling of the 'price' field.
	* field("price").ceil();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the ceiling of the numeric value.
	*/ ceil() {
		return new y("ceil", [this]);
	}
	/**
	* Creates an expression that computes the floor of a numeric value.
	*
	* @example
	* ```typescript
	* // Compute the floor of the 'price' field.
	* field("price").floor();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the floor of the numeric value.
	*/ floor() {
		return new y("floor", [this]);
	}
	/**
	* Creates an expression that computes the absolute value of a numeric value.
	*
	* @example
	* ```typescript
	* // Compute the absolute value of the 'price' field.
	* field("price").abs();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the absolute value of the numeric value.
	*/ abs() {
		return new y("abs", [this]);
	}
	/**
	* Creates an expression that computes e to the power of this expression.
	*
	* @example
	* ```typescript
	* // Compute e to the power of the 'value' field.
	* field("value").exp();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the exp of the numeric value.
	*/ exp() {
		return new y("exp", [this]);
	}
	/**
	* Accesses a value from a map (object) field using the provided key.
	*
	* @example
	* ```typescript
	* // Get the 'city' value from the 'address' map field
	* field("address").mapGet("city");
	* ```
	*
	* @param subfield - The key to access in the map.
	* @returns A new `Expression` representing the value associated with the given key in the map.
	*/ mapGet(e) {
		return new y("map_get", [this, i(e)], "mapGet");
	}
	/**
	* Creates an expression that returns a new map with the specified entries added or updated.
	*
	* @remarks
	* Note that `mapSet` only performs shallow updates to the map. Setting a value to `null`
	* will retain the key with a `null` value. To remove a key entirely, use `mapRemove`.
	*
	* @example
	* ```typescript
	* // Set the 'city' to "San Francisco" in the 'address' map
	* field("address").mapSet("city", "San Francisco");
	* ```
	*
	* @param key - The key to set. Must be a string or a constant string expression.
	* @param value - The value to set.
	* @param moreKeyValues - Additional key-value pairs to set.
	* @returns A new `Expression` representing the map with the entries set.
	*/ mapSet(e, t, ...n) {
		return new y("map_set", [
			this,
			__PRIVATE_valueToDefaultExpr(e),
			__PRIVATE_valueToDefaultExpr(t),
			...n.map(__PRIVATE_valueToDefaultExpr)
		], "mapSet");
	}
	/**
	* Creates an expression that returns the keys of a map.
	*
	* @remarks
	* While the backend generally preserves insertion order, relying on the
	* order of the output array is not guaranteed and should be avoided.
	*
	* @example
	* ```typescript
	* // Get the keys of the 'address' map
	* field("address").mapKeys();
	* ```
	*
	* @returns A new `Expression` representing the keys of the map.
	*/ mapKeys() {
		return new y("map_keys", [this], "mapKeys");
	}
	/**
	* Creates an expression that returns the values of a map.
	*
	* @remarks
	* While the backend generally preserves insertion order, relying on the
	* order of the output array is not guaranteed and should be avoided.
	*
	* @example
	* ```typescript
	* // Get the values of the 'address' map
	* field("address").mapValues();
	* ```
	*
	* @returns A new `Expression` representing the values of the map.
	*/ mapValues() {
		return new y("map_values", [this], "mapValues");
	}
	/**
	* Creates an expression that returns the entries of a map as an array of maps,
	* where each map contains a `"k"` property for the key and a `"v"` property for the value.
	* For example: `[{ k: "key1", v: "value1" }, ...]`.
	*
	* @example
	* ```typescript
	* // Get the entries of the 'address' map
	* field("address").mapEntries();
	* ```
	*
	* @returns A new `Expression` representing the entries of the map.
	*/ mapEntries() {
		return new y("map_entries", [this], "mapEntries");
	}
	/**
	* @public
	* Creates an expression that returns the value of a field from the document that results from the evaluation of this expression.
	*
	* @example
	* ```typescript
	* // Get the value of the "city" field in the "address" document.
	* field("address").getField("city")
	* ```
	*
	* @param key The field to access in the document.
	* @returns A new `Expression` representing the value of the field in the document.
	*/ getField(e) {
		return new y("get_field", [this, __PRIVATE_valueToDefaultExpr(e)], "get_field");
	}
	/**
	* Creates an aggregation that counts the number of stage inputs with valid evaluations of the
	* expression or field.
	*
	* @example
	* ```typescript
	* // Count the total number of products
	* field("productId").count().as("totalProducts");
	* ```
	*
	* @returns A new `AggregateFunction` representing the 'count' aggregation.
	*/ count() {
		return k._create("count", [this], "count");
	}
	/**
	* Creates an aggregation that calculates the sum of a numeric field across multiple stage inputs.
	*
	* @example
	* ```typescript
	* // Calculate the total revenue from a set of orders
	* field("orderAmount").sum().as("totalRevenue");
	* ```
	*
	* @returns A new `AggregateFunction` representing the 'sum' aggregation.
	*/ sum() {
		return k._create("sum", [this], "sum");
	}
	/**
	* Creates an aggregation that calculates the average (mean) of a numeric field across multiple
	* stage inputs.
	*
	* @example
	* ```typescript
	* // Calculate the average age of users
	* field("age").average().as("averageAge");
	* ```
	*
	* @returns A new `AggregateFunction` representing the 'average' aggregation.
	*/ average() {
		return k._create("average", [this], "average");
	}
	/**
	* Creates an aggregation that finds the minimum value of a field across multiple stage inputs.
	*
	* @example
	* ```typescript
	* // Find the lowest price of all products
	* field("price").minimum().as("lowestPrice");
	* ```
	*
	* @returns A new `AggregateFunction` representing the 'minimum' aggregation.
	*/ minimum() {
		return k._create("minimum", [this], "minimum");
	}
	/**
	* Creates an aggregation that finds the maximum value of a field across multiple stage inputs.
	*
	* @example
	* ```typescript
	* // Find the highest score in a leaderboard
	* field("score").maximum().as("highestScore");
	* ```
	*
	* @returns A new `AggregateFunction` representing the 'maximum' aggregation.
	*/ maximum() {
		return k._create("maximum", [this], "maximum");
	}
	/**
	* Creates an aggregation that finds the first value of an expression across multiple stage inputs.
	*
	* @example
	* ```typescript
	* // Find the first value of the 'rating' field
	* field("rating").first().as("firstRating");
	* ```
	*
	* @returns A new `AggregateFunction` representing the 'first' aggregation.
	*/ first() {
		return k._create("first", [this], "first");
	}
	/**
	* Creates an aggregation that finds the last value of an expression across multiple stage inputs.
	*
	* @example
	* ```typescript
	* // Find the last value of the 'rating' field
	* field("rating").last().as("lastRating");
	* ```
	*
	* @returns A new `AggregateFunction` representing the 'last' aggregation.
	*/ last() {
		return k._create("last", [this], "last");
	}
	/**
	* Creates an aggregation that collects all values of an expression across multiple stage inputs
	* into an array.
	*
	* @remarks
	* If the expression resolves to an absent value, it is converted to `null`.
	* The order of elements in the output array is not stable and shouldn't be relied upon.
	*
	* @example
	* ```typescript
	* // Collect all tags from books into an array
	* field("tags").arrayAgg().as("allTags");
	* ```
	*
	* @returns A new `AggregateFunction` representing the 'array_agg' aggregation.
	*/ arrayAgg() {
		return k._create("array_agg", [this], "arrayAgg");
	}
	/**
	* Creates an aggregation that collects all distinct values of an expression across multiple stage
	* inputs into an array.
	*
	* @remarks
	* If the expression resolves to an absent value, it is converted to `null`.
	* The order of elements in the output array is not stable and shouldn't be relied upon.
	*
	* @example
	* ```typescript
	* // Collect all distinct tags from books into an array
	* field("tags").arrayAggDistinct().as("allDistinctTags");
	* ```
	*
	* @returns A new `AggregateFunction` representing the 'array_agg_distinct' aggregation.
	*/ arrayAggDistinct() {
		return k._create("array_agg_distinct", [this], "arrayAggDistinct");
	}
	/**
	* Creates an aggregation that counts the number of distinct values of the expression or field.
	*
	* @example
	* ```typescript
	* // Count the distinct number of products
	* field("productId").countDistinct().as("distinctProducts");
	* ```
	*
	* @returns A new `AggregateFunction` representing the 'count_distinct' aggregation.
	*/ countDistinct() {
		return k._create("count_distinct", [this], "countDistinct");
	}
	/**
	* Creates an expression that returns the larger value between this expression and another expression, based on Firestore's value type ordering.
	*
	* @example
	* ```typescript
	* // Returns the larger value between the 'timestamp' field and the current timestamp.
	* field("timestamp").logicalMaximum(currentTimestamp());
	* ```
	*
	* @param second - The second expression or literal to compare with.
	* @param others - Optional additional expressions or literals to compare with.
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the logical maximum operation.
	*/ logicalMaximum(e, ...t) {
		const n = [e, ...t];
		return new y("maximum", [this, ...n.map(__PRIVATE_valueToDefaultExpr)], "logicalMaximum");
	}
	/**
	* Creates an expression that returns the smaller value between this expression and another expression, based on Firestore's value type ordering.
	*
	* @example
	* ```typescript
	* // Returns the smaller value between the 'timestamp' field and the current timestamp.
	* field("timestamp").logicalMinimum(currentTimestamp());
	* ```
	*
	* @param second - The second expression or literal to compare with.
	* @param others - Optional additional expressions or literals to compare with.
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the logical minimum operation.
	*/ logicalMinimum(e, ...t) {
		const n = [e, ...t];
		return new y("minimum", [this, ...n.map(__PRIVATE_valueToDefaultExpr)], "minimum");
	}
	/**
	* Creates an expression that calculates the length (number of dimensions) of this Firestore Vector expression.
	*
	* @example
	* ```typescript
	* // Get the vector length (dimension) of the field 'embedding'.
	* field("embedding").vectorLength();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the length of the vector.
	*/ vectorLength() {
		return new y("vector_length", [this], "vectorLength");
	}
	cosineDistance(e) {
		return new y("cosine_distance", [this, __PRIVATE_vectorToExpr(e)], "cosineDistance");
	}
	dotProduct(e) {
		return new y("dot_product", [this, __PRIVATE_vectorToExpr(e)], "dotProduct");
	}
	euclideanDistance(e) {
		return new y("euclidean_distance", [this, __PRIVATE_vectorToExpr(e)], "euclideanDistance");
	}
	/**
	* Creates an expression that interprets this expression as the number of microseconds since the Unix epoch (1970-01-01 00:00:00 UTC)
	* and returns a timestamp.
	*
	* @example
	* ```typescript
	* // Interpret the 'microseconds' field as microseconds since epoch.
	* field("microseconds").unixMicrosToTimestamp();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the timestamp.
	*/ unixMicrosToTimestamp() {
		return new y("unix_micros_to_timestamp", [this], "unixMicrosToTimestamp");
	}
	/**
	* Creates an expression that converts this timestamp expression to the number of microseconds since the Unix epoch (1970-01-01 00:00:00 UTC).
	*
	* @example
	* ```typescript
	* // Convert the 'timestamp' field to microseconds since epoch.
	* field("timestamp").timestampToUnixMicros();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the number of microseconds since epoch.
	*/ timestampToUnixMicros() {
		return new y("timestamp_to_unix_micros", [this], "timestampToUnixMicros");
	}
	/**
	* Creates an expression that interprets this expression as the number of milliseconds since the Unix epoch (1970-01-01 00:00:00 UTC)
	* and returns a timestamp.
	*
	* @example
	* ```typescript
	* // Interpret the 'milliseconds' field as milliseconds since epoch.
	* field("milliseconds").unixMillisToTimestamp();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the timestamp.
	*/ unixMillisToTimestamp() {
		return new y("unix_millis_to_timestamp", [this], "unixMillisToTimestamp");
	}
	/**
	* Creates an expression that converts this timestamp expression to the number of milliseconds since the Unix epoch (1970-01-01 00:00:00 UTC).
	*
	* @example
	* ```typescript
	* // Convert the 'timestamp' field to milliseconds since epoch.
	* field("timestamp").timestampToUnixMillis();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the number of milliseconds since epoch.
	*/ timestampToUnixMillis() {
		return new y("timestamp_to_unix_millis", [this], "timestampToUnixMillis");
	}
	/**
	* Creates an expression that interprets this expression as the number of seconds since the Unix epoch (1970-01-01 00:00:00 UTC)
	* and returns a timestamp.
	*
	* @example
	* ```typescript
	* // Interpret the 'seconds' field as seconds since epoch.
	* field("seconds").unixSecondsToTimestamp();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the timestamp.
	*/ unixSecondsToTimestamp() {
		return new y("unix_seconds_to_timestamp", [this], "unixSecondsToTimestamp");
	}
	/**
	* Creates an expression that converts this timestamp expression to the number of seconds since the Unix epoch (1970-01-01 00:00:00 UTC).
	*
	* @example
	* ```typescript
	* // Convert the 'timestamp' field to seconds since epoch.
	* field("timestamp").timestampToUnixSeconds();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the number of seconds since epoch.
	*/ timestampToUnixSeconds() {
		return new y("timestamp_to_unix_seconds", [this], "timestampToUnixSeconds");
	}
	timestampAdd(e, t) {
		return new y("timestamp_add", [
			this,
			__PRIVATE_valueToDefaultExpr(e),
			__PRIVATE_valueToDefaultExpr(t)
		], "timestampAdd");
	}
	timestampSubtract(e, t) {
		return new y("timestamp_subtract", [
			this,
			__PRIVATE_valueToDefaultExpr(e),
			__PRIVATE_valueToDefaultExpr(t)
		], "timestampSubtract");
	}
	timestampDiff(e, t) {
		return new y("timestamp_diff", [
			this,
			__PRIVATE_fieldOrExpression(e),
			__PRIVATE_valueToDefaultExpr(t)
		], "timestampDiff");
	}
	timestampExtract(e, t) {
		const n = [this, __PRIVATE_valueToDefaultExpr(e)];
		return t && n.push(__PRIVATE_valueToDefaultExpr(t)), new y("timestamp_extract", n, "timestampExtract");
	}
	/**
	*
	* Creates an expression that returns the document ID from a path.
	*
	* @example
	* ```typescript
	* // Get the document ID from a path.
	* field("__path__").documentId();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the documentId operation.
	*/ documentId() {
		return new y("document_id", [this], "documentId");
	}
	/**
	*
	* Creates an expression that returns the parent document reference of a document reference.
	*
	* @example
	* ```typescript
	* // Get the parent document reference of a document reference.
	* field("__path__").parent();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the parent operation.
	*/ parent() {
		return new y("parent", [this], "parent");
	}
	substring(e, t) {
		const n = __PRIVATE_valueToDefaultExpr(e);
		return new y("substring", void 0 === t ? [this, n] : [
			this,
			n,
			__PRIVATE_valueToDefaultExpr(t)
		], "substring");
	}
	arrayGet(e) {
		return new y("array_get", [this, __PRIVATE_valueToDefaultExpr(e)], "arrayGet");
	}
	/**
	*
	* Creates an expression that checks if a given expression produces an error.
	*
	* @example
	* ```typescript
	* // Check if the result of a calculation is an error
	* field("title").arrayContains(1).isError();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#BooleanExpression} representing the 'isError' check.
	*/ isError() {
		return new y("is_error", [this], "isError").asBoolean();
	}
	ifError(e) {
		const t = new y("if_error", [this, __PRIVATE_valueToDefaultExpr(e)], "ifError");
		return e instanceof BooleanExpression ? t.asBoolean() : t;
	}
	/**
	*
	* Creates an expression that returns `true` if the result of this expression
	* is absent. Otherwise, returns `false` even if the value is `null`.
	*
	* @example
	* ```typescript
	* // Check if the field `value` is absent.
	* field("value").isAbsent();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#BooleanExpression} representing the 'isAbsent' check.
	*/ isAbsent() {
		return new y("is_absent", [this], "isAbsent").asBoolean();
	}
	mapRemove(e) {
		return new y("map_remove", [this, __PRIVATE_valueToDefaultExpr(e)], "mapRemove");
	}
	/**
	*
	* Creates an expression that merges multiple map values.
	*
	* @example
	* ```
	* // Merges the map in the settings field with, a map literal, and a map in
	* // that is conditionally returned by another expression
	* field('settings').mapMerge({ enabled: true }, conditional(field('isAdmin'), { admin: true}, {})
	* ```
	*
	* @param secondMap - A required second map to merge. Represented as a literal or
	* an expression that returns a map.
	* @param otherMaps - Optional additional maps to merge. Each map is represented
	* as a literal or an expression that returns a map.
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the 'mapMerge' operation.
	*/ mapMerge(e, ...t) {
		const n = __PRIVATE_valueToDefaultExpr(e), r = t.map(__PRIVATE_valueToDefaultExpr);
		return new y("map_merge", [
			this,
			n,
			...r
		], "mapMerge");
	}
	pow(e) {
		return new y("pow", [this, __PRIVATE_valueToDefaultExpr(e)]);
	}
	trunc(e) {
		return void 0 === e ? new y("trunc", [this]) : new y("trunc", [this, __PRIVATE_valueToDefaultExpr(e)], "trunc");
	}
	round(e) {
		return void 0 === e ? new y("round", [this]) : new y("round", [this, __PRIVATE_valueToDefaultExpr(e)], "round");
	}
	/**
	* Creates an expression that returns the collection ID from a path.
	*
	* @example
	* ```typescript
	* // Get the collection ID from a path.
	* field("__path__").collectionId();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the collectionId operation.
	*/ collectionId() {
		return new y("collection_id", [this]);
	}
	/**
	* Creates an expression that calculates the length of a string, array, map, vector, or bytes.
	*
	* @example
	* ```typescript
	* // Get the length of the 'name' field.
	* field("name").length();
	*
	* // Get the number of items in the 'cart' array.
	* field("cart").length();
	* ```
	*
	* @returns A new `Expression` representing the length of the string, array, map, vector, or bytes.
	*/ length() {
		return new y("length", [this]);
	}
	/**
	* Creates an expression that computes the natural logarithm of a numeric value.
	*
	* @example
	* ```typescript
	* // Compute the natural logarithm of the 'value' field.
	* field("value").ln();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the natural logarithm of the numeric value.
	*/ ln() {
		return new y("ln", [this]);
	}
	/**
	* Creates an expression that computes the square root of a numeric value.
	*
	* @example
	* ```typescript
	* // Compute the square root of the 'value' field.
	* field("value").sqrt();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the square root of the numeric value.
	*/ sqrt() {
		return new y("sqrt", [this]);
	}
	/**
	* Creates an expression that reverses a string.
	*
	* @example
	* ```typescript
	* // Reverse the value of the 'myString' field.
	* field("myString").stringReverse();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the reversed string.
	*/ stringReverse() {
		return new y("string_reverse", [this]);
	}
	ifAbsent(e) {
		return new y("if_absent", [this, __PRIVATE_valueToDefaultExpr(e)], "ifAbsent");
	}
	ifNull(e) {
		return new y("if_null", [this, __PRIVATE_valueToDefaultExpr(e)], "ifNull");
	}
	/**
	* Creates an expression that returns the first non-null, non-absent argument, without evaluating
	* the rest of the arguments. When all arguments are null or absent, returns the last argument.
	*
	* @example
	* ```typescript
	* // Returns the value of the first non-null, non-absent field among 'preferredName', 'fullName',
	* // or the last argument if all previous fields are null.
	* field("preferredName").coalesce(field("fullName"), "Anonymous");
	* ```
	*
	* @param replacement - The value to use if this expression evaluates to null.
	* @param others - Optional additional values to check if previous values are null.
	* @returns A new `Expression` representing the coalesce operation.
	*/ coalesce(e, ...t) {
		return new y("coalesce", [
			this,
			__PRIVATE_valueToDefaultExpr(e),
			...t.map(__PRIVATE_valueToDefaultExpr)
		], "coalesce");
	}
	join(e) {
		return new y("join", [this, __PRIVATE_valueToDefaultExpr(e)], "join");
	}
	/**
	* Creates an expression that computes the base-10 logarithm of a numeric value.
	*
	* @example
	* ```typescript
	* // Compute the base-10 logarithm of the 'value' field.
	* field("value").log10();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the base-10 logarithm of the numeric value.
	*/ log10() {
		return new y("log10", [this]);
	}
	/**
	* Creates an expression that computes the sum of the elements in an array.
	*
	* @example
	* ```typescript
	* // Compute the sum of the elements in the 'scores' field.
	* field("scores").arraySum();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the sum of the elements in the array.
	*/ arraySum() {
		return new y("sum", [this]);
	}
	split(e) {
		return new y("split", [this, __PRIVATE_valueToDefaultExpr(e)]);
	}
	timestampTruncate(e, t) {
		const n = [this, __PRIVATE_valueToDefaultExpr(e)];
		return t && n.push(__PRIVATE_valueToDefaultExpr(t)), new y("timestamp_trunc", n);
	}
	/**
	* Creates an {@link @firebase/firestore/pipelines#Ordering} that sorts documents in ascending order based on this expression.
	*
	* @example
	* ```typescript
	* // Sort documents by the 'name' field in ascending order
	* firestore.pipeline().collection("users")
	*   .sort(field("name").ascending());
	* ```
	*
	* @returns A new `Ordering` for ascending sorting.
	*/
	ascending() {
		return ascending(this);
	}
	/**
	* Creates an {@link @firebase/firestore/pipelines#Ordering} that sorts documents in descending order based on this expression.
	*
	* @example
	* ```typescript
	* // Sort documents by the 'createdAt' field in descending order
	* firestore.pipeline().collection("users")
	*   .sort(field("createdAt").descending());
	* ```
	*
	* @returns A new `Ordering` for descending sorting.
	*/ descending() {
		return descending(this);
	}
	/**
	* Assigns an alias to this expression.
	*
	* Aliases are useful for renaming fields in the output of a stage or for giving meaningful
	* names to calculated values.
	*
	* @example
	* ```typescript
	* // Calculate the total price and assign it the alias "totalPrice" and add it to the output.
	* firestore.pipeline().collection("items")
	*   .addFields(field("price").multiply(field("quantity")).as("totalPrice"));
	* ```
	*
	* @param name - The alias to assign to this expression.
	* @returns A new {@link @firebase/firestore/pipelines#AliasedExpression} that wraps this
	*     expression and associates it with the provided alias.
	*/ as(e) {
		return new c(this, e, "as");
	}
};
/**
*
* A class that represents an aggregate function.
*/ var k = class k {
	constructor(e, t) {
		this.name = e, this.params = t, this.exprType = "AggregateFunction", this._protoValueType = "ProtoValue";
	}
	/**
	* @internal
	* @private
	*/ static _create(e, t, n) {
		const r = new k(e, t);
		return r._methodName = n, r;
	}
	/**
	* Assigns an alias to this AggregateFunction. The alias specifies the name that
	* the aggregated value will have in the output document.
	*
	* @example
	* ```typescript
	* // Calculate the average price of all items and assign it the alias "averagePrice".
	* firestore.pipeline().collection("items")
	*   .aggregate(field("price").average().as("averagePrice"));
	* ```
	*
	* @param name - The alias to assign to this AggregateFunction.
	* @returns A new {@link @firebase/firestore/pipelines#AliasedAggregate} that wraps this
	*     AggregateFunction and associates it with the provided alias.
	*/ as(e) {
		return new AliasedAggregate(this, e, "as");
	}
	/**
	* @private
	* @internal
	*/ _toProto(e) {
		return { functionValue: {
			name: this.name,
			args: this.params.map(((t) => t._toProto(e)))
		} };
	}
	/**
	* @private
	* @internal
	*/ _readUserData(e) {
		e = this._methodName ? e.contextWith({ methodName: this._methodName }) : e, this.params.forEach(((t) => t._readUserData(e)));
	}
};
/**
*
* An AggregateFunction with alias.
*/ var AliasedAggregate = class {
	constructor(e, t, n) {
		this.aggregate = e, this.alias = t, this._methodName = n;
	}
	/**
	* @private
	* @internal
	*/ _readUserData(e) {
		this.aggregate._readUserData(e);
	}
};
var c = class {
	constructor(e, t, n) {
		this.expr = e, this.alias = t, this._methodName = n, this.exprType = "AliasedExpression", this.selectable = true;
	}
	/**
	* @private
	* @internal
	*/ _readUserData(e) {
		this.expr._readUserData(e);
	}
};
/**
* @internal
*/ var __PRIVATE_ListOfExprs = class extends t {
	constructor(e, t) {
		super(), this.fi = e, this._methodName = t, this.expressionType = "ListOfExpressions";
	}
	/**
	* @private
	* @internal
	*/ _toProto(e) {
		return { arrayValue: { values: this.fi.map(((t) => t._toProto(e))) } };
	}
	/**
	* @private
	* @internal
	*/ _readUserData(e) {
		this.fi.forEach(((t) => t._readUserData(e)));
	}
};
/**
*
* Represents a reference to a field in a Firestore document, or outputs of a {@link @firebase/firestore/pipelines#Pipeline} stage.
*
* <p>Field references are used to access document field values in expressions and to specify fields
* for sorting, filtering, and projecting data in Firestore pipelines.
*
* <p>You can create a `Field` instance using the static {@link @firebase/firestore/pipelines#(field:1) | field} method:
*
* @example
* ```typescript
* // Create a Field instance for the 'name' field
* const nameField = field("name");
*
* // Create a Field instance for a nested field 'address.city'
* const cityField = field("address.city");
* ```
*/ var o = class extends t {
	/**
	* @internal
	* @private
	* @hideconstructor
	* @param fieldPath
	*/
	constructor(e, t) {
		super(), this.fieldPath = e, this._methodName = t, this.expressionType = "Field", this.selectable = true;
	}
	get _fieldPath() {
		return this.fieldPath;
	}
	get fieldName() {
		return this.fieldPath.canonicalString();
	}
	get alias() {
		return this.fieldName;
	}
	get expr() {
		return this;
	}
	/**
	* @beta
	* Evaluates to the distance in meters between the location specified
	* by this field and the query location.
	*
	* @remarks This Expression can only be used within a `search` stage.
	*
	* @param location - Compute distance to this GeoPoint.
	*/
	geoDistance(e) {
		return new y("geo_distance", [this, __PRIVATE_valueToDefaultExpr(e)], "geoDistance");
	}
	/**
	* @private
	* @internal
	*/ _toProto(e) {
		return { fieldReferenceValue: this.fieldPath.canonicalString() };
	}
	/**
	* @private
	* @internal
	*/ _readUserData(e) {}
};
function s(e) {
	return G(e, "field");
}
function G(e, t) {
	return new o("string" == typeof e ? Fe === e ? documentId$1()._internalPath : K("field", e) : e._internalPath, t);
}
/**
* @internal
*
* Represents a constant value that can be used in a Firestore pipeline expression.
*
* You can create a `Constant` instance using the static {@link @firebase/firestore/pipelines#(constant:1) | constant} method:
*
* @example
* ```typescript
* // Create a Constant instance for the number 10
* const ten = constant(10);
*
* // Create a Constant instance for the string "hello"
* const hello = constant("hello");
* ```
*/ var Constant = class Constant extends t {
	/**
	* @private
	* @internal
	* @hideconstructor
	* @param value - The value of the constant.
	*/
	constructor(e, t) {
		super(), this.value = e, this._methodName = t, this.expressionType = "Constant";
	}
	/**
	* @private
	* @internal
	*/ static _fromProto(e) {
		const t = new Constant(e, void 0);
		return t._protoValue = e, t;
	}
	/**
	* @private
	* @internal
	*/ _toProto(e) {
		return __PRIVATE_hardAssert(void 0 !== this._protoValue, 237), this._protoValue;
	}
	_getValue() {
		return this._protoValue;
	}
	/**
	* @private
	* @internal
	*/ _readUserData(e) {
		e = this._methodName ? e.contextWith({ methodName: this._methodName }) : e, u(this._protoValue) || (this._protoValue = __PRIVATE_parseData(this.value, e));
	}
};
function i(e, t) {
	return m(e, "constant");
}
/**
* @internal
* @private
* @param value
* @param methodName
*/ function m(e, t) {
	const n = new Constant(e, t);
	return "boolean" == typeof e ? new __PRIVATE_BooleanConstant(n) : n;
}
/**
*
* This class defines the base class for Firestore {@link @firebase/firestore/pipelines#Pipeline} functions, which can be evaluated within pipeline
* execution.
*
* Typically, you would not use this class or its children directly. Use either the functions like {@link @firebase/firestore/pipelines#and}, {@link @firebase/firestore/pipelines#(equal:1)},
* or the methods on {@link @firebase/firestore/pipelines#Expression} ({@link @firebase/firestore/pipelines#Expression.(equal:1)}, {@link @firebase/firestore/pipelines#Expression.(lessThan:1)}, etc.) to construct new Function instances.
*/ var y = class extends t {
	/**
	* @hideconstructor
	*/
	constructor(e, t, n, r) {
		super(), this.name = e, this.params = t, this.expressionType = "Function", this._optionsProto = void 0, void 0 !== n && (this._methodName = n), void 0 !== r && (this._options = r);
	}
	/**
	* @private
	* @internal
	*/ get _optionsUtil() {
		return new OptionsUtil({});
	}
	/**
	* @private
	* @internal
	*/ _toProto(e) {
		const t = { functionValue: {
			name: this.name,
			args: this.params.map(((t) => t._toProto(e)))
		} };
		return this._optionsProto && (t.functionValue.options = this._optionsProto), t;
	}
	/**
	* @private
	* @internal
	*/ _readUserData(e) {
		e = this._methodName ? e.contextWith({ methodName: this._methodName }) : e, this.params.forEach(((t) => t._readUserData(e))), this._options && (this._optionsProto = this._optionsUtil.getOptionsProto(e, this._options));
	}
};
/**
*
* An interface that represents a filter condition.
*/ var BooleanExpression = class BooleanExpression extends t {
	get _methodName() {
		return this._expr._methodName;
	}
	/**
	* Creates an aggregation that finds the count of input documents satisfying
	* this boolean expression.
	*
	* @example
	* ```typescript
	* // Find the count of documents with a score greater than 90
	* field("score").greaterThan(90).countIf().as("highestScore");
	* ```
	*
	* @returns A new `AggregateFunction` representing the 'countIf' aggregation.
	*/ countIf() {
		return k._create("count_if", [this], "countIf");
	}
	/**
	* Creates an expression that negates this boolean expression.
	*
	* @example
	* ```typescript
	* // Find documents where the 'tags' field does not contain 'completed'
	* field("tags").arrayContains("completed").not();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the negated filter condition.
	*/ not() {
		return new y("not", [this], "not").asBoolean();
	}
	/**
	* Creates a conditional expression that evaluates to the 'then' expression
	* if `this` expression evaluates to `true`,
	* or evaluates to the 'else' expression if `this` expressions evaluates `false`.
	*
	* @example
	* ```typescript
	* // If 'age' is greater than 18, return "Adult"; otherwise, return "Minor".
	* field("age").greaterThanOrEqual(18).conditional(constant("Adult"), constant("Minor"));
	* ```
	*
	* @param thenExpr - The expression to evaluate if the condition is true.
	* @param elseExpr - The expression to evaluate if the condition is false.
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the conditional expression.
	*/ conditional(e, t) {
		return new y("conditional", [
			this,
			e,
			t
		], "conditional");
	}
	ifError(e) {
		const t = __PRIVATE_valueToDefaultExpr(e), n = new y("if_error", [this, t], "ifError");
		return t instanceof BooleanExpression ? n.asBoolean() : n;
	}
	/**
	* @private
	* @internal
	*/ _toProto(e) {
		return this._expr._toProto(e);
	}
	/**
	* @private
	* @internal
	*/ _readUserData(e) {
		this._expr._readUserData(e);
	}
};
var __PRIVATE_BooleanFunctionExpression = class extends BooleanExpression {
	constructor(e) {
		super(), this._expr = e, this.expressionType = "Function";
	}
};
var __PRIVATE_BooleanConstant = class extends BooleanExpression {
	constructor(e) {
		super(), this._expr = e, this.expressionType = "Constant";
	}
	_getValue() {
		return this._expr._getValue();
	}
};
var __PRIVATE_BooleanField = class extends BooleanExpression {
	constructor(e) {
		super(), this._expr = e, this.expressionType = "Field";
	}
};
function __PRIVATE__map(e, t) {
	const n = [];
	for (const t in e) if (Object.prototype.hasOwnProperty.call(e, t)) {
		const r = e[t];
		n.push(i(t)), n.push(__PRIVATE_valueToDefaultExpr(r));
	}
	return new y("map", n, "map");
}
/**
*
* Creates an expression that creates a Firestore array value from an input array.
*
* @example
* ```typescript
* // Create an array value from the input array and reference the 'baz' field value from the input document.
* array(['bar', field('baz')]).as('foo');
* ```
*
* @param elements - The input array to evaluate in the expression.
* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the array function.
*/ function b(e) {
	return function __PRIVATE__array(e, t) {
		return new y("array", e.map(((e) => __PRIVATE_valueToDefaultExpr(e))), t);
	}(e, "array");
}
function ascending(e) {
	return new Ordering(__PRIVATE_fieldOrExpression(e), "ascending", "ascending");
}
function descending(e) {
	return new Ordering(__PRIVATE_fieldOrExpression(e), "descending", "descending");
}
/**
*
* Represents an ordering criterion for sorting documents in a Firestore pipeline.
*
* You create `Ordering` instances using the `ascending` and `descending` helper functions.
*/ var Ordering = class {
	constructor(e, t, n) {
		this.expr = e, this.direction = t, this._methodName = n, this._protoValueType = "ProtoValue";
	}
	/**
	* @private
	* @internal
	*/ _toProto(e) {
		return { mapValue: { fields: {
			direction: __PRIVATE_toStringValue(this.direction),
			expression: this.expr._toProto(e)
		} } };
	}
	/**
	* @private
	* @internal
	*/ _readUserData(e) {
		this.expr._readUserData(e);
	}
};
/**
* @license
* Copyright 2024 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var Stage = class {
	constructor(e) {
		/**
		* Store _optionsProto parsed by _readUserData.
		* @private
		* @internal
		* @protected
		*/
		this.optionsProto = void 0, {rawOptions: this.rawOptions, ...this.knownOptions} = e;
	}
	_readUserData(e) {
		this.optionsProto = this._optionsUtil.getOptionsProto(e, this.knownOptions, this.rawOptions);
	}
	_toProto(e) {
		return {
			name: this._name,
			options: this.optionsProto
		};
	}
};
var w = class extends Stage {
	get _name() {
		return "add_fields";
	}
	get _optionsUtil() {
		return new OptionsUtil({});
	}
	constructor(e, t) {
		super(t), this.fields = e;
	}
	_toProto(e) {
		return {
			...super._toProto(e),
			args: [toMapValue(e, this.fields)]
		};
	}
	_readUserData(e) {
		super._readUserData(e), __PRIVATE_readUserDataHelper(this.fields, e);
	}
};
var O = class extends Stage {
	get _name() {
		return "aggregate";
	}
	get _optionsUtil() {
		return new OptionsUtil({});
	}
	constructor(e, t, n) {
		super(n), this.groups = e, this.accumulators = t;
	}
	/**
	* @internal
	* @private
	*/ _toProto(e) {
		return {
			...super._toProto(e),
			args: [toMapValue(e, this.accumulators), toMapValue(e, this.groups)]
		};
	}
	_readUserData(e) {
		super._readUserData(e), __PRIVATE_readUserDataHelper(this.groups, e), __PRIVATE_readUserDataHelper(this.accumulators, e);
	}
};
var M = class extends Stage {
	get _name() {
		return "distinct";
	}
	get _optionsUtil() {
		return new OptionsUtil({});
	}
	constructor(e, t) {
		super(t), this.groups = e;
	}
	/**
	* @internal
	* @private
	*/ _toProto(e) {
		return {
			...super._toProto(e),
			args: [toMapValue(e, this.groups)]
		};
	}
	_readUserData(e) {
		super._readUserData(e), __PRIVATE_readUserDataHelper(this.groups, e);
	}
};
var X = class extends Stage {
	get _name() {
		return "collection";
	}
	get _optionsUtil() {
		return new OptionsUtil({ forceIndex: { serverName: "force_index" } });
	}
	constructor(e, t) {
		super(t), this.pi = e.startsWith("/") ? e : "/" + e;
	}
	/**
	* @internal
	* @private
	*/ _toProto(e) {
		return {
			...super._toProto(e),
			args: [{ referenceValue: this.pi }]
		};
	}
	_readUserData(e) {
		super._readUserData(e);
	}
};
var Y = class extends Stage {
	get _name() {
		return "collection_group";
	}
	get _optionsUtil() {
		return new OptionsUtil({ forceIndex: { serverName: "force_index" } });
	}
	constructor(e, t) {
		super(t), this.collectionId = e;
	}
	/**
	* @internal
	* @private
	*/ _toProto(e) {
		return {
			...super._toProto(e),
			args: [{ referenceValue: "" }, { stringValue: this.collectionId }]
		};
	}
	_readUserData(e) {
		super._readUserData(e);
	}
};
var Z = class extends Stage {
	get _name() {
		return "database";
	}
	get _optionsUtil() {
		return new OptionsUtil({});
	}
	/**
	* @internal
	* @private
	*/ _toProto(e) {
		return { ...super._toProto(e) };
	}
	_readUserData(e) {
		super._readUserData(e);
	}
};
var sa = class extends Stage {
	get _name() {
		return "documents";
	}
	get _optionsUtil() {
		return new OptionsUtil({});
	}
	constructor(t, n) {
		if (super(n), !t || 0 === t.length) throw new e(ta.INVALID_ARGUMENT, "Empty document paths are not allowed in DocumentsSource");
		const r = t.map(((e) => e.startsWith("/") ? e : "/" + e)), i = new Set(r);
		if (i.size !== r.length) throw new e(ta.INVALID_ARGUMENT, "Duplicate document paths are not allowed in DocumentsSource");
		this.gi = r, this.yi = i;
	}
	/**
	* @internal
	* @private
	*/ _toProto(e) {
		return {
			...super._toProto(e),
			args: this.gi.map(((e) => ({ referenceValue: e })))
		};
	}
	_readUserData(e) {
		super._readUserData(e);
	}
};
var A = class extends Stage {
	get _name() {
		return "where";
	}
	get _optionsUtil() {
		return new OptionsUtil({});
	}
	constructor(e, t) {
		super(t), this.condition = e;
	}
	/**
	* @internal
	* @private
	*/ _toProto(e) {
		return {
			...super._toProto(e),
			args: [this.condition._toProto(e)]
		};
	}
	_readUserData(e) {
		super._readUserData(e), __PRIVATE_readUserDataHelper(this.condition, e);
	}
};
var v = class extends Stage {
	get _name() {
		return "limit";
	}
	get _optionsUtil() {
		return new OptionsUtil({});
	}
	constructor(e, t) {
		__PRIVATE_hardAssert(!isNaN(e) && e !== 1 / 0 && e !== -1 / 0, 34860), super(t), this.limit = e;
	}
	/**
	* @internal
	* @private
	*/ _toProto(e) {
		return {
			...super._toProto(e),
			args: [toNumber(e, this.limit)]
		};
	}
};
var I = class extends Stage {
	get _name() {
		return "offset";
	}
	get _optionsUtil() {
		return new OptionsUtil({});
	}
	constructor(e, t) {
		super(t), this.offset = e;
	}
	/**
	* @internal
	* @private
	*/ _toProto(e) {
		return {
			...super._toProto(e),
			args: [toNumber(e, this.offset)]
		};
	}
};
var x = class extends Stage {
	get _name() {
		return "select";
	}
	get _optionsUtil() {
		return new OptionsUtil({});
	}
	constructor(e, t) {
		super(t), this.selections = e;
	}
	/**
	* @internal
	* @private
	*/ _toProto(e) {
		return {
			...super._toProto(e),
			args: [toMapValue(e, this.selections)]
		};
	}
	_readUserData(e) {
		super._readUserData(e), __PRIVATE_readUserDataHelper(this.selections, e);
	}
};
var L = class extends Stage {
	get _name() {
		return "sort";
	}
	get _optionsUtil() {
		return new OptionsUtil({});
	}
	constructor(e, t) {
		super(t), this.orderings = e;
	}
	/**
	* @internal
	* @private
	*/ _toProto(e) {
		return {
			...super._toProto(e),
			args: this.orderings.map(((t) => t._toProto(e)))
		};
	}
	_readUserData(e) {
		super._readUserData(e), __PRIVATE_readUserDataHelper(this.orderings, e);
	}
};
var $ = class $ extends Stage {
	get _name() {
		return "replace_with";
	}
	get _optionsUtil() {
		return new OptionsUtil({});
	}
	constructor(e, t) {
		super(t), this.map = e;
	}
	_toProto(e) {
		return {
			...super._toProto(e),
			args: [this.map._toProto(e), __PRIVATE_toStringValue($.wi)]
		};
	}
	_readUserData(e) {
		super._readUserData(e), __PRIVATE_readUserDataHelper(this.map, e);
	}
};
$.wi = "full_replace";
/**
* Helper to read user data across a number of different formats.
* @param name - Name of the calling function. Used for error messages when invalid user data is encountered.
* @param expressionMap
* @returns the expressionMap argument.
* @private
*/ function __PRIVATE_readUserDataHelper(e, t) {
	return __PRIVATE_isUserData(e) ? e._readUserData(t) : Array.isArray(e) ? e.forEach(((e) => e._readUserData(t))) : e instanceof Map ? e.forEach(((e) => e._readUserData(t))) : Object.values(e).forEach(((e) => e._readUserData(t))), e;
}
/**
* @license
* Copyright 2026 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @beta
* @internal
*
* The RealtimePipeline class provides a flexible and expressive framework for building complex data
* transformation and query pipelines that can be used with Firestore's real-time and offline capabilities.
*
* A RealtimePipeline takes data sources, such as Firestore collections or collection groups, and applies
* a series of stages that are chained together. Each stage takes the output from the previous stage
* (or the data source) and produces an output for the next stage (or as the final output of the
* pipeline).
*
* Expressions can be used within each stage to filter and transform data through the stage.
*
* NOTE: Both the initial and subsequent snapshots for RealtimePipeline take the consideration of the SDK's cache.
* They might include results that have not been synchronized with the server yet, and wait for subsequent snapshots
* to reflect the latest server state, this is the same as classic Firestore {@link Query}.
* This behavior is different from the {@link Pipeline} class, which does not take the consideration of the SDK's cache.
*
* Usage Examples:
*
* ```typescript
* const db: Firestore; // Assumes a valid firestore instance.
*
* // Example 1: Listen to books published after 1980
* const unsubscribe = onRealtimePipelineSnapshot(db.realtimePipeline()
*     .collection("books")
*     .where(field("published").gt(1980)),
*     (snapshot) => {
*       // Handle the snapshot
*     }
* );
* ```
*/
var __PRIVATE_RealtimePipeline = class __PRIVATE_RealtimePipeline {
	/**
	* @internal
	* @private
	* @param _db
	* @param userDataReader
	* @param _userDataWriter
	* @param _documentReferenceFactory
	* @param stages
	*/
	constructor(e, t, n, r) {
		this._db = e, this.userDataReader = t, this._userDataWriter = n, this.stages = r;
	}
	/**
	* Reads user data for each expression in the expressionMap.
	* @param name Name of the calling function. Used for error messages when invalid user data is encountered.
	* @param expressionMap
	* @return the expressionMap argument.
	* @private
	* @internal
	*/ xi(e, t) {
		const n = this.userDataReader.createContext(3, e);
		return __PRIVATE_isUserData(t) ? t._readUserData(n) : Array.isArray(t) ? t.forEach(((e) => e._readUserData(n))) : t.forEach(((e) => e._readUserData(n))), t;
	}
	where(e) {
		const t = this.stages.map(((e) => e));
		return this.xi("where", e), t.push(new A(e, {})), new __PRIVATE_RealtimePipeline(this._db, this.userDataReader, this._userDataWriter, t);
	}
	limit(e) {
		const t = this.stages.map(((e) => e));
		return t.push(new v(e, {})), new __PRIVATE_RealtimePipeline(this._db, this.userDataReader, this._userDataWriter, t);
	}
	sort(e, ...t) {
		const n = this.stages.map(((e) => e));
		return "orderings" in e ? n.push(new L(this.xi("sort", e.orderings), {})) : n.push(new L(this.xi("sort", [e, ...t]), {})), new __PRIVATE_RealtimePipeline(this._db, this.userDataReader, this._userDataWriter, n);
	}
	/**
	* @internal
	* @private
	*/ Di(e) {
		return { pipeline: { stages: this.stages.map(((t) => t._toProto(e))) } };
	}
};
// Copyright 2024 Google LLC* @license
var CorePipeline = class {
	constructor(e, t, n) {
		this.serializer = e, this.stages = t, this.listenOptions = n, this.isCorePipeline = true;
	}
	getPipelineCollection() {
		return getPipelineCollection(this);
	}
	getPipelineCollectionGroup() {
		return getPipelineCollectionGroup(this);
	}
	getPipelineCollectionId() {
		return getPipelineCollectionId(this);
	}
	getPipelineDocuments() {
		return getPipelineDocuments(this);
	}
	getPipelineFlavor() {
		return function getPipelineFlavor(e) {
			let t = "exact";
			return e.stages.forEach(((n, r) => {
				n._name !== M.name && n._name !== O.name || (t = "keyless"), n._name === x.name && "exact" === t && (t = "augmented"), n._name === w.name && r < e.stages.length - 1 && "exact" === t && (t = "augmented");
			})), t;
		}(this);
		// Copyright 2024 Google LLC* @license
	}
	getPipelineSourceType() {
		return getPipelineSourceType(this);
	}
};
function getPipelineSourceType(e) {
	const t = e.stages[0];
	return t instanceof X || t instanceof Y || t instanceof Z || t instanceof sa ? t._name : "unknown";
}
function getPipelineCollection(e) {
	if ("collection" === getPipelineSourceType(e)) return e.stages[0].pi;
}
function getPipelineCollectionGroup(e) {
	if ("collection_group" === getPipelineSourceType(e)) return e.stages[0].collectionId;
}
function getPipelineCollectionId(e) {
	switch (getPipelineSourceType(e)) {
		case "collection": return ResourcePath.fromString(getPipelineCollection(e)).lastSegment();
		case "collection_group": return getPipelineCollectionGroup(e);
		default: return;
	}
}
function getPipelineDocuments(e) {
	if ("documents" === getPipelineSourceType(e)) return e.stages[0].gi;
}
var __PRIVATE_EvaluateResult = class __PRIVATE_EvaluateResult {
	constructor(e, t) {
		this.type = e, this.value = t;
	}
	static Ci() {
		return new __PRIVATE_EvaluateResult("ERROR", void 0);
	}
	static Fi() {
		return new __PRIVATE_EvaluateResult("UNSET", void 0);
	}
	static Oi() {
		return new __PRIVATE_EvaluateResult("NULL", ht);
	}
	static newValue(e) {
		return __PRIVATE_isNullValue(e) ? new __PRIVATE_EvaluateResult("NULL", ht) : function __PRIVATE_isBoolean(e) {
			return !!e && "booleanValue" in e;
		}(e) ? new __PRIVATE_EvaluateResult("BOOLEAN", e) : __PRIVATE_isIntegerValue(e) ? new __PRIVATE_EvaluateResult("INT", e) : __PRIVATE_isDoubleValue(e) ? new __PRIVATE_EvaluateResult("DOUBLE", e) : function __PRIVATE_isTimestampValue(e) {
			return !!e && "timestampValue" in e && !!e.timestampValue;
		}(e) ? new __PRIVATE_EvaluateResult("TIMESTAMP", e) : function __PRIVATE_isString(e) {
			return !!e && "stringValue" in e;
		}(e) ? new __PRIVATE_EvaluateResult("STRING", e) : function __PRIVATE_isBytes(e) {
			return !!e && "bytesValue" in e;
		}(e) ? new __PRIVATE_EvaluateResult("BYTES", e) : e.referenceValue ? new __PRIVATE_EvaluateResult("REFERENCE", e) : e.geoPointValue ? new __PRIVATE_EvaluateResult("GEO_POINT", e) : isArray(e) ? new __PRIVATE_EvaluateResult("ARRAY", e) : __PRIVATE_isVectorValue(e) ? new __PRIVATE_EvaluateResult("VECTOR", e) : __PRIVATE_isMapValue(e) ? new __PRIVATE_EvaluateResult("MAP", e) : new __PRIVATE_EvaluateResult("ERROR", void 0);
	}
	Mi() {
		return "ERROR" === this.type || "UNSET" === this.type;
	}
	Ni() {
		return "NULL" === this.type;
	}
};
function __PRIVATE_valueOrUndefined(e) {
	if (!e.Mi()) return e.value;
}
function __PRIVATE_unwrapExpression(e) {
	return e instanceof BooleanExpression ? e._expr : e;
}
function __PRIVATE_toEvaluable(e) {
	if ((e = __PRIVATE_unwrapExpression(e)) instanceof o) return new __PRIVATE_CoreField(e);
	if (e instanceof Constant) return new __PRIVATE_CoreConstant(e);
	if (e instanceof __PRIVATE_ListOfExprs) return new __PRIVATE_CoreListOfExprs(e);
	if (e instanceof y) {
		if ("add" === e.name) return new __PRIVATE_CoreAdd(e);
		if ("subtract" === e.name) return new __PRIVATE_CoreSubtract(e);
		if ("multiply" === e.name) return new __PRIVATE_CoreMultiply(e);
		if ("divide" === e.name) return new __PRIVATE_CoreDivide(e);
		if ("mod" === e.name) return new __PRIVATE_CoreMod(e);
		if ("and" === e.name) return new __PRIVATE_CoreAnd(e);
		if ("equal" === e.name) return new __PRIVATE_CoreEq(e);
		if ("not_equal" === e.name) return new __PRIVATE_CoreNeq(e);
		if ("less_than" === e.name) return new __PRIVATE_CoreLt(e);
		if ("less_than_or_equal" === e.name) return new __PRIVATE_CoreLte(e);
		if ("greater_than" === e.name) return new __PRIVATE_CoreGt(e);
		if ("greater_than_or_equal" === e.name) return new __PRIVATE_CoreGte(e);
		if ("array_concat" === e.name) return new __PRIVATE_CoreArrayConcat(e);
		if ("array_reverse" === e.name) return new __PRIVATE_CoreArrayReverse(e);
		if ("array_contains" === e.name) return new __PRIVATE_CoreArrayContains(e);
		if ("array_contains_all" === e.name) return new __PRIVATE_CoreArrayContainsAll(e);
		if ("array_contains_any" === e.name) return new __PRIVATE_CoreArrayContainsAny(e);
		if ("array_length" === e.name) return new __PRIVATE_CoreArrayLength(e);
		if ("array_element" === e.name) return new __PRIVATE_CoreArrayElement(e);
		if ("equal_any" === e.name) return new __PRIVATE_CoreEqAny(e);
		if ("not_equal_any" === e.name) return new __PRIVATE_CoreNotEqAny(e);
		if ("is_nan" === e.name) return new __PRIVATE_CoreIsNan(e);
		if ("is_not_nan" === e.name) return new __PRIVATE_CoreIsNotNan(e);
		if ("is_null" === e.name) return new __PRIVATE_CoreIsNull(e);
		if ("is_not_null" === e.name) return new __PRIVATE_CoreIsNotNull(e);
		if ("is_error" === e.name) return new __PRIVATE_CoreIsError(e);
		if ("exists" === e.name) return new __PRIVATE_CoreExists(e);
		if ("not" === e.name) return new __PRIVATE_CoreNot(e);
		if ("or" === e.name) return new __PRIVATE_CoreOr(e);
		if ("xor" === e.name) return new __PRIVATE_CoreXor(e);
		if ("conditional" === e.name) return new __PRIVATE_CoreCond(e);
		if ("maximum" === e.name) return new __PRIVATE_CoreLogicalMaximum(e);
		if ("minimum" === e.name) return new __PRIVATE_CoreLogicalMinimum(e);
		if ("reverse" === e.name) return new __PRIVATE_CoreReverse(e);
		if ("replace_first" === e.name) return new __PRIVATE_CoreReplaceFirst(e);
		if ("replace_all" === e.name) return new __PRIVATE_CoreReplaceAll(e);
		if ("char_length" === e.name) return new __PRIVATE_CoreCharLength(e);
		if ("byte_length" === e.name) return new __PRIVATE_CoreByteLength(e);
		if ("like" === e.name) return new __PRIVATE_CoreLike(e);
		if ("regex_contains" === e.name) return new __PRIVATE_CoreRegexContains(e);
		if ("regex_match" === e.name) return new __PRIVATE_CoreRegexMatch(e);
		if ("string_contains" === e.name) return new __PRIVATE_CoreStrContains(e);
		if ("starts_with" === e.name) return new __PRIVATE_CoreStartsWith(e);
		if ("ends_with" === e.name) return new __PRIVATE_CoreEndsWith(e);
		if ("to_lower" === e.name) return new __PRIVATE_CoreToLower(e);
		if ("to_upper" === e.name) return new __PRIVATE_CoreToUpper(e);
		if ("trim" === e.name) return new __PRIVATE_CoreTrim(e);
		if ("string_concat" === e.name) return new __PRIVATE_CoreStrConcat(e);
		if ("map_get" === e.name) return new __PRIVATE_CoreMapGet(e);
		if ("cosine_distance" === e.name) return new __PRIVATE_CoreCosineDistance(e);
		if ("dot_product" === e.name) return new __PRIVATE_CoreDotProduct(e);
		if ("euclidean_distance" === e.name) return new __PRIVATE_CoreEuclideanDistance(e);
		if ("vector_length" === e.name) return new __PRIVATE_CoreVectorLength(e);
		if ("unix_micros_to_timestamp" === e.name) return new __PRIVATE_CoreUnixMicrosToTimestamp(e);
		if ("timestamp_to_unix_micros" === e.name) return new __PRIVATE_CoreTimestampToUnixMicros(e);
		if ("unix_millis_to_timestamp" === e.name) return new __PRIVATE_CoreUnixMillisToTimestamp(e);
		if ("timestamp_to_unix_millis" === e.name) return new __PRIVATE_CoreTimestampToUnixMillis(e);
		if ("unix_seconds_to_timestamp" === e.name) return new __PRIVATE_CoreUnixSecondsToTimestamp(e);
		if ("timestamp_to_unix_seconds" === e.name) return new __PRIVATE_CoreTimestampToUnixSeconds(e);
		if ("timestamp_add" === e.name) return new __PRIVATE_CoreTimestampAdd(e);
		if ("timestamp_subtract" === e.name) return new __PRIVATE_CoreTimestampSub(e);
	}
	throw new Error(`Unknown Expr : ${e}`);
}
var __PRIVATE_CoreField = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		if (this.expr.fieldName === Fe) return __PRIVATE_EvaluateResult.newValue({ referenceValue: __PRIVATE_toName(e.serializer, t.key) });
		if ("__update_time__" === this.expr.fieldName) return __PRIVATE_EvaluateResult.newValue({ timestampValue: __PRIVATE_toVersion(e.serializer, t.version) });
		if ("__create_time__" === this.expr.fieldName) return __PRIVATE_EvaluateResult.newValue({ timestampValue: __PRIVATE_toVersion(e.serializer, t.createTime) });
		const n = t.data.field(this.expr._fieldPath);
		return n ? __PRIVATE_isServerTimestamp(n) ? __PRIVATE_EvaluateResult.newValue(function __PRIVATE_getServerTimestampValue(e, t) {
			if ("estimate" === e.serverTimestampBehavior) return { timestampValue: __PRIVATE_toVersion(e.serializer, SnapshotVersion.fromTimestamp(__PRIVATE_getLocalWriteTime(t))) };
			if ("previous" === e.serverTimestampBehavior) {
				const e = __PRIVATE_getPreviousValue(t);
				if (e) return e;
			}
			return { nullValue: "NULL_VALUE" };
		}(e, n)) : __PRIVATE_EvaluateResult.newValue(n) : __PRIVATE_EvaluateResult.Fi();
	}
};
var __PRIVATE_CoreConstant = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		return __PRIVATE_EvaluateResult.newValue(this.expr._getValue());
	}
};
var __PRIVATE_CoreListOfExprs = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		const n = this.expr.fi.map(((n) => __PRIVATE_toEvaluable(n).evaluate(e, t)));
		return n.some(((e) => e.Mi())) ? __PRIVATE_EvaluateResult.Ci() : __PRIVATE_EvaluateResult.newValue({ arrayValue: { values: n.map(((e) => e.value)) } });
	}
};
function __PRIVATE_asDouble(e) {
	return __PRIVATE_isDoubleValue(e) ? Number(e.doubleValue) : Number(e.integerValue);
}
function __PRIVATE_asBigInt(e) {
	return BigInt(e.integerValue);
}
var un = BigInt("0x7fffffffffffffff");
var cn = -BigInt("0x8000000000000000");
var __PRIVATE_BigIntOrDoubleArithmetics = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(this.expr.params.length >= 2, 24778);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t), r = __PRIVATE_toEvaluable(this.expr.params[1]).evaluate(e, t);
		let i = this.Bi(n, r);
		for (const n of this.expr.params.slice(2)) {
			const r = __PRIVATE_toEvaluable(n).evaluate(e, t);
			i = this.Bi(i, r);
		}
		return i;
	}
	Bi(e, t) {
		if (e.Mi() || t.Mi()) return __PRIVATE_EvaluateResult.Ci();
		if (e.Ni() || t.Ni()) return __PRIVATE_EvaluateResult.Oi();
		const n = e.value, r = t.value;
		if (!__PRIVATE_isDoubleValue(n) && !__PRIVATE_isIntegerValue(n) || !__PRIVATE_isDoubleValue(r) && !__PRIVATE_isIntegerValue(r)) return __PRIVATE_EvaluateResult.Ci();
		if (__PRIVATE_isDoubleValue(n) || __PRIVATE_isDoubleValue(r)) {
			const e = this.Li(n, r);
			return e ? __PRIVATE_EvaluateResult.newValue(e) : __PRIVATE_EvaluateResult.Ci();
		}
		if (__PRIVATE_isIntegerValue(n) && __PRIVATE_isIntegerValue(r)) {
			const e = this.Ui(n, r);
			return void 0 === e ? __PRIVATE_EvaluateResult.Ci() : "number" == typeof e ? __PRIVATE_EvaluateResult.newValue({ doubleValue: e }) : e < cn || e > un ? __PRIVATE_EvaluateResult.Ci() : __PRIVATE_EvaluateResult.newValue({ integerValue: `${e}` });
		}
		return __PRIVATE_EvaluateResult.Ci();
	}
};
function __PRIVATE_strictValueEquals(e, t) {
	return __PRIVATE_typeOrder(e) !== __PRIVATE_typeOrder(t) ? "TYPE_MISMATCH" : __PRIVATE_isNanValue(e) || __PRIVATE_isNanValue(t) ? "NOT_EQ" : __PRIVATE_isNullValue(e) && __PRIVATE_isNullValue(t) ? "EQ" : __PRIVATE_isNullValue(e) || __PRIVATE_isNullValue(t) ? "NULL" : isArray(e) && isArray(t) ? function __PRIVATE_strictArrayValueEquals(e, t) {
		if (e.values?.length !== t.values?.length) return "NOT_EQ";
		let n = false;
		for (let r = 0; r < (e.values?.length ?? 0); r++) {
			const i = e.values[r], s = t.values[r];
			switch (__PRIVATE_strictValueEquals(i, s)) {
				case "EQ": break;
				case "NOT_EQ":
				case "TYPE_MISMATCH": return "NOT_EQ";
				case "NULL":
					n = true;
					break;
				default: l(44609, {
					ki: i,
					Qi: s
				});
			}
		}
		if (n) return "NULL";
		return "EQ";
	}(e.arrayValue, t.arrayValue) : __PRIVATE_isVectorValue(e) && __PRIVATE_isVectorValue(t) || __PRIVATE_isMapValue(e) && __PRIVATE_isMapValue(t) ? function __PRIVATE_strictObjectValueEquals(e, t) {
		const n = e.fields || {}, r = t.fields || {};
		if (__PRIVATE_objectSize(n) !== __PRIVATE_objectSize(r)) return "NOT_EQ";
		let i = false;
		for (const e in n) if (n.hasOwnProperty(e)) {
			if (void 0 === r[e]) return "NOT_EQ";
			switch (__PRIVATE_strictValueEquals(n[e], r[e])) {
				case "NOT_EQ":
				case "TYPE_MISMATCH": return "NOT_EQ";
				case "NULL": i = true;
			}
		}
		if (i) return "NULL";
		return "EQ";
	}(e.mapValue, t.mapValue) : function __PRIVATE_valueEquals(e, t) {
		return __PRIVATE_valueEquals$1(e, t, {
			be: false,
			ye: true,
			we: true
		});
	}(e, t) ? "EQ" : "NOT_EQ";
}
var __PRIVATE_CoreAdd = class extends __PRIVATE_BigIntOrDoubleArithmetics {
	Ui(e, t) {
		return __PRIVATE_asBigInt(e) + __PRIVATE_asBigInt(t);
	}
	Li(e, t) {
		return { doubleValue: __PRIVATE_asDouble(e) + __PRIVATE_asDouble(t) };
	}
};
var __PRIVATE_CoreSubtract = class extends __PRIVATE_BigIntOrDoubleArithmetics {
	constructor(e) {
		super(e), this.expr = e;
	}
	Ui(e, t) {
		return __PRIVATE_asBigInt(e) - __PRIVATE_asBigInt(t);
	}
	Li(e, t) {
		return { doubleValue: __PRIVATE_asDouble(e) - __PRIVATE_asDouble(t) };
	}
};
var __PRIVATE_CoreMultiply = class extends __PRIVATE_BigIntOrDoubleArithmetics {
	constructor(e) {
		super(e), this.expr = e;
	}
	Ui(e, t) {
		return __PRIVATE_asBigInt(e) * __PRIVATE_asBigInt(t);
	}
	Li(e, t) {
		return { doubleValue: __PRIVATE_asDouble(e) * __PRIVATE_asDouble(t) };
	}
};
var __PRIVATE_CoreDivide = class extends __PRIVATE_BigIntOrDoubleArithmetics {
	constructor(e) {
		super(e), this.expr = e;
	}
	Ui(e, t) {
		const n = __PRIVATE_asBigInt(t);
		if (n !== BigInt(0)) return __PRIVATE_asBigInt(e) / n;
	}
	Li(e, t) {
		const n = __PRIVATE_asDouble(t);
		return 0 === n ? { doubleValue: __PRIVATE_isNegativeZero(n) ? Number.NEGATIVE_INFINITY : Number.POSITIVE_INFINITY } : { doubleValue: __PRIVATE_asDouble(e) / n };
	}
};
var __PRIVATE_CoreMod = class extends __PRIVATE_BigIntOrDoubleArithmetics {
	constructor(e) {
		super(e), this.expr = e;
	}
	Ui(e, t) {
		const n = __PRIVATE_asBigInt(t);
		if (n !== BigInt(0)) return __PRIVATE_asBigInt(e) % n;
	}
	Li(e, t) {
		const n = __PRIVATE_asDouble(t);
		if (0 !== n) return { doubleValue: __PRIVATE_asDouble(e) % n };
	}
};
var __PRIVATE_CoreAnd = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		let n = false, r = false;
		for (const i of this.expr.params) {
			const s = __PRIVATE_toEvaluable(i).evaluate(e, t);
			switch (s.type) {
				case "BOOLEAN":
					if (!s.value?.booleanValue) return __PRIVATE_EvaluateResult.newValue(bt);
					break;
				case "NULL":
					r = true;
					break;
				default: n = true;
			}
		}
		return n ? __PRIVATE_EvaluateResult.Ci() : r ? __PRIVATE_EvaluateResult.Oi() : __PRIVATE_EvaluateResult.newValue(wt);
	}
};
var __PRIVATE_CoreNot = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 9634);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "BOOLEAN": return __PRIVATE_EvaluateResult.newValue({ booleanValue: !n.value?.booleanValue });
			case "NULL": return __PRIVATE_EvaluateResult.Oi();
			default: return __PRIVATE_EvaluateResult.Ci();
		}
	}
};
var __PRIVATE_CoreOr = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		let n = false, r = false;
		for (const i of this.expr.params) {
			const s = __PRIVATE_toEvaluable(i).evaluate(e, t);
			switch (s.type) {
				case "BOOLEAN":
					if (s.value?.booleanValue) return __PRIVATE_EvaluateResult.newValue(wt);
					break;
				case "NULL":
					r = true;
					break;
				default: n = true;
			}
		}
		return n ? __PRIVATE_EvaluateResult.Ci() : r ? __PRIVATE_EvaluateResult.Oi() : __PRIVATE_EvaluateResult.newValue(bt);
	}
};
var __PRIVATE_CoreXor = class __PRIVATE_CoreXor {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		let n = false, r = false;
		for (const i of this.expr.params) {
			const s = __PRIVATE_toEvaluable(i).evaluate(e, t);
			switch (s.type) {
				case "BOOLEAN":
					n = __PRIVATE_CoreXor.xor(n, !!s.value?.booleanValue);
					break;
				case "NULL":
					r = true;
					break;
				default: return __PRIVATE_EvaluateResult.Ci();
			}
		}
		return r ? __PRIVATE_EvaluateResult.Oi() : __PRIVATE_EvaluateResult.newValue({ booleanValue: n });
	}
	static xor(e, t) {
		return (e || t) && !(e && t);
	}
};
var __PRIVATE_CoreEqAny = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(2 === this.expr.params.length, 55094);
		let n = false;
		const r = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (r.type) {
			case "NULL":
				n = true;
				break;
			case "ERROR":
			case "UNSET": return __PRIVATE_EvaluateResult.Ci();
		}
		const i = __PRIVATE_toEvaluable(this.expr.params[1]).evaluate(e, t);
		switch (i.type) {
			case "ARRAY": break;
			case "NULL":
				n = true;
				break;
			default: return __PRIVATE_EvaluateResult.Ci();
		}
		if (n) return __PRIVATE_EvaluateResult.Oi();
		for (const e of i.value?.arrayValue?.values ?? []) switch (__PRIVATE_isNullValue(r.value) && __PRIVATE_isNullValue(e) ? "EQ" : __PRIVATE_strictValueEquals(r.value, e)) {
			case "EQ": return __PRIVATE_EvaluateResult.newValue(wt);
			case "NOT_EQ":
			case "TYPE_MISMATCH": break;
			case "NULL":
				n = true;
				break;
			default: l(44608, {
				value: r.value,
				candidate: e
			});
		}
		return n ? __PRIVATE_EvaluateResult.Oi() : __PRIVATE_EvaluateResult.newValue(bt);
	}
};
var __PRIVATE_CoreNotEqAny = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		return new __PRIVATE_CoreNot(new y("not", [new y("equal_any", this.expr.params)])).evaluate(e, t);
	}
};
var __PRIVATE_CoreIsNan = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 23322);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "INT": return __PRIVATE_EvaluateResult.newValue(bt);
			case "DOUBLE": return __PRIVATE_EvaluateResult.newValue({ booleanValue: isNaN(__PRIVATE_asDouble(n.value)) });
			case "NULL": return __PRIVATE_EvaluateResult.Oi();
			default: return __PRIVATE_EvaluateResult.Ci();
		}
	}
};
var __PRIVATE_CoreIsNotNan = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 50406);
		return new __PRIVATE_CoreNot(new y("not", [new y("is_nan", this.expr.params)])).evaluate(e, t);
	}
};
var __PRIVATE_CoreIsNull = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 23123);
		switch (__PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t).type) {
			case "NULL": return __PRIVATE_EvaluateResult.newValue(wt);
			case "UNSET":
			case "ERROR": return __PRIVATE_EvaluateResult.Ci();
			default: return __PRIVATE_EvaluateResult.newValue(bt);
		}
	}
};
var __PRIVATE_CoreIsNotNull = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 23167);
		return new __PRIVATE_CoreNot(new y("not", [new y("is_null", this.expr.params)])).evaluate(e, t);
	}
};
var __PRIVATE_CoreIsError = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 5228);
		return "ERROR" === __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t).type ? __PRIVATE_EvaluateResult.newValue(wt) : __PRIVATE_EvaluateResult.newValue(bt);
	}
};
var __PRIVATE_CoreExists = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 6877);
		switch (__PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t).type) {
			case "ERROR": return __PRIVATE_EvaluateResult.Ci();
			case "UNSET": return __PRIVATE_EvaluateResult.newValue(bt);
			default: return __PRIVATE_EvaluateResult.newValue(wt);
		}
	}
};
var __PRIVATE_CoreCond = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(3 === this.expr.params.length, 11706);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "BOOLEAN": return n.value?.booleanValue ? __PRIVATE_toEvaluable(this.expr.params[1]).evaluate(e, t) : __PRIVATE_toEvaluable(this.expr.params[2]).evaluate(e, t);
			case "NULL": return __PRIVATE_toEvaluable(this.expr.params[2]).evaluate(e, t);
			default: return __PRIVATE_EvaluateResult.Ci();
		}
	}
};
var __PRIVATE_CoreLogicalMaximum = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		const n = this.expr.params.map(((n) => __PRIVATE_toEvaluable(n).evaluate(e, t)));
		let r;
		for (const e of n) switch (e.type) {
			case "ERROR":
			case "UNSET":
			case "NULL": continue;
			default: r = void 0 === r || __PRIVATE_valueCompare(e.value, r.value) > 0 ? e : r;
		}
		return void 0 === r ? __PRIVATE_EvaluateResult.Oi() : r;
	}
};
var __PRIVATE_CoreLogicalMinimum = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		const n = this.expr.params.map(((n) => __PRIVATE_toEvaluable(n).evaluate(e, t)));
		let r;
		for (const e of n) switch (e.type) {
			case "ERROR":
			case "UNSET":
			case "NULL": continue;
			default: r = void 0 === r || __PRIVATE_valueCompare(e.value, r.value) < 0 ? e : r;
		}
		return void 0 === r ? __PRIVATE_EvaluateResult.Oi() : r;
	}
};
var __PRIVATE_ComparisonBase = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(2 === this.expr.params.length, 31033, `${this.expr.name}() function should have exactly 2 params`);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "ERROR":
			case "UNSET": return __PRIVATE_EvaluateResult.Ci();
		}
		const r = __PRIVATE_toEvaluable(this.expr.params[1]).evaluate(e, t);
		switch (r.type) {
			case "ERROR":
			case "UNSET": return __PRIVATE_EvaluateResult.Ci();
		}
		return this.qi(n, r);
	}
};
var __PRIVATE_CoreEq = class extends __PRIVATE_ComparisonBase {
	constructor(e) {
		super(e), this.expr = e;
	}
	qi(e, t) {
		if (e.Ni() && t.Ni()) return __PRIVATE_EvaluateResult.newValue(wt);
		if (e.Ni() || t.Ni()) return __PRIVATE_EvaluateResult.newValue(bt);
		if (__PRIVATE_isNanValue(e.value) || __PRIVATE_isNanValue(t.value)) return __PRIVATE_EvaluateResult.newValue(bt);
		if (__PRIVATE_typeOrder(e.value) !== __PRIVATE_typeOrder(t.value)) return __PRIVATE_EvaluateResult.newValue(bt);
		switch (__PRIVATE_strictValueEquals(e.value, t.value)) {
			case "EQ": return __PRIVATE_EvaluateResult.newValue(wt);
			case "NOT_EQ": return __PRIVATE_EvaluateResult.newValue(bt);
			case "NULL": return __PRIVATE_EvaluateResult.Oi();
			default: l(44615, {
				left: e,
				right: t
			});
		}
	}
};
var __PRIVATE_CoreNeq = class extends __PRIVATE_ComparisonBase {
	constructor(e) {
		super(e), this.expr = e;
	}
	qi(e, t) {
		switch (__PRIVATE_strictValueEquals(e.value, t.value)) {
			case "EQ": return __PRIVATE_EvaluateResult.newValue(bt);
			case "NOT_EQ":
			case "TYPE_MISMATCH": return __PRIVATE_EvaluateResult.newValue(wt);
			case "NULL": return __PRIVATE_EvaluateResult.Oi();
			default: l(44614, {
				left: e,
				right: t
			});
		}
	}
};
var __PRIVATE_CoreLt = class extends __PRIVATE_ComparisonBase {
	constructor(e) {
		super(e), this.expr = e;
	}
	qi(e, t) {
		return __PRIVATE_typeOrder(e.value) !== __PRIVATE_typeOrder(t.value) || __PRIVATE_isNanValue(e.value) || __PRIVATE_isNanValue(t.value) ? __PRIVATE_EvaluateResult.newValue(bt) : __PRIVATE_EvaluateResult.newValue({ booleanValue: __PRIVATE_valueCompare(e.value, t.value) < 0 });
	}
};
var __PRIVATE_CoreLte = class extends __PRIVATE_ComparisonBase {
	constructor(e) {
		super(e), this.expr = e;
	}
	qi(e, t) {
		return __PRIVATE_typeOrder(e.value) !== __PRIVATE_typeOrder(t.value) || __PRIVATE_isNanValue(e.value) || __PRIVATE_isNanValue(t.value) ? __PRIVATE_EvaluateResult.newValue(bt) : "EQ" === __PRIVATE_strictValueEquals(e.value, t.value) ? __PRIVATE_EvaluateResult.newValue(wt) : __PRIVATE_EvaluateResult.newValue({ booleanValue: __PRIVATE_valueCompare(e.value, t.value) < 0 });
	}
};
var __PRIVATE_CoreGt = class extends __PRIVATE_ComparisonBase {
	constructor(e) {
		super(e), this.expr = e;
	}
	qi(e, t) {
		return __PRIVATE_typeOrder(e.value) !== __PRIVATE_typeOrder(t.value) || __PRIVATE_isNanValue(e.value) || __PRIVATE_isNanValue(t.value) ? __PRIVATE_EvaluateResult.newValue(bt) : __PRIVATE_EvaluateResult.newValue({ booleanValue: __PRIVATE_valueCompare(e.value, t.value) > 0 });
	}
};
var __PRIVATE_CoreGte = class extends __PRIVATE_ComparisonBase {
	constructor(e) {
		super(e), this.expr = e;
	}
	qi(e, t) {
		return __PRIVATE_typeOrder(e.value) !== __PRIVATE_typeOrder(t.value) || __PRIVATE_isNanValue(e.value) || __PRIVATE_isNanValue(t.value) ? __PRIVATE_EvaluateResult.newValue(bt) : "EQ" === __PRIVATE_strictValueEquals(e.value, t.value) ? __PRIVATE_EvaluateResult.newValue(wt) : __PRIVATE_EvaluateResult.newValue({ booleanValue: __PRIVATE_valueCompare(e.value, t.value) > 0 });
	}
};
var __PRIVATE_CoreArrayConcat = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		throw new Error("Unimplemented");
	}
};
var __PRIVATE_CoreArrayReverse = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 216);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "NULL": return __PRIVATE_EvaluateResult.Oi();
			case "ARRAY": {
				const e = n.value.arrayValue?.values ?? [];
				return __PRIVATE_EvaluateResult.newValue({ arrayValue: { values: [...e].reverse() } });
			}
			default: return __PRIVATE_EvaluateResult.Ci();
		}
	}
};
var __PRIVATE_CoreArrayContains = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		return __PRIVATE_hardAssert(2 === this.expr.params.length, 52884), new __PRIVATE_CoreEqAny(new y("eq_any", [this.expr.params[1], this.expr.params[0]])).evaluate(e, t);
	}
};
var __PRIVATE_CoreArrayContainsAll = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(2 === this.expr.params.length, 1392);
		let n = false;
		const r = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (r.type) {
			case "ARRAY": break;
			case "NULL":
				n = true;
				break;
			default: return __PRIVATE_EvaluateResult.Ci();
		}
		const i = __PRIVATE_toEvaluable(this.expr.params[1]).evaluate(e, t);
		switch (i.type) {
			case "ARRAY": break;
			case "NULL":
				n = true;
				break;
			default: return __PRIVATE_EvaluateResult.Ci();
		}
		if (n) return __PRIVATE_EvaluateResult.Oi();
		const s = i.value?.arrayValue?.values ?? [], _ = r.value?.arrayValue?.values ?? [];
		for (const e of s) {
			let t = false;
			n = false;
			for (const r of _) {
				switch (__PRIVATE_isNullValue(e) && __PRIVATE_isNullValue(r) ? "EQ" : __PRIVATE_strictValueEquals(e, r)) {
					case "EQ":
						t = true;
						break;
					case "NOT_EQ":
					case "TYPE_MISMATCH": break;
					case "NULL":
						n = true;
						break;
					default: l(44613, {
						value: r,
						search: e
					});
				}
				if (t) break;
			}
			if (!t) return __PRIVATE_EvaluateResult.newValue(bt);
		}
		return __PRIVATE_EvaluateResult.newValue(wt);
	}
};
var __PRIVATE_CoreArrayContainsAny = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(2 === this.expr.params.length, 2680);
		let n = false;
		const r = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (r.type) {
			case "ARRAY": break;
			case "NULL":
				n = true;
				break;
			default: return __PRIVATE_EvaluateResult.Ci();
		}
		const i = __PRIVATE_toEvaluable(this.expr.params[1]).evaluate(e, t);
		switch (i.type) {
			case "ARRAY": break;
			case "NULL":
				n = true;
				break;
			default: return __PRIVATE_EvaluateResult.Ci();
		}
		if (n) return __PRIVATE_EvaluateResult.Oi();
		const s = i.value?.arrayValue?.values ?? [], _ = r.value?.arrayValue?.values ?? [];
		for (const e of _) for (const t of s) switch (__PRIVATE_isNullValue(e) && __PRIVATE_isNullValue(t) ? "EQ" : __PRIVATE_strictValueEquals(e, t)) {
			case "EQ": return __PRIVATE_EvaluateResult.newValue(wt);
			case "NOT_EQ":
			case "TYPE_MISMATCH": break;
			case "NULL":
				n = true;
				break;
			default: l(60403, {
				value: e,
				search: t
			});
		}
		return n ? __PRIVATE_EvaluateResult.Oi() : __PRIVATE_EvaluateResult.newValue(bt);
	}
};
var __PRIVATE_CoreArrayLength = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 38605);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "NULL": return __PRIVATE_EvaluateResult.Oi();
			case "ARRAY": return __PRIVATE_EvaluateResult.newValue({ integerValue: `${n.value?.arrayValue?.values?.length ?? 0}` });
			default: return __PRIVATE_EvaluateResult.Ci();
		}
	}
};
var __PRIVATE_CoreArrayElement = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		throw new Error("Unimplemented");
	}
};
var __PRIVATE_CoreReverse = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 1508);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "NULL": return __PRIVATE_EvaluateResult.Oi();
			case "BYTES": {
				const e = n.value?.bytesValue;
				if ("string" == typeof e) {
					const t = ByteString.fromBase64String(e).toUint8Array();
					return t.reverse(), __PRIVATE_EvaluateResult.newValue({ bytesValue: ByteString.fromUint8Array(t).toBase64() });
				}
				return __PRIVATE_EvaluateResult.newValue({ bytesValue: new Uint8Array(e).reverse() });
			}
			case "STRING": {
				const e = n.value?.stringValue, t = new Intl.__PRIVATE_Segmenter(void 0, { granularity: "grapheme" }).segment(e), r = Array.from(t, ((e) => e.segment)).reverse();
				return __PRIVATE_EvaluateResult.newValue({ stringValue: r.join("") });
			}
			default: return __PRIVATE_EvaluateResult.Ci();
		}
	}
};
var __PRIVATE_CoreReplaceFirst = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		throw new Error("Unimplemented");
	}
};
var __PRIVATE_CoreReplaceAll = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		throw new Error("Unimplemented");
	}
};
var __PRIVATE_CoreCharLength = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 19400);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "NULL": return __PRIVATE_EvaluateResult.Oi();
			case "STRING": {
				const e = function __PRIVATE_getUnicodePointCount(e) {
					let t = 0;
					for (let n = 0; n < e.length; n++) {
						const r = e.codePointAt(n);
						if (void 0 === r) return;
						if (r <= 65535) if (r >= 55296 && r <= 57343) if (r <= 56319) {
							const r = e.codePointAt(n + 1);
							void 0 !== r && r >= 56320 && r <= 57343 ? (t += 1, n++) : t += 1;
						} else t += 1;
						else t += 1;
						else {
							if (!(r <= 1114111)) return;
							t += 1, n++;
						}
					}
					return t;
				}(n.value.stringValue);
				return void 0 === e ? __PRIVATE_EvaluateResult.Ci() : __PRIVATE_EvaluateResult.newValue({ integerValue: e });
			}
			default: return __PRIVATE_EvaluateResult.Ci();
		}
	}
};
var __PRIVATE_CoreByteLength = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 8486);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "BYTES": {
				const e = n.value?.bytesValue;
				return "string" == typeof e ? __PRIVATE_EvaluateResult.newValue({ integerValue: ByteString.fromBase64String(e).toUint8Array().length }) : __PRIVATE_EvaluateResult.newValue({ integerValue: new Uint8Array(e).length });
			}
			case "STRING": {
				const e = function __PRIVATE_getUtf8ByteLength(e) {
					let t = 0;
					for (let n = 0; n < e.length; n++) {
						const r = e.codePointAt(n);
						if (void 0 === r) return;
						if (r >= 55296 && r <= 57343) {
							if (!(r <= 56319)) return;
							{
								const r = e.codePointAt(n + 1);
								if (void 0 === r || !(r >= 56320 && r <= 57343)) return;
								t += 4, n++;
							}
						} else if (r <= 127) t += 1;
						else if (r <= 2047) t += 2;
						else if (r <= 65535) t += 3;
						else {
							if (!(r <= 1114111)) return;
							t += 4, n++;
						}
					}
					return t;
				}(n.value?.stringValue);
				return void 0 === e ? __PRIVATE_EvaluateResult.Ci() : __PRIVATE_EvaluateResult.newValue({ integerValue: e });
			}
			case "NULL": return __PRIVATE_EvaluateResult.Oi();
			default: return __PRIVATE_EvaluateResult.Ci();
		}
	}
};
var __PRIVATE_StringSearchFunctionBase = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(2 === this.expr.params.length, 39773, `${this.expr.name}() function should have exactly two parameters`);
		let n = false;
		const r = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (r.type) {
			case "STRING": break;
			case "NULL":
				n = true;
				break;
			default: return __PRIVATE_EvaluateResult.Ci();
		}
		const i = __PRIVATE_toEvaluable(this.expr.params[1]).evaluate(e, t);
		switch (i.type) {
			case "STRING": break;
			case "NULL":
				n = true;
				break;
			default: return __PRIVATE_EvaluateResult.Ci();
		}
		return n ? __PRIVATE_EvaluateResult.Oi() : this.Ki(r.value?.stringValue, i.value?.stringValue);
	}
};
var __PRIVATE_CoreLike = class extends __PRIVATE_StringSearchFunctionBase {
	Ki(e, t) {
		try {
			const n = function __PRIVATE_likeToRegex(e) {
				let t = "";
				for (let n = 0; n < e.length; n++) {
					const r = e.charAt(n);
					switch (r) {
						case "_":
							t += ".";
							break;
						case "%":
							t += ".*";
							break;
						case "\\":
						case ".":
						case "*":
						case "?":
						case "+":
						case "^":
						case "$":
						case "|":
						case "(":
						case ")":
						case "[":
						case "]":
						case "{":
						case "}":
							t += "\\" + r;
							break;
						default: t += r;
					}
				}
				return "^" + t + "$";
			}(t), r = RE2JS.compile(n);
			return __PRIVATE_EvaluateResult.newValue({ booleanValue: r.matches(e) });
		} catch (e) {
			return __PRIVATE_logWarn(`Invalid LIKE pattern converted to regex: ${t}, returning error. Error: ${e}`), __PRIVATE_EvaluateResult.Ci();
		}
	}
};
var __PRIVATE_CoreRegexContains = class extends __PRIVATE_StringSearchFunctionBase {
	Ki(e, t) {
		try {
			const n = RE2JS.compile(t);
			return __PRIVATE_EvaluateResult.newValue({ booleanValue: n.test(e) });
		} catch (e) {
			return __PRIVATE_logWarn(`Invalid regex pattern found in regex_contains: ${t}, returning error`), __PRIVATE_EvaluateResult.Ci();
		}
	}
};
var __PRIVATE_CoreRegexMatch = class extends __PRIVATE_StringSearchFunctionBase {
	Ki(e, t) {
		try {
			return __PRIVATE_EvaluateResult.newValue({ booleanValue: RE2JS.compile(t).matches(e) });
		} catch (e) {
			return __PRIVATE_logWarn(`Invalid regex pattern found in regex_match: ${t}, returning error`), __PRIVATE_EvaluateResult.Ci();
		}
	}
};
var __PRIVATE_CoreStrContains = class extends __PRIVATE_StringSearchFunctionBase {
	Ki(e, t) {
		return __PRIVATE_EvaluateResult.newValue({ booleanValue: e.includes(t) });
	}
};
var __PRIVATE_CoreStartsWith = class extends __PRIVATE_StringSearchFunctionBase {
	Ki(e, t) {
		return __PRIVATE_EvaluateResult.newValue({ booleanValue: e.startsWith(t) });
	}
};
var __PRIVATE_CoreEndsWith = class extends __PRIVATE_StringSearchFunctionBase {
	Ki(e, t) {
		return __PRIVATE_EvaluateResult.newValue({ booleanValue: e.endsWith(t) });
	}
};
var __PRIVATE_CoreToLower = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 29079);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "STRING": return __PRIVATE_EvaluateResult.newValue({ stringValue: n.value?.stringValue?.toLowerCase() });
			case "NULL": return __PRIVATE_EvaluateResult.Oi();
			default: return __PRIVATE_EvaluateResult.Ci();
		}
	}
};
var __PRIVATE_CoreToUpper = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 60487);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "STRING": return __PRIVATE_EvaluateResult.newValue({ stringValue: n.value?.stringValue?.toUpperCase() });
			case "NULL": return __PRIVATE_EvaluateResult.Oi();
			default: return __PRIVATE_EvaluateResult.Ci();
		}
	}
};
var __PRIVATE_CoreTrim = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 28544);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "STRING": return __PRIVATE_EvaluateResult.newValue({ stringValue: n.value?.stringValue?.trim() });
			case "NULL": return __PRIVATE_EvaluateResult.Oi();
			default: return __PRIVATE_EvaluateResult.Ci();
		}
	}
};
var __PRIVATE_CoreStrConcat = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		const n = this.expr.params.map(((n) => __PRIVATE_toEvaluable(n).evaluate(e, t)));
		let r = "", i = false;
		for (const e of n) switch (e.type) {
			case "STRING":
				r += e.value.stringValue;
				break;
			case "NULL":
				i = true;
				break;
			default: return __PRIVATE_EvaluateResult.Ci();
		}
		return i ? __PRIVATE_EvaluateResult.Oi() : __PRIVATE_EvaluateResult.newValue({ stringValue: r });
	}
};
var __PRIVATE_CoreMapGet = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(2 === this.expr.params.length, 4483);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "UNSET": return __PRIVATE_EvaluateResult.Fi();
			case "MAP": break;
			default: return __PRIVATE_EvaluateResult.Ci();
		}
		const r = __PRIVATE_toEvaluable(this.expr.params[1]).evaluate(e, t);
		if ("STRING" !== r.type) return __PRIVATE_EvaluateResult.Ci();
		const i = n.value?.mapValue?.fields?.[r.value?.stringValue];
		return void 0 === i ? __PRIVATE_EvaluateResult.Fi() : __PRIVATE_EvaluateResult.newValue(i);
	}
};
var __PRIVATE_DistanceBase = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(2 === this.expr.params.length, 25231, `${this.expr.name}() function should have exactly 2 params`);
		let n = false;
		const r = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (r.type) {
			case "VECTOR": break;
			case "NULL":
				n = true;
				break;
			default: return __PRIVATE_EvaluateResult.Ci();
		}
		const i = __PRIVATE_toEvaluable(this.expr.params[1]).evaluate(e, t);
		switch (i.type) {
			case "VECTOR": break;
			case "NULL":
				n = true;
				break;
			default: return __PRIVATE_EvaluateResult.Ci();
		}
		if (n) return __PRIVATE_EvaluateResult.Oi();
		const s = __PRIVATE_getVectorValue(r.value), _ = __PRIVATE_getVectorValue(i.value);
		if (void 0 === s || void 0 === _ || s.values?.length !== _.values?.length) return __PRIVATE_EvaluateResult.Ci();
		const o = this.$i(s, _);
		return void 0 === o || isNaN(o) ? __PRIVATE_EvaluateResult.Ci() : __PRIVATE_EvaluateResult.newValue({ doubleValue: o });
	}
};
var __PRIVATE_CoreCosineDistance = class extends __PRIVATE_DistanceBase {
	$i(e, t) {
		const n = e?.values ?? [], r = t?.values ?? [];
		if (0 === n.length) return;
		let i = 0, s = 0, _ = 0;
		for (let e = 0; e < n.length; e++) {
			if (!R(n[e]) || !R(r[e])) return;
			const t = __PRIVATE_asDouble(n[e]), o = __PRIVATE_asDouble(r[e]);
			i += t * o, s += t * t, _ += o * o;
		}
		const o = Math.sqrt(s) * Math.sqrt(_);
		if (0 === o) return;
		return 1 - Math.max(-1, Math.min(1, i / o));
	}
};
var __PRIVATE_CoreDotProduct = class extends __PRIVATE_DistanceBase {
	$i(e, t) {
		const n = e?.values ?? [], r = t?.values ?? [];
		if (0 === n.length) return 0;
		let i = 0;
		for (let e = 0; e < n.length; e++) {
			if (!R(n[e]) || !R(r[e])) return;
			i += __PRIVATE_asDouble(n[e]) * __PRIVATE_asDouble(r[e]);
		}
		return i;
	}
};
var __PRIVATE_CoreEuclideanDistance = class extends __PRIVATE_DistanceBase {
	$i(e, t) {
		const n = e?.values ?? [], r = t?.values ?? [];
		if (0 === n.length) return 0;
		let i = 0;
		for (let e = 0; e < n.length; e++) {
			if (!R(n[e]) || !R(r[e])) return;
			const t = __PRIVATE_asDouble(n[e]), s = __PRIVATE_asDouble(r[e]);
			i += Math.pow(t - s, 2);
		}
		return Math.sqrt(i);
	}
};
var __PRIVATE_CoreVectorLength = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 39044);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "VECTOR": {
				const e = __PRIVATE_getVectorValue(n.value);
				return __PRIVATE_EvaluateResult.newValue({ integerValue: e?.values?.length ?? 0 });
			}
			case "NULL": return __PRIVATE_EvaluateResult.Oi();
			default: return __PRIVATE_EvaluateResult.Ci();
		}
	}
};
var En = BigInt(-62135596800);
var hn = BigInt(253402300799);
var Tn = BigInt(1e3);
var Pn = BigInt(1e6);
var In = En * Tn;
var Rn = hn * Tn + BigInt(999);
var An = En * Pn;
var Vn = hn * Pn + BigInt(999999);
function __PRIVATE_isMicrosInBounds(e) {
	return e >= An && e <= Vn;
}
function __PRIVATE_isSecondsInBounds(e) {
	return e >= En && e <= hn;
}
function __PRIVATE_isTimestampInBounds(e, t) {
	const n = BigInt(e);
	return !(n < En || n > hn) && !(t < 0 || t >= 1e9) && (n !== En || 0 === t) && !(n === hn && t > 999999999);
}
function __PRIVATE_adjustTimestamp(e, t) {
	return t < 0 ? {
		seconds: e - 1,
		nanos: t + 1e9
	} : {
		seconds: e,
		nanos: t
	};
}
function __PRIVATE_timestampToMicros(e) {
	return BigInt(e.seconds) * Pn + BigInt(Math.trunc(e.nanoseconds / 1e3));
}
var __PRIVATE_UnixToTimestamp = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 49262, `${this.expr.name}() function should have exactly one parameter`);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "INT": return this.toTimestamp(BigInt(n.value.integerValue));
			case "NULL": return __PRIVATE_EvaluateResult.Oi();
			default: return __PRIVATE_EvaluateResult.Ci();
		}
	}
};
var __PRIVATE_CoreUnixMicrosToTimestamp = class extends __PRIVATE_UnixToTimestamp {
	toTimestamp(e) {
		if (!__PRIVATE_isMicrosInBounds(e)) return __PRIVATE_EvaluateResult.Ci();
		let t = Number(e / Pn), n = Number(e % Pn * BigInt(1e3));
		const r = __PRIVATE_adjustTimestamp(t, n);
		return t = r.seconds, n = r.nanos, __PRIVATE_isTimestampInBounds(t, n) ? __PRIVATE_EvaluateResult.newValue({ timestampValue: {
			seconds: t,
			nanos: n
		} }) : __PRIVATE_EvaluateResult.Ci();
	}
};
var __PRIVATE_CoreUnixMillisToTimestamp = class extends __PRIVATE_UnixToTimestamp {
	toTimestamp(e) {
		if (!function __PRIVATE_isMillisInBounds(e) {
			return e >= In && e <= Rn;
		}(e)) return __PRIVATE_EvaluateResult.Ci();
		let t = Number(e / Tn), n = Number(e % Tn * BigInt(1e6));
		const r = __PRIVATE_adjustTimestamp(t, n);
		return t = r.seconds, n = r.nanos, __PRIVATE_isTimestampInBounds(t, n) ? __PRIVATE_EvaluateResult.newValue({ timestampValue: {
			seconds: t,
			nanos: n
		} }) : __PRIVATE_EvaluateResult.Ci();
	}
};
var __PRIVATE_CoreUnixSecondsToTimestamp = class extends __PRIVATE_UnixToTimestamp {
	toTimestamp(e) {
		if (!__PRIVATE_isSecondsInBounds(e)) return __PRIVATE_EvaluateResult.Ci();
		const t = Number(e);
		return __PRIVATE_EvaluateResult.newValue({ timestampValue: {
			seconds: t,
			nanos: 0
		} });
	}
};
var __PRIVATE_TimestampToUnix = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 1265, `${this.expr.name}() function should have exactly one parameter`);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "TIMESTAMP": break;
			case "NULL": return __PRIVATE_EvaluateResult.Oi();
			default: return __PRIVATE_EvaluateResult.Ci();
		}
		const r = fromTimestamp(n.value.timestampValue);
		return __PRIVATE_isTimestampInBounds(r.seconds, r.nanoseconds) ? this.Wi(r) : __PRIVATE_EvaluateResult.Ci();
	}
};
var __PRIVATE_CoreTimestampToUnixMicros = class extends __PRIVATE_TimestampToUnix {
	Wi(e) {
		const t = __PRIVATE_timestampToMicros(e);
		return __PRIVATE_isMicrosInBounds(t) ? __PRIVATE_EvaluateResult.newValue({ integerValue: `${t.toString()}` }) : __PRIVATE_EvaluateResult.Ci();
	}
};
var __PRIVATE_CoreTimestampToUnixMillis = class extends __PRIVATE_TimestampToUnix {
	Wi(e) {
		const t = __PRIVATE_timestampToMicros(e), n = t / BigInt(1e3), r = t % BigInt(1e3);
		return n > BigInt(0) || r === BigInt(0) ? __PRIVATE_EvaluateResult.newValue({ integerValue: n.toString() }) : __PRIVATE_EvaluateResult.newValue({ integerValue: (n - BigInt(1)).toString() });
	}
};
var __PRIVATE_CoreTimestampToUnixSeconds = class extends __PRIVATE_TimestampToUnix {
	Wi(e) {
		const t = BigInt(e.seconds);
		return __PRIVATE_isSecondsInBounds(t) ? __PRIVATE_EvaluateResult.newValue({ integerValue: t.toString() }) : __PRIVATE_EvaluateResult.Ci();
	}
};
var __PRIVATE_TimestampArithmetic = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(3 === this.expr.params.length, 2775, `${this.expr.name}() function should have exactly 3 parameters`);
		let n = false;
		const r = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (r.type) {
			case "TIMESTAMP": break;
			case "NULL":
				n = true;
				break;
			default: return __PRIVATE_EvaluateResult.Ci();
		}
		const i = __PRIVATE_toEvaluable(this.expr.params[1]).evaluate(e, t);
		let s;
		switch (i.type) {
			case "STRING":
				if (s = function __PRIVATE_asTimeUnit(e) {
					switch (e) {
						case "microsecond": return "microsecond";
						case "millisecond": return "millisecond";
						case "second": return "second";
						case "minute": return "minute";
						case "hour": return "hour";
						case "day": return "day";
						default: return;
					}
				}(i.value.stringValue), void 0 === s) return __PRIVATE_EvaluateResult.Ci();
				break;
			case "NULL":
				n = true;
				break;
			default: return __PRIVATE_EvaluateResult.Ci();
		}
		const _ = __PRIVATE_toEvaluable(this.expr.params[2]).evaluate(e, t);
		switch (_.type) {
			case "INT": break;
			case "NULL":
				n = true;
				break;
			default: return __PRIVATE_EvaluateResult.Ci();
		}
		if (n) return __PRIVATE_EvaluateResult.Oi();
		const o = BigInt(_.value.integerValue);
		let a;
		try {
			switch (s) {
				case "microsecond":
					a = o;
					break;
				case "millisecond":
					a = o * BigInt(1e3);
					break;
				case "second":
					a = o * BigInt(1e6);
					break;
				case "minute":
					a = o * BigInt(6e7);
					break;
				case "hour":
					a = o * BigInt(36e8);
					break;
				case "day":
					a = o * BigInt(864e8);
					break;
				default: return __PRIVATE_EvaluateResult.Ci();
			}
			if ("microsecond" !== s && o !== BigInt(0) && a / o !== BigInt(this.Gi(s))) return __PRIVATE_EvaluateResult.Ci();
		} catch (e) {
			return __PRIVATE_logWarn(`Error during timestamp arithmetic: ${e}`), __PRIVATE_EvaluateResult.Ci();
		}
		const u = fromTimestamp(r.value.timestampValue);
		if (!__PRIVATE_isTimestampInBounds(u.seconds, u.nanoseconds)) return __PRIVATE_EvaluateResult.Ci();
		const c = __PRIVATE_timestampToMicros(u), l = this.ji(c, a);
		if (!__PRIVATE_isMicrosInBounds(l)) return __PRIVATE_EvaluateResult.Ci();
		const E = Number(l / Pn), h = l % Pn, T = Number((h < 0 ? h + Pn : h) * BigInt(1e3)), P = h < 0 ? E - 1 : E;
		return __PRIVATE_isTimestampInBounds(P, T) ? __PRIVATE_EvaluateResult.newValue({ timestampValue: {
			seconds: P,
			nanos: T
		} }) : __PRIVATE_EvaluateResult.Ci();
	}
	Gi(e) {
		switch (e) {
			case "millisecond": return 1e3;
			case "second": return 1e6;
			case "minute": return 6e7;
			case "hour": return 36e8;
			case "day": return 864e8;
			default: return 1;
		}
	}
};
var __PRIVATE_CoreTimestampAdd = class extends __PRIVATE_TimestampArithmetic {
	ji(e, t) {
		return e + t;
	}
};
var __PRIVATE_CoreTimestampSub = class extends __PRIVATE_TimestampArithmetic {
	ji(e, t) {
		return e - t;
	}
};
/**
* @license
* Copyright 2024 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function __PRIVATE_canonifyExpr(e) {
	if ((e = __PRIVATE_unwrapExpression(e)) instanceof o) return `fld(${e.fieldName})`;
	if (e instanceof Constant) return `cst(${function __PRIVATE_canonifyConstantValue(e) {
		return null === e ? "null" : "number" == typeof e ? e.toString() : "string" == typeof e ? `"${e}"` : e instanceof aa ? `ref(${e.path})` : e instanceof n ? `vec(${JSON.stringify(e)})` : JSON.stringify(e);
	}(e.value)})`;
	if (e instanceof y) return `fn(${e.name},[${e.params.map(__PRIVATE_canonifyExpr).join(",")}])`;
	if ("ListOfExpressions" === e.expressionType) return `list([${e.fi.map(__PRIVATE_canonifyExpr).join(",")}])`;
	throw new Error(`Unrecognized expr ${JSON.stringify(e, null, 2)}`);
}
function __PRIVATE_canonifyStage(e) {
	if (e instanceof w) return `${e._name}(${__PRIVATE_canonifyExprMap(e.fields)})`;
	if (e instanceof O) {
		let t = `${e._name}(${__PRIVATE_canonifyExprMap(e.accumulators)})`;
		return e.groups.size > 0 && (t += `grouping(${__PRIVATE_canonifyExprMap(e.groups)})`), t;
	}
	if (e instanceof M) return `${e._name}(${__PRIVATE_canonifyExprMap(e.groups)})`;
	if (e instanceof X) return `${e._name}(${e.pi})`;
	if (e instanceof Y) return `${e._name}(${e.collectionId})`;
	if (e instanceof Z) return `${e._name}()`;
	if (e instanceof sa) return `${e._name}(${e.gi.sort()})`;
	if (e instanceof A) return `${e._name}(${__PRIVATE_canonifyExpr(e.condition)})`;
	if (e instanceof v) return `${e._name}(${e.limit})`;
	if (e instanceof L) return `${e._name}(${function __PRIVATE_canonifySortOrderings(e) {
		return e.map(((e) => `${__PRIVATE_canonifyExpr(e.expr)}${e.direction}`)).join(",");
	}(e.orderings)})`;
	throw new Error(`Unrecognized stage ${e._name}`);
}
function __PRIVATE_canonifyExprMap(e) {
	return `${Array.from(e.entries()).sort().map((([e, t]) => `${e}=${__PRIVATE_canonifyExpr(t)}`)).join(",")}`;
}
function __PRIVATE_canonifyPipeline(e) {
	return e.stages.map(((e) => __PRIVATE_canonifyStage(e))).join("|");
}
function __PRIVATE_pipelineEq(e, t) {
	return __PRIVATE_canonifyPipeline(e) === __PRIVATE_canonifyPipeline(t);
}
function __PRIVATE_isPipeline(e) {
	return e instanceof CorePipeline;
}
function __PRIVATE_stringifyQueryOrPipeline(e) {
	return __PRIVATE_isPipeline(e) ? __PRIVATE_canonifyPipeline(e) : __PRIVATE_stringifyQuery(e);
}
function __PRIVATE_canonifyQueryOrPipeline(e) {
	return __PRIVATE_isPipeline(e) ? __PRIVATE_canonifyPipeline(e) : function __PRIVATE_canonifyQuery(e) {
		return `${__PRIVATE_canonifyTarget(__PRIVATE_queryToTarget(e))}|lt:${e.limitType}`;
	}(e);
}
function __PRIVATE_queryOrPipelineEqual(e, t) {
	return e instanceof CorePipeline && t instanceof CorePipeline ? __PRIVATE_pipelineEq(e, t) : !(e instanceof CorePipeline && !(t instanceof CorePipeline) || !(e instanceof CorePipeline) && t instanceof CorePipeline) && __PRIVATE_queryEquals(e, t);
}
function __PRIVATE_canonifyTargetOrPipeline(e) {
	return __PRIVATE_targetIsPipelineTarget(e) ? __PRIVATE_canonifyPipeline(e) : __PRIVATE_canonifyTarget(e);
}
function __PRIVATE_targetOrPipelineEqual(e, t) {
	return e instanceof CorePipeline && t instanceof CorePipeline ? __PRIVATE_pipelineEq(e, t) : !(e instanceof CorePipeline && !(t instanceof CorePipeline) || !(e instanceof CorePipeline) && t instanceof CorePipeline) && __PRIVATE_targetEquals(e, t);
}
function __PRIVATE_toCorePipeline(e, t) {
	const n = function __PRIVATE_rewriteStages(e) {
		let t = false;
		const n = [];
		for (const r of e) if (r instanceof L) if (t = true, r.orderings.some(((e) => e.expr instanceof o && e.expr.fieldName === Fe))) n.push(r);
		else {
			const e = r.orderings.map(((e) => e));
			e.push(s(Fe).ascending()), n.push(new L(e, {}));
		}
		else r instanceof v ? (t || (n.push(new L([s(Fe).ascending()], {})), t = true), n.push(r)) : n.push(r);
		return t || n.push(new L([s(Fe).ascending()], {})), n;
	}(e.stages);
	if (e.userDataReader) {
		const t = e.userDataReader.createContext(3, "toCorePipeline");
		n.forEach(((e) => e._readUserData(t)));
	}
	return new CorePipeline(e.userDataReader.serializer, n, t);
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* A batch of mutations that will be sent as one unit to the backend.
*/ var MutationBatch = class {
	/**
	* @param batchId - The unique ID of this mutation batch.
	* @param localWriteTime - The original write time of this mutation.
	* @param baseMutations - Mutations that are used to populate the base
	* values when this mutation is applied locally. This can be used to locally
	* overwrite values that are persisted in the remote document cache. Base
	* mutations are never sent to the backend.
	* @param mutations - The user-provided mutations in this mutation batch.
	* User-provided mutations are applied both locally and remotely on the
	* backend.
	*/
	constructor(e, t, n, r) {
		this.batchId = e, this.localWriteTime = t, this.baseMutations = n, this.mutations = r;
	}
	/**
	* Applies all the mutations in this MutationBatch to the specified document
	* to compute the state of the remote document
	*
	* @param document - The document to apply mutations to.
	* @param batchResult - The result of applying the MutationBatch to the
	* backend.
	*/ applyToRemoteDocument(e, t) {
		const n = t.mutationResults;
		for (let t = 0; t < this.mutations.length; t++) {
			const r = this.mutations[t];
			if (r.key.isEqual(e.key)) __PRIVATE_mutationApplyToRemoteDocument(r, e, n[t]);
		}
	}
	/**
	* Computes the local view of a document given all the mutations in this
	* batch.
	*
	* @param document - The document to apply mutations to.
	* @param mutatedFields - Fields that have been updated before applying this mutation batch.
	* @returns A `FieldMask` representing all the fields that are mutated.
	*/ applyToLocalView(e, t) {
		for (const n of this.baseMutations) n.key.isEqual(e.key) && (t = __PRIVATE_mutationApplyToLocalView(n, e, t, this.localWriteTime));
		for (const n of this.mutations) n.key.isEqual(e.key) && (t = __PRIVATE_mutationApplyToLocalView(n, e, t, this.localWriteTime));
		return t;
	}
	/**
	* Computes the local view for all provided documents given the mutations in
	* this batch. Returns a `DocumentKey` to `Mutation` map which can be used to
	* replace all the mutation applications.
	*/ applyToLocalDocumentSet(e, t) {
		const n = __PRIVATE_newMutationMap();
		return this.mutations.forEach(((r) => {
			const i = e.get(r.key), s = i.overlayedDocument;
			let _ = this.applyToLocalView(s, i.mutatedFields);
			_ = t.has(r.key) ? null : _;
			const o = __PRIVATE_calculateOverlayMutation(s, _);
			null !== o && n.set(r.key, o), s.isValidDocument() || s.convertToNoDocument(SnapshotVersion.min());
		})), n;
	}
	keys() {
		return this.mutations.reduce(((e, t) => e.add(t.key)), __PRIVATE_documentKeySet());
	}
	isEqual(e) {
		return this.batchId === e.batchId && __PRIVATE_arrayEquals(this.mutations, e.mutations, ((e, t) => __PRIVATE_mutationEquals(e, t))) && __PRIVATE_arrayEquals(this.baseMutations, e.baseMutations, ((e, t) => __PRIVATE_mutationEquals(e, t)));
	}
};
/** The result of applying a mutation batch to the backend. */ var MutationBatchResult = class MutationBatchResult {
	constructor(e, t, n, r) {
		this.batch = e, this.commitVersion = t, this.mutationResults = n, this.docVersions = r;
	}
	/**
	* Creates a new MutationBatchResult for the given batch and results. There
	* must be one result for each mutation in the batch. This static factory
	* caches a document=&gt;version mapping (docVersions).
	*/ static from(e, t, n) {
		__PRIVATE_hardAssert(e.mutations.length === n.length, 58842, {
			zi: e.mutations.length,
			Hi: n.length
		});
		let r = function __PRIVATE_documentVersionMap() {
			return Ft;
		}();
		const i = e.mutations;
		for (let e = 0; e < i.length; e++) r = r.insert(i[e].key, n[e].version);
		return new MutationBatchResult(e, t, n, r);
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var fn = "";
/**
* Encodes a resource path into a IndexedDb-compatible string form.
*/
function __PRIVATE_encodeResourcePath(e) {
	let t = "";
	for (let n = 0; n < e.length; n++) t.length > 0 && (t = __PRIVATE_encodeSeparator(t)), t = __PRIVATE_encodeSegment(e.get(n), t);
	return __PRIVATE_encodeSeparator(t);
}
/** Encodes a single segment of a resource path into the given result */ function __PRIVATE_encodeSegment(e, t) {
	let n = t;
	const r = e.length;
	for (let t = 0; t < r; t++) {
		const r = e.charAt(t);
		switch (r) {
			case "\0":
				n += "";
				break;
			case fn:
				n += "";
				break;
			default: n += r;
		}
	}
	return n;
}
/** Encodes a path separator into the given result */ function __PRIVATE_encodeSeparator(e) {
	return e + "";
}
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Representation of an overlay computed by Firestore.
*
* Holds information about a mutation and the largest batch id in Firestore when
* the mutation was created.
*/ var Overlay = class {
	constructor(e, t) {
		this.largestBatchId = e, this.mutation = t;
	}
	getKey() {
		return this.mutation.key;
	}
	isEqual(e) {
		return null !== e && this.mutation === e.mutation;
	}
	toString() {
		return `Overlay{\n      largestBatchId: ${this.largestBatchId},\n      mutation: ${this.mutation.toString()}\n    }`;
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* An immutable set of metadata that the local store tracks for each target.
*/ var TargetData = class TargetData {
	constructor(e, t, n, r, i = SnapshotVersion.min(), s = SnapshotVersion.min(), _ = ByteString.EMPTY_BYTE_STRING, o = null) {
		this.target = e, this.targetId = t, this.purpose = n, this.sequenceNumber = r, this.snapshotVersion = i, this.lastLimboFreeSnapshotVersion = s, this.resumeToken = _, this.expectedCount = o;
	}
	/** Creates a new target data instance with an updated sequence number. */ withSequenceNumber(e) {
		return new TargetData(this.target, this.targetId, this.purpose, e, this.snapshotVersion, this.lastLimboFreeSnapshotVersion, this.resumeToken, this.expectedCount);
	}
	/**
	* Creates a new target data instance with an updated resume token and
	* snapshot version.
	*/ withResumeToken(e, t) {
		return new TargetData(this.target, this.targetId, this.purpose, this.sequenceNumber, t, this.lastLimboFreeSnapshotVersion, e, null);
	}
	/**
	* Creates a new target data instance with an updated expected count.
	*/ withExpectedCount(e) {
		return new TargetData(this.target, this.targetId, this.purpose, this.sequenceNumber, this.snapshotVersion, this.lastLimboFreeSnapshotVersion, this.resumeToken, e);
	}
	/**
	* Creates a new target data instance with an updated last limbo free
	* snapshot version number.
	*/ withLastLimboFreeSnapshotVersion(e) {
		return new TargetData(this.target, this.targetId, this.purpose, this.sequenceNumber, this.snapshotVersion, e, this.resumeToken, this.expectedCount);
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/** Serializer for values stored in the LocalStore. */ var __PRIVATE_LocalSerializer = class {
	constructor(e) {
		this.Yi = e;
	}
};
/**
* Encodes a `BundledQuery` from bundle proto to a Query object.
*
* This reconstructs the original query used to build the bundle being loaded,
* including features exists only in SDKs (for example: limit-to-last).
*/
function __PRIVATE_fromBundledQuery(e) {
	const t = __PRIVATE_convertQueryTargetToQuery({
		parent: e.parent,
		structuredQuery: e.structuredQuery
	});
	return "LAST" === e.limitType ? __PRIVATE_queryWithLimit(t, t.limit, "L") : t;
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2024 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2021 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/** Firestore index value writer.  */
var __PRIVATE_FirestoreIndexValueWriter = class {
	constructor() {}
	/** Writes an index value.  */
	Es(e, t) {
		this.hs(e, t), t.Ts();
	}
	hs(e, t) {
		if ("nullValue" in e) this.Ps(t, 5);
		else if ("booleanValue" in e) this.Ps(t, 10), t.Is(e.booleanValue ? 1 : 0);
		else if ("integerValue" in e) this.Ps(t, 15), t.Is(__PRIVATE_normalizeNumber(e.integerValue));
		else if ("doubleValue" in e) {
			const n = __PRIVATE_normalizeNumber(e.doubleValue);
			this.Rs(n, t);
		} else if ("timestampValue" in e) this.As(e.timestampValue, t);
		else if ("stringValue" in e) this.Vs(e.stringValue, t), this.fs(t);
		else if ("bytesValue" in e) this.Ps(t, 30), t.ds(__PRIVATE_normalizeByteString(e.bytesValue)), this.fs(t);
		else if ("referenceValue" in e) this.ps(e.referenceValue, t);
		else if ("geoPointValue" in e) this.gs(e.geoPointValue, t);
		else if ("mapValue" in e) {
			const n = __PRIVATE_detectMapRepresentation(e);
			if (n === dt.de) this.Ps(t, Number.MAX_SAFE_INTEGER);
			else if (n === dt.me) this.ys(e.mapValue, t);
			else if (n === dt.fe) this.Ps(t, 999);
			else if (n === dt.Ve) this.Ps(t, 7);
			else if (n === dt.Ae) {
				const i = ((e.mapValue?.fields)?.[Et])?.bytesValue, s = __PRIVATE_normalizeByteString(i).toUint8Array();
				if (0 === s[0]) {
					const e = s.slice(1);
					this.Ps(t, 30), t.ds(ByteString.fromUint8Array(e)), this.fs(t);
				} else this.ws(e.mapValue, t);
			} else if (n === dt.he) this.bs(e.mapValue, t);
			else if (n === dt.Re) this.Ss(e.mapValue, t);
			else if (n === dt.Te) this.xs(e.mapValue, t);
			else if (n === dt.Pe) this.vs(e.mapValue, t);
			else if (n === dt.Ie) {
				const n = parseFloat(e.mapValue.fields[at].stringValue);
				this.Rs(n, t);
			} else this.Ds(e.mapValue, t), this.fs(t);
		} else "arrayValue" in e ? (this.Cs(e.arrayValue, t), this.fs(t)) : l(19022, { Fs: e });
	}
	Vs(e, t) {
		this.Ps(t, 25), this.Os(e, t);
	}
	Os(e, t) {
		t.Ms(e);
	}
	Rs(e, t) {
		isNaN(e) ? this.Ps(t, 13) : (this.Ps(t, 15), __PRIVATE_isNegativeZero(e) ? t.Is(0) : t.Is(e));
	}
	vs(e, t) {
		this.Ps(t, 15), t.Is(__PRIVATE_normalizeNumber(e.fields[ot].integerValue));
	}
	As(e, t) {
		this.Ps(t, 20), "string" == typeof e && (e = __PRIVATE_normalizeTimestamp(e)), t.Ms(`${e.seconds || ""}`), t.Is(e.nanos || 0);
	}
	gs(e, t) {
		this.Ps(t, 45), t.Is(e.latitude || 0), t.Is(e.longitude || 0);
	}
	Ds(e, t) {
		const n = e.fields || {};
		this.Ps(t, 55);
		for (const e of Object.keys(n)) this.Vs(e, t), this.hs(n[e], t);
	}
	ys(e, t) {
		const n = e.fields || {};
		this.Ps(t, 53);
		const r = Xe, i = n[r].arrayValue?.values?.length || 0;
		this.Ps(t, 15), t.Is(__PRIVATE_normalizeNumber(i)), this.Vs(r, t), this.hs(n[r], t);
	}
	Cs(e, t) {
		const n = e.values || [];
		this.Ps(t, 50);
		for (const e of n) this.hs(e, t);
	}
	ps(e, t) {
		this.Ps(t, 37);
		const n = e.split("/").filter(((e) => e.length > 0));
		DocumentKey.fromSegments(n.slice(5)).path.forEach(((e) => {
			this.Ps(t, 60), this.Os(e, t);
		}));
	}
	Ps(e, t) {
		e.Is(t);
	}
	fs(e) {
		e.Is(2);
	}
	Ss(e, t) {
		this.Ps(t, 22);
		const n = e.fields || {};
		n && this.Ds(n[ut].mapValue, t);
	}
	xs(e, t) {
		this.Ps(t, 43);
		const r = (e.fields || {})[_t]?.stringValue || "";
		t.ds(__PRIVATE_normalizeByteString(r));
	}
	ws(e, t) {
		this.Ps(t, 31);
		const r = (e.fields || {})[Et]?.bytesValue || "";
		t.ds(__PRIVATE_normalizeByteString(r)), this.fs(t);
	}
	bs(e, t) {
		this.Ps(t, 47);
		const r = (e.fields || {})[rt]?.mapValue?.fields || {};
		r && (t.Ms(r[it]?.stringValue || ""), t.Ms(r[st]?.stringValue || "")), this.fs(t);
	}
};
__PRIVATE_FirestoreIndexValueWriter.Ns = new __PRIVATE_FirestoreIndexValueWriter();
/**
* @license
* Copyright 2021 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law | agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES | CONDITIONS OF ANY KIND, either express | implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* An in-memory implementation of IndexManager.
*/ var __PRIVATE_MemoryIndexManager = class {
	constructor() {
		this.A_ = new __PRIVATE_MemoryCollectionParentIndex();
	}
	addToCollectionParentIndex(e, t) {
		return this.A_.add(t), PersistencePromise.resolve();
	}
	getCollectionParents(e, t) {
		return PersistencePromise.resolve(this.A_.getEntries(t));
	}
	addFieldIndex(e, t) {
		return PersistencePromise.resolve();
	}
	deleteFieldIndex(e, t) {
		return PersistencePromise.resolve();
	}
	deleteAllFieldIndexes(e) {
		return PersistencePromise.resolve();
	}
	createTargetIndexes(e, t) {
		return PersistencePromise.resolve();
	}
	getDocumentsMatchingTarget(e, t) {
		return PersistencePromise.resolve(null);
	}
	getIndexType(e, t) {
		return PersistencePromise.resolve(0);
	}
	getFieldIndexes(e, t) {
		return PersistencePromise.resolve([]);
	}
	getNextCollectionGroupToUpdate(e) {
		return PersistencePromise.resolve(null);
	}
	getMinOffset(e, t) {
		return PersistencePromise.resolve(IndexOffset.min());
	}
	getMinOffsetFromCollectionGroup(e, t) {
		return PersistencePromise.resolve(IndexOffset.min());
	}
	updateCollectionGroup(e, t, n) {
		return PersistencePromise.resolve();
	}
	updateIndexEntries(e, t) {
		return PersistencePromise.resolve();
	}
};
/**
* Internal implementation of the collection-parent index exposed by MemoryIndexManager.
* Also used for in-memory caching by IndexedDbIndexManager and initial index population
* in indexeddb_schema.ts
*/ var __PRIVATE_MemoryCollectionParentIndex = class {
	constructor() {
		this.index = {};
	}
	add(e) {
		const t = e.lastSegment(), n = e.popLast(), r = this.index[t] || new SortedSet(ResourcePath.comparator), i = !r.has(n);
		return this.index[t] = r.add(n), i;
	}
	has(e) {
		const t = e.lastSegment(), n = e.popLast(), r = this.index[t];
		return r && r.has(n);
	}
	getEntries(e) {
		return (this.index[e] || new SortedSet(ResourcePath.comparator)).toArray();
	}
};
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/** Offset to ensure non-overlapping target ids. */
/**
* Generates monotonically increasing target IDs for sending targets to the
* watch stream.
*
* The client constructs two generators, one for the target cache, and one for
* for the sync engine (to generate limbo documents targets). These
* generators produce non-overlapping IDs (by using even and odd IDs
* respectively).
*
* By separating the target ID space, the query cache can generate target IDs
* that persist across client restarts, while sync engine can independently
* generate in-memory target IDs that are transient and can be reused after a
* restart.
*/
var __PRIVATE_TargetIdGenerator = class __PRIVATE_TargetIdGenerator {
	constructor(e) {
		this.Q_ = e;
	}
	next() {
		return this.Q_ += 2, this.Q_;
	}
	static q_() {
		return new __PRIVATE_TargetIdGenerator(0);
	}
	static K_() {
		return new __PRIVATE_TargetIdGenerator(-1);
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
// Copyright 2024 Google LLC* @license
function __PRIVATE_runPipeline(e, t) {
	let n = t;
	for (const t of e.stages) n = evaluate({
		serializer: e.serializer,
		serverTimestampBehavior: e.listenOptions?.serverTimestampBehavior
	}, t, n);
	return n;
}
function __PRIVATE_pipelineMatches(e, t) {
	return __PRIVATE_runPipeline(e, [t]).length > 0;
}
function __PRIVATE_queryOrPipelineMatches(e, t) {
	return __PRIVATE_isPipeline(e) ? __PRIVATE_pipelineMatches(e, t) : __PRIVATE_queryMatches(e, t);
}
function evaluate(e, t, n) {
	if (t instanceof X) return function __PRIVATE_evaluateCollection(e, t, n) {
		return n.filter(((e) => e.isFoundDocument() && `/${e.key.getCollectionPath().canonicalString()}` === t.pi));
	}(0, t, n);
	if (t instanceof A) return function __PRIVATE_evaluateWhere(e, t, n) {
		return n.filter(((n) => {
			const r = __PRIVATE_valueOrUndefined(__PRIVATE_toEvaluable(t.condition).evaluate(e, n));
			return void 0 !== r && __PRIVATE_valueEquals$1(r, wt);
		}));
	}(e, t, n);
	if (t instanceof Y) return function __PRIVATE_evaluateCollectionGroup(e, t, n) {
		return n.filter(((e) => e.isFoundDocument() && e.key.getCollectionPath().lastSegment() === t.collectionId));
	}(0, t, n);
	if (t instanceof Z) return function __PRIVATE_evaluateDatabase(e, t, n) {
		return n.filter(((e) => e.isFoundDocument()));
	}(0, 0, n);
	if (t instanceof sa) return function __PRIVATE_evaluateDocuments(e, t, n) {
		return n.filter(((e) => e.isFoundDocument() && t.yi.has(e.key.path.toStringWithLeadingSlash())));
	}(0, t, n);
	if (t instanceof v) return function __PRIVATE_evaluateLimit(e, t, n) {
		return n.slice(0, t.limit);
	}(0, t, n);
	if (t instanceof L) return function __PRIVATE_evaluateSort(e, t, n) {
		const r = t.orderings.map(((e) => ({
			Z_: __PRIVATE_toEvaluable(e.expr),
			direction: e.direction
		})));
		return [...n].sort(((t, n) => {
			for (const { Z_: i, direction: s } of r) {
				const r = __PRIVATE_valueOrUndefined(i.evaluate(e, t)), _ = __PRIVATE_valueOrUndefined(i.evaluate(e, n)), o = __PRIVATE_valueCompare(r ?? ht, _ ?? ht);
				if (0 !== o) return "ascending" === s ? o : -o;
			}
			return 0;
		}));
	}(e, t, n);
	throw new Error(`Unknown stage: ${t._name}`);
}
function __PRIVATE_newPipelineComparator(e) {
	const t = function __PRIVATE_lastEffectiveSort(e) {
		for (let t = e.stages.length - 1; t >= 0; t--) {
			const n = e.stages[t];
			if (n instanceof L) return n.orderings;
		}
		throw new Error("Pipeline must contain at least one Sort stage");
	}(e);
	return (n, r) => {
		for (const i of t) {
			const t = __PRIVATE_valueOrUndefined(__PRIVATE_toEvaluable(i.expr).evaluate({ serializer: e.serializer }, n)), s = __PRIVATE_valueOrUndefined(__PRIVATE_toEvaluable(i.expr).evaluate({ serializer: e.serializer }, r)), _ = __PRIVATE_valueCompare(t || ht, s || ht);
			if (0 !== _) return "ascending" === i.direction ? _ : -_;
		}
		return 0;
	};
}
function __PRIVATE_getLastEffectiveLimit(e) {
	for (let t = e.stages.length - 1; t >= 0; t--) {
		const n = e.stages[t];
		if (n instanceof v) return { limit: n.limit };
	}
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* An in-memory buffer of entries to be written to a RemoteDocumentCache.
* It can be used to batch up a set of changes to be written to the cache, but
* additionally supports reading entries back with the `getEntry()` method,
* falling back to the underlying RemoteDocumentCache if no entry is
* buffered.
*
* Entries added to the cache *must* be read first. This is to facilitate
* calculating the size delta of the pending changes.
*
* PORTING NOTE: This class was implemented then removed from other platforms.
* If byte-counting ends up being needed on the other platforms, consider
* porting this class as part of that implementation work.
*/ var RemoteDocumentChangeBuffer = class {
	constructor() {
		this.changes = new ObjectMap(((e) => e.toString()), ((e, t) => e.isEqual(t))), this.changesApplied = false;
	}
	/**
	* Buffers a `RemoteDocumentCache.addEntry()` call.
	*
	* You can only modify documents that have already been retrieved via
	* `getEntry()/getEntries()` (enforced via IndexedDbs `apply()`).
	*/ addEntry(e) {
		this.assertNotApplied(), this.changes.set(e.key, e);
	}
	/**
	* Buffers a `RemoteDocumentCache.removeEntry()` call.
	*
	* You can only remove documents that have already been retrieved via
	* `getEntry()/getEntries()` (enforced via IndexedDbs `apply()`).
	*/ removeEntry(e, t) {
		this.assertNotApplied(), this.changes.set(e, MutableDocument.newInvalidDocument(e).setReadTime(t));
	}
	/**
	* Looks up an entry in the cache. The buffered changes will first be checked,
	* and if no buffered change applies, this will forward to
	* `RemoteDocumentCache.getEntry()`.
	*
	* @param transaction - The transaction in which to perform any persistence
	*     operations.
	* @param documentKey - The key of the entry to look up.
	* @returns The cached document or an invalid document if we have nothing
	* cached.
	*/ getEntry(e, t) {
		this.assertNotApplied();
		const n = this.changes.get(t);
		return void 0 !== n ? PersistencePromise.resolve(n) : this.getFromCache(e, t);
	}
	/**
	* Looks up several entries in the cache, forwarding to
	* `RemoteDocumentCache.getEntry()`.
	*
	* @param transaction - The transaction in which to perform any persistence
	*     operations.
	* @param documentKeys - The keys of the entries to look up.
	* @returns A map of cached documents, indexed by key. If an entry cannot be
	*     found, the corresponding key will be mapped to an invalid document.
	*/ getEntries(e, t) {
		return this.getAllFromCache(e, t);
	}
	/**
	* Applies buffered changes to the underlying RemoteDocumentCache, using
	* the provided transaction.
	*/ apply(e) {
		return this.assertNotApplied(), this.changesApplied = true, this.applyChanges(e);
	}
	/** Helper to assert this.changes is not null  */ assertNotApplied() {}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Schema Version for the Web client:
* 1.  Initial version including Mutation Queue, Query Cache, and Remote
*     Document Cache
* 2.  Used to ensure a targetGlobal object exists and add targetCount to it. No
*     longer required because migration 3 unconditionally clears it.
* 3.  Dropped and re-created Query Cache to deal with cache corruption related
*     to limbo resolution. Addresses
*     https://github.com/firebase/firebase-ios-sdk/issues/1548
* 4.  Multi-Tab Support.
* 5.  Removal of held write acks.
* 6.  Create document global for tracking document cache size.
* 7.  Ensure every cached document has a sentinel row with a sequence number.
* 8.  Add collection-parent index for Collection Group queries.
* 9.  Change RemoteDocumentChanges store to be keyed by readTime rather than
*     an auto-incrementing ID. This is required for Index-Free queries.
* 10. Rewrite the canonical IDs to the explicit Protobuf-based format.
* 11. Add bundles and named_queries for bundle support.
* 12. Add document overlays.
* 13. Rewrite the keys of the remote document cache to allow for efficient
*     document lookup via `getAll()`.
* 14. Add overlays.
* 15. Add indexing support.
* 16. Parse timestamp strings before creating index entries.
* 17. TODO(tomandersen)
* 18. Encode key safe representations of IndexEntry in DbIndexEntryStore.
*/
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Represents a local view (overlay) of a document, and the fields that are
* locally mutated.
*/
var OverlayedDocument = class {
	constructor(e, t) {
		this.overlayedDocument = e, this.mutatedFields = t;
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* A readonly view of the local state of all documents we're tracking (i.e. we
* have a cached version in remoteDocumentCache or local mutations for the
* document). The view is computed by applying the mutations in the
* MutationQueue to the RemoteDocumentCache.
*/ var LocalDocumentsView = class {
	constructor(e, t, n, r) {
		this.remoteDocumentCache = e, this.mutationQueue = t, this.documentOverlayCache = n, this.indexManager = r;
	}
	/**
	* Get the local view of the document identified by `key`.
	*
	* @returns Local view of the document or null if we don't have any cached
	* state for it.
	*/ getDocument(e, t) {
		let n = null;
		return this.documentOverlayCache.getOverlay(e, t).next(((r) => (n = r, this.remoteDocumentCache.getEntry(e, t)))).next(((e) => (null !== n && __PRIVATE_mutationApplyToLocalView(n.mutation, e, FieldMask.empty(), Timestamp.now()), e)));
	}
	/**
	* Gets the local view of the documents identified by `keys`.
	*
	* If we don't have cached state for a document in `keys`, a NoDocument will
	* be stored for that key in the resulting set.
	*/ getDocuments(e, t) {
		return this.remoteDocumentCache.getEntries(e, t).next(((t) => this.getLocalViewOfDocuments(e, t, __PRIVATE_documentKeySet()).next((() => t))));
	}
	/**
	* Similar to `getDocuments`, but creates the local view from the given
	* `baseDocs` without retrieving documents from the local store.
	*
	* @param transaction - The transaction this operation is scoped to.
	* @param docs - The documents to apply local mutations to get the local views.
	* @param existenceStateChanged - The set of document keys whose existence state
	*   is changed. This is useful to determine if some documents overlay needs
	*   to be recalculated.
	*/ getLocalViewOfDocuments(e, t, n = __PRIVATE_documentKeySet()) {
		const r = __PRIVATE_newOverlayMap();
		return this.populateOverlays(e, r, t).next((() => this.computeViews(e, t, r, n).next(((e) => {
			let t = documentMap();
			return e.forEach(((e, n) => {
				t = t.insert(e, n.overlayedDocument);
			})), t;
		}))));
	}
	/**
	* Gets the overlayed documents for the given document map, which will include
	* the local view of those documents and a `FieldMask` indicating which fields
	* are mutated locally, `null` if overlay is a Set or Delete mutation.
	*/ getOverlayedDocuments(e, t) {
		const n = __PRIVATE_newOverlayMap();
		return this.populateOverlays(e, n, t).next((() => this.computeViews(e, t, n, __PRIVATE_documentKeySet())));
	}
	/**
	* Fetches the overlays for {@code docs} and adds them to provided overlay map
	* if the map does not already contain an entry for the given document key.
	*/ populateOverlays(e, t, n) {
		const r = [];
		return n.forEach(((e) => {
			t.has(e) || r.push(e);
		})), this.documentOverlayCache.getOverlays(e, r).next(((e) => {
			e.forEach(((e, n) => {
				t.set(e, n);
			}));
		}));
	}
	/**
	* Computes the local view for the given documents.
	*
	* @param docs - The documents to compute views for. It also has the base
	*   version of the documents.
	* @param overlays - The overlays that need to be applied to the given base
	*   version of the documents.
	* @param existenceStateChanged - A set of documents whose existence states
	*   might have changed. This is used to determine if we need to re-calculate
	*   overlays from mutation queues.
	* @returns A map represents the local documents view.
	*/ computeViews(e, t, n, r) {
		let i = __PRIVATE_mutableDocumentMap();
		const s = __PRIVATE_newDocumentKeyMap(), _ = function __PRIVATE_newOverlayedDocumentMap() {
			return __PRIVATE_newDocumentKeyMap();
		}();
		return t.forEach(((e, t) => {
			const _ = n.get(t.key);
			r.has(t.key) && (void 0 === _ || _.mutation instanceof __PRIVATE_PatchMutation) ? i = i.insert(t.key, t) : void 0 !== _ ? (s.set(t.key, _.mutation.getFieldMask()), __PRIVATE_mutationApplyToLocalView(_.mutation, t, _.mutation.getFieldMask(), Timestamp.now())) : s.set(t.key, FieldMask.empty());
		})), this.recalculateAndSaveOverlays(e, i).next(((e) => (e.forEach(((e, t) => s.set(e, t))), t.forEach(((e, t) => _.set(e, new OverlayedDocument(t, s.get(e) ?? null)))), _)));
	}
	recalculateAndSaveOverlays(e, t) {
		const n = __PRIVATE_newDocumentKeyMap();
		let r = new SortedMap(((e, t) => e - t)), i = __PRIVATE_documentKeySet();
		return this.mutationQueue.getAllMutationBatchesAffectingDocumentKeys(e, t).next(((e) => {
			for (const i of e) i.keys().forEach(((e) => {
				const s = t.get(e);
				if (null === s) return;
				let _ = n.get(e) || FieldMask.empty();
				_ = i.applyToLocalView(s, _), n.set(e, _);
				const o = (r.get(i.batchId) || __PRIVATE_documentKeySet()).add(e);
				r = r.insert(i.batchId, o);
			}));
		})).next((() => {
			const s = [], _ = r.getReverseIterator();
			for (; _.hasNext();) {
				const r = _.getNext(), o = r.key, a = r.value, u = __PRIVATE_newMutationMap();
				a.forEach(((e) => {
					if (!i.has(e)) {
						const r = __PRIVATE_calculateOverlayMutation(t.get(e), n.get(e));
						null !== r && u.set(e, r), i = i.add(e);
					}
				})), s.push(this.documentOverlayCache.saveOverlays(e, o, u));
			}
			return PersistencePromise.waitFor(s);
		})).next((() => n));
	}
	/**
	* Recalculates overlays by reading the documents from remote document cache
	* first, and saves them after they are calculated.
	*/ recalculateAndSaveOverlaysForDocumentKeys(e, t) {
		return this.remoteDocumentCache.getEntries(e, t).next(((t) => this.recalculateAndSaveOverlays(e, t)));
	}
	/**
	* Performs a query against the local view of all documents.
	*
	* @param transaction - The persistence transaction.
	* @param query - The query to match documents against.
	* @param offset - Read time and key to start scanning by (exclusive).
	* @param context - A optional tracker to keep a record of important details
	*   during database local query execution.
	*/ getDocumentsMatchingQuery(e, t, n, r) {
		return __PRIVATE_isPipeline(t) ? this.getDocumentsMatchingPipeline(e, t, n, r) : __PRIVATE_isDocumentQuery$1(t) ? this.getDocumentsMatchingDocumentQuery(e, t.path) : __PRIVATE_isCollectionGroupQuery(t) ? this.getDocumentsMatchingCollectionGroupQuery(e, t, n, r) : this.getDocumentsMatchingCollectionQuery(e, t, n, r);
	}
	/**
	* Given a collection group, returns the next documents that follow the provided offset, along
	* with an updated batch ID.
	*
	* <p>The documents returned by this method are ordered by remote version from the provided
	* offset. If there are no more remote documents after the provided offset, documents with
	* mutations in order of batch id from the offset are returned. Since all documents in a batch are
	* returned together, the total number of documents returned can exceed {@code count}.
	*
	* @param transaction
	* @param collectionGroup - The collection group for the documents.
	* @param offset - The offset to index into.
	* @param count - The number of documents to return
	* @returns A LocalWriteResult with the documents that follow the provided offset and the last processed batch id.
	*/ getNextDocuments(e, t, n, r) {
		return this.remoteDocumentCache.getAllFromCollectionGroup(e, t, n, r).next(((i) => {
			const s = r - i.size > 0 ? this.documentOverlayCache.getOverlaysForCollectionGroup(e, t, n.largestBatchId, r - i.size) : PersistencePromise.resolve(__PRIVATE_newOverlayMap());
			let _ = St, o = i;
			return s.next(((t) => PersistencePromise.forEach(t, ((t, n) => (_ < n.largestBatchId && (_ = n.largestBatchId), i.get(t) ? PersistencePromise.resolve() : this.remoteDocumentCache.getEntry(e, t).next(((e) => {
				o = o.insert(t, e);
			}))))).next((() => this.populateOverlays(e, t, i))).next((() => this.computeViews(e, o, t, __PRIVATE_documentKeySet()))).next(((e) => ({
				batchId: _,
				changes: __PRIVATE_convertOverlayedDocumentMapToDocumentMap(e)
			})))));
		}));
	}
	getDocumentsMatchingDocumentQuery(e, t) {
		return this.getDocument(e, new DocumentKey(t)).next(((e) => {
			let t = documentMap();
			return e.isFoundDocument() && (t = t.insert(e.key, e)), t;
		}));
	}
	getDocumentsMatchingCollectionGroupQuery(e, t, n, r) {
		const i = t.collectionGroup;
		let s = documentMap();
		return this.indexManager.getCollectionParents(e, i).next(((_) => PersistencePromise.forEach(_, ((_) => {
			const o = function __PRIVATE_asCollectionQueryAtPath(e, t) {
				return new __PRIVATE_QueryImpl(t, null, e.explicitOrderBy.slice(), e.filters.slice(), e.limit, e.limitType, e.startAt, e.endAt);
			}(t, _.child(i));
			return this.getDocumentsMatchingCollectionQuery(e, o, n, r).next(((e) => {
				e.forEach(((e, t) => {
					s = s.insert(e, t);
				}));
			}));
		})).next((() => s))));
	}
	getDocumentsMatchingCollectionQuery(e, t, n, r) {
		let i;
		return this.documentOverlayCache.getOverlaysForCollection(e, t.path, n.largestBatchId).next(((s) => (i = s, this.remoteDocumentCache.getDocumentsMatchingQuery(e, t, n, i, r)))).next(((e) => this.retrieveMatchingLocalDocuments(i, e, ((e) => __PRIVATE_queryMatches(t, e)))));
	}
	getDocumentsMatchingPipeline(t, n, r, i) {
		if ("collection_group" === getPipelineSourceType(n)) {
			const e = getPipelineCollectionGroup(n);
			let s = documentMap();
			return this.indexManager.getCollectionParents(t, e).next(((_) => PersistencePromise.forEach(_, ((_) => {
				const o = function __PRIVATE_asCollectionPipelineAtPath(e, t) {
					const n = e.stages.map(((e) => e instanceof Y ? new X(t.canonicalString(), {}) : e));
					return new CorePipeline(e.serializer, n);
				}(n, _.child(e));
				return this.getDocumentsMatchingPipeline(t, o, r, i).next(((e) => {
					e.forEach(((e, t) => {
						s = s.insert(e, t);
					}));
				}));
			})).next((() => s))));
		}
		{
			let s;
			return this.getOverlaysForPipeline(t, n, r.largestBatchId).next(((_) => {
				switch (s = _, getPipelineSourceType(n)) {
					case "collection": return this.remoteDocumentCache.getDocumentsMatchingQuery(t, n, r, s, i);
					case "documents":
						let _ = __PRIVATE_documentKeySet();
						for (const e of getPipelineDocuments(n)) _ = _.add(DocumentKey.fromPath(e));
						return this.remoteDocumentCache.getEntries(t, _);
					case "database": return this.remoteDocumentCache.getAllEntries(t);
					default: throw new e("invalid-argument", `Invalid pipeline source to execute offline: ${__PRIVATE_canonifyPipeline(n)}`);
				}
			})).next(((e) => this.retrieveMatchingLocalDocuments(s, e, ((e) => __PRIVATE_pipelineMatches(n, e)))));
		}
	}
	retrieveMatchingLocalDocuments(e, t, n) {
		e.forEach(((e, n) => {
			const r = n.getKey();
			null === t.get(r) && (t = t.insert(r, MutableDocument.newInvalidDocument(r)));
		}));
		let r = documentMap();
		return t.forEach(((t, i) => {
			const s = e.get(t);
			void 0 !== s && __PRIVATE_mutationApplyToLocalView(s.mutation, i, FieldMask.empty(), Timestamp.now()), n(i) && (r = r.insert(t, i));
		})), r;
	}
	getOverlaysForPipeline(t, n, r) {
		switch (getPipelineSourceType(n)) {
			case "collection": return this.documentOverlayCache.getOverlaysForCollection(t, ResourcePath.fromString(getPipelineCollection(n)), r);
			case "collection_group": throw new e("invalid-argument", `Unexpected collection group pipeline: ${__PRIVATE_canonifyPipeline(n)}`);
			case "documents": return this.documentOverlayCache.getOverlays(t, getPipelineDocuments(n).map(((e) => DocumentKey.fromPath(e))));
			case "database": return this.documentOverlayCache.getAllOverlays(t, r);
			default: throw new e("invalid-argument", `Failed to get overlays for pipeline: ${__PRIVATE_canonifyPipeline(n)}`);
		}
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var __PRIVATE_MemoryBundleCache = class {
	constructor(e) {
		this.serializer = e, this.ao = /* @__PURE__ */ new Map(), this.uo = /* @__PURE__ */ new Map();
	}
	getBundleMetadata(e, t) {
		return PersistencePromise.resolve(this.ao.get(t));
	}
	saveBundleMetadata(e, t) {
		return this.ao.set(
			t.id,
			/** Decodes a BundleMetadata proto into a BundleMetadata object. */
			function __PRIVATE_fromBundleMetadata(e) {
				return {
					id: e.id,
					version: e.version,
					createTime: __PRIVATE_fromVersion(e.createTime)
				};
			}(t)
		), PersistencePromise.resolve();
	}
	getNamedQuery(e, t) {
		return PersistencePromise.resolve(this.uo.get(t));
	}
	saveNamedQuery(e, t) {
		return this.uo.set(t.name, function __PRIVATE_fromProtoNamedQuery(e) {
			return {
				name: e.name,
				query: __PRIVATE_fromBundledQuery(e.bundledQuery),
				readTime: __PRIVATE_fromVersion(e.readTime)
			};
		}(t)), PersistencePromise.resolve();
	}
};
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* An in-memory implementation of DocumentOverlayCache.
*/ var __PRIVATE_MemoryDocumentOverlayCache = class {
	constructor() {
		this.overlays = new SortedMap(DocumentKey.comparator), this.co = /* @__PURE__ */ new Map();
	}
	getOverlay(e, t) {
		return PersistencePromise.resolve(this.overlays.get(t));
	}
	getOverlays(e, t) {
		const n = __PRIVATE_newOverlayMap();
		return PersistencePromise.forEach(t, ((t) => this.getOverlay(e, t).next(((e) => {
			null !== e && n.set(t, e);
		})))).next((() => n));
	}
	getAllOverlays(e, t) {
		const n = __PRIVATE_newOverlayMap();
		return this.overlays.forEach(((e, r) => {
			r.largestBatchId > t && n.set(e, r);
		})), PersistencePromise.resolve(n);
	}
	saveOverlays(e, t, n) {
		return n.forEach(((n, r) => {
			this.cs(e, t, r);
		})), PersistencePromise.resolve();
	}
	removeOverlaysForBatchId(e, t, n) {
		const r = this.co.get(n);
		return void 0 !== r && (r.forEach(((e) => this.overlays = this.overlays.remove(e))), this.co.delete(n)), PersistencePromise.resolve();
	}
	getOverlaysForCollection(e, t, n) {
		const r = __PRIVATE_newOverlayMap(), i = t.length + 1, s = new DocumentKey(t.child("")), _ = this.overlays.getIteratorFrom(s);
		for (; _.hasNext();) {
			const e = _.getNext().value, s = e.getKey();
			if (!t.isPrefixOf(s.path)) break;
			s.path.length === i && e.largestBatchId > n && r.set(e.getKey(), e);
		}
		return PersistencePromise.resolve(r);
	}
	getOverlaysForCollectionGroup(e, t, n, r) {
		let i = new SortedMap(((e, t) => e - t));
		const s = this.overlays.getIterator();
		for (; s.hasNext();) {
			const e = s.getNext().value;
			if (e.getKey().getCollectionGroup() === t && e.largestBatchId > n) {
				let t = i.get(e.largestBatchId);
				null === t && (t = __PRIVATE_newOverlayMap(), i = i.insert(e.largestBatchId, t)), t.set(e.getKey(), e);
			}
		}
		const _ = __PRIVATE_newOverlayMap(), o = i.getIterator();
		for (; o.hasNext();) if (o.getNext().value.forEach(((e, t) => _.set(e, t))), _.size() >= r) break;
		return PersistencePromise.resolve(_);
	}
	cs(e, t, n) {
		const r = this.overlays.get(n.key);
		if (null !== r) {
			const e = this.co.get(r.largestBatchId).delete(n.key);
			this.co.set(r.largestBatchId, e);
		}
		this.overlays = this.overlays.insert(n.key, new Overlay(t, n));
		let i = this.co.get(t);
		void 0 === i && (i = __PRIVATE_documentKeySet(), this.co.set(t, i)), this.co.set(t, i.add(n.key));
	}
};
/**
* @license
* Copyright 2024 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var __PRIVATE_MemoryGlobalsCache = class {
	constructor() {
		this.sessionToken = ByteString.EMPTY_BYTE_STRING;
	}
	getSessionToken(e) {
		return PersistencePromise.resolve(this.sessionToken);
	}
	setSessionToken(e, t) {
		return this.sessionToken = t, PersistencePromise.resolve();
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* A collection of references to a document from some kind of numbered entity
* (either a target ID or batch ID). As references are added to or removed from
* the set corresponding events are emitted to a registered garbage collector.
*
* Each reference is represented by a DocumentReference object. Each of them
* contains enough information to uniquely identify the reference. They are all
* stored primarily in a set sorted by key. A document is considered garbage if
* there's no references in that set (this can be efficiently checked thanks to
* sorting by key).
*
* ReferenceSet also keeps a secondary set that contains references sorted by
* IDs. This one is used to efficiently implement removal of all references by
* some target ID.
*/ var __PRIVATE_ReferenceSet = class {
	constructor() {
		this.lo = new SortedSet(__PRIVATE_DocReference.Eo), this.ho = new SortedSet(__PRIVATE_DocReference.To);
	}
	/** Returns true if the reference set contains no references. */ isEmpty() {
		return this.lo.isEmpty();
	}
	/** Adds a reference to the given document key for the given ID. */ addReference(e, t) {
		const n = new __PRIVATE_DocReference(e, t);
		this.lo = this.lo.add(n), this.ho = this.ho.add(n);
	}
	/** Add references to the given document keys for the given ID. */ Po(e, t) {
		e.forEach(((e) => this.addReference(e, t)));
	}
	/**
	* Removes a reference to the given document key for the given
	* ID.
	*/ removeReference(e, t) {
		this.Io(new __PRIVATE_DocReference(e, t));
	}
	Ro(e, t) {
		e.forEach(((e) => this.removeReference(e, t)));
	}
	/**
	* Clears all references with a given ID. Calls removeRef() for each key
	* removed.
	*/ Ao(e) {
		const t = new DocumentKey(new ResourcePath([])), n = new __PRIVATE_DocReference(t, e), r = new __PRIVATE_DocReference(t, e + 1), i = [];
		return this.ho.forEachInRange([n, r], ((e) => {
			this.Io(e), i.push(e.key);
		})), i;
	}
	Vo() {
		this.lo.forEach(((e) => this.Io(e)));
	}
	Io(e) {
		this.lo = this.lo.delete(e), this.ho = this.ho.delete(e);
	}
	fo(e) {
		const t = new DocumentKey(new ResourcePath([])), n = new __PRIVATE_DocReference(t, e), r = new __PRIVATE_DocReference(t, e + 1);
		let i = __PRIVATE_documentKeySet();
		return this.ho.forEachInRange([n, r], ((e) => {
			i = i.add(e.key);
		})), i;
	}
	containsKey(e) {
		const t = new __PRIVATE_DocReference(e, 0), n = this.lo.firstAfterOrEqual(t);
		return null !== n && e.isEqual(n.key);
	}
};
var __PRIVATE_DocReference = class {
	constructor(e, t) {
		this.key = e, this.mo = t;
	}
	/** Compare by key then by ID */ static Eo(e, t) {
		return DocumentKey.comparator(e.key, t.key) || __PRIVATE_primitiveComparator(e.mo, t.mo);
	}
	/** Compare by ID then by key */ static To(e, t) {
		return __PRIVATE_primitiveComparator(e.mo, t.mo) || DocumentKey.comparator(e.key, t.key);
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var __PRIVATE_MemoryMutationQueue = class {
	constructor(e, t) {
		this.indexManager = e, this.referenceDelegate = t, this.mutationQueue = [], this.ts = 1, this.po = new SortedSet(__PRIVATE_DocReference.Eo);
	}
	checkEmpty(e) {
		return PersistencePromise.resolve(0 === this.mutationQueue.length);
	}
	addMutationBatch(e, t, n, r) {
		const i = this.ts;
		this.ts++, this.mutationQueue.length > 0 && this.mutationQueue[this.mutationQueue.length - 1];
		const s = new MutationBatch(i, t, n, r);
		this.mutationQueue.push(s);
		for (const t of r) this.po = this.po.add(new __PRIVATE_DocReference(t.key, i)), this.indexManager.addToCollectionParentIndex(e, t.key.path.popLast());
		return PersistencePromise.resolve(s);
	}
	lookupMutationBatch(e, t) {
		return PersistencePromise.resolve(this.yo(t));
	}
	getNextMutationBatchAfterBatchId(e, t) {
		const n = t + 1, r = this.wo(n), i = r < 0 ? 0 : r;
		return PersistencePromise.resolve(this.mutationQueue.length > i ? this.mutationQueue[i] : null);
	}
	getHighestUnacknowledgedBatchId() {
		return PersistencePromise.resolve(0 === this.mutationQueue.length ? Je : this.ts - 1);
	}
	getAllMutationBatches(e) {
		return PersistencePromise.resolve(this.mutationQueue.slice());
	}
	getAllMutationBatchesAffectingDocumentKey(e, t) {
		const n = new __PRIVATE_DocReference(t, 0), r = new __PRIVATE_DocReference(t, Number.POSITIVE_INFINITY), i = [];
		return this.po.forEachInRange([n, r], ((e) => {
			const t = this.yo(e.mo);
			i.push(t);
		})), PersistencePromise.resolve(i);
	}
	getAllMutationBatchesAffectingDocumentKeys(e, t) {
		let n = new SortedSet(__PRIVATE_primitiveComparator);
		return t.forEach(((e) => {
			const t = new __PRIVATE_DocReference(e, 0), r = new __PRIVATE_DocReference(e, Number.POSITIVE_INFINITY);
			this.po.forEachInRange([t, r], ((e) => {
				n = n.add(e.mo);
			}));
		})), PersistencePromise.resolve(this.bo(n));
	}
	getAllMutationBatchesAffectingQuery(e, t) {
		const n = t.path, r = n.length + 1;
		let i = n;
		DocumentKey.isDocumentKey(i) || (i = i.child(""));
		const s = new __PRIVATE_DocReference(new DocumentKey(i), 0);
		let _ = new SortedSet(__PRIVATE_primitiveComparator);
		return this.po.forEachWhile(((e) => {
			const t = e.key.path;
			return !!n.isPrefixOf(t) && (t.length === r && (_ = _.add(e.mo)), true);
		}), s), PersistencePromise.resolve(this.bo(_));
	}
	bo(e) {
		const t = [];
		return e.forEach(((e) => {
			const n = this.yo(e);
			null !== n && t.push(n);
		})), t;
	}
	removeMutationBatch(e, t) {
		__PRIVATE_hardAssert(0 === this.So(t.batchId, "removed"), 55003), this.mutationQueue.shift();
		let n = this.po;
		return PersistencePromise.forEach(t.mutations, ((r) => {
			const i = new __PRIVATE_DocReference(r.key, t.batchId);
			return n = n.delete(i), this.referenceDelegate.markPotentiallyOrphaned(e, r.key);
		})).next((() => {
			this.po = n;
		}));
	}
	ss(e) {}
	containsKey(e, t) {
		const n = new __PRIVATE_DocReference(t, 0), r = this.po.firstAfterOrEqual(n);
		return PersistencePromise.resolve(t.isEqual(r && r.key));
	}
	performConsistencyCheck(e) {
		return this.mutationQueue.length, PersistencePromise.resolve();
	}
	/**
	* Finds the index of the given batchId in the mutation queue and asserts that
	* the resulting index is within the bounds of the queue.
	*
	* @param batchId - The batchId to search for
	* @param action - A description of what the caller is doing, phrased in passive
	* form (e.g. "acknowledged" in a routine that acknowledges batches).
	*/ So(e, t) {
		return this.wo(e);
	}
	/**
	* Finds the index of the given batchId in the mutation queue. This operation
	* is O(1).
	*
	* @returns The computed index of the batch with the given batchId, based on
	* the state of the queue. Note this index can be negative if the requested
	* batchId has already been removed from the queue or past the end of the
	* queue if the batchId is larger than the last added batch.
	*/ wo(e) {
		if (0 === this.mutationQueue.length) return 0;
		return e - this.mutationQueue[0].batchId;
	}
	/**
	* A version of lookupMutationBatch that doesn't return a promise, this makes
	* other functions that uses this code easier to read and more efficient.
	*/ yo(e) {
		const t = this.wo(e);
		if (t < 0 || t >= this.mutationQueue.length) return null;
		return this.mutationQueue[t];
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* The smallest value representable by a 64-bit signed integer (long).
*/
/**
* The memory-only RemoteDocumentCache for IndexedDb. To construct, invoke
* `newMemoryRemoteDocumentCache()`.
*/
var __PRIVATE_MemoryRemoteDocumentCacheImpl = class {
	/**
	* @param sizer - Used to assess the size of a document. For eager GC, this is
	* expected to just return 0 to avoid unnecessarily doing the work of
	* calculating the size.
	*/
	constructor(e) {
		this.xo = e, this.docs = function __PRIVATE_documentEntryMap() {
			return new SortedMap(DocumentKey.comparator);
		}(), this.size = 0;
	}
	setIndexManager(e) {
		this.indexManager = e;
	}
	/**
	* Adds the supplied entry to the cache and updates the cache size as appropriate.
	*
	* All calls of `addEntry`  are required to go through the RemoteDocumentChangeBuffer
	* returned by `newChangeBuffer()`.
	*/ addEntry(e, t) {
		const n = t.key, r = this.docs.get(n), i = r ? r.size : 0, s = this.xo(t);
		return this.docs = this.docs.insert(n, {
			document: t.mutableCopy(),
			size: s
		}), this.size += s - i, this.indexManager.addToCollectionParentIndex(e, n.path.popLast());
	}
	/**
	* Removes the specified entry from the cache and updates the cache size as appropriate.
	*
	* All calls of `removeEntry` are required to go through the RemoteDocumentChangeBuffer
	* returned by `newChangeBuffer()`.
	*/ removeEntry(e) {
		const t = this.docs.get(e);
		t && (this.docs = this.docs.remove(e), this.size -= t.size);
	}
	getEntry(e, t) {
		const n = this.docs.get(t);
		return PersistencePromise.resolve(n ? n.document.mutableCopy() : MutableDocument.newInvalidDocument(t));
	}
	getEntries(e, t) {
		let n = __PRIVATE_mutableDocumentMap();
		return t.forEach(((e) => {
			const t = this.docs.get(e);
			n = n.insert(e, t ? t.document.mutableCopy() : MutableDocument.newInvalidDocument(e));
		})), PersistencePromise.resolve(n);
	}
	getAllEntries(e) {
		let t = __PRIVATE_mutableDocumentMap();
		return this.docs.forEach(((e, n) => {
			t = t.insert(e, n.document);
		})), PersistencePromise.resolve(t);
	}
	getDocumentsMatchingQuery(e, t, n, r) {
		let i, s;
		__PRIVATE_isPipeline(t) ? (i = ResourcePath.fromString(getPipelineCollection(t)), s = (e) => __PRIVATE_pipelineMatches(t, e)) : (i = t.path, s = (e) => __PRIVATE_queryMatches(t, e));
		let _ = __PRIVATE_mutableDocumentMap();
		const o = new DocumentKey(i.child("__id-9223372036854775808__")), a = this.docs.getIteratorFrom(o);
		for (; a.hasNext();) {
			const { key: e, value: { document: t } } = a.getNext();
			if (!i.isPrefixOf(e.path)) break;
			e.path.length > i.length + 1 || __PRIVATE_indexOffsetComparator(__PRIVATE_newIndexOffsetFromDocument(t), n) <= 0 || (r.has(t.key) || s(t)) && (_ = _.insert(t.key, t.mutableCopy()));
		}
		return PersistencePromise.resolve(_);
	}
	getAllFromCollectionGroup(e, t, n, r) {
		l(9500);
	}
	vo(e, t) {
		return PersistencePromise.forEach(this.docs, ((e) => t(e)));
	}
	newChangeBuffer(e) {
		return new __PRIVATE_MemoryRemoteDocumentChangeBuffer(this);
	}
	getSize(e) {
		return PersistencePromise.resolve(this.size);
	}
};
/**
* Creates a new memory-only RemoteDocumentCache.
*
* @param sizer - Used to assess the size of a document. For eager GC, this is
* expected to just return 0 to avoid unnecessarily doing the work of
* calculating the size.
*/
/**
* Handles the details of adding and updating documents in the MemoryRemoteDocumentCache.
*/
var __PRIVATE_MemoryRemoteDocumentChangeBuffer = class extends RemoteDocumentChangeBuffer {
	constructor(e) {
		super(), this._o = e;
	}
	applyChanges(e) {
		const t = [];
		return this.changes.forEach(((n, r) => {
			r.isValidDocument() ? t.push(this._o.addEntry(e, r)) : this._o.removeEntry(n);
		})), PersistencePromise.waitFor(t);
	}
	getFromCache(e, t) {
		return this._o.getEntry(e, t);
	}
	getAllFromCache(e, t) {
		return this._o.getEntries(e, t);
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var __PRIVATE_MemoryTargetCache = class {
	constructor(e) {
		this.persistence = e, this.Do = new ObjectMap(((e) => __PRIVATE_canonifyTargetOrPipeline(e)), __PRIVATE_targetOrPipelineEqual), this.lastRemoteSnapshotVersion = SnapshotVersion.min(), this.highestTargetId = 0, this.Co = 0, this.Fo = new __PRIVATE_ReferenceSet(), this.targetCount = 0, this.Oo = __PRIVATE_TargetIdGenerator.q_();
	}
	forEachTarget(e, t) {
		return this.Do.forEach(((e, n) => t(n))), PersistencePromise.resolve();
	}
	getLastRemoteSnapshotVersion(e) {
		return PersistencePromise.resolve(this.lastRemoteSnapshotVersion);
	}
	getHighestSequenceNumber(e) {
		return PersistencePromise.resolve(this.Co);
	}
	allocateTargetId(e) {
		return this.highestTargetId = this.Oo.next(), PersistencePromise.resolve(this.highestTargetId);
	}
	setTargetsMetadata(e, t, n) {
		return n && (this.lastRemoteSnapshotVersion = n), t > this.Co && (this.Co = t), PersistencePromise.resolve();
	}
	j_(e) {
		this.Do.set(e.target, e);
		const t = e.targetId;
		t > this.highestTargetId && (this.Oo = new __PRIVATE_TargetIdGenerator(t), this.highestTargetId = t), e.sequenceNumber > this.Co && (this.Co = e.sequenceNumber);
	}
	addTargetData(e, t) {
		return this.j_(t), this.targetCount += 1, PersistencePromise.resolve();
	}
	updateTargetData(e, t) {
		return this.j_(t), PersistencePromise.resolve();
	}
	removeTargetData(e, t) {
		return this.Do.delete(t.target), this.Fo.Ao(t.targetId), this.targetCount -= 1, PersistencePromise.resolve();
	}
	removeTargets(e, t, n) {
		let r = 0;
		const i = [];
		return this.Do.forEach(((s, _) => {
			_.sequenceNumber <= t && null === n.get(_.targetId) && (this.Do.delete(s), i.push(this.removeMatchingKeysForTargetId(e, _.targetId)), r++);
		})), PersistencePromise.waitFor(i).next((() => r));
	}
	getTargetCount(e) {
		return PersistencePromise.resolve(this.targetCount);
	}
	getTargetData(e, t) {
		const n = this.Do.get(t) || null;
		return PersistencePromise.resolve(n);
	}
	addMatchingKeys(e, t, n) {
		return this.Fo.Po(t, n), PersistencePromise.resolve();
	}
	removeMatchingKeys(e, t, n) {
		this.Fo.Ro(t, n);
		const r = this.persistence.referenceDelegate, i = [];
		return r && t.forEach(((t) => {
			i.push(r.markPotentiallyOrphaned(e, t));
		})), PersistencePromise.waitFor(i);
	}
	removeMatchingKeysForTargetId(e, t) {
		return this.Fo.Ao(t), PersistencePromise.resolve();
	}
	getMatchingKeysForTargetId(e, t) {
		const n = this.Fo.fo(t);
		return PersistencePromise.resolve(n);
	}
	containsKey(e, t) {
		return PersistencePromise.resolve(this.Fo.containsKey(t));
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* A memory-backed instance of Persistence. Data is stored only in RAM and
* not persisted across sessions.
*/
var __PRIVATE_MemoryPersistence = class {
	/**
	* The constructor accepts a factory for creating a reference delegate. This
	* allows both the delegate and this instance to have strong references to
	* each other without having nullable fields that would then need to be
	* checked or asserted on every access.
	*/
	constructor(e, t) {
		this.Mo = {}, this.overlays = {}, this.No = new __PRIVATE_ListenSequence(0), this.Bo = false, this.Bo = true, this.Lo = new __PRIVATE_MemoryGlobalsCache(), this.referenceDelegate = e(this), this.Uo = new __PRIVATE_MemoryTargetCache(this);
		this.indexManager = new __PRIVATE_MemoryIndexManager(), this.remoteDocumentCache = function __PRIVATE_newMemoryRemoteDocumentCache(e) {
			return new __PRIVATE_MemoryRemoteDocumentCacheImpl(e);
		}(((e) => this.referenceDelegate.ko(e))), this.serializer = new __PRIVATE_LocalSerializer(t), this.Qo = new __PRIVATE_MemoryBundleCache(this.serializer);
	}
	start() {
		return Promise.resolve();
	}
	shutdown() {
		return this.Bo = false, Promise.resolve();
	}
	get started() {
		return this.Bo;
	}
	setDatabaseDeletedListener() {}
	setNetworkEnabled() {}
	getIndexManager(e) {
		return this.indexManager;
	}
	getDocumentOverlayCache(e) {
		let t = this.overlays[e.toKey()];
		return t || (t = new __PRIVATE_MemoryDocumentOverlayCache(), this.overlays[e.toKey()] = t), t;
	}
	getMutationQueue(e, t) {
		let n = this.Mo[e.toKey()];
		return n || (n = new __PRIVATE_MemoryMutationQueue(t, this.referenceDelegate), this.Mo[e.toKey()] = n), n;
	}
	getGlobalsCache() {
		return this.Lo;
	}
	getTargetCache() {
		return this.Uo;
	}
	getRemoteDocumentCache() {
		return this.remoteDocumentCache;
	}
	getBundleCache() {
		return this.Qo;
	}
	runTransaction(e, t, n) {
		__PRIVATE_logDebug("MemoryPersistence", "Starting transaction:", e);
		const r = new __PRIVATE_MemoryTransaction(this.No.next());
		return this.referenceDelegate.qo(), n(r).next(((e) => this.referenceDelegate.Ko(r).next((() => e)))).toPromise().then(((e) => (r.raiseOnCommittedEvent(), e)));
	}
	$o(e, t) {
		return PersistencePromise.or(Object.values(this.Mo).map(((n) => () => n.containsKey(e, t))));
	}
};
/**
* Memory persistence is not actually transactional, but future implementations
* may have transaction-scoped state.
*/ var __PRIVATE_MemoryTransaction = class extends PersistenceTransaction {
	constructor(e) {
		super(), this.currentSequenceNumber = e;
	}
};
var __PRIVATE_MemoryEagerDelegate = class __PRIVATE_MemoryEagerDelegate {
	constructor(e) {
		this.persistence = e, this.Wo = new __PRIVATE_ReferenceSet(), this.Go = null;
	}
	static jo(e) {
		return new __PRIVATE_MemoryEagerDelegate(e);
	}
	get zo() {
		if (this.Go) return this.Go;
		throw l(60996);
	}
	addReference(e, t, n) {
		return this.Wo.addReference(n, t), this.zo.delete(n.toString()), PersistencePromise.resolve();
	}
	removeReference(e, t, n) {
		return this.Wo.removeReference(n, t), this.zo.add(n.toString()), PersistencePromise.resolve();
	}
	markPotentiallyOrphaned(e, t) {
		return this.zo.add(t.toString()), PersistencePromise.resolve();
	}
	removeTarget(e, t) {
		this.Wo.Ao(t.targetId).forEach(((e) => this.zo.add(e.toString())));
		const n = this.persistence.getTargetCache();
		return n.getMatchingKeysForTargetId(e, t.targetId).next(((e) => {
			e.forEach(((e) => this.zo.add(e.toString())));
		})).next((() => n.removeTargetData(e, t)));
	}
	qo() {
		this.Go = /* @__PURE__ */ new Set();
	}
	Ko(e) {
		const t = this.persistence.getRemoteDocumentCache().newChangeBuffer();
		return PersistencePromise.forEach(this.zo, ((n) => {
			const r = DocumentKey.fromPath(n);
			return this.Ho(e, r).next(((e) => {
				e || t.removeEntry(r, SnapshotVersion.min());
			}));
		})).next((() => (this.Go = null, t.apply(e))));
	}
	updateLimboDocument(e, t) {
		return this.Ho(e, t).next(((e) => {
			e ? this.zo.delete(t.toString()) : this.zo.add(t.toString());
		}));
	}
	ko(e) {
		return 0;
	}
	Ho(e, t) {
		return PersistencePromise.or([
			() => PersistencePromise.resolve(this.Wo.containsKey(t)),
			() => this.persistence.getTargetCache().containsKey(e, t),
			() => this.persistence.$o(e, t)
		]);
	}
};
var __PRIVATE_MemoryLruDelegate = class __PRIVATE_MemoryLruDelegate {
	constructor(e, t) {
		this.persistence = e, this.Jo = new ObjectMap(((e) => __PRIVATE_encodeResourcePath(e.path)), ((e, t) => e.isEqual(t))), this.garbageCollector = __PRIVATE_newLruGarbageCollector(this, t);
	}
	static jo(e, t) {
		return new __PRIVATE_MemoryLruDelegate(e, t);
	}
	qo() {}
	Ko(e) {
		return PersistencePromise.resolve();
	}
	forEachTarget(e, t) {
		return this.persistence.getTargetCache().forEachTarget(e, t);
	}
	Pi(e) {
		const t = this.H_(e);
		return this.persistence.getTargetCache().getTargetCount(e).next(((e) => t.next(((t) => e + t))));
	}
	H_(e) {
		let t = 0;
		return this.Ii(e, ((e) => {
			t++;
		})).next((() => t));
	}
	Ii(e, t) {
		return PersistencePromise.forEach(this.Jo, ((n, r) => this.Y_(e, n, r).next(((e) => e ? PersistencePromise.resolve() : t(r)))));
	}
	removeTargets(e, t, n) {
		return this.persistence.getTargetCache().removeTargets(e, t, n);
	}
	removeOrphanedDocuments(e, t) {
		let n = 0;
		const r = this.persistence.getRemoteDocumentCache(), i = r.newChangeBuffer();
		return r.vo(e, ((r) => this.Y_(e, r, t).next(((e) => {
			e || (n++, i.removeEntry(r, SnapshotVersion.min()));
		})))).next((() => i.apply(e))).next((() => n));
	}
	markPotentiallyOrphaned(e, t) {
		return this.Jo.set(t, e.currentSequenceNumber), PersistencePromise.resolve();
	}
	removeTarget(e, t) {
		const n = t.withSequenceNumber(e.currentSequenceNumber);
		return this.persistence.getTargetCache().updateTargetData(e, n);
	}
	addReference(e, t, n) {
		return this.Jo.set(n, e.currentSequenceNumber), PersistencePromise.resolve();
	}
	removeReference(e, t, n) {
		return this.Jo.set(n, e.currentSequenceNumber), PersistencePromise.resolve();
	}
	updateLimboDocument(e, t) {
		return this.Jo.set(t, e.currentSequenceNumber), PersistencePromise.resolve();
	}
	ko(e) {
		let t = e.key.toString().length;
		return e.isFoundDocument() && (t += __PRIVATE_estimateByteSize(e.data.value)), t;
	}
	Y_(e, t, n) {
		return PersistencePromise.or([
			() => this.persistence.$o(e, t),
			() => this.persistence.getTargetCache().containsKey(e, t),
			() => {
				const e = this.Jo.get(t);
				return PersistencePromise.resolve(void 0 !== e && e > n);
			}
		]);
	}
	getCacheSize(e) {
		return this.persistence.getRemoteDocumentCache().getSize(e);
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* A set of changes to what documents are currently in view and out of view for
* a given query. These changes are sent to the LocalStore by the View (via
* the SyncEngine) and are used to pin / unpin documents as appropriate.
*/
var __PRIVATE_LocalViewChanges = class __PRIVATE_LocalViewChanges {
	constructor(e, t, n, r) {
		this.targetId = e, this.fromCache = t, this.Ba = n, this.La = r;
	}
	static Ua(e, t) {
		let n = __PRIVATE_documentKeySet(), r = __PRIVATE_documentKeySet();
		for (const e of t.docChanges) switch (e.type) {
			case 0:
				n = n.add(e.doc.key);
				break;
			case 1: r = r.add(e.doc.key);
		}
		return new __PRIVATE_LocalViewChanges(e, t.fromCache, n, r);
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ function __PRIVATE_compareByKey(e, t) {
	return DocumentKey.comparator(e.key, t.key);
}
/**
* @license
* Copyright 2023 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* A tracker to keep a record of important details during database local query
* execution.
*/ var QueryContext = class {
	constructor() {
		/**
		* Counts the number of documents passed through during local query execution.
		*/
		this._documentReadCount = 0;
	}
	get documentReadCount() {
		return this._documentReadCount;
	}
	incrementDocumentReadCount(e) {
		this._documentReadCount += e;
	}
};
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* The Firestore query engine.
*
* Firestore queries can be executed in three modes. The Query Engine determines
* what mode to use based on what data is persisted. The mode only determines
* the runtime complexity of the query - the result set is equivalent across all
* implementations.
*
* The Query engine will use indexed-based execution if a user has configured
* any index that can be used to execute query (via `setIndexConfiguration()`).
* Otherwise, the engine will try to optimize the query by re-using a previously
* persisted query result. If that is not possible, the query will be executed
* via a full collection scan.
*
* Index-based execution is the default when available. The query engine
* supports partial indexed execution and merges the result from the index
* lookup with documents that have not yet been indexed. The index evaluation
* matches the backend's format and as such, the SDK can use indexing for all
* queries that the backend supports.
*
* If no index exists, the query engine tries to take advantage of the target
* document mapping in the TargetCache. These mappings exists for all queries
* that have been synced with the backend at least once and allow the query
* engine to only read documents that previously matched a query plus any
* documents that were edited after the query was last listened to.
*
* There are some cases when this optimization is not guaranteed to produce
* the same results as full collection scans. In these cases, query
* processing falls back to full scans. These cases are:
*
* - Limit queries where a document that matched the query previously no longer
*   matches the query.
*
* - Limit queries where a document edit may cause the document to sort below
*   another document that is in the local cache.
*
* - Queries that have never been CURRENT or free of limbo documents.
*/
var __PRIVATE_QueryEngine = class {
	constructor() {
		this.ka = false, this.Qa = false, this.qa = 100, this.Ka = function __PRIVATE_getDefaultRelativeIndexReadCostPerDocument() {
			return isSafari() ? 8 : __PRIVATE_getAndroidVersion(getUA()) > 0 ? 6 : 4;
		}();
	}
	/** Sets the document view to query against. */ initialize(e, t) {
		this.$a = e, this.indexManager = t, this.ka = true;
	}
	/** Returns all local documents matching the specified query. */ getDocumentsMatchingQuery(e, t, n, r) {
		const i = { result: null };
		return this.Wa(e, t).next(((e) => {
			i.result = e;
		})).next((() => {
			if (!i.result) return this.Ga(e, t, r, n).next(((e) => {
				i.result = e;
			}));
		})).next((() => {
			if (i.result) return;
			const n = new QueryContext();
			return this.ja(e, t, n).next(((r) => {
				if (i.result = r, this.Qa) return this.za(e, t, n, r.size);
			}));
		})).next((() => i.result));
	}
	za(e, t, n, r) {
		return __PRIVATE_isPipeline(t) ? PersistencePromise.resolve() : n.documentReadCount < this.qa ? (__PRIVATE_getLogLevel() <= LogLevel.DEBUG && __PRIVATE_logDebug("QueryEngine", "SDK will not create cache indexes for query:", __PRIVATE_stringifyQuery(t), "since it only creates cache indexes for collection contains", "more than or equal to", this.qa, "documents"), PersistencePromise.resolve()) : (__PRIVATE_getLogLevel() <= LogLevel.DEBUG && __PRIVATE_logDebug("QueryEngine", "Query:", __PRIVATE_stringifyQuery(t), "scans", n.documentReadCount, "local documents and returns", r, "documents as results."), n.documentReadCount > this.Ka * r ? (__PRIVATE_getLogLevel() <= LogLevel.DEBUG && __PRIVATE_logDebug("QueryEngine", "The SDK decides to create cache indexes for query:", __PRIVATE_stringifyQuery(t), "as using cache indexes may help improve performance."), this.indexManager.createTargetIndexes(e, __PRIVATE_queryToTarget(t))) : PersistencePromise.resolve());
	}
	/**
	* Performs an indexed query that evaluates the query based on a collection's
	* persisted index values. Returns `null` if an index is not available.
	*/ Wa(e, t) {
		if (__PRIVATE_isPipeline(t)) return PersistencePromise.resolve(null);
		let n = t;
		if (__PRIVATE_queryMatchesAllDocuments(n)) return PersistencePromise.resolve(null);
		let r = __PRIVATE_queryToTarget(n);
		return this.indexManager.getIndexType(e, r).next(((t) => 0 === t ? null : (null !== n.limit && 1 === t && (n = __PRIVATE_queryWithLimit(n, null, "F"), r = __PRIVATE_queryToTarget(n)), this.indexManager.getDocumentsMatchingTarget(e, r).next(((t) => {
			const i = __PRIVATE_documentKeySet(...t);
			return this.$a.getDocuments(e, i).next(((t) => this.indexManager.getMinOffset(e, r).next(((r) => {
				const s = this.Ha(n, t);
				return this.Ja(n, s, i, r.readTime) ? this.Wa(e, __PRIVATE_queryWithLimit(n, null, "F")) : this.Ya(e, s, n, r);
			}))));
		})))));
	}
	/**
	* Performs a query based on the target's persisted query mapping. Returns
	* `null` if the mapping is not available or cannot be used.
	*/ Ga(e, t, n, r) {
		return (__PRIVATE_isPipeline(t) ? function __PRIVATE_pipelineMatchesAllDocuments(e) {
			for (const t of e.stages) {
				if (t instanceof v || t instanceof I) return false;
				if (t instanceof A) {
					if (t.condition instanceof __PRIVATE_BooleanFunctionExpression && "exists" === t.condition._expr.name && t.condition._expr.params[0] instanceof o && t.condition._expr.params[0].fieldName === Fe) continue;
					return false;
				}
			}
			return true;
		}(t) : __PRIVATE_queryMatchesAllDocuments(t)) || r.isEqual(SnapshotVersion.min()) ? PersistencePromise.resolve(null) : this.$a.getDocuments(e, n).next(((i) => {
			const s = this.Ha(t, i);
			return this.Ja(t, s, n, r) ? PersistencePromise.resolve(null) : (__PRIVATE_getLogLevel() <= LogLevel.DEBUG && __PRIVATE_logDebug("QueryEngine", "Re-using previous result from %s to execute query: %s", r.toString(), __PRIVATE_stringifyQueryOrPipeline(t)), this.Ya(e, s, t, __PRIVATE_newIndexOffsetSuccessorFromReadTime(r, St)).next(((e) => e)));
		}));
	}
	/** Applies the query filter and sorting to the provided documents.  */ Ha(e, t) {
		let n, r;
		return __PRIVATE_isPipeline(e) ? (n = new SortedSet(__PRIVATE_compareByKey), r = (t) => __PRIVATE_pipelineMatches(e, t)) : (n = new SortedSet(__PRIVATE_newQueryComparator(e)), r = (t) => __PRIVATE_queryMatches(e, t)), t.forEach(((e, t) => {
			r(t) && (n = n.add(t));
		})), n;
	}
	/**
	* Determines if a limit query needs to be refilled from cache, making it
	* ineligible for index-free execution.
	*
	* @param query - The query.
	* @param sortedPreviousResults - The documents that matched the query when it
	* was last synchronized, sorted by the query's comparator.
	* @param remoteKeys - The document keys that matched the query at the last
	* snapshot.
	* @param limboFreeSnapshotVersion - The version of the snapshot when the
	* query was last synchronized.
	*/ Ja(e, t, n, r) {
		if (__PRIVATE_isPipeline(e)) return function __PRIVATE_pipelineHasRanges(e) {
			return e.stages.some(((e) => e instanceof v || e instanceof I));
		}(e);
		if (null === e.limit) return false;
		if (n.size !== t.size) return true;
		const i = "F" === e.limitType ? t.last() : t.first();
		return !!i && (i.hasPendingWrites || i.version.compareTo(r) > 0);
	}
	ja(e, t, n) {
		return __PRIVATE_getLogLevel() <= LogLevel.DEBUG && __PRIVATE_logDebug("QueryEngine", "Using full collection scan to execute query:", __PRIVATE_stringifyQueryOrPipeline(t)), this.$a.getDocumentsMatchingQuery(e, t, IndexOffset.min(), n);
	}
	/**
	* Combines the results from an indexed execution with the remaining documents
	* that have not yet been indexed.
	*/ Ya(e, t, n, r) {
		return this.$a.getDocumentsMatchingQuery(e, n, r).next(((e) => (t.forEach(((t) => {
			e = e.insert(t.key, t);
		})), e)));
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var kr = "LocalStore";
var Qr = 3e8;
/**
* The maximum time to leave a resume token buffered without writing it out.
* This value is arbitrary: it's long enough to avoid several writes
* (possibly indefinitely if updates come more frequently than this) but
* short enough that restarting after crashing will still have a pretty
* recent resume token.
*/
/**
* Implements `LocalStore` interface.
*
* Note: some field defined in this class might have public access level, but
* the class is not exported so they are only accessible from this module.
* This is useful to implement optional features (like bundles) in free
* functions, such that they are tree-shakeable.
*/
var __PRIVATE_LocalStoreImpl = class {
	constructor(e, t, n, r) {
		this.persistence = e, this.Za = t, this.serializer = r, this.Xa = new SortedMap(__PRIVATE_primitiveComparator), this.eu = new ObjectMap(((e) => __PRIVATE_canonifyTargetOrPipeline(e)), __PRIVATE_targetOrPipelineEqual), this.tu = /* @__PURE__ */ new Map(), this.nu = e.getRemoteDocumentCache(), this.Uo = e.getTargetCache(), this.Qo = e.getBundleCache(), this.ru(n);
	}
	ru(e) {
		this.documentOverlayCache = this.persistence.getDocumentOverlayCache(e), this.indexManager = this.persistence.getIndexManager(e), this.mutationQueue = this.persistence.getMutationQueue(e, this.indexManager), this.localDocuments = new LocalDocumentsView(this.nu, this.mutationQueue, this.documentOverlayCache, this.indexManager), this.nu.setIndexManager(this.indexManager), this.Za.initialize(this.localDocuments, this.indexManager);
	}
	collectGarbage(e) {
		return this.persistence.runTransaction("Collect garbage", "readwrite-primary", ((t) => e.collect(t, this.Xa)));
	}
};
function __PRIVATE_newLocalStore(e, t, n, r) {
	return new __PRIVATE_LocalStoreImpl(e, t, n, r);
}
/**
* Tells the LocalStore that the currently authenticated user has changed.
*
* In response the local store switches the mutation queue to the new user and
* returns any resulting document changes.
*/
async function __PRIVATE_localStoreHandleUserChange(e, t) {
	const n = __PRIVATE_debugCast(e);
	return await n.persistence.runTransaction("Handle user change", "readonly", ((e) => {
		let r;
		return n.mutationQueue.getAllMutationBatches(e).next(((i) => (r = i, n.ru(t), n.mutationQueue.getAllMutationBatches(e)))).next(((t) => {
			const i = [], s = [];
			let _ = __PRIVATE_documentKeySet();
			for (const e of r) {
				i.push(e.batchId);
				for (const t of e.mutations) _ = _.add(t.key);
			}
			for (const e of t) {
				s.push(e.batchId);
				for (const t of e.mutations) _ = _.add(t.key);
			}
			return n.localDocuments.getDocuments(e, _).next(((e) => ({
				iu: e,
				removedBatchIds: i,
				addedBatchIds: s
			})));
		}));
	}));
}
/**
* Acknowledges the given batch.
*
* On the happy path when a batch is acknowledged, the local store will
*
*  + remove the batch from the mutation queue;
*  + apply the changes to the remote document cache;
*  + recalculate the latency compensated view implied by those changes (there
*    may be mutations in the queue that affect the documents but haven't been
*    acknowledged yet); and
*  + give the changed documents back the sync engine
*
* @returns The resulting (modified) documents.
*/
function __PRIVATE_localStoreAcknowledgeBatch(e, t) {
	const n = __PRIVATE_debugCast(e);
	return n.persistence.runTransaction("Acknowledge batch", "readwrite-primary", ((e) => {
		const r = t.batch.keys(), i = n.nu.newChangeBuffer({ trackRemovals: true });
		return function __PRIVATE_applyWriteToRemoteDocuments(e, t, n, r) {
			const i = n.batch, s = i.keys();
			let _ = PersistencePromise.resolve();
			return s.forEach(((e) => {
				_ = _.next((() => r.getEntry(t, e))).next(((t) => {
					const s = n.docVersions.get(e);
					__PRIVATE_hardAssert(null !== s, 48541), t.version.compareTo(s) < 0 && (i.applyToRemoteDocument(t, n), t.isValidDocument() && (t.setReadTime(n.commitVersion), r.addEntry(t)));
				}));
			})), _.next((() => e.mutationQueue.removeMutationBatch(t, i)));
		}(n, e, t, i).next((() => i.apply(e))).next((() => n.mutationQueue.performConsistencyCheck(e))).next((() => n.documentOverlayCache.removeOverlaysForBatchId(e, r, t.batch.batchId))).next((() => n.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(e, function __PRIVATE_getKeysWithTransformResults(e) {
			let t = __PRIVATE_documentKeySet();
			for (let n = 0; n < e.mutationResults.length; ++n) e.mutationResults[n].transformResults.length > 0 && (t = t.add(e.batch.mutations[n].key));
			return t;
		}(t)))).next((() => n.localDocuments.getDocuments(e, r)));
	}));
}
/**
* Returns the last consistent snapshot processed (used by the RemoteStore to
* determine whether to buffer incoming snapshots from the backend).
*/
function __PRIVATE_localStoreGetLastRemoteSnapshotVersion(e) {
	const t = __PRIVATE_debugCast(e);
	return t.persistence.runTransaction("Get last remote snapshot version", "readonly", ((e) => t.Uo.getLastRemoteSnapshotVersion(e)));
}
/**
* Updates the "ground-state" (remote) documents. We assume that the remote
* event reflects any write batches that have been acknowledged or rejected
* (i.e. we do not re-apply local mutations to updates from this event).
*
* LocalDocuments are re-calculated if there are remaining mutations in the
* queue.
*/ function __PRIVATE_localStoreApplyRemoteEventToLocalCache(e, t) {
	const n = __PRIVATE_debugCast(e), r = t.snapshotVersion;
	let i = n.Xa;
	return n.persistence.runTransaction("Apply remote event", "readwrite-primary", ((e) => {
		const s = n.nu.newChangeBuffer({ trackRemovals: true });
		i = n.Xa;
		const _ = [];
		t.targetChanges.forEach(((s, o) => {
			const a = i.get(o);
			if (!a) return;
			_.push(n.Uo.removeMatchingKeys(e, s.removedDocuments, o).next((() => n.Uo.addMatchingKeys(e, s.addedDocuments, o))));
			let u = a.withSequenceNumber(e.currentSequenceNumber);
			null !== t.targetMismatches.get(o) ? u = u.withResumeToken(ByteString.EMPTY_BYTE_STRING, SnapshotVersion.min()).withLastLimboFreeSnapshotVersion(SnapshotVersion.min()) : s.resumeToken.approximateByteSize() > 0 && (u = u.withResumeToken(s.resumeToken, r)), i = i.insert(o, u), function __PRIVATE_shouldPersistTargetData(e, t, n) {
				if (0 === e.resumeToken.approximateByteSize()) return true;
				if (t.snapshotVersion.toMicroseconds() - e.snapshotVersion.toMicroseconds() >= Qr) return true;
				return n.addedDocuments.size + n.modifiedDocuments.size + n.removedDocuments.size > 0;
			}(a, u, s) && _.push(n.Uo.updateTargetData(e, u));
		}));
		let o = __PRIVATE_mutableDocumentMap(), a = __PRIVATE_documentKeySet();
		if (t.documentUpdates.forEach(((r) => {
			t.resolvedLimboDocuments.has(r) && _.push(n.persistence.referenceDelegate.updateLimboDocument(e, r));
		})), _.push(__PRIVATE_populateDocumentChangeBuffer(e, s, t.documentUpdates).next(((e) => {
			o = e.su, a = e._u;
		}))), !r.isEqual(SnapshotVersion.min())) {
			const t = n.Uo.getLastRemoteSnapshotVersion(e).next(((t) => n.Uo.setTargetsMetadata(e, e.currentSequenceNumber, r)));
			_.push(t);
		}
		return PersistencePromise.waitFor(_).next((() => s.apply(e))).next((() => n.localDocuments.getLocalViewOfDocuments(e, o, a))).next((() => o));
	})).then(((e) => (n.Xa = i, e)));
}
/**
* Populates document change buffer with documents from backend or a bundle.
* Returns the document changes resulting from applying those documents, and
* also a set of documents whose existence state are changed as a result.
*
* @param txn - Transaction to use to read existing documents from storage.
* @param documentBuffer - Document buffer to collect the resulted changes to be
*        applied to storage.
* @param documents - Documents to be applied.
*/ function __PRIVATE_populateDocumentChangeBuffer(e, t, n) {
	let r = __PRIVATE_documentKeySet(), i = __PRIVATE_documentKeySet();
	return n.forEach(((e) => r = r.add(e))), t.getEntries(e, r).next(((e) => {
		let r = __PRIVATE_mutableDocumentMap();
		return n.forEach(((n, s) => {
			const _ = e.get(n);
			s.isFoundDocument() !== _.isFoundDocument() && (i = i.add(n)), s.isNoDocument() && s.version.isEqual(SnapshotVersion.min()) ? (t.removeEntry(n, s.readTime), r = r.insert(n, s)) : !_.isValidDocument() || s.version.compareTo(_.version) > 0 || 0 === s.version.compareTo(_.version) && _.hasPendingWrites ? (t.addEntry(s), r = r.insert(n, s)) : __PRIVATE_logDebug(kr, "Ignoring outdated watch update for ", n, ". Current version:", _.version, " Watch version:", s.version);
		})), {
			su: r,
			_u: i
		};
	}));
}
/**
* Gets the mutation batch after the passed in batchId in the mutation queue
* or null if empty.
* @param afterBatchId - If provided, the batch to search after.
* @returns The next mutation or null if there wasn't one.
*/
function __PRIVATE_localStoreGetNextMutationBatch(e, t) {
	const n = __PRIVATE_debugCast(e);
	return n.persistence.runTransaction("Get next mutation batch", "readonly", ((e) => (void 0 === t && (t = Je), n.mutationQueue.getNextMutationBatchAfterBatchId(e, t))));
}
/**
* Reads the current value of a Document with a given key or null if not
* found - used for testing.
*/
/**
* Assigns the given target an internal ID so that its results can be pinned so
* they don't get GC'd. A target must be allocated in the local store before
* the store can be used to manage its view.
*
* Allocating an already allocated `Target` will return the existing `TargetData`
* for that `Target`.
*/
function __PRIVATE_localStoreAllocateTarget(e, t) {
	const n = __PRIVATE_debugCast(e);
	return n.persistence.runTransaction("Allocate target", "readwrite", ((e) => {
		let r;
		return n.Uo.getTargetData(e, t).next(((i) => i ? (r = i, PersistencePromise.resolve(r)) : n.Uo.allocateTargetId(e).next(((i) => (r = new TargetData(t, i, "TargetPurposeListen", e.currentSequenceNumber), n.Uo.addTargetData(e, r).next((() => r)))))));
	})).then(((e) => {
		const r = n.Xa.get(e.targetId);
		return (null === r || e.snapshotVersion.compareTo(r.snapshotVersion) > 0) && (n.Xa = n.Xa.insert(e.targetId, e), n.eu.set(t, e.targetId)), e;
	}));
}
/**
* Returns the TargetData as seen by the LocalStore, including updates that may
* have not yet been persisted to the TargetCache.
*/
/**
* Unpins all the documents associated with the given target. If
* `keepPersistedTargetData` is set to false and Eager GC enabled, the method
* directly removes the associated target data from the target cache.
*
* Releasing a non-existing `Target` is a no-op.
*/
async function __PRIVATE_localStoreReleaseTarget(e, t, n) {
	const r = __PRIVATE_debugCast(e), i = r.Xa.get(t), s = n ? "readwrite" : "readwrite-primary";
	try {
		n || await r.persistence.runTransaction("Release target", s, ((e) => r.persistence.referenceDelegate.removeTarget(e, i)));
	} catch (e) {
		if (!__PRIVATE_isIndexedDbTransactionError(e)) throw e;
		__PRIVATE_logDebug(kr, `Failed to update sequence numbers for target ${t}: ${e}`);
	}
	r.Xa = r.Xa.remove(t), r.eu.delete(i.target);
}
/**
* Runs the specified query against the local store and returns the results,
* potentially taking advantage of query data from previous executions (such
* as the set of remote keys).
*
* @param usePreviousResults - Whether results from previous executions can
* be used to optimize this query execution.
*/ function __PRIVATE_localStoreExecuteQuery(e, t, n) {
	const r = __PRIVATE_debugCast(e);
	let i = SnapshotVersion.min(), s = __PRIVATE_documentKeySet();
	return r.persistence.runTransaction("Execute query", "readwrite", ((e) => function __PRIVATE_localStoreGetTargetData(e, t, n) {
		const r = __PRIVATE_debugCast(e), i = r.eu.get(n);
		return void 0 !== i ? PersistencePromise.resolve(r.Xa.get(i)) : r.Uo.getTargetData(t, n);
	}(r, e, __PRIVATE_isPipeline(t) ? t : __PRIVATE_queryToTarget(t)).next(((t) => {
		if (t) return i = t.lastLimboFreeSnapshotVersion, r.Uo.getMatchingKeysForTargetId(e, t.targetId).next(((e) => {
			s = e;
		}));
	})).next((() => r.Za.getDocumentsMatchingQuery(e, t, n ? i : SnapshotVersion.min(), n ? s : __PRIVATE_documentKeySet()))).next(((e) => (__PRIVATE_setMaxReadTime(r, e), {
		documents: e,
		ou: s
	})))));
}
/** Sets the collection group's maximum read time from the given documents. */
function __PRIVATE_setMaxReadTime(e, t) {
	t.forEach(((t, n) => {
		const r = n.key.getCollectionGroup(), i = e.tu.get(r) || SnapshotVersion.min();
		n.readTime.compareTo(i) > 0 && e.tu.set(r, n.readTime);
	}));
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* On web, a `ReadableStream` is wrapped around by a `ByteStreamReader`.
*/
/**
* A component used by the RemoteStore to track the OnlineState (that is,
* whether or not the client as a whole should be considered to be online or
* offline), implementing the appropriate heuristics.
*
* In particular, when the client is trying to connect to the backend, we
* allow up to MAX_WATCH_STREAM_FAILURES within ONLINE_STATE_TIMEOUT_MS for
* a connection to succeed. If we have too many failures or the timeout elapses,
* then we set the OnlineState to Offline, and the client will behave as if
* it is offline (get()s will return cached data, etc.).
*/
var __PRIVATE_OnlineStateTracker = class {
	constructor(e, t) {
		this.asyncQueue = e, this.onlineStateHandler = t, this.state = "Unknown", this.hu = 0, this.Tu = null, this.Pu = true;
	}
	/**
	* Called by RemoteStore when a watch stream is started (including on each
	* backoff attempt).
	*
	* If this is the first attempt, it sets the OnlineState to Unknown and starts
	* the onlineStateTimer.
	*/ Iu() {
		0 === this.hu && (this.Ru("Unknown"), this.Tu = this.asyncQueue.enqueueAfterDelay("online_state_timeout", 1e4, (() => (this.Tu = null, this.Au("Backend didn't respond within 10 seconds."), this.Ru("Offline"), Promise.resolve()))));
	}
	/**
	* Updates our OnlineState as appropriate after the watch stream reports a
	* failure. The first failure moves us to the 'Unknown' state. We then may
	* allow multiple failures (based on MAX_WATCH_STREAM_FAILURES) before we
	* actually transition to the 'Offline' state.
	*/ Vu(e) {
		"Online" === this.state ? this.Ru("Unknown") : (this.hu++, this.hu >= 1 && (this.fu(), this.Au(`Connection failed 1 times. Most recent error: ${e.toString()}`), this.Ru("Offline")));
	}
	/**
	* Explicitly sets the OnlineState to the specified state.
	*
	* Note that this resets our timers / failure counters, etc. used by our
	* Offline heuristics, so must not be used in place of
	* handleWatchStreamStart() and handleWatchStreamFailure().
	*/ set(e) {
		this.fu(), this.hu = 0, "Online" === e && (this.Pu = false), this.Ru(e);
	}
	Ru(e) {
		e !== this.state && (this.state = e, this.onlineStateHandler(e));
	}
	Au(e) {
		const t = `Could not reach Cloud Firestore backend. ${e}\nThis typically indicates that your device does not have a healthy Internet connection at the moment. The client will operate in offline mode until it is able to successfully connect to the backend.`;
		this.Pu ? (__PRIVATE_logError(t), this.Pu = false) : __PRIVATE_logDebug("OnlineStateTracker", t);
	}
	fu() {
		null !== this.Tu && (this.Tu.cancel(), this.Tu = null);
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var qr = "RemoteStore";
var __PRIVATE_RemoteStoreImpl = class {
	constructor(e, t, n, r, i) {
		this.localStore = e, this.datastore = t, this.asyncQueue = n, this.remoteSyncer = {}, this.du = [], this.mu = /* @__PURE__ */ new Map(), this.pu = /* @__PURE__ */ new Map(), this.gu = /* @__PURE__ */ new Map(), this.yu = new __PRIVATE_TargetIdGenerator(1e3), this.wu = new __PRIVATE_TargetIdGenerator(1001), this.bu = /* @__PURE__ */ new Set(), this.Su = [], this.xu = i, this.xu.tn(((e) => {
			n.enqueueAndForget((async () => {
				__PRIVATE_canUseNetwork(this) && (__PRIVATE_logDebug(qr, "Restarting streams for network reachability change."), await async function __PRIVATE_restartNetwork(e) {
					const t = __PRIVATE_debugCast(e);
					t.bu.add(4), await __PRIVATE_disableNetworkInternal(t), t.vu.set("Unknown"), t.bu.delete(4), await __PRIVATE_enableNetworkInternal(t);
				}(this));
			}));
		})), this.vu = new __PRIVATE_OnlineStateTracker(n, r);
	}
};
async function __PRIVATE_enableNetworkInternal(e) {
	if (__PRIVATE_canUseNetwork(e)) for (const t of e.Su) await t(true);
}
/**
* Temporarily disables the network. The network can be re-enabled using
* enableNetwork().
*/ async function __PRIVATE_disableNetworkInternal(e) {
	for (const t of e.Su) await t(false);
}
/**
* Returns the remote target ID currently mapped to this
* sdkTargetId. Or returns `0` if the SDK target ID
* is not currently mapped.
* @param remoteStoreImpl
* @param sdkTargetId
*/
function __PRIVATE_getRemoteTargetId(e, t) {
	return e.pu.get(t) || void 0;
}
/**
* Generates a new remote target ID that is acceptable
* to map to the given SDK target ID.
* @param remoteStoreImpl
* @param sdkTargetId
*/
/**
* Starts new listen for the given target. Uses resume token if provided. It
* is a no-op if the target of given `TargetData` is already being listened to.
*/
function __PRIVATE_remoteStoreListen(e, t) {
	const n = __PRIVATE_debugCast(e), r = __PRIVATE_getRemoteTargetId(n, t.targetId);
	if (void 0 !== r && n.mu.has(r)) return;
	const i = function __PRIVATE_allocateRemoteTargetId(e, t) {
		const n = __PRIVATE_getRemoteTargetId(e, t);
		void 0 !== n && e.gu.delete(n);
		const r = function __PRIVATE_generateRemoteTargetId(e, t) {
			return t % 2 != 0 ? e.wu.next() : e.yu.next();
		}(e, t);
		return e.pu.set(t, r), e.gu.set(r, t), r;
	}(n, t.targetId);
	__PRIVATE_logDebug(qr, "remoteStoreListen mapping SDK target ID to remote", t.targetId, i);
	const s = new TargetData(t.target, i, t.purpose, t.sequenceNumber, t.snapshotVersion, t.lastLimboFreeSnapshotVersion, t.resumeToken);
	n.mu.set(i, s), __PRIVATE_shouldStartWatchStream(n) ? __PRIVATE_startWatchStream(n) : __PRIVATE_ensureWatchStream(n).ur() && __PRIVATE_sendWatchRequest(n, s);
}
/**
* Removes the listen from server. It is a no-op if the given target id is
* not being listened to.
*/ function __PRIVATE_remoteStoreUnlisten(e, t) {
	const n = __PRIVATE_debugCast(e), r = __PRIVATE_ensureWatchStream(n), i = __PRIVATE_getRemoteTargetId(n, t);
	__PRIVATE_logDebug(qr, "remoteStoreUnlisten removing mapping of SDK target ID to remote", t, i), n.mu.delete(i), n.pu.delete(t), n.gu.delete(i), r.ur() && __PRIVATE_sendUnwatchRequest(n, i), 0 === n.mu.size && (r.ur() ? r.Er() : __PRIVATE_canUseNetwork(n) && n.vu.set("Unknown"));
}
/**
* We need to increment the expected number of pending responses we're due
* from watch so we wait for the ack to process any messages from this target.
*/ function __PRIVATE_sendWatchRequest(e, t) {
	if (e.Du.rt(t.targetId), t.resumeToken.approximateByteSize() > 0 || t.snapshotVersion.compareTo(SnapshotVersion.min()) > 0) {
		const n = e.gu.get(t.targetId);
		if (void 0 === n) return void __PRIVATE_logDebug(qr, "SDK target ID not found for remote ID: " + t.targetId);
		const r = e.remoteSyncer.getRemoteKeysForTarget(n).size;
		t = t.withExpectedCount(r);
	}
	__PRIVATE_ensureWatchStream(e).yr(t);
}
/**
* We need to increment the expected number of pending responses we're due
* from watch so we wait for the removal on the server before we process any
* messages from this target.
*/ function __PRIVATE_sendUnwatchRequest(e, t) {
	e.Du.rt(t), __PRIVATE_ensureWatchStream(e).wr(t);
}
function __PRIVATE_startWatchStream(e) {
	e.Du = new __PRIVATE_WatchChangeAggregator({
		getRemoteKeysForTarget: (t) => {
			const n = e.gu.get(t);
			return void 0 !== n ? e.remoteSyncer.getRemoteKeysForTarget(n) : __PRIVATE_documentKeySet();
		},
		Mt: (t) => e.mu.get(t) || null,
		xt: () => e.datastore.serializer.databaseId
	}), __PRIVATE_ensureWatchStream(e).start(), e.vu.Iu();
}
/**
* Returns whether the watch stream should be started because it's necessary
* and has not yet been started.
*/ function __PRIVATE_shouldStartWatchStream(e) {
	return __PRIVATE_canUseNetwork(e) && !__PRIVATE_ensureWatchStream(e).ar() && e.mu.size > 0;
}
function __PRIVATE_canUseNetwork(e) {
	return 0 === __PRIVATE_debugCast(e).bu.size;
}
function __PRIVATE_cleanUpWatchStreamState(e) {
	e.Du = void 0;
}
async function __PRIVATE_onWatchStreamConnected(e) {
	e.vu.set("Online");
}
async function __PRIVATE_onWatchStreamOpen(e) {
	e.mu.forEach(((t, n) => {
		__PRIVATE_sendWatchRequest(e, t);
	}));
}
async function __PRIVATE_onWatchStreamClose(e, t) {
	__PRIVATE_cleanUpWatchStreamState(e), __PRIVATE_shouldStartWatchStream(e) ? (e.vu.Vu(t), __PRIVATE_startWatchStream(e)) : e.vu.set("Unknown");
}
async function __PRIVATE_onWatchStreamChange(e, t, n) {
	if (e.vu.set("Online"), t instanceof __PRIVATE_WatchTargetChange && 2 === t.state && t.cause) try {
		/** Handles an error on a target */
		await async function __PRIVATE_handleTargetError(e, t) {
			const n = t.cause;
			for (const r of t.targetIds) {
				if (e.mu.has(r)) {
					const t = e.gu.get(r);
					void 0 !== t && (await e.remoteSyncer.rejectListen(t, n), e.pu.delete(t), e.gu.delete(r)), e.mu.delete(r);
				}
				e.Du.removeTarget(r);
			}
		}(e, t);
	} catch (n) {
		__PRIVATE_logDebug(qr, "Failed to remove targets %s: %s ", t.targetIds.join(","), n), await __PRIVATE_disableNetworkUntilRecovery(e, n);
	}
	else if (t instanceof __PRIVATE_DocumentWatchChange ? e.Du.Tt(t) : t instanceof __PRIVATE_ExistenceFilterChange ? e.Du.dt(t) : e.Du.Rt(t), !n.isEqual(SnapshotVersion.min())) try {
		const t = await __PRIVATE_localStoreGetLastRemoteSnapshotVersion(e.localStore);
		n.compareTo(t) >= 0 && await function __PRIVATE_raiseWatchSnapshot(e, t) {
			const n = e.Du.Dt(t);
			n.targetChanges.forEach(((n, r) => {
				if (n.resumeToken.approximateByteSize() > 0) {
					const i = e.mu.get(r);
					i && e.mu.set(r, i.withResumeToken(n.resumeToken, t));
				}
			})), n.targetMismatches.forEach(((t, n) => {
				const r = e.mu.get(t);
				if (!r) return;
				e.mu.set(t, r.withResumeToken(ByteString.EMPTY_BYTE_STRING, r.snapshotVersion)), __PRIVATE_sendUnwatchRequest(e, t);
				__PRIVATE_sendWatchRequest(e, new TargetData(r.target, t, n, r.sequenceNumber));
			}));
			const r = function __PRIVATE_toSdkRemoteEvent(e, t) {
				const n = /* @__PURE__ */ new Map();
				t.targetChanges.forEach(((t, r) => {
					const i = e.gu.get(r);
					void 0 !== i && n.set(i, t);
				}));
				let r = new SortedMap(__PRIVATE_primitiveComparator);
				return t.targetMismatches.forEach(((t, n) => {
					const i = e.gu.get(t);
					void 0 !== i && (r = r.insert(i, n));
				})), new RemoteEvent(t.snapshotVersion, n, r, t.documentUpdates, t.augmentedDocumentUpdates, t.resolvedLimboDocuments);
			}(e, n);
			return e.remoteSyncer.applyRemoteEvent(r);
		}(e, n);
	} catch (t) {
		__PRIVATE_logDebug(qr, "Failed to raise snapshot:", t), await __PRIVATE_disableNetworkUntilRecovery(e, t);
	}
}
/**
* Recovery logic for IndexedDB errors that takes the network offline until
* `op` succeeds. Retries are scheduled with backoff using
* `enqueueRetryable()`. If `op()` is not provided, IndexedDB access is
* validated via a generic operation.
*
* The returned Promise is resolved once the network is disabled and before
* any retry attempt.
*/ async function __PRIVATE_disableNetworkUntilRecovery(e, t, n) {
	if (!__PRIVATE_isIndexedDbTransactionError(t)) throw t;
	e.bu.add(1), await __PRIVATE_disableNetworkInternal(e), e.vu.set("Offline"), n || (n = () => __PRIVATE_localStoreGetLastRemoteSnapshotVersion(e.localStore)), e.asyncQueue.enqueueRetryable((async () => {
		__PRIVATE_logDebug(qr, "Retrying IndexedDB access"), await n(), e.bu.delete(1), await __PRIVATE_enableNetworkInternal(e);
	}));
}
/**
* Executes `op`. If `op` fails, takes the network offline until `op`
* succeeds. Returns after the first attempt.
*/ function __PRIVATE_executeWithRecovery(e, t) {
	return t().catch(((n) => __PRIVATE_disableNetworkUntilRecovery(e, n, t)));
}
async function __PRIVATE_fillWritePipeline(e) {
	const t = __PRIVATE_debugCast(e), n = __PRIVATE_ensureWriteStream(t);
	let r = t.du.length > 0 ? t.du[t.du.length - 1].batchId : Je;
	for (; __PRIVATE_canAddToWritePipeline(t);) try {
		const e = await __PRIVATE_localStoreGetNextMutationBatch(t.localStore, r);
		if (null === e) {
			0 === t.du.length && n.Er();
			break;
		}
		r = e.batchId, __PRIVATE_addToWritePipeline(t, e);
	} catch (e) {
		await __PRIVATE_disableNetworkUntilRecovery(t, e);
	}
	__PRIVATE_shouldStartWriteStream(t) && __PRIVATE_startWriteStream(t);
}
/**
* Returns true if we can add to the write pipeline (i.e. the network is
* enabled and the write pipeline is not full).
*/ function __PRIVATE_canAddToWritePipeline(e) {
	return __PRIVATE_canUseNetwork(e) && e.du.length < 10;
}
/**
* Queues additional writes to be sent to the write stream, sending them
* immediately if the write stream is established.
*/ function __PRIVATE_addToWritePipeline(e, t) {
	e.du.push(t);
	const n = __PRIVATE_ensureWriteStream(e);
	n.ur() && n.br && n.Sr(t.mutations);
}
function __PRIVATE_shouldStartWriteStream(e) {
	return __PRIVATE_canUseNetwork(e) && !__PRIVATE_ensureWriteStream(e).ar() && e.du.length > 0;
}
function __PRIVATE_startWriteStream(e) {
	__PRIVATE_ensureWriteStream(e).start();
}
async function __PRIVATE_onWriteStreamOpen(e) {
	__PRIVATE_ensureWriteStream(e).Cr();
}
async function __PRIVATE_onWriteHandshakeComplete(e) {
	const t = __PRIVATE_ensureWriteStream(e);
	for (const n of e.du) t.Sr(n.mutations);
}
async function __PRIVATE_onMutationResult(e, t, n) {
	const r = e.du.shift(), i = MutationBatchResult.from(r, t, n);
	await __PRIVATE_executeWithRecovery(e, (() => e.remoteSyncer.applySuccessfulWrite(i))), await __PRIVATE_fillWritePipeline(e);
}
async function __PRIVATE_onWriteStreamClose(e, t) {
	t && __PRIVATE_ensureWriteStream(e).br && await async function __PRIVATE_handleWriteError(e, t) {
		if (function __PRIVATE_isPermanentWriteError(e) {
			return __PRIVATE_isPermanentError(e) && e !== ta.ABORTED;
		}(t.code)) {
			const n = e.du.shift();
			__PRIVATE_ensureWriteStream(e).lr(), await __PRIVATE_executeWithRecovery(e, (() => e.remoteSyncer.rejectFailedWrite(n.batchId, t))), await __PRIVATE_fillWritePipeline(e);
		}
	}(e, t), __PRIVATE_shouldStartWriteStream(e) && __PRIVATE_startWriteStream(e);
}
async function __PRIVATE_remoteStoreHandleCredentialChange(e, t) {
	const n = __PRIVATE_debugCast(e);
	n.asyncQueue.verifyOperationInProgress(), __PRIVATE_logDebug(qr, "RemoteStore received new credentials");
	const r = __PRIVATE_canUseNetwork(n);
	n.bu.add(3), await __PRIVATE_disableNetworkInternal(n), r && n.vu.set("Unknown"), await n.remoteSyncer.handleCredentialChange(t), n.bu.delete(3), await __PRIVATE_enableNetworkInternal(n);
}
/**
* Toggles the network state when the client gains or loses its primary lease.
*/ async function __PRIVATE_remoteStoreApplyPrimaryState(e, t) {
	const n = __PRIVATE_debugCast(e);
	t ? (n.bu.delete(2), await __PRIVATE_enableNetworkInternal(n)) : t || (n.bu.add(2), await __PRIVATE_disableNetworkInternal(n), n.vu.set("Unknown"));
}
/**
* If not yet initialized, registers the WatchStream and its network state
* callback with `remoteStoreImpl`. Returns the existing stream if one is
* already available.
*
* PORTING NOTE: On iOS and Android, the WatchStream gets registered on startup.
* This is not done on Web to allow it to be tree-shaken.
*/ function __PRIVATE_ensureWatchStream(e) {
	return e.Cu || (e.Cu = function __PRIVATE_newPersistentWatchStream(e, t, n) {
		const r = __PRIVATE_debugCast(e);
		return r.Or(), new __PRIVATE_PersistentListenStream(t, r.connection, r.authCredentials, r.appCheckCredentials, r.serializer, n);
	}(e.datastore, e.asyncQueue, {
		pn: __PRIVATE_onWatchStreamConnected.bind(null, e),
		yn: __PRIVATE_onWatchStreamOpen.bind(null, e),
		bn: __PRIVATE_onWatchStreamClose.bind(null, e),
		gr: __PRIVATE_onWatchStreamChange.bind(null, e)
	}), e.Su.push((async (t) => {
		t ? (e.Cu.lr(), __PRIVATE_shouldStartWatchStream(e) ? __PRIVATE_startWatchStream(e) : e.vu.set("Unknown")) : (await e.Cu.stop(), __PRIVATE_cleanUpWatchStreamState(e));
	}))), e.Cu;
}
/**
* If not yet initialized, registers the WriteStream and its network state
* callback with `remoteStoreImpl`. Returns the existing stream if one is
* already available.
*
* PORTING NOTE: On iOS and Android, the WriteStream gets registered on startup.
* This is not done on Web to allow it to be tree-shaken.
*/ function __PRIVATE_ensureWriteStream(e) {
	return e.Fu || (e.Fu = function __PRIVATE_newPersistentWriteStream(e, t, n) {
		const r = __PRIVATE_debugCast(e);
		return r.Or(), new __PRIVATE_PersistentWriteStream(t, r.connection, r.authCredentials, r.appCheckCredentials, r.serializer, n);
	}(e.datastore, e.asyncQueue, {
		pn: () => Promise.resolve(),
		yn: __PRIVATE_onWriteStreamOpen.bind(null, e),
		bn: __PRIVATE_onWriteStreamClose.bind(null, e),
		vr: __PRIVATE_onWriteHandshakeComplete.bind(null, e),
		Dr: __PRIVATE_onMutationResult.bind(null, e)
	}), e.Su.push((async (t) => {
		t ? (e.Fu.lr(), await __PRIVATE_fillWritePipeline(e)) : (await e.Fu.stop(), e.du.length > 0 && (__PRIVATE_logDebug(qr, `Stopping write stream with ${e.du.length} pending writes`), e.du = []));
	}))), e.Fu;
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var __PRIVATE_AsyncObserver = class {
	constructor(e) {
		this.observer = e, this.muted = false;
	}
	next(e) {
		this.muted || this.observer.next && this.Ou(this.observer.next, e);
	}
	error(e) {
		this.muted || (this.observer.error ? this.Ou(this.observer.error, e) : __PRIVATE_logError("Uncaught Error in snapshot listener:", e.toString()));
	}
	Mu() {
		this.muted = true;
	}
	Ou(e, t) {
		setTimeout((() => {
			this.muted || e(t);
		}), 0);
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Represents an operation scheduled to be run in the future on an AsyncQueue.
*
* It is created via DelayedOperation.createAndSchedule().
*
* Supports cancellation (via cancel()) and early execution (via skipDelay()).
*
* Note: We implement `PromiseLike` instead of `Promise`, as the `Promise` type
* in newer versions of TypeScript defines `finally`, which is not available in
* IE.
*/
var DelayedOperation = class DelayedOperation {
	constructor(e, t, n, r, i) {
		this.asyncQueue = e, this.timerId = t, this.targetTimeMs = n, this.op = r, this.removalCallback = i, this.deferred = new __PRIVATE_Deferred(), this.then = this.deferred.promise.then.bind(this.deferred.promise), this.deferred.promise.catch(((e) => {}));
	}
	get promise() {
		return this.deferred.promise;
	}
	/**
	* Creates and returns a DelayedOperation that has been scheduled to be
	* executed on the provided asyncQueue after the provided delayMs.
	*
	* @param asyncQueue - The queue to schedule the operation on.
	* @param id - A Timer ID identifying the type of operation this is.
	* @param delayMs - The delay (ms) before the operation should be scheduled.
	* @param op - The operation to run.
	* @param removalCallback - A callback to be called synchronously once the
	*   operation is executed or canceled, notifying the AsyncQueue to remove it
	*   from its delayedOperations list.
	*   PORTING NOTE: This exists to prevent making removeDelayedOperation() and
	*   the DelayedOperation class public.
	*/ static createAndSchedule(e, t, n, r, i) {
		const s = Date.now() + n, _ = new DelayedOperation(e, t, s, r, i);
		return _.start(n), _;
	}
	/**
	* Starts the timer. This is called immediately after construction by
	* createAndSchedule().
	*/ start(e) {
		this.timerHandle = setTimeout((() => this.handleDelayElapsed()), e);
	}
	/**
	* Queues the operation to run immediately (if it hasn't already been run or
	* canceled).
	*/ skipDelay() {
		return this.handleDelayElapsed();
	}
	/**
	* Cancels the operation if it hasn't already been executed or canceled. The
	* promise will be rejected.
	*
	* As long as the operation has not yet been run, calling cancel() provides a
	* guarantee that the operation will not be run.
	*/ cancel(t) {
		null !== this.timerHandle && (this.clearTimeout(), this.deferred.reject(new e(ta.CANCELLED, "Operation cancelled" + (t ? ": " + t : ""))));
	}
	handleDelayElapsed() {
		this.asyncQueue.enqueueAndForget((() => null !== this.timerHandle ? (this.clearTimeout(), this.op().then(((e) => this.deferred.resolve(e)))) : Promise.resolve()));
	}
	clearTimeout() {
		null !== this.timerHandle && (this.removalCallback(this), clearTimeout(this.timerHandle), this.timerHandle = null);
	}
};
/**
* Returns a FirestoreError that can be surfaced to the user if the provided
* error is an IndexedDbTransactionError. Re-throws the error otherwise.
*/ function __PRIVATE_wrapInUserErrorIfRecoverable(t, n) {
	if (__PRIVATE_logError("AsyncQueue", `${n}: ${t}`), __PRIVATE_isIndexedDbTransactionError(t)) return new e(ta.UNAVAILABLE, `${n}: ${t}`);
	throw t;
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2025 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2018 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Metadata state of the local client. Unlike `RemoteClientState`, this class is
* mutable and keeps track of all pending mutations, which allows us to
* update the range of pending mutation batch IDs as new mutations are added or
* removed.
*
* The data in `LocalClientState` is not read from WebStorage and instead
* updated via its instance methods. The updated state can be serialized via
* `toWebStorageJSON()`.
*/
var __PRIVATE_LocalClientState = class {
	constructor() {
		this.activeTargetIds = __PRIVATE_targetIdSet();
	}
	ec(e) {
		this.activeTargetIds = this.activeTargetIds.add(e);
	}
	tc(e) {
		this.activeTargetIds = this.activeTargetIds.delete(e);
	}
	/**
	* Converts this entry into a JSON-encoded format we can use for WebStorage.
	* Does not encode `clientId` as it is part of the key in WebStorage.
	*/ Xu() {
		const e = {
			activeTargetIds: this.activeTargetIds.toArray(),
			updateTimeMs: Date.now()
		};
		return JSON.stringify(e);
	}
};
var __PRIVATE_MemorySharedClientState = class {
	constructor() {
		this.Uc = new __PRIVATE_LocalClientState(), this.kc = {}, this.onlineStateHandler = null, this.sequenceNumberHandler = null;
	}
	addPendingMutation(e) {}
	updateMutationState(e, t, n) {}
	addLocalQueryTarget(e, t = true) {
		return t && this.Uc.ec(e), this.kc[e] || "not-current";
	}
	updateQueryState(e, t, n) {
		this.kc[e] = t;
	}
	removeLocalQueryTarget(e) {
		this.Uc.tc(e);
	}
	isLocalQueryTarget(e) {
		return this.Uc.activeTargetIds.has(e);
	}
	clearQueryState(e) {
		delete this.kc[e];
	}
	getAllActiveQueryTargets() {
		return this.Uc.activeTargetIds;
	}
	isActiveQueryTarget(e) {
		return this.Uc.activeTargetIds.has(e);
	}
	start() {
		return this.Uc = new __PRIVATE_LocalClientState(), Promise.resolve();
	}
	handleUserChange(e, t, n) {}
	setOnlineState(e) {}
	shutdown() {}
	writeSequenceNumber(e) {}
	notifyBundleLoaded(e) {}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/** The Platform's 'document' implementation or null if not available. */ function getDocument() {
	return "undefined" != typeof document ? document : null;
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* DocumentSet is an immutable (copy-on-write) collection that holds documents
* in order specified by the provided comparator. We always add a document key
* comparator on top of what is provided to guarantee document equality based on
* the key.
*/ var DocumentSet = class DocumentSet {
	/**
	* Returns an empty copy of the existing DocumentSet, using the same
	* comparator.
	*/
	static emptySet(e) {
		return new DocumentSet(e.comparator);
	}
	/** The default ordering is by key if the comparator is omitted */ constructor(e) {
		this.comparator = e ? (t, n) => e(t, n) || DocumentKey.comparator(t.key, n.key) : (e, t) => DocumentKey.comparator(e.key, t.key), this.keyedMap = documentMap(), this.sortedSet = new SortedMap(this.comparator);
	}
	has(e) {
		return null != this.keyedMap.get(e);
	}
	get(e) {
		return this.keyedMap.get(e);
	}
	first() {
		return this.sortedSet.minKey();
	}
	last() {
		return this.sortedSet.maxKey();
	}
	isEmpty() {
		return this.sortedSet.isEmpty();
	}
	/**
	* Returns the index of the provided key in the document set, or -1 if the
	* document key is not present in the set;
	*/ indexOf(e) {
		const t = this.keyedMap.get(e);
		return t ? this.sortedSet.indexOf(t) : -1;
	}
	get size() {
		return this.sortedSet.size;
	}
	/** Iterates documents in order defined by "comparator" */ forEach(e) {
		this.sortedSet.inorderTraversal(((t, n) => (e(t), false)));
	}
	/** Inserts or updates a document with the same key */ add(e) {
		const t = this.delete(e.key);
		return t.copy(t.keyedMap.insert(e.key, e), t.sortedSet.insert(e, null));
	}
	/** Deletes a document with a given key */ delete(e) {
		const t = this.get(e);
		return t ? this.copy(this.keyedMap.remove(e), this.sortedSet.remove(t)) : this;
	}
	isEqual(e) {
		if (!(e instanceof DocumentSet)) return false;
		if (this.size !== e.size) return false;
		const t = this.sortedSet.getIterator(), n = e.sortedSet.getIterator();
		for (; t.hasNext();) {
			const e = t.getNext().key, r = n.getNext().key;
			if (!e.isEqual(r)) return false;
		}
		return true;
	}
	toString() {
		const e = [];
		return this.forEach(((t) => {
			e.push(t.toString());
		})), 0 === e.length ? "DocumentSet ()" : "DocumentSet (\n  " + e.join("  \n") + "\n)";
	}
	copy(e, t) {
		const n = new DocumentSet();
		return n.comparator = this.comparator, n.keyedMap = e, n.sortedSet = t, n;
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* DocumentChangeSet keeps track of a set of changes to docs in a query, merging
* duplicate events for the same doc.
*/ var __PRIVATE_DocumentChangeSet = class {
	constructor() {
		this.Qc = new SortedMap(DocumentKey.comparator);
	}
	track(e) {
		const t = e.doc.key, n = this.Qc.get(t);
		n ? 0 !== e.type && 3 === n.type ? this.Qc = this.Qc.insert(t, e) : 3 === e.type && 1 !== n.type ? this.Qc = this.Qc.insert(t, {
			type: n.type,
			doc: e.doc
		}) : 2 === e.type && 2 === n.type ? this.Qc = this.Qc.insert(t, {
			type: 2,
			doc: e.doc
		}) : 2 === e.type && 0 === n.type ? this.Qc = this.Qc.insert(t, {
			type: 0,
			doc: e.doc
		}) : 1 === e.type && 0 === n.type ? this.Qc = this.Qc.remove(t) : 1 === e.type && 2 === n.type ? this.Qc = this.Qc.insert(t, {
			type: 1,
			doc: n.doc
		}) : 0 === e.type && 1 === n.type ? this.Qc = this.Qc.insert(t, {
			type: 2,
			doc: e.doc
		}) : l(63341, {
			Nt: e,
			qc: n
		}) : this.Qc = this.Qc.insert(t, e);
	}
	Kc() {
		const e = [];
		return this.Qc.inorderTraversal(((t, n) => {
			e.push(n);
		})), e;
	}
};
var ViewSnapshot = class ViewSnapshot {
	constructor(e, t, n, r, i, s, _, o, a) {
		this.query = e, this.docs = t, this.oldDocs = n, this.docChanges = r, this.mutatedKeys = i, this.fromCache = s, this.syncStateChanged = _, this.excludesMetadataChanges = o, this.hasCachedResults = a;
	}
	/** Returns a view snapshot as if all documents in the snapshot were added. */ static fromInitialDocuments(e, t, n, r, i) {
		const s = [];
		return t.forEach(((e) => {
			s.push({
				type: 0,
				doc: e
			});
		})), new ViewSnapshot(e, t, DocumentSet.emptySet(t), s, n, r, true, false, i);
	}
	get hasPendingWrites() {
		return !this.mutatedKeys.isEmpty();
	}
	isEqual(e) {
		if (!(this.fromCache === e.fromCache && this.hasCachedResults === e.hasCachedResults && this.syncStateChanged === e.syncStateChanged && this.mutatedKeys.isEqual(e.mutatedKeys) && __PRIVATE_queryOrPipelineEqual(this.query, e.query) && this.docs.isEqual(e.docs) && this.oldDocs.isEqual(e.oldDocs))) return false;
		const t = this.docChanges, n = e.docChanges;
		if (t.length !== n.length) return false;
		for (let e = 0; e < t.length; e++) if (t[e].type !== n[e].type || !t[e].doc.isEqual(n[e].doc)) return false;
		return true;
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Holds the listeners and the last received ViewSnapshot for a query being
* tracked by EventManager.
*/ var __PRIVATE_QueryListenersInfo = class {
	constructor() {
		this.$c = void 0, this.Wc = [];
	}
	Gc() {
		return this.Wc.some(((e) => e.jc()));
	}
};
var __PRIVATE_EventManagerImpl = class {
	constructor() {
		this.queries = __PRIVATE_newQueriesObjectMap(), this.onlineState = "Unknown", this.zc = /* @__PURE__ */ new Set();
	}
	terminate() {
		(function __PRIVATE_errorAllTargets(e, t) {
			const n = __PRIVATE_debugCast(e), r = n.queries;
			n.queries = __PRIVATE_newQueriesObjectMap(), r.forEach(((e, n) => {
				for (const e of n.Wc) e.onError(t);
			}));
		})(this, new e(ta.ABORTED, "Firestore shutting down"));
	}
};
function __PRIVATE_newQueriesObjectMap() {
	return new ObjectMap(((e) => __PRIVATE_canonifyQueryOrPipeline(e)), __PRIVATE_queryOrPipelineEqual);
}
async function __PRIVATE_eventManagerListen(e, t) {
	const n = __PRIVATE_debugCast(e);
	let r = 3;
	const i = t.query;
	let s = n.queries.get(i);
	s ? !s.Gc() && t.jc() && (r = 2) : (s = new __PRIVATE_QueryListenersInfo(), r = t.jc() ? 0 : 1);
	try {
		switch (r) {
			case 0:
				s.$c = await n.onListen(
					i,
					/** enableRemoteListen= */
					!0
				);
				break;
			case 1:
				s.$c = await n.onListen(
					i,
					/** enableRemoteListen= */
					!1
				);
				break;
			case 2: await n.onFirstRemoteStoreListen(i);
		}
	} catch (e) {
		const n = __PRIVATE_wrapInUserErrorIfRecoverable(e, `Initialization of query '${__PRIVATE_isPipeline(t.query) ? __PRIVATE_canonifyPipeline(t.query) : __PRIVATE_stringifyQuery(t.query)}' failed`);
		t.onError(n);
		return;
	}
	if (n.queries.set(i, s), s.Wc.push(t), t.Hc(n.onlineState), s.$c) t.Jc(s.$c) && __PRIVATE_raiseSnapshotsInSyncEvent(n);
}
async function __PRIVATE_eventManagerUnlisten(e, t) {
	const n = __PRIVATE_debugCast(e), r = t.query;
	let i = 3;
	const s = n.queries.get(r);
	if (s) {
		const e = s.Wc.indexOf(t);
		e >= 0 && (s.Wc.splice(e, 1), 0 === s.Wc.length ? i = t.jc() ? 0 : 1 : !s.Gc() && t.jc() && (i = 2));
	}
	switch (i) {
		case 0: return n.queries.delete(r), n.onUnlisten(
			r,
			/** disableRemoteListen= */
			true
		);
		case 1: return n.queries.delete(r), n.onUnlisten(
			r,
			/** disableRemoteListen= */
			false
		);
		case 2: return n.onLastRemoteStoreUnlisten(r);
		default: return;
	}
}
function __PRIVATE_eventManagerOnWatchChange(e, t) {
	const n = __PRIVATE_debugCast(e);
	let r = false;
	for (const e of t) {
		const t = e.query, i = n.queries.get(t);
		if (i) {
			for (const t of i.Wc) t.Jc(e) && (r = true);
			i.$c = e;
		}
	}
	r && __PRIVATE_raiseSnapshotsInSyncEvent(n);
}
function __PRIVATE_eventManagerOnWatchError(e, t, n) {
	const r = __PRIVATE_debugCast(e), i = r.queries.get(t);
	if (i) for (const e of i.Wc) e.onError(n);
	r.queries.delete(t);
}
function __PRIVATE_raiseSnapshotsInSyncEvent(e) {
	e.zc.forEach(((e) => {
		e.next();
	}));
}
var zr;
(function(e) {
	/** Listen to both cache and server changes */
	e.Default = "default", e.Cache = "cache";
})(zr || (zr = {}));
/**
* QueryListener takes a series of internal view snapshots and determines
* when to raise the event.
*
* It uses an Observer to dispatch events.
*/
var __PRIVATE_QueryListener = class {
	constructor(e, t, n) {
		this.query = e, this.Yc = t, this.Zc = false, this.Xc = null, this.onlineState = "Unknown", this.options = n || {};
	}
	/**
	* Applies the new ViewSnapshot to this listener, raising a user-facing event
	* if applicable (depending on what changed, whether the user has opted into
	* metadata-only changes, etc.). Returns true if a user-facing event was
	* indeed raised.
	*/ Jc(e) {
		if (!this.options.includeMetadataChanges) {
			const t = [];
			for (const n of e.docChanges) 3 !== n.type && t.push(n);
			e = new ViewSnapshot(e.query, e.docs, e.oldDocs, t, e.mutatedKeys, e.fromCache, e.syncStateChanged, true, e.hasCachedResults);
		}
		let t = false;
		return this.Zc ? this.el(e) && (this.Yc.next(e), t = true) : this.tl(e, this.onlineState) && (this.nl(e), t = true), this.Xc = e, t;
	}
	onError(e) {
		this.Yc.error(e);
	}
	/** Returns whether a snapshot was raised. */ Hc(e) {
		this.onlineState = e;
		let t = false;
		return this.Xc && !this.Zc && this.tl(this.Xc, e) && (this.nl(this.Xc), t = true), t;
	}
	tl(e, t) {
		if (!e.fromCache) return true;
		if (!this.jc()) return true;
		const n = "Offline" !== t;
		return (!this.options.waitForSyncWhenOnline || !n) && (!e.docs.isEmpty() || e.hasCachedResults || "Offline" === t);
	}
	el(e) {
		if (e.docChanges.length > 0) return true;
		const t = this.Xc && this.Xc.hasPendingWrites !== e.hasPendingWrites;
		return !(!e.syncStateChanged && !t) && true === this.options.includeMetadataChanges;
	}
	nl(e) {
		e = ViewSnapshot.fromInitialDocuments(e.query, e.docs, e.mutatedKeys, e.fromCache, e.hasCachedResults), this.Zc = true, this.Yc.next(e);
	}
	jc() {
		return this.options.source !== zr.Cache;
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Returns a `LoadBundleTaskProgress` representing the progress that the loading
* has succeeded.
*/
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var __PRIVATE_AddedLimboDocument = class {
	constructor(e) {
		this.key = e;
	}
};
var __PRIVATE_RemovedLimboDocument = class {
	constructor(e) {
		this.key = e;
	}
};
/**
* View is responsible for computing the final merged truth of what docs are in
* a query. It gets notified of local and remote changes to docs, and applies
* the query filters and limits to determine the most correct possible results.
*/ var __PRIVATE_View = class {
	constructor(e, t) {
		this.query = e, this.ll = t, this.El = null, this.hasCachedResults = false, this.current = false, this.hl = __PRIVATE_documentKeySet(), this.mutatedKeys = __PRIVATE_documentKeySet(), this.Tl = __PRIVATE_isPipeline(e) ? __PRIVATE_newPipelineComparator(e) : __PRIVATE_newQueryComparator(e), this.Pl = new DocumentSet(this.Tl);
	}
	/**
	* The set of remote documents that the server has told us belongs to the target associated with
	* this view.
	*/ get Il() {
		return this.ll;
	}
	/**
	* Iterates over a set of doc changes, applies the query limit, and computes
	* what the new results should be, what the changes were, and whether we may
	* need to go back to the local cache for more results. Does not make any
	* changes to the view.
	* @param docChanges - The doc changes to apply to this view.
	* @param previousChanges - If this is being called with a refill, then start
	*        with this set of docs and changes instead of the current view.
	* @returns a new set of docs, changes, and refill flag.
	*/ Rl(e, t) {
		const n = t ? t.Al : new __PRIVATE_DocumentChangeSet(), r = t ? t.Pl : this.Pl;
		let i = t ? t.mutatedKeys : this.mutatedKeys, s = r, _ = false;
		const [o, a] = this.Vl(this.query, r);
		e.inorderTraversal(((e, t) => {
			const u = r.get(e), c = __PRIVATE_queryOrPipelineMatches(this.query, t) ? t : null, l = !!u && this.mutatedKeys.has(u.key), E = !!c && (c.hasLocalMutations || this.mutatedKeys.has(c.key) && c.hasCommittedMutations);
			let h = false;
			if (u && c) u.data.isEqual(c.data) ? l !== E && (n.track({
				type: 3,
				doc: c
			}), h = true) : this.fl(u, c) || (n.track({
				type: 2,
				doc: c
			}), h = true, (o && this.Tl(c, o) > 0 || a && this.Tl(c, a) < 0) && (_ = true));
			else !u && c ? (n.track({
				type: 0,
				doc: c
			}), h = true) : u && !c && (n.track({
				type: 1,
				doc: u
			}), h = true, (o || a) && (_ = true));
			h && (c ? (s = s.add(c), i = E ? i.add(e) : i.delete(e)) : (s = s.delete(e), i = i.delete(e)));
		}));
		const u = this.dl(this.query);
		if (u) if (__PRIVATE_isPipeline(this.query)) {
			const e = [];
			s.forEach(((t) => e.push(t)));
			const t = __PRIVATE_runPipeline(this.query, e);
			let r = new DocumentSet(__PRIVATE_newPipelineComparator(this.query));
			for (const e of t) r = r.add(e);
			s.forEach(((e) => {
				r.has(e.key) || (i = i.delete(e.key), n.track({
					type: 1,
					doc: e
				}));
			})), s = r;
		} else {
			const e = this.ml(this.query);
			for (; s.size > u;) {
				const t = "F" === e ? s.last() : s.first();
				s = s.delete(t.key), i = i.delete(t.key), n.track({
					type: 1,
					doc: t
				});
			}
		}
		return {
			Pl: s,
			Al: n,
			Ja: _,
			mutatedKeys: i
		};
	}
	dl(e) {
		return __PRIVATE_isPipeline(e) ? __PRIVATE_getLastEffectiveLimit(e)?.limit : e.limit || void 0;
	}
	ml(e) {
		if (__PRIVATE_isPipeline(e)) {
			const t = __PRIVATE_getLastEffectiveLimit(e);
			return t && t.limit < 0 ? "L" : "F";
		}
		return e.limitType;
	}
	Vl(e, t) {
		if (__PRIVATE_isPipeline(e)) {
			const n = __PRIVATE_getLastEffectiveLimit(e)?.limit;
			return [t.size === n ? t.last() : null, null];
		}
		return ["F" === e.limitType && t.size === this.dl(this.query) ? t.last() : null, "L" === e.limitType && t.size === this.dl(this.query) ? t.first() : null];
	}
	fl(e, t) {
		return e.hasLocalMutations && t.hasCommittedMutations && !t.hasLocalMutations;
	}
	/**
	* Updates the view with the given ViewDocumentChanges and optionally updates
	* limbo docs and sync state from the provided target change.
	* @param docChanges - The set of changes to make to the view's docs.
	* @param limboResolutionEnabled - Whether to update limbo documents based on
	*        this change.
	* @param targetChange - A target change to apply for computing limbo docs and
	*        sync state.
	* @param targetIsPendingReset - Whether the target is pending to reset due to
	*        existence filter mismatch. If not explicitly specified, it is treated
	*        equivalently to `false`.
	* @returns A new ViewChange with the given docs, changes, and sync state.
	*/
	applyChanges(e, t, n, r) {
		const i = this.Pl;
		this.Pl = e.Pl, this.mutatedKeys = e.mutatedKeys;
		const s = e.Al.Kc();
		s.sort(((e, t) => function __PRIVATE_compareChangeType(e, t) {
			const order = (e) => {
				switch (e) {
					case 0: return 1;
					case 2:
					case 3: return 2;
					case 1: return 0;
					default: return l(20277, { Nt: e });
				}
			};
			return order(e) - order(t);
		}(e.type, t.type) || this.Tl(e.doc, t.doc))), this.pl(n), r = r ?? false;
		/**
		* @license
		* Copyright 2020 Google LLC
		*
		* Licensed under the Apache License, Version 2.0 (the "License");
		* you may not use this file except in compliance with the License.
		* You may obtain a copy of the License at
		*
		*   http://www.apache.org/licenses/LICENSE-2.0
		*
		* Unless required by applicable law or agreed to in writing, software
		* distributed under the License is distributed on an "AS IS" BASIS,
		* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
		* See the License for the specific language governing permissions and
		* limitations under the License.
		*/
		const _ = t && !r ? this.gl() : [], o = 0 === this.hl.size && this.current && !r ? 1 : 0, a = o !== this.El;
		if (this.El = o, 0 !== s.length || a) return {
			snapshot: new ViewSnapshot(this.query, e.Pl, i, s, e.mutatedKeys, 0 === o, a, false, !!n && n.resumeToken.approximateByteSize() > 0),
			yl: _
		};
		return { yl: _ };
	}
	/**
	* Applies an OnlineState change to the view, potentially generating a
	* ViewChange if the view's syncState changes as a result.
	*/ Hc(e) {
		return this.current && "Offline" === e ? (this.current = false, this.applyChanges({
			Pl: this.Pl,
			Al: new __PRIVATE_DocumentChangeSet(),
			mutatedKeys: this.mutatedKeys,
			Ja: false
		}, false)) : { yl: [] };
	}
	/**
	* Returns whether the doc for the given key should be in limbo.
	*/ wl(e) {
		return !this.ll.has(e) && !!this.Pl.has(e) && !this.Pl.get(e).hasLocalMutations;
	}
	/**
	* Updates syncedDocuments, current, and limbo docs based on the given change.
	* Returns the list of changes to which docs are in limbo.
	*/ pl(e) {
		e && (e.addedDocuments.forEach(((e) => this.ll = this.ll.add(e))), e.modifiedDocuments.forEach(((e) => {})), e.removedDocuments.forEach(((e) => this.ll = this.ll.delete(e))), this.current = e.current);
	}
	gl() {
		if (!this.current) return [];
		const e = this.hl;
		this.hl = __PRIVATE_documentKeySet(), this.Pl.forEach(((e) => {
			this.wl(e.key) && (this.hl = this.hl.add(e.key));
		}));
		const t = [];
		return e.forEach(((e) => {
			this.hl.has(e) || t.push(new __PRIVATE_RemovedLimboDocument(e));
		})), this.hl.forEach(((n) => {
			e.has(n) || t.push(new __PRIVATE_AddedLimboDocument(n));
		})), t;
	}
	/**
	* Update the in-memory state of the current view with the state read from
	* persistence.
	*
	* We update the query view whenever a client's primary status changes:
	* - When a client transitions from primary to secondary, it can miss
	*   LocalStorage updates and its query views may temporarily not be
	*   synchronized with the state on disk.
	* - For secondary to primary transitions, the client needs to update the list
	*   of `syncedDocuments` since secondary clients update their query views
	*   based purely on synthesized RemoteEvents.
	*
	* @param queryResult.documents - The documents that match the query according
	* to the LocalStore.
	* @param queryResult.remoteKeys - The keys of the documents that match the
	* query according to the backend.
	*
	* @returns The ViewChange that resulted from this synchronization.
	*/
	bl(e) {
		this.ll = e.ou, this.hl = __PRIVATE_documentKeySet();
		const t = this.Rl(e.documents);
		return this.applyChanges(t, true);
	}
	/**
	* Returns a view snapshot as if this query was just listened to. Contains
	* a document add for every existing document and the `fromCache` and
	* `hasPendingWrites` status of the already established view.
	*/
	Sl() {
		return ViewSnapshot.fromInitialDocuments(this.query, this.Pl, this.mutatedKeys, 0 === this.El, this.hasCachedResults);
	}
};
var Hr = "SyncEngine";
/**
* QueryView contains all of the data that SyncEngine needs to keep track of for
* a particular query.
*/ var __PRIVATE_QueryView = class {
	constructor(e, t, n) {
		this.query = e, this.targetId = t, this.view = n;
	}
};
/** Tracks a limbo resolution. */ var LimboResolution = class {
	constructor(e) {
		this.key = e, this.xl = false;
	}
};
/**
* An implementation of `SyncEngine` coordinating with other parts of SDK.
*
* The parts of SyncEngine that act as a callback to RemoteStore need to be
* registered individually. This is done in `syncEngineWrite()` and
* `syncEngineListen()` (as well as `applyPrimaryState()`) as these methods
* serve as entry points to RemoteStore's functionality.
*
* Note: some field defined in this class might have public access level, but
* the class is not exported so they are only accessible from this module.
* This is useful to implement optional features (like bundles) in free
* functions, such that they are tree-shakeable.
*/ var __PRIVATE_SyncEngineImpl = class {
	constructor(e, t, n, r, i, s) {
		this.localStore = e, this.remoteStore = t, this.eventManager = n, this.sharedClientState = r, this.currentUser = i, this.maxConcurrentLimboResolutions = s, this.vl = {}, this.Dl = new ObjectMap(((e) => __PRIVATE_canonifyQueryOrPipeline(e)), __PRIVATE_queryOrPipelineEqual), this.Cl = /* @__PURE__ */ new Map(), this.Fl = /* @__PURE__ */ new Set(), this.Ol = new SortedMap(DocumentKey.comparator), this.Ml = /* @__PURE__ */ new Map(), this.Nl = new __PRIVATE_ReferenceSet(), this.Bl = {}, this.Ll = /* @__PURE__ */ new Map(), this.Ul = __PRIVATE_TargetIdGenerator.K_(), this.onlineState = "Unknown", this.kl = void 0;
	}
	get isPrimaryClient() {
		return true === this.kl;
	}
};
/**
* Initiates the new listen, resolves promise when listen enqueued to the
* server. All the subsequent view snapshots or errors are sent to the
* subscribed handlers. Returns the initial snapshot.
*/
async function __PRIVATE_syncEngineListen(e, t, n = true) {
	const r = __PRIVATE_ensureWatchCallbacks(e);
	let i;
	const s = r.Dl.get(t);
	return s ? (r.sharedClientState.addLocalQueryTarget(s.targetId), i = s.view.Sl()) : i = await __PRIVATE_allocateTargetAndMaybeListen(
		r,
		t,
		n,
		/** shouldInitializeView= */
		true
	), i;
}
/** Query has been listening to the cache, and tries to initiate the remote store listen */ async function __PRIVATE_triggerRemoteStoreListen(e, t) {
	await __PRIVATE_allocateTargetAndMaybeListen(
		__PRIVATE_ensureWatchCallbacks(e),
		t,
		/** shouldListenToRemote= */
		true,
		/** shouldInitializeView= */
		false
	);
}
async function __PRIVATE_allocateTargetAndMaybeListen(e, t, n, r) {
	const i = await __PRIVATE_localStoreAllocateTarget(e.localStore, __PRIVATE_isPipeline(t) ? t : __PRIVATE_queryToTarget(t)), s = i.targetId, _ = e.sharedClientState.addLocalQueryTarget(s, n);
	let o;
	return r && (o = await __PRIVATE_initializeViewAndComputeSnapshot(e, t, s, "current" === _, i.resumeToken)), e.isPrimaryClient && n && __PRIVATE_remoteStoreListen(e.remoteStore, i), o;
}
/**
* Registers a view for a previously unknown query and computes its initial
* snapshot.
*/ async function __PRIVATE_initializeViewAndComputeSnapshot(e, t, n, r, i) {
	e.Ql = (t, n, r) => async function __PRIVATE_applyDocChanges(e, t, n, r) {
		let i = t.view.Rl(n);
		i.Ja && (i = await __PRIVATE_localStoreExecuteQuery(e.localStore, t.query, false).then((({ documents: e }) => t.view.Rl(e, i))));
		const s = r && r.targetChanges.get(t.targetId), _ = r && null != r.targetMismatches.get(t.targetId), o = t.view.applyChanges(i, e.isPrimaryClient, s, _);
		return __PRIVATE_updateTrackedLimbos(e, t.targetId, o.yl), o.snapshot;
	}(e, t, n, r);
	const s = await __PRIVATE_localStoreExecuteQuery(e.localStore, t, true), _ = new __PRIVATE_View(t, s.ou), o = _.Rl(s.documents), a = TargetChange.createSynthesizedTargetChangeForCurrentChange(n, r && "Offline" !== e.onlineState, i), u = _.applyChanges(o, e.isPrimaryClient, a);
	__PRIVATE_updateTrackedLimbos(e, n, u.yl);
	const c = new __PRIVATE_QueryView(t, n, _);
	return e.Dl.set(t, c), e.Cl.has(n) ? e.Cl.get(n).push(t) : e.Cl.set(n, [t]), u.snapshot;
}
/** Stops listening to the query. */ async function __PRIVATE_syncEngineUnlisten(e, t, n) {
	const r = __PRIVATE_debugCast(e), i = r.Dl.get(t), s = r.Cl.get(i.targetId);
	if (s.length > 1) return r.Cl.set(i.targetId, s.filter(((e) => !__PRIVATE_queryOrPipelineEqual(e, t)))), void r.Dl.delete(t);
	if (r.isPrimaryClient) {
		r.sharedClientState.removeLocalQueryTarget(i.targetId);
		r.sharedClientState.isActiveQueryTarget(i.targetId) || await __PRIVATE_localStoreReleaseTarget(r.localStore, i.targetId, false).then((() => {
			r.sharedClientState.clearQueryState(i.targetId), n && __PRIVATE_remoteStoreUnlisten(r.remoteStore, i.targetId), __PRIVATE_removeAndCleanupTarget(r, i.targetId);
		})).catch(__PRIVATE_ignoreIfPrimaryLeaseLoss);
	} else __PRIVATE_removeAndCleanupTarget(r, i.targetId), await __PRIVATE_localStoreReleaseTarget(r.localStore, i.targetId, true);
}
/** Unlistens to the remote store while still listening to the cache. */ async function __PRIVATE_triggerRemoteStoreUnlisten(e, t) {
	const n = __PRIVATE_debugCast(e), r = n.Dl.get(t), i = n.Cl.get(r.targetId);
	n.isPrimaryClient && 1 === i.length && (n.sharedClientState.removeLocalQueryTarget(r.targetId), __PRIVATE_remoteStoreUnlisten(n.remoteStore, r.targetId));
}
/**
* Initiates the write of local mutation batch which involves adding the
* writes to the mutation queue, notifying the remote store about new
* mutations and raising events for any changes this write caused.
*
* The promise returned by this call is resolved when the above steps
* have completed, *not* when the write was acked by the backend. The
* userCallback is resolved once the write was acked/rejected by the
* backend (or failed locally for any other reason).
*/ async function __PRIVATE_syncEngineWrite(e, t, n) {
	const r = __PRIVATE_syncEngineEnsureWriteCallbacks(e);
	try {
		const e = await function __PRIVATE_localStoreWriteLocally(e, t) {
			const n = __PRIVATE_debugCast(e), r = Timestamp.now(), i = t.reduce(((e, t) => e.add(t.key)), __PRIVATE_documentKeySet());
			let s, _;
			return n.persistence.runTransaction("Locally write mutations", "readwrite", ((e) => {
				let o = __PRIVATE_mutableDocumentMap(), a = __PRIVATE_documentKeySet();
				return n.nu.getEntries(e, i).next(((e) => {
					o = e, o.forEach(((e, t) => {
						t.isValidDocument() || (a = a.add(e));
					}));
				})).next((() => n.localDocuments.getOverlayedDocuments(e, o))).next(((i) => {
					s = i;
					const _ = [];
					for (const e of t) {
						const t = __PRIVATE_mutationExtractBaseValue(e, s.get(e.key).overlayedDocument);
						null != t && _.push(new __PRIVATE_PatchMutation(e.key, t, __PRIVATE_extractFieldMask(t.value.mapValue), Precondition.exists(!0)));
					}
					return n.mutationQueue.addMutationBatch(e, r, _, t);
				})).next(((t) => {
					_ = t;
					const r = t.applyToLocalDocumentSet(s, a);
					return n.documentOverlayCache.saveOverlays(e, t.batchId, r);
				}));
			})).then((() => ({
				batchId: _.batchId,
				changes: __PRIVATE_convertOverlayedDocumentMapToDocumentMap(s)
			})));
		}(r.localStore, t);
		r.sharedClientState.addPendingMutation(e.batchId), function __PRIVATE_addMutationCallback(e, t, n) {
			let r = e.Bl[e.currentUser.toKey()];
			r || (r = new SortedMap(__PRIVATE_primitiveComparator));
			r = r.insert(t, n), e.Bl[e.currentUser.toKey()] = r;
		}(r, e.batchId, n), await __PRIVATE_syncEngineEmitNewSnapsAndNotifyLocalStore(r, e.changes), await __PRIVATE_fillWritePipeline(r.remoteStore);
	} catch (e) {
		const t = __PRIVATE_wrapInUserErrorIfRecoverable(e, "Failed to persist write");
		n.reject(t);
	}
}
/**
* Applies one remote event to the sync engine, notifying any views of the
* changes, and releasing any pending mutation batches that would become
* visible because of the snapshot version the remote event contains.
*/ async function __PRIVATE_syncEngineApplyRemoteEvent(e, t) {
	const n = __PRIVATE_debugCast(e);
	try {
		const e = await __PRIVATE_localStoreApplyRemoteEventToLocalCache(n.localStore, t);
		t.targetChanges.forEach(((e, t) => {
			const r = n.Ml.get(t);
			r && (__PRIVATE_hardAssert(e.addedDocuments.size + e.modifiedDocuments.size + e.removedDocuments.size <= 1, 22616), e.addedDocuments.size > 0 ? r.xl = !0 : e.modifiedDocuments.size > 0 ? __PRIVATE_hardAssert(r.xl, 14607) : e.removedDocuments.size > 0 && (__PRIVATE_hardAssert(r.xl, 42227), r.xl = !1));
		})), await __PRIVATE_syncEngineEmitNewSnapsAndNotifyLocalStore(n, e, t);
	} catch (e) {
		await __PRIVATE_ignoreIfPrimaryLeaseLoss(e);
	}
}
/**
* Applies an OnlineState change to the sync engine and notifies any views of
* the change.
*/ function __PRIVATE_syncEngineApplyOnlineStateChange(e, t, n) {
	const r = __PRIVATE_debugCast(e);
	if (r.isPrimaryClient && 0 === n || !r.isPrimaryClient && 1 === n) {
		const e = [];
		r.Dl.forEach(((n, r) => {
			const i = r.view.Hc(t);
			i.snapshot && e.push(i.snapshot);
		})), function __PRIVATE_eventManagerOnOnlineStateChange(e, t) {
			const n = __PRIVATE_debugCast(e);
			n.onlineState = t;
			let r = false;
			n.queries.forEach(((e, n) => {
				for (const e of n.Wc) e.Hc(t) && (r = true);
			})), r && __PRIVATE_raiseSnapshotsInSyncEvent(n);
		}(r.eventManager, t), e.length && r.vl.gr(e), r.onlineState = t, r.isPrimaryClient && r.sharedClientState.setOnlineState(t);
	}
}
/**
* Rejects the listen for the given targetID. This can be triggered by the
* backend for any active target.
*
* @param syncEngine - The sync engine implementation.
* @param targetId - The targetID corresponds to one previously initiated by the
* user as part of TargetData passed to listen() on RemoteStore.
* @param err - A description of the condition that has forced the rejection.
* Nearly always this will be an indication that the user is no longer
* authorized to see the data matching the target.
*/ async function __PRIVATE_syncEngineRejectListen(e, t, n) {
	const r = __PRIVATE_debugCast(e);
	r.sharedClientState.updateQueryState(t, "rejected", n);
	const i = r.Ml.get(t), s = i && i.key;
	if (s) {
		let e = new SortedMap(DocumentKey.comparator);
		e = e.insert(s, MutableDocument.newNoDocument(s, SnapshotVersion.min()));
		const n = __PRIVATE_documentKeySet().add(s);
		await __PRIVATE_syncEngineApplyRemoteEvent(r, new RemoteEvent(SnapshotVersion.min(), /* @__PURE__ */ new Map(), new SortedMap(__PRIVATE_primitiveComparator), e, __PRIVATE_mutableDocumentMap(), n)), r.Ol = r.Ol.remove(s), r.Ml.delete(t), __PRIVATE_pumpEnqueuedLimboResolutions(r);
	} else await __PRIVATE_localStoreReleaseTarget(r.localStore, t, false).then((() => __PRIVATE_removeAndCleanupTarget(r, t, n))).catch(__PRIVATE_ignoreIfPrimaryLeaseLoss);
}
async function __PRIVATE_syncEngineApplySuccessfulWrite(e, t) {
	const n = __PRIVATE_debugCast(e), r = t.batch.batchId;
	try {
		const e = await __PRIVATE_localStoreAcknowledgeBatch(n.localStore, t);
		__PRIVATE_processUserCallback(n, r, null), __PRIVATE_triggerPendingWritesCallbacks(n, r), n.sharedClientState.updateMutationState(r, "acknowledged"), await __PRIVATE_syncEngineEmitNewSnapsAndNotifyLocalStore(n, e);
	} catch (e) {
		await __PRIVATE_ignoreIfPrimaryLeaseLoss(e);
	}
}
async function __PRIVATE_syncEngineRejectFailedWrite(e, t, n) {
	const r = __PRIVATE_debugCast(e);
	try {
		const e = await function __PRIVATE_localStoreRejectBatch(e, t) {
			const n = __PRIVATE_debugCast(e);
			return n.persistence.runTransaction("Reject batch", "readwrite-primary", ((e) => {
				let r;
				return n.mutationQueue.lookupMutationBatch(e, t).next(((t) => (__PRIVATE_hardAssert(null !== t, 37113), r = t.keys(), n.mutationQueue.removeMutationBatch(e, t)))).next((() => n.mutationQueue.performConsistencyCheck(e))).next((() => n.documentOverlayCache.removeOverlaysForBatchId(e, r, t))).next((() => n.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(e, r))).next((() => n.localDocuments.getDocuments(e, r)));
			}));
		}(r.localStore, t);
		__PRIVATE_processUserCallback(r, t, n), __PRIVATE_triggerPendingWritesCallbacks(r, t), r.sharedClientState.updateMutationState(t, "rejected", n), await __PRIVATE_syncEngineEmitNewSnapsAndNotifyLocalStore(r, e);
	} catch (n) {
		await __PRIVATE_ignoreIfPrimaryLeaseLoss(n);
	}
}
/**
* Triggers the callbacks that are waiting for this batch id to get acknowledged by server,
* if there are any.
*/ function __PRIVATE_triggerPendingWritesCallbacks(e, t) {
	(e.Ll.get(t) || []).forEach(((e) => {
		e.resolve();
	})), e.Ll.delete(t);
}
/** Reject all outstanding callbacks waiting for pending writes to complete. */ function __PRIVATE_processUserCallback(e, t, n) {
	const r = __PRIVATE_debugCast(e);
	let i = r.Bl[r.currentUser.toKey()];
	if (i) {
		const e = i.get(t);
		e && (n ? e.reject(n) : e.resolve(), i = i.remove(t)), r.Bl[r.currentUser.toKey()] = i;
	}
}
function __PRIVATE_removeAndCleanupTarget(e, t, n = null) {
	e.sharedClientState.removeLocalQueryTarget(t);
	for (const r of e.Cl.get(t)) e.Dl.delete(r), n && e.vl.ql(r, n);
	if (e.Cl.delete(t), e.isPrimaryClient) e.Nl.Ao(t).forEach(((t) => {
		e.Nl.containsKey(t) || __PRIVATE_removeLimboTarget(e, t);
	}));
}
function __PRIVATE_removeLimboTarget(e, t) {
	e.Fl.delete(t.path.canonicalString());
	const n = e.Ol.get(t);
	null !== n && (__PRIVATE_remoteStoreUnlisten(e.remoteStore, n), e.Ol = e.Ol.remove(t), e.Ml.delete(n), __PRIVATE_pumpEnqueuedLimboResolutions(e));
}
function __PRIVATE_updateTrackedLimbos(e, t, n) {
	for (const r of n) if (r instanceof __PRIVATE_AddedLimboDocument) e.Nl.addReference(r.key, t), __PRIVATE_trackLimboChange(e, r);
	else if (r instanceof __PRIVATE_RemovedLimboDocument) {
		__PRIVATE_logDebug(Hr, "Document no longer in limbo: " + r.key), e.Nl.removeReference(r.key, t);
		e.Nl.containsKey(r.key) || __PRIVATE_removeLimboTarget(e, r.key);
	} else l(19791, { Kl: r });
}
function __PRIVATE_trackLimboChange(e, t) {
	const n = t.key, r = n.path.canonicalString();
	e.Ol.get(n) || e.Fl.has(r) || (__PRIVATE_logDebug(Hr, "New document in limbo: " + n), e.Fl.add(r), __PRIVATE_pumpEnqueuedLimboResolutions(e));
}
/**
* Starts listens for documents in limbo that are enqueued for resolution,
* subject to a maximum number of concurrent resolutions.
*
* Without bounding the number of concurrent resolutions, the server can fail
* with "resource exhausted" errors which can lead to pathological client
* behavior as seen in https://github.com/firebase/firebase-js-sdk/issues/2683.
*/ function __PRIVATE_pumpEnqueuedLimboResolutions(e) {
	for (; e.Fl.size > 0 && e.Ol.size < e.maxConcurrentLimboResolutions;) {
		const t = e.Fl.values().next().value;
		e.Fl.delete(t);
		const n = new DocumentKey(ResourcePath.fromString(t)), r = e.Ul.next();
		e.Ml.set(r, new LimboResolution(n)), e.Ol = e.Ol.insert(n, r), __PRIVATE_remoteStoreListen(e.remoteStore, new TargetData(__PRIVATE_queryToTarget(__PRIVATE_newQueryForPath(n.path)), r, "TargetPurposeLimboResolution", __PRIVATE_ListenSequence.Br));
	}
}
async function __PRIVATE_syncEngineEmitNewSnapsAndNotifyLocalStore(e, t, n) {
	const r = __PRIVATE_debugCast(e), i = [], s = [], _ = [];
	r.Dl.isEmpty() || (r.Dl.forEach(((e, o) => {
		_.push(r.Ql(o, t, n).then(((e) => {
			if ((e || n) && r.isPrimaryClient) {
				const t = e ? !e.fromCache : n?.targetChanges.get(o.targetId)?.current;
				r.sharedClientState.updateQueryState(o.targetId, t ? "current" : "not-current");
			}
			if (e) {
				i.push(e);
				const t = __PRIVATE_LocalViewChanges.Ua(o.targetId, e);
				s.push(t);
			}
		})));
	})), await Promise.all(_), r.vl.gr(i), await async function __PRIVATE_localStoreNotifyLocalViewChanges(e, t) {
		const n = __PRIVATE_debugCast(e);
		try {
			await n.persistence.runTransaction("notifyLocalViewChanges", "readwrite", ((e) => PersistencePromise.forEach(t, ((t) => PersistencePromise.forEach(t.Ba, ((r) => n.persistence.referenceDelegate.addReference(e, t.targetId, r))).next((() => PersistencePromise.forEach(t.La, ((r) => n.persistence.referenceDelegate.removeReference(e, t.targetId, r)))))))));
		} catch (e) {
			if (!__PRIVATE_isIndexedDbTransactionError(e)) throw e;
			__PRIVATE_logDebug(kr, "Failed to update sequence numbers: " + e);
		}
		for (const e of t) {
			const t = e.targetId;
			if (!e.fromCache) {
				const e = n.Xa.get(t), r = e.snapshotVersion, i = e.withLastLimboFreeSnapshotVersion(r);
				n.Xa = n.Xa.insert(t, i);
			}
		}
	}(r.localStore, s));
}
async function __PRIVATE_syncEngineHandleCredentialChange(t, n) {
	const r = __PRIVATE_debugCast(t);
	if (!r.currentUser.isEqual(n)) {
		__PRIVATE_logDebug(Hr, "User change. New user:", n.toKey());
		const t = await __PRIVATE_localStoreHandleUserChange(r.localStore, n);
		r.currentUser = n, function __PRIVATE_rejectOutstandingPendingWritesCallbacks(t, n) {
			t.Ll.forEach(((t) => {
				t.forEach(((t) => {
					t.reject(new e(ta.CANCELLED, n));
				}));
			})), t.Ll.clear();
		}(r, "'waitForPendingWrites' promise is rejected due to a user change."), r.sharedClientState.handleUserChange(n, t.removedBatchIds, t.addedBatchIds), await __PRIVATE_syncEngineEmitNewSnapsAndNotifyLocalStore(r, t.iu);
	}
}
function __PRIVATE_syncEngineGetRemoteKeysForTarget(e, t) {
	const n = __PRIVATE_debugCast(e), r = n.Ml.get(t);
	if (r && r.xl) return __PRIVATE_documentKeySet().add(r.key);
	{
		let e = __PRIVATE_documentKeySet();
		const r = n.Cl.get(t);
		if (!r) return e;
		for (const t of r ?? []) {
			const r = n.Dl.get(t);
			e = e.unionWith(r.view.Il);
		}
		return e;
	}
}
function __PRIVATE_ensureWatchCallbacks(e) {
	const t = __PRIVATE_debugCast(e);
	return t.remoteStore.remoteSyncer.applyRemoteEvent = __PRIVATE_syncEngineApplyRemoteEvent.bind(null, t), t.remoteStore.remoteSyncer.getRemoteKeysForTarget = __PRIVATE_syncEngineGetRemoteKeysForTarget.bind(null, t), t.remoteStore.remoteSyncer.rejectListen = __PRIVATE_syncEngineRejectListen.bind(null, t), t.vl.gr = __PRIVATE_eventManagerOnWatchChange.bind(null, t.eventManager), t.vl.ql = __PRIVATE_eventManagerOnWatchError.bind(null, t.eventManager), t;
}
function __PRIVATE_syncEngineEnsureWriteCallbacks(e) {
	const t = __PRIVATE_debugCast(e);
	return t.remoteStore.remoteSyncer.applySuccessfulWrite = __PRIVATE_syncEngineApplySuccessfulWrite.bind(null, t), t.remoteStore.remoteSyncer.rejectFailedWrite = __PRIVATE_syncEngineRejectFailedWrite.bind(null, t), t;
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var __PRIVATE_MemoryOfflineComponentProvider = class {
	constructor() {
		this.kind = "memory", this.synchronizeTabs = false;
	}
	async initialize(e) {
		this.serializer = __PRIVATE_newSerializer(e.databaseInfo.databaseId), this.sharedClientState = this.Wl(e), this.persistence = this.Gl(e), await this.persistence.start(), this.localStore = this.jl(e), this.gcScheduler = this.zl(e, this.localStore), this.indexBackfillerScheduler = this.Hl(e, this.localStore);
	}
	zl(e, t) {
		return null;
	}
	Hl(e, t) {
		return null;
	}
	jl(e) {
		return __PRIVATE_newLocalStore(this.persistence, new __PRIVATE_QueryEngine(), e.initialUser, this.serializer);
	}
	Gl(e) {
		return new __PRIVATE_MemoryPersistence(__PRIVATE_MemoryEagerDelegate.jo, this.serializer);
	}
	Wl(e) {
		return new __PRIVATE_MemorySharedClientState();
	}
	async terminate() {
		this.gcScheduler?.stop(), this.indexBackfillerScheduler?.stop(), this.sharedClientState.shutdown(), await this.persistence.shutdown();
	}
};
__PRIVATE_MemoryOfflineComponentProvider.provider = { build: () => new __PRIVATE_MemoryOfflineComponentProvider() };
var __PRIVATE_LruGcMemoryOfflineComponentProvider = class extends __PRIVATE_MemoryOfflineComponentProvider {
	constructor(e) {
		super(), this.cacheSizeBytes = e;
	}
	zl(e, t) {
		__PRIVATE_hardAssert(this.persistence.referenceDelegate instanceof __PRIVATE_MemoryLruDelegate, 46915);
		const n = this.persistence.referenceDelegate.garbageCollector;
		return new __PRIVATE_LruScheduler(n, e.asyncQueue, t);
	}
	Gl(e) {
		const t = void 0 !== this.cacheSizeBytes ? LruParams.withCacheSize(this.cacheSizeBytes) : LruParams.DEFAULT;
		return new __PRIVATE_MemoryPersistence(((e) => __PRIVATE_MemoryLruDelegate.jo(e, t)), this.serializer);
	}
};
/**
* Initializes and wires the components that are needed to interface with the
* network.
*/ var OnlineComponentProvider = class {
	async initialize(e, t) {
		this.localStore || (this.localStore = e.localStore, this.sharedClientState = e.sharedClientState, this.datastore = this.createDatastore(t), this.remoteStore = this.createRemoteStore(t), this.eventManager = this.createEventManager(t), this.syncEngine = this.createSyncEngine(t, !e.synchronizeTabs), this.sharedClientState.onlineStateHandler = (e) => __PRIVATE_syncEngineApplyOnlineStateChange(this.syncEngine, e, 1), this.remoteStore.remoteSyncer.handleCredentialChange = __PRIVATE_syncEngineHandleCredentialChange.bind(null, this.syncEngine), await __PRIVATE_remoteStoreApplyPrimaryState(this.remoteStore, this.syncEngine.isPrimaryClient));
	}
	createEventManager(e) {
		return function __PRIVATE_newEventManager() {
			return new __PRIVATE_EventManagerImpl();
		}();
	}
	createDatastore(e) {
		const t = __PRIVATE_newSerializer(e.databaseInfo.databaseId), n = __PRIVATE_newConnection(e.databaseInfo);
		return __PRIVATE_newDatastore(e.authCredentials, e.appCheckCredentials, n, t);
	}
	createRemoteStore(e) {
		return function __PRIVATE_newRemoteStore(e, t, n, r, i) {
			return new __PRIVATE_RemoteStoreImpl(e, t, n, r, i);
		}(this.localStore, this.datastore, e.asyncQueue, ((e) => __PRIVATE_syncEngineApplyOnlineStateChange(this.syncEngine, e, 0)), function __PRIVATE_newConnectivityMonitor() {
			return __PRIVATE_BrowserConnectivityMonitor.cn() ? new __PRIVATE_BrowserConnectivityMonitor() : new __PRIVATE_NoopConnectivityMonitor();
		}());
		/**
		* @license
		* Copyright 2017 Google LLC
		*
		* Licensed under the Apache License, Version 2.0 (the "License");
		* you may not use this file except in compliance with the License.
		* You may obtain a copy of the License at
		*
		*   http://www.apache.org/licenses/LICENSE-2.0
		*
		* Unless required by applicable law or agreed to in writing, software
		* distributed under the License is distributed on an "AS IS" BASIS,
		* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
		* See the License for the specific language governing permissions and
		* limitations under the License.
		*/
	}
	createSyncEngine(e, t) {
		return function __PRIVATE_newSyncEngine(e, t, n, r, i, s, _) {
			const o = new __PRIVATE_SyncEngineImpl(e, t, n, r, i, s);
			return _ && (o.kl = true), o;
		}(this.localStore, this.remoteStore, this.eventManager, this.sharedClientState, e.initialUser, e.maxConcurrentLimboResolutions, t);
	}
	async terminate() {
		await async function __PRIVATE_remoteStoreShutdown(e) {
			const t = __PRIVATE_debugCast(e);
			__PRIVATE_logDebug(qr, "RemoteStore shutting down."), t.bu.add(5), await __PRIVATE_disableNetworkInternal(t), t.xu.shutdown(), t.vu.set("Unknown");
		}(this.remoteStore), this.datastore?.terminate(), this.eventManager?.terminate();
	}
};
OnlineComponentProvider.provider = { build: () => new OnlineComponentProvider() };
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var Jr = "FirestoreClient";
/**
* FirestoreClient is a top-level class that constructs and owns all of the //
* pieces of the client SDK architecture. It is responsible for creating the //
* async queue that is shared by all of the other components in the system. //
*/
var FirestoreClient = class {
	constructor(e, t, n, r, i) {
		this.authCredentials = e, this.appCheckCredentials = t, this.asyncQueue = n, this._databaseInfo = r, this.user = User.UNAUTHENTICATED, this.clientId = __PRIVATE_AutoId.newId(), this.authCredentialListener = () => Promise.resolve(), this.appCheckCredentialListener = () => Promise.resolve(), this._uninitializedComponentsProvider = i, this.authCredentials.start(n, (async (e) => {
			__PRIVATE_logDebug(Jr, "Received user=", e.uid), await this.authCredentialListener(e), this.user = e;
		})), this.appCheckCredentials.start(n, ((e) => (__PRIVATE_logDebug(Jr, "Received new app check token=", e), this.appCheckCredentialListener(e, this.user))));
	}
	get configuration() {
		return {
			asyncQueue: this.asyncQueue,
			databaseInfo: this._databaseInfo,
			clientId: this.clientId,
			authCredentials: this.authCredentials,
			appCheckCredentials: this.appCheckCredentials,
			initialUser: this.user,
			maxConcurrentLimboResolutions: 100
		};
	}
	setCredentialChangeListener(e) {
		this.authCredentialListener = e;
	}
	setAppCheckTokenChangeListener(e) {
		this.appCheckCredentialListener = e;
	}
	terminate() {
		this.asyncQueue.enterRestrictedMode();
		const e = new __PRIVATE_Deferred();
		return this.asyncQueue.enqueueAndForgetEvenWhileRestricted((async () => {
			try {
				this._onlineComponents && await this._onlineComponents.terminate(), this._offlineComponents && await this._offlineComponents.terminate(), this.authCredentials.shutdown(), this.appCheckCredentials.shutdown(), e.resolve();
			} catch (t) {
				const n = __PRIVATE_wrapInUserErrorIfRecoverable(t, "Failed to shutdown persistence");
				e.reject(n);
			}
		})), e.promise;
	}
};
async function __PRIVATE_setOfflineComponentProvider(e, t) {
	e.asyncQueue.verifyOperationInProgress(), __PRIVATE_logDebug(Jr, "Initializing OfflineComponentProvider");
	const n = e.configuration;
	await t.initialize(n);
	let r = n.initialUser;
	e.setCredentialChangeListener((async (e) => {
		r.isEqual(e) || (await __PRIVATE_localStoreHandleUserChange(t.localStore, e), r = e);
	})), t.persistence.setDatabaseDeletedListener((() => e.terminate())), e._offlineComponents = t;
}
async function __PRIVATE_setOnlineComponentProvider(e, t) {
	e.asyncQueue.verifyOperationInProgress();
	const n = await __PRIVATE_ensureOfflineComponents(e);
	__PRIVATE_logDebug(Jr, "Initializing OnlineComponentProvider"), await t.initialize(n, e.configuration), e.setCredentialChangeListener(((e) => __PRIVATE_remoteStoreHandleCredentialChange(t.remoteStore, e))), e.setAppCheckTokenChangeListener(((e, n) => __PRIVATE_remoteStoreHandleCredentialChange(t.remoteStore, n))), e._onlineComponents = t;
}
/**
* Decides whether the provided error allows us to gracefully disable
* persistence (as opposed to crashing the client).
*/ async function __PRIVATE_ensureOfflineComponents(e) {
	if (!e._offlineComponents) if (e._uninitializedComponentsProvider) {
		__PRIVATE_logDebug(Jr, "Using user provided OfflineComponentProvider");
		try {
			await __PRIVATE_setOfflineComponentProvider(e, e._uninitializedComponentsProvider._offline);
		} catch (t) {
			const n = t;
			if (!function __PRIVATE_canFallbackFromIndexedDbError(e) {
				return "FirebaseError" === e.name ? e.code === ta.FAILED_PRECONDITION || e.code === ta.UNIMPLEMENTED : !("undefined" != typeof DOMException && e instanceof DOMException) || 22 === e.code || 20 === e.code || 11 === e.code;
			}(n)) throw n;
			__PRIVATE_logWarn("Error using user provided cache. Falling back to memory cache: " + n), await __PRIVATE_setOfflineComponentProvider(e, new __PRIVATE_MemoryOfflineComponentProvider());
		}
	} else __PRIVATE_logDebug(Jr, "Using default OfflineComponentProvider"), await __PRIVATE_setOfflineComponentProvider(e, new __PRIVATE_LruGcMemoryOfflineComponentProvider(void 0));
	return e._offlineComponents;
}
async function __PRIVATE_ensureOnlineComponents(e) {
	return e._onlineComponents || (e._uninitializedComponentsProvider ? (__PRIVATE_logDebug(Jr, "Using user provided OnlineComponentProvider"), await __PRIVATE_setOnlineComponentProvider(e, e._uninitializedComponentsProvider._online)) : (__PRIVATE_logDebug(Jr, "Using default OnlineComponentProvider"), await __PRIVATE_setOnlineComponentProvider(e, new OnlineComponentProvider()))), e._onlineComponents;
}
function __PRIVATE_getSyncEngine(e) {
	return __PRIVATE_ensureOnlineComponents(e).then(((e) => e.syncEngine));
}
async function __PRIVATE_getEventManager(e) {
	const t = await __PRIVATE_ensureOnlineComponents(e), n = t.eventManager;
	return n.onListen = __PRIVATE_syncEngineListen.bind(null, t.syncEngine), n.onUnlisten = __PRIVATE_syncEngineUnlisten.bind(null, t.syncEngine), n.onFirstRemoteStoreListen = __PRIVATE_triggerRemoteStoreListen.bind(null, t.syncEngine), n.onLastRemoteStoreUnlisten = __PRIVATE_triggerRemoteStoreUnlisten.bind(null, t.syncEngine), n;
}
function __PRIVATE_firestoreClientGetDocumentViaSnapshotListener(t, n, r = {}) {
	const i = new __PRIVATE_Deferred();
	return t.asyncQueue.enqueueAndForget((async () => function __PRIVATE_readDocumentViaSnapshotListener(t, n, r, i, s) {
		const _ = new __PRIVATE_AsyncObserver({
			next: (a) => {
				_.Mu(), n.enqueueAndForget((() => __PRIVATE_eventManagerUnlisten(t, o)));
				const u = a.docs.has(r);
				!u && a.fromCache ? s.reject(new e(ta.UNAVAILABLE, "Failed to get document because the client is offline.")) : u && a.fromCache && i && "server" === i.source ? s.reject(new e(ta.UNAVAILABLE, "Failed to get document from server. (However, this document does exist in the local cache. Run again without setting source to \"server\" to retrieve the cached document.)")) : s.resolve(a);
			},
			error: (e) => s.reject(e)
		}), o = new __PRIVATE_QueryListener(__PRIVATE_newQueryForPath(r.path), _, {
			includeMetadataChanges: true,
			waitForSyncWhenOnline: true
		});
		return __PRIVATE_eventManagerListen(t, o);
	}(await __PRIVATE_getEventManager(t), t.asyncQueue, n, r, i))), i.promise;
}
function __PRIVATE_firestoreClientGetDocumentsViaSnapshotListener(t, n, r = {}) {
	const i = new __PRIVATE_Deferred();
	return t.asyncQueue.enqueueAndForget((async () => function __PRIVATE_executeQueryViaSnapshotListener(t, n, r, i, s) {
		const _ = new __PRIVATE_AsyncObserver({
			next: (r) => {
				_.Mu(), n.enqueueAndForget((() => __PRIVATE_eventManagerUnlisten(t, o))), r.fromCache && "server" === i.source ? s.reject(new e(ta.UNAVAILABLE, "Failed to get documents from server. (However, these documents may exist in the local cache. Run again without setting source to \"server\" to retrieve the cached documents.)")) : s.resolve(r);
			},
			error: (e) => s.reject(e)
		}), o = new __PRIVATE_QueryListener(r instanceof __PRIVATE_RealtimePipeline ? __PRIVATE_toCorePipeline(r) : r, _, {
			includeMetadataChanges: true,
			waitForSyncWhenOnline: true
		});
		return __PRIVATE_eventManagerListen(t, o);
	}(await __PRIVATE_getEventManager(t), t.asyncQueue, n, r, i))), i.promise;
}
function __PRIVATE_firestoreClientWrite(e, t) {
	const n = new __PRIVATE_Deferred();
	return e.asyncQueue.enqueueAndForget((async () => __PRIVATE_syncEngineWrite(await __PRIVATE_getSyncEngine(e), t, n))), n.promise;
}
/**
* @license
* Copyright 2018 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* A `DocumentSnapshot` contains data read from a document in your Firestore
* database. The data can be extracted with `.data()` or `.get(<field>)` to
* get a specific field.
*
* For a `DocumentSnapshot` that points to a non-existing document, any data
* access will return 'undefined'. You can use the `exists()` method to
* explicitly verify a document's existence.
*/ var Yr = class DocumentSnapshot {
	/** @hideconstructor protected */
	constructor(e, t, n, r, i) {
		this._firestore = e, this._userDataWriter = t, this._key = n, this._document = r, this._converter = i;
	}
	/** Property of the `DocumentSnapshot` that provides the document's ID. */ get id() {
		return this._key.path.lastSegment();
	}
	/**
	* The `DocumentReference` for the document included in the `DocumentSnapshot`.
	*/ get ref() {
		return new aa(this._firestore, this._converter, this._key);
	}
	/**
	* Signals whether or not the document at the snapshot's location exists.
	*
	* @returns true if the document exists.
	*/ exists() {
		return null !== this._document;
	}
	/**
	* Retrieves all fields in the document as an `Object`. Returns `undefined` if
	* the document doesn't exist.
	*
	* @returns An `Object` containing all fields in the document or `undefined`
	* if the document doesn't exist.
	*/ data() {
		if (this._document) {
			if (this._converter) {
				const e = new Zr(this._firestore, this._userDataWriter, this._key, this._document, null);
				return this._converter.fromFirestore(e);
			}
			return this._userDataWriter.convertValue(this._document.data.value);
		}
	}
	/**
	* @internal
	* @private
	*
	* Retrieves all fields in the document as a proto Value. Returns `undefined` if
	* the document doesn't exist.
	*
	* @returns An `Object` containing all fields in the document or `undefined`
	* if the document doesn't exist.
	*/ _fieldsProto() {
		return this._document?.data.clone().value.mapValue.fields ?? void 0;
	}
	/**
	* Retrieves the field specified by `fieldPath`. Returns `undefined` if the
	* document or field doesn't exist.
	*
	* @param fieldPath - The path (for example 'foo' or 'foo.bar') to a specific
	* field.
	* @returns The data at the specified field location or undefined if no such
	* field exists in the document.
	*/
	get(e) {
		if (this._document) {
			const t = this._document.data.field(K("DocumentSnapshot.get", e));
			if (null !== t) return this._userDataWriter.convertValue(t);
		}
	}
};
var Zr = class QueryDocumentSnapshot extends Yr {
	/**
	* Retrieves all fields in the document as an `Object`.
	*
	* @override
	* @returns An `Object` containing all fields in the document.
	*/
	data() {
		return super.data();
	}
};
/**
* A `QueryDocumentSnapshot` contains data read from a document in your
* Firestore database as part of a query. The document is guaranteed to exist
* and its data can be extracted with `.data()` or `.get(<field>)` to get a
* specific field.
*
* A `QueryDocumentSnapshot` offers the same API surface as a
* `DocumentSnapshot`. Since query results contain only existing documents, the
* `exists` property will always be true and `data()` will never return
* 'undefined'.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Converts Firestore's internal types to the JavaScript types that we expose
* to the user.
*
* @internal
*/
var AbstractUserDataWriter = class {
	convertValue(e, t = "none") {
		switch (__PRIVATE_typeOrder(e)) {
			case 0: return null;
			case 2: return e.booleanValue;
			case 3:
				if ("mapValue" in e) {
					if (__PRIVATE_isInt32Value(e)) return this.convertToInt32Value(e.mapValue);
					if (__PRIVATE_isDecimal128Value(e)) return this.convertToDecimal128Value(e.mapValue);
				}
				return __PRIVATE_normalizeNumber(e.integerValue || e.doubleValue);
			case 4: return this.convertTimestamp(e.timestampValue);
			case 6: return this.convertServerTimestamp(e, t);
			case 7: return e.stringValue;
			case 8: return "bytesValue" in e ? this.convertBytes(__PRIVATE_normalizeByteString(e.bytesValue)) : this.convertToBytesWithSubtype(e.mapValue);
			case 9: return this.convertReference(e.referenceValue);
			case 11: return this.convertGeoPoint(e.geoPointValue);
			case 13: return this.convertArray(e.arrayValue, t);
			case 15: return this.convertObject(e.mapValue, t);
			case 14: return this.convertVectorValue(e.mapValue);
			case 12: return this.convertToRegexValue(e.mapValue);
			case 10: return this.convertToBsonObjectId(e.mapValue);
			case 5: return this.convertToBsonTimestamp(e.mapValue);
			case 16: return MaxKey.instance();
			case 1: return MinKey.instance();
			default: throw l(62114, { value: e });
		}
	}
	convertObject(e, t) {
		return this.convertObjectMap(e.fields, t);
	}
	/**
	* @internal
	*/ convertObjectMap(e, t = "none") {
		const n = {};
		return forEach(e, ((e, r) => {
			n[e] = this.convertValue(r, t);
		})), n;
	}
	/**
	* @internal
	*/ convertVectorValue(e) {
		const t = e.fields?.[Xe].arrayValue?.values?.map(((e) => __PRIVATE_normalizeNumber(e.doubleValue)));
		return new n(t);
	}
	convertToBsonObjectId(e) {
		return new BsonObjectId(e.fields?.[_t]?.stringValue ?? "");
	}
	convertToBytesWithSubtype(e) {
		const n = (e.fields?.[Et])?.bytesValue;
		if (!n) throw new Error("Received incorrect bytesValue for Bytes with subtype");
		const r = __PRIVATE_normalizeByteString(n).toUint8Array();
		if (0 === r.length) throw new Error("Received empty bytesValue for Bytes with subtype");
		const i = r[0], s = r.slice(1);
		return new Bytes(ByteString.fromUint8Array(s), i);
	}
	convertToBsonTimestamp(e) {
		const t = e.fields?.[ut];
		return new BsonTimestamp(Number(t?.mapValue?.fields?.[ct]?.integerValue), Number(t?.mapValue?.fields?.[lt]?.integerValue));
	}
	convertToRegexValue(e) {
		return new RegexValue(e.fields?.[rt]?.mapValue?.fields?.[it]?.stringValue ?? "", e.fields?.[rt]?.mapValue?.fields?.[st]?.stringValue ?? "");
	}
	convertToInt32Value(e) {
		return new Int32Value(Number(e.fields?.[ot]?.integerValue));
	}
	convertToDecimal128Value(e) {
		return new Decimal128Value(e.fields?.[at]?.stringValue ?? "");
	}
	convertGeoPoint(e) {
		return new GeoPoint(__PRIVATE_normalizeNumber(e.latitude), __PRIVATE_normalizeNumber(e.longitude));
	}
	convertArray(e, t) {
		return (e.values || []).map(((e) => this.convertValue(e, t)));
	}
	convertServerTimestamp(e, t) {
		switch (t) {
			case "previous":
				const n = __PRIVATE_getPreviousValue(e);
				return null == n ? null : this.convertValue(n, t);
			case "estimate": return this.convertTimestamp(__PRIVATE_getLocalWriteTime(e));
			default: return null;
		}
	}
	convertTimestamp(e) {
		const t = __PRIVATE_normalizeTimestamp(e);
		return new Timestamp(t.seconds, t.nanos);
	}
	convertDocumentKey(e, t) {
		const n = ResourcePath.fromString(e);
		__PRIVATE_hardAssert(__PRIVATE_isValidResourceName(n), 9688, { name: e });
		const r = new DatabaseId(n.get(1), n.get(3)), i = new DocumentKey(n.popFirst(5));
		return r.isEqual(t) || __PRIVATE_logError(`A document reference to ${i} refers to a different database (${r.projectId}/${r.database}), which is not supported. It will be treated as a reference in the current database (${t.projectId}/${t.database}) instead.`), i;
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Converts custom model object of type T into `DocumentData` by applying the
* converter if it exists.
*
* This function is used when converting user objects to `DocumentData`
* because we want to provide the user with a more specific error message if
* their `set()` or fails due to invalid data originating from a `toFirestore()`
* call.
*/ function __PRIVATE_applyFirestoreDataConverter(e, t, n) {
	let r;
	return r = e ? n && (n.merge || n.mergeFields) ? e.toFirestore(t, n) : e.toFirestore(t) : t, r;
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var Xr = "AsyncQueue";
var __PRIVATE_AsyncQueueImpl = class {
	constructor(e = Promise.resolve()) {
		this.iE = [], this.sE = false, this._E = [], this.oE = null, this.aE = false, this.uE = false, this.cE = [], this._r = new __PRIVATE_ExponentialBackoff(this, "async_queue_retry"), this.lE = () => {
			const e = getDocument();
			e && __PRIVATE_logDebug(Xr, "Visibility state changed to " + e.visibilityState), this._r.Xn();
		}, this.EE = e;
		const t = getDocument();
		t && "function" == typeof t.addEventListener && t.addEventListener("visibilitychange", this.lE);
	}
	get isShuttingDown() {
		return this.sE;
	}
	/**
	* Adds a new operation to the queue without waiting for it to complete (i.e.
	* we ignore the Promise result).
	*/ enqueueAndForget(e) {
		this.enqueue(e);
	}
	enqueueAndForgetEvenWhileRestricted(e) {
		this.hE(), this.TE(e);
	}
	enterRestrictedMode(e) {
		if (!this.sE) {
			this.sE = true, this.uE = e || false;
			const t = getDocument();
			t && "function" == typeof t.removeEventListener && t.removeEventListener("visibilitychange", this.lE);
		}
	}
	enqueue(e) {
		if (this.hE(), this.sE) return new Promise((() => {}));
		const t = new __PRIVATE_Deferred();
		return this.TE((() => this.sE && this.uE ? Promise.resolve() : (e().then(t.resolve, t.reject), t.promise))).then((() => t.promise));
	}
	enqueueRetryable(e) {
		this.enqueueAndForget((() => (this.iE.push(e), this.PE())));
	}
	/**
	* Runs the next operation from the retryable queue. If the operation fails,
	* reschedules with backoff.
	*/ async PE() {
		if (0 !== this.iE.length) {
			try {
				await this.iE[0](), this.iE.shift(), this._r.reset();
			} catch (e) {
				if (!__PRIVATE_isIndexedDbTransactionError(e)) throw e;
				__PRIVATE_logDebug(Xr, "Operation failed with retryable error: " + e);
			}
			this.iE.length > 0 && this._r.Yn((() => this.PE()));
		}
	}
	TE(e) {
		const t = this.EE.then((() => (this.aE = true, e().catch(((e) => {
			this.oE = e, this.aE = false;
			throw __PRIVATE_logError("INTERNAL UNHANDLED ERROR: ", __PRIVATE_getMessageOrStack(e)), e;
		})).then(((e) => (this.aE = false, e))))));
		return this.EE = t, t;
	}
	enqueueAfterDelay(e, t, n) {
		this.hE(), this.cE.indexOf(e) > -1 && (t = 0);
		const r = DelayedOperation.createAndSchedule(this, e, t, n, ((e) => this.IE(e)));
		return this._E.push(r), r;
	}
	hE() {
		this.oE && l(47125, { RE: __PRIVATE_getMessageOrStack(this.oE) });
	}
	verifyOperationInProgress() {}
	/**
	* Waits until all currently queued tasks are finished executing. Delayed
	* operations are not run.
	*/ async AE() {
		let e;
		do
			e = this.EE, await e;
		while (e !== this.EE);
	}
	/**
	* For Tests: Determine if a delayed operation with a particular TimerId
	* exists.
	*/ VE(e) {
		for (const t of this._E) if (t.timerId === e) return true;
		return false;
	}
	/**
	* For Tests: Runs some or all delayed operations early.
	*
	* @param lastTimerId - Delayed operations up to and including this TimerId
	* will be drained. Pass TimerId.All to run all delayed operations.
	* @returns a Promise that resolves once all operations have been run.
	*/ fE(e) {
		return this.AE().then((() => {
			this._E.sort(((e, t) => e.targetTimeMs - t.targetTimeMs));
			for (const t of this._E) if (t.skipDelay(), "all" !== e && t.timerId === e) break;
			return this.AE();
		}));
	}
	/**
	* For Tests: Skip all subsequent delays for a timer id.
	*/ dE(e) {
		this.cE.push(e);
	}
	/** Called once a DelayedOperation is run or canceled. */ IE(e) {
		const t = this._E.indexOf(e);
		this._E.splice(t, 1);
	}
};
/**
* Chrome includes Error.message in Error.stack. Other browsers do not.
* This returns expected output of message + stack when available.
* @param error - Error or FirestoreError
*/ function __PRIVATE_getMessageOrStack(e) {
	let t = e.message || "";
	return e.stack && (t = e.stack.includes(e.message) ? e.stack : e.message + "\n" + e.stack), t;
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* The Cloud Firestore service interface.
*
* Do not call this constructor directly. Instead, use {@link (getFirestore:1)}.
*/ var da = class extends _n {
	/** @hideconstructor */
	constructor(e, t, n, r) {
		super(e, t, n, r), this.type = "firestore", this._queue = new __PRIVATE_AsyncQueueImpl(), this._persistenceKey = r?.name || "[DEFAULT]";
	}
	async _terminate() {
		if (this._firestoreClient) {
			const e = this._firestoreClient.terminate();
			this._queue = new __PRIVATE_AsyncQueueImpl(e), this._firestoreClient = void 0, await e;
		}
	}
};
/**
* Initializes a new instance of {@link Firestore} with the provided settings.
* Can only be called before any other function, including
* {@link (getFirestore:1)}. If the custom settings are empty, this function is
* equivalent to calling {@link (getFirestore:1)}.
*
* @param app - The {@link @firebase/app#FirebaseApp} with which the {@link Firestore} instance will
* be associated.
* @param settings - A settings object to configure the {@link Firestore} instance.
* @param databaseId - The name of the database.
* @returns A newly initialized {@link Firestore} instance.
*/ function initializeFirestore(t, n, r) {
	r || (r = Ke);
	const i = _getProvider(t, "firestore");
	if (i.isInitialized(r)) {
		const t = i.getImmediate({ identifier: r }), s = i.getOptions(r);
		if (deepEqual(s, n)) return t;
		throw new e(ta.FAILED_PRECONDITION, "initializeFirestore() has already been called with different options. To avoid this error, call initializeFirestore() with the same options as when it was originally called, or call getFirestore() to return the already initialized instance.");
	}
	if (void 0 !== n.cacheSizeBytes && void 0 !== n.localCache) throw new e(ta.INVALID_ARGUMENT, "cache and cacheSizeBytes cannot be specified at the same time as cacheSizeBytes willbe deprecated. Instead, specify the cache size in the cache object");
	if (void 0 !== n.cacheSizeBytes && -1 !== n.cacheSizeBytes && n.cacheSizeBytes < nn) throw new e(ta.INVALID_ARGUMENT, "cacheSizeBytes must be at least 1048576");
	return n.host && isCloudWorkstation(n.host) && pingServer(n.host), i.initialize({
		options: n,
		instanceIdentifier: r
	});
}
function getFirestore(e, t) {
	const n = "object" == typeof e ? e : getApp(), r = "string" == typeof e ? e : t || Ke, i = _getProvider(n, "firestore").getImmediate({ identifier: r });
	if (!i._initialized) {
		const e = getDefaultEmulatorHostnameAndPort("firestore");
		e && connectFirestoreEmulator(i, ...e);
	}
	return i;
}
/**
* @internal
*/ function oa(t) {
	if (t._terminated) throw new e(ta.FAILED_PRECONDITION, "The client has already been terminated.");
	return t._firestoreClient || __PRIVATE_configureFirestore(t), t._firestoreClient;
}
function __PRIVATE_configureFirestore(e) {
	const t = e._freezeSettings(), n = __PRIVATE_makeDatabaseInfo(e._databaseId, e._app?.options.appId || "", e._persistenceKey, e._app?.options.apiKey, t);
	e._componentsProvider || t.localCache?._offlineComponentProvider && t.localCache?._onlineComponentProvider && (e._componentsProvider = {
		_offline: t.localCache._offlineComponentProvider,
		_online: t.localCache._onlineComponentProvider
	}), e._firestoreClient = new FirestoreClient(e._authCredentials, e._appCheckCredentials, e._queue, n, e._componentsProvider && function __PRIVATE_buildComponentProvider(e) {
		const t = e?._online.build();
		return {
			_offline: e?._offline.build(t),
			_online: t
		};
	}(e._componentsProvider));
}
/**
* @license
* Copyright 2024 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var ua = class extends AbstractUserDataWriter {
	constructor(e) {
		super(), this.firestore = e;
	}
	convertBytes(e) {
		return new Bytes(e);
	}
	convertReference(e) {
		const t = this.convertDocumentKey(e, this.firestore._databaseId);
		return new aa(this.firestore, null, t);
	}
};
/**
* @license
* Copyright 2025 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Metadata about a snapshot, describing the state of the snapshot.
*/ var SnapshotMetadata = class {
	/** @hideconstructor */
	constructor(e, t) {
		this.hasPendingWrites = e, this.fromCache = t;
	}
	/**
	* Returns true if this `SnapshotMetadata` is equal to the provided one.
	*
	* @param other - The `SnapshotMetadata` to compare against.
	* @returns true if this `SnapshotMetadata` is equal to the provided one.
	*/ isEqual(e) {
		return this.hasPendingWrites === e.hasPendingWrites && this.fromCache === e.fromCache;
	}
};
/**
* A `DocumentSnapshot` contains data read from a document in your Firestore
* database. The data can be extracted with `.data()` or `.get(<field>)` to
* get a specific field.
*
* For a `DocumentSnapshot` that points to a non-existing document, any data
* access will return 'undefined'. You can use the `exists()` method to
* explicitly verify a document's existence.
*/ var DocumentSnapshot = class DocumentSnapshot extends Yr {
	/** @hideconstructor protected */
	constructor(e, t, n, r, i, s) {
		super(e, t, n, r, s), this._firestore = e, this._firestoreImpl = e, this.metadata = i;
	}
	/**
	* Returns whether or not the data exists. True if the document exists.
	*/ exists() {
		return super.exists();
	}
	/**
	* Retrieves all fields in the document as an `Object`. Returns `undefined` if
	* the document doesn't exist.
	*
	* By default, `serverTimestamp()` values that have not yet been
	* set to their final value will be returned as `null`. You can override
	* this by passing an options object.
	*
	* @param options - An options object to configure how data is retrieved from
	* the snapshot (for example the desired behavior for server timestamps that
	* have not yet been set to their final value).
	* @returns An `Object` containing all fields in the document or `undefined` if
	* the document doesn't exist.
	*/ data(e = {}) {
		if (this._document) {
			if (this._converter) {
				const t = new QueryDocumentSnapshot(this._firestore, this._userDataWriter, this._key, this._document, this.metadata, null);
				return this._converter.fromFirestore(t, e);
			}
			return this._userDataWriter.convertValue(this._document.data.value, e.serverTimestamps);
		}
	}
	/**
	* Retrieves the field specified by `fieldPath`. Returns `undefined` if the
	* document or field doesn't exist.
	*
	* By default, a `serverTimestamp()` that has not yet been set to
	* its final value will be returned as `null`. You can override this by
	* passing an options object.
	*
	* @param fieldPath - The path (for example 'foo' or 'foo.bar') to a specific
	* field.
	* @param options - An options object to configure how the field is retrieved
	* from the snapshot (for example the desired behavior for server timestamps
	* that have not yet been set to their final value).
	* @returns The data at the specified field location or undefined if no such
	* field exists in the document.
	*/
	get(e, t = {}) {
		if (this._document) {
			const n = this._document.data.field(K("DocumentSnapshot.get", e));
			if (null !== n) return this._userDataWriter.convertValue(n, t.serverTimestamps);
		}
	}
	/**
	* Returns a JSON-serializable representation of this `DocumentSnapshot` instance.
	*
	* @returns a JSON representation of this object.  Throws a {@link FirestoreError} if this
	* `DocumentSnapshot` has pending writes.
	*/ toJSON() {
		if (this.metadata.hasPendingWrites) throw new e(ta.FAILED_PRECONDITION, "DocumentSnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");
		const t = this._document, n = {};
		if (n.type = DocumentSnapshot._jsonSchemaVersion, n.bundle = "", n.bundleSource = "DocumentSnapshot", n.bundleName = this._key.toString(), !t || !t.isValidDocument() || !t.isFoundDocument()) return n;
		this._userDataWriter.convertObjectMap(t.data.value.mapValue.fields, "previous");
		return n.bundle = (this._firestore, this.ref.path, "NOT SUPPORTED"), n;
	}
};
/**
* A `QueryDocumentSnapshot` contains data read from a document in your
* Firestore database as part of a query. The document is guaranteed to exist
* and its data can be extracted with `.data()` or `.get(<field>)` to get a
* specific field.
*
* A `QueryDocumentSnapshot` offers the same API surface as a
* `DocumentSnapshot`. Since query results contain only existing documents, the
* `exists` property will always be true and `data()` will never return
* 'undefined'.
*/ DocumentSnapshot._jsonSchemaVersion = "firestore/documentSnapshot/1.0", DocumentSnapshot._jsonSchema = {
	type: property("string", DocumentSnapshot._jsonSchemaVersion),
	bundleSource: property("string", "DocumentSnapshot"),
	bundleName: property("string"),
	bundle: property("string")
};
var QueryDocumentSnapshot = class extends DocumentSnapshot {
	/**
	* Retrieves all fields in the document as an `Object`.
	*
	* By default, `serverTimestamp()` values that have not yet been
	* set to their final value will be returned as `null`. You can override
	* this by passing an options object.
	*
	* @override
	* @param options - An options object to configure how data is retrieved from
	* the snapshot (for example the desired behavior for server timestamps that
	* have not yet been set to their final value).
	* @returns An `Object` containing all fields in the document.
	*/
	data(e = {}) {
		return super.data(e);
	}
};
/**
* A `QuerySnapshot` contains zero or more `DocumentSnapshot` objects
* representing the results of a query. The documents can be accessed as an
* array via the `docs` property or enumerated using the `forEach` method. The
* number of documents can be determined via the `empty` and `size`
* properties.
*/ var QuerySnapshot = class QuerySnapshot {
	/** @hideconstructor */
	constructor(e, t, n, r) {
		this._firestore = e, this._userDataWriter = t, this._snapshot = r, this.metadata = new SnapshotMetadata(r.hasPendingWrites, r.fromCache), this.query = n;
	}
	/** An array of all the documents in the `QuerySnapshot`. */ get docs() {
		const e = [];
		return this.forEach(((t) => e.push(t))), e;
	}
	/** The number of documents in the `QuerySnapshot`. */ get size() {
		return this._snapshot.docs.size;
	}
	/** True if there are no documents in the `QuerySnapshot`. */ get empty() {
		return 0 === this.size;
	}
	/**
	* Enumerates all of the documents in the `QuerySnapshot`.
	*
	* @param callback - A callback to be called with a `QueryDocumentSnapshot` for
	* each document in the snapshot.
	* @param thisArg - The `this` binding for the callback.
	*/ forEach(e, t) {
		this._snapshot.docs.forEach(((n) => {
			e.call(t, new QueryDocumentSnapshot(this._firestore, this._userDataWriter, n.key, n, new SnapshotMetadata(this._snapshot.mutatedKeys.has(n.key), this._snapshot.fromCache), this.query.converter));
		}));
	}
	/**
	* Returns an array of the documents changes since the last snapshot. If this
	* is the first snapshot, all documents will be in the list as 'added'
	* changes.
	*
	* @param options - `SnapshotListenOptions` that control whether metadata-only
	* changes (i.e. only `DocumentSnapshot.metadata` changed) should trigger
	* snapshot events.
	*/ docChanges(t = {}) {
		const n = !!t.includeMetadataChanges;
		if (n && this._snapshot.excludesMetadataChanges) throw new e(ta.INVALID_ARGUMENT, "To include metadata changes with your document changes, you must also pass { includeMetadataChanges:true } to onSnapshot().");
		return this._cachedChanges && this._cachedChangesIncludeMetadataChanges === n || (this._cachedChanges = function __PRIVATE_changesFromSnapshot(e, t) {
			if (e._snapshot.oldDocs.isEmpty()) {
				let t = 0;
				return e._snapshot.docChanges.map(((n) => {
					__PRIVATE_isPipeline(e._snapshot.query) ? __PRIVATE_newPipelineComparator(e._snapshot.query) : e.query._query;
					const r = new QueryDocumentSnapshot(e._firestore, e._userDataWriter, n.doc.key, n.doc, new SnapshotMetadata(e._snapshot.mutatedKeys.has(n.doc.key), e._snapshot.fromCache), e.query.converter);
					return n.doc, {
						type: "added",
						doc: r,
						oldIndex: -1,
						newIndex: t++
					};
				}));
			}
			{
				let n = e._snapshot.oldDocs;
				return e._snapshot.docChanges.filter(((e) => t || 3 !== e.type)).map(((t) => {
					const r = new QueryDocumentSnapshot(e._firestore, e._userDataWriter, t.doc.key, t.doc, new SnapshotMetadata(e._snapshot.mutatedKeys.has(t.doc.key), e._snapshot.fromCache), e.query.converter);
					let i = -1, s = -1;
					return 0 !== t.type && (i = n.indexOf(t.doc.key), n = n.delete(t.doc.key)), 1 !== t.type && (n = n.add(t.doc), s = n.indexOf(t.doc.key)), {
						type: __PRIVATE_resultChangeType(t.type),
						doc: r,
						oldIndex: i,
						newIndex: s
					};
				}));
			}
		}(this, n), this._cachedChangesIncludeMetadataChanges = n), this._cachedChanges;
	}
	/**
	* Returns a JSON-serializable representation of this `QuerySnapshot` instance.
	*
	* @returns a JSON representation of this object. Throws a {@link FirestoreError} if this
	* `QuerySnapshot` has pending writes.
	*/ toJSON() {
		if (this.metadata.hasPendingWrites) throw new e(ta.FAILED_PRECONDITION, "QuerySnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");
		const t = {};
		t.type = QuerySnapshot._jsonSchemaVersion, t.bundleSource = "QuerySnapshot", t.bundleName = __PRIVATE_AutoId.newId(), this._firestore._databaseId.database, this._firestore._databaseId.projectId;
		const n = [], r = [], i = [];
		return this.docs.forEach(((e) => {
			null !== e._document && (n.push(e._document), r.push(this._userDataWriter.convertObjectMap(e._document.data.value.mapValue.fields, "previous")), i.push(e.ref.path));
		})), t.bundle = (this._firestore, this.query._query, t.bundleName, "NOT SUPPORTED"), t;
	}
};
function __PRIVATE_resultChangeType(e) {
	switch (e) {
		case 0: return "added";
		case 2:
		case 3: return "modified";
		case 1: return "removed";
		default: return l(61501, { type: e });
	}
}
/**
* @license
* Copyright 2025 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ QuerySnapshot._jsonSchemaVersion = "firestore/querySnapshot/1.0", QuerySnapshot._jsonSchema = {
	type: property("string", QuerySnapshot._jsonSchemaVersion),
	bundleSource: property("string", "QuerySnapshot"),
	bundleName: property("string"),
	bundle: property("string")
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
//#endregion
//#region node_modules/@firebase/firestore/dist/index.esm.js
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ function __PRIVATE_validateHasExplicitOrderByForLimitToLast(e$1) {
	if ("L" === e$1.limitType && 0 === e$1.explicitOrderBy.length) throw new e(ta.UNIMPLEMENTED, "limitToLast() queries require specifying at least one orderBy() clause");
}
/**
* An `AppliableConstraint` is an abstraction of a constraint that can be applied
* to a Firestore query.
*/ var AppliableConstraint = class {};
/**
* A `QueryConstraint` is used to narrow the set of documents returned by a
* Firestore query. `QueryConstraint`s are created by invoking {@link where},
* {@link orderBy}, {@link (startAt:1)}, {@link (startAfter:1)}, {@link
* (endBefore:1)}, {@link (endAt:1)}, {@link limit}, {@link limitToLast} and
* can then be passed to {@link (query:1)} to create a new query instance that
* also contains this `QueryConstraint`.
*/ var QueryConstraint = class extends AppliableConstraint {};
function query(e$1, t, ...n) {
	let r = [];
	t instanceof AppliableConstraint && r.push(t), r = r.concat(n), function __PRIVATE_validateQueryConstraintArray(e$1) {
		const t = e$1.filter(((e) => e instanceof QueryCompositeFilterConstraint)).length, n = e$1.filter(((e) => e instanceof QueryFieldFilterConstraint)).length;
		if (t > 1 || t > 0 && n > 0) throw new e(ta.INVALID_ARGUMENT, "InvalidQuery. When using composite filters, you cannot use more than one filter at the top level. Consider nesting the multiple filters within an `and(...)` statement. For example: change `query(query, where(...), or(...))` to `query(query, and(where(...), or(...)))`.");
	}(r);
	/**
	* @license
	* Copyright 2022 Google LLC
	*
	* Licensed under the Apache License, Version 2.0 (the "License");
	* you may not use this file except in compliance with the License.
	* You may obtain a copy of the License at
	*
	*   http://www.apache.org/licenses/LICENSE-2.0
	*
	* Unless required by applicable law or agreed to in writing, software
	* distributed under the License is distributed on an "AS IS" BASIS,
	* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	* See the License for the specific language governing permissions and
	* limitations under the License.
	*/
	for (const t of r) e$1 = t._apply(e$1);
	return e$1;
}
/**
* A `QueryFieldFilterConstraint` is used to narrow the set of documents returned by
* a Firestore query by filtering on one or more document fields.
* `QueryFieldFilterConstraint`s are created by invoking {@link where} and can then
* be passed to {@link (query:1)} to create a new query instance that also contains
* this `QueryFieldFilterConstraint`.
*/ var QueryFieldFilterConstraint = class QueryFieldFilterConstraint extends QueryConstraint {
	/**
	* @internal
	*/
	constructor(e, t, n) {
		super(), this._field = e, this._op = t, this._value = n, this.type = "where";
	}
	static _create(e, t, n) {
		return new QueryFieldFilterConstraint(e, t, n);
	}
	_apply(e) {
		const t = this._parse(e);
		return __PRIVATE_validateNewFieldFilter(e._query, t), new Query(e.firestore, e.converter, __PRIVATE_queryWithAddedFilter(e._query, t));
	}
	_parse(e$1) {
		const t = la(e$1.firestore);
		return function __PRIVATE_newQueryFilter(e$1, t, n, r, s, a, o) {
			let i;
			if (function __PRIVATE_validateQueryOperator(e, t) {
				if ("number" == typeof e && isNaN(e) && "==" !== t && "!=" !== t && "array-contains" !== t) throw new Error("Invalid query. You can only perform '==' and '!=' comparisons on NaN.");
				if (null === e && "==" !== t && "!=" !== t && "array-contains" !== t) throw new Error("Invalid query. You can only perform '==' and '!=' comparisons on Null.");
			}(o, a), s.isKeyField()) {
				if ("array-contains" === a || "array-contains-any" === a) throw new e(ta.INVALID_ARGUMENT, `Invalid Query. You can't perform '${a}' queries on documentId().`);
				if ("in" === a || "not-in" === a) {
					__PRIVATE_validateDisjunctiveFilterElements(o, a);
					const t = [];
					for (const n of o) t.push(__PRIVATE_parseDocumentIdValue(r, e$1, n));
					i = { arrayValue: { values: t } };
				} else i = __PRIVATE_parseDocumentIdValue(r, e$1, o);
			} else "in" !== a && "not-in" !== a && "array-contains-any" !== a || __PRIVATE_validateDisjunctiveFilterElements(o, a), i = __PRIVATE_parseQueryValue(n, t, o, "in" === a || "not-in" === a);
			return FieldFilter.create(s, a, i);
		}(e$1._query, "where", t, e$1.firestore._databaseId, this._field, this._op, this._value);
	}
};
/**
* Creates a {@link QueryFieldFilterConstraint} that enforces that documents
* must contain the specified field and that the value should satisfy the
* relation constraint provided.
*
* @param fieldPath - The path to compare
* @param opStr - The operation string (e.g "&lt;", "&lt;=", "==", "&lt;",
*   "&lt;=", "!=").
* @param value - The value for comparison
* @returns The created {@link QueryFieldFilterConstraint}.
*/ function where(e, t, n) {
	const r = t, s = K("where", e);
	return QueryFieldFilterConstraint._create(s, r, n);
}
/**
* A `QueryCompositeFilterConstraint` is used to narrow the set of documents
* returned by a Firestore query by performing the logical OR or AND of multiple
* {@link QueryFieldFilterConstraint}s or {@link QueryCompositeFilterConstraint}s.
* `QueryCompositeFilterConstraint`s are created by invoking {@link or} or
* {@link and} and can then be passed to {@link (query:1)} to create a new query
* instance that also contains the `QueryCompositeFilterConstraint`.
*/ var QueryCompositeFilterConstraint = class QueryCompositeFilterConstraint extends AppliableConstraint {
	/**
	* @internal
	*/
	constructor(e, t) {
		super(), this.type = e, this._queryConstraints = t;
	}
	static _create(e, t) {
		return new QueryCompositeFilterConstraint(e, t);
	}
	_parse(e) {
		const t = this._queryConstraints.map(((t) => t._parse(e))).filter(((e) => e.getFilters().length > 0));
		return 1 === t.length ? t[0] : CompositeFilter.create(t, this._getOperator());
	}
	_apply(e) {
		const t = this._parse(e);
		return 0 === t.getFilters().length ? e : (function __PRIVATE_validateNewFilter(e, t) {
			let n = e;
			const r = t.getFlattenedFilters();
			for (const e of r) __PRIVATE_validateNewFieldFilter(n, e), n = __PRIVATE_queryWithAddedFilter(n, e);
		}(e._query, t), new Query(e.firestore, e.converter, __PRIVATE_queryWithAddedFilter(e._query, t)));
	}
	_getQueryConstraints() {
		return this._queryConstraints;
	}
	_getOperator() {
		return "and" === this.type ? "and" : "or";
	}
};
/**
* A `QueryOrderByConstraint` is used to sort the set of documents returned by a
* Firestore query. `QueryOrderByConstraint`s are created by invoking
* {@link orderBy} and can then be passed to {@link (query:1)} to create a new query
* instance that also contains this `QueryOrderByConstraint`.
*
* Note: Documents that do not contain the orderBy field will not be present in
* the query result.
*/ var QueryOrderByConstraint = class QueryOrderByConstraint extends QueryConstraint {
	/**
	* @internal
	*/
	constructor(e, t) {
		super(), this._field = e, this._direction = t, this.type = "orderBy";
	}
	static _create(e, t) {
		return new QueryOrderByConstraint(e, t);
	}
	_apply(e$1) {
		const t = function __PRIVATE_newQueryOrderBy(e$1, t, n) {
			if (null !== e$1.startAt) throw new e(ta.INVALID_ARGUMENT, "Invalid query. You must not call startAt() or startAfter() before calling orderBy().");
			if (null !== e$1.endAt) throw new e(ta.INVALID_ARGUMENT, "Invalid query. You must not call endAt() or endBefore() before calling orderBy().");
			return new OrderBy(t, n);
		}(e$1._query, this._field, this._direction);
		return new Query(e$1.firestore, e$1.converter, __PRIVATE_queryWithAddedOrderBy(e$1._query, t));
	}
};
/**
* Creates a {@link QueryOrderByConstraint} that sorts the query result by the
* specified field, optionally in descending order instead of ascending.
*
* Note: Documents that do not contain the specified field will not be present
* in the query result.
*
* @param fieldPath - The field to sort by.
* @param directionStr - Optional direction to sort by ('asc' or 'desc'). If
* not specified, order will be ascending.
* @returns The created {@link QueryOrderByConstraint}.
*/ function orderBy(e, t = "asc") {
	const n = t, r = K("orderBy", e);
	return QueryOrderByConstraint._create(r, n);
}
/**
* A `QueryLimitConstraint` is used to limit the number of documents returned by
* a Firestore query.
* `QueryLimitConstraint`s are created by invoking {@link limit} or
* {@link limitToLast} and can then be passed to {@link (query:1)} to create a new
* query instance that also contains this `QueryLimitConstraint`.
*/ var QueryLimitConstraint = class QueryLimitConstraint extends QueryConstraint {
	/**
	* @internal
	*/
	constructor(e, t, n) {
		super(), this.type = e, this._limit = t, this._limitType = n;
	}
	static _create(e, t, n) {
		return new QueryLimitConstraint(e, t, n);
	}
	_apply(e) {
		return new Query(e.firestore, e.converter, __PRIVATE_queryWithLimit(e._query, this._limit, this._limitType));
	}
};
/**
* Creates a {@link QueryLimitConstraint} that only returns the first matching
* documents.
*
* @param limit - The maximum number of items to return.
* @returns The created {@link QueryLimitConstraint}.
*/ function limit(e) {
	return __PRIVATE_validatePositiveNumber("limit", e), QueryLimitConstraint._create("limit", e, "F");
}
function __PRIVATE_parseDocumentIdValue(e$1, t, n) {
	if ("string" == typeof (n = getModularInstance(n))) {
		if ("" === n) throw new e(ta.INVALID_ARGUMENT, "Invalid query. When querying with documentId(), you must provide a valid document ID, but it was an empty string.");
		if (!__PRIVATE_isCollectionGroupQuery(t) && -1 !== n.indexOf("/")) throw new e(ta.INVALID_ARGUMENT, `Invalid query. When querying a collection by documentId(), you must provide a plain document ID, but '${n}' contains a '/' character.`);
		const r = t.path.child(ResourcePath.fromString(n));
		if (!DocumentKey.isDocumentKey(r)) throw new e(ta.INVALID_ARGUMENT, `Invalid query. When querying a collection group by documentId(), the value provided must result in a valid document path, but '${r}' is not because it has an odd number of segments (${r.length}).`);
		return __PRIVATE_refValue(e$1, new DocumentKey(r));
	}
	if (n instanceof aa) return __PRIVATE_refValue(e$1, n._key);
	throw new e(ta.INVALID_ARGUMENT, `Invalid query. When querying with documentId(), you must provide a valid string or a DocumentReference, but it was: ${__PRIVATE_valueDescription(n)}.`);
}
/**
* Validates that the value passed into a disjunctive filter satisfies all
* array requirements.
*/ function __PRIVATE_validateDisjunctiveFilterElements(e$1, t) {
	if (!Array.isArray(e$1) || 0 === e$1.length) throw new e(ta.INVALID_ARGUMENT, `Invalid Query. A non-empty array is required for '${t.toString()}' filters.`);
}
function __PRIVATE_validateNewFieldFilter(e$1, t) {
	const n = function __PRIVATE_findOpInsideFilters(e, t) {
		for (const n of e) for (const e of n.getFlattenedFilters()) if (t.indexOf(e.op) >= 0) return e.op;
		return null;
	}(e$1.filters, function __PRIVATE_conflictingOps(e) {
		switch (e) {
			case "!=": return ["!=", "not-in"];
			case "array-contains-any":
			case "in": return ["not-in"];
			case "not-in": return [
				"array-contains-any",
				"in",
				"not-in",
				"!="
			];
			default: return [];
		}
	}(t.op));
	if (null !== n) throw n === t.op ? new e(ta.INVALID_ARGUMENT, `Invalid query. You cannot use more than one '${t.op.toString()}' filter.`) : new e(ta.INVALID_ARGUMENT, `Invalid query. You cannot use '${t.op.toString()}' filters with '${n.toString()}' filters.`);
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2023 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Reads the document referred to by this `DocumentReference`.
*
* Note: `getDoc()` attempts to provide up-to-date data when possible by waiting
* for data from the server, but it may return cached data or fail if you are
* offline and the server cannot be reached. To specify this behavior, invoke
* {@link getDocFromCache} or {@link getDocFromServer}.
*
* @param reference - The reference of the document to fetch.
* @returns A `Promise` that resolves with a `DocumentSnapshot` containing the
* document contents.
*/ function getDoc(e) {
	e = ra(e, aa);
	const t = ra(e.firestore, da);
	return __PRIVATE_firestoreClientGetDocumentViaSnapshotListener(oa(t), e._key).then(((n) => __PRIVATE_convertToDocSnapshot(t, e, n)));
}
function getDocs(e) {
	e = ra(e, Query);
	const t = ra(e.firestore, da), n = oa(t), r = new ua(t);
	return __PRIVATE_validateHasExplicitOrderByForLimitToLast(e._query), __PRIVATE_firestoreClientGetDocumentsViaSnapshotListener(n, e._query).then(((n) => new QuerySnapshot(t, r, e, n)));
}
function setDoc(e, t, n) {
	e = ra(e, aa);
	const r = ra(e.firestore, da), s = __PRIVATE_applyFirestoreDataConverter(e.converter, t, n);
	return executeWrite(r, [__PRIVATE_parseSetData(la(r), "setDoc", e._key, s, null !== e.converter, n).toMutation(e._key, Precondition.none())]);
}
/**
* Deletes the document referred to by the specified `DocumentReference`.
*
* Note that the returned `Promise` does _not_ resolve until the document is
* successfully deleted from the remote Firestore backend and, similarly, is not
* rejected until the remote Firestore backend reports an error deleting the given
* document. So if the client cannot reach the backend (for example, due to being
* offline) then the returned `Promise` will not resolve for a potentially-long
* time (for example, until the client has gone back online). That being said,
* the given data _will_ be immediately deleted from the local cache and will be
* reflected in future "get" operations as if it had been successfully
* deleted from the remote Firestore server, a feature of Firestore called
* "latency compensation". The document will _eventually_ be deleted from the remote
* Firestore backend once a connection can be established. Therefore, it is
* usually undesirable to `await` the `Promise` returned from this function
* because the indefinite amount of time before which the promise resolves or
* rejects can block application logic unnecessarily.
*
* @param reference - A reference to the document to delete.
* @returns A `Promise` that resolves once the document has been successfully
* deleted from the backend or rejects once the backend reports an error
* deleting the document.
*/ function deleteDoc(e) {
	return executeWrite(ra(e.firestore, da), [new __PRIVATE_DeleteMutation(e._key, Precondition.none())]);
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Locally writes `mutations` on the async queue.
* @internal
*/ function executeWrite(e, t) {
	return __PRIVATE_firestoreClientWrite(oa(e), t);
}
/**
* Converts a {@link ViewSnapshot} that contains the single document specified by `ref`
* to a {@link DocumentSnapshot}.
*/ function __PRIVATE_convertToDocSnapshot(e, t, n) {
	const r = n.docs.get(t._key);
	return new DocumentSnapshot(e, new ua(e), t._key, r, new SnapshotMetadata(n.hasPendingWrites, n.fromCache), t.converter);
}
/**
* @license
* Copyright 2021 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2023 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2023 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var Me = "@firebase/firestore";
var Le = "4.18.0";
/**
* Cloud Firestore
*
* @packageDocumentation
*/
(function __PRIVATE_registerFirestore(s, a = true) {
	/**
	* @license
	* Copyright 2020 Google LLC
	*
	* Licensed under the Apache License, Version 2.0 (the "License");
	* you may not use this file except in compliance with the License.
	* You may obtain a copy of the License at
	*
	*   http://www.apache.org/licenses/LICENSE-2.0
	*
	* Unless required by applicable law or agreed to in writing, software
	* distributed under the License is distributed on an "AS IS" BASIS,
	* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	* See the License for the specific language governing permissions and
	* limitations under the License.
	*/
	__PRIVATE_setSDKVersion(SDK_VERSION), _registerComponent(new Component("firestore", ((e, { instanceIdentifier: t, options: n }) => {
		const r = e.getProvider("app").getImmediate(), s = new da(new __PRIVATE_FirebaseAuthCredentialsProvider(e.getProvider("auth-internal")), new __PRIVATE_FirebaseAppCheckTokenProvider(r, e.getProvider("app-check-internal")), __PRIVATE_databaseIdFromApp(r, t), r);
		return n = {
			useFetchStreams: a,
			...n
		}, s._setSettings(n), s;
	}), "PUBLIC").setMultipleInstances(true)), registerVersion(Me, Le, s), registerVersion(Me, Le, "esm2020");
})();
//#endregion
export { orderBy as a, where as c, getFirestore as d, initializeFirestore as f, limit as i, collection as l, getDoc as n, query as o, setLogLevel as p, getDocs as r, setDoc as s, deleteDoc as t, doc as u };
