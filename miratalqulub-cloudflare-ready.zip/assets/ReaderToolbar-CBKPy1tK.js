import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { Et as Layers, I as Share2, K as RotateCcw, S as Sun, Wt as FileText, bn as Check, ht as Maximize2, rn as Copy, st as Moon } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import { d as useAppTheme, l as useLanguage } from "./index-C5uCeetQ.js";
//#region src/components/ReaderToolbar.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var ReaderToolbar = ({ isLight: isLightProp, language: languageProp, fontSize, onChangeFontSize, onToggleTheme: onToggleThemeProp, shareTitle, shareSummary, shareUrl, viewMode = "segmented_and_continuous", onChangeViewMode, onJumpToContinuous, onOpenFullScreen, contentTypeLabelAr = "البحث / القصة", contentTypeLabelEn = "Paper / Story" }) => {
	const { language: ctxLanguage } = useLanguage();
	const [ctxTheme, ctxToggleTheme] = useAppTheme();
	const language = languageProp ?? ctxLanguage;
	const isLight = isLightProp ?? ctxTheme === "light";
	const onToggleTheme = onToggleThemeProp ?? ctxToggleTheme;
	const [showSocialMenu, setShowSocialMenu] = (0, import_react.useState)(false);
	const [copiedLink, setCopiedLink] = (0, import_react.useState)(false);
	const isAr = language === "ar";
	const currentUrl = shareUrl || (typeof window !== "undefined" ? window.location.href : "https://miratalqulub.com/#/articles");
	const fullShareText = `📖 ${shareTitle}\n\n${shareSummary.slice(0, 220)}...\n\n🔗 ${currentUrl}`;
	const encodedText = encodeURIComponent(fullShareText);
	const encodedUrl = encodeURIComponent(currentUrl);
	const encodedTitle = encodeURIComponent(`📖 ${shareTitle} — ${shareSummary.slice(0, 140)}...`);
	const handleCopyShare = () => {
		soundManager.playTap();
		if (navigator.clipboard) {
			navigator.clipboard.writeText(fullShareText);
			setCopiedLink(true);
			setTimeout(() => setCopiedLink(false), 2400);
		}
	};
	const pct = Math.round(fontSize / 16 * 100);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `sticky top-2 z-30 p-3 sm:p-4 rounded-2xl border backdrop-blur-md shadow-lg space-y-2.5 transition-colors ${isLight ? "bg-white/95 border-indigo-200 text-slate-800 shadow-slate-200/70" : "bg-slate-900/95 border-cyan-500/35 text-gray-100 shadow-black/50"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center justify-between gap-2.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-1.5",
				children: [onChangeViewMode && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `inline-flex items-center p-1 rounded-xl border ${isLight ? "bg-slate-100 border-slate-200" : "bg-black/40 border-white/10"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							soundManager.playTap();
							onChangeViewMode("continuous_only");
						},
						className: `px-3 py-1.5 rounded-lg text-xs font-extrabold flex items-center gap-1.5 transition cursor-pointer ${viewMode === "continuous_only" ? "bg-gradient-to-r from-indigo-600 to-cyan-600 text-white shadow-sm" : isLight ? "text-slate-700 hover:bg-white" : "text-gray-300 hover:bg-white/10"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? `📜 قراءة ${contentTypeLabelAr} كاملة دون تجزئة` : `📜 Read Full ${contentTypeLabelEn} Unsegmented` })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							soundManager.playTap();
							onChangeViewMode("segmented_and_continuous");
						},
						className: `px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition cursor-pointer ${viewMode === "segmented_and_continuous" ? "bg-gradient-to-r from-purple-600 to-rose-600 text-white shadow-sm" : isLight ? "text-slate-700 hover:bg-white" : "text-gray-300 hover:bg-white/10"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "📑 العرض المنهجي + النص الكامل" : "📑 Structured + Full Text" })]
					})]
				}), viewMode === "segmented_and_continuous" && onJumpToContinuous && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						soundManager.playTap();
						onJumpToContinuous();
					},
					className: `px-2.5 py-1.5 rounded-xl text-[11px] font-bold border transition cursor-pointer ${isLight ? "bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border-indigo-200" : "bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-200 border-cyan-500/30"}`,
					children: isAr ? "⬇ الانتقال للنص الكامل المتواصل بالأسفل" : "⬇ Jump to Full Continuous Text"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl border ${isLight ? "bg-slate-100 border-slate-200" : "bg-black/40 border-white/15"}`,
						title: isAr ? "التحكم في حجم الخط" : "Font Size Control",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] font-bold px-0.5 opacity-75 hidden sm:inline",
								children: isAr ? "حجم الخط:" : "Font:"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									soundManager.playTap();
									onChangeFontSize(Math.max(13, fontSize - 2));
								},
								className: `px-2 py-0.5 rounded-lg text-xs font-black transition cursor-pointer ${isLight ? "hover:bg-white text-slate-800" : "hover:bg-white/15 text-white"}`,
								title: isAr ? "تصغير الخط" : "Decrease Font Size",
								children: "A-"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "range",
								min: 13,
								max: 28,
								step: 1,
								value: fontSize,
								onChange: (e) => onChangeFontSize(Number(e.target.value)),
								className: "w-16 sm:w-20 accent-indigo-600 cursor-pointer hidden md:inline-block",
								"aria-label": isAr ? "شريط التحكم بحجم الخط" : "Font Size Slider"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-[11px] font-mono tabular-nums font-bold px-1 text-indigo-600 dark:text-cyan-300",
								children: [pct, "%"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									soundManager.playTap();
									onChangeFontSize(Math.min(28, fontSize + 2));
								},
								className: `px-2 py-0.5 rounded-lg text-xs font-black transition cursor-pointer ${isLight ? "hover:bg-white text-slate-800" : "hover:bg-white/15 text-white"}`,
								title: isAr ? "تكبير الخط" : "Increase Font Size",
								children: "A+"
							}),
							fontSize !== 17 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									soundManager.playTap();
									onChangeFontSize(17);
								},
								className: "p-1 rounded-lg opacity-70 hover:opacity-100 cursor-pointer",
								title: isAr ? "إعادة ضبط حجم الخط" : "Reset Font Size",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "w-3 h-3" })
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							soundManager.playTap();
							onToggleTheme();
						},
						className: `px-3 py-1.5 rounded-xl text-xs font-extrabold border flex items-center gap-1.5 transition cursor-pointer ${isLight ? "bg-amber-50 hover:bg-amber-100 text-amber-900 border-amber-300" : "bg-indigo-950/70 hover:bg-indigo-900/80 text-amber-300 border-amber-400/30"}`,
						title: isAr ? "تبديل الوضع الليلي / النهاري" : "Toggle Dark / Light Mode",
						children: [isLight ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "w-3.5 h-3.5 text-indigo-700" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "w-3.5 h-3.5 text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isLight ? isAr ? "الوضع الليلي" : "Dark Mode" : isAr ? "الوضع النهاري" : "Light Mode" })]
					}),
					onOpenFullScreen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							soundManager.playTap();
							onOpenFullScreen();
						},
						className: "px-3 py-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white text-xs font-extrabold flex items-center gap-1.5 shadow-sm transition cursor-pointer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "ملء الشاشة" : "Full Screen" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							soundManager.playTap();
							setShowSocialMenu((prev) => !prev);
						},
						className: "px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-extrabold flex items-center gap-1.5 shadow-sm transition cursor-pointer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "مشاركة عبر التواصل الاجتماعي" : "Share on Social Media" })]
					})
				]
			})]
		}), showSocialMenu && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: `pt-2.5 border-t flex flex-wrap items-center justify-between gap-2 text-xs ${isLight ? "border-slate-200" : "border-white/10"}`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-bold opacity-80",
				children: isAr ? "اختر منصة المشاركة المباشرة:" : "Share directly via:"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: `https://api.whatsapp.com/send?text=${encodedText}`,
						target: "_blank",
						rel: "noopener noreferrer",
						onClick: () => soundManager.playTap(),
						className: "px-3 py-1.5 rounded-xl bg-[#25D366]/15 hover:bg-[#25D366]/25 text-emerald-700 dark:text-emerald-300 border border-[#25D366]/40 font-extrabold flex items-center gap-1.5 transition",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "💬" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "واتساب (WhatsApp)" : "WhatsApp" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: `https://twitter.com/intent/tweet?text=${encodedTitle}&url=${encodedUrl}`,
						target: "_blank",
						rel: "noopener noreferrer",
						onClick: () => soundManager.playTap(),
						className: `px-3 py-1.5 rounded-xl border font-extrabold flex items-center gap-1.5 transition ${isLight ? "bg-slate-100 hover:bg-slate-200 text-slate-900 border-slate-300" : "bg-white/10 hover:bg-white/20 text-white border-white/20"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "𝕏" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "منصة إكس (X)" : "X (Twitter)" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: `https://t.me/share/url?url=${encodedUrl}&text=${encodedTitle}`,
						target: "_blank",
						rel: "noopener noreferrer",
						onClick: () => soundManager.playTap(),
						className: "px-3 py-1.5 rounded-xl bg-sky-500/15 hover:bg-sky-500/25 text-sky-700 dark:text-sky-300 border border-sky-500/40 font-extrabold flex items-center gap-1.5 transition",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "✈️" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "تيليجرام (Telegram)" : "Telegram" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`,
						target: "_blank",
						rel: "noopener noreferrer",
						onClick: () => soundManager.playTap(),
						className: "px-3 py-1.5 rounded-xl bg-blue-600/15 hover:bg-blue-600/25 text-blue-700 dark:text-blue-300 border border-blue-500/40 font-extrabold flex items-center gap-1.5 transition",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "📘" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "فيسبوك (Facebook)" : "Facebook" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`,
						target: "_blank",
						rel: "noopener noreferrer",
						onClick: () => soundManager.playTap(),
						className: "px-3 py-1.5 rounded-xl bg-indigo-600/15 hover:bg-indigo-600/25 text-indigo-700 dark:text-indigo-300 border border-indigo-500/40 font-extrabold flex items-center gap-1.5 transition",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "💼" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "لينكدإن (LinkedIn)" : "LinkedIn" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: handleCopyShare,
						className: "px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold flex items-center gap-1.5 transition cursor-pointer",
						children: [copiedLink ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: copiedLink ? isAr ? "تم نسخ الرابط والنص!" : "Link & Text Copied!" : isAr ? "نسخ الرابط والمقتطف" : "Copy Link & Excerpt" })]
					})
				]
			})]
		})]
	});
};
function renderFormattedInline(line, isLight) {
	return line.split(/(\*\*[^*]+\*\*|\*"[^"]+"\*\|\[\[[^\]]+\]\]|\[\d+(?:,\s*\d+)*\])/g).map((part, idx) => {
		if (part.startsWith("**") && part.endsWith("**")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
			className: `font-extrabold ${isLight ? "text-slate-900" : "text-white"}`,
			children: part.slice(2, -2)
		}, idx);
		if (part.startsWith("[[") && part.endsWith("]]") || /^\[\d+(?:,\s*\d+)*\]$/.test(part)) {
			const cleanRef = part.replace(/^\[+|\]+$/g, "");
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: `inline-block px-1.5 py-0.2 mx-0.5 rounded text-[0.82em] font-mono font-bold ${isLight ? "bg-indigo-100 text-indigo-800 border border-indigo-200" : "bg-cyan-500/15 text-cyan-300 border border-cyan-500/30"}`,
				children: [
					"[",
					cleanRef,
					"]"
				]
			}, idx);
		}
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Fragment, { children: part }, idx);
	});
}
var FormattedContinuousManuscript = ({ text, fontSize, isLight }) => {
	const lines = text.split("\n");
	const elements = [];
	let i = 0;
	while (i < lines.length) {
		const trimmed = lines[i].trim();
		if (!trimmed) {
			i++;
			continue;
		}
		if (trimmed.startsWith("|") && trimmed.endsWith("|")) {
			const tableLines = [];
			while (i < lines.length && lines[i].trim().startsWith("|")) {
				tableLines.push(lines[i].trim());
				i++;
			}
			const parsedRows = tableLines.filter((tl) => !/^\|[\s\-:|]+\|$/.test(tl)).map((tl) => tl.slice(1, -1).split("|").map((cell) => cell.trim()));
			if (parsedRows.length > 0) {
				const headers = parsedRows[0];
				const bodyRows = parsedRows.slice(1);
				elements.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `my-6 rounded-2xl border overflow-x-auto ${isLight ? "border-indigo-200 bg-indigo-50/30" : "border-cyan-500/30 bg-slate-900/60"}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-xs sm:text-sm border-collapse",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
							className: isLight ? "bg-indigo-100/90 text-indigo-950 border-b border-indigo-200" : "bg-cyan-950/60 text-cyan-200 border-b border-cyan-500/30",
							children: headers.map((h, hIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "p-3 text-start font-extrabold",
								children: renderFormattedInline(h, isLight)
							}, hIdx))
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: bodyRows.map((r, rIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
							className: `border-b ${isLight ? "border-indigo-100 bg-white/90 hover:bg-indigo-50/40" : "border-white/10 bg-black/20 hover:bg-white/[0.03]"}`,
							children: r.map((c, cIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: `p-3 leading-relaxed ${cIdx === 0 ? "font-bold text-indigo-700 dark:text-cyan-300" : ""}`,
								children: renderFormattedInline(c, isLight)
							}, cIdx))
						}, rIdx)) })]
					})
				}, `tbl-${i}`));
			}
			continue;
		}
		if (trimmed === "---" || trimmed.startsWith("────────")) {
			elements.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hr", { className: `my-7 border-t-2 ${isLight ? "border-indigo-200/80" : "border-white/15"}` }, `hr-${i}`));
			i++;
			continue;
		}
		if (trimmed.startsWith("# ")) {
			elements.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: `font-black font-['Alexandria'] mt-6 mb-4 pb-3 border-b ${isLight ? "text-indigo-950 border-indigo-200" : "text-white border-cyan-500/30"}`,
				style: {
					fontSize: `${Math.round(fontSize * 1.45)}px`,
					lineHeight: 1.4
				},
				children: trimmed.replace(/^#\s+/, "")
			}, `h1-${i}`));
			i++;
			continue;
		}
		if (trimmed.startsWith("## ")) {
			elements.push(/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
				className: `font-black font-['Alexandria'] mt-8 mb-3 flex items-center gap-2 ${isLight ? "text-indigo-800" : "text-cyan-300"}`,
				style: {
					fontSize: `${Math.round(fontSize * 1.25)}px`,
					lineHeight: 1.45
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-2.5 h-2.5 rounded-full bg-indigo-500 dark:bg-cyan-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: trimmed.replace(/^##\s+/, "") })]
			}, `h2-${i}`));
			i++;
			continue;
		}
		if (trimmed.startsWith("### ")) {
			elements.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
				className: `font-extrabold font-['Alexandria'] mt-6 mb-2 ${isLight ? "text-rose-800" : "text-rose-300"}`,
				style: {
					fontSize: `${Math.round(fontSize * 1.12)}px`,
					lineHeight: 1.5
				},
				children: trimmed.replace(/^###\s+/, "")
			}, `h3-${i}`));
			i++;
			continue;
		}
		if (trimmed.startsWith(">") || trimmed.startsWith("*\"") && trimmed.endsWith("\"*")) {
			const cleanQuote = trimmed.replace(/^>\s*/, "");
			elements.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
				className: `my-4 p-4 rounded-2xl border-s-4 border-rose-500 italic font-medium ${isLight ? "bg-rose-50/70 text-slate-800 border border-rose-200" : "bg-rose-950/25 text-rose-100 border border-rose-500/20"}`,
				style: {
					fontSize: `${fontSize}px`,
					lineHeight: 1.9
				},
				children: renderFormattedInline(cleanQuote, isLight)
			}, `q-${i}`));
			i++;
			continue;
		}
		if (/^(\*|-|•|\d+\.)\s+/.test(trimmed)) {
			elements.push(/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "my-2 flex items-start gap-2.5 ps-2",
				style: {
					fontSize: `${fontSize}px`,
					lineHeight: 1.9
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-indigo-600 dark:text-cyan-400 font-bold shrink-0 mt-0.5",
					children: trimmed.match(/^(\d+\.)/) ? trimmed.match(/^(\d+\.)/)[1] : "•"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex-1",
					children: renderFormattedInline(trimmed.replace(/^(\*|-|•|\d+\.)\s+/, ""), isLight)
				})]
			}, `li-${i}`));
			i++;
			continue;
		}
		elements.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "my-3.5 leading-loose",
			style: {
				fontSize: `${fontSize}px`,
				lineHeight: 1.95
			},
			children: renderFormattedInline(trimmed, isLight)
		}, `p-${i}`));
		i++;
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-1",
		children: elements
	});
};
//#endregion
export { ReaderToolbar as n, FormattedContinuousManuscript as t };
