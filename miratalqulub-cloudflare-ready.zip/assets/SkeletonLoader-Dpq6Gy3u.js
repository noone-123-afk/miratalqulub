import "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
require_react();
var import_jsx_runtime = require_jsx_runtime();
var SkeletonLoader = ({ type = "history_card", count = 3 }) => {
	const items = Array.from({ length: count });
	if (type === "history_card") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-3 w-full",
		dir: "rtl",
		children: items.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "p-4 sm:p-5 rounded-2xl bg-slate-900/90 border border-slate-800 animate-pulse space-y-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-10 h-10 rounded-xl bg-slate-800" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-36 h-4 bg-slate-800 rounded-md" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-24 h-3 bg-slate-800/60 rounded-md" })]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-16 h-7 bg-slate-800 rounded-xl" })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2 pt-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-20 h-5 bg-slate-800/70 rounded-lg" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-24 h-5 bg-slate-800/70 rounded-lg" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-16 h-5 bg-slate-800/70 rounded-lg" })
				]
			})]
		}, i))
	});
	if (type === "profile_stats") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 sm:grid-cols-4 gap-3 w-full animate-pulse",
		dir: "rtl",
		children: Array.from({ length: 4 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-8 h-8 rounded-lg bg-slate-800" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-16 h-5 bg-slate-800 rounded-md" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-24 h-3 bg-slate-800/60 rounded-md" })
			]
		}, i))
	});
	if (type === "chart") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-6 rounded-3xl bg-slate-900/90 border border-slate-800 animate-pulse space-y-4 w-full",
		dir: "rtl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-40 h-5 bg-slate-800 rounded-md" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "w-full h-48 bg-slate-800/40 rounded-2xl flex items-center justify-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-32 h-32 rounded-full border-4 border-slate-800 border-dashed" })
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-5 rounded-2xl bg-slate-900/90 border border-slate-800 animate-pulse space-y-3 w-full",
		dir: "rtl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-48 h-5 bg-slate-800 rounded-md" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-full h-3 bg-slate-800/60 rounded-md" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-3/4 h-3 bg-slate-800/60 rounded-md" })
		]
	});
};
//#endregion
export { SkeletonLoader as t };
