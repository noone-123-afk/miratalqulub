import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { An as BookOpen, B as Send, D as Sparkles, L as Settings, On as Bookmark, P as ShieldCheck, Sn as Calendar, Y as Radio, cn as Clock, ft as MessageCircle, h as Trash2, mn as CircleCheck, r as X, s as Users } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import { d as useAppTheme, l as useLanguage, u as useAuth } from "./index-C5uCeetQ.js";
import { n as AnimatePresence, t as motion } from "./vendor-motion-BS7ODJw7.js";
import { t as db } from "./firebase-Cu7XUsbK.js";
import { a as orderBy, i as limit, l as collection, n as getDoc, o as query, r as getDocs, s as setDoc, t as deleteDoc, u as doc } from "./vendor-firebase-firestore-nFD0fmjQ.js";
//#region src/services/bookClubService.ts
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var LOCAL_STORAGE_SESSION_KEY = "mirat_book_club_session_v1";
var LOCAL_STORAGE_MESSAGES_KEY = "mirat_book_club_messages_v1";
var DEFAULT_BOOK_SESSION = {
	id: "current_week_session",
	bookTitleAr: "الذكاء العاطفي في العلاقات الإنسانية",
	bookTitleEn: "Emotional Intelligence in Human Relationships",
	authorAr: "د. دانييل غولمان (تحليل ونقاش تطبيقي)",
	authorEn: "Dr. Daniel Goleman (Applied Discussion)",
	coverImage: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80",
	descriptionAr: "يناقش الصالون هذا الأسبوع كيف يؤثر الوعي بالمشاعر والتعاطف والتنظيم الانفعالي على نجاح العلاقات الزوجية والاجتماعية وتجاوز الخلافات بحكمة.",
	descriptionEn: "This week the salon explores how emotional awareness, empathy, and affective regulation elevate marital and personal relationships and resolve conflicts constructively.",
	sessionDate: "2026-11-20",
	sessionTimeAr: "الجمعة القادمة • 8:00 مساءً (بتوقيت مكة المكرمة)",
	sessionTimeEn: "Upcoming Friday • 8:00 PM (Mecca Time)",
	status: "scheduled",
	objectivesAr: [
		"فهم الأنماط الانفعالية الأربعة في إدارة الغضب أثناء الخلاف.",
		"التفريق بين التعاطف المعرفي والتعاطف الوجداني مع الشريك.",
		"خطوات عملية لبناء المرونة العاطفية في مواجهة الضغوط اليومية.",
		"تبادل التجارب الواقعية حول تطبيق الاستبصار الذاتي في التواصل."
	],
	objectivesEn: [
		"Understanding 4 affective patterns in managing conflict and anger.",
		"Distinguishing cognitive empathy from affective empathy with partners.",
		"Actionable steps to build emotional agility under daily stress.",
		"Sharing real-world reflections on mindful interpersonal dialogue."
	],
	updatedAt: (/* @__PURE__ */ new Date()).toISOString()
};
var DEFAULT_CHAT_MESSAGES = [
	{
		id: "msg-welcome-admin",
		senderName: "إدارة مرآة القلوب",
		senderRole: "admin",
		text: "أهلاً بكم في صالون القراءة والنقاش الأسبوعي. نلتقي كل أسبوع لمناقشة كتاب هادف في بيئة تسودها الخصوصية والرقي الفكري. يمكنكم مشاركة آرائكم وطرح أسئلتكم حول كتاب هذا الأسبوع.",
		createdAt: (/* @__PURE__ */ new Date(Date.now() - 864e5)).toISOString(),
		likes: 8
	},
	{
		id: "msg-reader-1",
		senderName: "سارة م.",
		senderRole: "reader",
		text: "فصل «الوعي بالذات» في الكتاب كان ملهماً جداً، خصوصاً فكرة التوقف لثوانٍ قبل الرد في لحظات الانفعال!",
		createdAt: (/* @__PURE__ */ new Date(Date.now() - 432e5)).toISOString(),
		likes: 5
	},
	{
		id: "msg-reader-2",
		senderName: "عمر القحطاني",
		senderRole: "reader",
		text: "أعجبني تطبيق الكاتب لمفهوم التعاطف الوجداني، بانتظار موعد النقاش المباشر يوم الجمعة بإذن الله.",
		createdAt: (/* @__PURE__ */ new Date(Date.now() - 108e5)).toISOString(),
		likes: 3
	}
];
async function fetchCurrentBookSession() {
	try {
		const sessionRef = doc(db, "site_config", "book_club_session");
		const snap = await getDoc(sessionRef);
		if (snap.exists()) {
			const data = snap.data();
			localStorage.setItem(LOCAL_STORAGE_SESSION_KEY, JSON.stringify(data));
			return data;
		}
	} catch (err) {
		console.warn("Could not fetch book club session from Firestore, checking localStorage", err);
	}
	const cached = localStorage.getItem(LOCAL_STORAGE_SESSION_KEY);
	if (cached) try {
		return JSON.parse(cached);
	} catch {}
	return DEFAULT_BOOK_SESSION;
}
async function saveBookSession(session) {
	const updated = {
		...session,
		updatedAt: (/* @__PURE__ */ new Date()).toISOString()
	};
	localStorage.setItem(LOCAL_STORAGE_SESSION_KEY, JSON.stringify(updated));
	try {
		const sessionRef = doc(db, "site_config", "book_club_session");
		await setDoc(sessionRef, updated, { merge: true });
	} catch (err) {
		console.warn("Could not sync book club session to Firestore", err);
	}
}
async function fetchBookClubMessages() {
	try {
		const colRef = collection(db, "site_config", "book_club_session", "messages");
		const q = query(colRef, orderBy("createdAt", "asc"), limit(100));
		const snap = await getDocs(q);
		if (!snap.empty) {
			const msgs = snap.docs.map((d) => ({
				id: d.id,
				...d.data()
			}));
			localStorage.setItem(LOCAL_STORAGE_MESSAGES_KEY, JSON.stringify(msgs));
			return msgs;
		}
	} catch (err) {
		console.warn("Could not fetch book club messages from Firestore, checking localStorage", err);
	}
	const cached = localStorage.getItem(LOCAL_STORAGE_MESSAGES_KEY);
	if (cached) try {
		return JSON.parse(cached);
	} catch {}
	return DEFAULT_CHAT_MESSAGES;
}
async function postBookClubMessage(message) {
	const newMsg = {
		...message,
		id: "msg-" + Date.now() + "-" + Math.random().toString(36).substring(2, 7)
	};
	const updated = [...await fetchBookClubMessages(), newMsg];
	localStorage.setItem(LOCAL_STORAGE_MESSAGES_KEY, JSON.stringify(updated));
	try {
		const colRef = collection(db, "site_config", "book_club_session", "messages");
		await setDoc(doc(colRef, newMsg.id), newMsg);
	} catch (err) {
		console.warn("Could not post message to Firestore", err);
	}
	return newMsg;
}
async function deleteBookClubMessage(messageId) {
	const filtered = (await fetchBookClubMessages()).filter((m) => m.id !== messageId);
	localStorage.setItem(LOCAL_STORAGE_MESSAGES_KEY, JSON.stringify(filtered));
	try {
		const msgRef = doc(db, "site_config", "book_club_session", "messages", messageId);
		await deleteDoc(msgRef);
	} catch (err) {
		console.warn("Could not delete message from Firestore", err);
	}
}
//#endregion
//#region src/components/BookClubCommunityModal.tsx
var import_jsx_runtime = require_jsx_runtime();
var BookClubCommunityModal = ({ isOpen, onClose }) => {
	const { language, isRTL } = useLanguage();
	const isAr = language === "ar";
	const { user, isOwner } = useAuth();
	const [theme] = useAppTheme();
	const isLight = theme === "light";
	const [activeTab, setActiveTab] = (0, import_react.useState)("chat");
	const [session, setSession] = (0, import_react.useState)(DEFAULT_BOOK_SESSION);
	const [messages, setMessages] = (0, import_react.useState)([]);
	const [senderName, setSenderName] = (0, import_react.useState)(() => {
		return localStorage.getItem("mirat_chat_username") || user?.displayName || "";
	});
	const [inputText, setInputText] = (0, import_react.useState)("");
	const [isSending, setIsSending] = (0, import_react.useState)(false);
	const [saveSuccess, setSaveSuccess] = (0, import_react.useState)(false);
	const [adminForm, setAdminForm] = (0, import_react.useState)(DEFAULT_BOOK_SESSION);
	const [objectivesTextAr, setObjectivesTextAr] = (0, import_react.useState)("");
	const [objectivesTextEn, setObjectivesTextEn] = (0, import_react.useState)("");
	const messagesEndRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (isOpen) loadData();
	}, [isOpen]);
	const loadData = async () => {
		const s = await fetchCurrentBookSession();
		setSession(s);
		setAdminForm(s);
		setObjectivesTextAr(s.objectivesAr.join("\n"));
		setObjectivesTextEn(s.objectivesEn.join("\n"));
		const msgs = await fetchBookClubMessages();
		setMessages(msgs);
	};
	(0, import_react.useEffect)(() => {
		if (activeTab === "chat") messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
	}, [messages, activeTab]);
	const handleSendMessage = async (e) => {
		if (e) e.preventDefault();
		if (!inputText.trim()) return;
		soundManager.playTap();
		setIsSending(true);
		const effectiveName = senderName.trim() || (isAr ? "قارئ مهتم" : "Mindful Reader");
		localStorage.setItem("mirat_chat_username", effectiveName);
		const newMsg = await postBookClubMessage({
			senderName: effectiveName,
			senderRole: isOwner ? "admin" : "reader",
			text: inputText.trim(),
			createdAt: (/* @__PURE__ */ new Date()).toISOString(),
			likes: 0
		});
		setMessages((prev) => [...prev, newMsg]);
		setInputText("");
		setIsSending(false);
		soundManager.playTap();
	};
	const handleDeleteMessage = async (msgId) => {
		soundManager.playTap();
		await deleteBookClubMessage(msgId);
		setMessages((prev) => prev.filter((m) => m.id !== msgId));
	};
	const handleSaveAdminSession = async (e) => {
		e.preventDefault();
		soundManager.playTap();
		const objAr = objectivesTextAr.split("\n").map((s) => s.trim()).filter(Boolean);
		const objEn = objectivesTextEn.split("\n").map((s) => s.trim()).filter(Boolean);
		const updated = {
			...adminForm,
			objectivesAr: objAr.length > 0 ? objAr : adminForm.objectivesAr,
			objectivesEn: objEn.length > 0 ? objEn : adminForm.objectivesEn,
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		await saveBookSession(updated);
		setSession(updated);
		setSaveSuccess(true);
		soundManager.playTap();
		setTimeout(() => {
			setSaveSuccess(false);
			setActiveTab("chat");
		}, 1500);
	};
	if (!isOpen) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto bg-black/75 backdrop-blur-md",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: {
				opacity: 0,
				scale: .95,
				y: 15
			},
			animate: {
				opacity: 1,
				scale: 1,
				y: 0
			},
			exit: {
				opacity: 0,
				scale: .95,
				y: 15
			},
			transition: { duration: .25 },
			dir: isRTL ? "rtl" : "ltr",
			className: `relative w-full max-w-4xl max-h-[92vh] flex flex-col rounded-3xl border shadow-2xl overflow-hidden transition-colors ${isLight ? "bg-white border-slate-200 text-slate-800" : "bg-slate-900 border-white/10 text-white"}`,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `p-4 sm:p-6 border-b flex items-center justify-between gap-4 shrink-0 ${isLight ? "border-slate-100 bg-slate-50/80" : "border-white/5 bg-slate-950/40"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-500 via-pink-500 to-rose-500 text-white flex items-center justify-center shadow-lg shadow-purple-500/20 shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "w-6 h-6" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-lg sm:text-xl font-black font-['Alexandria']",
								children: isAr ? "المجتمع والتفاعل • صالون كتاب الأسبوع" : "Community • Weekly Book Club"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: `inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-extrabold border ${session.status === "live" ? "bg-rose-500/15 border-rose-500/30 text-rose-500 animate-pulse" : "bg-emerald-500/15 border-emerald-500/30 text-emerald-500"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "w-3 h-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: session.status === "live" ? isAr ? "الصالون مباشر الآن" : "Live Session" : isAr ? "جلسة أسبوعية مجدولة" : "Scheduled Session" })]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: `text-xs mt-0.5 ${isLight ? "text-slate-500" : "text-slate-400"}`,
							children: isAr ? "مساحة راقية للحوار وتبادل الخبرات ومناقشة كتاب أسبوعي محدد" : "A respectful sanctuary for purposeful dialogue and weekly book discussion"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							soundManager.playTap();
							onClose();
						},
						className: `w-9 h-9 rounded-xl flex items-center justify-center transition cursor-pointer shrink-0 ${isLight ? "bg-slate-200 hover:bg-slate-300 text-slate-700" : "bg-white/10 hover:bg-white/15 text-white"}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-4 h-4" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `px-4 sm:px-6 py-3 border-b flex flex-wrap items-center justify-between gap-3 text-xs shrink-0 ${isLight ? "bg-gradient-to-r from-purple-50 via-pink-50 to-amber-50/50 border-purple-100 text-purple-950" : "bg-gradient-to-r from-purple-950/40 via-pink-950/30 to-slate-900 border-white/5 text-purple-200"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "w-4 h-4 text-purple-500 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-bold",
							children: [
								isAr ? "كتاب الأسبوع:" : "Book of the Week:",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-black text-purple-600 dark:text-purple-300",
									children: isAr ? session.bookTitleAr : session.bookTitleEn
								}),
								" ",
								"— (",
								isAr ? session.authorAr : session.authorEn,
								")"
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center gap-3 font-semibold text-[11px]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "w-3.5 h-3.5 text-pink-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? session.sessionTimeAr : session.sessionTimeEn })]
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `px-4 sm:px-6 pt-3 border-b flex items-center justify-between gap-2 shrink-0 ${isLight ? "border-slate-100" : "border-white/5"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								soundManager.playTap();
								setActiveTab("chat");
							},
							className: `pb-2.5 px-3 text-xs font-black font-['Alexandria'] border-b-2 transition cursor-pointer flex items-center gap-1.5 ${activeTab === "chat" ? "border-purple-500 text-purple-500" : isLight ? "border-transparent text-slate-500 hover:text-slate-800" : "border-transparent text-slate-400 hover:text-white"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "w-4 h-4" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "غرفة الحوار والدردشة" : "Discussion Room" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "px-1.5 py-0.2 rounded-full text-[10px] bg-purple-500/10 text-purple-500",
									children: messages.length
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								soundManager.playTap();
								setActiveTab("book");
							},
							className: `pb-2.5 px-3 text-xs font-black font-['Alexandria'] border-b-2 transition cursor-pointer flex items-center gap-1.5 ${activeTab === "book" ? "border-purple-500 text-purple-500" : isLight ? "border-transparent text-slate-500 hover:text-slate-800" : "border-transparent text-slate-400 hover:text-white"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "تفاصيل الكتاب وغايات النقاش" : "Book & Goals" })]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							soundManager.playTap();
							setActiveTab(activeTab === "admin" ? "chat" : "admin");
						},
						className: `pb-2.5 px-3 text-xs font-bold transition cursor-pointer flex items-center gap-1 ${activeTab === "admin" ? "text-amber-500 border-b-2 border-amber-500" : "text-slate-400 hover:text-amber-400"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "إدارة الجلسة والكتاب" : "Manage Session" })]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 overflow-y-auto p-4 sm:p-6 space-y-4",
					children: [
						activeTab === "chat" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col h-full space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `p-3.5 rounded-2xl border text-xs flex items-start gap-3 ${isLight ? "bg-indigo-50/70 border-indigo-100 text-indigo-950" : "bg-indigo-950/25 border-indigo-500/20 text-indigo-200"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "w-4 h-4 text-indigo-500 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-0.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-extrabold block",
											children: isAr ? "ميثاق صالون مرآة القلوب الحواري:" : "Mirror of Hearts Salon Guidelines:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: `text-[11px] leading-relaxed ${isLight ? "text-indigo-900/80" : "text-indigo-300"}`,
											children: isAr ? "مساحة تحترم الخصوصية والتعددية الفكرية. يُرجى التركيز على أفكار الكتاب والتجارب الإنسانية الهادفة، وتجنب أي لغة غير لائقة أو إعلانات تجارية." : "A safe space respecting privacy and diverse perspectives. Please focus on book insights and constructive personal reflections."
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-3 min-h-[260px] max-h-[380px] overflow-y-auto pr-1",
									children: [messages.map((msg) => {
										const isAdmin = msg.senderRole === "admin";
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: `p-4 rounded-2xl border transition-all ${isAdmin ? isLight ? "bg-purple-50/90 border-purple-200 text-purple-950" : "bg-purple-950/30 border-purple-500/30 text-purple-100" : isLight ? "bg-slate-50 border-slate-200/80 text-slate-800" : "bg-white/[0.03] border-white/10 text-slate-200"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between gap-2 mb-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-2",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: `w-7 h-7 rounded-lg flex items-center justify-center font-black text-xs ${isAdmin ? "bg-purple-600 text-white" : isLight ? "bg-slate-200 text-slate-700" : "bg-white/10 text-white"}`,
															children: msg.senderName.charAt(0) || "U"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "font-extrabold text-xs font-['Alexandria']",
															children: msg.senderName
														}),
														isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "px-2 py-0.5 rounded-full text-[10px] font-black bg-purple-500/20 text-purple-500 border border-purple-500/30",
															children: isAr ? "إدارة المنصة" : "Admin"
														})
													]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] text-slate-400",
														children: new Date(msg.createdAt).toLocaleTimeString(isAr ? "ar-SA" : "en-US", {
															hour: "2-digit",
															minute: "2-digit"
														})
													}), (isOwner || msg.senderRole === "admin") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														onClick: () => handleDeleteMessage(msg.id),
														title: isAr ? "حذف الرسالة" : "Delete message",
														className: "text-slate-400 hover:text-rose-500 transition cursor-pointer p-1",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "w-3.5 h-3.5" })
													})]
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs sm:text-sm leading-relaxed whitespace-pre-wrap",
												children: msg.text
											})]
										}, msg.id);
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { ref: messagesEndRef })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
									onSubmit: handleSendMessage,
									className: `pt-3 border-t space-y-2.5 ${isLight ? "border-slate-100" : "border-white/5"}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-1/3 min-w-[130px]",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "text",
												value: senderName,
												onChange: (e) => setSenderName(e.target.value),
												placeholder: isAr ? "اسمك أو اسمك المستعار..." : "Your Name / Handle...",
												className: `w-full px-3 py-2 rounded-xl border text-xs outline-none transition ${isLight ? "bg-slate-50 border-slate-200 text-slate-800 focus:border-purple-500" : "bg-white/5 border-white/10 text-white focus:border-purple-400"}`
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex-1 flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "text",
												value: inputText,
												onChange: (e) => setInputText(e.target.value),
												placeholder: isAr ? "شارك رأيك أو انطباعك حول كتاب هذا الأسبوع..." : "Share your perspective on this week’s book...",
												className: `w-full px-3.5 py-2 rounded-xl border text-xs outline-none transition ${isLight ? "bg-slate-50 border-slate-200 text-slate-800 focus:border-purple-500" : "bg-white/5 border-white/10 text-white focus:border-purple-400"}`
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "submit",
												disabled: isSending || !inputText.trim(),
												className: "px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-extrabold text-xs transition cursor-pointer flex items-center gap-1.5 shadow-md shadow-purple-500/20 disabled:opacity-50 shrink-0",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "إرسال" : "Send" })]
											})]
										})]
									})
								})
							]
						}),
						activeTab === "book" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `p-6 rounded-3xl border ${isLight ? "bg-white border-slate-200 shadow-sm" : "bg-slate-900/60 border-white/10"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col sm:flex-row items-start gap-6",
									children: [session.coverImage && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "w-32 h-44 rounded-2xl overflow-hidden shadow-xl shrink-0 border border-white/20",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: session.coverImage,
											alt: session.bookTitleAr,
											className: "w-full h-full object-cover"
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-3 flex-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "px-3 py-1 rounded-full text-xs font-black bg-purple-500/10 text-purple-500 border border-purple-500/20 inline-block",
												children: isAr ? "كتاب الأسبوع المختار للنقاش" : "Selected Book of the Week"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-xl sm:text-2xl font-black font-['Alexandria']",
												children: isAr ? session.bookTitleAr : session.bookTitleEn
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs sm:text-sm font-semibold text-purple-500",
												children: isAr ? session.authorAr : session.authorEn
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: `text-xs sm:text-sm leading-relaxed ${isLight ? "text-slate-600" : "text-slate-300"}`,
												children: isAr ? session.descriptionAr : session.descriptionEn
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "pt-2 flex flex-wrap items-center gap-4 text-xs font-bold text-slate-500",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "flex items-center gap-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "w-4 h-4 text-purple-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: session.sessionDate })]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "flex items-center gap-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "w-4 h-4 text-pink-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? session.sessionTimeAr : session.sessionTimeEn })]
												})]
											})
										]
									})]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `p-6 rounded-3xl border space-y-4 ${isLight ? "bg-slate-50 border-slate-200" : "bg-white/[0.02] border-white/10"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
									className: "text-sm font-black font-['Alexandria'] flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-4 h-4 text-amber-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "غايات ومحاور النقاش الأسبوعي:" : "Discussion Objectives & Focal Points:" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "space-y-2.5",
									children: (isAr ? session.objectivesAr : session.objectivesEn).map((obj, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-start gap-2.5 text-xs sm:text-sm leading-relaxed",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-4 h-4 text-emerald-500 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: obj })]
									}, i))
								})]
							})]
						}),
						activeTab === "admin" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit: handleSaveAdminSession,
							className: "space-y-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `p-4 rounded-2xl border text-xs flex items-center gap-3 ${isLight ? "bg-amber-50 border-amber-200 text-amber-950" : "bg-amber-500/10 border-amber-500/30 text-amber-200"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "w-4 h-4 text-amber-500 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "لوحة تحكم المشرف: يمكنك هنا تغيير كتاب الأسبوع، وضبط تاريخ وموعد جلسة النقاش، وتحديد محاور الحوار." : "Admin Control Panel: Update the weekly book, schedule date and time, and customize discussion objectives." })]
								}),
								saveSuccess && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-500 text-xs font-bold flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "تم حفظ التعديلات ونشرها بنجاح!" : "Changes saved and published successfully!" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "font-extrabold",
												children: isAr ? "عنوان الكتاب (عربي)" : "Book Title (Arabic)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "text",
												value: adminForm.bookTitleAr,
												onChange: (e) => setAdminForm({
													...adminForm,
													bookTitleAr: e.target.value
												}),
												className: `w-full px-3 py-2.5 rounded-xl border outline-none ${isLight ? "bg-white border-slate-300" : "bg-slate-800 border-white/10 text-white"}`
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "font-extrabold",
												children: isAr ? "عنوان الكتاب (إنجليزي)" : "Book Title (English)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "text",
												value: adminForm.bookTitleEn,
												onChange: (e) => setAdminForm({
													...adminForm,
													bookTitleEn: e.target.value
												}),
												className: `w-full px-3 py-2.5 rounded-xl border outline-none ${isLight ? "bg-white border-slate-300" : "bg-slate-800 border-white/10 text-white"}`
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "font-extrabold",
												children: isAr ? "اسم المؤلف (عربي)" : "Author (Arabic)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "text",
												value: adminForm.authorAr,
												onChange: (e) => setAdminForm({
													...adminForm,
													authorAr: e.target.value
												}),
												className: `w-full px-3 py-2.5 rounded-xl border outline-none ${isLight ? "bg-white border-slate-300" : "bg-slate-800 border-white/10 text-white"}`
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "font-extrabold",
												children: isAr ? "اسم المؤلف (إنجليزي)" : "Author (English)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "text",
												value: adminForm.authorEn,
												onChange: (e) => setAdminForm({
													...adminForm,
													authorEn: e.target.value
												}),
												className: `w-full px-3 py-2.5 rounded-xl border outline-none ${isLight ? "bg-white border-slate-300" : "bg-slate-800 border-white/10 text-white"}`
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "font-extrabold",
												children: isAr ? "تاريخ وموعد الجلسة (عربي)" : "Session Schedule (Arabic)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "text",
												value: adminForm.sessionTimeAr,
												onChange: (e) => setAdminForm({
													...adminForm,
													sessionTimeAr: e.target.value
												}),
												placeholder: "الجمعة القادمة • 8:00 مساءً",
												className: `w-full px-3 py-2.5 rounded-xl border outline-none ${isLight ? "bg-white border-slate-300" : "bg-slate-800 border-white/10 text-white"}`
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "font-extrabold",
												children: isAr ? "تاريخ وموعد الجلسة (إنجليزي)" : "Session Schedule (English)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "text",
												value: adminForm.sessionTimeEn,
												onChange: (e) => setAdminForm({
													...adminForm,
													sessionTimeEn: e.target.value
												}),
												placeholder: "Friday • 8:00 PM",
												className: `w-full px-3 py-2.5 rounded-xl border outline-none ${isLight ? "bg-white border-slate-300" : "bg-slate-800 border-white/10 text-white"}`
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1.5 sm:col-span-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "font-extrabold",
												children: isAr ? "حالة الجلسة" : "Session Status"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
												"aria-label": isAr ? "حالة الجلسة" : "Session Status",
												title: isAr ? "حالة الجلسة" : "Session Status",
												value: adminForm.status,
												onChange: (e) => setAdminForm({
													...adminForm,
													status: e.target.value
												}),
												className: `w-full px-3 py-2.5 rounded-xl border outline-none ${isLight ? "bg-white border-slate-300" : "bg-slate-800 border-white/10 text-white"}`,
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "scheduled",
														children: isAr ? "مجدولة قادمة" : "Scheduled"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "live",
														children: isAr ? "جارية ومباشرة الآن" : "Live Now"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "completed",
														children: isAr ? "منتهية ومؤرشفة" : "Completed"
													})
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1.5 sm:col-span-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "font-extrabold",
												children: isAr ? "نبذة عن الكتاب وموضوع النقاش (عربي)" : "Book Summary & Topic (Arabic)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
												rows: 3,
												value: adminForm.descriptionAr,
												onChange: (e) => setAdminForm({
													...adminForm,
													descriptionAr: e.target.value
												}),
												className: `w-full p-3 rounded-xl border outline-none ${isLight ? "bg-white border-slate-300" : "bg-slate-800 border-white/10 text-white"}`
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1.5 sm:col-span-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "font-extrabold",
												children: isAr ? "محاور وغايات النقاش (سطر لكل محور - عربي)" : "Objectives (One per line - Arabic)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
												rows: 3,
												value: objectivesTextAr,
												onChange: (e) => setObjectivesTextAr(e.target.value),
												className: `w-full p-3 rounded-xl border outline-none ${isLight ? "bg-white border-slate-300" : "bg-slate-800 border-white/10 text-white"}`
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "pt-2 flex justify-end gap-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "submit",
										className: "px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-extrabold text-xs cursor-pointer shadow-md",
										children: isAr ? "حفظ وتحديث الجلسة" : "Save & Publish Session"
									})
								})
							]
						})
					]
				})
			]
		})
	}) });
};
//#endregion
export { BookClubCommunityModal };
