import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { An as BookOpen, D as Sparkles, H as ScrollText, Ht as Flame, I as Share2, Lt as Globe, Nn as ArrowRight, On as Bookmark, Pn as ArrowLeft, S as Sun, Sn as Calendar, Wt as FileText, _n as ChevronRight, b as Target, bn as Check, cn as Clock, d as UserCheck, gt as MapPin, st as Moon, ut as MessageSquare, vn as ChevronLeft, w as Star } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import { d as useAppTheme, l as useLanguage } from "./index-C5uCeetQ.js";
import { n as getFullNovelContinuousText, t as NOVELS_CATALOG } from "./data-content-CCe8WBeA.js";
import { n as ReaderToolbar, t as FormattedContinuousManuscript } from "./ReaderToolbar-CBKPy1tK.js";
import { r as getAllNovels } from "./novelsService-DylA4WsJ.js";
import { t as NovelCommentsSection } from "./NovelCommentsSection-BjwcZvs9.js";
import { t as PageSEO } from "./PageSEO-tUCGtj4d.js";
//#region src/pages/NovelDetailPage.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var NovelDetailPage = ({ novelId, onBackToDirectory, onReadChapter }) => {
	const { language, setLanguage, isRTL } = useLanguage();
	const { appTheme, toggleAppTheme } = useAppTheme();
	const isLight = appTheme === "light";
	const [novel, setNovel] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [activeTab, setActiveTab] = (0, import_react.useState)("chapters");
	const [copiedShare, setCopiedShare] = (0, import_react.useState)(false);
	const [copiedFullStory, setCopiedFullStory] = (0, import_react.useState)(false);
	const [readerFontSize, setReaderFontSize] = (0, import_react.useState)(18);
	const [readerViewMode, setReaderViewMode] = (0, import_react.useState)("continuous_only");
	const [bookmarkChapterIndex, setBookmarkChapterIndex] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let isMounted = true;
		getAllNovels().then((list) => {
			if (!isMounted) return;
			const found = list.find((n) => n.id === novelId) || NOVELS_CATALOG.find((n) => n.id === novelId);
			if (found) setNovel(found);
			setLoading(false);
		});
		try {
			const raw = localStorage.getItem(`mirat_novel_bookmark_${novelId}`);
			if (raw !== null) setBookmarkChapterIndex(parseInt(raw, 10));
		} catch {}
		return () => {
			isMounted = false;
		};
	}, [novelId]);
	const handleShare = () => {
		soundManager.playTap();
		const url = window.location.href;
		if (navigator.clipboard) navigator.clipboard.writeText(url).then(() => {
			setCopiedShare(true);
			setTimeout(() => setCopiedShare(false), 2500);
		});
	};
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `min-h-screen flex items-center justify-center ${isLight ? "bg-slate-50 text-slate-800" : "bg-slate-950 text-slate-100"}`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-slate-400",
			children: language === "ar" ? "جارٍ فتح ملف الرواية..." : "Opening novel dossier..."
		})
	});
	if (!novel) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `min-h-screen flex flex-col items-center justify-center p-6 space-y-4 ${isLight ? "bg-slate-50 text-slate-800" : "bg-slate-950 text-slate-100"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "w-12 h-12 text-slate-500" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xl font-bold",
				children: language === "ar" ? "الرواية غير موجودة" : "Novel Not Found"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: onBackToDirectory,
				className: "px-4 py-2 bg-rose-600 text-white rounded-xl text-sm font-semibold",
				children: language === "ar" ? "العودة للمكتبة" : "Back to Library"
			})
		]
	});
	const allClues = novel.chapters.flatMap((c) => c.investigationClues || []);
	const displayTitle = language === "en" && novel.titleEn ? novel.titleEn : novel.titleAr;
	const displaySubtitle = language === "en" && novel.subtitleEn ? novel.subtitleEn : novel.subtitleAr;
	const displaySynopsis = language === "en" && novel.synopsisEn ? novel.synopsisEn : novel.synopsisAr;
	const displayGenre = language === "en" && novel.genreLabelEn ? novel.genreLabelEn : novel.genreLabelAr;
	const displayTime = language === "en" && novel.timeSettingEn ? novel.timeSettingEn : novel.timeSettingAr;
	const displayPlace = language === "en" && novel.placeSettingEn ? novel.placeSettingEn : novel.placeSettingAr;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		dir: isRTL ? "rtl" : "ltr",
		className: `min-h-screen py-10 px-4 sm:px-6 lg:px-8 transition-colors duration-300 selection:bg-rose-500/30 ${isLight ? "bg-slate-50 text-slate-900" : "bg-slate-950 text-slate-100"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageSEO, {
			title: `${displayTitle} | ${language === "ar" ? "مرآة القلوب" : "Mirror of Hearts"}`,
			description: displaySynopsis.slice(0, 155),
			canonicalPath: `/#/novels/${novel.id}`,
			language
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-5xl mx-auto space-y-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `flex flex-wrap items-center justify-between gap-3 border-b pb-4 ${isLight ? "border-slate-200" : "border-slate-800/80"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => {
							soundManager.playTap();
							onBackToDirectory();
						},
						className: `inline-flex items-center gap-2 text-sm transition-colors group px-3.5 py-2 rounded-xl border ${isLight ? "bg-white text-slate-700 border-slate-200 hover:border-rose-400 hover:text-rose-600 shadow-sm" : "bg-slate-900/60 text-slate-300 border-slate-800 hover:border-rose-500/30 hover:text-rose-400"}`,
						children: [isRTL ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "w-4 h-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "العودة لمكتبة الروايات" : "Back to Novels Library" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => {
									soundManager.playTap();
									setLanguage(language === "ar" ? "en" : "ar");
								},
								className: `inline-flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-xl font-bold border transition ${isLight ? "bg-white border-slate-200 text-slate-700 hover:bg-slate-100" : "bg-slate-900/60 border-slate-800 text-slate-200 hover:bg-slate-800"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "w-3.5 h-3.5 text-cyan-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "English" : "العربية" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => {
									soundManager.playTap();
									toggleAppTheme();
								},
								className: `inline-flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-xl font-bold border transition ${isLight ? "bg-amber-50 border-amber-200 text-amber-800 hover:bg-amber-100" : "bg-slate-900/60 border-slate-800 text-amber-300 hover:bg-slate-800"}`,
								children: [isLight ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isLight ? language === "ar" ? "ليلي" : "Dark" : language === "ar" ? "نهاري" : "Light" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: handleShare,
								className: `inline-flex items-center gap-2 text-xs px-3 py-1.5 rounded-xl border ${isLight ? "bg-white text-slate-700 border-slate-200 hover:bg-slate-100" : "bg-slate-900/60 text-slate-300 hover:text-white border-slate-800 hover:border-slate-700"}`,
								children: copiedShare ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-3.5 h-3.5 text-emerald-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-emerald-500 font-bold",
									children: language === "ar" ? "تم نسخ الرابط" : "Link Copied"
								})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "w-3.5 h-3.5 text-rose-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "مشاركة الرواية" : "Share Novel" })] })
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `border rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden ${isLight ? "bg-white border-slate-200" : "bg-slate-900/70 border-slate-800/80"}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative z-10 grid grid-cols-1 md:grid-cols-3 gap-6 items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-full h-64 md:h-80 rounded-2xl bg-slate-950 border border-slate-800 p-2 flex items-center justify-center shadow-inner",
							dangerouslySetInnerHTML: { __html: novel.coverIllustrationSvg }
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "md:col-span-2 space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-bold px-3 py-1 rounded-full border",
											style: {
												borderColor: `${novel.genreBadgeColor}55`,
												backgroundColor: `${novel.genreBadgeColor}18`,
												color: novel.genreBadgeColor
											},
											children: displayGenre
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: `flex items-center gap-1 text-amber-500 text-xs font-bold px-2.5 py-1 rounded-full border ${isLight ? "bg-amber-50 border-amber-200" : "bg-slate-950 border-slate-800"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "w-3.5 h-3.5 fill-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: novel.rating.toFixed(2) })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: `flex items-center gap-1 text-xs px-2.5 py-1 rounded-full border ${isLight ? "bg-slate-100 border-slate-200 text-slate-700" : "bg-slate-950 border-slate-800 text-slate-300"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, { className: "w-3.5 h-3.5 text-rose-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
												novel.readsCount.toLocaleString(),
												" ",
												language === "ar" ? "قراءة" : "reads"
											] })]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: `text-2xl sm:text-4xl font-black tracking-tight leading-tight ${isLight ? "text-slate-900" : "text-white"}`,
									children: displayTitle
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: `text-sm sm:text-base font-semibold mt-1 ${isLight ? "text-rose-700" : "text-rose-300/90"}`,
									children: displaySubtitle
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: `text-sm leading-relaxed ${isLight ? "text-slate-700" : "text-slate-300"}`,
									children: displaySynopsis
								}),
								(displayTime || displayPlace) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2",
									children: [displayTime && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `p-3 rounded-xl border text-xs flex items-start gap-2.5 ${isLight ? "bg-amber-50/70 border-amber-200 text-slate-800" : "bg-slate-950/80 border-amber-500/30 text-slate-200"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "w-4 h-4 text-amber-500 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-bold block text-amber-500 mb-0.5",
											children: language === "ar" ? "الزمان والإطار الزمني:" : "Time Setting:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "leading-relaxed",
											children: displayTime
										})] })]
									}), displayPlace && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `p-3 rounded-xl border text-xs flex items-start gap-2.5 ${isLight ? "bg-emerald-50/70 border-emerald-200 text-slate-800" : "bg-slate-950/80 border-emerald-500/30 text-slate-200"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "w-4 h-4 text-emerald-500 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-bold block text-emerald-500 mb-0.5",
											children: language === "ar" ? "المكان ومسرح الأحداث:" : "Place & Setting:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "leading-relaxed",
											children: displayPlace
										})] })]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `grid grid-cols-2 sm:grid-cols-3 gap-3 pt-3 border-t text-xs ${isLight ? "border-slate-200" : "border-slate-800/80"}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: `p-2.5 rounded-xl border ${isLight ? "bg-slate-50 border-slate-200" : "bg-slate-950/60 border-slate-800/60"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-slate-400 block text-[11px]",
												children: language === "ar" ? "الشخصيات المحورية:" : "Key Figures:"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `font-semibold ${isLight ? "text-slate-800" : "text-slate-200"}`,
												children: novel.authorPersonaAr
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: `p-2.5 rounded-xl border ${isLight ? "bg-slate-50 border-slate-200" : "bg-slate-950/60 border-slate-800/60"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-slate-400 block text-[11px]",
												children: language === "ar" ? "زمن القراءة:" : "Read Time:"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `font-semibold ${isLight ? "text-slate-800" : "text-slate-200"}`,
												children: novel.estimatedReadingTime
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: `p-2.5 rounded-xl border col-span-2 sm:col-span-1 ${isLight ? "bg-slate-50 border-slate-200" : "bg-slate-950/60 border-slate-800/60"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-slate-400 block text-[11px]",
												children: language === "ar" ? "إجمالي الكلمات:" : "Total Words:"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `font-semibold ${isLight ? "text-slate-800" : "text-slate-200"}`,
												children: novel.totalWords.toLocaleString()
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap gap-3 pt-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: () => {
												soundManager.playTap();
												onReadChapter(novel.id, 0);
											},
											className: "px-6 py-2.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-sm font-bold transition-all shadow-lg flex items-center gap-2 cursor-pointer",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "w-4 h-4" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "ابدأ القراءة من الفصل الأول" : "Start Chapter 1" }),
												isRTL ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "w-4 h-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "w-4 h-4" })
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => {
												soundManager.playTap();
												setActiveTab("full_continuous");
												setTimeout(() => {
													const el = document.getElementById("novel-full-continuous-reader");
													if (el) el.scrollIntoView({
														behavior: "smooth",
														block: "start"
													});
												}, 100);
											},
											className: `px-5 py-2.5 rounded-xl text-sm font-extrabold transition-all border flex items-center gap-2 cursor-pointer shadow-md ${activeTab === "full_continuous" ? "bg-indigo-600 text-white border-indigo-500" : isLight ? "bg-indigo-50 hover:bg-indigo-100 text-indigo-900 border-indigo-300" : "bg-indigo-950/70 hover:bg-indigo-900/80 text-cyan-200 border-indigo-500/40"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollText, { className: "w-4 h-4 text-cyan-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "📜 قراءة القصة / الرواية كاملة دون تجزئة" : "📜 Read Full Story Unsegmented" })]
										}),
										bookmarkChapterIndex !== null && bookmarkChapterIndex < novel.chapters.length && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: () => {
												soundManager.playTap();
												onReadChapter(novel.id, bookmarkChapterIndex);
											},
											className: `px-5 py-2.5 rounded-xl text-sm font-semibold transition-all border flex items-center gap-2 cursor-pointer ${isLight ? "bg-amber-50 hover:bg-amber-100 text-amber-900 border-amber-300" : "bg-slate-800 hover:bg-slate-700 text-slate-100 border-slate-700/80"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "w-4 h-4 text-amber-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? `استئناف القراءة (الفصل ${bookmarkChapterIndex + 1})` : `Resume Chapter ${bookmarkChapterIndex + 1}` })]
										})
									]
								})
							]
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `flex items-center gap-2 border-b pb-2 overflow-x-auto ${isLight ? "border-slate-200" : "border-slate-800/80"}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundManager.playTap();
								setActiveTab("chapters");
							},
							className: `flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all whitespace-nowrap cursor-pointer ${activeTab === "chapters" ? "bg-rose-600 text-white shadow-md" : isLight ? "bg-white text-slate-600 hover:text-slate-900 border border-slate-200" : "bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "w-4 h-4" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "فصول القصة / الرواية" : "Story Chapters" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs bg-black/20 px-2 py-0.5 rounded-full",
									children: novel.chapters.length
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundManager.playTap();
								setActiveTab("full_continuous");
							},
							className: `flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-extrabold transition-all whitespace-nowrap cursor-pointer ${activeTab === "full_continuous" ? "bg-indigo-600 text-white shadow-md" : isLight ? "bg-indigo-50 text-indigo-800 hover:bg-indigo-100 border border-indigo-200" : "bg-indigo-950/60 text-cyan-200 hover:bg-indigo-900/70 border border-indigo-500/40"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollText, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "📜 قراءة كاملة دون تجزئة (النص الكامل)" : "📜 Full Unsegmented Story" })]
						}),
						(novel.appendixItems || novel.authorWordAr) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundManager.playTap();
								setActiveTab("appendix");
							},
							className: `flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all whitespace-nowrap cursor-pointer ${activeTab === "appendix" ? "bg-emerald-600 text-white shadow-md" : isLight ? "bg-white text-slate-600 hover:text-slate-900 border border-slate-200" : "bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? novel.appendixTitleAr || "الملحق الأدبي / العلمي وكلمة المؤلف" : novel.appendixTitleEn || "Literary / Scientific Appendix" })]
						}),
						allClues.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundManager.playTap();
								setActiveTab("evidence");
							},
							className: `flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all whitespace-nowrap cursor-pointer ${activeTab === "evidence" ? "bg-rose-600 text-white shadow-md" : isLight ? "bg-white text-slate-600 hover:text-slate-900 border border-slate-200" : "bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, { className: "w-4 h-4" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "لوحة الأدلة والتقارير" : "Evidence Board" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs bg-black/20 px-2 py-0.5 rounded-full",
									children: allClues.length
								})
							]
						}),
						novel.suspectsDossier && novel.suspectsDossier.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundManager.playTap();
								setActiveTab("suspects");
							},
							className: `flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all whitespace-nowrap cursor-pointer ${activeTab === "suspects" ? "bg-rose-600 text-white shadow-md" : isLight ? "bg-white text-slate-600 hover:text-slate-900 border border-slate-200" : "bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "w-4 h-4" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "الشخصيات والمشتبه بهم" : "Characters & Suspects" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs bg-black/20 px-2 py-0.5 rounded-full",
									children: novel.suspectsDossier.length
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								soundManager.playTap();
								setActiveTab("comments");
							},
							className: `flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all whitespace-nowrap cursor-pointer ${activeTab === "comments" ? "bg-rose-600 text-white shadow-md" : isLight ? "bg-white text-slate-600 hover:text-slate-900 border border-slate-200" : "bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquare, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "التعليقات ومناقشات القراء" : "Reader Comments" })]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					activeTab === "chapters" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-3",
						children: novel.chapters.map((chapter, idx) => {
							const chapTitle = language === "en" && chapter.titleEn ? chapter.titleEn : chapter.titleAr;
							const chapSynopsis = language === "en" && chapter.synopsisEn ? chapter.synopsisEn : chapter.synopsisAr;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `rounded-2xl border p-5 transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 group ${isLight ? "bg-white hover:bg-slate-50 border-slate-200 shadow-sm" : "bg-slate-900/60 hover:bg-slate-900 border-slate-800/80"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs font-bold text-rose-500",
													children: language === "ar" ? `الجزء ${chapter.chapterNumber}` : `Part ${chapter.chapterNumber}`
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-slate-400",
													children: "•"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-xs text-slate-400 flex items-center gap-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "w-3 h-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
														chapter.estimatedMinutes,
														" ",
														language === "ar" ? "دقيقة" : "mins"
													] })]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-slate-400",
													children: "•"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-xs text-slate-400",
													children: [
														chapter.wordsCount.toLocaleString(),
														" ",
														language === "ar" ? "كلمة" : "words"
													]
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: `text-base font-bold group-hover:text-rose-500 transition-colors ${isLight ? "text-slate-900" : "text-white"}`,
											children: chapTitle
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: `text-xs line-clamp-2 ${isLight ? "text-slate-600" : "text-slate-400"}`,
											children: chapSynopsis
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => {
										soundManager.playTap();
										onReadChapter(novel.id, idx);
									},
									className: "self-end sm:self-center px-4 py-2.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "قراءة الفصل" : "Read Chapter" }), isRTL ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "w-3.5 h-3.5" })]
								})]
							}, chapter.chapterNumber);
						})
					}),
					activeTab === "full_continuous" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						id: "novel-full-continuous-reader",
						className: "space-y-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReaderToolbar, {
							fontSize: readerFontSize,
							onChangeFontSize: setReaderFontSize,
							viewMode: readerViewMode,
							onChangeViewMode: (mode) => {
								setReaderViewMode(mode);
								if (mode === "segmented_and_continuous") setActiveTab("chapters");
							},
							shareTitle: displayTitle,
							shareSummary: displaySynopsis,
							shareUrl: window.location.href,
							contentTypeLabelAr: "للقصة / الرواية",
							contentTypeLabelEn: "Story"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `p-6 sm:p-10 rounded-3xl border-2 space-y-5 shadow-xl ${isLight ? "bg-gradient-to-b from-indigo-50/50 via-white to-slate-50 border-indigo-300 text-slate-900" : "bg-gradient-to-b from-indigo-950/35 via-slate-900/95 to-slate-950 border-indigo-500/40 text-slate-100"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-3 border-b pb-4 border-indigo-200 dark:border-slate-800",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/15 border border-indigo-500/30 text-indigo-700 dark:text-cyan-300 text-xs font-extrabold",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollText, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "ar" ? "وضع القراءة المتصلة الكاملة دون تجزئة" : "Full Continuous Unsegmented Reading Mode" })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
											className: "text-xl sm:text-2xl font-black",
											children: [
												displayTitle,
												" — ",
												language === "ar" ? "النص الكامل المتواصل" : "Complete Unsegmented Text"
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs opacity-80",
											children: language === "ar" ? "جميع الفصول والحالات السريرية والملاحق معروضة بشكل متصل ومتواصل دون أي تجزئة لقراءة غامرة." : "All chapters, clinical cases, and appendices presented continuously without segmentation."
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										soundManager.playTap();
										const fullText = getFullNovelContinuousText(novel, language);
										if (navigator.clipboard) {
											navigator.clipboard.writeText(fullText);
											setCopiedFullStory(true);
											setTimeout(() => setCopiedFullStory(false), 2500);
										}
									},
									className: "px-4 py-2 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-extrabold flex items-center gap-1.5 transition cursor-pointer shadow-md",
									children: [copiedFullStory ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-4 h-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: copiedFullStory ? language === "ar" ? "تم نسخ النص الكامل!" : "Full Text Copied!" : language === "ar" ? "نسخ النص الكامل للقصة" : "Copy Full Story Text" })]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `p-5 sm:p-8 rounded-2xl border select-text ${isLight ? "bg-white border-slate-200 text-slate-800 shadow-inner" : "bg-slate-950/70 border-slate-800 text-slate-200"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormattedContinuousManuscript, {
									text: getFullNovelContinuousText(novel, language),
									fontSize: readerFontSize,
									isLight
								})
							})]
						})]
					}),
					activeTab === "appendix" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-6",
						children: [novel.appendixItems && novel.appendixItems.map((item, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `rounded-2xl border p-6 space-y-3 ${isLight ? "bg-white border-slate-200 shadow-sm" : "bg-slate-900/70 border-slate-800/80"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "text-lg font-black text-emerald-500 flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-5 h-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: language === "en" && item.titleEn ? item.titleEn : item.titleAr })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `text-sm leading-relaxed whitespace-pre-line font-serif ${isLight ? "text-slate-700" : "text-slate-200"}`,
								children: language === "en" && item.contentEn ? item.contentEn : item.contentAr
							})]
						}, idx)), (novel.authorWordAr || novel.authorWordEn) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `rounded-2xl border p-6 space-y-3 ${isLight ? "bg-amber-50/80 border-amber-200 text-slate-800" : "bg-amber-950/20 border-amber-500/30 text-amber-100"}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm leading-relaxed whitespace-pre-line font-serif",
								children: language === "en" && novel.authorWordEn ? novel.authorWordEn : novel.authorWordAr
							})
						})]
					}),
					activeTab === "evidence" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-1 md:grid-cols-2 gap-4",
							children: allClues.map((clue) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `border rounded-2xl p-5 space-y-3 ${isLight ? "bg-white border-slate-200 shadow-sm" : "bg-slate-900/70 border-slate-800/80"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-bold text-rose-500 uppercase",
											children: clue.type
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[11px] px-2.5 py-0.5 rounded-full bg-amber-500/15 text-amber-500 font-bold border border-amber-500/30",
											children: clue.significanceLevel
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: `text-base font-bold ${isLight ? "text-slate-900" : "text-white"}`,
										children: clue.titleAr
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: `text-xs ${isLight ? "text-slate-600" : "text-slate-300"}`,
										children: clue.descriptionAr
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `p-3 rounded-xl border text-xs font-mono ${isLight ? "bg-emerald-50 border-emerald-200 text-emerald-900" : "bg-slate-950 border-slate-800/60 text-emerald-300/90"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-slate-400 block text-[10px] mb-1 font-sans",
											children: language === "ar" ? "التقرير المخبري الجنائي:" : "Forensic Lab Report:"
										}), clue.forensicLabReportAr]
									})
								]
							}, clue.id))
						})
					}),
					activeTab === "suspects" && novel.suspectsDossier && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 md:grid-cols-2 gap-4",
						children: novel.suspectsDossier.map((suspect, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `border rounded-2xl p-5 space-y-3 ${isLight ? "bg-white border-slate-200 shadow-sm" : "bg-slate-900/70 border-slate-800/80"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: `text-base font-bold ${isLight ? "text-slate-900" : "text-white"}`,
										children: suspect.nameAr
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-slate-400",
										children: [
											suspect.roleAr,
											" • ",
											suspect.age,
											" ",
											language === "ar" ? "سنة" : "y/o"
										]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[11px] px-2.5 py-0.5 rounded-full bg-rose-500/15 text-rose-500 font-bold border border-rose-500/30",
										children: suspect.status
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1 text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-slate-400 block",
										children: language === "ar" ? "الدافع النفسي والسلوكي:" : "Psychological Profile:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: isLight ? "text-slate-700" : "text-slate-200",
										children: suspect.psychologicalMotiveAr
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1 text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-slate-400 block",
										children: language === "ar" ? "الدور في الأحداث:" : "Role & Alibi:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: isLight ? "text-slate-600" : "text-slate-300",
										children: suspect.alibiAr
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap gap-1.5 pt-2",
									children: suspect.behavioralTraitsAr?.map((trait, tIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `text-[10px] px-2 py-0.5 rounded-md border ${isLight ? "bg-slate-100 text-slate-700 border-slate-200" : "bg-slate-950 text-slate-300 border-slate-800"}`,
										children: trait
									}, tIdx))
								})
							]
						}, idx))
					}),
					activeTab === "comments" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `border rounded-2xl p-6 ${isLight ? "bg-white border-slate-200" : "bg-slate-900/60 border-slate-800/80"}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NovelCommentsSection, {
							novelId: novel.id,
							novelTitle: displayTitle
						})
					})
				] })
			]
		})]
	});
};
//#endregion
export { NovelDetailPage };
