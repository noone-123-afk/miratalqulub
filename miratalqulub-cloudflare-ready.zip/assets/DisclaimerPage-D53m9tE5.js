import "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { Lt as Globe, Nn as ArrowRight, Pn as ArrowLeft, Pt as Heart, U as Scale, p as TriangleAlert, un as CircleX } from "./vendor-icons-WoMClU7U.js";
import { l as useLanguage, s as OFFICIAL_LOGO_URL } from "./index-C5uCeetQ.js";
import { t as PageSEO } from "./PageSEO-tUCGtj4d.js";
require_react();
var import_jsx_runtime = require_jsx_runtime();
var DisclaimerPage = ({ onBackToHome, onNavigatePage }) => {
	const { language, isRTL, toggleLanguage } = useLanguage();
	const isAr = language === "ar";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full min-h-screen text-slate-100 py-6 sm:py-10 px-3 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageSEO, {
			title: isAr ? "إخلاء المسؤولية القانوني | مرآة القلوب - حدود الاستخدام والتنبيه الاستشاري" : "Content Disclaimer | Mirror of Hearts - Legal & Educational Limits",
			description: isAr ? "تنبيه إخلاء المسؤولية الصريح لمنصة مرآة القلوب: النتائج لأغراض معرفية وتثقيفية فقط وليست استشارات طبية أو عيادية أو قانونية، ولا تضمن نجاح أو استمرار أي علاقة." : "Explicit Content Disclaimer for Mirror of Hearts: all results are purely educational and exploratory, with zero relationship guarantees.",
			canonicalPath: "/#/disclaimer",
			language,
			pageType: "terms",
			structuredData: {
				"@context": "https://schema.org",
				"@type": "WebPage",
				name: isAr ? "إخلاء المسؤولية القانوني والتنبيه الاستشاري | مرآة القلوب" : "Content Disclaimer | Mirror of Hearts",
				description: isAr ? "وثيقة إخلاء المسؤولية الرسمية لمنصة مرآة القلوب: توضيح حدود المسؤولية، طبيعة النتائج الاسترشادية والتثقيفية، وعدم تقديم استشارات طبية أو نفسية أو قانونية." : "Official Content Disclaimer of Mirror of Hearts: detailing advisory limitations, non-clinical nature, and non-guarantee of relationship success.",
				url: "https://miratalqulub.com/#/disclaimer",
				publisher: {
					"@type": "Organization",
					name: "مرآة القلوب - Mirror of Hearts",
					email: "one497303@gmail.com",
					address: {
						"@type": "PostalAddress",
						addressLocality: "Amman",
						addressCountry: "JO"
					}
				}
			}
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-4xl mx-auto space-y-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-white/10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-xs text-slate-400",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: onBackToHome,
								className: "hover:text-rose-400 transition cursor-pointer flex items-center gap-1 font-semibold",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "الرئيسية" : "Home" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "/" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-white font-bold",
								children: isAr ? "إخلاء المسؤولية" : "Content Disclaimer"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: toggleLanguage,
							className: "px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-bold text-sky-300 transition flex items-center gap-1.5 cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "English" : "العربية" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: onBackToHome,
							className: "px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-xs font-bold text-rose-300 transition flex items-center gap-1 cursor-pointer",
							children: [isRTL ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "العودة للرئيسية" : "Back to Home" })]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-amber-950/40 via-slate-900/80 to-rose-950/40 border border-amber-500/30 shadow-2xl backdrop-blur-xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 mb-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: OFFICIAL_LOGO_URL,
							alt: "شعار مرآة القلوب الرسمي",
							className: "w-12 h-12 rounded-2xl object-cover border border-amber-500/40 shadow-lg shrink-0"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[11px] font-bold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scale, { className: "w-3 h-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "إشعار قانوني ملزم وتنبيه استشاري" : "Binding Legal & Advisory Notice" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-2xl sm:text-3xl font-black text-white font-['Alexandria'] mt-1",
							children: isAr ? "إخلاء المسؤولية (Content Disclaimer)" : "Content & Liability Disclaimer"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs sm:text-sm text-slate-300 leading-relaxed max-w-2xl",
						children: isAr ? "يرجى قراءة هذا الإشعار بعناية قبل استخدام أدوات واستبيانات منصة «مرآة القلوب». دخولك إلى الموقع يمثل إقراراً وفهماً تاماً لكافة البنود الموضحة أدناه." : "Please review this notice carefully before utilizing Mirror of Hearts tools. Accessing our platform constitutes full understanding and acknowledgment of these provisions."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-6 sm:p-8 rounded-3xl bg-slate-900/60 border border-slate-800 space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-white font-bold text-sm sm:text-base",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "w-5 h-5 text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "1. طبيعة النتائج: استرشادية وتثقيفية فقط" : "1. Advisory & Educational Nature of Results" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs sm:text-sm text-slate-300 leading-relaxed",
						children: isAr ? "كافة الاستبيانات، ومقاييس الشخصية، ومؤشرات التوافق، والتقارير التحليلية المصدرة عبر منصة «مرآة القلوب» صُممت حصراً لأغراض التثقيف النفسي، وزيادة الوعي الذاتي، وفتح آفاق الحوار الإيجابي. لا تقدم المنصة أي نتائج قطعية أو أحكام حتمية حول مستقبل أي علاقة." : "All questionnaires, personality metrics, compatibility indices, and narrative reports generated on Mirror of Hearts are designed exclusively for psychological education, introspective reflection, and constructive dialogue. The platform provides no categorical verdicts regarding relationship outcomes."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-6 sm:p-8 rounded-3xl bg-slate-900/60 border border-slate-800 space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-white font-bold text-sm sm:text-base",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "w-5 h-5 text-rose-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "2. عدم تقديم استشارات مهنية، نفسية، أو طبية" : "2. No Licensed Psychological, Medical, or Legal Advice" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xs sm:text-sm text-slate-300 space-y-2 leading-relaxed",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: isAr ? "الموقع وأدواته لا يقدم استشارات عيادية، ولا يشكل بديلاً عن استشارة الأخصائيين النفسيين، أو الأطباء، أو المستشارين الأسريين المعتمدين، أو المحامين." : "The platform does not provide clinical therapy and does not replace the counsel of licensed psychotherapists, psychiatrists, family counselors, or legal attorneys." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-rose-300 font-medium text-xs",
							children: isAr ? "إذا كنت تعاني من ضغوط نفسية حادة، أو اكتئاب، أو أزمات أسرية معقدة، نوصيك بالتواصل فوراً مع جهات الرعاية الصحية أو الاستشارية المعتمدة في دولتك." : "If you are undergoing severe psychological distress or domestic crises, we urge you to consult qualified healthcare and social counseling professionals."
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-6 sm:p-8 rounded-3xl bg-slate-900/60 border border-slate-800 space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-white font-bold text-sm sm:text-base",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "w-5 h-5 text-pink-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "3. عدم ضمان نجاح العلاقات أو الزواج" : "3. No Guarantees of Relationship Longevity or Marriage" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs sm:text-sm text-slate-300 leading-relaxed",
						children: isAr ? "لا يضمن الموقع نجاح، استمرار، أو التوفيق في أي علاقة عاطفية أو زواج. النجاح الإنساني والأسري يرتبط بالنضج الشخصي، والمرونة، والظروف الواقعية، والتفاهم المستمر بين الطرفين، وهي أبعاد حية لا يمكن لأي أداة رقمية ضمانها أو فرضها." : "The platform offers zero guarantees regarding marriage success, dating longevity, or relationship stability. Real-world interpersonal fulfillment hinges upon emotional maturity, reciprocal empathy, and joint commitment beyond any software calculation."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-6 sm:p-8 rounded-3xl bg-slate-900/60 border border-slate-800 space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-white font-bold text-sm sm:text-base",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scale, { className: "w-5 h-5 text-indigo-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "4. حدود المسؤولية القانونية" : "4. Complete Limitation of Liability" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs sm:text-sm text-slate-300 leading-relaxed",
						children: isAr ? "لا يتحمل فريق تطوير أو إدارة «مرآة القلوب» أي مسؤولية قانونية أو أدبية عن أي قرارات شخصية، أو عاطفية، أو مالية، أو اجتماعية يتخذها المستخدم استناداً إلى نتائج أو محتويات الموقع. تقع مسؤولية جميع القرارات الحياتية كاملة على عاتق المستخدم وحده." : "Under no circumstances shall the developers or operators of Mirror of Hearts be held liable for personal, relational, financial, or social decisions made by users in connection with site contents. All life choices remain the sole responsibility of the individual."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-4 p-5 rounded-3xl bg-slate-900/50 border border-white/5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => onNavigatePage("terms"),
						className: "text-xs text-cyan-400 hover:underline flex items-center gap-1 font-semibold cursor-pointer",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "انتقل إلى: شروط الاستخدام (Terms of Service)" : "View: Terms of Service" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => onNavigatePage("privacy"),
						className: "text-xs text-emerald-400 hover:underline flex items-center gap-1 font-semibold cursor-pointer",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "سياسة الخصوصية (Privacy Policy)" : "Privacy Policy" })
					})]
				})
			]
		})]
	});
};
//#endregion
export { DisclaimerPage };
