import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { B as Send, Xt as ExternalLink, _t as Mail, hn as CircleAlert, mn as CircleCheck, r as X, w as Star, wn as Building } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import { u as useAuth } from "./index-C5uCeetQ.js";
import { n as AnimatePresence, t as motion } from "./vendor-motion-BS7ODJw7.js";
import { r as submitFeedbackMessage, t as OFFICIAL_EMAIL } from "./feedbackService-rknvSOxy.js";
//#region src/components/ContactFeedbackModal.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var ContactFeedbackModal = ({ isOpen, onClose, initialCategory = "general" }) => {
	const { user } = useAuth();
	const [name, setName] = (0, import_react.useState)(user?.displayName || "");
	const [email, setEmail] = (0, import_react.useState)(user?.email || "");
	const [subject, setSubject] = (0, import_react.useState)("");
	const [message, setMessage] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)(initialCategory);
	const [rating, setRating] = (0, import_react.useState)(5);
	const [hoverRating, setHoverRating] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [submitted, setSubmitted] = (0, import_react.useState)(false);
	const [mailtoUrl, setMailtoUrl] = (0, import_react.useState)("");
	const [errorMessage, setErrorMessage] = (0, import_react.useState)(null);
	if (!isOpen) return null;
	const categories = [
		{
			key: "general",
			label: "ملاحظة عامة",
			icon: "💬"
		},
		{
			key: "test_question",
			label: "استفسار عن الاختبارات والنتائج",
			icon: "🧠"
		},
		{
			key: "feature_request",
			label: "اقتراح ميزة أو تطوير",
			icon: "💡"
		},
		{
			key: "technical",
			label: "إبلاغ عن خطأ تقني",
			icon: "🛠️"
		},
		{
			key: "partner_experience",
			label: "تجربة التوافق وشريك الحياة",
			icon: "💖"
		}
	];
	const handleSubmit = async (e) => {
		e.preventDefault();
		if (!name.trim() || !email.trim() || !message.trim()) {
			setErrorMessage("يرجى ملء جميع الحقول المطلوبة");
			return;
		}
		setLoading(true);
		setErrorMessage(null);
		const activeCat = categories.find((c) => c.key === category);
		try {
			const res = await submitFeedbackMessage({
				name,
				email,
				subject: subject.trim() || activeCat?.label || "ملاحظة زائر",
				message,
				category,
				categoryLabelAr: activeCat?.label || "ملاحظة عامة",
				rating,
				user
			});
			soundManager.playRoundPass();
			setMailtoUrl(res.mailtoUrl);
			setSubmitted(true);
		} catch (err) {
			setErrorMessage(err.message || "حدث خطأ أثناء إرسال الرسالة، يرجى المحاولة لاحقاً");
		} finally {
			setLoading(false);
		}
	};
	const handleReset = () => {
		setSubmitted(false);
		setSubject("");
		setMessage("");
		setErrorMessage(null);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md overflow-y-auto",
		dir: "rtl",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: {
				opacity: 0,
				scale: .95,
				y: 15
			},
			animate: {
				opacity: 1,
				scale: 1,
				y: 0
			},
			exit: {
				opacity: 0,
				scale: .95,
				y: 15
			},
			transition: { duration: .25 },
			className: "relative w-full max-w-2xl max-h-[92vh] flex flex-col rounded-3xl bg-[#0f172a] border border-slate-700 shadow-2xl text-white overflow-hidden shadow-black/80",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-4 sm:p-6 border-b border-slate-800 flex items-center justify-between gap-4 bg-slate-900/60 shrink-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-blue-950/80 border border-blue-500/40 flex items-center justify-center text-blue-400",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "w-5 h-5 text-blue-400" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-base sm:text-lg font-extrabold text-white font-['Alexandria']",
						children: "تواصل معنا وإبداء الملاحظات"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-slate-300",
						children: ["فريق المهندسين المتخصصين يستقبل رسائلكم مباشرة عبر: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-blue-400 font-bold",
							children: OFFICIAL_EMAIL
						})]
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						soundManager.playTap();
						onClose();
					},
					className: "w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition cursor-pointer",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-5 h-5" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-1 overflow-y-auto p-4 sm:p-6 space-y-5 text-xs sm:text-sm text-slate-200 custom-scrollbar",
				children: submitted ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-6 sm:p-8 rounded-3xl bg-emerald-950/40 border border-emerald-500/50 text-center space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/20",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-8 h-8" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "text-lg sm:text-xl font-black text-white font-['Alexandria']",
							children: "تم استلام رسالتك وحفظها بنجاح!"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs sm:text-sm text-slate-300 leading-relaxed max-w-lg mx-auto",
							children: [
								"تم تسجيل ملاحظتك في قاعدة بيانات المنصة المشفرة وتوجيه إشعار رسمي إلى الفريق الهندسي المسؤول عبر البريد:",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "block text-emerald-300 font-mono mt-1",
									children: OFFICIAL_EMAIL
								}),
								"سنقوم بمراجعة ملاحظاتك والرد على بريدك الإلكتروني في أقرب وقت."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pt-3 flex flex-col sm:flex-row items-center justify-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: mailtoUrl,
								className: "w-full sm:w-auto py-2.5 px-5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition shadow-md shadow-blue-900/30",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "إرسال نسخة مباشرة عبر تطبيق الإيميل / Gmail" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: handleReset,
								className: "w-full sm:w-auto py-2.5 px-5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition",
								children: "إرسال رسالة أخرى"
							})]
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handleSubmit,
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 text-xs text-slate-300 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building, { className: "w-4 h-4 text-emerald-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "الموقع مشرف عليه ومُدار بواسطة مجموعة من المهندسين المتخصصين" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 text-slate-400 text-[11px]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-emerald-400 font-semibold",
										children: "الأردن - عمّان"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-blue-400 select-all",
										children: OFFICIAL_EMAIL
									})
								]
							})]
						}),
						errorMessage && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-3 rounded-xl bg-rose-950/60 border border-rose-500/50 text-rose-200 text-xs flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "w-4 h-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: errorMessage })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-xs font-bold text-slate-300 mb-1",
								children: ["الاسم الكامل أو المستعار: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-rose-400",
									children: "*"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								value: name,
								onChange: (e) => setName(e.target.value),
								placeholder: "مثال: أحمد خالد",
								required: true,
								className: "w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-xs font-bold text-slate-300 mb-1",
								children: ["بريدك الإلكتروني (للرد والمتابعة): ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-rose-400",
									children: "*"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "email",
								value: email,
								onChange: (e) => setEmail(e.target.value),
								placeholder: "name@example.com",
								required: true,
								className: "w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-bold text-slate-300 mb-1.5",
							children: "تصنيف الرسالة أو الاستفسار:"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-2 sm:grid-cols-3 gap-2",
							children: categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									soundManager.playTap();
									setCategory(c.key);
								},
								className: `p-2.5 rounded-xl text-xs font-bold border text-right transition flex items-center gap-2 cursor-pointer ${category === c.key ? "bg-blue-600/30 border-blue-500 text-white shadow-sm" : "bg-slate-900/60 border-slate-800 text-slate-400 hover:text-white"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-base",
									children: c.icon
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate",
									children: c.label
								})]
							}, c.key))
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-bold text-slate-300 mb-1",
							children: "عنوان الموضوع:"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							value: subject,
							onChange: (e) => setSubject(e.target.value),
							placeholder: "اكتب عنواناً مختصراً لرسالتك...",
							className: "w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-bold text-slate-300 mb-1",
							children: "تقييمك لتجربة المنصة والأدوات السيكومترية:"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1.5 pt-0.5",
							children: [[
								1,
								2,
								3,
								4,
								5
							].map((star) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									soundManager.playTap();
									setRating(star);
								},
								onMouseEnter: () => setHoverRating(star),
								onMouseLeave: () => setHoverRating(null),
								className: "p-1 transition-transform hover:scale-110 cursor-pointer",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: `w-5 h-5 ${(hoverRating !== null ? star <= hoverRating : star <= rating) ? "text-amber-400 fill-amber-400" : "text-slate-600"}` })
							}, star)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-amber-300 font-bold mr-2",
								children: rating === 5 ? "ممتاز جداً 🌟" : rating === 4 ? "جيد جداً 👍" : rating === 3 ? "مقبول ✨" : "يحتاج لتحسين 🔧"
							})]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-xs font-bold text-slate-300 mb-1",
							children: ["تفاصيل الرسالة أو الملاحظة: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-rose-400",
								children: "*"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							rows: 4,
							value: message,
							onChange: (e) => setMessage(e.target.value),
							placeholder: "اكتب ملاحظاتك، استفساراتك، أو تفاصيل المشكلة التي واجهتك بكل أريحية...",
							required: true,
							className: "w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs placeholder:text-slate-500 focus:outline-none focus:border-blue-500 resize-none leading-relaxed"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-slate-400 leading-relaxed",
							children: "🔒 «أي معلومات يتم مشاركتها مع الموقع هي واضحة وضمن موافقتك الشخصية، ولا يتم استخدامها، أو المساس بها، أو الإساءة لها، أو بيعها لأي جهات أخرى، وكل شيء يخضع لشروط وسياسة قوقل»."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pt-2 flex items-center justify-end gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									soundManager.playTap();
									onClose();
								},
								className: "py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition",
								children: "إلغاء"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "submit",
								disabled: loading,
								className: "py-2.5 px-6 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-2 shadow-md shadow-blue-900/30 transition cursor-pointer disabled:opacity-50",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: loading ? "جاري الإرسال..." : "إرسال الملاحظة الآن ✉️" })]
							})]
						})
					]
				})
			})]
		})
	}) });
};
//#endregion
export { ContactFeedbackModal };
