import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { B as Send, D as Sparkles, _ as ThumbsUp, bn as Check, w as Star } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import { u as useAuth } from "./index-C5uCeetQ.js";
import { t as motion } from "./vendor-motion-BS7ODJw7.js";
import { a as getNovelComments, s as likeNovelComment, t as addNovelComment } from "./novelsService-DylA4WsJ.js";
//#region src/components/NovelCommentsSection.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var NovelCommentsSection = ({ novelId, novelTitle }) => {
	const { user } = useAuth();
	const [comments, setComments] = (0, import_react.useState)([]);
	const [isLoading, setIsLoading] = (0, import_react.useState)(true);
	const [userName, setUserName] = (0, import_react.useState)("");
	const [userRoleTitle, setUserRoleTitle] = (0, import_react.useState)("متابع للتحقيقات");
	const [rating, setRating] = (0, import_react.useState)(5);
	const [hoverRating, setHoverRating] = (0, import_react.useState)(0);
	const [commentText, setCommentText] = (0, import_react.useState)("");
	const [isSubmitting, setIsSubmitting] = (0, import_react.useState)(false);
	const [successMessage, setSuccessMessage] = (0, import_react.useState)(false);
	const [likedComments, setLikedComments] = (0, import_react.useState)({});
	(0, import_react.useEffect)(() => {
		if (user?.displayName && !userName) setUserName(user.displayName);
	}, [user]);
	(0, import_react.useEffect)(() => {
		let isMounted = true;
		setIsLoading(true);
		getNovelComments(novelId).then((data) => {
			if (isMounted) {
				setComments(data);
				setIsLoading(false);
			}
		});
		return () => {
			isMounted = false;
		};
	}, [novelId]);
	const handleSubmit = async (e) => {
		e.preventDefault();
		if (!commentText.trim()) return;
		setIsSubmitting(true);
		soundManager.playTap();
		try {
			const added = await addNovelComment(novelId, userName || user?.displayName || "قارئ زائر", rating, commentText, userRoleTitle);
			soundManager.playRoundPass();
			setComments((prev) => [added, ...prev]);
			setCommentText("");
			setSuccessMessage(true);
			setTimeout(() => setSuccessMessage(false), 3e3);
		} catch (err) {
			console.error("Failed to post comment", err);
		} finally {
			setIsSubmitting(false);
		}
	};
	const handleLike = (commentId) => {
		if (likedComments[commentId]) return;
		soundManager.playTap();
		setLikedComments((prev) => ({
			...prev,
			[commentId]: true
		}));
		setComments((prev) => prev.map((c) => c.id === commentId ? {
			...c,
			likesCount: c.likesCount + 1
		} : c));
		likeNovelComment(commentId, novelId);
	};
	const averageRating = comments.length > 0 ? (comments.reduce((acc, c) => acc + c.rating, 0) / comments.length).toFixed(1) : "5.0";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pt-6 mt-8 border-t border-white/10 space-y-6 text-right",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-white/10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-8 h-8 rounded-xl bg-gradient-to-tr from-rose-500 to-purple-600 flex items-center justify-center text-sm shadow-md",
						children: "💬"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "font-extrabold text-sm sm:text-base text-white font-['Alexandria']",
						children: "انطباعات ومناقشات القراء والمحققين"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[11px] text-gray-400",
						children: "شارك تحليلك لمسرح الجريمة، الأكشن، الاستنتاجات، وتوقعاتك للأحداث القادمة"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center gap-2 text-xs",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1 text-amber-400 font-bold px-2.5 py-1 rounded-xl bg-amber-500/10 border border-amber-500/20",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["★ ", averageRating] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-gray-400 font-normal",
							children: [
								"(",
								comments.length,
								" تعليق)"
							]
						})]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: handleSubmit,
				className: "p-4 sm:p-5 rounded-2xl bg-white/5 border border-white/10 space-y-3.5 shadow-md",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between text-xs font-bold text-white",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1.5 text-rose-300",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-4 h-4 text-rose-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "أضف انطباعك أو تحليلك الجنائي:" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] text-gray-400 ml-1",
								children: "تقييمك:"
							}), [
								1,
								2,
								3,
								4,
								5
							].map((star) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onMouseEnter: () => setHoverRating(star),
								onMouseLeave: () => setHoverRating(0),
								onClick: () => {
									soundManager.playTap();
									setRating(star);
								},
								className: "p-0.5 text-amber-400 hover:scale-110 transition cursor-pointer",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: `w-4 h-4 ${star <= (hoverRating || rating) ? "fill-amber-400 text-amber-400" : "text-gray-600"}` })
							}, star))]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 gap-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-[11px] text-gray-400 block mb-1",
							children: "اسمك أو لقبك المستعار:"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							value: userName,
							onChange: (e) => setUserName(e.target.value),
							placeholder: user?.displayName || "مثال: المحقق فهد، سارة، باحث فلكي...",
							className: "w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-rose-400/50 transition"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-[11px] text-gray-400 block mb-1",
							children: "صفتك أو اهتمامك:"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							"aria-label": "صفتك أو اهتمامك الأدبي",
							title: "صفتك أو اهتمامك الأدبي",
							value: userRoleTitle,
							onChange: (e) => setUserRoleTitle(e.target.value),
							className: "w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-xs text-white focus:outline-none focus:border-rose-400/50 transition cursor-pointer",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "متابع للتحقيقات الجنائية",
									className: "bg-slate-900",
									children: "متابع للتحقيقات الجنائية 🔍"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "عاشق روايات الغموض والجريمة",
									className: "bg-slate-900",
									children: "عاشق روايات الغموض والجريمة 🕵️"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "محب لأكشن المطاردات والتكتيك",
									className: "bg-slate-900",
									children: "محب لأكشن المطاردات والتكتيك 🎯"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "شغوف بالخيال العلمي والمستقبل",
									className: "bg-slate-900",
									children: "شغوف بالخيال العلمي والمستقبل 🚀"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "قارئ روايات عام",
									className: "bg-slate-900",
									children: "قارئ روايات عام 📖"
								})
							]
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-[11px] text-gray-400 block mb-1",
						children: "تعليقك وانطباعك حول الأحداث والأدلة:"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: commentText,
						onChange: (e) => setCommentText(e.target.value),
						rows: 3,
						placeholder: "ما رأيك في الدليل الحاسم، تصرف المحقق، دوافع المشتبه بهم، أو المشهد الأكشن؟ شاركنا تحليلك...",
						className: "w-full p-3 rounded-xl bg-black/40 border border-white/10 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-rose-400/50 transition resize-none",
						required: true
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between pt-1",
						children: [successMessage ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs text-emerald-400 font-bold flex items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تم نشر انطباعك بنجاح! شكرًا لمشاركتك." })]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] text-gray-400",
							children: "متاح للجميع دون الحاجة لتسجيل دخول إلزامي 🌟"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "submit",
							disabled: isSubmitting || !commentText.trim(),
							className: "px-4 py-2 rounded-xl bg-gradient-to-r from-rose-600 to-purple-600 hover:opacity-95 text-white font-bold text-xs transition shadow-md flex items-center gap-1.5 cursor-pointer disabled:opacity-50",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isSubmitting ? "جارٍ النشر..." : "نشر التعليق" })]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h5", {
					className: "font-bold text-xs text-gray-300",
					children: [
						"أحدث انطباعات ومناقشات القراء (",
						comments.length,
						"):"
					]
				}), isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-center py-6 text-xs text-gray-400",
					children: "جارٍ تحميل تعليقات الرواية..."
				}) : comments.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-center py-8 rounded-2xl bg-white/5 border border-white/10 text-gray-400 text-xs",
					children: "كن أول من يشارك انطباعه وتحليله لهذه الرواية! ✨"
				}) : comments.map((c) => {
					const isLiked = likedComments[c.id];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
						initial: {
							opacity: 0,
							y: 10
						},
						animate: {
							opacity: 1,
							y: 0
						},
						className: "p-3.5 sm:p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2 shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "w-7 h-7 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 flex items-center justify-center font-bold text-xs",
										children: c.userName.charAt(0) || "ق"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-bold text-white text-xs",
											children: c.userName
										}), c.userRoleTitle && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[10px] text-gray-400 hidden sm:inline",
											children: ["· ", c.userRoleTitle]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex items-center gap-1 text-amber-400 text-[10px]",
										children: [...Array(c.rating)].map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "★" }, i))
									})] })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] text-gray-400 font-mono",
									children: c.createdAt
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-gray-200 leading-relaxed pl-2 pr-1",
								children: c.commentText
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center justify-end pt-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => handleLike(c.id),
									className: `flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer ${isLiked ? "bg-rose-500/20 text-rose-300 border border-rose-500/30" : "bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white border border-white/5"}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThumbsUp, { className: "w-3 h-3" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "مفيد" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-mono text-[10px]",
											children: [
												"(",
												c.likesCount,
												")"
											]
										})
									]
								})
							})
						]
					}, c.id);
				})]
			})
		]
	});
};
//#endregion
export { NovelCommentsSection as t };
