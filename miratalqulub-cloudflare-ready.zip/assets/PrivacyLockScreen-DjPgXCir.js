import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { $t as Delete, At as KeyRound, F as ShieldAlert, Nn as ArrowRight, bt as Lock, hn as CircleAlert } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import { a as verifyPin, r as removePinCompletely } from "./index-C5uCeetQ.js";
import { n as AnimatePresence, t as motion } from "./vendor-motion-BS7ODJw7.js";
//#region src/components/PrivacyLockScreen.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var PrivacyLockScreen = ({ onUnlock, onBackToHome }) => {
	const [pin, setPin] = (0, import_react.useState)("");
	const [errorMsg, setErrorMsg] = (0, import_react.useState)(null);
	const [isShaking, setIsShaking] = (0, import_react.useState)(false);
	const [showForgotModal, setShowForgotModal] = (0, import_react.useState)(false);
	const [resetSuccess, setResetSuccess] = (0, import_react.useState)(false);
	const handleDigitPress = (digit) => {
		if (pin.length >= 4) return;
		soundManager.playTap();
		setErrorMsg(null);
		const nextPin = pin + digit;
		setPin(nextPin);
		if (nextPin.length === 4) setTimeout(() => checkPin(nextPin), 150);
	};
	const handleBackspace = () => {
		soundManager.playTap();
		setErrorMsg(null);
		setPin((prev) => prev.slice(0, -1));
	};
	const handleClear = () => {
		soundManager.playTap();
		setErrorMsg(null);
		setPin("");
	};
	const checkPin = (codeToTest) => {
		if (verifyPin(codeToTest)) {
			soundManager.playResultReveal();
			onUnlock();
		} else {
			soundManager.playTap();
			setIsShaking(true);
			setErrorMsg("رمز المرور غير صحيح! حاول مرة أخرى");
			setTimeout(() => {
				setIsShaking(false);
				setPin("");
			}, 700);
		}
	};
	(0, import_react.useEffect)(() => {
		const handleKeyDown = (e) => {
			if (showForgotModal) return;
			if (e.key >= "0" && e.key <= "9") handleDigitPress(e.key);
			else if (e.key === "Backspace") handleBackspace();
			else if (e.key === "Escape") handleClear();
		};
		window.addEventListener("keydown", handleKeyDown);
		return () => window.removeEventListener("keydown", handleKeyDown);
	}, [pin, showForgotModal]);
	const handleResetPin = () => {
		removePinCompletely();
		setResetSuccess(true);
		setTimeout(() => {
			setShowForgotModal(false);
			onUnlock();
		}, 1200);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-[70vh] flex items-center justify-center py-6 px-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: {
				opacity: 0,
				scale: .95
			},
			animate: {
				opacity: 1,
				scale: 1
			},
			exit: {
				opacity: 0,
				scale: .95
			},
			className: "w-full max-w-sm glass-panel rounded-3xl p-6 sm:p-7 border border-rose-500/30 text-center relative overflow-hidden shadow-2xl shadow-rose-950/40",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -top-20 -right-20 w-52 h-52 bg-rose-500/20 rounded-full blur-3xl pointer-events-none" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -bottom-20 -left-20 w-52 h-52 bg-violet-600/20 rounded-full blur-3xl pointer-events-none" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative mb-4 flex justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
						animate: {
							scale: [
								1,
								1.06,
								1
							],
							boxShadow: [
								"0 0 15px rgba(244, 63, 94, 0.3)",
								"0 0 30px rgba(244, 63, 94, 0.6)",
								"0 0 15px rgba(244, 63, 94, 0.3)"
							]
						},
						transition: {
							duration: 3,
							repeat: Infinity,
							ease: "easeInOut"
						},
						className: "w-16 h-16 rounded-3xl bg-gradient-to-tr from-rose-500 to-purple-600 flex items-center justify-center text-white shadow-xl cursor-default",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "w-8 h-8" })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/20 border border-rose-500/30 text-[11px] font-bold text-rose-300 mb-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "حماية الخصوصية مفعلة" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-xl font-extrabold text-white font-['Alexandria'] mb-1",
					children: "أدخل رمز الأمان (PIN)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-gray-300 mb-6",
					children: "صفحة النتائج وهوية شريكك محمية برمز مرور مكون من 4 أرقام"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
					animate: isShaking ? { x: [
						-10,
						10,
						-10,
						10,
						0
					] } : {},
					transition: { duration: .4 },
					className: "flex justify-center items-center gap-4 mb-4",
					children: [
						0,
						1,
						2,
						3
					].map((idx) => {
						const isFilled = pin.length > idx;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
							initial: false,
							animate: {
								scale: isFilled ? 1.15 : 1,
								borderColor: isFilled ? "#fb7185" : "rgba(255,255,255,0.2)",
								backgroundColor: isFilled ? "rgba(244, 63, 94, 0.25)" : "rgba(255,255,255,0.05)",
								boxShadow: isFilled ? "0 0 14px rgba(244, 63, 94, 0.5)" : "none"
							},
							className: "w-12 h-12 rounded-2xl border-2 flex items-center justify-center transition-all duration-200",
							children: isFilled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
								initial: { scale: 0 },
								animate: { scale: 1 },
								className: "w-3.5 h-3.5 rounded-full bg-rose-400"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-2 h-2 rounded-full bg-white/20" })
						}, idx);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-6 mb-3 flex items-center justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: errorMsg && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
						initial: {
							opacity: 0,
							y: -4
						},
						animate: {
							opacity: 1,
							y: 0
						},
						exit: { opacity: 0 },
						className: "text-xs font-bold text-rose-400 flex items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "w-3.5 h-3.5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: errorMsg })]
					}) })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-3 gap-2.5 max-w-[280px] mx-auto mb-4",
					children: [
						[
							"1",
							"2",
							"3",
							"4",
							"5",
							"6",
							"7",
							"8",
							"9"
						].map((digit) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
							whileHover: {
								scale: 1.06,
								backgroundColor: "rgba(255,255,255,0.14)"
							},
							whileTap: { scale: .92 },
							onClick: () => handleDigitPress(digit),
							className: "h-13 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 text-white font-['Alexandria'] text-xl font-bold flex items-center justify-center transition cursor-pointer shadow-sm",
							children: digit
						}, digit)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
							whileHover: { scale: 1.06 },
							whileTap: { scale: .92 },
							onClick: handleClear,
							className: "h-13 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 text-gray-400 text-xs font-bold flex items-center justify-center transition cursor-pointer",
							title: "مسح",
							children: "مسح"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
							whileHover: {
								scale: 1.06,
								backgroundColor: "rgba(255,255,255,0.14)"
							},
							whileTap: { scale: .92 },
							onClick: () => handleDigitPress("0"),
							className: "h-13 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 text-white font-['Alexandria'] text-xl font-bold flex items-center justify-center transition cursor-pointer shadow-sm",
							children: "0"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
							whileHover: { scale: 1.06 },
							whileTap: { scale: .92 },
							onClick: handleBackspace,
							className: "h-13 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 text-rose-300 flex items-center justify-center transition cursor-pointer",
							title: "حذف رقم",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Delete, { className: "w-5 h-5" })
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between text-xs text-gray-400 pt-3 border-t border-white/10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setShowForgotModal(true),
						className: "hover:text-rose-300 transition underline underline-offset-4 cursor-pointer",
						children: "نسيت رمز المرور؟"
					}), onBackToHome && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onBackToHome,
						className: "hover:text-white transition flex items-center gap-1 cursor-pointer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "إعادة الاختبار" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "w-3.5 h-3.5" })]
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: showForgotModal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
			initial: { opacity: 0 },
			animate: { opacity: 1 },
			exit: { opacity: 0 },
			className: "fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					scale: .92,
					y: 10
				},
				animate: {
					scale: 1,
					y: 0
				},
				exit: {
					scale: .92,
					y: 10
				},
				className: "w-full max-w-sm glass-panel rounded-3xl p-6 border border-white/20 text-center space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center mx-auto text-amber-300",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "w-6 h-6" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "font-extrabold text-lg text-white font-['Alexandria']",
						children: "إعادة تعيين رمز الأمان"
					}),
					resetSuccess ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "p-3 rounded-2xl bg-emerald-500/20 text-emerald-300 text-xs font-bold",
						children: "تم إلغاء قفل الأمان بنجاح! جاري فتح النتيجة..."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-gray-300 leading-relaxed",
						children: "هل نسيت رمز المرور الخاص بك؟ يمكنك إلغاء قفل الأمان وفتح النتيجة مباشرة دون فقدان أي بيانات."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2 pt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
							whileHover: { scale: 1.02 },
							whileTap: { scale: .98 },
							onClick: handleResetPin,
							className: "flex-1 py-2.5 rounded-xl bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs cursor-pointer shadow-md shadow-rose-500/25",
							children: "إلغاء القفل وفتح النتيجة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
							whileHover: { scale: 1.02 },
							whileTap: { scale: .98 },
							onClick: () => setShowForgotModal(false),
							className: "flex-1 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-gray-300 font-medium text-xs cursor-pointer",
							children: "إلغاء"
						})]
					})] })
				]
			})
		}) })]
	});
};
//#endregion
export { PrivacyLockScreen };
