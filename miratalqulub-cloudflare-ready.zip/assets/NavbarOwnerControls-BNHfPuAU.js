import "./rolldown-runtime-Bk_YeHJf.js";
import { n as __vitePreload, o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { P as ShieldCheck, sn as Cloud, tn as Crown, xn as ChartColumn, yn as ChevronDown } from "./vendor-icons-WoMClU7U.js";
require_react();
var import_jsx_runtime = require_jsx_runtime();
var NavbarOwnerControls = ({ isAr, isLight, isOpen, user, onToggle, onNavAction, onNavigatePage, onOpenDomainHosting, onOpenAdSense, onOpenAnalytics }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative hidden sm:block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: onToggle,
			"aria-expanded": isOpen,
			"aria-label": isAr ? "قائمة إدارة المنصة وتحميل الملفات" : "Platform Admin & Files Menu",
			title: isAr ? "قائمة إدارة المنصة وتحميل الملفات" : "Platform Admin & Files Menu",
			className: `flex items-center gap-1 px-2.5 py-1.5 sm:py-2 rounded-xl border text-xs font-bold transition cursor-pointer ${isLight ? "bg-amber-50 border-amber-300 text-amber-900" : "bg-amber-500/20 border-amber-400/50 text-amber-300"}`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crown, { className: "w-3.5 h-3.5 text-amber-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `w-3 h-3 transition-transform ${isOpen ? "rotate-180" : ""}` })]
		}), isOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: `absolute top-full mt-2 w-72 p-2.5 rounded-2xl border shadow-2xl z-50 space-y-1.5 ${isAr ? "left-0 text-right" : "right-0 text-left"} ${isLight ? "bg-white border-slate-200 text-slate-800" : "bg-slate-950 border-amber-500/40 text-slate-100"}`,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onNavAction(async () => {
						try {
							const { downloadOwnerProtectedZip } = await __vitePreload(async () => {
								const { downloadOwnerProtectedZip } = await import("./ownerDownload-pspstBV-.js");
								return { downloadOwnerProtectedZip };
							}, []);
							await downloadOwnerProtectedZip("/api/download-cloudflare-zip", "miratalqulub-cloudflare-ready.zip", user);
						} catch {}
					}),
					className: "w-full p-2.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-400 flex items-center gap-2 text-xs font-extrabold cursor-pointer text-start",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "📦" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "تحميل ملفات الموقع للنشر (ZIP)" : "Download Ready Website (ZIP)" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onNavAction(async () => {
						try {
							const { downloadOwnerProtectedZip } = await __vitePreload(async () => {
								const { downloadOwnerProtectedZip } = await import("./ownerDownload-pspstBV-.js");
								return { downloadOwnerProtectedZip };
							}, []);
							await downloadOwnerProtectedZip("/api/download-source-zip", "miratalqulub-full-source.zip", user);
						} catch {}
					}),
					className: "w-full p-2.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-400 flex items-center gap-2 text-xs font-bold cursor-pointer text-start",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "💻" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "تحميل الكود المصدري الكامل (ZIP)" : "Download Full Source Code (ZIP)" })]
				}),
				onNavigatePage && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onNavAction(() => onNavigatePage("admin-cms")),
					className: "w-full p-2 rounded-xl hover:bg-rose-500/15 text-rose-500 flex items-center gap-2 text-xs font-bold cursor-pointer",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "w-4 h-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "مركز إدارة المحتوى والمنصة" : "CMS & Platform Audit" })]
				}),
				onOpenDomainHosting && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onNavAction(onOpenDomainHosting),
					className: "w-full p-2 rounded-xl hover:bg-blue-500/15 text-blue-500 flex items-center gap-2 text-xs font-bold cursor-pointer",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cloud, { className: "w-4 h-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "الاستضافة والدومين وتحميل الحزمة" : "Hosting & Domain" })]
				}),
				onOpenAnalytics && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onNavAction(onOpenAnalytics),
					className: "w-full p-2 rounded-xl hover:bg-emerald-500/15 text-emerald-500 flex items-center gap-2 text-xs font-bold cursor-pointer",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartColumn, { className: "w-4 h-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "إحصائيات الزوار" : "Visitor Analytics" })]
				})
			]
		})]
	});
};
//#endregion
export { NavbarOwnerControls };
