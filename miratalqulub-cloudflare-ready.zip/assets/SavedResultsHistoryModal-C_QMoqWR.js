const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/pdfReportGenerator-BNu3pVmt.js","assets/index-C5uCeetQ.js","assets/rolldown-runtime-Bk_YeHJf.js","assets/vendor-react-Bm_EF59R.js","assets/vendor-icons-WoMClU7U.js","assets/sound-C_zXqyNA.js","assets/index.es-C20Q95Ms.js","assets/firebase-Cu7XUsbK.js","assets/firebaseAuth-D6LKvzXg.js","assets/index-DMmCvB5f.css"])))=>i.map(i=>d[i]);
import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { n as __vitePreload, o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { En as Brain, Gt as FileDown, J as RefreshCw, Jt as Eye, Nt as History, P as ShieldCheck, Sn as Calendar, V as Search, Vt as Funnel, Xt as ExternalLink, h as Trash2, m as TrendingUp, r as X } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import { u as useAuth } from "./index-C5uCeetQ.js";
import { n as AnimatePresence, t as motion } from "./vendor-motion-BS7ODJw7.js";
import { a as fetchUnifiedTestHistory, n as deleteSavedResultFromHistory, o as fetchUserSavedResults, r as deleteUnifiedTestRecord, t as buildTemporalEvolutionSummary } from "./userHistoryService-6N9Zh8ed.js";
import { t as SkeletonLoader } from "./SkeletonLoader-Dpq6Gy3u.js";
//#region src/components/SavedResultsHistoryModal.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var SavedResultsHistoryModal = ({ isOpen, onClose, onOpenAuth, onLoadHistoricalResult }) => {
	const { user, logout } = useAuth();
	const [activeTab, setActiveTab] = (0, import_react.useState)("unified");
	const [results, setResults] = (0, import_react.useState)([]);
	const [unifiedRecords, setUnifiedRecords] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [deletingId, setDeletingId] = (0, import_react.useState)(null);
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [typeFilter, setTypeFilter] = (0, import_react.useState)("all");
	const [tierFilter, setTierFilter] = (0, import_react.useState)("all");
	const [reopenedRecord, setReopenedRecord] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (isOpen) loadHistory();
	}, [isOpen, user]);
	const loadHistory = async () => {
		setLoading(true);
		try {
			const [partnerData, unifiedData] = await Promise.all([fetchUserSavedResults(user), fetchUnifiedTestHistory(user)]);
			setResults(partnerData);
			setUnifiedRecords(unifiedData);
		} catch (e) {
			console.error("Failed to load saved results", e);
		}
		setLoading(false);
	};
	const handleDelete = async (resultId) => {
		soundManager.playTap();
		setDeletingId(resultId);
		try {
			await deleteSavedResultFromHistory(user, resultId);
			setResults((prev) => prev.filter((r) => r.id !== resultId));
		} catch (e) {
			console.error("Failed to delete result", e);
		}
		setDeletingId(null);
	};
	const handleDeleteUnified = async (recordId) => {
		soundManager.playTap();
		setDeletingId(recordId);
		try {
			await deleteUnifiedTestRecord(user, recordId);
			setUnifiedRecords((prev) => prev.filter((r) => r.id !== recordId));
			if (reopenedRecord?.id === recordId) setReopenedRecord(null);
		} catch (e) {
			console.error("Failed to delete unified record", e);
		}
		setDeletingId(null);
	};
	const handleDownloadUnifiedPdf = async (rec) => {
		soundManager.playTap();
		const { exportPsychometricReportAsPDF } = await __vitePreload(async () => {
			const { exportPsychometricReportAsPDF } = await import("./pdfReportGenerator-BNu3pVmt.js");
			return { exportPsychometricReportAsPDF };
		}, __vite__mapDeps([0,1,2,3,4,5,6,7,8,9]));
		if (rec.snapshot && rec.snapshot.subscales && rec.snapshot.visualCharts) {
			const rep = rec.snapshot;
			exportPsychometricReportAsPDF({
				reportTitle: `${rep.tierTitleAr} — التقرير السيكومتري الشامل`,
				subTitle: `${rep.archetypeTitleAr} (${rep.answeredCount}/${rep.questionCount} سؤالاً)`,
				scientificBasis: (rep.scientificReferences || []).join(" • "),
				userName: rep.userName,
				completedAt: new Date(rec.createdAt).toLocaleDateString("ar-JO"),
				overallScoreLabel: "مؤشر النضج السيكومتري الكلي",
				overallScoreValue: `${rep.overallMaturityIndex}%`,
				cognitiveFingerprintTitle: `الاتساق الداخلي ${rep.consistencyIndex}% • المعيارية ${rep.overallPercentile}%`,
				executiveSummary: rep.executiveSummaryAr,
				metrics: (rep.subscales || []).slice(0, 14).map((s) => ({
					label: s.labelAr,
					scorePercent: s.percentage,
					levelLabel: `Sten ${s.stenScore}/10 • T=${s.tScore}`,
					rawText: s.interpretationAr,
					color: s.color
				})),
				sections: [{
					title: "وصف الشخصية الأساسي والتركيبة النفسية",
					content: rep.personalityDescriptionAr || ""
				}, {
					title: "نقاط القوة ومجالات التحسين",
					content: rep.emotionalMaturitySummaryAr || "",
					items: [...rep.strengthsAr || [], ...rep.improvementAreasAr || []]
				}],
				visualCharts: rep.visualCharts
			});
			return;
		}
		exportPsychometricReportAsPDF({
			reportTitle: rec.testTitleAr,
			subTitle: rec.testCategoryAr,
			scientificBasis: "APA Validated Psychometric Models • Mirror of Hearts Lab",
			userName: user?.displayName || "المختبَر",
			completedAt: new Date(rec.createdAt).toLocaleDateString("ar-JO"),
			overallScoreLabel: "النتيجة المعيارية",
			overallScoreValue: rec.scoreOrArchetype,
			cognitiveFingerprintTitle: rec.testTitleAr,
			executiveSummary: (rec.keyInsights || []).join(" — ") || rec.scoreOrArchetype,
			metrics: Object.entries(rec.standardizedScores || {}).map(([k, v]) => ({
				label: k,
				scorePercent: Number(v) || rec.percentage,
				levelLabel: "معياري معتمد",
				color: rec.badgeColor || "#8b5cf6"
			})),
			sections: [{
				title: "أبرز المؤشرات السيكومترية المحفوظة",
				content: rec.scoreOrArchetype,
				items: rec.keyInsights || []
			}]
		});
	};
	const handleSelectResult = (item) => {
		soundManager.playTap();
		if (onLoadHistoricalResult && item.profileSnapshot && item.fullResultSnapshot) {
			onLoadHistoricalResult(item.profileSnapshot, item.fullResultSnapshot);
			onClose();
		}
	};
	if (!isOpen) return null;
	const evolution = buildTemporalEvolutionSummary(unifiedRecords);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: {
				opacity: 0,
				scale: .95,
				y: 15
			},
			animate: {
				opacity: 1,
				scale: 1,
				y: 0
			},
			exit: {
				opacity: 0,
				scale: .95,
				y: 15
			},
			className: "relative w-full max-w-3xl max-h-[92vh] flex flex-col p-5 sm:p-6 overflow-hidden glass-panel rounded-3xl border border-rose-500/30 shadow-2xl text-white",
			dir: "rtl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between pb-4 border-b border-white/10 shrink-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-10 h-10 rounded-2xl bg-gradient-to-tr from-rose-500 to-purple-600 flex items-center justify-center text-white shadow-md shadow-rose-500/25",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "w-5 h-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-lg sm:text-xl font-black font-['Alexandria']",
							children: "سجل تقاريري وتتبع التغير مع الزمن"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-gray-300",
							children: user ? `الحساب: ${user.displayName || user.email || "مستخدم مسجل"}` : "سجل الزائر المستمر (محفوظ تلقائياً في قاعدة البيانات)"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: loadHistory,
							disabled: loading,
							"aria-label": "تحديث السجل من قاعدة البيانات",
							title: "تحديث السجل من قاعدة البيانات",
							className: "p-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white transition-colors cursor-pointer",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `w-4 h-4 ${loading ? "animate-spin" : ""}` })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								soundManager.playTap();
								onClose();
							},
							"aria-label": "إغلاق نافذة سجل التقارير",
							className: "p-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white transition-colors cursor-pointer",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-5 h-5" })
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2 p-1 rounded-2xl bg-black/40 border border-white/10 mt-3 shrink-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setActiveTab("unified"),
						className: `py-2 px-3 rounded-xl text-xs font-extrabold transition cursor-pointer ${activeTab === "unified" ? "bg-purple-600 text-white shadow-md" : "text-gray-400 hover:text-white"}`,
						children: [
							"سجل التقارير الشامل وتتبع الزمن (",
							unifiedRecords.length,
							")"
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setActiveTab("partner"),
						className: `py-2 px-3 rounded-xl text-xs font-extrabold transition cursor-pointer ${activeTab === "partner" ? "bg-rose-600 text-white shadow-md" : "text-gray-400 hover:text-white"}`,
						children: [
							"بطاقات توافق الشريك (",
							results.length,
							")"
						]
					})]
				}),
				!user && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 p-3 rounded-2xl bg-blue-950/40 border border-blue-500/30 flex items-center justify-between gap-2 text-xs shrink-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-blue-200",
						children: "✓ نتائجك محفوظة تلقائياً في قاعدة بيانات الموقع لهذا المتصفح. يمكنك أيضاً ربطها بحسابك للوصول إليها من أي جهاز آخر."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							soundManager.playTap();
							onOpenAuth();
						},
						className: "px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold shrink-0 cursor-pointer",
						children: "ربط بحساب"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex-1 overflow-y-auto py-4 space-y-3.5 pr-1",
					children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "py-2 space-y-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkeletonLoader, {
							type: "history_card",
							count: 3
						})
					}) : activeTab === "unified" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-4 rounded-2xl bg-emerald-950/30 border border-emerald-500/30 space-y-2.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
											className: "text-xs sm:text-sm font-extrabold flex items-center gap-1.5 text-emerald-300",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تتبع التغير مع الزمن (العام الماضي ← الشهر الماضي ← اليوم)" })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-black text-emerald-400 tabular-nums",
											children: evolution.trendDelta >= 0 ? `+${evolution.trendDelta}%` : `${evolution.trendDelta}%`
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[11px] text-gray-300",
										children: evolution.trendInsightAr
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-3 gap-2 text-center text-xs",
										children: evolution.buckets.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-2.5 rounded-xl bg-black/40 border border-white/10",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-[10px] text-gray-400 font-bold",
													children: b.periodLabelAr
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-base font-black text-emerald-400 tabular-nums",
													children: b.count > 0 ? `${b.avgScore}%` : "—"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "text-[10px] text-gray-400",
													children: [b.count, " اختبار"]
												})
											]
										}, b.periodKey))
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-3 gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative sm:col-span-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "w-3.5 h-3.5 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "text",
										"aria-label": "ابحث في سجل تقاريري",
										placeholder: "ابحث باسم التقرير أو النمط أو المستوى...",
										value: searchQuery,
										onChange: (e) => setSearchQuery(e.target.value),
										className: "w-full pr-8 pl-3 py-2 rounded-xl bg-black/40 border border-white/15 text-xs text-white outline-none"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									"aria-label": "تصفية حسب مستوى التحليل",
									value: tierFilter,
									onChange: (e) => setTierFilter(e.target.value),
									className: "px-3 py-2 rounded-xl bg-black/40 border border-white/15 text-xs text-white outline-none",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "all",
											children: "كل المستويات"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "quick",
											children: "التحليل السريع (32)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "advanced",
											children: "التحليل المتقدم (144)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "professional",
											children: "التحليل الاحترافي (288)"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px] font-bold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { className: "w-3.5 h-3.5 text-gray-400 shrink-0" }), [
									{
										id: "all",
										label: "الكل"
									},
									{
										id: "tiered_assessment",
										label: "مستويات التحليل"
									},
									{
										id: "personality_comparison",
										label: "مقارنة شخصيتين"
									},
									{
										id: "psychology",
										label: "المقاييس النفسية"
									},
									{
										id: "intelligence",
										label: "اختبارات الذكاء"
									},
									{
										id: "partner_compatibility",
										label: "توافق الشريك"
									}
								].map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setTypeFilter(f.id),
									className: `px-2.5 py-1 rounded-lg transition cursor-pointer shrink-0 ${typeFilter === f.id ? "bg-purple-600 text-white" : "bg-white/5 text-gray-300"}`,
									children: f.label
								}, f.id))]
							}),
							unifiedRecords.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "py-10 text-center text-xs text-gray-400",
								children: "لا توجد تقارير محفوظة بعد. أكمل أي اختبار لحفظ التقرير والدرجات الخام والمعيارية هنا."
							}) : unifiedRecords.filter((r) => typeFilter === "all" ? true : r.testType === typeFilter).filter((r) => tierFilter === "all" ? true : r.analysisTier === tierFilter).filter((r) => {
								const q = searchQuery.trim().toLowerCase();
								if (!q) return true;
								return r.testTitleAr.toLowerCase().includes(q) || r.scoreOrArchetype.toLowerCase().includes(q) || r.testCategoryAr.toLowerCase().includes(q);
							}).map((rec) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-bold text-sm text-white",
											children: rec.testTitleAr
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[11px] text-purple-300",
											children: rec.scoreOrArchetype
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-[10px] text-gray-400 mt-0.5",
											children: [
												new Date(rec.createdAt).toLocaleString("ar-SA"),
												" · ",
												rec.testCategoryAr
											]
										})
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => setReopenedRecord(reopenedRecord?.id === rec.id ? null : rec),
												className: "px-3 py-1.5 rounded-xl bg-purple-600/30 hover:bg-purple-600/50 border border-purple-500/40 text-purple-200 text-xs font-bold flex items-center gap-1 cursor-pointer",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "فتح التقرير" })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => handleDownloadUnifiedPdf(rec),
												className: "px-3 py-1.5 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/35 border border-indigo-500/40 text-indigo-200 text-xs font-bold flex items-center gap-1 cursor-pointer",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileDown, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "PDF" })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => handleDeleteUnified(rec.id),
												disabled: deletingId === rec.id,
												"aria-label": "حذف هذا التقرير",
												className: "p-1.5 rounded-xl bg-white/5 hover:bg-rose-500/20 text-gray-400 hover:text-rose-400 cursor-pointer",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "w-4 h-4" })
											})
										]
									})]
								}), reopenedRecord?.id === rec.id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3.5 rounded-xl bg-black/50 border border-purple-500/30 text-xs space-y-2 mt-2",
									children: [rec.snapshot?.executiveSummaryAr && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-gray-200 leading-relaxed",
										children: rec.snapshot.executiveSummaryAr
									}), rec.keyInsights && rec.keyInsights.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "space-y-1 text-emerald-300",
										children: rec.keyInsights.map((k, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["• ", k] }, idx))
									})]
								})]
							}, rec.id))
						]
					}) : results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "py-12 text-center space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "w-10 h-10 text-rose-400 mx-auto" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "text-base font-bold text-white mb-1",
							children: "لا توجد نتائج توافق شريك محفوظة بعد"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-gray-300 max-w-xs mx-auto",
							children: "عند إتمام اختبار توافق الشريك، اضغط على زر «حفظ النتيجة في حسابي» لتظهر هنا بشكل دائم."
						})] })]
					}) : results.map((res) => {
						const dateStr = new Date(res.createdAt).toLocaleDateString("ar-SA", {
							year: "numeric",
							month: "short",
							day: "numeric",
							hour: "2-digit",
							minute: "2-digit"
						});
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-2xl bg-white/5 border border-white/10 hover:border-rose-500/40 transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-md",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [res.imageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: res.imageUrl,
									alt: res.partnerName,
									className: "w-14 h-14 rounded-2xl object-cover border border-rose-500/30 shrink-0"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-14 h-14 rounded-2xl bg-gradient-to-tr from-rose-500/20 to-purple-500/20 border border-white/10 flex items-center justify-center text-xl shrink-0",
									children: res.partnerGender === "female" ? "👩" : "👨"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-bold text-sm sm:text-base text-white",
											children: res.partnerName
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 text-[11px] font-black border border-rose-500/30",
											children: [res.compatibilityScore, "% توافق"]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center gap-2 text-xs text-gray-400",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex items-center gap-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "w-3 h-3 text-gray-400" }), dateStr]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: res.country })
										]
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 w-full sm:w-auto justify-end pt-2 sm:pt-0 border-t sm:border-t-0 border-white/5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: async () => {
											soundManager.playTap();
											const { exportPsychometricReportAsPDF } = await __vitePreload(async () => {
												const { exportPsychometricReportAsPDF } = await import("./pdfReportGenerator-BNu3pVmt.js");
												return { exportPsychometricReportAsPDF };
											}, __vite__mapDeps([0,1,2,3,4,5,6,7,8,9]));
											exportPsychometricReportAsPDF({
												reportTitle: `تقرير التوافق السيكومتري المحفوظ — ${res.partnerName}`,
												subTitle: "Saved Partner Compatibility Psychometric Report",
												scientificBasis: "Gottman (1999) • Bowlby/ECR-R • Sternberg • Bowen • Schwartz",
												userName: res.country,
												completedAt: dateStr,
												overallScoreLabel: "مؤشر التوافق الكلي الموزون",
												overallScoreValue: `${res.compatibilityScore}%`,
												cognitiveFingerprintTitle: `${res.partnerName} (${res.country})`,
												executiveSummary: `تقرير توافق محفوظ في قاعدة البيانات بنسبة توافق كلي (${res.compatibilityScore}%)، وتناغم فكري (${res.intellectualScore}%)، واجتماعي (${res.sociologicalScore}%)، وعاطفي (${res.emotionalScore}%).`,
												metrics: [
													{
														label: "التوافق الفكري والتعليمي (Intellectual Synergy)",
														scorePercent: res.intellectualScore || 88,
														levelLabel: "معياري موثق",
														color: "#8b5cf6"
													},
													{
														label: "التوافق الاجتماعي والعائلي (Sociological Harmony)",
														scorePercent: res.sociologicalScore || 86,
														levelLabel: "معياري موثق",
														color: "#06b6d4"
													},
													{
														label: "الذكاء العاطفي والاستقرار (Emotional Intelligence)",
														scorePercent: res.emotionalScore || 90,
														levelLabel: "معياري موثق",
														color: "#10b981"
													},
													{
														label: "انسجام نمط الحياة والأهداف (Lifestyle Alignment)",
														scorePercent: res.lifestyleScore || 87,
														levelLabel: "معياري موثق",
														color: "#f43f5e"
													}
												],
												sections: [{
													title: "ملخص أبعاد التوافق المحفوظة",
													badge: `${res.compatibilityScore}% توافق`,
													content: res.fullResultSnapshot?.detailedMatchReason || `تم حساب هذا التقرير بناءً على إجاباتك الفعلية وتفضيلاتك الديموغرافية في (${res.country}).`
												}]
											});
										},
										className: "px-3 py-1.5 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-200 border border-indigo-500/35 font-bold text-xs flex items-center gap-1 transition-colors cursor-pointer",
										title: "تصدير التقرير بصيغة PDF",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileDown, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "PDF 📄" })]
									}),
									onLoadHistoricalResult && res.profileSnapshot && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => handleSelectResult(res),
										className: "px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 font-bold text-xs flex items-center gap-1 transition-colors cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "فتح التقرير" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => handleDelete(res.id),
										disabled: deletingId === res.id,
										"aria-label": "حذف من السجل",
										title: "حذف من السجل",
										className: "p-1.5 rounded-xl bg-white/5 hover:bg-rose-500/20 text-gray-400 hover:text-rose-400 transition-colors disabled:opacity-50 cursor-pointer",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "w-4 h-4" })
									})
								]
							})]
						}, res.id);
					})
				}),
				user && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pt-3 border-t border-white/10 flex items-center justify-between text-xs text-gray-400 shrink-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "w-3.5 h-3.5 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "النتائج محفوظة بأمان ومحمية بقواعد أمان Firebase Firestore" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							logout();
							onClose();
						},
						className: "text-gray-400 hover:text-rose-400 transition-colors",
						children: "تسجيل الخروج"
					})]
				})
			]
		})
	}) });
};
//#endregion
export { SavedResultsHistoryModal };
