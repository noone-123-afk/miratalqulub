import { n as CONSTRUCT_SCIENTIFIC_CATALOG, r as getQuestionsForAnalysisTier, t as ANALYSIS_TIERS_CATALOG } from "./data-tiered-assessment-ByFodY9o.js";
//#region src/utils/personalityComparisonEngine.ts
function clampScore(n) {
	if (!Number.isFinite(n)) return 50;
	return Math.max(0, Math.min(100, Math.round(n)));
}
function similarityMatch(a, b) {
	return clampScore(100 - Math.abs(a - b));
}
function balancedMatch(a, b) {
	const diff = Math.abs(a - b);
	if (diff <= 15) return clampScore(100 - diff * .5);
	return clampScore(100 - diff * .9);
}
function profileFromTieredReport(report, overrideName) {
	const sub = (k, fallback = 65) => report.subscales.find((s) => s.key === k)?.percentage ?? fallback;
	const attStyle = report.visualCharts?.attachment?.styleAr || "نمط التعلق الآمن";
	const topComm = [...report.visualCharts?.communicationStyles || []].sort((a, b) => b.score - a.score)[0]?.style || "الحزم المحترم";
	const topConf = [...report.visualCharts?.conflictModes || []].sort((a, b) => b.score - a.score)[0]?.mode || "التعاون التكاملي";
	return {
		personName: overrideName || report.userName || "المختبَر",
		personLabelAr: `${overrideName || report.userName} (${report.tierTitleAr})`,
		sourceType: "tiered_report",
		bigFive: {
			openness: sub("bf_openness"),
			conscientiousness: sub("bf_conscientiousness"),
			extraversion: sub("bf_extraversion"),
			agreeableness: sub("bf_agreeableness"),
			emotionalStability: sub("bf_emotional_stability")
		},
		hexaco: {
			honestyHumility: sub("hx_honesty_humility"),
			emotionality: sub("hx_emotionality"),
			extraversion: sub("hx_extraversion"),
			agreeableness: sub("hx_agreeableness"),
			conscientiousness: sub("hx_conscientiousness"),
			openness: sub("hx_openness")
		},
		attachment: {
			anxiety: sub("att_anxiety", 32),
			avoidance: sub("att_avoidance", 30),
			styleAr: attStyle
		},
		emotionalIntelligence: clampScore((sub("ei_self_awareness") + sub("ei_empathy") + sub("ei_regulation") + sub("ei_social_skill")) / 4),
		communicationStyle: {
			assertive: sub("com_assertive"),
			reflective: sub("com_reflective"),
			analytical: sub("com_analytical"),
			expressive: sub("com_expressive"),
			primaryAr: topComm
		},
		conflictResolution: {
			collaborating: sub("com_collaborating"),
			compromising: clampScore((sub("bf_agreeableness") + sub("com_assertive")) / 2),
			accommodating: sub("hx_agreeableness"),
			competing: clampScore(sub("com_assertive") * .6 + (100 - sub("bf_agreeableness")) * .4),
			avoiding: sub("att_avoidance", 30),
			primaryAr: topConf
		},
		valuesScore: sub("pp_values_meaning"),
		lifeGoals: {
			familyStability: sub("int_parenting_family"),
			careerGrowth: sub("sr_goal_persistence"),
			intellectualDepth: sub("bf_openness"),
			socialHarmony: sub("ei_social_skill"),
			financialSecurity: sub("bf_conscientiousness")
		},
		parentingOrientation: sub("int_parenting_family")
	};
}
function profileFromUnifiedRecord(record, overrideName) {
	const snap = record.snapshot;
	if (snap && snap.subscales && snap.visualCharts) return profileFromTieredReport(snap, overrideName);
	const basePct = clampScore(record.percentage || 70);
	const std = record.standardizedScores || {};
	const dimScores = snap?.dimensionScores || [];
	const findDim = (kw, fb) => dimScores.find((d) => d.key?.includes(kw))?.score ?? std[kw] ?? fb;
	const openness = clampScore(findDim("openness", basePct));
	const conscientiousness = clampScore(findDim("conscientious", findDim("rule", basePct)));
	const extraversion = clampScore(findDim("extraversion", findDim("warmth", Math.max(40, basePct - 6))));
	const agreeableness = clampScore(findDim("agreeable", findDim("warmth", basePct)));
	const emotionalStability = clampScore(findDim("stability", basePct));
	return {
		personName: overrideName || snap?.userName || record.testTitleAr.slice(0, 28),
		personLabelAr: `${overrideName || record.testTitleAr} (${basePct}%)`,
		sourceType: "saved_record",
		bigFive: {
			openness,
			conscientiousness,
			extraversion,
			agreeableness,
			emotionalStability
		},
		hexaco: {
			honestyHumility: clampScore((conscientiousness + agreeableness) / 2),
			emotionality: clampScore(100 - emotionalStability * .5),
			extraversion,
			agreeableness,
			conscientiousness,
			openness
		},
		attachment: {
			anxiety: clampScore(100 - emotionalStability),
			avoidance: clampScore(100 - agreeableness * .8),
			styleAr: emotionalStability >= 60 ? "ارتباط متزن مستقر" : "ارتباط حساس يحتاج لطمأنة"
		},
		emotionalIntelligence: clampScore((agreeableness + emotionalStability) / 2),
		communicationStyle: {
			assertive: clampScore((conscientiousness + extraversion) / 2),
			reflective: agreeableness,
			analytical: openness,
			expressive: clampScore((extraversion + agreeableness) / 2),
			primaryAr: openness >= conscientiousness ? "تواصل تحليلي متفتح" : "تواصل منظم متزن"
		},
		conflictResolution: {
			collaborating: clampScore((agreeableness + emotionalStability + conscientiousness) / 3),
			compromising: agreeableness,
			accommodating: clampScore(agreeableness * .8),
			competing: clampScore(100 - agreeableness * .6),
			avoiding: clampScore(100 - extraversion * .5),
			primaryAr: "التعاون البناء"
		},
		valuesScore: clampScore((conscientiousness + agreeableness) / 2),
		lifeGoals: {
			familyStability: clampScore((agreeableness + emotionalStability) / 2),
			careerGrowth: clampScore((conscientiousness + openness) / 2),
			intellectualDepth: openness,
			socialHarmony: extraversion,
			financialSecurity: conscientiousness
		},
		parentingOrientation: clampScore((agreeableness + conscientiousness + emotionalStability) / 3)
	};
}
function profileFromQuestionnaireOrCommunity(source, overrideName) {
	const isCommunity = "dimensionScores" in source;
	const dims = isCommunity ? source.dimensionScores : {
		extraversion: source.socialEnergyStyle ? 74 : 68,
		emotionalStability: source.stressResponseStyle ? 82 : 68,
		openness: source.intellectualPassion ? 84 : 70,
		agreeableness: source.conflictResolutionProtocol ? 85 : 72,
		conscientiousness: source.financialManagementVision ? 84 : 72
	};
	const name = overrideName || (isCommunity ? source.displayName : source.fullName || "ملف الاستبيان الشخصي");
	return {
		personName: name,
		personLabelAr: name,
		sourceType: "profile_questionnaire",
		bigFive: {
			openness: clampScore(dims.openness),
			conscientiousness: clampScore(dims.conscientiousness),
			extraversion: clampScore(dims.extraversion),
			agreeableness: clampScore(dims.agreeableness),
			emotionalStability: clampScore(dims.emotionalStability)
		},
		hexaco: {
			honestyHumility: clampScore((dims.conscientiousness + dims.agreeableness) / 2 + 4),
			emotionality: clampScore(100 - dims.emotionalStability * .45),
			extraversion: clampScore(dims.extraversion),
			agreeableness: clampScore(dims.agreeableness),
			conscientiousness: clampScore(dims.conscientiousness),
			openness: clampScore(dims.openness)
		},
		attachment: {
			anxiety: clampScore(100 - dims.emotionalStability),
			avoidance: clampScore(100 - dims.agreeableness * .85),
			styleAr: dims.emotionalStability >= 70 ? "ارتباط آمن" : "ارتباط حساس نسبياً"
		},
		emotionalIntelligence: clampScore((dims.emotionalStability + dims.agreeableness) / 2),
		communicationStyle: {
			assertive: clampScore((dims.conscientiousness + dims.extraversion) / 2),
			reflective: clampScore(dims.agreeableness),
			analytical: clampScore(dims.openness),
			expressive: clampScore(dims.extraversion),
			primaryAr: dims.openness >= dims.extraversion ? "التحليل والحوار العميق" : "التواصل الدافئ التفاعلي"
		},
		conflictResolution: {
			collaborating: clampScore((dims.agreeableness + dims.emotionalStability) / 2),
			compromising: clampScore(dims.agreeableness),
			accommodating: clampScore(dims.agreeableness * .8),
			competing: clampScore(100 - dims.agreeableness * .5),
			avoiding: clampScore(100 - dims.extraversion * .5),
			primaryAr: "الإصلاح التشاركي"
		},
		valuesScore: clampScore((dims.conscientiousness + dims.agreeableness) / 2 + 3),
		lifeGoals: {
			familyStability: clampScore((dims.agreeableness + dims.emotionalStability) / 2),
			careerGrowth: clampScore((dims.conscientiousness + dims.openness) / 2),
			intellectualDepth: clampScore(dims.openness),
			socialHarmony: clampScore(dims.extraversion),
			financialSecurity: clampScore(dims.conscientiousness)
		},
		parentingOrientation: clampScore((dims.agreeableness + dims.conscientiousness) / 2)
	};
}
function compareTwoPsychometricProfiles(personA, personB) {
	const bigFiveA = clampScore((personA.bigFive.openness + personA.bigFive.conscientiousness + personA.bigFive.extraversion + personA.bigFive.agreeableness + personA.bigFive.emotionalStability) / 5);
	const bigFiveB = clampScore((personB.bigFive.openness + personB.bigFive.conscientiousness + personB.bigFive.extraversion + personB.bigFive.agreeableness + personB.bigFive.emotionalStability) / 5);
	const hexacoA = clampScore((personA.hexaco.honestyHumility + personA.hexaco.agreeableness + personA.hexaco.conscientiousness + personA.hexaco.openness + personA.hexaco.extraversion + (100 - Math.abs(personA.hexaco.emotionality - 55) * .4)) / 6);
	const hexacoB = clampScore((personB.hexaco.honestyHumility + personB.hexaco.agreeableness + personB.hexaco.conscientiousness + personB.hexaco.openness + personB.hexaco.extraversion + (100 - Math.abs(personB.hexaco.emotionality - 55) * .4)) / 6);
	const attSecA = clampScore(100 - (personA.attachment.anxiety * .5 + personA.attachment.avoidance * .5));
	const attSecB = clampScore(100 - (personB.attachment.anxiety * .5 + personB.attachment.avoidance * .5));
	const commCapA = clampScore((personA.communicationStyle.assertive + personA.communicationStyle.reflective + personA.communicationStyle.analytical + personA.communicationStyle.expressive) / 4);
	const commCapB = clampScore((personB.communicationStyle.assertive + personB.communicationStyle.reflective + personB.communicationStyle.analytical + personB.communicationStyle.expressive) / 4);
	const confCapA = clampScore(personA.conflictResolution.collaborating * .55 + personA.conflictResolution.compromising * .3 + (100 - personA.conflictResolution.avoiding) * .15);
	const confCapB = clampScore(personB.conflictResolution.collaborating * .55 + personB.conflictResolution.compromising * .3 + (100 - personB.conflictResolution.avoiding) * .15);
	const goalsMeanA = clampScore((personA.lifeGoals.familyStability + personA.lifeGoals.careerGrowth + personA.lifeGoals.intellectualDepth + personA.lifeGoals.socialHarmony + personA.lifeGoals.financialSecurity) / 5);
	const goalsMeanB = clampScore((personB.lifeGoals.familyStability + personB.lifeGoals.careerGrowth + personB.lifeGoals.intellectualDepth + personB.lifeGoals.socialHarmony + personB.lifeGoals.financialSecurity) / 5);
	const bfTraitMatch = (similarityMatch(personA.bigFive.openness, personB.bigFive.openness) + similarityMatch(personA.bigFive.conscientiousness, personB.bigFive.conscientiousness) + balancedMatch(personA.bigFive.extraversion, personB.bigFive.extraversion) + similarityMatch(personA.bigFive.agreeableness, personB.bigFive.agreeableness) + similarityMatch(personA.bigFive.emotionalStability, personB.bigFive.emotionalStability)) / 5;
	const hxTraitMatch = (similarityMatch(personA.hexaco.honestyHumility, personB.hexaco.honestyHumility) + similarityMatch(personA.hexaco.agreeableness, personB.hexaco.agreeableness) + similarityMatch(personA.hexaco.conscientiousness, personB.hexaco.conscientiousness) + similarityMatch(personA.hexaco.openness, personB.hexaco.openness) + balancedMatch(personA.hexaco.extraversion, personB.hexaco.extraversion) + similarityMatch(personA.hexaco.emotionality, personB.hexaco.emotionality)) / 6;
	const pursueWithdrawPenalty = (Math.max(0, personA.attachment.anxiety - 55) * Math.max(0, personB.attachment.avoidance - 55) + Math.max(0, personB.attachment.anxiety - 55) * Math.max(0, personA.attachment.avoidance - 55)) * .012;
	const attMatch = clampScore(similarityMatch(personA.attachment.anxiety, personB.attachment.anxiety) * .45 + similarityMatch(personA.attachment.avoidance, personB.attachment.avoidance) * .45 + (attSecA + attSecB) / 2 * .1 - pursueWithdrawPenalty);
	const eiMatch = clampScore(similarityMatch(personA.emotionalIntelligence, personB.emotionalIntelligence) * .75 + Math.min(personA.emotionalIntelligence, personB.emotionalIntelligence) * .25);
	const commMatch = clampScore((similarityMatch(personA.communicationStyle.assertive, personB.communicationStyle.assertive) + similarityMatch(personA.communicationStyle.reflective, personB.communicationStyle.reflective) + similarityMatch(personA.communicationStyle.analytical, personB.communicationStyle.analytical) + balancedMatch(personA.communicationStyle.expressive, personB.communicationStyle.expressive)) / 4);
	const conflictMatch = clampScore(similarityMatch(personA.conflictResolution.collaborating, personB.conflictResolution.collaborating) * .5 + similarityMatch(personA.conflictResolution.compromising, personB.conflictResolution.compromising) * .3 + similarityMatch(personA.conflictResolution.avoiding, personB.conflictResolution.avoiding) * .2);
	const valuesMatch = similarityMatch(personA.valuesScore, personB.valuesScore);
	const goalsMatch = clampScore((similarityMatch(personA.lifeGoals.familyStability, personB.lifeGoals.familyStability) + similarityMatch(personA.lifeGoals.careerGrowth, personB.lifeGoals.careerGrowth) + similarityMatch(personA.lifeGoals.intellectualDepth, personB.lifeGoals.intellectualDepth) + similarityMatch(personA.lifeGoals.socialHarmony, personB.lifeGoals.socialHarmony) + similarityMatch(personA.lifeGoals.financialSecurity, personB.lifeGoals.financialSecurity)) / 5);
	const parentingMatch = similarityMatch(personA.parentingOrientation, personB.parentingOrientation);
	const nineAxesBreakdown = [
		{
			axisKey: "big_five",
			axisNameAr: "العوامل الخمسة الكبرى (Big Five)",
			personAScore: bigFiveA,
			personBScore: bigFiveB,
			delta: Math.abs(bigFiveA - bigFiveB),
			matchScore: clampScore(bfTraitMatch),
			scientificNoteAr: bfTraitMatch >= 75 ? "تقارب قوي في البنية الشخصية اليومية والانضباط والتعاون." : "تباين في الإيقاع السلوكي يتطلب تفاهماً على المساحة والتنظيم."
		},
		{
			axisKey: "hexaco",
			axisNameAr: "نموذج هيكساكو والنزاهة (HEXACO)",
			personAScore: hexacoA,
			personBScore: hexacoB,
			delta: Math.abs(hexacoA - hexacoB),
			matchScore: clampScore(hxTraitMatch),
			scientificNoteAr: hxTraitMatch >= 75 ? "انسجام عالٍ في الصدق-التواضع والشفافية الأخلاقية." : "فجوة في التوقعات الأخلاقية أو التعبير العاطفي تستوجب الصراحة."
		},
		{
			axisKey: "attachment",
			axisNameAr: "أنماط التعلق والارتباط (ECR-R)",
			personAScore: attSecA,
			personBScore: attSecB,
			delta: Math.abs(attSecA - attSecB),
			matchScore: attMatch,
			scientificNoteAr: pursueWithdrawPenalty > 8 ? "تنبيه ديناميكية الملاحقة-الانسحاب (Anxious vs Avoidant)؛ ينصح بطقوس طمأنة وحدود واضحة." : attMatch >= 75 ? "أمان ارتباطي متناغم يتيح القرب الدافئ دون خوف أو اختناق." : "اختلاف في الحاجة للقرب العاطفي؛ يُبنى التوازن عبر الوضوح التدريجي."
		},
		{
			axisKey: "emotional_intelligence",
			axisNameAr: "الذكاء العاطفي والتعاطف (EI)",
			personAScore: personA.emotionalIntelligence,
			personBScore: personB.emotionalIntelligence,
			delta: Math.abs(personA.emotionalIntelligence - personB.emotionalIntelligence),
			matchScore: eiMatch,
			scientificNoteAr: eiMatch >= 75 ? "كفاءة متبادلة في قراءة المشاعر واحتواء الضغوط بلطف." : "تفاوت في سرعة التقاط الإشارات الشعورية يتطلب تعبيراً لفظياً أوضح."
		},
		{
			axisKey: "communication",
			axisNameAr: "أساليب التواصل والحوار",
			personAScore: commCapA,
			personBScore: commCapB,
			delta: Math.abs(commCapA - commCapB),
			matchScore: commMatch,
			scientificNoteAr: commMatch >= 75 ? "انسيابية في النقاش وتوافق بين التحليل والإنصات المتبادل." : "اختلاف في أسلوب النقاش (تحليلي مقابل عاطفي أو صامت)؛ اتفاق على قواعد الحوار يفيدكما."
		},
		{
			axisKey: "conflict",
			axisNameAr: "حل النزاعات وإدارة الخلاف (TKI)",
			personAScore: confCapA,
			personBScore: confCapB,
			delta: Math.abs(confCapA - confCapB),
			matchScore: conflictMatch,
			scientificNoteAr: conflictMatch >= 75 ? "نضج مشترك في معالجة الخلاف بالبحث عن حلول مربحة للطرفين." : "احتمال تباين ردود الفعل وقت الغضب؛ تجنب الصمت العقابي والهجوم المباشر."
		},
		{
			axisKey: "values",
			axisNameAr: "القيم والمعتقدات الجوهرية",
			personAScore: personA.valuesScore,
			personBScore: personB.valuesScore,
			delta: Math.abs(personA.valuesScore - personB.valuesScore),
			matchScore: valuesMatch,
			scientificNoteAr: valuesMatch >= 78 ? "بوصلة أخلاقية وقيمية موحدة تمثل أقوى ضمانات الديمومة الزوجية." : "تباين في أولويات القيم؛ يتطلب حواراً صريحاً حول الثوابت المشتركة."
		},
		{
			axisKey: "life_goals",
			axisNameAr: "أهداف الحياة والتخطيط المستقبلي",
			personAScore: goalsMeanA,
			personBScore: goalsMeanB,
			delta: Math.abs(goalsMeanA - goalsMeanB),
			matchScore: goalsMatch,
			scientificNoteAr: goalsMatch >= 75 ? "رؤية متلاقية في بناء الأسرة والطموح العملي والمالي." : "اختلاف في إيقاع الأولويات بين الاستقرار الأسري والطموح الفردي."
		},
		{
			axisKey: "parenting",
			axisNameAr: "التوجه الأسري والتربوي",
			personAScore: personA.parentingOrientation,
			personBScore: personB.parentingOrientation,
			delta: Math.abs(personA.parentingOrientation - personB.parentingOrientation),
			matchScore: parentingMatch,
			scientificNoteAr: parentingMatch >= 75 ? "توافق في فلسفة التربية، الدفء العائلي، وصناعة القدوة الأبوية." : "يُنصح بالاتفاق المسبق على فلسفة التربية والحدود الأسرية."
		}
	];
	const intellectualScore = clampScore(similarityMatch(personA.bigFive.openness, personB.bigFive.openness) * .45 + similarityMatch(personA.communicationStyle.analytical, personB.communicationStyle.analytical) * .3 + similarityMatch(personA.lifeGoals.intellectualDepth, personB.lifeGoals.intellectualDepth) * .25);
	const emotionalScore = clampScore(attMatch * .55 + eiMatch * .45);
	const socialScore = clampScore(balancedMatch(personA.bigFive.extraversion, personB.bigFive.extraversion) * .35 + commMatch * .4 + similarityMatch(personA.lifeGoals.socialHarmony, personB.lifeGoals.socialHarmony) * .25);
	const familyScore = clampScore(parentingMatch * .45 + conflictMatch * .35 + similarityMatch(personA.lifeGoals.familyStability, personB.lifeGoals.familyStability) * .2);
	const valuesIdxScore = clampScore(valuesMatch * .55 + similarityMatch(personA.hexaco.honestyHumility, personB.hexaco.honestyHumility) * .45);
	const goalsIdxScore = clampScore(goalsMatch * .65 + similarityMatch(personA.bigFive.conscientiousness, personB.bigFive.conscientiousness) * .35);
	const subIndices = [
		{
			key: "intellectual",
			titleAr: "التوافق الفكري والمعرفي",
			titleEn: "Intellectual Compatibility",
			score: intellectualScore,
			weight: .16,
			scientificReference: "Big Five Openness & Burleson Cognitive Complexity",
			interpretationAr: intellectualScore >= 75 ? "تناغم ذهني رائع يغذي الحوارات العميقة والاهتمامات المعرفية المشتركة." : "تنوع فكري يتطلب احتراماً متبادلاً لطريقة تفكير ومعالجة كل طرف.",
			strengthsAr: intellectualScore >= 70 ? ["عمق الحوار الفكري وتقارب الفضول المعرفي", "وضوح تحليلي متقارب في النقاشات"] : ["تنوع معرفي يتيح التكامل إذا توفّر الاحترام"],
			risksAr: intellectualScore < 65 ? ["احتمال الفتور الحواري أو اختلاف اهتمامات القراءة والمعرفة"] : []
		},
		{
			key: "emotional",
			titleAr: "التوافق العاطفي والارتباطي",
			titleEn: "Emotional & Attachment Compatibility",
			score: emotionalScore,
			weight: .22,
			scientificReference: "Bowlby Attachment (ECR-R) & Mayer-Salovey EI",
			interpretationAr: emotionalScore >= 75 ? "أمان وجداني مشترك وقدرة رفيعة على الاحتواء العاطفي والتطمين." : "تفاوت في احتياجات القرب العاطفي واليقظة الانفعالية يستدعي مراعاةً واضحة.",
			strengthsAr: emotionalScore >= 70 ? ["أمان ارتباطي عالٍ وتوازن في التعبير العاطفي", "قدرة متبادلة على قراءة المشاعر"] : ["فرصة لتطوير مهارات التطمين المتبادل والإنصات الوجداني"],
			risksAr: emotionalScore < 65 ? ["خطر سوء فهم الصمت أو الاختلاف في سرعة الاستجابة العاطفية"] : []
		},
		{
			key: "social",
			titleAr: "التوافق الاجتماعي والتواصلي",
			titleEn: "Social & Communication Compatibility",
			score: socialScore,
			weight: .14,
			scientificReference: "Gottman Sound House & Rosenberg NVC",
			interpretationAr: socialScore >= 75 ? "توازن جذاب في النشاط الاجتماعي وتكامل مريح في إدارة العلاقات مع المحيط." : "اختلاف في الحاجة للانبساط الاجتماعي مقابل الخصوصية الهادئة.",
			strengthsAr: ["توافق الإيقاع الاجتماعي واحترام المساحة الشخصية"],
			risksAr: socialScore < 65 ? ["تضارب محتمل حول كثرة الزيارات العائلية والاجتماعية"] : []
		},
		{
			key: "family",
			titleAr: "التوافق الأسري وإدارة الخلافات",
			titleEn: "Family & Conflict Management Compatibility",
			score: familyScore,
			weight: .18,
			scientificReference: "Bowen Family Systems & Thomas-Kilmann (TKI)",
			interpretationAr: familyScore >= 75 ? "جاهزية عالية لتأسيس بيت هادئ بحدود صحية وتوجه تربوي متوافق." : "يتطلب الاتفاق المسبق على آلية حسم الخلاف والحدود مع العائلتين.",
			strengthsAr: ["تشابه الرؤية التربوية وأسلوب حل النزاعات البناء"],
			risksAr: familyScore < 65 ? ["اختلاف في مرونة التعامل وقت النزاع أو الحدود مع المحيط"] : []
		},
		{
			key: "values",
			titleAr: "التوافق القيمي والأخلاقي",
			titleEn: "Values & Integrity Compatibility",
			score: valuesIdxScore,
			weight: .16,
			scientificReference: "Schwartz Basic Values & HEXACO Honesty-Humility",
			interpretationAr: valuesIdxScore >= 78 ? "اتحاد عميق في البوصلة الأخلاقية والصدق والنزاهة، وهو الحجر الأساس للثقة المطلقة." : "فروق واضحة في نسق القيم الأولوية تتطلب شفافية قبل الارتباط الرسمي.",
			strengthsAr: ["وضوح الضمير الأخلاقي وتقارب معايير الأمانة والوفاء"],
			risksAr: valuesIdxScore < 65 ? ["تضارب محتمل في القرارات الأخلاقية والمجتمعية الحساسة"] : []
		},
		{
			key: "goals",
			titleAr: "توافق أهداف الحياة والمستقبل",
			titleEn: "Life Goals Compatibility",
			score: goalsIdxScore,
			weight: .14,
			scientificReference: "Seligman PERMA & Emmons Personal Strivings",
			interpretationAr: goalsIdxScore >= 75 ? "مسار طموحات متوازٍ يدعم الشراكة المالية والمهنية والأسرية طويلة المدى." : "يحتاج الطرفان لمواءمة خطط الاستقرار والعمل حتى لا تتعارض الأولويات.",
			strengthsAr: ["اتفاق واقعي على الخطة المالية والمهنية والانضباط التخطيطي"],
			risksAr: goalsIdxScore < 65 ? ["تباين سرعة الإنجاز والطموح العملي بين الشريكين"] : []
		}
	];
	const overallWeightedCompatibility = clampScore(subIndices.reduce((acc, item) => acc + item.score * item.weight, 0));
	let compatibilityClassificationAr = "توافق متزن واعد وقابل للارتقاء";
	if (overallWeightedCompatibility >= 88) compatibilityClassificationAr = "تناغم استثنائي نادر واستقرار طويل الأمد";
	else if (overallWeightedCompatibility >= 75) compatibilityClassificationAr = "توافق علمي مرتفع وبنية شراكة متينة";
	else if (overallWeightedCompatibility >= 60) compatibilityClassificationAr = "توافق جيد يحتاج لمهارات حوار وإدارة اختلافات";
	else compatibilityClassificationAr = "تباين شخصي ملموس يتطلب حواراً عميقاً ومراجعة الأولويات";
	const sharedStrengthsAr = [...nineAxesBreakdown.filter((r) => r.matchScore >= 75).slice(0, 4).map((r) => `${r.axisNameAr} (${r.matchScore}%): ${r.scientificNoteAr}`)];
	if (sharedStrengthsAr.length === 0) sharedStrengthsAr.push("فرصة لبناء تكامل نوعي في المهارات المختلفة عبر الوعي والتفاهم الصريح.");
	const growthRecommendationsAr = [...nineAxesBreakdown.filter((r) => r.matchScore < 72).slice(0, 4).map((r) => `تطوير محور «${r.axisNameAr}» (${r.matchScore}%): ${r.scientificNoteAr}`), "اعتماد مبدأ الحوار الأسبوعي الهادئ دون أحكام وتفعيل طقوس الامتنان والتقدير المتبادل."];
	const executiveSummaryAr = `تحليل مقارنة شخصيتين بين «${personA.personName}» و«${personB.personName}» عبر 9 محاور سيكومترية و6 مؤشرات توافقية، أظهر معامل توافق إجمالي موزون قدره ${overallWeightedCompatibility}% (${compatibilityClassificationAr}). أعلى نقاط الانسجام برزت في «${[...subIndices].sort((a, b) => b.score - a.score)[0]?.titleAr}» (${[...subIndices].sort((a, b) => b.score - a.score)[0]?.score}%).`;
	return {
		id: `cmp_${Date.now()}`,
		createdAt: (/* @__PURE__ */ new Date()).toISOString(),
		personA,
		personB,
		overallWeightedCompatibility,
		compatibilityClassificationAr,
		subIndices,
		nineAxesBreakdown,
		sharedStrengthsAr,
		growthRecommendationsAr,
		executiveSummaryAr,
		scientificReferences: [
			"Costa & McCrae (1992) Big Five Model",
			"Ashton & Lee (2004) HEXACO-PI-R",
			"Fraley et al. (2000) ECR-R Adult Attachment",
			"Salovey & Mayer (1990) Emotional Intelligence",
			"Thomas & Kilmann (1974) Conflict Modes (TKI)",
			"Gottman (1999) & Bowen (1978) Relational Systems",
			"Schwartz (1992) Values & Seligman PERMA"
		]
	};
}
//#endregion
//#region src/utils/tieredScoringEngine.ts
var AUTOSAVE_PREFIX = "mirat_tiered_autosave_";
var NON_CLINICAL_DISCLAIMER_AR = "ملاحظة علمية وأخلاقية هامة: هذه الاختبارات النفسية مصممة لأغراض الاستكشاف الذاتي والوعي العلائقي المبني على النظريات السيكومترية الرصينة، وتحتمل الخطأ الإحصائي والتغير الموقفي، وليست بأي حال اختبارات طبية أو تشخيصات سريرية.";
function saveTieredProgressAutoSave(state) {
	try {
		if (typeof localStorage === "undefined") return;
		localStorage.setItem(`${AUTOSAVE_PREFIX}${state.tier}`, JSON.stringify(state));
	} catch {}
}
function loadTieredProgressAutoSave(tier) {
	try {
		if (typeof localStorage === "undefined") return null;
		const raw = localStorage.getItem(`${AUTOSAVE_PREFIX}${tier}`);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		if (parsed && parsed.tier === tier && parsed.answers && typeof parsed.currentIndex === "number") return parsed;
		return null;
	} catch {
		return null;
	}
}
function clearTieredProgressAutoSave(tier) {
	try {
		if (typeof localStorage === "undefined") return;
		localStorage.removeItem(`${AUTOSAVE_PREFIX}${tier}`);
	} catch {}
}
var SUBSCALE_METADATA = {
	bf_openness: {
		construct: "big_five",
		labelAr: "الانفتاح الفكري والجمالي (O)",
		labelEn: "Openness to Experience",
		color: "#8b5cf6",
		explanationAr: "الفضول المعرفي، الخيال الإبداعي، والانفتاح على الأفكار الجديدة.",
		reference: "Costa & McCrae (1992) NEO-PI-R"
	},
	bf_conscientiousness: {
		construct: "big_five",
		labelAr: "يقظة الضمير والانضباط (C)",
		labelEn: "Conscientiousness",
		color: "#6366f1",
		explanationAr: "المسؤولية، التخطيط المنظم، الإتقان، والوفاء بالالتزامات.",
		reference: "Costa & McCrae (1992) NEO-PI-R"
	},
	bf_extraversion: {
		construct: "big_five",
		labelAr: "الانبساط والحيوية الاجتماعية (E)",
		labelEn: "Extraversion",
		color: "#ec4899",
		explanationAr: "الحماس الاجتماعي، الدفء التعبيري، وتوليد الطاقة عبر التفاعل.",
		reference: "Costa & McCrae (1992) NEO-PI-R"
	},
	bf_agreeableness: {
		construct: "big_five",
		labelAr: "الوفاق واللطف العلائقي (A)",
		labelEn: "Agreeableness",
		color: "#10b981",
		explanationAr: "التعاون، الرأفة، التواضع التفاعلي، والسعي للوئام.",
		reference: "Costa & McCrae (1992) NEO-PI-R"
	},
	bf_emotional_stability: {
		construct: "big_five",
		labelAr: "الاتزان الانفعالي (ES)",
		labelEn: "Emotional Stability",
		color: "#06b6d4",
		explanationAr: "الهدوء الداخلي، المرونة أمام التوتر، وثبات المزاج.",
		reference: "Goldberg (1999) IPIP Big Five"
	},
	hx_honesty_humility: {
		construct: "hexaco",
		labelAr: "الصدق والنزاهة والتواضع (H)",
		labelEn: "Honesty-Humility",
		color: "#06b6d4",
		explanationAr: "الإخلاص، تجنب التلاعب والمصلحية، التواضع، والنزاهة الأخلاقية.",
		reference: "Ashton & Lee (2004) HEXACO-PI-R"
	},
	hx_emotionality: {
		construct: "hexaco",
		labelAr: "الرهافة والارتباط العاطفي (E)",
		labelEn: "HEXACO Emotionality",
		color: "#f43f5e",
		explanationAr: "الحساسية الوجدانية، طلب القرب، والتعلق العاطفي بالآخرين.",
		reference: "Ashton & Lee (2004) HEXACO-PI-R"
	},
	hx_extraversion: {
		construct: "hexaco",
		labelAr: "الثقة الاجتماعية والجرأة (X)",
		labelEn: "HEXACO Extraversion",
		color: "#a855f7",
		explanationAr: "تقدير الذات الاجتماعي، المبادرة القيادية، والحيوية.",
		reference: "Ashton & Lee (2004) HEXACO-PI-R"
	},
	hx_agreeableness: {
		construct: "hexaco",
		labelAr: "المسامحة وحلم الطبع (A)",
		labelEn: "HEXACO Agreeableness",
		color: "#10b981",
		explanationAr: "التسامح، الصبر، ولين الجانب عند الخلاف والخطأ.",
		reference: "Ashton & Lee (2004) HEXACO-PI-R"
	},
	hx_conscientiousness: {
		construct: "hexaco",
		labelAr: "الاجتهاد والحكمة التنظيمية (C)",
		labelEn: "HEXACO Conscientiousness",
		color: "#3b82f6",
		explanationAr: "التنظيم، التأني قبل اتخاذ القرار، والمثابرة العملية.",
		reference: "Ashton & Lee (2004) HEXACO-PI-R"
	},
	hx_openness: {
		construct: "hexaco",
		labelAr: "الاستكشاف الفكري والجمالي (O)",
		labelEn: "HEXACO Openness",
		color: "#8b5cf6",
		explanationAr: "تذوق المعرفة والفن، والمرونة الفكرية.",
		reference: "Ashton & Lee (2004) HEXACO-PI-R"
	},
	att_anxiety: {
		construct: "attachment",
		labelAr: "قلق التعلق والهجر",
		labelEn: "Attachment Anxiety",
		color: "#f59e0b",
		explanationAr: "مستوى القلق بشأن الاستجابة العاطفية والحاجة لطمأنة متكررة (القيم الأقل تشير لأمان أعلى).",
		reference: "Fraley et al. (2000) ECR-R",
		isReversePositive: true
	},
	att_avoidance: {
		construct: "attachment",
		labelAr: "تجنب القرب العاطفي",
		labelEn: "Attachment Avoidance",
		color: "#f97316",
		explanationAr: "درجة الانكفاء الذاتي أو التردد في البوح والاعتماد العاطفي المتبادل (القيم الأقل تشير لانفتاح آمن).",
		reference: "Fraley et al. (2000) ECR-R",
		isReversePositive: true
	},
	att_security: {
		construct: "attachment",
		labelAr: "الأمان العاطفي المكتسب",
		labelEn: "Attachment Security",
		color: "#10b981",
		explanationAr: "الثقة العاطفية، راحة القرب، وتوازن الاستقلالية والارتباط.",
		reference: "Bowlby (1969) & Ainsworth (1978)"
	},
	ei_self_awareness: {
		construct: "emotional_intelligence",
		labelAr: "الوعي العاطفي بالذات",
		labelEn: "Emotional Self-Awareness",
		color: "#ec4899",
		explanationAr: "القدرة على تسمية المشاعر بدقة وفهم محركاتها الداخلية.",
		reference: "Salovey & Mayer (1990) MSCEIT"
	},
	ei_empathy: {
		construct: "emotional_intelligence",
		labelAr: "التعاطف وفهم الآخر",
		labelEn: "Empathetic Decoding",
		color: "#db2777",
		explanationAr: "قراءة مشاعر الشريك والتناغم معها دون أحكام.",
		reference: "Goleman (1995) & Bar-On (1997)"
	},
	ei_regulation: {
		construct: "emotional_intelligence",
		labelAr: "إدارة الانفعالات وتوظيفها",
		labelEn: "Emotion Regulation & Use",
		color: "#f43f5e",
		explanationAr: "توجيه الانفعالات لبناء الحوار ومنع التصعيد الهدّام.",
		reference: "Salovey & Mayer (1990) MSCEIT"
	},
	ei_social_skill: {
		construct: "emotional_intelligence",
		labelAr: "المهارة الاجتماعية والاحتواء",
		labelEn: "Social & Relational Skill",
		color: "#8b5cf6",
		explanationAr: "بناء الألفة، التهدئة العاطفية، وتعزيز التقارب المستدام.",
		reference: "Bar-On (1997) EQ-i"
	},
	sr_cognitive_reappraisal: {
		construct: "self_regulation",
		labelAr: "إعادة التقييم المعرفي",
		labelEn: "Cognitive Reappraisal",
		color: "#f59e0b",
		explanationAr: "إعادة تأطير المواقف الضاغطة بتفكير متزن وهادئ.",
		reference: "Gross (1998) Emotion Regulation"
	},
	sr_impulse_control: {
		construct: "self_regulation",
		labelAr: "ضبط الاندفاع والتأني",
		labelEn: "Impulse Control",
		color: "#d97706",
		explanationAr: "تأخير ردود الفعل الحادة والتثبت قبل النطق أو القرار.",
		reference: "Baumeister & Vohs (2004)"
	},
	sr_stress_resilience: {
		construct: "self_regulation",
		labelAr: "الصلابة أمام الضغوط",
		labelEn: "Stress Resilience",
		color: "#eab308",
		explanationAr: "القدرة على التعافي العصبي والنفسي عند الأعباء الثقيلة.",
		reference: "Gross (1998) & Connor-Davidson"
	},
	sr_goal_persistence: {
		construct: "self_regulation",
		labelAr: "المثابرة والاستمرارية",
		labelEn: "Goal Persistence",
		color: "#84cc16",
		explanationAr: "الالتزام طويل الأمد بالأهداف والمشاريع المشتركة.",
		reference: "Baumeister & Vohs (2004)"
	},
	int_trust_commitment: {
		construct: "interpersonal",
		labelAr: "الثقة والميثاق العلائقي",
		labelEn: "Relational Trust & Commitment",
		color: "#10b981",
		explanationAr: "الاعتمادية، حفظ السر، والوفاء بالعهد في السراء والضراء.",
		reference: "Gottman (1999) Trust Metric"
	},
	int_boundaries: {
		construct: "interpersonal",
		labelAr: "الحدود الصحية والاستقلالية",
		labelEn: "Healthy Family Boundaries",
		color: "#059669",
		explanationAr: "التمايز النفسي وصيانة خصوصية الأسرة تجاه التدخلات.",
		reference: "Bowen (1978) Family Systems"
	},
	int_parenting_family: {
		construct: "interpersonal",
		labelAr: "التوجه التربوي والأسري",
		labelEn: "Parenting & Family Orientation",
		color: "#14b8a6",
		explanationAr: "رؤية التربية المتوازنة وبناء بيئة أسرية دافئة للأبناء.",
		reference: "Baumrind & Bowen Family Systems"
	},
	int_repair_synergy: {
		construct: "interpersonal",
		labelAr: "القدرة على الإصلاح والتكامل",
		labelEn: "Repair & Dyadic Synergy",
		color: "#0d9488",
		explanationAr: "مبادرات المصالحة والتكامل العملي بعد الخلافات.",
		reference: "Gottman (1999) Repair Attempts"
	},
	com_assertive: {
		construct: "communication",
		labelAr: "التواصل الحازم المحترم",
		labelEn: "Assertive Communication",
		color: "#3b82f6",
		explanationAr: "التعبير عن الحقوق والاحتياجات بوضوح دون عدوانية أو صمت.",
		reference: "Rosenberg (2003) NVC"
	},
	com_reflective: {
		construct: "communication",
		labelAr: "الإنصات التأملي الفعال",
		labelEn: "Reflective Listening",
		color: "#2563eb",
		explanationAr: "الاستماع المتعمق، التحقق من الفهم، وتجنب المقاطعة.",
		reference: "Rogers & Rosenberg NVC"
	},
	com_collaborating: {
		construct: "communication",
		labelAr: "التعاون التفاوضي في النزاعات",
		labelEn: "Collaborative Conflict Resolution",
		color: "#0284c7",
		explanationAr: "تحويل التعارض إلى حل تكاملي يرضي حاجات الطرفين.",
		reference: "Thomas & Kilmann (1974) TKI"
	},
	com_analytical: {
		construct: "communication",
		labelAr: "الوضوح التحليلي والمنطقي",
		labelEn: "Analytical Dialogue Clarity",
		color: "#4f46e5",
		explanationAr: "تنظيم الأفكار والمناقشة الموضوعية البعيدة عن الشخصنة.",
		reference: "Burleson Relational Communication"
	},
	com_expressive: {
		construct: "communication",
		labelAr: "التعبير الوجداني الدافئ",
		labelEn: "Warm Expressiveness",
		color: "#ec4899",
		explanationAr: "إظهار التقدير والامتنان والمودة بالكلام والمبادرة.",
		reference: "Gottman Fondness & Admiration"
	},
	pp_values_meaning: {
		construct: "positive_psychology",
		labelAr: "القيم الجوهرية ومعنى الحياة",
		labelEn: "Core Values & Meaning",
		color: "#14b8a6",
		explanationAr: "وضوح البوصلة الأخلاقية والعيش وفق مبادئ نبيلة.",
		reference: "Schwartz (1992) Values & Seligman PERMA"
	},
	pp_optimism_gratitude: {
		construct: "positive_psychology",
		labelAr: "التفاؤل الواقعي والامتنان",
		labelEn: "Learned Optimism & Gratitude",
		color: "#10b981",
		explanationAr: "تقدير النعم، حسن الظن، وصناعة الأمل التشاركي.",
		reference: "Seligman (2011) PERMA"
	},
	pp_life_goals: {
		construct: "positive_psychology",
		labelAr: "وضوح أهداف الحياة والمستقبل",
		labelEn: "Life Goals Alignment",
		color: "#06b6d4",
		explanationAr: "التخطيط المستقبلي المتوازن بين الأسرة والطموح الشخصي.",
		reference: "Emmons Personal Strivings & PERMA"
	},
	pp_resilience_flourishing: {
		construct: "positive_psychology",
		labelAr: "الازدهار والنمو النفسي",
		labelEn: "Psychological Flourishing",
		color: "#22c55e",
		explanationAr: "الشعور بالحيوية، العافية الروحية، والقدرة على الازدهار.",
		reference: "Keyes & Seligman Flourishing"
	}
};
function clampPct(n) {
	if (!Number.isFinite(n)) return 50;
	return Math.max(0, Math.min(100, Math.round(n)));
}
function pctToSten(pct) {
	const safe = clampPct(pct);
	const sten = Math.round(1 + safe / 100 * 9);
	return Math.max(1, Math.min(10, sten));
}
function pctToTScore(pct) {
	const safe = clampPct(pct);
	return Math.max(20, Math.min(80, Math.round(25 + safe / 100 * 50)));
}
function pctToPercentile(pct) {
	const safe = clampPct(pct);
	if (safe <= 2) return 1;
	if (safe >= 98) return 99;
	return Math.max(1, Math.min(99, Math.round(safe)));
}
function interpretSubscaleScore(meta, pct) {
	if (meta.isReversePositive) {
		if (pct >= 68) return {
			ar: `مؤشر مرتفع (${pct}%): يُنصح بتعزيز الأمان العاطفي عبر الحوار التطميني الهادئ وبناء الثقة التدريجية.`,
			en: `Elevated (${pct}%): Reassurance-focused dialogue and gradual emotional safety habits are beneficial.`
		};
		if (pct >= 38) return {
			ar: `مستوى متوسط (${pct}%): استجابة موقفية طبيعية تتوازن بالوضوح والتفاهم المتبادل.`,
			en: `Moderate (${pct}%): Situational reactivity balanced through transparent mutual communication.`
		};
		return {
			ar: `مؤشر منخفض مريح (${pct}%): يعكس طمأنينة عالية واستقراراً ارتباطياً متيناً.`,
			en: `Low & Secure (${pct}%): Indicates grounded emotional confidence and secure relational ease.`
		};
	}
	if (pct >= 72) return {
		ar: `مستوى مرتفع متميز (${pct}%): يمثل إحدى الركائز القيادية والوجدانية القوية في شخصيتك.`,
		en: `High Strength (${pct}%): Represents a core pillar of your psychological and relational profile.`
	};
	if (pct >= 45) return {
		ar: `مستوى متزن معتدل (${pct}%): مرونة تكيفية متزنة تتيح التناغم مع مختلف الأنماط البشرية.`,
		en: `Balanced Moderate (${pct}%): Adaptive flexibility supporting harmony across varied contexts.`
	};
	return {
		ar: `مستوى نامٍ قابل للتطوير (${pct}%): مساحة واعدة للتنمية الذاتية ورفع الكفاءة التفاعلية.`,
		en: `Developing Area (${pct}%): A focused opportunity for intentional personal and relational growth.`
	};
}
function validateTierReportCompleteness(tier, questions, answers) {
	const missingIds = [];
	for (const q of questions) {
		const ans = answers[q.id];
		if (q.format === "forced_choice") {
			if (ans !== "A" && ans !== "B") missingIds.push(q.id);
		} else {
			const num = typeof ans === "number" ? ans : Number(ans);
			if (!Number.isFinite(num) || num < 1 || num > 5) missingIds.push(q.id);
		}
	}
	const isComplete = missingIds.length === 0 && questions.length > 0;
	return {
		isComplete,
		answeredCount: questions.length - missingIds.length,
		totalCount: questions.length,
		missingIds,
		reasonAr: !isComplete ? `يتطلب اعتماد تقرير «${ANALYSIS_TIERS_CATALOG.find((t) => t.id === tier)?.titleAr || tier}» إكمال جميع الأسئلة (${questions.length - missingIds.length} من أصل ${questions.length} مكتملة). يمنع نظام الضبط العلمي إصدار تقرير ناقص البيانات.` : void 0
	};
}
function calculateTieredPsychometricReport(tier, answers, userName = "المستخدم", options) {
	const tierMeta = ANALYSIS_TIERS_CATALOG.find((t) => t.id === tier) || ANALYSIS_TIERS_CATALOG[0];
	const questions = getQuestionsForAnalysisTier(tier);
	const validation = validateTierReportCompleteness(tier, questions, answers);
	if (tier === "professional" && !validation.isComplete && !options?.allowPartialForTest) throw new Error(validation.reasonAr || "يمنع الوصول لتقرير التحليل الاحترافي قبل استكمال كافة الأسئلة الـ 288 لضمان الدقة السيكومترية.");
	const acc = {};
	Object.keys(SUBSCALE_METADATA).forEach((k) => {
		acc[k] = {
			sum: 0,
			minSum: 0,
			maxSum: 0,
			count: 0,
			values: []
		};
	});
	questions.forEach((q) => {
		const rawAns = answers[q.id];
		if (q.format === "forced_choice" && q.forcedOptions) {
			const optA = q.forcedOptions[0];
			const optB = q.forcedOptions[1];
			const minV = Math.min(optA.scoreValue, optB.scoreValue);
			const maxV = Math.max(optA.scoreValue, optB.scoreValue);
			const chosen = rawAns === "A" ? optA : rawAns === "B" ? optB : null;
			if (chosen) {
				const target = acc[chosen.targetSubscale] ? chosen.targetSubscale : q.subscale;
				const bucket = acc[target] || (acc[target] = {
					sum: 0,
					minSum: 0,
					maxSum: 0,
					count: 0,
					values: []
				});
				bucket.sum += chosen.scoreValue;
				bucket.minSum += Math.min(minV, 1);
				bucket.maxSum += Math.max(maxV, 5);
				bucket.count += 1;
				bucket.values.push(chosen.scoreValue);
			}
			return;
		}
		const numRaw = typeof rawAns === "number" ? rawAns : Number(rawAns);
		if (!Number.isFinite(numRaw) || numRaw < 1 || numRaw > 5) return;
		const scored = q.direction === -1 ? 6 - numRaw : numRaw;
		const bucket = acc[q.subscale] || (acc[q.subscale] = {
			sum: 0,
			minSum: 0,
			maxSum: 0,
			count: 0,
			values: []
		});
		bucket.sum += scored;
		bucket.minSum += 1;
		bucket.maxSum += 5;
		bucket.count += 1;
		bucket.values.push(scored);
	});
	const subscaleMap = {};
	const subscales = [];
	Object.entries(SUBSCALE_METADATA).forEach(([key, meta]) => {
		const b = acc[key];
		let percentage = 50;
		let rawScore = 0;
		let maxRawScore = 0;
		if (b && b.count > 0 && b.maxSum > b.minSum) {
			percentage = clampPct((b.sum - b.minSum) / (b.maxSum - b.minSum) * 100);
			rawScore = b.sum;
			maxRawScore = b.maxSum;
		} else if (b && b.count > 0 && b.maxSum === b.minSum) {
			percentage = b.sum >= b.maxSum ? 100 : 0;
			rawScore = b.sum;
			maxRawScore = b.maxSum;
		} else {
			const peerVals = Object.entries(acc).filter(([pk, pb]) => SUBSCALE_METADATA[pk]?.construct === meta.construct && pb.count > 0 && pb.maxSum > pb.minSum).map(([, pb]) => (pb.sum - pb.minSum) / (pb.maxSum - pb.minSum) * 100);
			if (peerVals.length > 0) percentage = clampPct(peerVals.reduce((s, v) => s + v, 0) / peerVals.length);
		}
		const interp = interpretSubscaleScore(meta, percentage);
		const entry = {
			key,
			construct: meta.construct,
			labelAr: meta.labelAr,
			labelEn: meta.labelEn,
			rawScore,
			maxRawScore,
			percentage,
			stenScore: pctToSten(percentage),
			percentile: pctToPercentile(percentage),
			tScore: pctToTScore(percentage),
			scientificReference: meta.reference,
			dimensionExplanationAr: meta.explanationAr,
			interpretationAr: interp.ar,
			interpretationEn: interp.en,
			color: meta.color
		};
		subscaleMap[key] = entry;
		subscales.push(entry);
	});
	const getPct = (k) => subscaleMap[k]?.percentage ?? 50;
	const constructSpreads = [];
	[
		"big_five",
		"hexaco",
		"attachment",
		"emotional_intelligence",
		"self_regulation",
		"interpersonal",
		"communication",
		"positive_psychology"
	].forEach((ck) => {
		const items = questions.filter((q) => q.construct === ck && q.format === "likert" && answers[q.id] !== void 0);
		if (items.length >= 2) {
			const vals = items.map((q) => {
				const r = Number(answers[q.id]);
				return q.direction === -1 ? 6 - r : r;
			});
			const avg = vals.reduce((a, b) => a + b, 0) / vals.length;
			const variance = vals.reduce((a, b) => a + Math.pow(b - avg, 2), 0) / vals.length;
			constructSpreads.push(Math.sqrt(variance));
		}
	});
	const consistencyIndex = clampPct(98 - (constructSpreads.length > 0 ? constructSpreads.reduce((a, b) => a + b, 0) / constructSpreads.length : .8) * 16);
	const attAnxiety = getPct("att_anxiety");
	const attAvoidance = getPct("att_avoidance");
	const attSecurityDirect = getPct("att_security");
	let attStyleKey = "secure";
	let attStyleAr = "نمط التعلق الآمن (Secure Attachment)";
	let attStyleEn = "Secure Attachment";
	if (attAnxiety >= 52 && attAvoidance >= 52) {
		attStyleKey = "fearful";
		attStyleAr = "نمط التعلق القلق-التجنبي الحذر (Fearful-Avoidant)";
		attStyleEn = "Fearful-Avoidant Attachment";
	} else if (attAnxiety >= 52) {
		attStyleKey = "anxious";
		attStyleAr = "نمط التعلق القلق المتعطش للطمانينة (Anxious-Preoccupied)";
		attStyleEn = "Anxious-Preoccupied Attachment";
	} else if (attAvoidance >= 52) {
		attStyleKey = "avoidant";
		attStyleAr = "نمط التعلق التجنبي المكتفي ذاتياً (Dismissive-Avoidant)";
		attStyleEn = "Dismissive-Avoidant Attachment";
	}
	const effectiveAttachmentSecurity = clampPct(attSecurityDirect * .45 + (100 - attAnxiety) * .275 + (100 - attAvoidance) * .275);
	const constructScores = {
		big_five: clampPct((getPct("bf_openness") + getPct("bf_conscientiousness") + getPct("bf_extraversion") + getPct("bf_agreeableness") + getPct("bf_emotional_stability")) / 5),
		hexaco: clampPct((getPct("hx_honesty_humility") + getPct("hx_agreeableness") + getPct("hx_conscientiousness") + getPct("hx_openness") + getPct("hx_extraversion") + (100 - Math.abs(getPct("hx_emotionality") - 55) * .5)) / 6),
		attachment: effectiveAttachmentSecurity,
		emotional_intelligence: clampPct((getPct("ei_self_awareness") + getPct("ei_empathy") + getPct("ei_regulation") + getPct("ei_social_skill")) / 4),
		self_regulation: clampPct((getPct("sr_cognitive_reappraisal") + getPct("sr_impulse_control") + getPct("sr_stress_resilience") + getPct("sr_goal_persistence")) / 4),
		interpersonal: clampPct((getPct("int_trust_commitment") + getPct("int_boundaries") + getPct("int_parenting_family") + getPct("int_repair_synergy")) / 4),
		communication: clampPct((getPct("com_assertive") + getPct("com_reflective") + getPct("com_collaborating") + getPct("com_analytical") + getPct("com_expressive")) / 5),
		positive_psychology: clampPct((getPct("pp_values_meaning") + getPct("pp_optimism_gratitude") + getPct("pp_life_goals") + getPct("pp_resilience_flourishing")) / 4)
	};
	const overallMaturityIndex = clampPct(constructScores.emotional_intelligence * .16 + constructScores.self_regulation * .14 + constructScores.attachment * .14 + constructScores.communication * .14 + constructScores.interpersonal * .14 + constructScores.positive_psychology * .12 + getPct("hx_honesty_humility") * .08 + getPct("bf_conscientiousness") * .08);
	const collab = clampPct(getPct("com_collaborating") * .65 + getPct("int_repair_synergy") * .35);
	const comprom = clampPct(getPct("bf_agreeableness") * .5 + getPct("com_assertive") * .5);
	const accom = clampPct(getPct("hx_agreeableness") * .55 + (100 - getPct("com_assertive")) * .45);
	const compet = clampPct(getPct("com_assertive") * .5 + (100 - getPct("bf_agreeableness")) * .5);
	const avoidMode = clampPct(attAvoidance * .6 + (100 - getPct("com_assertive")) * .4);
	const visualCharts = {
		overallRadar: [
			{
				subject: "العوامل الخمسة (Big 5)",
				score: constructScores.big_five,
				fullMark: 100
			},
			{
				subject: "النزاهة والمرونة (HEXACO)",
				score: constructScores.hexaco,
				fullMark: 100
			},
			{
				subject: "الأمان العاطفي (Attachment)",
				score: constructScores.attachment,
				fullMark: 100
			},
			{
				subject: "الذكاء العاطفي (EI)",
				score: constructScores.emotional_intelligence,
				fullMark: 100
			},
			{
				subject: "التنظيم الذاتي",
				score: constructScores.self_regulation,
				fullMark: 100
			},
			{
				subject: "الكفاءة البينشخصية",
				score: constructScores.interpersonal,
				fullMark: 100
			},
			{
				subject: "التواصل والحلول",
				score: constructScores.communication,
				fullMark: 100
			},
			{
				subject: "الازدهار والقيم (PERMA)",
				score: constructScores.positive_psychology,
				fullMark: 100
			}
		],
		bigFiveRadar: [
			{
				trait: "الانفتاح (O)",
				score: getPct("bf_openness"),
				benchmark: 64,
				fullMark: 100
			},
			{
				trait: "يقظة الضمير (C)",
				score: getPct("bf_conscientiousness"),
				benchmark: 68,
				fullMark: 100
			},
			{
				trait: "الانبساط (E)",
				score: getPct("bf_extraversion"),
				benchmark: 58,
				fullMark: 100
			},
			{
				trait: "الوفاق (A)",
				score: getPct("bf_agreeableness"),
				benchmark: 70,
				fullMark: 100
			},
			{
				trait: "الاتزان الانفعالي (ES)",
				score: getPct("bf_emotional_stability"),
				benchmark: 65,
				fullMark: 100
			}
		],
		hexacoRadar: [
			{
				trait: "الصدق-التواضع (H)",
				score: getPct("hx_honesty_humility"),
				fullMark: 100
			},
			{
				trait: "العاطفية (E)",
				score: getPct("hx_emotionality"),
				fullMark: 100
			},
			{
				trait: "الانبساط (X)",
				score: getPct("hx_extraversion"),
				fullMark: 100
			},
			{
				trait: "التسامح (A)",
				score: getPct("hx_agreeableness"),
				fullMark: 100
			},
			{
				trait: "الاجتهاد (C)",
				score: getPct("hx_conscientiousness"),
				fullMark: 100
			},
			{
				trait: "الانفتاح (O)",
				score: getPct("hx_openness"),
				fullMark: 100
			}
		],
		emotionalIntelligence: [
			{
				branch: "الوعي العاطفي بالذات",
				score: getPct("ei_self_awareness"),
				color: "#ec4899"
			},
			{
				branch: "التعاطف وفهم المشاعر",
				score: getPct("ei_empathy"),
				color: "#8b5cf6"
			},
			{
				branch: "تنظيم الانفعالات وضبطها",
				score: getPct("ei_regulation"),
				color: "#06b6d4"
			},
			{
				branch: "المهارة الاجتماعية والاحتواء",
				score: getPct("ei_social_skill"),
				color: "#10b981"
			}
		],
		attachment: {
			anxiety: attAnxiety,
			avoidance: attAvoidance,
			styleKey: attStyleKey,
			styleAr: attStyleAr,
			styleEn: attStyleEn
		},
		communicationStyles: [
			{
				style: "الحزم المحترم (Assertive)",
				score: getPct("com_assertive"),
				color: "#3b82f6"
			},
			{
				style: "الإنصات التأملي (Reflective)",
				score: getPct("com_reflective"),
				color: "#10b981"
			},
			{
				style: "الوضوح التحليلي (Analytical)",
				score: getPct("com_analytical"),
				color: "#8b5cf6"
			},
			{
				style: "الدفء التعبيري (Expressive)",
				score: getPct("com_expressive"),
				color: "#ec4899"
			}
		],
		conflictModes: [
			{
				mode: "التعاون التكاملي",
				score: collab,
				fullMark: 100
			},
			{
				mode: "الحلول الوسطية",
				score: comprom,
				fullMark: 100
			},
			{
				mode: "المرونة والاستيعاب",
				score: accom,
				fullMark: 100
			},
			{
				mode: "الحسم الفردي",
				score: compet,
				fullMark: 100
			},
			{
				mode: "التجنب والانسحاب",
				score: avoidMode,
				fullMark: 100
			}
		],
		lifeGoalsAlignment: [
			{
				domain: "استقرار الأسرة والمودة",
				userScore: getPct("int_parenting_family"),
				targetBenchmark: 78
			},
			{
				domain: "القيم والمعنى الروحي",
				userScore: getPct("pp_values_meaning"),
				targetBenchmark: 75
			},
			{
				domain: "النمو الفكري والمعرفي",
				userScore: getPct("bf_openness"),
				targetBenchmark: 68
			},
			{
				domain: "الإنجاز والانضباط العملي",
				userScore: getPct("sr_goal_persistence"),
				targetBenchmark: 72
			},
			{
				domain: "الصمود والازدهار النفسي",
				userScore: getPct("pp_resilience_flourishing"),
				targetBenchmark: 74
			}
		],
		compatibilityMatrix: [
			{
				axisA: "الاستقرار العاطفي",
				axisB: "الأمان الارتباطي",
				synergyScore: clampPct((getPct("bf_emotional_stability") + effectiveAttachmentSecurity) / 2),
				labelAr: "تحمل الأزمات بهدوء"
			},
			{
				axisA: "الاستقرار العاطفي",
				axisB: "التواصل البناء",
				synergyScore: clampPct((getPct("bf_emotional_stability") + constructScores.communication) / 2),
				labelAr: "حوار خالٍ من التصعيد"
			},
			{
				axisA: "الاستقرار العاطفي",
				axisB: "الوفاق والنزاهة",
				synergyScore: clampPct((getPct("bf_emotional_stability") + getPct("hx_honesty_humility")) / 2),
				labelAr: "أمانة وثبات مزاجي"
			},
			{
				axisA: "الاستقرار العاطفي",
				axisB: "القيم والأهداف",
				synergyScore: clampPct((getPct("bf_emotional_stability") + getPct("pp_values_meaning")) / 2),
				labelAr: "سكينة معنوية مستدامة"
			},
			{
				axisA: "الذكاء العاطفي",
				axisB: "الأمان الارتباطي",
				synergyScore: clampPct((constructScores.emotional_intelligence + effectiveAttachmentSecurity) / 2),
				labelAr: "احتواء وجداني عميق"
			},
			{
				axisA: "الذكاء العاطفي",
				axisB: "التواصل البناء",
				synergyScore: clampPct((constructScores.emotional_intelligence + constructScores.communication) / 2),
				labelAr: "تعاطف وإنصات فعّال"
			},
			{
				axisA: "الذكاء العاطفي",
				axisB: "الوفاق والنزاهة",
				synergyScore: clampPct((constructScores.emotional_intelligence + getPct("bf_agreeableness")) / 2),
				labelAr: "لطف معنوي ورفق"
			},
			{
				axisA: "الذكاء العاطفي",
				axisB: "القيم والأهداف",
				synergyScore: clampPct((constructScores.emotional_intelligence + getPct("pp_life_goals")) / 2),
				labelAr: "توجيه الطموح برحمة"
			},
			{
				axisA: "التنظيم الذاتي",
				axisB: "الأمان الارتباطي",
				synergyScore: clampPct((constructScores.self_regulation + effectiveAttachmentSecurity) / 2),
				labelAr: "ضبط الاندفاع بالثقة"
			},
			{
				axisA: "التنظيم الذاتي",
				axisB: "التواصل البناء",
				synergyScore: clampPct((getPct("sr_impulse_control") + getPct("com_assertive")) / 2),
				labelAr: "حزم متزن غير جارح"
			},
			{
				axisA: "التنظيم الذاتي",
				axisB: "الوفاق والنزاهة",
				synergyScore: clampPct((getPct("bf_conscientiousness") + getPct("hx_honesty_humility")) / 2),
				labelAr: "وفاء بالعهود والتزام"
			},
			{
				axisA: "التنظيم الذاتي",
				axisB: "القيم والأهداف",
				synergyScore: clampPct((getPct("sr_goal_persistence") + getPct("pp_life_goals")) / 2),
				labelAr: "تحويل الرؤية لإنجاز"
			},
			{
				axisA: "الشراكة الأسرية",
				axisB: "الأمان الارتباطي",
				synergyScore: clampPct((getPct("int_trust_commitment") + effectiveAttachmentSecurity) / 2),
				labelAr: "بناء بيت آمن مستقيم"
			},
			{
				axisA: "الشراكة الأسرية",
				axisB: "التواصل البناء",
				synergyScore: clampPct((getPct("int_repair_synergy") + collab) / 2),
				labelAr: "إصلاح الخلاف بسلاسة"
			},
			{
				axisA: "الشراكة الأسرية",
				axisB: "الوفاق والنزاهة",
				synergyScore: clampPct((getPct("int_boundaries") + getPct("hx_agreeableness")) / 2),
				labelAr: "حفظ الخصوصية باحترام"
			},
			{
				axisA: "الشراكة الأسرية",
				axisB: "القيم والأهداف",
				synergyScore: clampPct((getPct("int_parenting_family") + getPct("pp_values_meaning")) / 2),
				labelAr: "تربية وقدوة مشتركة"
			}
		]
	};
	const rankedPositive = subscales.filter((s) => !SUBSCALE_METADATA[s.key]?.isReversePositive).sort((a, b) => b.percentage - a.percentage);
	const top3 = rankedPositive.slice(0, 3);
	const bottom3 = rankedPositive.slice(-3).reverse();
	let archetypeTitleAr = "الشخصية المتزنة الشاملة";
	let archetypeTitleEn = "Balanced Integrative Profile";
	if (constructScores.emotional_intelligence >= 72 && effectiveAttachmentSecurity >= 70) {
		archetypeTitleAr = "النمط الآمن المتعاطف المتزن (Secure Empathetic Anchor)";
		archetypeTitleEn = "Secure Empathetic Anchor";
	} else if (getPct("bf_conscientiousness") >= 72 && getPct("hx_honesty_humility") >= 70) {
		archetypeTitleAr = "النمط الأمين المنضبط القيادي (Conscientious Principled Leader)";
		archetypeTitleEn = "Conscientious Principled Leader";
	} else if (getPct("bf_openness") >= 72 && getPct("com_analytical") >= 68) {
		archetypeTitleAr = "المفكر التطويري المستكشف (Reflective Growth Thinker)";
		archetypeTitleEn = "Reflective Growth Thinker";
	} else if (overallMaturityIndex < 40) {
		archetypeTitleAr = "مسار النمو واكتشاف الذات (Emerging Self-Discovery Path)";
		archetypeTitleEn = "Emerging Self-Discovery Path";
	}
	const dominantComm = [...visualCharts.communicationStyles].sort((a, b) => b.score - a.score)[0];
	const dominantConflict = [...visualCharts.conflictModes].sort((a, b) => b.score - a.score)[0];
	const strengthsAr = top3.map((s) => `${s.labelAr} (${s.percentage}% • معيار Sten ${s.stenScore}/10): ${s.interpretationAr}`);
	const improvementAreasAr = bottom3.map((s) => `${s.labelAr} (${s.percentage}%): يحتاج لدعم عملي وتدريب تدريجي لرفع مرونتك وتوازنك في المواقف الضاغطة.`);
	const executiveSummaryAr = `أتمّ «${userName}» تقييم «${tierMeta.titleAr}» (${validation.answeredCount}/${validation.totalCount} بنداً) بمؤشر نضج سيكومتري إجمالي قدره ${overallMaturityIndex}% (مرتبة مئينية ${pctToPercentile(overallMaturityIndex)}%) ومؤشر اتساق إجابات داخلي ${consistencyIndex}%. يبرز في البصمة النفسية تفوق واضح في «${top3[0]?.labelAr || ""}» (${top3[0]?.percentage || 50}%) و«${top3[1]?.labelAr || ""}» (${top3[1]?.percentage || 50}%).`;
	const personalityDescriptionAr = `تعكس درجاتك في العوامل الخمسة الكبرى ونموذج HEXACO ملفاً ${overallMaturityIndex >= 65 ? "ناضجاً مستقراً" : "نامياً قابلاً للتمكين"} يرتكز على الصدق والتواضع (${getPct("hx_honesty_humility")}%) ويقظة الضمير (${getPct("bf_conscientiousness")}%)، مع نمط «${attStyleAr}» وميل تواصلي غالبه «${dominantComm.style}» (${dominantComm.score}%).`;
	const communicationStyleAr = `أسلوب تواصلك الأساسي هو «${dominantComm.style}» (${dominantComm.score}%)، مدعوماً بالإنصات التأملي (${getPct("com_reflective")}%) والوضوح التحليلي (${getPct("com_analytical")}%). هذه البنية تساعد على صياغة الاحتياجات بوضوح وتفادي اللوم المباشر.`;
	const emotionalMaturitySummaryAr = `مؤشر الذكاء العاطفي المركب لديك هو ${constructScores.emotional_intelligence}% والتنظيم الذاتي ${constructScores.self_regulation}%، مما يعبر عن قدرتك على استيعاب الانفعالات (${getPct("ei_regulation")}%) والتعاطف الفعلي (${getPct("ei_empathy")}%).`;
	const includeAdvanced = tier === "advanced" || tier === "professional";
	const includePro = tier === "professional";
	const thinkingStyleAnalysisAr = includeAdvanced ? `يجمع نمطك الإدراكي بين الانفتاح الاستكشافي (${getPct("bf_openness")}%) والوضوح التحليلي (${getPct("com_analytical")}%) وإعادة التقييم المعرفي (${getPct("sr_cognitive_reappraisal")}%). عند مواجهة المواقف المعقدة تميل إلى ${getPct("com_analytical") >= getPct("ei_empathy") ? "تفكيك المعطيات منطقياً أولاً ثم مراعاة الأثر الشعوري" : "البدء باستقراء الأثر الإنساني والوجداني ثم ترتيب الخطوات العملية"}.` : void 0;
	const decisionMakingAnalysisAr = includeAdvanced ? `يعتمد أسلوب اتخاذ القرار لديك على يقظة الضمير (${getPct("bf_conscientiousness")}%) وضبط الاندفاع (${getPct("sr_impulse_control")}%). هذا يمنحك تأنياً محسوباً بمعدل ${pctToSten((getPct("bf_conscientiousness") + getPct("sr_impulse_control")) / 2)}/10، ويحد من القرارات الانفعالية تحت الضغط.` : void 0;
	const attachmentAnalysisAr = includeAdvanced ? `وفق نموذج الإحداثيات الثنائي للتعلق (ECR-R): درجة قلق التعلق ${attAnxiety}% ودرجة تجنب القرب ${attAvoidance}%، مع أمان مباشر ${attSecurityDirect}%، ما يصنفك ضمن «${attStyleAr}». تعزيز الوضوح الهادئ وقت المسافة النفسية يضاعف الشعور بالسكينة.` : void 0;
	const conflictResolutionAnalysisAr = includeAdvanced ? `عند نشوء خلاف علائقي، تبرز استراتيجية «${dominantConflict.mode}» (${dominantConflict.score}%) بفضل التعاون التفاوضي (${collab}%) والقدرة على الإصلاح السريع (${getPct("int_repair_synergy")}%). ويُنصح بالحذر من ارتفاع مؤشر التجنب (${avoidMode}%) إذا تجاوز 55%.` : void 0;
	const expectedEmotionalCompatibilityAr = includeAdvanced ? `تشير معادلة التوافق السيكومتري إلى انسجام مرتفع مع شريك يتحلى بـ «الوفاق العالي» (≥ 68%) والاتزان الانفعالي الآمن، لتكوين علاقة تقوم على الثقة (${getPct("int_trust_commitment")}%) والحدود الصحية (${getPct("int_boundaries")}%).` : void 0;
	const familySuccessIndicatorsAr = includeAdvanced ? [
		`مؤشر الأمان والثقة الأسرية (Gottman Trust Metric): ${getPct("int_trust_commitment")}%`,
		`كفاءة الحدود الصحية وحماية خصوصية البيت (Bowen): ${getPct("int_boundaries")}%`,
		`الانسجام في التوجه التربوي وبناء الأسرة: ${getPct("int_parenting_family")}%`,
		`القدرة على احتواء الخلاف وإعادة المودة (Repair Index): ${getPct("int_repair_synergy")}%`
	] : void 0;
	const valuesAndBeliefsAr = includePro ? `تكشف البصمة القيمية (نموذج شوارتز + HEXACO) عن محورية الصدق والنزاهة (${getPct("hx_honesty_humility")}%) والمعنى القيمي العميق (${getPct("pp_values_meaning")}%). تميل لاتخاذ مواقفك الجوهرية من منطلق المبدأ الثابت لا المظهر الاجتماعي العابر.` : void 0;
	const lifeGoalsAnalysisAr = includePro ? `تنسجم أهدافك المستقبلية (${getPct("pp_life_goals")}%) مع المثابرة التنفيذية (${getPct("sr_goal_persistence")}%) والتوجه الأسري (${getPct("int_parenting_family")}%). هذا التلاقي يدعم بناء مسار عائلي ومهني متوازن طويل النفس.` : void 0;
	const stressManagementCapacityAr = includePro ? `تبلغ سعتك التنفيذية لإدارة الضغوط ${constructScores.self_regulation}%: تشمل إعادة التقييم المعرفي (${getPct("sr_cognitive_reappraisal")}%)، والصلابة العصبية (${getPct("sr_stress_resilience")}%)، وضبط الاندفاع (${getPct("sr_impulse_control")}%). عند تراكم الأعباء يُنصح بتفريغ التوتر تدريجياً عبر الحركة والحوار الهادئ.` : void 0;
	const empathyAnalysisAr = includePro ? `يسجل بُعد التعاطف الوجداني والمعرفي ${getPct("ei_empathy")}% مع مهارة اجتماعية ${getPct("ei_social_skill")}% ولطف HEXACO (${getPct("hx_agreeableness")}%). تستطيع استشعار مشاعر الآخرين مبكراً، مع ضرورة التوازن الذاتي لحماية طاقتك النفسية.` : void 0;
	const longTermMaritalCompatibilityAr = includePro ? `تُظهر التنبؤات الطولية بناءً على مثلث (الوفاق + يقظة الضمير + النزاهة + الأمان الارتباطي + الإصلاح العلائقي) مؤشر ديمومة زوجية مقداره ${clampPct(getPct("hx_honesty_humility") * .2 + getPct("bf_conscientiousness") * .2 + effectiveAttachmentSecurity * .2 + getPct("int_repair_synergy") * .2 + getPct("pp_optimism_gratitude") * .2)}%. نجاح الشراكة على المدى البعيد يرتبط بصون طقوس الامتنان الأسبوعية والتفاهم المرن حول الأهداف المالية والتربوية.` : void 0;
	const scientificReferences = Array.from(new Set(Object.keys(CONSTRUCT_SCIENTIFIC_CATALOG).map((ck) => CONSTRUCT_SCIENTIFIC_CATALOG[ck].referenceAr)));
	return {
		id: `tr_${tier}_${Date.now()}`,
		tier,
		tierTitleAr: tierMeta.titleAr,
		tierTitleEn: tierMeta.titleEn,
		questionCount: questions.length,
		answeredCount: validation.answeredCount,
		isComplete: validation.isComplete,
		completionRate: Math.round(validation.answeredCount / Math.max(1, questions.length) * 100),
		consistencyIndex,
		createdAt: (/* @__PURE__ */ new Date()).toISOString(),
		userName,
		overallMaturityIndex,
		overallPercentile: pctToPercentile(overallMaturityIndex),
		overallSten: pctToSten(overallMaturityIndex),
		archetypeTitleAr,
		archetypeTitleEn,
		executiveSummaryAr,
		personalityDescriptionAr,
		strengthsAr,
		improvementAreasAr,
		communicationStyleAr,
		emotionalMaturitySummaryAr,
		thinkingStyleAnalysisAr,
		decisionMakingAnalysisAr,
		attachmentAnalysisAr,
		conflictResolutionAnalysisAr,
		expectedEmotionalCompatibilityAr,
		familySuccessIndicatorsAr,
		valuesAndBeliefsAr,
		lifeGoalsAnalysisAr,
		stressManagementCapacityAr,
		empathyAnalysisAr,
		longTermMaritalCompatibilityAr,
		subscales,
		visualCharts,
		scientificDisclaimerAr: NON_CLINICAL_DISCLAIMER_AR,
		scientificReferences,
		rawAnswersSnapshot: answers
	};
}
//#endregion
export { saveTieredProgressAutoSave as a, profileFromQuestionnaireOrCommunity as c, loadTieredProgressAutoSave as i, profileFromTieredReport as l, calculateTieredPsychometricReport as n, validateTierReportCompleteness as o, clearTieredProgressAutoSave as r, compareTwoPsychometricProfiles as s, NON_CLINICAL_DISCLAIMER_AR as t, profileFromUnifiedRecord as u };
