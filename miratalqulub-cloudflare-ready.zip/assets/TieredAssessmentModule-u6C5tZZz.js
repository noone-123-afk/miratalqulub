const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/ScientificVisualDashboards-BXG0MudB.js","assets/rolldown-runtime-Bk_YeHJf.js","assets/vendor-react-Bm_EF59R.js","assets/index-C5uCeetQ.js","assets/vendor-icons-WoMClU7U.js","assets/sound-C_zXqyNA.js","assets/react-redux-CuCZtN7g.js","assets/firebase-Cu7XUsbK.js","assets/firebaseAuth-D6LKvzXg.js","assets/index-DMmCvB5f.css","assets/pdfReportGenerator-BNu3pVmt.js","assets/index.es-C20Q95Ms.js"])))=>i.map(i=>d[i]);
import { r as __toESM } from "./rolldown-runtime-Bk_YeHJf.js";
import { n as __vitePreload, o as require_react, r as require_jsx_runtime } from "./vendor-react-Bm_EF59R.js";
import { $ as Printer, An as BookOpen, D as Sparkles, En as Brain, F as ShieldAlert, Gt as FileDown, Jt as Eye, K as RotateCcw, Nt as History, Sn as Calendar, St as ListChecks, U as Scale, V as Search, Vt as Funnel, Wt as FileText, _n as ChevronRight, cn as Clock, fn as CirclePlay, h as Trash2, j as SlidersVertical, kn as BookmarkCheck, m as TrendingUp, mn as CircleCheck, p as TriangleAlert, pn as CirclePause, r as X, vn as ChevronLeft } from "./vendor-icons-WoMClU7U.js";
import { t as soundManager } from "./sound-C_zXqyNA.js";
import { d as useAppTheme, l as useLanguage, o as TestScoringTrustBanner, u as useAuth } from "./index-C5uCeetQ.js";
import { a as loadUserPersonalQuestionnaire, t as COMMUNITY_PROFILES } from "./data-compatibility-s3wwWF9Q.js";
import { a as saveTieredProgressAutoSave, c as profileFromQuestionnaireOrCommunity, i as loadTieredProgressAutoSave, l as profileFromTieredReport, n as calculateTieredPsychometricReport, o as validateTierReportCompleteness, r as clearTieredProgressAutoSave, s as compareTwoPsychometricProfiles, t as NON_CLINICAL_DISCLAIMER_AR, u as profileFromUnifiedRecord } from "./engine-comparison-CmI_l5ta.js";
import { a as fetchUnifiedTestHistory, r as deleteUnifiedTestRecord, t as buildTemporalEvolutionSummary, u as saveUnifiedTestRecord } from "./userHistoryService-6N9Zh8ed.js";
import { n as CONSTRUCT_SCIENTIFIC_CATALOG, r as getQuestionsForAnalysisTier, t as ANALYSIS_TIERS_CATALOG } from "./data-tiered-assessment-ByFodY9o.js";
//#region src/components/TieredAssessmentModule.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var LazyScientificVisualDashboards = (0, import_react.lazy)(() => __vitePreload(() => import("./ScientificVisualDashboards-BXG0MudB.js").then((m) => ({ default: m.ScientificVisualDashboards })), __vite__mapDeps([0,1,2,3,4,5,6,7,8,9])));
var LIKERT_OPTIONS = [
	{
		value: 1,
		labelAr: "أعارض بشدة",
		subAr: "لا تنطبق أبداً"
	},
	{
		value: 2,
		labelAr: "أعارض",
		subAr: "نادراً"
	},
	{
		value: 3,
		labelAr: "محايد",
		subAr: "أحياناً / وسط"
	},
	{
		value: 4,
		labelAr: "أوافق",
		subAr: "غالباً"
	},
	{
		value: 5,
		labelAr: "أوافق بشدة",
		subAr: "تنطبق تماماً"
	}
];
var TieredAssessmentModule = ({ userName, onReportSaved, onLaunchComparison }) => {
	const { user } = useAuth();
	const { direction, tailwindClasses } = useLanguage();
	const { theme } = useAppTheme();
	const isLight = theme === "light";
	const [moduleTab, setModuleTab] = (0, import_react.useState)("tiers");
	const [selectedTier, setSelectedTier] = (0, import_react.useState)(null);
	const [runnerMode, setRunnerMode] = (0, import_react.useState)("single");
	const [answers, setAnswers] = (0, import_react.useState)({});
	const [currentIdx, setCurrentIdx] = (0, import_react.useState)(0);
	const [savedProgressMap, setSavedProgressMap] = (0, import_react.useState)({});
	const [pausedNotice, setPausedNotice] = (0, import_react.useState)(null);
	const [validationError, setValidationError] = (0, import_react.useState)(null);
	const [report, setReport] = (0, import_react.useState)(null);
	const [isSavedRecord, setIsSavedRecord] = (0, import_react.useState)(false);
	const [savedRecords, setSavedRecords] = (0, import_react.useState)([]);
	const [loadingRecords, setLoadingRecords] = (0, import_react.useState)(false);
	const [historyFilter, setHistoryFilter] = (0, import_react.useState)("all");
	const [historyTierFilter, setHistoryTierFilter] = (0, import_react.useState)("all");
	const [historySearchQuery, setHistorySearchQuery] = (0, import_react.useState)("");
	const [reopenedRecord, setReopenedRecord] = (0, import_react.useState)(null);
	const [sourceAKey, setSourceAKey] = (0, import_react.useState)("questionnaire");
	const [sourceBKey, setSourceBKey] = (0, import_react.useState)("community:0");
	const [customPartnerB, setCustomPartnerB] = (0, import_react.useState)({
		name: "الشريك المحتمل",
		openness: 76,
		conscientiousness: 80,
		extraversion: 70,
		agreeableness: 84,
		emotionalStability: 78,
		honestyHumility: 85,
		anxiety: 28,
		avoidance: 26,
		emotionalIntelligence: 82,
		communication: 80,
		conflictCollab: 82,
		valuesScore: 86,
		lifeGoalsScore: 82,
		parentingScore: 84
	});
	const [comparisonReport, setComparisonReport] = (0, import_react.useState)(null);
	const [comparisonSaved, setComparisonSaved] = (0, import_react.useState)(false);
	const refreshSavedProgress = () => {
		const next = {};
		ANALYSIS_TIERS_CATALOG.forEach((tierDef) => {
			const saved = loadTieredProgressAutoSave(tierDef.id);
			if (saved && Object.keys(saved.answers).length > 0) next[tierDef.id] = {
				count: Object.keys(saved.answers).length,
				total: tierDef.questionCount,
				updatedAt: saved.updatedAt
			};
		});
		setSavedProgressMap(next);
	};
	const refreshUnifiedHistory = async () => {
		setLoadingRecords(true);
		try {
			const list = await fetchUnifiedTestHistory(user);
			setSavedRecords(list);
			const firstComparable = list.find((r) => r.testType === "tiered_assessment" || r.testType === "psychology");
			if (firstComparable && sourceAKey === "questionnaire") setSourceAKey(`record:${firstComparable.id}`);
		} catch {} finally {
			setLoadingRecords(false);
		}
	};
	(0, import_react.useEffect)(() => {
		refreshSavedProgress();
		refreshUnifiedHistory();
	}, [user]);
	const startOrResumeTier = (tier, forceRestart = false) => {
		soundManager.playTap();
		setValidationError(null);
		setPausedNotice(null);
		setReport(null);
		setIsSavedRecord(false);
		if (forceRestart) {
			clearTieredProgressAutoSave(tier);
			setAnswers({});
			setCurrentIdx(0);
			setSelectedTier(tier);
			refreshSavedProgress();
			return;
		}
		const existing = loadTieredProgressAutoSave(tier);
		const qs = getQuestionsForAnalysisTier(tier);
		if (existing && Object.keys(existing.answers).length > 0) {
			setAnswers(existing.answers);
			setCurrentIdx(Math.min(existing.currentIndex, Math.max(0, qs.length - 1)));
		} else {
			setAnswers({});
			setCurrentIdx(0);
		}
		setSelectedTier(tier);
	};
	const questions = selectedTier ? getQuestionsForAnalysisTier(selectedTier) : [];
	const currentQ = questions[currentIdx];
	const handleSelectValue = (qId, val) => {
		if (!selectedTier) return;
		soundManager.playTap();
		setValidationError(null);
		const updatedAnswers = {
			...answers,
			[qId]: val
		};
		setAnswers(updatedAnswers);
		saveTieredProgressAutoSave({
			tier: selectedTier,
			answers: updatedAnswers,
			currentIndex: currentIdx,
			isPaused: false,
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		});
		refreshSavedProgress();
	};
	const handleNext = () => {
		if (!selectedTier || !currentQ) return;
		if (runnerMode === "batch10") {
			const batchStart = Math.floor(currentIdx / 10) * 10;
			const missingInBatch = questions.slice(batchStart, batchStart + 10).find((q) => {
				const v = answers[q.id];
				return v === void 0 || v === null;
			});
			if (missingInBatch) {
				soundManager.playTap();
				setValidationError(`يرجى الإجابة على جميع أسئلة هذه الصفحة قبل الانتقال (السؤال رقم ${missingInBatch.index} غير مجاب).`);
				return;
			}
			setValidationError(null);
			soundManager.playTap();
			const nextBatchIdx = batchStart + 10;
			if (nextBatchIdx < questions.length) {
				setCurrentIdx(nextBatchIdx);
				saveTieredProgressAutoSave({
					tier: selectedTier,
					answers,
					currentIndex: nextBatchIdx,
					isPaused: false,
					updatedAt: (/* @__PURE__ */ new Date()).toISOString()
				});
			} else finalizeTierReport(answers);
			return;
		}
		const curVal = answers[currentQ.id];
		if (curVal === void 0 || curVal === null) {
			soundManager.playTap();
			setValidationError("يرجى اختيار إجابة لهذا البند أولاً قبل الانتقال للسؤال التالي.");
			return;
		}
		setValidationError(null);
		soundManager.playTap();
		if (currentIdx + 1 < questions.length) {
			const nextIdx = currentIdx + 1;
			setCurrentIdx(nextIdx);
			saveTieredProgressAutoSave({
				tier: selectedTier,
				answers,
				currentIndex: nextIdx,
				isPaused: false,
				updatedAt: (/* @__PURE__ */ new Date()).toISOString()
			});
		} else finalizeTierReport(answers);
	};
	const handlePrev = () => {
		if (!selectedTier || currentIdx === 0) return;
		soundManager.playTap();
		setValidationError(null);
		const prevIdx = runnerMode === "batch10" ? Math.max(0, Math.floor(currentIdx / 10) * 10 - 10) : currentIdx - 1;
		setCurrentIdx(prevIdx);
		saveTieredProgressAutoSave({
			tier: selectedTier,
			answers,
			currentIndex: prevIdx,
			isPaused: false,
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		});
	};
	const handlePauseAndSave = () => {
		if (!selectedTier) return;
		soundManager.playTap();
		saveTieredProgressAutoSave({
			tier: selectedTier,
			answers,
			currentIndex: currentIdx,
			isPaused: true,
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		});
		refreshSavedProgress();
		setSelectedTier(null);
		setPausedNotice(`تم حفظ تقدمك تلقائياً (${Object.keys(answers).length} سؤالاً مجاباً). يمكنك الاستكمال من حيث توقفت في أي وقت.`);
	};
	const finalizeTierReport = async (finalAnswers) => {
		if (!selectedTier) return;
		const qs = getQuestionsForAnalysisTier(selectedTier);
		const check = validateTierReportCompleteness(selectedTier, qs, finalAnswers);
		if (!check.isComplete) {
			setValidationError(check.reasonAr || "يُرجى استكمال جميع الأسئلة قبل اعتماد التقرير النهائي.");
			if (check.missingIds.length > 0) {
				const firstMissingIdx = qs.findIndex((q) => q.id === check.missingIds[0]);
				if (firstMissingIdx >= 0) setCurrentIdx(firstMissingIdx);
			}
			return;
		}
		try {
			const computed = calculateTieredPsychometricReport(selectedTier, finalAnswers, userName || user?.displayName || "مختبَر مِرآة القلوب");
			clearTieredProgressAutoSave(selectedTier);
			refreshSavedProgress();
			soundManager.playResultReveal();
			setReport(computed);
			setSelectedTier(null);
			const rawScores = {};
			const standardizedScores = {};
			computed.subscales.forEach((s) => {
				rawScores[s.key] = s.rawScore;
				standardizedScores[s.key] = s.percentage;
			});
			const tierMeta = ANALYSIS_TIERS_CATALOG.find((t) => t.id === selectedTier);
			await saveUnifiedTestRecord(user || null, {
				testType: "tiered_assessment",
				testTitleAr: `${computed.tierTitleAr} (${computed.questionCount} سؤالاً)`,
				testCategoryAr: "التحليل السيكومتري متعدد المستويات",
				scoreOrArchetype: `${computed.archetypeTitleAr} • ${computed.overallMaturityIndex}%`,
				percentage: computed.overallMaturityIndex,
				badgeColor: tierMeta?.accentColor || "#8b5cf6",
				keyInsights: computed.strengthsAr.slice(0, 3),
				snapshot: computed,
				analysisTier: selectedTier,
				rawScores,
				standardizedScores
			});
			setIsSavedRecord(true);
			refreshUnifiedHistory();
			onReportSaved?.(computed);
		} catch (err) {
			setValidationError(err instanceof Error ? err.message : "تعذر إصدار التقرير: يرجى التأكد من إكمال كافة البنود المطلوبة.");
		}
	};
	const handleDownloadTierPdf = async (targetReport = report, options) => {
		if (!targetReport) return;
		soundManager.playTap();
		const { exportCurrentReportOrAnalysisToPDF } = await __vitePreload(async () => {
			const { exportCurrentReportOrAnalysisToPDF } = await import("./pdfReportGenerator-BNu3pVmt.js");
			return { exportCurrentReportOrAnalysisToPDF };
		}, __vite__mapDeps([10,3,1,2,4,5,11,7,8,9]));
		const sections = [
			{
				title: "وصف الشخصية الأساسي والتركيبة النفسية",
				content: targetReport.personalityDescriptionAr
			},
			{
				title: "نقاط القوة البارزة ومجالات التحسين",
				content: targetReport.emotionalMaturitySummaryAr,
				items: [...targetReport.strengthsAr, ...targetReport.improvementAreasAr]
			},
			{
				title: "أسلوب التواصل والذكاء العاطفي",
				content: targetReport.communicationStyleAr
			}
		];
		if (targetReport.thinkingStyleAnalysisAr) sections.push({
			title: "تحليل نمط التفكير واتخاذ القرار",
			content: `${targetReport.thinkingStyleAnalysisAr} ${targetReport.decisionMakingAnalysisAr || ""}`
		});
		if (targetReport.attachmentAnalysisAr) sections.push({
			title: "نمط التعلق وإدارة النزاعات والتوافق المتوقع",
			content: `${targetReport.attachmentAnalysisAr} ${targetReport.conflictResolutionAnalysisAr || ""} ${targetReport.expectedEmotionalCompatibilityAr || ""}`,
			items: targetReport.familySuccessIndicatorsAr
		});
		if (targetReport.valuesAndBeliefsAr) sections.push({
			title: "الملف الاحترافي: القيم، أهداف الحياة، إدارة الضغوط، والديمومة الزواجية",
			content: `${targetReport.valuesAndBeliefsAr} ${targetReport.lifeGoalsAnalysisAr || ""} ${targetReport.stressManagementCapacityAr || ""} ${targetReport.empathyAnalysisAr || ""} ${targetReport.longTermMaritalCompatibilityAr || ""}`
		});
		exportCurrentReportOrAnalysisToPDF({
			reportTitle: `${targetReport.tierTitleAr} — التقرير السيكومتري الشامل`,
			subTitle: `${targetReport.archetypeTitleAr} (${targetReport.answeredCount}/${targetReport.questionCount} سؤالاً)`,
			scientificBasis: targetReport.scientificReferences.join(" • "),
			userName: targetReport.userName,
			completedAt: new Date(targetReport.createdAt).toLocaleDateString("ar-JO"),
			overallScoreLabel: "مؤشر النضج السيكومتري الكلي",
			overallScoreValue: `${targetReport.overallMaturityIndex}%`,
			cognitiveFingerprintTitle: `الاتساق الداخلي ${targetReport.consistencyIndex}% • المعيارية ${targetReport.overallPercentile}%`,
			executiveSummary: targetReport.executiveSummaryAr,
			metrics: targetReport.subscales.slice(0, 14).map((s) => ({
				label: s.labelAr,
				scorePercent: s.percentage,
				levelLabel: `Sten ${s.stenScore}/10 • T=${s.tScore}`,
				rawText: s.interpretationAr,
				color: s.color
			})),
			sections,
			careersOrRecommendations: targetReport.improvementAreasAr,
			disclaimerText: targetReport.scientificDisclaimerAr,
			visualCharts: targetReport.visualCharts
		}, options);
	};
	const handleDownloadSavedRecordPdf = async (rec, options) => {
		soundManager.playTap();
		if (rec.snapshot && rec.snapshot.subscales && rec.snapshot.visualCharts) {
			await handleDownloadTierPdf(rec.snapshot, options);
			return;
		}
		const { exportCurrentReportOrAnalysisToPDF } = await __vitePreload(async () => {
			const { exportCurrentReportOrAnalysisToPDF } = await import("./pdfReportGenerator-BNu3pVmt.js");
			return { exportCurrentReportOrAnalysisToPDF };
		}, __vite__mapDeps([10,3,1,2,4,5,11,7,8,9]));
		if (rec.testType === "personality_comparison" && rec.snapshot?.nineAxesBreakdown) {
			const cmp = rec.snapshot;
			exportCurrentReportOrAnalysisToPDF({
				reportTitle: "تقرير مقارنة شخصيتين عبر المحاور التسعة السيكومترية",
				subTitle: `${cmp.personA.personName} ✕ ${cmp.personB.personName}`,
				scientificBasis: (cmp.scientificReferences || []).join(" • "),
				userName: cmp.personA.personName,
				completedAt: new Date(rec.createdAt).toLocaleDateString("ar-JO"),
				overallScoreLabel: "التوافق الإجمالي الموزون",
				overallScoreValue: `${cmp.overallWeightedCompatibility}%`,
				cognitiveFingerprintTitle: cmp.compatibilityClassificationAr,
				executiveSummary: cmp.executiveSummaryAr,
				metrics: (cmp.subIndices || []).map((s) => ({
					label: s.titleAr,
					scorePercent: s.score,
					levelLabel: `وزن ${Math.round(s.weight * 100)}%`,
					rawText: s.interpretationAr,
					color: "#059669"
				})),
				sections: (cmp.nineAxesBreakdown || []).map((ax) => ({
					title: ax.axisNameAr,
					badge: `توافق ${ax.matchScore}%`,
					content: ax.scientificNoteAr
				})),
				comparisonDualRadar: {
					personAName: cmp.personA.personName,
					personBName: cmp.personB.personName,
					axes: cmp.nineAxesBreakdown
				}
			}, options);
			return;
		}
		exportCurrentReportOrAnalysisToPDF({
			reportTitle: rec.testTitleAr,
			subTitle: rec.testCategoryAr,
			scientificBasis: "APA Validated Psychometric Models • Mirror of Hearts Lab",
			userName: userName || user?.displayName || "المختبَر",
			completedAt: new Date(rec.createdAt).toLocaleDateString("ar-JO"),
			overallScoreLabel: "النتيجة المعيارية",
			overallScoreValue: rec.scoreOrArchetype,
			cognitiveFingerprintTitle: rec.testTitleAr,
			executiveSummary: (rec.keyInsights || []).join(" — ") || rec.scoreOrArchetype,
			metrics: Object.entries(rec.standardizedScores || {}).map(([k, v]) => ({
				label: k,
				scorePercent: Number(v) || rec.percentage,
				levelLabel: "معياري معتمد",
				color: rec.badgeColor || "#8b5cf6"
			})),
			sections: [{
				title: "أبرز المؤشرات السيكومترية المستخلصة",
				content: rec.scoreOrArchetype,
				items: rec.keyInsights || []
			}]
		}, options);
	};
	const handleDeleteRecord = async (id) => {
		soundManager.playTap();
		await deleteUnifiedTestRecord(user, id);
		setSavedRecords((prev) => prev.filter((r) => r.id !== id));
		if (reopenedRecord?.id === id) setReopenedRecord(null);
	};
	const resolveComparisonProfile = (key, fallbackLabel) => {
		if (key === "active_report" && report) return profileFromTieredReport(report);
		if (key.startsWith("record:")) {
			const recId = key.replace("record:", "");
			const found = savedRecords.find((r) => r.id === recId);
			if (found) return profileFromUnifiedRecord(found);
		}
		if (key.startsWith("community:")) {
			const idx = Number(key.replace("community:", "")) || 0;
			const member = COMMUNITY_PROFILES[idx] || COMMUNITY_PROFILES[0];
			return profileFromQuestionnaireOrCommunity(member, member.displayName);
		}
		if (key === "custom_sliders") return {
			personName: customPartnerB.name || "شريك محتمل",
			personLabelAr: customPartnerB.name || "شريك محتمل (تخصيص مباشر)",
			sourceType: "live_assessment",
			bigFive: {
				openness: customPartnerB.openness,
				conscientiousness: customPartnerB.conscientiousness,
				extraversion: customPartnerB.extraversion,
				agreeableness: customPartnerB.agreeableness,
				emotionalStability: customPartnerB.emotionalStability
			},
			hexaco: {
				honestyHumility: customPartnerB.honestyHumility,
				emotionality: 100 - customPartnerB.emotionalStability * .45,
				extraversion: customPartnerB.extraversion,
				agreeableness: customPartnerB.agreeableness,
				conscientiousness: customPartnerB.conscientiousness,
				openness: customPartnerB.openness
			},
			attachment: {
				anxiety: customPartnerB.anxiety,
				avoidance: customPartnerB.avoidance,
				styleAr: customPartnerB.anxiety < 50 && customPartnerB.avoidance < 50 ? "نمط التعلق الآمن" : "نمط تعلق حساس"
			},
			emotionalIntelligence: customPartnerB.emotionalIntelligence,
			communicationStyle: {
				assertive: customPartnerB.communication,
				reflective: customPartnerB.agreeableness,
				analytical: customPartnerB.openness,
				expressive: customPartnerB.extraversion,
				primaryAr: "تواصل متوازن وواضح"
			},
			conflictResolution: {
				collaborating: customPartnerB.conflictCollab,
				compromising: Math.round((customPartnerB.conflictCollab + customPartnerB.agreeableness) / 2),
				accommodating: customPartnerB.agreeableness,
				competing: Math.max(15, 100 - customPartnerB.agreeableness),
				avoiding: customPartnerB.avoidance,
				primaryAr: "التعاون التكاملي"
			},
			valuesScore: customPartnerB.valuesScore,
			lifeGoals: {
				familyStability: customPartnerB.lifeGoalsScore,
				careerGrowth: customPartnerB.conscientiousness,
				intellectualDepth: customPartnerB.openness,
				socialHarmony: customPartnerB.extraversion,
				financialSecurity: customPartnerB.conscientiousness
			},
			parentingOrientation: customPartnerB.parentingScore
		};
		const qData = loadUserPersonalQuestionnaire();
		return profileFromQuestionnaireOrCommunity(qData, userName || fallbackLabel);
	};
	const handleRunComparison = () => {
		soundManager.playResultReveal();
		setComparisonSaved(false);
		const profA = resolveComparisonProfile(sourceAKey, userName || "الشخص الأول (أ)");
		const profB = resolveComparisonProfile(sourceBKey, "الشخص الثاني (ب)");
		const computed = compareTwoPsychometricProfiles(profA, profB);
		setComparisonReport(computed);
	};
	const handleSaveComparisonToHistory = async () => {
		if (!comparisonReport) return;
		soundManager.playTap();
		await saveUnifiedTestRecord(user || null, {
			testType: "personality_comparison",
			testTitleAr: `مقارنة: ${comparisonReport.personA.personName} ✕ ${comparisonReport.personB.personName}`,
			testCategoryAr: "مقارنة شخصيتين علمياً (9 محاور)",
			scoreOrArchetype: `${comparisonReport.overallWeightedCompatibility}% • ${comparisonReport.compatibilityClassificationAr}`,
			percentage: comparisonReport.overallWeightedCompatibility,
			badgeColor: "#059669",
			keyInsights: comparisonReport.subIndices.map((s) => `${s.titleAr}: ${s.score}%`),
			snapshot: comparisonReport,
			standardizedScores: Object.fromEntries(comparisonReport.subIndices.map((s) => [s.key, s.score]))
		});
		setComparisonSaved(true);
		refreshUnifiedHistory();
	};
	const containerCard = isLight ? "bg-white border-slate-200 text-slate-900 shadow-lg" : "bg-slate-900/80 border-white/10 text-slate-100 shadow-xl";
	if (report) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `rounded-3xl border p-5 sm:p-8 space-y-6 ${containerCard} ${tailwindClasses.containerClass}`,
		dir: direction,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-500/20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-xs font-bold opacity-75",
					children: [
						report.tierTitleAr,
						" · ",
						report.answeredCount,
						"/",
						report.questionCount,
						" بنداً · اتساق داخلي",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums font-bold",
							children: [report.consistencyIndex, "%"]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl sm:text-2xl font-black mt-1 font-['Alexandria']",
					children: report.archetypeTitleAr
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2 no-print",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => handleDownloadTierPdf(report, {
								textOnly: false,
								mode: "pdf"
							}),
							className: "px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileDown, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تنزيل التقرير الكامل (PDF بالرسوم البيانية)" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => handleDownloadTierPdf(report, {
								textOnly: true,
								mode: "pdf"
							}),
							className: "px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تصدير PDF نصي نظيف" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => handleDownloadTierPdf(report, {
								textOnly: false,
								mode: "print"
							}),
							className: "px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "طباعة نظيفة A4" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								soundManager.playTap();
								if (onLaunchComparison) onLaunchComparison(report);
								setSourceAKey("active_report");
								setReport(null);
								setModuleTab("two_person_compare");
								setTimeout(() => {
									const profA = profileFromTieredReport(report);
									const profB = resolveComparisonProfile(sourceBKey, "الشخص الثاني (ب)");
									setComparisonReport(compareTwoPsychometricProfiles(profA, profB));
								}, 40);
							},
							className: "px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scale, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "مقارنة شخصيتين بهذه النتيجة" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								soundManager.playTap();
								setReport(null);
							},
							className: `px-3.5 py-2 rounded-xl border text-xs font-bold transition cursor-pointer ${isLight ? "bg-slate-100 border-slate-300 text-slate-700" : "bg-white/5 border-white/15 text-slate-200"}`,
							children: "العودة لمستويات التحليل"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `p-3.5 rounded-2xl border text-xs leading-relaxed flex items-start gap-2.5 ${isLight ? "bg-amber-50 border-amber-200 text-amber-900" : "bg-amber-950/30 border-amber-500/30 text-amber-200"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "w-4 h-4 shrink-0 mt-0.5 text-amber-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: report.scientificDisclaimerAr })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 sm:grid-cols-4 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `p-3.5 rounded-2xl border ${isLight ? "bg-slate-50 border-slate-200" : "bg-white/[0.03] border-white/10"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] opacity-75 font-bold",
							children: "مؤشر النضج السيكومتري"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-2xl font-black text-purple-500 tabular-nums mt-0.5",
							children: [report.overallMaturityIndex, "%"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `p-3.5 rounded-2xl border ${isLight ? "bg-slate-50 border-slate-200" : "bg-white/[0.03] border-white/10"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] opacity-75 font-bold",
							children: "الدرجة المعيارية Sten"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-2xl font-black text-emerald-500 tabular-nums mt-0.5",
							children: [report.overallSten, " / 10"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `p-3.5 rounded-2xl border ${isLight ? "bg-slate-50 border-slate-200" : "bg-white/[0.03] border-white/10"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] opacity-75 font-bold",
							children: "الترتيب المئيني"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-2xl font-black text-sky-500 tabular-nums mt-0.5",
							children: [report.overallPercentile, "%"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `p-3.5 rounded-2xl border ${isLight ? "bg-slate-50 border-slate-200" : "bg-white/[0.03] border-white/10"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] opacity-75 font-bold",
							children: "حالة الحفظ التلقائي"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs font-extrabold text-emerald-500 flex items-center gap-1 mt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isSavedRecord ? "محفوظ في سجل تقاريري" : "تم الحساب بدقة" })]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `p-4 sm:p-5 rounded-2xl border space-y-2 ${isLight ? "bg-slate-50 border-slate-200" : "bg-black/25 border-white/10"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-extrabold text-sm",
						children: "الملخص التنفيذي وبنية الشخصية"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs sm:text-sm leading-relaxed opacity-90",
						children: report.executiveSummaryAr
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs sm:text-sm leading-relaxed opacity-85",
						children: report.personalityDescriptionAr
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 md:grid-cols-2 gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `p-4 rounded-2xl border space-y-2 ${isLight ? "bg-emerald-50/70 border-emerald-200" : "bg-emerald-950/20 border-emerald-500/20"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "font-extrabold text-xs sm:text-sm text-emerald-500",
						children: "أبرز نقاط القوة السيكومترية"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-1.5 text-xs leading-relaxed",
						children: report.strengthsAr.map((st, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["• ", st] }, idx))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `p-4 rounded-2xl border space-y-2 ${isLight ? "bg-amber-50/70 border-amber-200" : "bg-amber-950/20 border-amber-500/20"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "font-extrabold text-xs sm:text-sm text-amber-500",
						children: "نقاط التحسين والنمو المقترحة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-1.5 text-xs leading-relaxed",
						children: report.improvementAreasAr.map((imp, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["• ", imp] }, idx))
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 md:grid-cols-2 gap-4 text-xs leading-relaxed",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `p-4 rounded-2xl border space-y-1.5 ${isLight ? "bg-white border-slate-200" : "bg-white/[0.03] border-white/10"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "font-extrabold text-sm",
						children: "أسلوب التواصل السائد"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "opacity-85",
						children: report.communicationStyleAr
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `p-4 rounded-2xl border space-y-1.5 ${isLight ? "bg-white border-slate-200" : "bg-white/[0.03] border-white/10"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "font-extrabold text-sm",
						children: "مؤشر النضج العاطفي والتنظيم"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "opacity-85",
						children: report.emotionalMaturitySummaryAr
					})]
				})]
			}),
			report.thinkingStyleAnalysisAr && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 md:grid-cols-2 gap-4 text-xs leading-relaxed",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `p-4 rounded-2xl border space-y-1.5 ${isLight ? "bg-indigo-50/60 border-indigo-200" : "bg-indigo-950/25 border-indigo-500/25"}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "font-extrabold text-sm text-indigo-400",
							children: "نمط التفكير واتخاذ القرار"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: report.thinkingStyleAnalysisAr }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "opacity-85",
							children: report.decisionMakingAnalysisAr
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `p-4 rounded-2xl border space-y-1.5 ${isLight ? "bg-rose-50/60 border-rose-200" : "bg-rose-950/25 border-rose-500/25"}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "font-extrabold text-sm text-rose-400",
							children: "نمط التعلق وإدارة النزاعات والتوافق العاطفي"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: report.attachmentAnalysisAr }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "opacity-85",
							children: report.conflictResolutionAnalysisAr
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "opacity-85",
							children: report.expectedEmotionalCompatibilityAr
						})
					]
				})]
			}),
			report.familySuccessIndicatorsAr && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `p-4 rounded-2xl border space-y-2 text-xs ${isLight ? "bg-slate-50 border-slate-200" : "bg-white/[0.03] border-white/10"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
					className: "font-extrabold text-sm",
					children: "مؤشرات النجاح والاستقرار الأسري"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 gap-2",
					children: report.familySuccessIndicatorsAr.map((ind, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["✓ ", ind] }, i))
				})]
			}),
			report.valuesAndBeliefsAr && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `p-5 rounded-2xl border space-y-3 text-xs leading-relaxed ${isLight ? "bg-purple-50/70 border-purple-200" : "bg-purple-950/20 border-purple-500/25"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "font-extrabold text-sm text-purple-400",
						children: "الملف الاحترافي المعمق (Professional Dossier)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 md:grid-cols-2 gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "block mb-1",
								children: "القيم والمعتقدات الجوهرية:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "opacity-90",
								children: report.valuesAndBeliefsAr
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "block mb-1",
								children: "أهداف الحياة والتخطيط طويل المدى:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "opacity-90",
								children: report.lifeGoalsAnalysisAr
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "block mb-1",
								children: "القدرة على إدارة الضغوط والتنظيم التنفيذي:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "opacity-90",
								children: report.stressManagementCapacityAr
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "block mb-1",
								children: "التعاطف والقدرة على الاحتواء العاطفي:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "opacity-90",
								children: report.empathyAnalysisAr
							})] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pt-2 border-t border-purple-500/20",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "block mb-1",
							children: "مؤشر التوافق الزواجي طويل الأمد:"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "opacity-90",
							children: report.longTermMaritalCompatibilityAr
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
				fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "p-8 text-center text-xs font-bold opacity-75",
					children: "جارٍ تحميل اللوحات البصرية السيكومترية الـ 9..."
				}),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LazyScientificVisualDashboards, {
					charts: report.visualCharts,
					userName: report.userName
				})
			})
		]
	});
	if (selectedTier && currentQ) {
		const tierMeta = ANALYSIS_TIERS_CATALOG.find((t) => t.id === selectedTier);
		const constructMeta = CONSTRUCT_SCIENTIFIC_CATALOG[currentQ.construct];
		const currentAnswer = answers[currentQ.id];
		const answeredTotal = Object.keys(answers).length;
		const progressPct = Math.round(answeredTotal / questions.length * 100);
		const batchStart = Math.floor(currentIdx / 10) * 10;
		const batchSlice = questions.slice(batchStart, batchStart + 10);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: `rounded-3xl border p-5 sm:p-7 space-y-5 ${containerCard} ${tailwindClasses.containerClass}`,
			dir: direction,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-500/20",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xs font-bold text-purple-500",
						children: [
							tierMeta.titleAr,
							" · ",
							constructMeta.titleAr
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xs opacity-75 mt-0.5 tabular-nums",
						children: [
							runnerMode === "batch10" ? `الأسئلة ${batchStart + 1} – ${Math.min(questions.length, batchStart + 10)} من ${questions.length}` : `السؤال ${currentIdx + 1} من ${questions.length}`,
							" ",
							"· تم إنجاز ",
							answeredTotal,
							" سؤالاً (",
							progressPct,
							"%)"
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `flex items-center rounded-xl border p-0.5 text-[11px] font-bold ${isLight ? "bg-slate-100 border-slate-300" : "bg-white/5 border-white/15"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setRunnerMode("single"),
									className: `px-2.5 py-1 rounded-lg transition cursor-pointer ${runnerMode === "single" ? "bg-purple-600 text-white" : "opacity-75"}`,
									children: "سؤال بسؤال"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setRunnerMode("batch10"),
									className: `px-2.5 py-1 rounded-lg transition cursor-pointer flex items-center gap-1 ${runnerMode === "batch10" ? "bg-purple-600 text-white" : "opacity-75"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListChecks, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "10 أسئلة بالصفحة" })]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: handlePauseAndSave,
								className: `px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 cursor-pointer ${isLight ? "bg-amber-50 border-amber-300 text-amber-800" : "bg-amber-500/15 border-amber-500/35 text-amber-300"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CirclePause, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "إيقاف مؤقت وحفظ" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => startOrResumeTier(selectedTier, true),
								className: `px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1 cursor-pointer ${isLight ? "bg-slate-100 border-slate-300 text-slate-700" : "bg-white/5 border-white/15 text-slate-300"}`,
								title: "إعادة البدء من البداية",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "إعادة" })]
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `w-full h-2.5 rounded-full overflow-hidden ${isLight ? "bg-slate-200" : "bg-white/10"}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full rounded-full transition-all duration-300",
						style: {
							width: `${Math.max(3, progressPct)}%`,
							backgroundColor: tierMeta.accentColor
						}
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TestScoringTrustBanner, { compact: true }),
				runnerMode === "batch10" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-4",
					children: batchSlice.map((qItem) => {
						const qAns = answers[qItem.id];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `p-4 rounded-2xl border space-y-3 ${isLight ? "bg-slate-50/70 border-slate-200" : "bg-white/[0.03] border-white/10"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center justify-between gap-2 text-[11px] font-bold opacity-80",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										"#",
										qItem.index,
										" · البُعد المقاس: ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-purple-400",
											children: qItem.facetAr
										})
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: qItem.scientificReference })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "text-sm sm:text-base font-extrabold leading-relaxed font-['Alexandria']",
									children: qItem.textAr
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] opacity-75",
									children: qItem.dimensionExplanationAr
								}),
								qItem.format === "forced_choice" && qItem.forcedOptions ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-2.5",
									children: qItem.forcedOptions.map((opt) => {
										const selected = qAns === opt.id;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => handleSelectValue(qItem.id, opt.id),
											className: `p-3 rounded-xl border text-right transition cursor-pointer ${selected ? "bg-purple-600 text-white border-purple-400 shadow-md" : isLight ? "bg-white hover:bg-slate-100 border-slate-200 text-slate-800" : "bg-white/5 hover:bg-white/10 border-white/10 text-slate-200"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-[11px] font-black opacity-80",
												children: ["الخيار ", opt.id]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-xs font-bold leading-relaxed mt-0.5",
												children: opt.textAr
											})]
										}, opt.id);
									})
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-5 gap-2",
									children: LIKERT_OPTIONS.map((opt) => {
										const selected = qAns === opt.value;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => handleSelectValue(qItem.id, opt.value),
											className: `p-2.5 rounded-xl border text-center transition cursor-pointer flex flex-col items-center justify-center gap-0.5 ${selected ? "bg-purple-600 text-white border-purple-400 shadow-md" : isLight ? "bg-white hover:bg-slate-100 border-slate-200 text-slate-800" : "bg-white/5 hover:bg-white/10 border-white/10 text-slate-200"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-sm font-black tabular-nums",
												children: opt.value
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] font-bold",
												children: opt.labelAr
											})]
										}, opt.value);
									})
								})
							]
						}, qItem.id);
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs font-bold opacity-80",
							children: [
								"البُعد المقاس: ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-purple-400",
									children: currentQ.facetAr
								}),
								" ·",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: currentQ.format === "forced_choice" ? "اختيار قسري ثنائي" : "مقياس ليكرت الخماسي" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-lg sm:text-xl font-black leading-relaxed font-['Alexandria']",
							children: currentQ.textAr
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `p-3 rounded-xl border text-xs leading-relaxed flex items-start gap-2 ${isLight ? "bg-slate-50 border-slate-200 text-slate-700" : "bg-white/[0.04] border-white/10 text-slate-300"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "w-4 h-4 text-purple-400 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-bold",
								children: [
									"التفسير العلمي للبُعد (",
									currentQ.scientificReference,
									"): "
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: currentQ.dimensionExplanationAr })] })]
						})
					]
				}), currentQ.format === "forced_choice" && currentQ.forcedOptions ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
					children: currentQ.forcedOptions.map((opt) => {
						const selected = currentAnswer === opt.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => handleSelectValue(currentQ.id, opt.id),
							className: `p-4 rounded-2xl border text-right transition cursor-pointer flex flex-col justify-between gap-2 ${selected ? "bg-purple-600 text-white border-purple-400 shadow-lg" : isLight ? "bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-800" : "bg-white/5 hover:bg-white/10 border-white/10 text-slate-200"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs font-black opacity-80",
								children: ["الخيار ", opt.id]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-bold leading-relaxed",
								children: opt.textAr
							})]
						}, opt.id);
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 sm:grid-cols-5 gap-2.5",
					children: LIKERT_OPTIONS.map((opt) => {
						const selected = currentAnswer === opt.value;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => handleSelectValue(currentQ.id, opt.value),
							className: `p-3.5 rounded-2xl border text-center transition cursor-pointer flex flex-col items-center justify-center gap-1 ${selected ? "bg-purple-600 text-white border-purple-400 shadow-lg scale-[1.02]" : isLight ? "bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-800" : "bg-white/5 hover:bg-white/10 border-white/10 text-slate-200"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-base font-black tabular-nums",
									children: opt.value
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-extrabold",
									children: opt.labelAr
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] opacity-75",
									children: opt.subAr
								})
							]
						}, opt.value);
					})
				})] }),
				validationError && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-3 rounded-xl bg-rose-500/15 border border-rose-500/40 text-rose-400 text-xs font-bold flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "w-4 h-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: validationError })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between pt-3 border-t border-slate-500/20",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: handlePrev,
						disabled: currentIdx === 0,
						className: `px-4 py-2 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed ${isLight ? "bg-slate-100 border-slate-300 text-slate-700" : "bg-white/5 border-white/15 text-slate-200"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "السابق" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: handleNext,
						className: "px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-rose-600 hover:opacity-95 text-white text-xs sm:text-sm font-extrabold flex items-center gap-1.5 transition cursor-pointer shadow-md",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: runnerMode === "batch10" && batchStart + 10 >= questions.length || runnerMode === "single" && currentIdx + 1 === questions.length ? "اعتماد النتائج وعرض التقرير" : runnerMode === "batch10" ? "الصفحة التالية (10 أسئلة)" : "التالي" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "w-4 h-4" })]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] opacity-70 text-center",
					children: NON_CLINICAL_DISCLAIMER_AR
				})
			]
		});
	}
	const evolution = buildTemporalEvolutionSummary(savedRecords);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		"aria-label": "مستويات التحليل النفسي المعتمدة وسجل التقارير والمقارنة",
		className: `rounded-3xl border p-5 sm:p-7 space-y-5 ${containerCard} ${tailwindClasses.containerClass}`,
		dir: direction,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "text-lg sm:text-xl font-black font-['Alexandria'] flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "w-5 h-5 text-purple-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "منظومة التحليل النفسي متعدد المستويات والتقارير والمقارنة السيكومترية" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs opacity-80 leading-relaxed",
						children: "مبنية حصرياً على النماذج العلمية الثمانية المعتمدة (Big Five · HEXACO · Attachment · Emotional Intelligence · Self Regulation · Interpersonal · Communication · Positive Psychology)"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TestScoringTrustBanner, { compact: true }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `grid grid-cols-1 sm:grid-cols-3 gap-2 p-1.5 rounded-2xl border ${isLight ? "bg-slate-100 border-slate-200" : "bg-black/40 border-white/10"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							soundManager.playTap();
							setModuleTab("tiers");
						},
						className: `py-2.5 px-3 rounded-xl text-xs font-extrabold transition cursor-pointer flex items-center justify-center gap-1.5 ${moduleTab === "tiers" ? "bg-purple-600 text-white shadow-md" : "opacity-75 hover:opacity-100"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "مستويات التحليل الثلاثة (32 / 144 / 288)" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							soundManager.playTap();
							setModuleTab("reports_timeline");
							refreshUnifiedHistory();
						},
						className: `py-2.5 px-3 rounded-xl text-xs font-extrabold transition cursor-pointer flex items-center justify-center gap-1.5 ${moduleTab === "reports_timeline" ? "bg-emerald-600 text-white shadow-md" : "opacity-75 hover:opacity-100"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							"سجل تقاريري وتتبع التغير مع الزمن (",
							savedRecords.length,
							")"
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							soundManager.playTap();
							setModuleTab("two_person_compare");
						},
						className: `py-2.5 px-3 rounded-xl text-xs font-extrabold transition cursor-pointer flex items-center justify-center gap-1.5 ${moduleTab === "two_person_compare" ? "bg-indigo-600 text-white shadow-md" : "opacity-75 hover:opacity-100"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scale, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "مقارنة شخصيتين (9 محاور + 6 مؤشرات)" })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `p-3 rounded-2xl border text-xs leading-relaxed flex items-start gap-2 ${isLight ? "bg-amber-50 border-amber-200 text-amber-900" : "bg-amber-950/25 border-amber-500/30 text-amber-200"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "w-4 h-4 shrink-0 mt-0.5 text-amber-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: NON_CLINICAL_DISCLAIMER_AR })]
			}),
			moduleTab === "tiers" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [pausedNotice && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-3.5 rounded-2xl bg-emerald-500/15 border border-emerald-500/35 text-emerald-400 text-xs font-bold flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-4 h-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: pausedNotice })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 md:grid-cols-3 gap-4",
				children: ANALYSIS_TIERS_CATALOG.map((tierDef) => {
					const saved = savedProgressMap[tierDef.id];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `rounded-2xl border p-5 flex flex-col justify-between gap-4 transition ${isLight ? "bg-slate-50/80 border-slate-200 hover:border-purple-400" : "bg-white/[0.03] border-white/10 hover:border-purple-500/45"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[11px] font-extrabold",
										style: { color: tierDef.accentColor },
										children: tierDef.badgeAr
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[11px] font-bold opacity-75 flex items-center gap-1 tabular-nums",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "w-3.5 h-3.5" }), tierDef.durationLabelAr]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-base sm:text-lg font-black font-['Alexandria']",
									children: tierDef.titleAr
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs opacity-80 leading-relaxed",
									children: tierDef.descriptionAr
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1 pt-2 border-t border-slate-500/15",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] font-bold opacity-75",
										children: "مخرجات التقرير:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "space-y-1 text-[11px] opacity-90",
										children: tierDef.outputsAr.map((out, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "flex items-start gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {
												className: "w-3 h-3 shrink-0 mt-0.5",
												style: { color: tierDef.accentColor }
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: out })]
										}, idx))
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-2 pt-2",
							children: saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => startOrResumeTier(tierDef.id, false),
								className: "w-full py-2.5 px-4 rounded-xl text-white text-xs font-extrabold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-md",
								style: { backgroundColor: tierDef.accentColor },
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CirclePlay, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"استكمال التقييم (",
									saved.count,
									"/",
									saved.total,
									")"
								] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => startOrResumeTier(tierDef.id, true),
								className: `w-full py-1.5 px-3 rounded-xl border text-[11px] font-bold transition cursor-pointer ${isLight ? "border-slate-300 text-slate-600" : "border-white/15 text-slate-300"}`,
								children: "بدء محاولة جديدة من الصفر"
							})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => startOrResumeTier(tierDef.id, false),
								className: "w-full py-2.5 px-4 rounded-xl text-white text-xs font-extrabold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-md hover:opacity-95",
								style: { backgroundColor: tierDef.accentColor },
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"ابدأ ",
									tierDef.titleAr,
									" الآن"
								] })
							})
						})]
					}, tierDef.id);
				})
			})] }),
			moduleTab === "reports_timeline" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `p-4 sm:p-5 rounded-2xl border space-y-3 ${isLight ? "bg-emerald-50/50 border-emerald-200" : "bg-emerald-950/20 border-emerald-500/25"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "text-sm sm:text-base font-extrabold flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "w-4 h-4 text-emerald-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تتبع التغير مع الزمن: نتائج اليوم × الشهر الماضي × العام الماضي" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs opacity-80 mt-0.5",
								children: evolution.trendInsightAr
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs font-black text-emerald-500 tabular-nums",
								children: ["مؤشر التغير: ", evolution.trendDelta >= 0 ? `+${evolution.trendDelta}%` : `${evolution.trendDelta}%`]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs",
							children: evolution.buckets.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `p-3.5 rounded-xl border ${isLight ? "bg-white border-slate-200" : "bg-black/35 border-white/10"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between font-bold opacity-75",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: b.periodLabelAr }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [b.count, " تقرير"] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xl font-black text-emerald-500 tabular-nums my-1",
										children: b.count > 0 ? `${b.avgScore}%` : "لا توجد سجلات"
									}),
									b.count > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1 text-[11px] opacity-85 pt-1 border-t border-slate-500/15",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "النضج النفسي والعاطفي:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
													className: "tabular-nums",
													children: [b.emotionalAvg, "%"]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "الأداء المعرفي والذكاء:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
													className: "tabular-nums",
													children: [b.cognitiveAvg, "%"]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "التوافق العلائقي والأسري:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
													className: "tabular-nums",
													children: [b.relationalAvg, "%"]
												})]
											})
										]
									})
								]
							}, b.periodKey))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 sm:grid-cols-3 gap-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative sm:col-span-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "w-4 h-4 opacity-50 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								"aria-label": "ابحث في سجل تقاريري",
								placeholder: "ابحث باسم التقرير، المستوى، أو النمط السيكومتري...",
								value: historySearchQuery,
								onChange: (e) => setHistorySearchQuery(e.target.value),
								className: `w-full pr-9 pl-3 py-2 rounded-xl border text-xs outline-none ${isLight ? "bg-slate-50 border-slate-300 text-slate-900" : "bg-black/40 border-white/15 text-white"}`
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							"aria-label": "تصفية حسب مستوى التحليل",
							value: historyTierFilter,
							onChange: (e) => setHistoryTierFilter(e.target.value),
							className: `px-3 py-2 rounded-xl border text-xs outline-none ${isLight ? "bg-slate-50 border-slate-300 text-slate-900" : "bg-black/40 border-white/15 text-white"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "all",
									children: "كل مستويات التحليل"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "quick",
									children: "التحليل السريع (32)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "advanced",
									children: "التحليل المتقدم (144)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "professional",
									children: "التحليل الاحترافي (288)"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 overflow-x-auto pb-1 text-xs font-bold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "opacity-70 flex items-center gap-1 shrink-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { className: "w-3.5 h-3.5" }), " تصنيف:"]
						}), [
							{
								id: "all",
								label: `الكل (${savedRecords.length})`
							},
							{
								id: "tiered_assessment",
								label: `مستويات التحليل (${savedRecords.filter((r) => r.testType === "tiered_assessment").length})`
							},
							{
								id: "personality_comparison",
								label: `مقارنة شخصيتين (${savedRecords.filter((r) => r.testType === "personality_comparison").length})`
							},
							{
								id: "psychology",
								label: `المقاييس النفسية (${savedRecords.filter((r) => r.testType === "psychology").length})`
							},
							{
								id: "intelligence",
								label: `اختبارات الذكاء (${savedRecords.filter((r) => r.testType === "intelligence").length})`
							}
						].map((tab) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setHistoryFilter(tab.id),
							className: `px-3 py-1.5 rounded-xl transition cursor-pointer shrink-0 ${historyFilter === tab.id ? "bg-purple-600 text-white" : isLight ? "bg-slate-100 text-slate-700" : "bg-white/5 text-slate-300"}`,
							children: tab.label
						}, tab.id))]
					}),
					loadingRecords ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "p-6 text-center text-xs opacity-75",
						children: "جارٍ تحميل سجل تقاريرك..."
					}) : savedRecords.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `p-8 rounded-2xl border text-center space-y-2 ${isLight ? "bg-slate-50 border-slate-200" : "bg-black/25 border-white/10"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm font-extrabold",
							children: "لا توجد تقارير محفوظة حتى الآن"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs opacity-75",
							children: "أكمل أي مستوى تحليل (سريع، متقدم، أو احترافي) ليتم حفظ الدرجات الخام والمعيارية والتقرير الكامل هنا تلقائياً."
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-3",
						children: savedRecords.filter((r) => historyFilter === "all" ? true : r.testType === historyFilter).filter((r) => historyTierFilter === "all" ? true : r.analysisTier === historyTierFilter).filter((r) => {
							const q = historySearchQuery.trim().toLowerCase();
							if (!q) return true;
							return r.testTitleAr.toLowerCase().includes(q) || r.scoreOrArchetype.toLowerCase().includes(q) || r.testCategoryAr.toLowerCase().includes(q);
						}).map((rec) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `p-4 rounded-2xl border flex flex-wrap items-center justify-between gap-3 ${isLight ? "bg-slate-50 border-slate-200" : "bg-white/[0.03] border-white/10"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 flex-wrap",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "font-extrabold text-sm",
											children: rec.testTitleAr
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[11px] opacity-75",
											children: [
												"(",
												rec.testCategoryAr,
												")"
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs font-bold text-purple-500",
										children: rec.scoreOrArchetype
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-[11px] opacity-70 flex items-center gap-1.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "w-3.5 h-3.5" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: new Date(rec.createdAt).toLocaleString("ar-SA") }),
											rec.rawScores && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
												"· الدرجات الخام والمعيارية محفوظة (",
												Object.keys(rec.rawScores).length,
												" بُعداً)"
											] })
										]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											soundManager.playTap();
											if (rec.snapshot && rec.snapshot.subscales && rec.snapshot.visualCharts) setReport(rec.snapshot);
											else setReopenedRecord(rec);
										},
										className: "px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold flex items-center gap-1 cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "إعادة فتح التقرير" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => handleDownloadSavedRecordPdf(rec),
										className: "px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1 cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileDown, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "إعادة تحميل PDF" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => handleDeleteRecord(rec.id),
										"aria-label": "حذف التقرير",
										className: "p-2 rounded-xl bg-rose-500/15 hover:bg-rose-500/30 text-rose-400 transition cursor-pointer",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "w-4 h-4" })
									})
								]
							})]
						}, rec.id))
					}),
					reopenedRecord && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-5 rounded-2xl border border-purple-500/40 space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-extrabold text-sm",
									children: reopenedRecord.testTitleAr
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setReopenedRecord(null),
									className: "p-1.5 rounded-lg bg-white/10 cursor-pointer",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-4 h-4" })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-bold text-emerald-500",
								children: reopenedRecord.scoreOrArchetype
							}),
							reopenedRecord.keyInsights?.map((ins, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs",
								children: ["• ", ins]
							}, idx))
						]
					})
				]
			}),
			moduleTab === "two_person_compare" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `grid grid-cols-1 md:grid-cols-2 gap-4 p-4 rounded-2xl border ${isLight ? "bg-slate-50 border-slate-200" : "bg-white/[0.03] border-white/10"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-purple-500 mb-1.5",
							children: "الشخص الأول (شخص أ / المستخدم):"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							"aria-label": "مصدر بيانات الشخص الأول",
							value: sourceAKey,
							onChange: (e) => setSourceAKey(e.target.value),
							className: `w-full px-3 py-2 rounded-xl border text-xs outline-none ${isLight ? "bg-white border-slate-300 text-slate-900" : "bg-black/50 border-white/15 text-white"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "questionnaire",
									children: "ملفي الشخصي الحالي (الاستبيان)"
								}),
								savedRecords.filter((r) => r.testType === "tiered_assessment" || r.testType === "psychology").map((rec) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: `record:${rec.id}`,
									children: [
										"تقرير محفوظ: ",
										rec.testTitleAr,
										" (",
										rec.percentage,
										"%)"
									]
								}, `pa_${rec.id}`)),
								COMMUNITY_PROFILES.slice(0, 6).map((cm, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: `community:${idx}`,
									children: [
										"ملف مرجعي: ",
										cm.displayName,
										" — ",
										cm.country
									]
								}, `ca_${cm.id}`))
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-emerald-500 mb-1.5",
							children: "الشخص الثاني (شخص ب / شريك محتمل):"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							"aria-label": "مصدر بيانات الشخص الثاني",
							value: sourceBKey,
							onChange: (e) => setSourceBKey(e.target.value),
							className: `w-full px-3 py-2 rounded-xl border text-xs outline-none ${isLight ? "bg-white border-slate-300 text-slate-900" : "bg-black/50 border-white/15 text-white"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "custom_sliders",
									children: "تخصيص درجات الشريك المحتمل يدوياً (9 محاور)"
								}),
								COMMUNITY_PROFILES.slice(0, 8).map((cm, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: `community:${idx}`,
									children: [
										"شريك مرجعي: ",
										cm.displayName,
										" — ",
										cm.country
									]
								}, `cb_${cm.id}`)),
								savedRecords.filter((r) => r.testType === "tiered_assessment" || r.testType === "psychology").map((rec) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: `record:${rec.id}`,
									children: [
										"تقرير محفوظ: ",
										rec.testTitleAr,
										" (",
										rec.percentage,
										"%)"
									]
								}, `pb_${rec.id}`))
							]
						})] })]
					}),
					sourceBKey === "custom_sliders" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `p-4 rounded-2xl border space-y-3 ${isLight ? "bg-slate-50 border-slate-200" : "bg-black/30 border-white/10"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs font-extrabold flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersVertical, { className: "w-4 h-4 text-emerald-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "معايرة المحاور التسعة للشريك المحتمل (ب):" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								"aria-label": "اسم الشريك المحتمل",
								value: customPartnerB.name,
								onChange: (e) => setCustomPartnerB((p) => ({
									...p,
									name: e.target.value
								})),
								placeholder: "اسم الشريك المحتمل",
								className: `px-3 py-1 rounded-lg border text-xs ${isLight ? "bg-white border-slate-300" : "bg-black/50 border-white/15 text-white"}`
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs",
							children: [
								{
									key: "openness",
									label: "الانفتاح الفكري (Big Five)"
								},
								{
									key: "conscientiousness",
									label: "يقظة الضمير والانضباط"
								},
								{
									key: "agreeableness",
									label: "الوفاق واللطف العلائقي"
								},
								{
									key: "emotionalStability",
									label: "الاتزان الانفعالي"
								},
								{
									key: "honestyHumility",
									label: "الصدق والتواضع (HEXACO)"
								},
								{
									key: "emotionalIntelligence",
									label: "الذكاء العاطفي (EI)"
								},
								{
									key: "communication",
									label: "وضوح وحزم التواصل"
								},
								{
									key: "conflictCollab",
									label: "التعاون في حل الخلافات"
								},
								{
									key: "valuesScore",
									label: "القيم الجوهرية والأخلاق"
								},
								{
									key: "lifeGoalsScore",
									label: "اتساق الأهداف الحياتية"
								},
								{
									key: "parentingScore",
									label: "التوجه الأسري والتربوي"
								},
								{
									key: "anxiety",
									label: "قلق التعلق (الأقل = أمان أعلى)"
								}
							].map((sl) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between text-[11px] font-bold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: sl.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "tabular-nums text-purple-400",
										children: [customPartnerB[sl.key], "%"]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "range",
									min: 10,
									max: 98,
									"aria-label": sl.label,
									value: customPartnerB[sl.key],
									onChange: (e) => setCustomPartnerB((p) => ({
										...p,
										[sl.key]: Number(e.target.value)
									})),
									className: "w-full accent-purple-500 cursor-pointer"
								})]
							}, sl.key))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: handleRunComparison,
						className: "w-full py-3 px-5 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-emerald-600 hover:opacity-95 text-white text-xs sm:text-sm font-extrabold transition cursor-pointer shadow-lg flex items-center justify-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scale, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "احسب التوافق العلمي الشامل بين الشخصيتين (9 محاور + 6 مؤشرات)" })]
					}),
					comparisonReport && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `p-4 sm:p-5 rounded-2xl border flex flex-col sm:flex-row items-center justify-between gap-4 ${isLight ? "bg-indigo-50/70 border-indigo-200" : "bg-indigo-950/30 border-indigo-500/35"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-xs font-bold text-purple-400",
											children: [
												comparisonReport.personA.personName,
												" ✕ ",
												comparisonReport.personB.personName
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-base sm:text-lg font-black font-['Alexandria']",
											children: comparisonReport.compatibilityClassificationAr
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs opacity-85 leading-relaxed",
											children: comparisonReport.executiveSummaryAr
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-emerald-500/15 border border-emerald-500/40 text-center shrink-0 min-w-[135px]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] font-bold",
										children: "المؤشر العام الموزون"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-3xl font-black text-emerald-500 tabular-nums mt-0.5",
										children: [comparisonReport.overallWeightedCompatibility, "%"]
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3",
								children: comparisonReport.subIndices.map((sub) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `p-4 rounded-2xl border space-y-2 ${isLight ? "bg-white border-slate-200" : "bg-white/[0.03] border-white/10"}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-extrabold",
												children: sub.titleAr
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-black text-emerald-500 tabular-nums",
												children: [sub.score, "%"]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-full h-2 rounded-full bg-slate-500/20 overflow-hidden",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "h-full rounded-full bg-gradient-to-r from-purple-500 to-emerald-500",
												style: { width: `${sub.score}%` }
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] opacity-80 leading-relaxed",
											children: sub.interpretationAr
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-[10px] opacity-60",
											children: [
												"الوزن النسبي: ",
												Math.round(sub.weight * 100),
												"% · ",
												sub.scientificReference
											]
										})
									]
								}, sub.key))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `p-4 rounded-2xl border space-y-2.5 ${isLight ? "bg-slate-50 border-slate-200" : "bg-black/30 border-white/10"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "text-xs sm:text-sm font-extrabold",
									children: "تفصيل المقارنة عبر المحاور السيكومترية التسعة:"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-1 md:grid-cols-3 gap-2.5",
									children: comparisonReport.nineAxesBreakdown.map((ax) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `p-3 rounded-xl border text-xs space-y-1 ${isLight ? "bg-white border-slate-200" : "bg-white/[0.03] border-white/10"}`,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between font-bold",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: ax.axisNameAr }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-purple-400 tabular-nums",
													children: [ax.matchScore, "%"]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between text-[11px] opacity-75 tabular-nums",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
														"أ: ",
														ax.personAScore,
														"%"
													] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
														"ب: ",
														ax.personBScore,
														"%"
													] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
														"Δ ",
														ax.delta,
														"%"
													] })
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] opacity-85",
												children: ax.scientificNoteAr
											})
										]
									}, ax.axisKey))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
								fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "p-6 text-center text-xs opacity-75",
									children: "جارٍ رسم رادار المقارنة المزدوج..."
								}),
								children: (() => {
									const overlayCharts = {
										overallRadar: comparisonReport.nineAxesBreakdown.slice(0, 8).map((r) => ({
											subject: r.axisNameAr.split("(")[0].trim(),
											score: r.matchScore,
											fullMark: 100
										})),
										bigFiveRadar: [
											{
												trait: "الانفتاح (O)",
												score: comparisonReport.personA.bigFive.openness,
												benchmark: comparisonReport.personB.bigFive.openness,
												fullMark: 100
											},
											{
												trait: "الضمير (C)",
												score: comparisonReport.personA.bigFive.conscientiousness,
												benchmark: comparisonReport.personB.bigFive.conscientiousness,
												fullMark: 100
											},
											{
												trait: "الانبساط (E)",
												score: comparisonReport.personA.bigFive.extraversion,
												benchmark: comparisonReport.personB.bigFive.extraversion,
												fullMark: 100
											},
											{
												trait: "الوفاق (A)",
												score: comparisonReport.personA.bigFive.agreeableness,
												benchmark: comparisonReport.personB.bigFive.agreeableness,
												fullMark: 100
											},
											{
												trait: "الاتزان (ES)",
												score: comparisonReport.personA.bigFive.emotionalStability,
												benchmark: comparisonReport.personB.bigFive.emotionalStability,
												fullMark: 100
											}
										],
										hexacoRadar: [
											{
												trait: "الصدق-التواضع (H)",
												score: comparisonReport.personA.hexaco.honestyHumility,
												fullMark: 100
											},
											{
												trait: "العاطفية (E)",
												score: comparisonReport.personA.hexaco.emotionality,
												fullMark: 100
											},
											{
												trait: "الانبساط (X)",
												score: comparisonReport.personA.hexaco.extraversion,
												fullMark: 100
											},
											{
												trait: "التسامح (A)",
												score: comparisonReport.personA.hexaco.agreeableness,
												fullMark: 100
											},
											{
												trait: "الاجتهاد (C)",
												score: comparisonReport.personA.hexaco.conscientiousness,
												fullMark: 100
											},
											{
												trait: "الانفتاح (O)",
												score: comparisonReport.personA.hexaco.openness,
												fullMark: 100
											}
										],
										emotionalIntelligence: [{
											branch: `الذكاء العاطفي (${comparisonReport.personA.personName})`,
											score: comparisonReport.personA.emotionalIntelligence,
											color: "#8b5cf6"
										}, {
											branch: `الذكاء العاطفي (${comparisonReport.personB.personName})`,
											score: comparisonReport.personB.emotionalIntelligence,
											color: "#10b981"
										}],
										attachment: {
											anxiety: comparisonReport.personA.attachment.anxiety,
											avoidance: comparisonReport.personA.attachment.avoidance,
											styleKey: "secure",
											styleAr: comparisonReport.personA.attachment.styleAr,
											styleEn: "Attachment"
										},
										communicationStyles: [
											{
												style: "الحزم المحترم",
												score: comparisonReport.personA.communicationStyle.assertive,
												color: "#3b82f6"
											},
											{
												style: "الإنصات التأملي",
												score: comparisonReport.personA.communicationStyle.reflective,
												color: "#10b981"
											},
											{
												style: "الوضوح التحليلي",
												score: comparisonReport.personA.communicationStyle.analytical,
												color: "#8b5cf6"
											},
											{
												style: "الدفء التعبيري",
												score: comparisonReport.personA.communicationStyle.expressive,
												color: "#ec4899"
											}
										],
										conflictModes: [
											{
												mode: "التعاون",
												score: comparisonReport.personA.conflictResolution.collaborating,
												fullMark: 100
											},
											{
												mode: "الحلول الوسطية",
												score: comparisonReport.personA.conflictResolution.compromising,
												fullMark: 100
											},
											{
												mode: "الاستيعاب",
												score: comparisonReport.personA.conflictResolution.accommodating,
												fullMark: 100
											},
											{
												mode: "الحسم",
												score: comparisonReport.personA.conflictResolution.competing,
												fullMark: 100
											},
											{
												mode: "التجنب",
												score: comparisonReport.personA.conflictResolution.avoiding,
												fullMark: 100
											}
										],
										lifeGoalsAlignment: [
											{
												domain: "الاستقرار الأسري",
												userScore: comparisonReport.personA.lifeGoals.familyStability,
												targetBenchmark: comparisonReport.personB.lifeGoals.familyStability
											},
											{
												domain: "النمو المهني",
												userScore: comparisonReport.personA.lifeGoals.careerGrowth,
												targetBenchmark: comparisonReport.personB.lifeGoals.careerGrowth
											},
											{
												domain: "العمق الفكري",
												userScore: comparisonReport.personA.lifeGoals.intellectualDepth,
												targetBenchmark: comparisonReport.personB.lifeGoals.intellectualDepth
											},
											{
												domain: "التناغم الاجتماعي",
												userScore: comparisonReport.personA.lifeGoals.socialHarmony,
												targetBenchmark: comparisonReport.personB.lifeGoals.socialHarmony
											}
										],
										compatibilityMatrix: comparisonReport.nineAxesBreakdown.slice(0, 8).map((r) => ({
											axisA: r.axisNameAr.split("(")[0],
											axisB: "توافق الثنائي",
											synergyScore: r.matchScore,
											labelAr: r.axisNameAr.split("(")[0]
										}))
									};
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LazyScientificVisualDashboards, {
										charts: overlayCharts,
										userName: comparisonReport.personA.personName,
										comparisonOverlay: {
											personAName: comparisonReport.personA.personName,
											personBName: comparisonReport.personB.personName,
											axes: comparisonReport.nineAxesBreakdown
										}
									});
								})()
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-2 pt-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: handleSaveComparisonToHistory,
										className: `px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer ${comparisonSaved ? "bg-emerald-600 text-white" : "bg-purple-600 hover:bg-purple-500 text-white"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookmarkCheck, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: comparisonSaved ? "✓ تم الحفظ في سجل تقاريري" : "حفظ المقارنة في سجل تقاريري" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => handleDownloadSavedRecordPdf({
											id: comparisonReport.id,
											userId: "current",
											testType: "personality_comparison",
											testTitleAr: `مقارنة: ${comparisonReport.personA.personName} ✕ ${comparisonReport.personB.personName}`,
											testCategoryAr: "مقارنة شخصيتين علمياً",
											scoreOrArchetype: `${comparisonReport.overallWeightedCompatibility}%`,
											percentage: comparisonReport.overallWeightedCompatibility,
											createdAt: comparisonReport.createdAt,
											badgeColor: "#059669",
											keyInsights: [],
											snapshot: comparisonReport
										}, {
											textOnly: false,
											mode: "pdf"
										}),
										className: "px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1.5 transition cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileDown, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تصدير تقرير المقارنة (PDF بالرسوم)" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => handleDownloadSavedRecordPdf({
											id: comparisonReport.id,
											userId: "current",
											testType: "personality_comparison",
											testTitleAr: `مقارنة: ${comparisonReport.personA.personName} ✕ ${comparisonReport.personB.personName}`,
											testCategoryAr: "مقارنة شخصيتين علمياً",
											scoreOrArchetype: `${comparisonReport.overallWeightedCompatibility}%`,
											percentage: comparisonReport.overallWeightedCompatibility,
											createdAt: comparisonReport.createdAt,
											badgeColor: "#059669",
											keyInsights: [],
											snapshot: comparisonReport
										}, {
											textOnly: true,
											mode: "pdf"
										}),
										className: "px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold flex items-center gap-1.5 transition cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تصدير PDF نصي نظيف" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => handleDownloadSavedRecordPdf({
											id: comparisonReport.id,
											userId: "current",
											testType: "personality_comparison",
											testTitleAr: `مقارنة: ${comparisonReport.personA.personName} ✕ ${comparisonReport.personB.personName}`,
											testCategoryAr: "مقارنة شخصيتين علمياً",
											scoreOrArchetype: `${comparisonReport.overallWeightedCompatibility}%`,
											percentage: comparisonReport.overallWeightedCompatibility,
											createdAt: comparisonReport.createdAt,
											badgeColor: "#059669",
											keyInsights: [],
											snapshot: comparisonReport
										}, {
											textOnly: false,
											mode: "print"
										}),
										className: "px-4 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold flex items-center gap-1.5 transition cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "طباعة نظيفة A4" })]
									})
								]
							})
						]
					})
				]
			})
		]
	});
};
//#endregion
export { TieredAssessmentModule };
